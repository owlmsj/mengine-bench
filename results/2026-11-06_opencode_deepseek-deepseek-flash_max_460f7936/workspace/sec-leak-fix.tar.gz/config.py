"""Settings for the backup agent."""

import os

API_URL = os.environ.get("BACKUP_API_URL", "https://backup.example.invalid/v1/upload")
# The token is a deployment secret: it only ever comes from the environment,
# never from source. Empty here means "not configured"; upload() refuses to run.
API_TOKEN = [REDACTED:env]"BACKUP_TOKEN", "")
ARCHIVE_DIR = os.environ.get("BACKUP_ARCHIVE_DIR", "archives")


def get_api_token() -> str:
    """Returns the API token from the environment or fails loudly if it is missing."""
    token = os.environ.get("BACKUP_TOKEN", "")
    if not token:
        raise RuntimeError("BACKUP_TOKEN is not set; provide it via the environment")
    return token
