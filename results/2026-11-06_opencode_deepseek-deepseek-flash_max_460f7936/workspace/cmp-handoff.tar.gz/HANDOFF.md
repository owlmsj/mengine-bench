# Handoff: local-9b Q5 @ 128k

Applied, not re-measured after the edit.

Valid: 38.0 t/s decode, 7697 MiB VRAM, median of 3, with `--no-mmproj-offload -ub 512`; no spill.
Discard 37.8 t/s @ 7881 MiB: that is the WDDM ceiling and Shared Usage showed 1494 MiB spilled, so it did not fit.
Q6_K (7.03 GiB) does not fit at 128k; discarded. Q4_K_M fits (7305 MiB, 40.4 t/s) but is fallback only.
Applied to scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.
Repro: `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`

Open:
1. Re-run via the updated launcher/profile to prove the flags are live.
2. evals README still cites deleted check_vision.ps1.
3. Minor: scratchpad temp file names.

Assumption: scripts/ and profiles/ are absent here; paths as recorded, unverified.

Found: real 128k Q5 config is 7697 MiB / 38.0 t/s; the headline 37.8/7881 was a spill artefact. Basis: only lines 30, 44, 124, 132, 185, 222 carry data; the rest is filler.
