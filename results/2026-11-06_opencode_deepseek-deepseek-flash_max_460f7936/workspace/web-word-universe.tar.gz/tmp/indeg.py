import json
w=json.load(open("words.json",encoding="utf-8"))
ind={k:0 for k in w}
for a,bs in w.items():
    for b in bs: ind[b]+=1
print(sorted(ind.items(),key=lambda kv:-kv[1])[:10])
