import os, re, json, html, unicodedata
from urllib.parse import unquote

SITE = "site"
files = [f for f in os.listdir(SITE) if f.lower().endswith(".html")]
DOC = re.compile(r"<h1>(.*?)</h1>", re.S)
TEMA = re.compile(r'<p class="tema">Tema:\s*(.*?)</p>', re.S)
SEC = re.compile(r'<section id="(sinonimos|analogas)">(.*?)</section>', re.S)
LINK = re.compile(r'<a href="([^"]+)">(.*?)</a>', re.S)
LI = re.compile(r"<li>(.*?)</li>", re.S)

def clean(s):
    return html.unescape(re.sub(r"<[^>]+>", "", s)).strip()

pages = {}
for f in files:
    raw = open(os.path.join(SITE, f), encoding="utf-8").read()
    m = DOC.search(raw)
    if not m:
        continue
    title = clean(m.group(1))
    t = TEMA.search(raw)
    theme = clean(t.group(1)) if t else None
    secs = {}
    for sm in SEC.finditer(raw):
        links = []
        for lm in LINK.finditer(sm.group(2)):
            href = unquote(lm.group(1))
            links.append((href, clean(lm.group(2))))
        secs[sm.group(1)] = links
    pages[f] = dict(file=f, word=title, theme=theme, sections=secs)

print("parsed pages", len(pages))
# pages without tema
print("no tema:", [(p['word'], p['file']) for p in pages.values() if not p['theme']])
# duplicate h1 (case-insensitive)
from collections import Counter, defaultdict
c = Counter(p['word'].lower() for p in pages.values())
print("dup h1:", [(w, n, [p['file'] for p in pages.values() if p['word'].lower()==w]) for w,n in c.items() if n>1])

# all link targets inside relation sections
targets = set()
missing = Counter()
for f,p in pages.items():
    for sec, links in p['sections'].items():
        for href,label in links:
            targets.add(href)
            if href not in pages:
                missing[href]+=1
print("relation targets", len(targets), "missing", missing)
# links outside sections named in relations? check
for p in pages.values():
    if not p['sections']:
        print("NO SECTIONS", p['file'], p['word'])
print("with relations:", sum(1 for p in pages.values() if p['sections']))
print("total relation links:", sum(len(v) for p in pages.values() for v in p['sections'].values()))
print("sample keys", sorted(pages)[:10])
print("special", [(p['word'],p['file']) for p in pages.values() if p['word'].lower()!=os.path.splitext(p['file'])[0].lower()][:30])
