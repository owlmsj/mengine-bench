import os, re, json, html, unicodedata
from urllib.parse import unquote
from collections import Counter, defaultdict

SITE = "site"
DOC = re.compile(r"<h1>(.*?)</h1>", re.S)
TEMA = re.compile(r'<p class="tema">Tema:\s*(.*?)</p>', re.S)
SEC = re.compile(r'<section id="(sinonimos|analogas)">(.*?)</section>', re.S)
LINK = re.compile(r'<a href="([^"]+)">(.*?)</a>', re.S)

def clean(s):
    return html.unescape(re.sub(r"<[^>]+>", "", s)).strip()

def norm(s):
    s = unicodedata.normalize("NFD", s.lower().strip())
    return "".join(c for c in s if unicodedata.category(c) != "Mn")

files = [f for f in os.listdir(SITE) if f.lower().endswith(".html")]
pages = {}
for f in files:
    raw = open(os.path.join(SITE, f), encoding="utf-8").read()
    m = DOC.search(raw)
    if not m:
        continue
    word = clean(m.group(1))
    if f.lower() in ("index.html", "sobre.html", "contato.html"):
        continue
    t = TEMA.search(raw)
    sections = {}
    for sm in SEC.finditer(raw):
        out = []
        for lm in LINK.finditer(sm.group(2)):
            out.append((unquote(lm.group(1)), clean(lm.group(2))))
        sections[sm.group(1)] = out
    pages[f] = {"file": f, "word": word, "theme": clean(t.group(1)) if t else "", "sections": sections}

redirect = {}
for f in files:
    raw = open(os.path.join(SITE, f), encoding="utf-8").read()
    if "<h1>" in raw:
        continue
    m = re.search(r'http-equiv="refresh" content="0; url=([^"]+)"', raw)
    if m:
        redirect[unquote(m.group(1)).lower()] = f

file_by_lower = {f.lower(): f for f in pages}

def resolve(href):
    h = href.lower()
    if h in file_by_lower:
        return file_by_lower[h]
    if h in redirect:
        target = redirect[h]
        if target.lower() in file_by_lower:
            return file_by_lower[target.lower()]
    return None

adj = defaultdict(set)
out_links = defaultdict(set)
syn = defaultdict(set)
ana = defaultdict(set)
broken = Counter()
self_links = 0
dup_links = 0
for f, p in pages.items():
    a = p["word"]
    seen = set()
    for sec, links in p["sections"].items():
        for href, label in links:
            tf = resolve(href)
            if not tf:
                broken[href] += 1
                continue
            b = pages[tf]["word"]
            if b == a:
                self_links += 1
                continue
            if b in seen:
                dup_links += 1
                continue
            seen.add(b)
            out_links[a].add(b)
            adj[a].add(b)
            adj[b].add(a)
            (syn if sec == "sinonimos" else ana)[a].add(b)

words = sorted(p["word"] for p in pages.values())
idx = {w: i for i, w in enumerate(words)}
words_json = {w: sorted(adj.get(w, ())) for w in words}
pairs = set()
for a, bs in adj.items():
    for b in bs:
        pairs.add(tuple(sorted((a, b))))

deg = {w: len(adj.get(w, ())) for w in words}
maxdeg = max(deg.values())
top = sorted([w for w, d in deg.items() if d == maxdeg])
result = {
    "words": len(words),
    "relations": len(pairs),
    "most_connected": top[0],
}

os.makedirs("universe", exist_ok=True)
with open("words.json", "w", encoding="utf-8") as fh:
    json.dump(words_json, fh, ensure_ascii=False, indent=1)
with open("result.json", "w", encoding="utf-8") as fh:
    json.dump(result, fh, ensure_ascii=False, indent=1)

theme_names = sorted({p["theme"] for p in pages.values()})
colors = {
    "sentimentos": "#e6b878",
    "corpo": "#e07f74",
    "família": "#c79ae2",
    "tempo": "#73b7dc",
    "natureza": "#8ecb92",
    "lugares": "#d7c46e",
    "comida": "#e19a5c",
    "ofícios": "#a9b6ca",
    "artes": "#e58fb0",
    "linguagem": "#77cfc0",
}
themes = [{"name": t, "color": colors.get(t, "#9aa3b5")} for t in theme_names]
theme_id = {t["name"]: i for i, t in enumerate(themes)}
data = {
    "words": [{"w": w, "t": theme_id[pages[[f for f in pages if pages[f]["word"] == w][0]]["theme"]],
               "d": deg[w]} for w in words],
    "themes": themes,
    "adj": [[idx[b] for b in sorted(adj[w])] for w in words],
    "syn": [[idx[b] for b in sorted(syn[w])] for w in words],
    "ana": [[idx[b] for b in sorted(ana[w])] for w in words],
    "stats": {"words": len(words), "relations": len(pairs), "most": top[0], "mostdeg": maxdeg},
}
with open("tmp/data.json", "w", encoding="utf-8") as fh:
    json.dump(data, fh, ensure_ascii=False, separators=(",", ":"))

print("words", len(words), "pairs", len(pairs), "result", result)
print("redirects used", redirect)
print("broken", broken, "self", self_links, "dups", dup_links)
print("top", top)
print("data bytes", os.path.getsize("tmp/data.json"))
