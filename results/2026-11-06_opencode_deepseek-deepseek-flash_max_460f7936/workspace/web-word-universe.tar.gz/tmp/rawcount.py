import os,re,html
from collections import Counter
out={}
for f in os.listdir("site"):
    if not f.endswith(".html"): continue
    raw=open("site/"+f,encoding="utf-8").read()
    m=re.search(r"<h1>(.*?)</h1>",raw,re.S)
    if not m: continue
    w=html.unescape(m.group(1)).strip()
    if w in ("Sobre","Contato","Dicionário Criativo"): continue
    sec="".join(re.findall(r'<section id="(?:sinonimos|analogas)">(.*?)</section>',raw,re.S))
    out[w]=len(re.findall(r"<a href=",sec))
print(sorted(out.items(),key=lambda kv:-kv[1])[:10])
