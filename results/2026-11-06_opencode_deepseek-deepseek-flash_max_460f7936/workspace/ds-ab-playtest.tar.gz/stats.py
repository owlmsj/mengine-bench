import csv, collections, math, random, statistics

rows = list(csv.DictReader(open('telemetry/playtest_ab.csv', newline='', encoding='utf-8-sig')))

# raw (no dedupe) rates
for v in ('a', 'b'):
    rr = [r for r in rows if r['variant'].strip().lower() == v]
    c = sum(int(r['completed_tutorial']) for r in rr)
    print('RAW', v, len(rr), c, c / len(rr))

sessions = {}
for r in rows:
    sid = r['session_id'].strip()
    if sid not in sessions:
        sessions[sid] = {
            'sid': sid,
            'variant': r['variant'].strip().lower(),
            'completed': int(r['completed_tutorial']),
            'player': r['player_id'].strip(),
            'minutes': float(r['match_minutes']),
        }

A = [s for s in sessions.values() if s['variant'] == 'a']
B = [s for s in sessions.values() if s['variant'] == 'b']
n1, n2 = len(A), len(B)
x1, x2 = sum(s['completed'] for s in A), sum(s['completed'] for s in B)
p1, p2 = x1 / n1, x2 / n2
pbar = (x1 + x2) / (n1 + n2)
se_pool = math.sqrt(pbar * (1 - pbar) * (1 / n1 + 1 / n2))
z = (p2 - p1) / se_pool
print('n', n1, n2, 'x', x1, x2, 'p', p1, p2, 'diff', p2 - p1)
print('pooled z', z)


def norm_sf(x):
    return 0.5 * math.erfc(x / math.sqrt(2))


p_two = 2 * norm_sf(abs(z))
print('two-sided p', p_two)
print('one-sided p (B>A)', norm_sf(-z))

# Wilson-ish CI for difference (unpooled)
se_un = math.sqrt(p1 * (1 - p1) / n1 + p2 * (1 - p2) / n2)
print('unpooled se', se_un, '95% CI', (p2 - p1) - 1.96 * se_un, (p2 - p1) + 1.96 * se_un)
print('chi2', z * z)

# Fisher exact two-sided
def logcomb(n, k):
    return math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1)


def hypergeom_pmf(k, n1, n2, x1x2):
    # k = completed in A; total successes fixed x1+x2
    return math.exp(logcomb(n1, k) + logcomb(n2, x1x2 - k) - logcomb(n1 + n2, x1x2))


lo = max(0, x1 + x2 - n2)
hi = min(n1, x1 + x2)
obs = hypergeom_pmf(x1, n1, n2, x1 + x2)
p_fish = sum(hypergeom_pmf(k, n1, n2, x1 + x2) for k in range(lo, hi + 1)
             if hypergeom_pmf(k, n1, n2, x1 + x2) <= obs + 1e-12)
print('fisher two-sided p', p_fish)

# distribution of sessions per player and variants
cnt = collections.Counter()
for s in sessions.values():
    cnt[s['player']] += 1
print('sessions per player', collections.Counter(cnt.values()))
print('max sessions player', max(cnt.values()))
by_player = collections.defaultdict(list)
for s in sessions.values():
    by_player[s['player']].append(s)
both = [p for p, ss in by_player.items() if len({s['variant'] for s in ss}) == 2]
print('players both variants', len(both))

# balance
ma = statistics.mean(s['minutes'] for s in A)
mb = statistics.mean(s['minutes'] for s in B)
print('mean minutes a,b', ma, mb)

# cluster robust linear probability model: completed = a + b*B, cluster by player
# OLS with intercept and B indicator; HC0 cluster-robust
X = []
y = []
clusters = []
for s in sessions.values():
    X.append([1.0, 1.0 if s['variant'] == 'b' else 0.0])
    y.append(float(s['completed']))
    clusters.append(s['player'])
n = len(y)
# beta = (X'X)^-1 X'y, 2x2
s00 = sum(row[0] * row[0] for row in X)
s01 = sum(row[0] * row[1] for row in X)
s11 = sum(row[1] * row[1] for row in X)
t0 = sum(row[0] * yy for row, yy in zip(X, y))
t1 = sum(row[1] * yy for row, yy in zip(X, y))
det = s00 * s11 - s01 * s01
b0 = (s11 * t0 - s01 * t1) / det
b1 = (s00 * t1 - s01 * t0) / det
print('OLS beta', b0, b1)
# meat sum over clusters of (X'e)(X'e)'
meat = [[0.0, 0.0], [0.0, 0.0]]
for cl in set(clusters):
    idx = [i for i, c in enumerate(clusters) if c == cl]
    g0 = sum(X[i][0] * (y[i] - b0 - b1 * X[i][1]) for i in idx)
    g1 = sum(X[i][1] * (y[i] - b0 - b1 * X[i][1]) for i in idx)
    meat[0][0] += g0 * g0
    meat[0][1] += g0 * g1
    meat[1][0] += g1 * g0
    meat[1][1] += g1 * g1
# bread = inv(X'X); cluster variance = bread * meat * bread * G/(G-1)
G = len(set(clusters))
bread = [[s11 / det, -s01 / det], [-s01 / det, s00 / det]]
tmp = [[sum(bread[i][k] * meat[k][j] for k in range(2)) for j in range(2)] for i in range(2)]
var = [[sum(tmp[i][k] * bread[k][j] for k in range(2)) * G / (G - 1) for j in range(2)] for i in range(2)]
se1 = math.sqrt(var[1][1])
zcr = b1 / se1
print('cluster robust G', G, 'se', se1, 'z', zcr, 'two-sided p', 2 * norm_sf(abs(zcr)), '95CI', (b1 - 1.96 * se1, b1 + 1.96 * se1))

# within-player permutation test: permute variant labels among each player's sessions
# statistic = B-A completion rate difference
obs_stat = p2 - p1
rng = random.Random(20261106)
count = 0
reps = 20000
for _ in range(reps):
    ca = cb = na = nb = 0
    for p, ss in by_player.items():
        labels = [s['variant'] for s in ss]
        comps = [s['completed'] for s in ss]
        rng.shuffle(labels)
        for lab, c in zip(labels, comps):
            if lab == 'a':
                na += 1; ca += c
            else:
                nb += 1; cb += c
    stat = (cb / nb if nb else 0) - (ca / na if na else 0)
    if abs(stat) >= abs(obs_stat) - 1e-15:
        count += 1
print('within-player permutation p', (count + 1) / (reps + 1), 'reps', reps)

# cluster bootstrap by player (resample players with replacement), percentile p / CI
boot = []
for _ in range(5000):
    ps = rng.choices(list(by_player), k=len(by_player))
    ca = cb = na = nb = 0
    for p in ps:
        for s in by_player[p]:
            if s['variant'] == 'a':
                na += 1; ca += s['completed']
            else:
                nb += 1; cb += s['completed']
    boot.append(cb / nb - ca / na)
boot.sort()
print('cluster bootstrap 95CI', boot[int(.025 * len(boot))], boot[int(.975 * len(boot))])
print('cluster bootstrap two-sided p (sign)', 2 * min(sum(b <= 0 for b in boot), sum(b >= 0 for b in boot)) / len(boot))
