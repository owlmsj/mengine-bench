import csv, collections, math, statistics

rows = list(csv.DictReader(open('telemetry/playtest_ab.csv', newline='', encoding='utf-8-sig')))
sessions = {}
for r in rows:
    sid = r['session_id'].strip()
    if sid not in sessions:
        sessions[sid] = dict(sid=sid, variant=r['variant'].strip().lower(),
                             completed=int(r['completed_tutorial']),
                             player=r['player_id'].strip(), minutes=float(r['match_minutes']))

# verify duplicate rows identical on all fields
by = collections.defaultdict(list)
for r in rows:
    by[r['session_id'].strip()].append(tuple(r[k] for k in ['variant', 'player_id', 'completed_tutorial', 'match_minutes']))
print('duplicate groups with differing payload', sum(1 for v in by.values() if len(set(v)) > 1))

A = [s for s in sessions.values() if s['variant'] == 'a']
B = [s for s in sessions.values() if s['variant'] == 'b']

def mean(xs): return sum(xs) / len(xs)
def sd(xs):
    m = mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1))
ma, mb = mean([s['minutes'] for s in A]), mean([s['minutes'] for s in B])
sa, sb = sd([s['minutes'] for s in A]), sd([s['minutes'] for s in B])
print('minutes mean/sd a', ma, sa, 'b', mb, sb, 'welch t', (mb - ma) / math.sqrt(sa**2/len(A) + sb**2/len(B)))

# completion rate by minutes quartile and variant
allm = sorted(s['minutes'] for s in sessions.values())
qs = [allm[int(len(allm) * q)] for q in (0.25, 0.5, 0.75)]
print('quartile cutoffs', qs)
def qidx(x):
    return sum(x > q for q in qs)
for v in ('a', 'b'):
    for qi in range(4):
        ss = [s for s in sessions.values() if s['variant'] == v and qidx(s['minutes']) == qi]
        print(v, 'Q', qi + 1, len(ss), round(sum(s['completed'] for s in ss) / len(ss), 4))

# OLS completed ~ 1 + B + minutes
X = [[1.0, 1.0 if s['variant'] == 'b' else 0.0, s['minutes']] for s in sessions.values()]
y = [float(s['completed']) for s in sessions.values()]
# normal equations 3x3
def matmul(A, B):
    return [[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def inv3(M):
    a,b,c = M[0]; d,e,f = M[1]; g,h,i = M[2]
    det = a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g)
    return [[(e*i-f*h)/det,(c*h-b*i)/det,(b*f-c*e)/det],
            [(f*g-d*i)/det,(a*i-c*g)/det,(c*d-a*f)/det],
            [(d*h-e*g)/det,(b*g-a*h)/det,(a*e-b*d)/det]]
XtX = [[sum(row[i]*row[j] for row in X) for j in range(3)] for i in range(3)]
Xty = [sum(row[i]*yy for row, yy in zip(X,y)) for i in range(3)]
beta = [sum(inv3(XtX)[i][j]*Xty[j] for j in range(3)) for i in range(3)]
print('OLS adj beta (intercept, B, minutes)', beta)
# classic SE
resid = [yy - sum(beta[j]*row[j] for j in range(3)) for row, yy in zip(X,y)]
sigma2 = sum(e*e for e in resid) / (len(y)-3)
V = [[inv3(XtX)[i][j]*sigma2 for j in range(3)] for i in range(3)]
print('adj B se,z,p', math.sqrt(V[1][1]), beta[1]/math.sqrt(V[1][1]), 2*0.5*math.erfc(abs(beta[1]/math.sqrt(V[1][1]))/math.sqrt(2)))
