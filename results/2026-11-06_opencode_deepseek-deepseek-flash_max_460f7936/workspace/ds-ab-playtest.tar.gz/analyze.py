import csv, collections, math

rows = list(csv.DictReader(open('telemetry/playtest_ab.csv', newline='', encoding='utf-8-sig')))
print('rows', len(rows))
print('fields', list(rows[0].keys()))
print('variants raw', collections.Counter(repr(r['variant']) for r in rows))
print('completed raw', collections.Counter(repr(r['completed_tutorial']) for r in rows))
ids = collections.Counter(r['session_id'] for r in rows)
print('unique ids', len(ids), 'dupes', sum(1 for v in ids.values() if v > 1), 'max repeat', max(ids.values()))

by = collections.defaultdict(list)
for r in rows:
    by[r['session_id']].append(r)

bad = []
for sid, rs in by.items():
    if (len({r['variant'].strip().lower() for r in rs}) > 1
            or len({r['completed_tutorial'] for r in rs}) > 1
            or len({r['player_id'] for r in rs}) > 1):
        bad.append((sid, rs))
print('conflicting ids', len(bad))
for sid, rs in bad[:10]:
    print(sid, rs)

# Deduplicate: session_id unique key; normalize variant; use first row
sessions = {}
for r in rows:
    sid = r['session_id'].strip()
    if sid not in sessions:
        sessions[sid] = {
            'variant': r['variant'].strip().lower(),
            'completed': int(r['completed_tutorial']),
            'player': r['player_id'].strip(),
            'minutes': float(r['match_minutes']),
        }
print('sessions', len(sessions))

for v in sorted({s['variant'] for s in sessions.values()}):
    ss = [s for s in sessions.values() if s['variant'] == v]
    comp = sum(s['completed'] for s in ss)
    print(v, 'n=', len(ss), 'completed=', comp, 'rate=', comp / len(ss))

# Players appearing in both variants
players = collections.defaultdict(set)
for s in sessions.values():
    players[s['player']].add(s['variant'])
print('players in both variants', sum(1 for v in players.values() if len(v) > 1))
print('unique players', len(players), 'sessions', len(sessions))

# breakdown by raw duplicate count
dup_sessions = {sid for sid, c in ids.items() if c > 1}
print('sessions duplicated', len(dup_sessions))
print('rows belonging to duplicated sessions', sum(ids[sid] for sid in dup_sessions))
