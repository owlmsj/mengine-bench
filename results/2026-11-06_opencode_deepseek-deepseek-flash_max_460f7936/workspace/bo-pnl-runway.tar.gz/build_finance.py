"""Build 2026 H1 monthly P&L and H1-locked burn/runway from ./finance.

Assumptions (stated because the brief leaves them open):
  - EBITDA = revenue (incl. refunds, acct 3.1.09) - cogs - sales_marketing - rnd - ga.
    Account 6.1.01 (investment income) and 6.1.02 (interest/IOF) are the
    financial line below EBITDA and are excluded from EBITDA and from burn.
  - Gross margin % = (revenue - cogs) / revenue, using net revenue after refunds.
  - Burn follows finance/README.md: average of the monthly negative EBITDA over
    the last three closed months (Apr-Jun 2026); runway = cash at 30/06/2026 / burn.
  - Amounts are nominal BRL; no accrual/timing normalization.
"""
import csv
import json
from collections import defaultdict
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FIN = ROOT / "finance"

PNL_ORDER = ["revenue", "cogs", "sales_marketing", "rnd", "ga", "financial"]


def brl_to_decimal(text: str) -> Decimal:
    """Parse Brazilian ledger amount: thousands '.' and decimal ','."""
    cleaned = text.strip().replace(".", "").replace(",", ".")
    return Decimal(cleaned)


def load_chart() -> dict[str, str]:
    with (FIN / "chart_of_accounts.csv").open(encoding="utf-8") as handle:
        return {
            row["account"]: row["pnl_line"]
            for row in csv.DictReader(handle, delimiter=";")
        }


def load_ledger() -> dict[str, dict[str, Decimal]]:
    """month -> pnl_line -> signed total."""
    chart = load_chart()
    totals: dict[str, dict[str, Decimal]] = defaultdict(
        lambda: defaultdict(Decimal)
    )
    unknown: list[str] = []
    with (FIN / "ledger.csv").open(encoding="utf-8") as handle:
        for row in csv.DictReader(handle, delimiter=";"):
            day, month, year = row["date"].split("/")
            if year != "2026":
                continue
            account = row["account"]
            if account not in chart:
                unknown.append(account)
                continue
            key = f"{year}-{month}"
            totals[key][chart[account]] += brl_to_decimal(row["amount"])
    if unknown:
        raise ValueError(f"ledger accounts missing from chart: {sorted(set(unknown))}")
    return totals


def monthly_statement(totals: dict[str, dict[str, Decimal]]) -> dict:
    months: dict[str, dict] = {}
    for key in sorted(totals):
        signed = {name: totals[key].get(name, Decimal("0")) for name in PNL_ORDER}
        # Ledger sign convention: inflows positive, outflows negative.
        # Normalize outflows to positive expense magnitudes for presentation.
        revenue = signed["revenue"]
        cogs = -signed["cogs"]
        sales_marketing = -signed["sales_marketing"]
        rnd = -signed["rnd"]
        ga = -signed["ga"]
        gross_profit = revenue - cogs
        ebitda = gross_profit - sales_marketing - rnd - ga
        months[key] = {
            "revenue": revenue,
            "cogs": cogs,
            "gross_profit": gross_profit,
            "gross_margin_pct": (gross_profit / revenue * 100) if revenue else None,
            "sales_marketing": sales_marketing,
            "rnd": rnd,
            "ga": ga,
            "ebitda": ebitda,
            "financial": signed["financial"],
            "net_income": ebitda + signed["financial"],
        }
    return months


def main() -> None:
    months = monthly_statement(load_ledger())
    if list(months) != [f"2026-{m:02d}" for m in range(1, 7)]:
        raise ValueError(f"expected 2026-01..2026-06, got {list(months)}")

    closed = ["2026-04", "2026-05", "2026-06"]
    burn = sum(-months[m]["ebitda"] for m in closed) / len(closed)
    cash = Decimal("1847350.40")  # cash_balance.txt, 30/06/2026
    runway = cash / burn

    result = {
        "revenue": {m: float(v["revenue"]) for m, v in months.items()},
        "gross_margin_pct": {
            m: round(float(v["gross_margin_pct"]), 2) for m, v in months.items()
        },
        "ebitda": {m: float(v["ebitda"]) for m, v in months.items()},
        "burn": float(burn),
        "runway_months": round(float(runway), 2),
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )

    columns = [
        "revenue",
        "cogs",
        "gross_profit",
        "gross_margin_pct",
        "sales_marketing",
        "rnd",
        "ga",
        "ebitda",
        "financial",
        "net_income",
    ]
    with (ROOT / "monthly_pnl.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["month", *columns])
        for key, v in months.items():
            writer.writerow(
                [
                    key,
                    *[
                        f"{v[c]:.2f}" if c != "gross_margin_pct" else f"{v[c]:.2f}"
                        for c in columns
                    ],
                ]
            )

    print(
        "month    revenue      gross%   ebitda       net_income"
    )
    for key, v in months.items():
        print(
            f"{key}  {v['revenue']:>11,.2f}  {v['gross_margin_pct']:>6.1f}%"
            f"  {v['ebitda']:>11,.2f}  {v['net_income']:>11,.2f}"
        )
    print(f"\nburn (avg Apr-Jun negative EBITDA): {burn:,.2f}")
    print(f"cash 30/06/2026: {cash:,.2f}")
    print(f"runway_months: {runway:.2f}")
    total_rev = sum(v["revenue"] for v in months.values())
    total_ebitda = sum(v["ebitda"] for v in months.values())
    print(f"H1 revenue {total_rev:,.2f}  H1 EBITDA {total_ebitda:,.2f}")


if __name__ == "__main__":
    main()
