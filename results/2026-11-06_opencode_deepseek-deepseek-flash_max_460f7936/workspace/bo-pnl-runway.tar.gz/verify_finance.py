"""Independent cross-check of build_finance.py output (different code path)."""
import csv
from decimal import Decimal
from pathlib import Path

FIN = Path(__file__).resolve().parent / "finance"
amount = lambda s: Decimal(s.replace(".", "").replace(",", "."))

chart = {}
with (FIN / "chart_of_accounts.csv").open(encoding="utf-8") as fh:
    for row in csv.DictReader(fh, delimiter=";"):
        chart[row["account"]] = row["pnl_line"]

rows = list(csv.DictReader((FIN / "ledger.csv").open(encoding="utf-8"), delimiter=";"))
print("ledger rows:", len(rows))
print("years:", sorted({r["date"][6:] for r in rows}))
print("accounts not in chart:", sorted({r["account"] for r in rows} - set(chart)))

by_month = {}
for r in rows:
    key = f"{r['date'][6:]}-{r['date'][3:5]}"
    line = chart[r["account"]]
    d = by_month.setdefault(key, {})
    d[line] = d.get(line, Decimal(0)) + amount(r["amount"])

total_pnl = Decimal(0)
for key in sorted(by_month):
    d = by_month[key]
    ebitda = sum(d.get(k, Decimal(0)) for k in ("revenue", "cogs", "sales_marketing", "rnd", "ga"))
    total_pnl += sum(d.values())
    print(
        key,
        f"rev={d['revenue']:>12,.2f}",
        f"cogs={d['cogs']:>11,.2f}",
        f"sm={d['sales_marketing']:>11,.2f}",
        f"rnd={d['rnd']:>11,.2f}",
        f"ga={d['ga']:>10,.2f}",
        f"fin={d.get('financial', 0):>9,.2f}",
        f"EBITDA={ebitda:>12,.2f}",
        f"net={sum(d.values()):>12,.2f}",
    )
print("sum of all ledger amounts:", f"{total_pnl:,.2f}")

burn = sum(
    -sum(by_month[m].get(k, Decimal(0)) for k in ("revenue", "cogs", "sales_marketing", "rnd", "ga"))
    for m in ("2026-04", "2026-05", "2026-06")
) / 3
print("burn:", f"{burn:,.2f}", "runway:", f"{Decimal('1847350.40') / burn:.4f}")
