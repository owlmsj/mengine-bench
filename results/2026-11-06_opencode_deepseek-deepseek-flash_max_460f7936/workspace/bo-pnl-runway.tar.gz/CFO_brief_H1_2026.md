# H1 2026 CFO briefing

Prepared from `finance/ledger.csv` (86 P&L entries, Jan-Jun 2026), `finance/chart_of_accounts.csv`, `finance/cash_balance.txt` and the board's definitions in `finance/README.md`. All figures BRL, nominal. The full monthly build is in `monthly_pnl.csv`; the summary figures are in `result.json`.

## Headline

| Metric | H1 2026 | Read |
|---|---:|---|
| Revenue (net of refunds) | 1,389,492.82 | June exit run-rate 272,391.57/month |
| Gross margin | 70.2% | Stable, 68.5%-72.4% by month |
| EBITDA | -1,218,969.18 | Loss narrowed from -210.3k (Jan) to -193.0k (Jun) |
| Net loss | -1,179,354.45 | Includes +39,614.73 net financial income |
| Cash, 30/06/2026 | 1,847,350.40 | Board burn 197,288.23 -> **9.36 months** |
| Board burn (avg Apr-Jun negative EBITDA) | 197,288.23 | Runway to ~April 2027 |
| Cash-watch runway | 4.00 months | June cash fell 461,837.60 vs 187,346.57 net loss |

## Monthly P&L

| Month | Revenue | MoM | Gross margin | EBITDA | Net income |
|---|---:|---:|---:|---:|---:|
| 2026-01 | 200,510.87 | - | 70.03% | -210,278.96 | -203,812.19 |
| 2026-02 | 216,328.06 | +7.9% | 70.29% | -212,300.08 | -205,001.69 |
| 2026-03 | 219,066.17 | +1.3% | 68.46% | -204,525.45 | -198,078.94 |
| 2026-04 | 238,163.26 | +8.7% | 70.24% | -196,950.65 | -189,670.28 |
| 2026-05 | 243,032.89 | +2.0% | 69.56% | -201,945.82 | -195,444.78 |
| 2026-06 | 272,391.57 | +12.1% | 72.41% | -192,968.22 | -187,346.57 |

H1 total revenue 1,389,492.82 (+35.8% Jan to Jun). H1 gross profit 976,022.59.

## How each month went

- **January** - Opening month: 200.5k revenue, 70.0% gross margin, EBITDA -210.3k. Base cost run-rate already ~351k opex.
- **February** - Revenue +7.9%, margin +0.3pp, but R&D jumped to 182.3k and EBITDA slipped 2.0k to -212.3k. Growth did not drop through.
- **March** - Revenue only +1.3% while COGS rose 7.5%; margin fell 1.8pp to 68.5%, the weakest month. EBITDA -204.5k.
- **April** - Revenue +8.7% and margin back to 70.2%; EBITDA improved 7.6k to -197.0k, the first clear operating leverage.
- **May** - Revenue +2.0%, margin 69.6%, R&D 185.9k; EBITDA gave back 5.0k to -201.9k. Refund of 8.6k booked.
- **June** - Best month on every line: revenue +12.1% to 272.4k, margin 72.4%, EBITDA -193.0k (loss down 8.2% from January). Subscription revenue is the engine: 1,260,553.79, or 90.7% of H1 net revenue.

## What the numbers say

1. **Top line is working.** Revenue grew 35.8% in five months with subscriptions at 90.7% of net revenue. Sales and marketing stayed essentially flat (143.5k in Jan, 151.9k in Jun) while revenue grew, so acquisition efficiency improved.
2. **Gross margin is stable at ~70%.** June's 72.4% is the high; March's 68.5% the low. No structural margin problem.
3. **Opex is eating the contribution.** Gross profit rose 56.8k from Jan to Jun, but opex rose 39.5k (R&D +26.6k, S&M +8.4k, G&A +4.5k), leaving only 17.3k of EBITDA improvement. R&D at 190.0k is the largest single cost line and grew 16% in H1.
4. **Break-even is roughly double June revenue.** At June's 72.4% margin and 390.2k opex, break-even needs ~538.9k monthly revenue (+98% vs June). At the H1 average monthly growth rate (~6.3%) that is about 12 months - beyond the 9.4-month board runway. Cost action or a financing decision is needed now, not at the trough.
5. **Cash is the real story.** The board's EBITDA definition gives 9.36 months, but June cash fell 461,837.60 while the P&L net loss was 187,346.57. About 274,491.03 of June outflow is not in the P&L (capex, working capital, tax, or financing). If that pace repeats, runway is 4.00 months, not 9.36. One month is not a trend, but the gap must be reconciled before the investor meeting; the board metric overstates runway by about 5 months if the outflow is recurring.

## Runway

- Board definition (per `finance/README.md`): burn = mean of Apr, May, Jun negative EBITDA = (196,950.65 + 201,945.82 + 192,968.22) / 3 = **197,288.23**.
- Runway = 1,847,350.40 / 197,288.23 = **9.36 months**, i.e. cash through roughly April 2027.
- Cash-watch downside: 1,847,350.40 / 461,837.60 = **4.00 months**, i.e. through roughly October 2026.
- No April cash balance is available, so a full H1 cash-flow bridge cannot be built from the files.

## Assumptions

1. EBITDA = net revenue (subscriptions + onboarding - refunds) - COGS - sales & marketing - R&D - G&A. Investment income (6.1.01) and interest/IOF (6.1.02) are treated as below-EBITDA financial items and excluded.
2. Gross margin % = (net revenue - COGS) / net revenue, with refunds netted against revenue per the chart of accounts (3.1.09 -> revenue).
3. Burn uses the board's written definition: average monthly negative EBITDA of the last three closed months (Apr-Jun 2026). Runway uses the latest closing cash balance (30/06/2026).
4. Figures are accrual P&L as booked, nominal BRL. No normalization for one-offs, seasonality or FX; no capex, receivables, payables or debt data beyond the two cash snapshots.
5. All 86 ledger rows are 2026 and every account maps to a P&L line. No rows were excluded.

## Presenting to investors

- Lead with growth and gross margin: +35.8% in H1, 70%+ margin, 90.7% subscription mix.
- Show the loss narrowing (-210.3k to -193.0k) and the June exit run-rate of 3.27M annualized, but do not claim operating leverage until opex growth decelerates.
- Disclose runway on the board definition (9.4 months) and pre-empt the cash question with the June bridge and the 4.0-month downside. Better to surface the 274.5k gap than be asked.
- Ask: approve a cost plan to hold opex flat and/or start the next raise now, with 9-12 months of cushion targeted before cash falls below six months.

## Verification

- 86 ledger rows, all dated 2026; 13 accounts, all present in the chart of accounts.
- Two independent computations (`build_finance.py` and `verify_finance.py`) agree to the cent on every monthly line.
- Monthly net income sums to -1,179,354.45, which equals H1 EBITDA -1,218,969.18 plus net financial income 39,614.73.
- Account totals: revenue 1,389,492.82; COGS 413,470.23; S&M 847,420.60; R&D 1,073,109.97; G&A 274,461.20.
- `result.json` is generated by `build_finance.py` and contains the six monthly values plus burn and runway.
