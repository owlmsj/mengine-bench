//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex, MutexGuard};

pub type PlayerId = u32;

#[derive(Default)]
struct Scores {
    players: HashMap<PlayerId, i64>,
    total: i64,
}

/// Clones share the same scores, so each match thread keeps its own handle.
///
/// Every operation takes the single state lock, so a score and the board total
/// are always updated together and lock order can never invert.
#[derive(Clone, Default)]
pub struct Board {
    scores: Arc<Mutex<Scores>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    fn lock(&self) -> MutexGuard<'_, Scores> {
        // A panic elsewhere must not make the shared board unusable.
        self.scores
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        let mut scores = self.lock();
        let previous = scores.players.insert(id, score);
        // A repeated join replaces the old score and keeps total == sum(scores).
        scores.total += score - previous.unwrap_or(0);
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let mut scores = self.lock();
        let slot = scores
            .players
            .get_mut(&id)
            .unwrap_or_else(|| panic!("award for unknown player {id}"));
        *slot += points;
        scores.total += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let mut scores = self.lock();
        if !scores.players.contains_key(&from) {
            panic!("transfer from unknown player {from}");
        }
        if !scores.players.contains_key(&to) {
            panic!("transfer to unknown player {to}");
        }
        if from == to {
            return;
        }

        *scores.players.get_mut(&from).unwrap() -= points;
        *scores.players.get_mut(&to).unwrap() += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self
            .lock()
            .players
            .get(&id)
            .unwrap_or_else(|| panic!("score for unknown player {id}"))
    }

    pub fn total(&self) -> i64 {
        self.lock().total
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Barrier;
    use std::thread;

    #[test]
    fn concurrent_awards_keep_every_point() {
        let board = Board::new();
        board.join(1, 0);
        let barrier = Arc::new(Barrier::new(8));
        let handlers: Vec<_> = (0..8)
            .map(|_| {
                let board = board.clone();
                let barrier = barrier.clone();
                thread::spawn(move || {
                    barrier.wait();
                    for _ in 0..1_000 {
                        board.award(1, 1);
                    }
                })
            })
            .collect();
        for handler in handlers {
            handler.join().unwrap();
        }
        assert_eq!((board.score(1), board.total()), (8_000, 8_000));
    }

    #[test]
    fn opposite_and_self_transfers_do_not_deadlock() {
        let board = Board::new();
        board.join(1, 500_000);
        board.join(2, 500_000);
        let barrier = Arc::new(Barrier::new(8));
        let handlers: Vec<_> = (0..8)
            .map(|worker| {
                let board = board.clone();
                let barrier = barrier.clone();
                thread::spawn(move || {
                    barrier.wait();
                    for _ in 0..1_000 {
                        if worker % 2 == 0 {
                            board.transfer(1, 2, 1);
                        } else {
                            board.transfer(2, 1, 1);
                        }
                        board.transfer(1, 1, 7);
                    }
                })
            })
            .collect();
        for handler in handlers {
            handler.join().unwrap();
        }
        assert_eq!(
            board.score(1) + board.score(2),
            board.total(),
            "transfers must conserve the total"
        );
    }
}
