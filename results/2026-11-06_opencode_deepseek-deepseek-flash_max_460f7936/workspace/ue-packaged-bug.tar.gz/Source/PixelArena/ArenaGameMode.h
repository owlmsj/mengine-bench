#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "ArenaGameMode.generated.h"

class UArenaHud;
class UArenaPalette;
class UArenaScoreTracker;
struct FArenaStats;

UCLASS()
class PIXELARENA_API AArenaGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type Reason) override;

	void OnGoalScored(int32 TeamIndex);

private:
	UPROPERTY()
	TObjectPtr<UArenaHud> Hud;

	UPROPERTY()
	TObjectPtr<UArenaPalette> Palette;

	// UPROPERTY keeps the NewObject-created tracker reachable by GC.
	UPROPERTY()
	TObjectPtr<UArenaScoreTracker> ScoreTracker = nullptr;

	// Plain C++ data owned by this class, freed in EndPlay.
	FArenaStats* Stats = nullptr;
};
