/**
 * Hook bus for harness plugins (OpenCode-style hooks). The README states the contract:
 * handlers run one after another in subscription order, emit resolves after all of them,
 * a handler error rejects emit, and unsubscribing during an emit does not stop the others.
 */

export type Handler<T> = (payload: T) => void | Promise<void>;

/** One subscription. Removed by identity so duplicate handlers unsubscribe independently. */
type Registration = { handler: Handler<unknown> };

export class HookBus {
  private handlers: Map<string, Registration[]> = new Map();

  /** Subscribes a handler to an event; returns the function that unsubscribes it. */
  on<T>(event: string, handler: Handler<T>): () => void {
    const list = this.handlers.get(event) ?? [];
    const registration: Registration = { handler: handler as Handler<unknown> };
    list.push(registration);
    this.handlers.set(event, list);

    let subscribed = true;
    return () => {
      if (!subscribed) {
        return;
      }
      subscribed = false;
      const current = this.handlers.get(event);
      if (!current) {
        return;
      }
      const index = current.indexOf(registration);
      if (index >= 0) {
        current.splice(index, 1);
      }
      if (current.length === 0) {
        this.handlers.delete(event);
      }
    };
  }

  /** Runs the handlers of an event with the payload, sequentially, in subscription order. */
  async emit<T>(event: string, payload: T): Promise<void> {
    // Snapshot: subscriptions changed during the emit apply from the next emit on.
    const snapshot = this.handlers.get(event)?.slice() ?? [];
    for (const registration of snapshot) {
      await registration.handler(payload);
    }
  }

  /** How many handlers an event has. */
  count(event: string): number {
    return this.handlers.get(event)?.length ?? 0;
  }
}
