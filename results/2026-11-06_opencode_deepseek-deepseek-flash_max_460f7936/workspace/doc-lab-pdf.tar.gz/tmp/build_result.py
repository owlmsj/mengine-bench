# Build ./result.json from ./exams/*.pdf.
# Strategy: read value + unit from each report, convert report 2 into report 1's
# units, and validate the conversion by also converting report 2's reference
# range and comparing it with report 1's printed range.
import json
import re
from pathlib import Path

import pymupdf

ROOT = Path(__file__).resolve().parents[1]
ALFA = ROOT / "exams" / "laudo_alfa.pdf"
BETA = ROOT / "exams" / "resultado_beta.pdf"
OUT = ROOT / "result.json"

# canonical marker -> conversion from beta unit to alfa unit
# glucose: mg/dL = mmol/L * 18.016 (MW 180.16 g/mol)
# LDL cholesterol: mg/dL = mmol/L * 38.67 (MW 386.65 g/mol)
# creatinine: mg/dL = umol/L / 88.4 (MW 113.12 g/mol)
# HbA1c: NGSP % = 0.09148 * IFCC mmol/mol + 2.152 (IFCC/NGSP master equation)
FACTORS = {
    "GLICOSE EM JEJUM": ("mmol/L", "mg/dL", lambda v: v * 18.016),
    "COLESTEROL LDL": ("mmol/L", "mg/dL", lambda v: v * 38.67),
    "CREATININA": ("umol/L", "mg/dL", lambda v: v / 88.4),
    "HEMOGLOBINA GLICADA (HbA1c)": ("mmol/mol", "%", lambda v: 0.09148 * v + 2.152),
}

LABEL_TO_MARKER = {
    "glicose em jejum": "GLICOSE EM JEJUM",
    "colesterol ldl": "COLESTEROL LDL",
    "creatinina": "CREATININA",
    "hemoglobina glicada (hba1c)": "HEMOGLOBINA GLICADA (HbA1c)",
}


def num(text: str) -> float:
    return float(text.strip().replace(".", "").replace(",", "."))


def norm_unit(unit: str) -> str:
    # micro sign U+00B5 and Greek mu U+03BC both mean micro
    return unit.strip().replace("\u00b5", "u").replace("\u03bc", "u")


def parse_alfa(path: Path):
    text = pymupdf.open(path)[0].get_text()
    date = re.search(r"Data da coleta:\s*(\d{2})/(\d{2})/(\d{4})", text)
    iso = f"{date.group(3)}-{date.group(2)}-{date.group(1)}"
    blocks = re.findall(
        r"^([A-ZÇÃÕÉÊÁÍÓÚÂÔ ]+?(?:\s*\([^)]*\))?)\n"
        r"Resultado:\s*([\d.,]+)\s*([^\n]+?)\n"
        r"Valor de referência:\s*([^\n]+)$",
        text,
        re.M,
    )
    values, ranges = {}, {}
    for name, value, unit, ref in blocks:
        name = name.strip()
        values[name] = (num(value), unit.strip())
        ranges[name] = ref.strip()
    assert len(values) == 4, values
    return iso, values, ranges


def parse_beta(path: Path):
    text = pymupdf.open(path)[0].get_text()
    date = re.search(r"Coleta:\s*(\d{2})/(\d{2})/(\d{4})", text)
    iso = f"{date.group(3)}-{date.group(2)}-{date.group(1)}"
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    header = lines.index("Valores de referência")
    rows = {}
    i = header + 1
    while i + 3 < len(lines):
        label, value, unit, ref = lines[i : i + 4]
        key = label.lower()
        if key not in LABEL_TO_MARKER:
            break
        rows[LABEL_TO_MARKER[key]] = (num(value), unit, ref)
        i += 4
    assert len(rows) == 4, rows
    return iso, rows


alfa_date, alfa_values, alfa_ranges = parse_alfa(ALFA)
beta_date, beta_rows = parse_beta(BETA)

def conv_for(marker: str):
    return FACTORS[marker][2]

history = {}
worse = []
checks = []
for marker, (value, unit) in alfa_values.items():
    beta_value, beta_unit, beta_ref = beta_rows[marker]
    src_unit, dst_unit, conv = FACTORS[marker]
    assert unit == dst_unit, (marker, unit, dst_unit)
    assert norm_unit(beta_unit) == src_unit, (marker, beta_unit, src_unit)
    converted = conv(beta_value)
    # store at the reporting precision of the first report: integers for the
    # two mg/dL lipids/glucose, 2 decimals for creatinine, 1 for HbA1c %
    if marker in ("GLICOSE EM JEJUM", "COLESTEROL LDL"):
        stored = int(round(converted))
    elif marker == "CREATININA":
        stored = round(converted, 2)
    else:
        stored = round(converted, 1)
    history[marker] = {alfa_date: value, beta_date: stored}

    # consistency check: convert beta's printed reference range with the same
    # factor; it should reproduce alfa's printed range (within printed rounding)
    if "-" in beta_ref:
        lo_s, hi_s = [p.strip() for p in beta_ref.split("-")]
        lo, hi = conv(num(lo_s)), conv(num(hi_s))
    else:
        hi = conv(num(beta_ref.lstrip("<").strip()))
        lo = None
    if marker == "GLICOSE EM JEJUM":
        alo, ahi, hi_inclusive = 70.0, 99.0, True
    elif marker == "COLESTEROL LDL":
        alo, ahi, hi_inclusive = None, 130.0, False  # "inferior a 130"
    elif marker == "CREATININA":
        alo, ahi, hi_inclusive = 0.70, 1.30, True
    else:
        alo, ahi, hi_inclusive = 4.0, 5.6, True
    tol = 0.06 * max(abs(ahi), 1.0)
    ok = (ahi is None or abs(hi - ahi) <= tol) and (
        alo is None or abs(lo - alo) <= tol
    )
    checks.append((marker, beta_ref, lo, hi, alo, ahi, ok))
    assert ok, (marker, lo, hi, alo, ahi)

    # "worse" = numerically higher (all four are high-is-worse) and outside
    # the first report's own printed reference limits; classify on the
    # unrounded converted value, not the rounded display value
    got_worse = converted > value
    outside = False
    if ahi is not None:
        outside = converted > ahi or (hi_inclusive is False and converted == ahi)
    elif alo is not None:
        outside = converted < alo
    if got_worse and outside:
        worse.append(marker)

OUT.write_text(
    json.dumps({"history": history, "worse": worse}, ensure_ascii=False, indent=2) + "\n",
    encoding="utf-8",
)
print("dates", alfa_date, beta_date)
for c in checks:
    print("check", c)
print("history")
print(json.dumps(history, ensure_ascii=False, indent=2))
print("worse", worse)
