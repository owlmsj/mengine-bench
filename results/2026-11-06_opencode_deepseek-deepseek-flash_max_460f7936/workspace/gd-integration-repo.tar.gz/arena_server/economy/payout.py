"""Match payout. Rules live in docs/ECONOMY.md."""

from decimal import Decimal, ROUND_HALF_UP


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    raw = (base + kills * cfg["kill_bonus"]) * cfg["event_multiplier"]
    rounded = Decimal(str(raw)).quantize(Decimal("1E1"), rounding=ROUND_HALF_UP)
    return int(rounded)
