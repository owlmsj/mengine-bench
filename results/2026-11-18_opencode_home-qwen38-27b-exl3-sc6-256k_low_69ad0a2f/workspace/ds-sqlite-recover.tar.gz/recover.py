import struct, json

data = open('prices.db','rb').read()
print("file size:", len(data))

def varint(buf, off):
    # SQLite varint: 1-9 bytes, big-endian, high bit of first 8 bytes means continue
    result = 0
    for i in range(9):
        if off+i >= len(buf):
            return None, off
        b = buf[off+i]
        if i == 8:
            result = (result << 8) | b
            return result, off+9
        result = (result << 7) | (b & 0x7f)
        if not (b & 0x80):
            return result, off+i+1
    return result, off+9

# Page header
ptype = data[0]
print("page type byte:", ptype)
first_free, = struct.unpack('>H', data[1:3])
ncells, = struct.unpack('>H', data[3:5])
content_start, = struct.unpack('>H', data[5:7])
frag = data[7]
print("first_free:", first_free, "ncells:", ncells, "content_start:", content_start, "frag:", frag)

# interior page: header 12 bytes, cell ptrs start at 12
# leaf page: header 8 bytes, cell ptrs start at 8
# Try both. For interior index (13): 12-byte header.
hdr = 12 if ptype in (5,13) else 8
ptrs = []
for i in range(ncells):
    o = hdr + 2*i
    if o+2 > len(data): break
    p, = struct.unpack('>H', data[o:o+2])
    ptrs.append(p)
print("cell pointers:", ptrs)

# Parse each cell as a table leaf cell (rowid + record)
def parse_record(buf, off):
    # returns (rowid, [values]) or None
    # payload length varint
    plen, o = varint(buf, off)
    if plen is None: return None
    rowid, o2 = varint(buf, o)
    if rowid is None: return None
    # record starts at o2
    hdrlen, o3 = varint(buf, o2)
    if hdrlen is None: return None
    # serial types
    serials = []
    oo = o3
    while oo < o3 + hdrlen:
        st, oo = varint(buf, oo)
        if st is None: break
        serials.append(st)
    # body
    body_off = o2 + hdrlen
    vals = []
    for st in serials:
        if st == 0:
            vals.append(None)
        elif st == 1:
            vals.append(struct.unpack('>b', buf[body_off:body_off+1])[0]); body_off+=1
        elif st == 2:
            vals.append(int.from_bytes(buf[body_off:body_off+2],'big',signed=True)); body_off+=2
        elif st == 3:
            vals.append(int.from_bytes(buf[body_off:body_off+3],'big',signed=True)); body_off+=3
        elif st == 4:
            vals.append(int.from_bytes(buf[body_off:body_off+4],'big',signed=True)); body_off+=4
        elif st == 5:
            vals.append(int.from_bytes(buf[body_off:body_off+6],'big',signed=True)); body_off+=6
        elif st == 6:
            vals.append(int.from_bytes(buf[body_off:body_off+8],'big',signed=True)); body_off+=8
        elif st == 7:
            vals.append(struct.unpack('>d', buf[body_off:body_off+8])[0]); body_off+=8
        elif st == 8:
            vals.append(0)
        elif st == 9:
            vals.append(1)
        elif st >= 12 and st % 2 == 0:
            n = (st-12)//2
            vals.append(buf[body_off:body_off+n].decode('utf-8','replace')); body_off+=n
        elif st >= 13 and st % 2 == 1:
            n = (st-13)//2
            vals.append(buf[body_off:body_off+n]); body_off+=n
        else:
            vals.append(None)
    return rowid, vals

rows = []
for p in ptrs:
    if p == 0: 
        print("  null pointer"); continue
    if p >= len(data):
        print(f"  ptr {p} out of range"); continue
    rec = parse_record(data, p)
    print(f"  ptr {p}: {rec}")
    if rec:
        rows.append(rec)

print("\nParsed rows:")
for r in rows:
    print(r)