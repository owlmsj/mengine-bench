import csv, json, os
from collections import defaultdict

base = os.path.dirname(os.path.abspath(__file__))

# chart of accounts
coa = {}
with open(os.path.join(base, "chart_of_accounts.csv"), encoding="utf-8") as f:
    r = csv.reader(f, delimiter=";")
    header = next(r)
    for row in r:
        if len(row) >= 3:
            coa[row[0].strip()] = row[2].strip()

def parse_amt(s):
    s = s.strip().replace(" ", "")
    neg = s.startswith("-")
    s = s.lstrip("-")
    # Brazilian format: 1.234.567,89
    s = s.replace(".", "").replace(",", ".")
    v = float(s)
    return -v if neg else v

months = ["2026-01","2026-02","2026-03","2026-04","2026-05","2026-06"]
tot = {m: defaultdict(float) for m in months}

with open(os.path.join(base, "ledger.csv"), encoding="utf-8") as f:
    r = csv.reader(f, delimiter=";")
    next(r)
    for row in r:
        if len(row) < 4:
            continue
        d, acct, desc, amt = row[0].strip(), row[1].strip(), row[2].strip(), row[3]
        dd, mm, yyyy = d.split("/")
        m = f"{yyyy}-{mm}"
        line = coa.get(acct)
        if m in tot and line:
            tot[m][line] += parse_amt(amt)

result = {}
for m in months:
    t = tot[m]
    rev = t["revenue"]
    cogs = t["cogs"]
    ebitda = (rev + t["cogs"] + t["sales_marketing"] + t["rnd"] + t["ga"] + t["financial"])
    result[m] = {
        "revenue": round(rev, 2),
        "cogs": round(cogs, 2),
        "sales_marketing": round(t["sales_marketing"], 2),
        "rnd": round(t["rnd"], 2),
        "ga": round(t["ga"], 2),
        "financial": round(t["financial"], 2),
        "ebitda": round(ebitda, 2),
        "gross_margin_pct": round((rev + cogs) / rev * 100, 2) if rev else None,
    }

# burn: avg monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = [result[m]["ebitda"] for m in ["2026-04","2026-05","2026-06"]]
neg = [v for v in last3 if v < 0]
burn = round(-sum(neg) / len(neg), 2)
cash = 1847350.40
runway = round(cash / burn, 2)

out = {
    "revenue": {m: result[m]["revenue"] for m in months},
    "gross_margin_pct": {m: result[m]["gross_margin_pct"] for m in months},
    "ebitda": {m: result[m]["ebitda"] for m in months},
    "burn": burn,
    "runway_months": runway,
    "_detail": {m: result[m] for m in months},
    "_cash_2026_06": cash,
    "_ebitda_last3": last3,
}
with open(os.path.join(os.path.dirname(base), "result.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2, ensure_ascii=False)
print(json.dumps(out, indent=2, ensure_ascii=False))