"""Bounded-concurrency task runner for batch scripts.

Usage:
    from run import run_tasks

Assumptions (brief left these open):
- Tasks are zero-arg callables returning awaitables (coroutines or
  Futures). They are called lazily, only when a slot frees up.
- max_concurrent < 1 raises ValueError.
- Exceptions from jobs are collected, not raised; run_tasks returns
  a list of (task_callable, result_or_exception) pairs in input order.
  This keeps one bad job from cancelling the rest.
- Ctrl+C: on KeyboardInterrupt or cancellation, every in-flight job is
  cancelled and awaited (so its finally/cleanup code runs) before the
  exception propagates. Uses asyncio.TaskGroup (3.11+) for correct
  child cancellation semantics.
"""

from __future__ import annotations

import asyncio
from typing import Any, Awaitable, Callable, Sequence


async def run_tasks(
    tasks: Sequence[Callable[[], Awaitable[Any]]],
    max_concurrent: int,
) -> list[tuple[Callable[[], Awaitable[Any]], Any]]:
    """Run zero-arg awaitable-returning callables, at most max_concurrent at once.

    Returns when every job has finished (successfully or with an
    exception). Returns a list of (callable, result_or_exception) in
    input order. On KeyboardInterrupt or cancellation, in-flight jobs
    are cancelled and awaited (so their cleanup code runs) before the
    exception propagates.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent}")

    results: list[tuple[Callable[[], Awaitable[Any]], Any]] = [
        (t, None) for t in tasks
    ]
    semaphore = asyncio.Semaphore(max_concurrent)

    async def _run_one(index: int, task: Callable[[], Awaitable[Any]]) -> None:
        async with semaphore:
            job = task()
            try:
                results[index] = (task, await job)
            except BaseException as exc:  # noqa: BLE001 - recorded, not re-raised
                results[index] = (task, exc)

    try:
        async with asyncio.TaskGroup() as tg:
            for i, t in enumerate(tasks):
                tg.create_task(_run_one(i, t))
    except (KeyboardInterrupt, asyncio.CancelledError):
        # TaskGroup already cancelled all children on exit and awaited
        # them, so their finally/cleanup code has run. Re-raise so the
        # signal propagates to the caller.
        raise

    return results