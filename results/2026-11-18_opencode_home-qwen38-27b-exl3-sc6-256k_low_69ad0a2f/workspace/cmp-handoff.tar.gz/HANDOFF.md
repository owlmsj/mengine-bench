# HANDOFF - local-9b @ 128k

Measure local-9b Q5 at 128k (131072). Done, fix applied.

## Findings (measured)
- Baseline: 37.8 t/s, VRAM 7881 MiB (WDDM ceiling). Shared Usage shows 1494 MiB spilled to system RAM - the real problem.
- Fix: `--no-mmproj-offload` + `-ub 512` removes the spill. Final 7697 MiB, 38.0 t/s (median of 3).
- Quant: Q6_K (7.03 GiB) does NOT fit at 128k, discarded. Q4_K_M fits (7305 MiB, 40.4 t/s), fallback only. Q5 is the working config.

## Fix applied to
- `scripts/start_server.ps1:165` (local9 block)
- `profiles/local/local-9b.json`

## Still open
1. evals README cites `check_vision.ps1` - file no longer exists. Update it.
2. Review the scratchpad temp file names (noted repeatedly, never done).

## How I know it is right
From `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024` and the GPU Shared Usage counter (reports actual spill, not the WDDM-capped total). Median of 3, not one sample.

## Assumptions
- "local-9b Q5" = the Q5 quant in `profiles/local/local-9b.json`; measured that exact build.
- The spill fix is the deliverable; speed is secondary (38.0 vs 37.8 t/s is within noise).