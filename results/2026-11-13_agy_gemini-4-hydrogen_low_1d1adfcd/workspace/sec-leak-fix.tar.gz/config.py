"""Settings for the backup agent."""

API_URL = "https://backup.example.invalid/v1/upload"
ARCHIVE_DIR = "archives"
