# Handoff: local-9b Q5 at 128k Context

## Goal & Status
Measure and configure `local-9b` Q5 for 128k (`131072`) context. Configuration is complete; only docs cleanup remains.

## Findings
- Baseline (`pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`): 37.8 t/s, 7881 MiB VRAM, but hit WDDM ceiling with 1494 MiB spilled to Shared Usage (invalid).
- Fix (`--no-mmproj-offload` and `-ub 512`): eliminates spill. Final VRAM: 7697 MiB; final decode: 38.0 t/s (median of 3).
- Alternatives: `Q6_K` (7.03 GiB) does not fit at 128k (discarded). `Q4_K_M` fits (7305 MiB, 40.4 t/s), kept only as fallback.

## Changes Applied
- `scripts/start_server.ps1:165` (`local9` block)
- `profiles/local/local-9b.json`

## Next
- Update the evals README, which still cites `check_vision.ps1` (file no longer exists).
