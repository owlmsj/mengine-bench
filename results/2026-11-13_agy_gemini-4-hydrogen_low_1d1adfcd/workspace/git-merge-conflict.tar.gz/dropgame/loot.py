"""Loot drops for the dungeon crawler."""

RARE_CHANCE = 0.05
PITY_LIMIT = 10


class LootTable:
    """Decides what one defeated monster drops."""

    def __init__(self, event_multiplier: float = 1.0) -> None:
        self.misses = 0
        self.event_multiplier = event_multiplier

    def drop(self, roll: float) -> str:
        """Return "rare" or "common" for a roll in [0, 1).

        A roll below the rare chance drops a rare.
        During an event the rare chance is RARE_CHANCE times event_multiplier, capped at 1.
        Pity timer: after PITY_LIMIT common drops in a row, the next drop is rare whatever the roll.
        Any rare drop, however it came, resets the count of commons in a row to zero.
        """
        chance = min(1.0, RARE_CHANCE * self.event_multiplier)
        if self.misses >= PITY_LIMIT or roll < chance:
            self.misses = 0
            return "rare"
        self.misses += 1
        return "common"
