import json
import struct


def read_varint(buf: bytes, pos: int) -> tuple[int, int]:
    val = 0
    for i in range(8):
        b = buf[pos + i]
        val = (val << 7) | (b & 0x7F)
        if not (b & 0x80):
            return val, pos + i + 1
    b = buf[pos + 8]
    val = (val << 8) | b
    return val, pos + 9


def decode_serial_type(st: int, buf: bytes, pos: int) -> tuple[object, int]:
    if st == 0:
        return None, pos
    if st == 1:
        return struct.unpack(">b", buf[pos : pos + 1])[0], pos + 1
    if st == 2:
        return struct.unpack(">h", buf[pos : pos + 2])[0], pos + 2
    if st == 3:
        raw = buf[pos : pos + 3]
        val = int.from_bytes(raw, "big", signed=True)
        return val, pos + 3
    if st == 4:
        return struct.unpack(">i", buf[pos : pos + 4])[0], pos + 4
    if st == 5:
        val = int.from_bytes(buf[pos : pos + 6], "big", signed=True)
        return val, pos + 6
    if st == 6:
        return struct.unpack(">q", buf[pos : pos + 8])[0], pos + 8
    if st == 7:
        return struct.unpack(">d", buf[pos : pos + 8])[0], pos + 8
    if st == 8:
        return 0, pos
    if st == 9:
        return 1, pos
    if st >= 12 and st % 2 == 0:
        n = (st - 12) // 2
        return buf[pos : pos + n], pos + n
    if st >= 13 and st % 2 == 1:
        n = (st - 13) // 2
        return buf[pos : pos + n].decode("utf-8"), pos + n
    raise ValueError(f"Unsupported serial type {st}")


def main() -> None:
    data = open("prices.db", "rb").read()
    assert data[0] == 0x0D, f"Expected leaf table page (0x0d), got {hex(data[0])}"
    num_cells = struct.unpack(">H", data[3:5])[0]
    ptrs = [struct.unpack(">H", data[8 + 2 * i : 10 + 2 * i])[0] for i in range(num_cells)]

    rows = []
    for ptr in ptrs:
        payload_len, pos = read_varint(data, ptr)
        rowid, pos = read_varint(data, pos)
        hdr_len, hdr_pos = read_varint(data, pos)
        hdr_end = pos + hdr_len
        serial_types = []
        while hdr_pos < hdr_end:
            st, hdr_pos = read_varint(data, hdr_pos)
            serial_types.append(st)
        val_pos = hdr_end
        cols = []
        for st in serial_types:
            val, val_pos = decode_serial_type(st, data, val_pos)
            cols.append(val)
        print(f"rowid={rowid} cols={cols}")
        if len(cols) == 2:
            rows.append({"item": cols[0], "price": cols[1]})
        elif len(cols) >= 3:
            # In case id is stored as NULL or int in col 0
            rows.append({"item": cols[1], "price": cols[2]})

    with open("recovered.json", "w", encoding="utf-8") as f:
        json.dump(rows, f, indent=2, ensure_ascii=False)
    print(f"Wrote {len(rows)} rows to recovered.json")


if __name__ == "__main__":
    main()
