import sqlite3, struct

data = open("prices.db", "rb").read()
print("len:", len(data), "magic:", data[:16])
page_size = struct.unpack(">H", data[16:18])[0]
print("page_size:", page_size)
db_pages = struct.unpack(">I", data[28:32])[0]
print("db_pages:", db_pages)

# Page 1 btree header starts at offset 100
page_type = data[100]
num_cells = struct.unpack(">H", data[103:105])[0]
cell_start = struct.unpack(">H", data[105:107])[0]
print(f"page1: type={hex(page_type)}, num_cells={num_cells}, cell_start={cell_start}")

try:
    con = sqlite3.connect("prices.db")
    print("tables:", con.execute("SELECT name, sql FROM sqlite_master").fetchall())
except Exception as e:
    print("sqlite3 err:", e)
