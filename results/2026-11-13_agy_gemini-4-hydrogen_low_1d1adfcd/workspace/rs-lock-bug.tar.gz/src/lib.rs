//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        *slot.lock().unwrap() += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return;
        }
        let from_slot = self.slot(from);
        let to_slot = self.slot(to);
        if from < to {
            let mut from_score = from_slot.lock().unwrap();
            let mut to_score = to_slot.lock().unwrap();
            *from_score -= points;
            *to_score += points;
        } else {
            let mut to_score = to_slot.lock().unwrap();
            let mut from_score = from_slot.lock().unwrap();
            *from_score -= points;
            *to_score += points;
        }
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}

#[cfg(test)]
mod tests {
    use super::Board;
    use std::thread;

    #[test]
    fn self_transfer_is_noop() {
        let board = Board::new();
        board.join(1, 50);
        board.transfer(1, 1, 20);
        assert_eq!(board.score(1), 50);
        assert_eq!(board.total(), 50);
    }

    #[test]
    fn concurrent_awards_do_not_lose_points() {
        let board = Board::new();
        board.join(1, 0);
        let threads = 8;
        let iters = 5_000;

        thread::scope(|s| {
            for _ in 0..threads {
                let b = board.clone();
                s.spawn(move || {
                    for _ in 0..iters {
                        b.award(1, 1);
                    }
                });
            }
        });

        let expected = (threads * iters) as i64;
        assert_eq!(board.score(1), expected);
        assert_eq!(board.total(), expected);
    }

    #[test]
    fn concurrent_opposite_transfers_do_not_deadlock() {
        let board = Board::new();
        board.join(1, 10_000);
        board.join(2, 10_000);
        let iters = 5_000;

        thread::scope(|s| {
            let b1 = board.clone();
            s.spawn(move || {
                for _ in 0..iters {
                    b1.transfer(1, 2, 1);
                }
            });
            let b2 = board.clone();
            s.spawn(move || {
                for _ in 0..iters {
                    b2.transfer(2, 1, 1);
                }
            });
        });

        assert_eq!(board.score(1), 10_000);
        assert_eq!(board.score(2), 10_000);
        assert_eq!(board.total(), 20_000);
    }
}
