from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Iterable
from typing import TypeVar

T = TypeVar("T")


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[T]]],
    max_concurrent: int,
) -> list[T]:
    """Run zero-arg task factories concurrently up to ``max_concurrent``.

    Each task factory is called only after a concurrency slot is acquired,
    preventing unawaited-coroutine warnings if cancelled early. On
    cancellation (e.g. Ctrl+C), ``asyncio.TaskGroup`` cancels all running
    jobs and awaits their cleanup before propagating ``CancelledError``.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent!r}")

    task_list = list(tasks)
    if not task_list:
        return []

    semaphore = asyncio.Semaphore(max_concurrent)
    results: list[T] = [None] * len(task_list)  # type: ignore[list-item]

    async def _worker(index: int, factory: Callable[[], Awaitable[T]]) -> None:
        async with semaphore:
            results[index] = await factory()

    async with asyncio.TaskGroup() as tg:
        for idx, factory in enumerate(task_list):
            tg.create_task(_worker(idx, factory))

    return results
