import csv, json, statistics

rows = []
with open(r"<WORKSPACE>\capture\presentmon.csv") as f:
    for r in csv.DictReader(f):
        rows.append(r)

n = len(rows)
t0 = float(rows[0]["TimeInSeconds"])
t1 = float(rows[-1]["TimeInSeconds"])
durs = [float(r["MsBetweenPresents"]) for r in rows]
seconds = (t1 - t0)
avg_fps = n / seconds
p99 = sorted(durs)[int(0.99 * len(durs))]
low1 = 1000 / p99
print("frames:", n, "seconds:", seconds, "avg_fps:", round(avg_fps, 2), "p99_ms:", p99, "low1:", round(low1, 2))
# hitches: gaps > 12ms
h = [(rows[i]["TimeInSeconds"], durs[i]) for i in range(n) if durs[i] > 12]
print("hitches (>12ms):", h)