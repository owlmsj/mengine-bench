import csv
rows = list(csv.DictReader(open(r"<WORKSPACE>\capture\sensors.csv")))
# sensor is 1s sample; hitch starts at 2.4, 6.4, 10.4, ... i.e. t mod 4 == 2.4
# check sensor rows in windows [2.4,2.64+~0.24s burst] -> seconds 2..3, 6..7, ...
for r in rows:
    t = int(r["time_s"])
    if (t - 2) % 4 == 0 and t <= 3:
        pass
print("sensor rows where t mod 4 in {2,3} (hitch window):")
for r in rows:
    t = int(r["time_s"])
    if (t - 2) % 4 == 0 or (t - 3) % 4 == 0:
        print(t, r["cpu_clock_mhz"], r["cpu_util_pct"], r["gpu_pcie_link_state"], r["dpc_latency_us"], r["disk_active_pct"], r["top_cpu_process"])