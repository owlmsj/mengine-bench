"""Backup agent: packs a folder chosen in the intranet web form and uploads it to the backup API."""

from __future__ import annotations

import logging
import subprocess
import urllib.request
from pathlib import Path

import config

log = logging.getLogger("backup_agent")


def _safe_folder(folder: str) -> Path:
    """Resolves the user-typed folder to an existing directory, rejecting path tricks."""
    p = Path(folder)
    if not p.is_absolute() and not p.is_absolute():
        p = Path.cwd() / p
    p = p.resolve()
    if not p.is_dir():
        raise ValueError(f"folder is not a directory: {folder!r}")
    return p


def archive_folder(folder: str, out_dir: str = config.ARCHIVE_DIR) -> Path:
    """Packs `folder` into `out_dir/<folder name>.tar.gz` and returns the archive path."""
    src = _safe_folder(folder)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    target = out / (src.name + ".tar.gz")
    subprocess.run(["tar", "-czf", str(target), str(src)], check=True)
    return target


def send_archive(path: Path, url: str, token: str) -> int:
    """Uploads one archive to the backup API and returns the HTTP status."""
    request = urllib.request.Request(url, data=path.read_bytes(), method="POST",
                                     headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.status


def upload(path: Path) -> int:
    log.info("uploading %s", path)
    return send_archive(path, config.API_URL, config.API_TOKEN)


def handle_form(form: dict[str, str]) -> int:
    """Web form handler: backs up the folder the user typed."""
    archive = archive_folder(form["folder"])
    log.info("archived %s", archive)
    return upload(archive)