import csv, json
from collections import defaultdict

base = r"<WORKSPACE>\finance"
pnl = {}
with open(base + r"\chart_of_accounts.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        pnl[row["account"]] = row["pnl_line"]

months = ["2026-01","2026-02","2026-03","2026-04","2026-05","2026-06"]
agg = {m: defaultdict(float) for m in months}
with open(base + r"\ledger.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        d = row["date"]
        dd, mm, yyyy = d.split("/")
        m = f"{yyyy}-{mm}"
        if m not in agg: continue
        amt = float(row["amount"].replace(".", "").replace(",", "."))
        agg[m][pnl[row["account"]]] += amt

out = {}
ebitda = {}
for m in months:
    a = agg[m]
    rev = a["revenue"]
    cogs = a["cogs"]
    gross = rev + cogs  # cogs negative
    gm = gross / rev * 100 if rev else 0.0
    e = sum(a.values())  # all P&L lines incl financial
    ebitda[m] = round(e, 2)
    out[m] = {"revenue": round(rev, 2), "gross_margin_pct": round(gm, 2), "ebitda": round(e, 2)}

# board burn: avg monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = [ebitda[m] for m in ["2026-04","2026-05","2026-06"]]
burn = -sum(last3) / len(last3)
cash = 1847350.40
runway = cash / burn

result = {
    "revenue": {m: out[m]["revenue"] for m in months},
    "gross_margin_pct": {m: out[m]["gross_margin_pct"] for m in months},
    "ebitda": {m: out[m]["ebitda"] for m in months},
    "burn": round(burn, 2),
    "runway_months": round(runway, 2),
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
print(json.dumps(result, indent=2))