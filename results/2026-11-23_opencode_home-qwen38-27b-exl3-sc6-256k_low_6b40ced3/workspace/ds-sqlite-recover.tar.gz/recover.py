import struct, json

data = open('prices.db','rb').read()
PAGE = 4096
# File is a single 4096-byte page with no 100-byte db header (truncated).
# B-tree leaf header is at absolute offset 0x0f33; cell pointers are absolute
# offsets within this file.
h = 0
assert data[h] == 0x0d, 'not table leaf'
ncells = struct.unpack('>H', data[h+3:h+5])[0]
cellptrs = [struct.unpack('>H', data[h+8+2*i:h+10+2*i])[0] for i in range(ncells)]
print('ncells', ncells, 'cellptrs', cellptrs)

def varint(b, i):
    v = 0
    for n in range(9):
        byte = b[i+n]
        if n == 8:
            v = (v << 8) | byte
            return v, i+9
        v = (v << 7) | (byte & 0x7f)
        if not byte & 0x80:
            return v, i+n+1
    raise ValueError

rows = []
dropped = []
for cp in cellptrs:
    off = cp
    payload_len, i = varint(data, off)
    rowid, i = varint(data, i)
    # record header
    hstart = i
    hdr_len, j = varint(data, i)
    hdr_end = hstart + hdr_len
    types = []
    while j < hdr_end:
        t, j = varint(data, j)
        types.append(t)
    body = hdr_end
    vals = []
    ok = True
    for t in types:
        if t == 0:
            vals.append(None)
        elif t == 1:
            vals.append(struct.unpack('>b', data[body:body+1])[0]); body += 1
        elif t == 2:
            vals.append(struct.unpack('>h', data[body:body+2])[0]); body += 2
        elif t == 3:
            vals.append(struct.unpack('>i', data[body:body+3])[0]); body += 3
        elif t == 4:
            vals.append(struct.unpack('>i', data[body:body+4])[0]); body += 4
        elif t == 5:
            vals.append(struct.unpack('>q', data[body:body+6])[0]); body += 6
        elif t == 6:
            vals.append(struct.unpack('>q', data[body:body+8])[0]); body += 8
        elif t == 7:
            vals.append(struct.unpack('>d', data[body:body+8])[0]); body += 8
        elif t >= 12 and t % 2 == 0:
            n = (t - 12)//2
            vals.append(data[body:body+n].decode('utf-8', 'replace')); body += n
        elif t >= 13 and t % 2 == 1:
            n = (t - 13)//2
            vals.append(data[body:body+n]); body += n
        else:
            ok = False; break
    print('rowid', rowid, 'payload', payload_len, 'types', types, 'vals', vals, 'body_end', body, 'ok', ok)
    if ok and body <= len(data) and isinstance(vals[1], (str, bytes)) and isinstance(vals[2], (int, float)):
        item = vals[1].decode('utf-8') if isinstance(vals[1], bytes) else vals[1]
        rows.append({'item': item, 'price': vals[2]})
    else:
        dropped.append((rowid, vals))

print('recovered', len(rows))
print('dropped (price bytes zeroed/unreadable):', dropped)
open('recovered.json','w',encoding='utf-8').write(json.dumps(rows, ensure_ascii=False, indent=2))
print(open('recovered.json',encoding='utf-8').read())