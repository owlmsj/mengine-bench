"""Batch helper: run zero-argument async factory callables with bounded concurrency."""

import asyncio


async def run_tasks(tasks, max_concurrent):
    """Run each task's job with at most max_concurrent jobs in flight.

    Each entry of ``tasks`` is a zero-argument callable returning an
    awaitable job. Jobs are started lazily as earlier ones finish, so at
    most ``max_concurrent`` run at once. Returns once every job is done,
    propagating the first exception raised by any job.

    On Ctrl+C the caller's KeyboardInterrupt is allowed to propagate;
    in-flight jobs are cancelled first so their ``finally`` / cleanup
    code runs.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent!r}")

    async def _run(task):
        job = task()
        try:
            return await job
        except asyncio.CancelledError:
            # Re-raise after the job's own cleanup (finally blocks) has run.
            raise

    semaphore = asyncio.Semaphore(max_concurrent)
    pending = set()

    async def _worker(task):
        async with semaphore:
            return await _run(task)

    try:
        for task in tasks:
            pending.add(asyncio.ensure_future(_worker(task)))
        # Wait for all, propagating the first exception.
        return await asyncio.gather(*pending)
    except BaseException:
        # Cancel remaining jobs so their cleanup code runs, then wait for
        # them to finish cleaning up before propagating.
        for future in pending:
            future.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
        raise