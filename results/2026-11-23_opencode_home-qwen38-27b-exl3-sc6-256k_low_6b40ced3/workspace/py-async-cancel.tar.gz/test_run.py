import asyncio
import time
from run import run_tasks

async def main():
    # 1) Bounded concurrency
    active = 0
    max_seen = 0
    async def job():
        nonlocal active, max_seen
        active += 1
        max_seen = max(max_seen, active)
        await asyncio.sleep(0.05)
        active -= 1

    t0 = time.monotonic()
    results = await run_tasks([job] * 10, 3)
    dt = time.monotonic() - t0
    assert max_seen <= 3, max_seen
    assert len(results) == 10
    # 10 jobs / 3 slots * 0.05s = ~0.2s
    assert 0.15 < dt < 0.6, dt
    print("bounded concurrency OK", max_seen, round(dt, 3))

    # 2) Cleanup runs when cancelled
    cleaned = []
    async def job2():
        try:
            await asyncio.sleep(10)
        finally:
            cleaned.append(1)

    async def cancel_later():
        await asyncio.sleep(0.05)
        for t in asyncio.all_tasks():
            if t is not asyncio.current_task():
                t.cancel()

    task = asyncio.ensure_future(run_tasks([job2] * 4, 2))
    await cancel_later()
    try:
        await task
    except (asyncio.CancelledError, Exception):
        pass
    await asyncio.sleep(0.05)
    assert cleaned, "cleanup did not run"
    print("cleanup on cancel OK", len(cleaned))

    # 3) Exception propagates
    async def bad():
        raise ValueError("boom")
    try:
        await run_tasks([bad], 2)
        assert False
    except ValueError as e:
        assert str(e) == "boom"
    print("exception propagation OK")

asyncio.run(main())
print("ALL OK")