# Handoff: local-9b Q5 at 128k context

Goal: run local-9b Q5 at 128k without VRAM spill.

Done (per session transcript):
- Baseline `scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`: 37.8 t/s, 7881 MiB, but WDDM ceiling with 1494 MiB spilled - invalid.
- Fix: `--no-mmproj-offload` + `-ub 512` -> spill gone, 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k - discarded. Q4_K_M fits (7305 MiB, 40.4 t/s) - fallback only.
- Recipe applied: scripts/start_server.ps1:165 (local9 block), profiles/local/local-9b.json.

Open:
1. evals README still cites check_vision.ps1, which no longer exists - update it.
2. Review scratchpad temp file names (noted repeatedly, never done).

Assumption: the repo (scripts/, profiles/, evals/) is not in this folder; only the transcript is. Numbers are the transcript's, not re-measured here.

Found: working recipe is `--no-mmproj-offload -ub 512`, Q5 at 128k, 38.0 t/s, no spill. Known from the transcript's measurement (median of 3).