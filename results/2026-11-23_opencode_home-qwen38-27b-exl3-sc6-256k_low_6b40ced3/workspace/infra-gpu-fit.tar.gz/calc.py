import csv, json

weights_gb = 70.0  # 70B params * 1 byte (FP8)
kv_per_seq = 327680 * 32768 / 1e9
kv_total = kv_per_seq * 4
overhead = 8.0
total = weights_gb + kv_total + overhead

allowed = {"us-east", "us-central", "eu-west"}
rows = list(csv.DictReader(open("offers.csv")))
results = []
for r in rows:
    mem = int(r["gpu_count"]) * int(r["vram_gb_per_gpu"])
    price = float(r["usd_per_hour"])
    in_stock = r["in_stock"].strip().lower() == "yes"
    region_ok = r["region"] in allowed
    price_ok = price <= 4.0
    mem_ok = mem >= total
    eligible = in_stock and region_ok and price_ok and mem_ok
    results.append(dict(
        id=r["offer_id"], region=r["region"], stock=in_stock,
        mem=mem, price=price, eligible=eligible,
        in_stock=in_stock, region_ok=region_ok, price_ok=price_ok, mem_ok=mem_ok,
    ))

elig = [r for r in results if r["eligible"]]
best = min(elig, key=lambda r: r["price"])
out = dict(
    weights_gb=weights_gb,
    kv_cache_gb=round(kv_total, 6),
    total_gb=round(total, 6),
    offer_id=best["id"],
    usd_per_hour=best["price"],
    usd_per_month=round(best["price"] * 730, 2),
)
print(json.dumps(out, indent=2))
print("--- all offers ---")
for r in results:
    print(r)