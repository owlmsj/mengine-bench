import csv, re, json
from decimal import Decimal

base = r"<WORKSPACE>\backoffice"

invoices = {}
with open(base + r"\invoices.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = Decimal(row["amount"])

payments = {}  # inv_id -> list of amounts
with open(base + r"\bank_statement_june.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        m = re.search(r"(?:INV|invoice)[-\s]?(\d{4})", memo, re.IGNORECASE)
        if not m:
            continue  # fees, interest, unidentified PIX
        inv_id = "INV-" + m.group(1)
        if inv_id not in invoices:
            continue
        payments.setdefault(inv_id, []).append(Decimal(row["amount"]))

unpaid, duplicated, mismatched = [], [], []
for inv_id in sorted(invoices):
    amts = payments.get(inv_id, [])
    if not amts:
        unpaid.append(inv_id)
    elif len(amts) > 1:
        duplicated.append(inv_id)
    elif amts[0] != invoices[inv_id]:
        mismatched.append({"id": inv_id, "invoiced": str(invoices[inv_id]), "paid": str(amts[0])})

result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
out = r"<WORKSPACE>\result.json"
with open(out, "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))