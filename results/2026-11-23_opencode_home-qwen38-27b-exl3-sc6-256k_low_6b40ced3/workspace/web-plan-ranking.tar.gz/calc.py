import json
from datetime import date

ipca = {1985: 242.23, 1986: 79.66, 1987: 363.41, 1988: 980.21, 1989: 1972.91,
        1990: 1620.97, 1991: 472.70, 1992: 1119.10, 1993: 2477.15, 1994: 916.46, 1995: 22.41}

# plan: (launch_date, next_plan_launch_date or None)
plans = [
    ("Cruzado",   date(1986, 2, 28), date(1987, 6, 12)),
    ("Bresser",   date(1987, 6, 12), date(1989, 1, 15)),
    ("Verao",     date(1989, 1, 15), date(1990, 3, 16)),
    ("Collor I",  date(1990, 3, 16), date(1991, 1, 31)),
    ("Collor II", date(1991, 1, 31), date(1994, 2, 27)),
    ("Real",      date(1994, 7, 1),  None),
]

def months_between(a, b):
    # whole calendar months from a to b
    return (b.year - a.year) * 12 + (b.month - a.month) - (1 if b.day < a.day else 0)

rows = []
for name, launch, nxt in plans:
    y = launch.year
    before = ipca[y - 1]
    after = ipca[y + 1]
    drop = max(0.0, min(1.0, 1 - after / before))
    if nxt is None:
        months = 60
    else:
        months = months_between(launch, nxt)
    dur = min(months, 60) / 60
    score = 0.7 * drop + 0.3 * dur
    rows.append((name, y, before, after, months, drop, dur, score))

for r in rows:
    print(f"{r[0]:10} Y={r[1]} before={r[2]:9.2f} after={r[3]:9.2f} months={r[4]:3} drop={r[5]:.4f} dur={r[6]:.4f} score={r[7]:.4f}")

top3 = [r[0] for r in sorted(rows, key=lambda x: -x[7])[:3]]
print("TOP3:", top3)