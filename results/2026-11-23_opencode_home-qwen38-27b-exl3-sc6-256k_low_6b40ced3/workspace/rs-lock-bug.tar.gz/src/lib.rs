//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        let mut score = slot.lock().unwrap();
        *score += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        // Lock slots in id order so concurrent transfers of the same two
        // players cannot deadlock.
        if from == to {
            let slot = self.slot(from);
            let mut slot = slot.lock().unwrap();
            *slot -= points;
            *slot += points;
            return;
        }
        let (low, high) = if from < to { (from, to) } else { (to, from) };
        let low_slot = self.slot(low);
        let high_slot = self.slot(high);
        let mut low_guard = low_slot.lock().unwrap();
        let mut high_guard = high_slot.lock().unwrap();
        let (from_guard, to_guard) = if from < to {
            (&mut low_guard, &mut high_guard)
        } else {
            (&mut high_guard, &mut low_guard)
        };
        **from_guard -= points;
        **to_guard += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}
