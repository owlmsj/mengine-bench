import json

# First report: laudo_alfa.pdf, coleta 10/02/2026
# Units of first report: mg/dL for glucose/LDL/creatinine, % for HbA1c
# Reference ranges (first report):
#   Glicose em jejum: 70-99 mg/dL
#   Colesterol LDL: <130 mg/dL
#   Creatinina: 0.70-1.30 mg/dL
#   HbA1c: 4.0-5.6 %

# Second report: resultado_beta.pdf, coleta 18/08/2026
# Conversions (standard factors):
#   glucose: mmol/L * 18.0156 = mg/dL
#   LDL: mmol/L * 38.67 = mg/dL
#   creatinine: umol/L / 88.4 = mg/dL
#   HbA1c: mmol/mol -> % via IFCC formula: % = (0.0237 * mmol/mol + 11.67) ... 
#   Actually the standard conversion: HbA1c% = (mmol/mol + 23.5) / 1.5948
#   Check: 37 mmol/mol -> (37+23.5)/1.5948 = 60.5/1.5948 = 37.94... that's wrong.
#   Correct formula: % = 0.09147 * mmol/mol + 2.2312 (approx)
#   Standard: HbA1c (NGSP %) = (IFCC mmol/mol + 23.5) / 1.5948
#   37 mmol/mol: (37+23.5)/1.5948 = 60.5/1.5948 = 37.94 -> that can't be right.
#   Let me re-check. The correct conversion is:
#   mmol/mol = (NGSP% - 2.15) * 10.929
#   So NGSP% = mmol/mol / 10.929 + 2.15
#   37 mmol/mol: 37/10.929 + 2.15 = 3.386 + 2.15 = 5.536 %
#   Check with known: 48 mmol/mol = 6.5%: 48/10.929+2.15 = 4.392+2.15 = 6.54 ~ 6.5 OK
#   32 mmol/mol = 5.0%: 32/10.929+2.15 = 2.928+2.15 = 5.08 ~ 5.0 OK
#   So 37 mmol/mol = 5.54 %

glucose_beta_mgdl = 6.1 * 18.0156
ldl_beta_mgdl = 3.70 * 38.67
creatinine_beta_mgdl = 76 / 88.4
hba1c_beta_pct = 37 / 10.929 + 2.15

print("Glucose beta mg/dL:", round(glucose_beta_mgdl, 1))
print("LDL beta mg/dL:", round(ldl_beta_mgdl, 1))
print("Creatinine beta mg/dL:", round(creatinine_beta_mgdl, 2))
print("HbA1c beta %:", round(hba1c_beta_pct, 2))

history = {
    "Glicose em jejum": {"2026-02-10": 92, "2026-08-18": round(glucose_beta_mgdl, 1)},
    "Colesterol LDL": {"2026-02-10": 118, "2026-08-18": round(ldl_beta_mgdl, 1)},
    "Creatinina": {"2026-02-10": 0.95, "2026-08-18": round(creatinine_beta_mgdl, 2)},
    "Hemoglobina glicada (HbA1c)": {"2026-02-10": 5.4, "2026-08-18": round(hba1c_beta_pct, 2)},
}

# Worse = got worse (value moved in bad direction) AND now outside first report's reference range
# Glucose: 92 -> 109.9, worse (higher), outside 70-99 (above) -> worse
# LDL: 118 -> 143.1, worse (higher), outside <130 (above) -> worse
# Creatinine: 0.95 -> 0.86, improved (lower, within range) -> not worse
# HbA1c: 5.4 -> 5.54, worse (higher), within 4.0-5.6 -> not outside range -> not worse

worse = []
# Glucose: 109.9 > 99 -> outside, and worse
worse.append("Glicose em jejum")
# LDL: 143.1 > 130 -> outside, and worse
worse.append("Colesterol LDL")
# Creatinine: 0.86, within 0.70-1.30, improved -> no
# HbA1c: 5.54, within 4.0-5.6, slightly worse but inside range -> no

result = {"history": history, "worse": worse}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
print(json.dumps(result, ensure_ascii=False, indent=2))