import sys
try:
    from pypdf import PdfReader
except ImportError:
    from PyPDF2 import PdfReader
for p in [r"exams\laudo_alfa.pdf", r"exams\resultado_beta.pdf"]:
    print("=====", p)
    r = PdfReader(p)
    for i, pg in enumerate(r.pages):
        print(f"--- page {i+1}")
        print(pg.extract_text())