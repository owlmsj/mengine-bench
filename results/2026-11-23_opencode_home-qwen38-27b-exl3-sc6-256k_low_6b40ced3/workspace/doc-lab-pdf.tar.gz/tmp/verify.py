import json

# Independent re-check
# Beta raw values: glucose 6.1 mmol/L, LDL 3.70 mmol/L, creatinine 76 umol/L, HbA1c 37 mmol/mol
# First report (Alfa) units: mg/dL (glucose, LDL, creatinine), % (HbA1c)
# First report reference ranges: glucose 70-99, LDL <130, creatinine 0.70-1.30, HbA1c 4.0-5.6

# Standard conversions:
# mg/dL = mmol/L * 18.0156 (glucose), * 38.67 (LDL)
# mg/dL = umol/L / 88.4 (creatinine)
# NGSP% = mmol/mol / 10.929 + 2.15 (HbA1c, IFCC->NGSP)

checks = [
    ("glucose", 6.1*18.0156, 92, 109.9, (70,99), "above=bad"),
    ("LDL", 3.70*38.67, 118, 143.1, (130, float('inf')), "above=bad"),
    ("creatinine", 76/88.4, 0.95, 0.86, (0.70,1.30), "either=bad"),
    ("HbA1c", 37/10.929+2.15, 5.4, 5.54, (4.0,5.6), "above=bad"),
]
for name, conv, first, second, rng, _ in checks:
    outside = not (rng[0] <= second <= rng[1])
    worse = (second > first) or (second < first and name=="creatinine")
    print(f"{name}: conv={conv:.2f} first={first} second={second} outside_range={outside} moved_worse={second>first or (name=='creatinine' and second<first)}")

# Verify result.json content
with open("result.json", encoding="utf-8") as f:
    r = json.load(f)
assert set(r.keys()) == {"history","worse"}
assert set(r["history"].keys()) == {"Glicose em jejum","Colesterol LDL","Creatinina","Hemoglobina glicada (HbA1c)"}
assert r["worse"] == ["Glicose em jejum","Colesterol LDL"]
# Verify values
h = r["history"]
assert h["Glicose em jejum"] == {"2026-02-10":92,"2026-08-18":109.9}
assert h["Colesterol LDL"] == {"2026-02-10":118,"2026-08-18":143.1}
assert h["Creatinina"] == {"2026-02-10":0.95,"2026-08-18":0.86}
assert h["Hemoglobina glicada (HbA1c)"] == {"2026-02-10":5.4,"2026-08-18":5.54}
print("ALL CHECKS PASSED")