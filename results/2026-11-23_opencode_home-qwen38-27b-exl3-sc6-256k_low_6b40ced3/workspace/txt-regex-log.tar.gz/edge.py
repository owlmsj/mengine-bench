import re

pattern = open("regex.txt", encoding="utf-8").read().strip()

cases = [
    ("2026-04-02 INFO no address here", []),
    ("2026-04-02 INFO ip 10.12.0.7 date 2026-04-01", ["2026-04-01"]),
    ("2026-04-02 INFO ip 10.12.0.7 only", ["2026-04-02"]),
    ("x2026-04-02 INFO ip 10.12.0.7 date 2026-04-01", ["2026-04-01"]),
    ("2026-04-02 INFO ip 10.12.0.7 date 2026-04-01x", ["2026-04-02"]),
    ("2026-04-02 INFO ip 10.12.0.77 date 2026-04-01", ["2026-04-01"]),
    ("2026-04-02 INFO ip 10.12.0.777 date 2026-04-01", []),
    ("2026-04-02 INFO ip 010.12.0.7 date 2026-04-01", []),
    ("2026-04-02 INFO ip 10.12.0.07 date 2026-04-01", []),
    ("2026-04-02 INFO ip 10.12.0.256 date 2026-04-01", []),
    ("2026-02-30 INFO ip 10.12.0.7 date 2026-02-28", ["2026-02-28"]),
    ("2026-04-02 INFO ip 10.12.0.7 date 2026-02-29", ["2026-02-29"]),
    ("2026-04-02 INFO ip 10.12.0.7 date 2026-02-30", ["2026-04-02"]),
    ("2026-04-02 INFO ip 10.12.0.7 date 2026-04-31", ["2026-04-02"]),
    ("2026-04-02 INFO ip 10.12.0.7 date 2026-01-31", ["2026-01-31"]),
    ("2026-04-02 INFO ip 10.12.0.7 date 2026-06-31", ["2026-04-02"]),
    ("2026-04-02 INFO ip 10.12.0.7 date 2026-04-01 2026-04-05", ["2026-04-05"]),
    ("2026-04-02 INFO 10.12.0.7", ["2026-04-02"]),
    ("INFO 10.12.0.7 2026-04-01", ["2026-04-01"]),
    ("2026-04-01 10.12.0.7 2026-04-02", ["2026-04-02"]),
    # letter before IP: still a valid IP per brief (only digit adjacency disqualifies)
    ("a10.12.0.7 2026-04-01", ["2026-04-01"]),
    # letter after IP: still valid
    ("10.12.0.7a 2026-04-01", ["2026-04-01"]),
    ("10.12.0.7x 2026-04-01", ["2026-04-01"]),
    # digit before IP: invalid (910 > 255 as first octet)
    ("910.12.0.7 2026-04-01", []),
    # date with digit before: 20260402... not a date
    ("20260402 10.12.0.7 2026-04-01", ["2026-04-01"]),
    # date with digit after: 2026-04-011 not a date
    ("10.12.0.7 2026-04-011", []),
    # multiple IPs, one date
    ("10.0.0.1 10.0.0.2 2026-04-01", ["2026-04-01"]),
    # no date at all
    ("10.0.0.1 10.0.0.2", []),
]

ok = True
for line, expected in cases:
    got = re.findall(pattern, line + "\n", re.MULTILINE)
    status = "OK" if got == expected else "FAIL"
    if got != expected:
        ok = False
    print(f"{status}  got={got}  expected={expected}  line={line!r}")

print("ALL PASS" if ok else "SOME FAILED")