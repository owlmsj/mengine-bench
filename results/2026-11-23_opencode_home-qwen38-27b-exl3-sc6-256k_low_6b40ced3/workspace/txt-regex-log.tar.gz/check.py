import re

pattern = open("regex.txt", encoding="utf-8").read().strip()
log = open("server.log", encoding="utf-8").read()

found = re.findall(pattern, log, re.MULTILINE)
print("found:", found)

# Expected: for each line containing a valid IPv4, the last date on that line
ipv4 = re.compile(r'(?<![\d.])((?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?![\d.])')
dates = re.compile(r'\b\d{4}-\d{2}-\d{2}\b')
expected = []
for line in log.splitlines():
    if ipv4.search(line):
        ds = dates.findall(line)
        if ds:
            expected.append(ds[-1])
print("expected:", expected)
print("match:", found == expected)