import csv, json, math

path = r"<WORKSPACE>\telemetry\playtest_ab.csv"

rows = []
with open(path, newline="", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        rows.append(r)

print("raw rows:", len(rows))

# Dedupe by session_id (first occurrence wins; verify duplicates are identical)
seen = {}
dup_conflicts = 0
for r in rows:
    sid = r["session_id"].strip()
    v = r["variant"].strip().lower()
    c = r["completed_tutorial"].strip()
    key = (sid, v, c)
    if sid in seen:
        if seen[sid] != key:
            dup_conflicts += 1
    else:
        seen[sid] = key

print("unique sessions:", len(seen))
print("duplicate rows:", len(rows) - len(seen))
print("conflicting duplicates:", dup_conflicts)

a_n = a_c = b_n = b_c = 0
for sid, (s, v, c) in seen.items():
    if v == "a":
        a_n += 1
        a_c += int(c)
    elif v == "b":
        b_n += 1
        b_c += int(c)
    else:
        print("UNEXPECTED VARIANT:", repr(v))

pa = a_c / a_n
pb = b_c / b_n
print(f"A: {a_c}/{a_n} = {pa:.4f}")
print(f"B: {b_c}/{b_n} = {pb:.4f}")

# Two-proportion z-test, two-sided, H0: p_a = p_b
p_pool = (a_c + b_c) / (a_n + b_n)
se = math.sqrt(p_pool * (1 - p_pool) * (1 / a_n + 1 / b_n))
z = (pb - pa) / se
# two-sided p-value
p_val = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))
print(f"pooled p = {p_pool:.4f}, se = {se:.4f}, z = {z:.4f}, p = {p_val:.6f}")

ship_b = p_val < 0.05 and pb > pa
print("ship_b:", ship_b)

out = {
    "ship_b": ship_b,
    "sessions_a": a_n,
    "sessions_b": b_n,
    "completion_rate_a": round(pa, 4),
    "completion_rate_b": round(pb, 4),
    "p_value": round(p_val, 6),
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))