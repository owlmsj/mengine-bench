import re, zlib
b = open(r'<WORKSPACE>\LP-2026-0418.pdf','rb').read()
# find stream ... endstream
m = re.search(rb'stream\r?\n(.*?)endstream', b, re.S)
raw = m.group(1)
try:
    out = zlib.decompress(raw)
except Exception:
    out = zlib.decompress(raw, -15)
print(out.decode('latin-1'))