import sqlite3, json
from collections import defaultdict

STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']
c = sqlite3.connect('analytics.db')

# real players only
players = {}  # user_id -> platform
for uid, platform, is_test in c.execute("SELECT user_id, platform, is_test FROM users"):
    if not is_test:
        players[uid] = platform

# first valid occurrence of each step per player, respecting order:
# a step counts only at or after the player's previous step
first = defaultdict(dict)  # uid -> step -> ts
for uid, name, ts in c.execute("SELECT user_id, name, ts FROM events"):
    if uid not in players or name not in STEPS:
        continue
    if name not in first[uid] or ts < first[uid][name]:
        first[uid][name] = ts

funnel = defaultdict(lambda: {s: 0 for s in STEPS})
for uid, plat in players.items():
    prev_ts = None
    reached = 0
    for s in STEPS:
        ts = first[uid].get(s)
        if ts is None:
            break
        if prev_ts is not None and ts < prev_ts:
            # step occurred before previous step: does not count
            break
        funnel[plat][s] += 1
        prev_ts = ts
        reached += 1

result = {'funnel': {}, 'biggest_drop': {}}
for plat, counts in funnel.items():
    result['funnel'][plat] = counts
    # conversion of step i = counts[i] / counts[i-1]; biggest drop = step with lowest conversion
    worst_step, worst_conv = None, None
    for i in range(1, len(STEPS)):
        prev = counts[STEPS[i-1]]
        conv = counts[STEPS[i]] / prev if prev else 0.0
        if worst_conv is None or conv < worst_conv:
            worst_conv, worst_step = conv, STEPS[i]
    result['biggest_drop'][plat] = worst_step

with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))