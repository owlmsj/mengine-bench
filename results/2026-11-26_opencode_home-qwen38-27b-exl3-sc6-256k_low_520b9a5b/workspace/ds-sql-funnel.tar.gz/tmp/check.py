import sqlite3
c = sqlite3.connect('analytics.db')
# independent check: per platform, count real players whose first valid step chain reaches each step
q = """
WITH real AS (SELECT user_id, platform FROM users WHERE is_test=0),
f AS (
  SELECT e.user_id, e.name, MIN(e.ts) ts
  FROM events e JOIN real r ON r.user_id=e.user_id
  WHERE e.name IN ('install','tutorial_complete','first_match','purchase')
  GROUP BY e.user_id, e.name
)
SELECT r.platform,
  SUM(CASE WHEN i.ts IS NOT NULL THEN 1 ELSE 0 END),
  SUM(CASE WHEN t.ts IS NOT NULL AND (i.ts IS NULL OR t.ts>=i.ts) THEN 1 ELSE 0 END),
  SUM(CASE WHEN t.ts IS NOT NULL AND i.ts IS NOT NULL AND t.ts>=i.ts
            AND m.ts IS NOT NULL AND m.ts>=t.ts THEN 1 ELSE 0 END),
  SUM(CASE WHEN i.ts IS NOT NULL AND t.ts IS NOT NULL AND t.ts>=i.ts
            AND m.ts IS NOT NULL AND m.ts>=t.ts
            AND p.ts IS NOT NULL AND p.ts>=m.ts THEN 1 ELSE 0 END)
FROM real r
LEFT JOIN f i ON i.user_id=r.user_id AND i.name='install'
LEFT JOIN f t ON t.user_id=r.user_id AND t.name='tutorial_complete'
LEFT JOIN f m ON m.user_id=r.user_id AND m.name='first_match'
LEFT JOIN f p ON p.user_id=r.user_id AND p.name='purchase'
GROUP BY r.platform
"""
for row in c.execute(q):
    print(row)
# sanity: event name spellings and test count
print('event names:', [r for r in c.execute("SELECT DISTINCT name FROM events")])
print('test users:', c.execute("SELECT COUNT(*) FROM users WHERE is_test=1").fetchone()[0])
print('events from unknown users:', c.execute("SELECT COUNT(*) FROM events e LEFT JOIN users u ON u.user_id=e.user_id WHERE u.user_id IS NULL").fetchone()[0])