import csv, json

# Memory needs (GB = 10^9 bytes)
weights_gb = 70e9 / 1e9                      # 70 GB (FP8, 1 byte/param)
kv_cache_gb = 4 * 32768 * 327680 / 1e9       # 4 seqs x 32768 tok x 327680 B/tok
overhead_gb = 8.0
total_gb = weights_gb + kv_cache_gb + overhead_gb
print(f"weights_gb={weights_gb} kv_cache_gb={kv_cache_gb} total_gb={total_gb}")

rows = list(csv.DictReader(open("offers.csv")))
best = None
for r in rows:
    if r["in_stock"] != "yes": continue
    if r["region"] not in ("us-east","us-central","eu-west"): continue
    price = float(r["usd_per_hour"])
    if price > 4.0: continue
    vram = int(r["gpu_count"]) * float(r["vram_gb_per_gpu"])
    ok = vram >= total_gb
    print(f'{r["offer_id"]} region={r["region"]} vram={vram} price={price} fits={ok}')
    if ok and (best is None or price < best[1]):
        best = (r["offer_id"], price)

r = next(x for x in rows if x["offer_id"] == best[0])
out = {
    "weights_gb": weights_gb,
    "kv_cache_gb": kv_cache_gb,
    "total_gb": total_gb,
    "offer_id": best[0],
    "usd_per_hour": best[1],
    "usd_per_month": round(best[1] * 730, 2),
}
json.dump(out, open("result.json","w"), indent=2)
print(json.dumps(out, indent=2))