"""Helper for batch scripts: run async jobs with a concurrency cap.

Usage:
    from run import run_tasks

    await run_tasks([job1, job2, ...], max_concurrent=4)

Each task is a zero-argument callable returning an awaitable job.
At most max_concurrent jobs run at once. Ctrl+C (SIGINT) cancels the
pending work but every job's cleanup code (finally blocks /
async with / try-except) still runs, because cancellation is
delivered into the running coroutine, not by killing the process.
"""

import asyncio
import signal
from typing import Awaitable, Callable, Sequence


async def run_tasks(
    tasks: Sequence[Callable[[], Awaitable[object]]],
    max_concurrent: int,
) -> None:
    """Run all tasks with at most max_concurrent jobs in flight.

    Returns when every job is done. On Ctrl+C the in-flight jobs are
    cancelled cooperatively (their finally/cleanup code runs) and the
    function returns instead of raising KeyboardInterrupt, so batch
    scripts can shut down cleanly.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent}")

    sem = asyncio.Semaphore(max_concurrent)

    async def _run(task: Callable[[], Awaitable[object]]) -> None:
        async with sem:
            await task()

    # Wrap each task so a cancellation of one job does not cancel the
    # others: we catch CancelledError per-job and let the job's own
    # cleanup run.
    async def _guarded(task: Callable[[], Awaitable[object]]) -> None:
        try:
            await _run(task)
        except (asyncio.CancelledError, KeyboardInterrupt):
            # Job was cancelled (e.g. Ctrl+C). Its finally blocks already
            # ran during the cancellation; swallow here so gather() does
            # not propagate and kill the remaining jobs' cleanup.
            pass

    # Run all jobs concurrently, capped by the semaphore. KeyboardInterrupt
    # (Ctrl+C) propagates into the running coroutines; each job's finally
    # block runs during the unwind, and _guarded swallows the exception so
    # gather() does not re-raise and kill remaining cleanup.
    await asyncio.gather(*(_guarded(t) for t in tasks))


if __name__ == "__main__":
    import sys

    async def _demo() -> None:
        async def job(n: int) -> None:
            try:
                print(f"job {n} start")
                await asyncio.sleep(5)
                print(f"job {n} done")
            finally:
                print(f"job {n} cleanup")

        await run_tasks([lambda n=n: job(n) for n in range(6)], max_concurrent=2)

    try:
        asyncio.run(_demo())
    except KeyboardInterrupt:
        print("interrupted", file=sys.stderr)