import csv, json
from collections import defaultdict

def parse_amt(s):
    s = s.strip().replace('.', '').replace(',', '.')
    return float(s)

coa = {}
with open('finance/chart_of_accounts.csv', encoding='utf-8') as f:
    r = csv.reader(f, delimiter=';')
    next(r)
    for row in r:
        coa[row[0]] = row[2]

months = ['2026-01','2026-02','2026-03','2026-04','2026-05','2026-06']
rev = defaultdict(float); cogs = defaultdict(float); opex = defaultdict(float); fin = defaultdict(float)

with open('finance/ledger.csv', encoding='utf-8') as f:
    r = csv.reader(f, delimiter=';')
    next(r)
    for row in r:
        d, acct, desc, amt = row
        dd, mm, yy = d.split('/')
        m = f'{yy}-{mm}'
        a = parse_amt(amt)
        line = coa[acct]
        if line == 'revenue':
            rev[m] += a
        elif line == 'cogs':
            cogs[m] += a
        elif line in ('sales_marketing','rnd','ga'):
            opex[m] += a
        elif line == 'financial':
            fin[m] += a

out = {'revenue': {}, 'gross_margin_pct': {}, 'ebitda': {}, 'burn': None, 'runway_months': None}
ebitda_vals = {}
for m in months:
    e = rev[m] + cogs[m] + opex[m] + fin[m]
    ebitda_vals[m] = e
    out['revenue'][m] = round(rev[m], 2)
    out['ebitda'][m] = round(e, 2)
    out['gross_margin_pct'][m] = round((rev[m] + cogs[m]) / rev[m] * 100, 2)

# burn: average monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = [ebitda_vals[m] for m in ['2026-04','2026-05','2026-06']]
burn = -sum(last3) / 3
cash = 1847350.40
runway = cash / burn
out['burn'] = round(burn, 2)
out['runway_months'] = round(runway, 2)

for m in months:
    print(m, 'rev=%.2f cogs=%.2f opex=%.2f fin=%.2f ebitda=%.2f gm=%.2f' % (
        rev[m], cogs[m], opex[m], fin[m], ebitda_vals[m], out['gross_margin_pct'][m]))
print('burn=%.2f runway=%.4f' % (burn, runway))

with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, indent=2)
print('written result.json')