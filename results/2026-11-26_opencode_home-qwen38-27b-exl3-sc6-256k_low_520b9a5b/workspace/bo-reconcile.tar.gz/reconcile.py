import csv, json, re

base = r"<WORKSPACE>\backoffice"

invoices = {}
with open(base + r"\invoices.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = float(row["amount"])

payments = []  # (invoice_id, amount)
with open(base + r"\bank_statement_june.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        m = re.search(r"(\d{4})", memo)
        if not m:
            continue  # no identifiable invoice (fees, interest, unidentified PIX)
        inv = "INV-" + m.group(1)
        if inv in invoices:
            payments.append((inv, float(row["amount"])))

# group by invoice
by_inv = {}
for inv, amt in payments:
    by_inv.setdefault(inv, []).append(amt)

unpaid = sorted(i for i in invoices if i not in by_inv)
duplicated = sorted(i for i, amts in by_inv.items() if len(amts) > 1)
mismatched = []
for i, amts in sorted(by_inv.items()):
    if len(amts) > 1:
        continue  # categories are exclusive
    if amts[0] != invoices[i]:
        mismatched.append({"id": i, "invoiced": invoices[i], "paid": amts[0]})

result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)

print(json.dumps(result, indent=2, ensure_ascii=False))
print("invoices:", len(invoices), "matched payments:", len(payments))