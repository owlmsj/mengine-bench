import csv, json, math
from collections import Counter

path = r"<WORKSPACE>\telemetry\playtest_ab.csv"

sessions = {}  # session_id -> (variant, completed)
dup_rows = 0
total_rows = 0
variant_raw = Counter()

with open(path, newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        total_rows += 1
        sid = row["session_id"].strip()
        v = row["variant"].strip().lower()
        c = int(row["completed_tutorial"])
        variant_raw[v] += 1
        if sid in sessions:
            dup_rows += 1
            prev_v, prev_c = sessions[sid]
            # verify duplicate rows are consistent (same variant, same outcome)
            if (prev_v, prev_c) != (v, c):
                print(f"INCONSISTENT DUPLICATE: {sid} prev=({prev_v},{prev_c}) new=({v},{c})")
        else:
            sessions[sid] = (v, c)

print(f"total_rows={total_rows} unique_sessions={len(sessions)} dup_rows={dup_rows}")
print(f"variant_raw_counts={dict(variant_raw)}")

n_a = n_b = 0
c_a = c_b = 0
for sid, (v, c) in sessions.items():
    if v == "a":
        n_a += 1
        c_a += c
    elif v == "b":
        n_b += 1
        c_b += c
    else:
        print(f"UNEXPECTED VARIANT: {v!r}")

rate_a = c_a / n_a
rate_b = c_b / n_b
print(f"A: n={n_a} completed={c_a} rate={rate_a:.6f}")
print(f"B: n={n_b} completed={c_b} rate={rate_b:.6f}")
print(f"abs_diff={abs(rate_b - rate_a):.6f} rel_diff={abs(rate_b - rate_a)/rate_a:.6f}")

# two-proportion z-test, two-sided, H0: p_a = p_b
p_pool = (c_a + c_b) / (n_a + n_b)
se = math.sqrt(p_pool * (1 - p_pool) * (1/n_a + 1/n_b))
z = (rate_b - rate_a) / se
# two-sided p-value via normal CDF
p_value = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))
print(f"p_pool={p_pool:.6f} se={se:.6f} z={z:.6f} p_value={p_value:.6g}")

# also continuity-corrected chi-square as a cross-check
# chi2 = (|ad-bc| - N/2)^2 * N / (row1*row2*col1*col2)
a11, a10 = c_a, n_a - c_a
a01, a00 = c_b, n_b - c_b
N = n_a + n_b
r1, r2 = n_a, n_b
c1, c0 = c_a + c_b, N - c_a - c_b
chi2 = (abs(a11*a00 - a10*a01) - N/2)**2 * N / (r1*r2*c1*c0)
p_chi = 1 - 0.5 * (1 + math.erf(math.sqrt(chi2/2) / math.sqrt(2)))  # chi2 df=1: p = erfc(sqrt(chi2/2))
p_chi = math.erfc(math.sqrt(chi2/2))
print(f"chi2_continuity={chi2:.6f} p_chi={p_chi:.6g}")

result = {
    "ship_b": bool(p_value < 0.05 and rate_b > rate_a),
    "sessions_a": n_a,
    "sessions_b": n_b,
    "completion_rate_a": round(rate_a, 6),
    "completion_rate_b": round(rate_b, 6),
    "p_value": round(p_value, 6),
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))