# Handoff: local-9b @ 128k

## Done (verified)
- local-9b Q5 @ 128k: 37.8 t/s, VRAM 7881 MiB (measure_decode.ps1 -Ctx 131072 -NPredict 1024).
- 7881 MiB is the WDDM ceiling; Shared Usage showed 1494 MiB spilled — that number does not count.
- Fix: `--no-mmproj-offload` + `-ub 512` removes the spill: VRAM 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k — discarded. Q4_K_M fits (7305 MiB, 40.4 t/s) — fallback only.
- Recipe applied in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

## Left
1. evals README still cites check_vision.ps1, which no longer exists — update it.
2. Review the names of the scratchpad temp files (noted repeatedly, never done).

## Assumptions
- No code changes beyond the recipe; diffs were formatting only.

## How I know it is right
- 7697 MiB / 38.0 t/s are the median of 3 runs, measured after the download finished.
- The 1494 MiB spill was confirmed gone via the Shared Usage counter, not the WDDM ceiling.