import wave, struct

with wave.open(r"<WORKSPACE>\raw.wav", "rb") as w:
    n = w.getnframes()
    rate = w.getframerate()
    data = w.readframes(n)

samples = struct.unpack("<%dh" % (n), data)

# Find speech: threshold on amplitude
thr = 800
start = 0
end = n
for i, s in enumerate(samples):
    if abs(s) > thr:
        start = max(0, i - int(rate * 0.2))
        break
for i in range(n - 1, -1, -1):
    if abs(samples[i]) > thr:
        end = min(n, i + int(rate * 0.3))
        break

dur = (end - start) / rate
print(f"start={start/rate:.2f}s end={end/rate:.2f}s dur={dur:.2f}s")

# If too long, trim to 8s; if too short, keep as is
if dur > 8:
    end = start + int(8 * rate)
    dur = 8

out = samples[start:end]
with wave.open(r"<WORKSPACE>\announcement.wav", "wb") as w:
    w.setnchannels(1)
    w.setsampwidth(2)
    w.setframerate(rate)
    w.writeframes(struct.pack("<%dh" % len(out), *out))

print(f"announcement.wav written: {len(out)/rate:.2f}s")