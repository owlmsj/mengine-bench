$ffmpeg = "<HOME>\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg.Shared_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build-shared\bin\ffmpeg.exe"
$mic = "@device_cm_{33D9A762-90C8-11D0-BD43-00A0C911CE86}\wave_{A5E102EA-4448-44F2-97D4-42DFC0839FFA}"
$out = "<WORKSPACE>\raw.wav"

$proc = Start-Process -FilePath $ffmpeg -ArgumentList "-hide_banner","-y","-f","dshow","-i","audio=`"$mic`"","-t","12","-ar","22050","-ac","1","$out" -PassThru -NoNewWindow
Start-Sleep -Seconds 2

$s = New-Object -ComObject SAPI.SpVoice
$s.Rate = 0
$s.Speak("Welcome aboard the evening ferry, please keep your bags clear of the doors.") | Out-Null

Start-Sleep -Seconds 3
$proc.WaitForExit()
Write-Output "record done"