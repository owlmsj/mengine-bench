$s = New-Object -ComObject SAPI.SpVoice
$s.Rate = 0
$s.Speak("Welcome aboard the evening ferry, please keep your bags clear of the doors.") | Out-Null
Write-Output "sapi done"