import json, struct

data = open('prices.db','rb').read()

# Leaf table b-tree page (type 0x0D). Cell content area start at offset 5-6.
idx = int.from_bytes(data[5:7], 'big')
print("cell content starts at", idx)

def varint(buf, pos):
    result = 0
    for i in range(9):
        b = buf[pos+i]
        if i == 8:
            return (result << 8) | b, pos+9
        result = (result << 7) | (b & 0x7F)
        if not (b & 0x80):
            return result, pos+i+1
    return result, pos+9

def parse_record(buf, pos):
    hdr_size, p = varint(buf, pos)
    hdr_end = pos + hdr_size
    serials = []
    while p < hdr_end:
        st, p = varint(buf, p)
        serials.append(st)
    body = hdr_end
    vals = []
    for st in serials:
        if st == 0:
            vals.append(None)
        elif 1 <= st <= 6:
            n = {1:1, 2:2, 3:3, 4:4, 5:6, 6:8}[st]
            vals.append(int.from_bytes(buf[body:body+n], 'big', signed=True)); body += n
        elif st == 7:
            vals.append(struct.unpack('>d', buf[body:body+8])[0]); body += 8
        elif st == 8:
            vals.append(0)
        elif st == 9:
            vals.append(1)
        elif st >= 12 and st % 2 == 0:
            n = (st-12)//2
            vals.append(buf[body:body+n].decode('utf-8', errors='replace')); body += n
        elif st >= 13 and st % 2 == 1:
            n = (st-13)//2
            vals.append(buf[body:body+n]); body += n
        else:
            vals.append(None)
    return vals

rows = []
pos = idx
while pos < len(data):
    payload_size, p = varint(data, pos)
    rowid, p = varint(data, p)
    if payload_size > 4000 or p + payload_size > len(data) + 16:
        break
    vals = parse_record(data, p)
    # (NULL rowid-alias, item TEXT, price) or (item, price)
    if len(vals) >= 3 and vals[0] is None and isinstance(vals[1], (str, bytes)):
        item, price = vals[1], vals[2]
    elif len(vals) >= 2 and isinstance(vals[0], (str, bytes)):
        item, price = vals[0], vals[1]
    else:
        break
    if isinstance(item, bytes):
        item = item.decode('utf-8', errors='replace')
    if isinstance(price, float):
        price = round(price, 2)
    rows.append({"item": item, "price": price})
    pos = p + payload_size

with open('recovered.json','w',encoding='utf-8') as f:
    json.dump(rows, f, ensure_ascii=False, indent=2)
print(json.dumps(rows, ensure_ascii=False, indent=2))