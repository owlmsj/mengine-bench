"""Match payout. Rules live in docs/ECONOMY.md."""


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    # Round to nearest ten, halves up.
    raw = (base + kills * cfg["kill_bonus"]) * cfg["event_multiplier"]
    return int((raw + 5) // 10) * 10
