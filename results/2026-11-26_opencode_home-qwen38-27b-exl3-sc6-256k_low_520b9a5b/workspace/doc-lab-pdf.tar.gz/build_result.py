import json

# First report (Alfa, 10/02/2026) - units of reference for the history
alfa = {
    "Glicose em jejum": {"date": "2026-02-10", "value": 92.0, "unit": "mg/dL", "ref": (70, 99)},
    "Colesterol LDL": {"date": "2026-02-10", "value": 118.0, "unit": "mg/dL", "ref": (None, 130)},  # desirable < 130
    "Creatinina": {"date": "2026-02-10", "value": 0.95, "unit": "mg/dL", "ref": (0.70, 1.30)},
    "Hemoglobina glicada (HbA1c)": {"date": "2026-02-10", "value": 5.4, "unit": "%", "ref": (4.0, 5.6)},
}

# Second report (Beta, 18/08/2026) converted to Alfa's units
# glucose: mmol/L -> mg/dL * 18.015588
# LDL: mmol/L -> mg/dL * 38.67
# creatinine: umol/L -> mg/dL * 0.011299 (1/88.42)
# HbA1c: mmol/mol -> % : (mmol/mol + 23.5) / 10.929
beta_raw = {
    "Glicose em jejum": 6.1,        # mmol/L
    "Colesterol LDL": 3.70,         # mmol/L
    "Creatinina": 76.0,             # umol/L
    "Hemoglobina glicada (HbA1c)": 37.0,  # mmol/mol
}

conv = {
    "Glicose em jejum": lambda v: v * 18.015588,
    "Colesterol LDL": lambda v: v * 38.67,
    "Creatinina": lambda v: v / 88.42,
    "Hemoglobina glicada (HbA1c)": lambda v: (v + 23.5) / 10.929,
}

history = {}
worse = []
for marker, info in alfa.items():
    v2 = conv[marker](beta_raw[marker])
    v2 = round(v2, 2)
    history[marker] = {info["date"]: info["value"], "2026-08-18": v2}
    lo, hi = info["ref"]
    outside = (lo is not None and v2 < lo) or (hi is not None and v2 > hi)
    got_worse = v2 > info["value"]
    print(f"{marker}: {info['value']} -> {v2} {info['unit']}  outside_ref={outside} worse={got_worse}")
    if got_worse and outside:
        worse.append(marker)

result = {"history": history, "worse": worse}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
print(json.dumps(result, ensure_ascii=False, indent=2))