import csv, json, statistics

rows = []
with open(r"<WORKSPACE>\capture\presentmon.csv") as f:
    r = csv.DictReader(f)
    for row in r:
        rows.append(row)

mbp = [float(x["MsBetweenPresents"]) for x in rows]
avg_fps = 1000.0 / (sum(mbp) / len(mbp))
mbp_sorted = sorted(mbp)
p99 = mbp_sorted[int(0.99 * (len(mbp_sorted) - 1))]
low1 = 1000.0 / p99
print("frames:", len(rows))
print("avg_fps: %.2f" % avg_fps)
print("p99_ms: %.3f  low1pct_fps: %.2f" % (p99, low1))

# slow frames: > 2x median
med = statistics.median(mbp)
slow = [(i, t, m) for i, (t, m) in enumerate(zip([float(x["TimeInSeconds"]) for x in rows], mbp)) if m > 2 * med]
print("median_ms: %.2f  slow_frames(>2x med): %d" % (med, len(slow)))
for i, t, m in slow[:40]:
    print("  t=%.3f ms=%.2f" % (t, m))

# sensor: L1 seconds and MsMpEng seconds
sens = []
with open(r"<WORKSPACE>\capture\sensors.csv") as f:
    for row in csv.DictReader(f):
        sens.append(row)
l1 = [int(x["time_s"]) for x in sens if x["gpu_pcie_link_state"] == "L1"]
mp = [int(x["time_s"]) for x in sens if x["top_cpu_process"] == "MsMpEng.exe"]
dpc_hi = [(int(x["time_s"]), int(x["dpc_latency_us"])) for x in sens if int(x["dpc_latency_us"]) > 200]
disk_hi = [(int(x["time_s"]), int(x["disk_active_pct"])) for x in sens if int(x["disk_active_pct"]) > 50]
print("L1 seconds:", l1)
print("MsMpEng seconds:", mp)
print("dpc>200us:", dpc_hi)
print("disk>50%:", disk_hi)

# how many slow frames fall in L1 seconds or MsMpEng seconds
slow_t = [round(t) for _, t, _ in slow]
print("slow in L1 sec:", sum(1 for t in slow_t if t in l1))
print("slow in MsMpEng sec:", sum(1 for t in slow_t if t in mp))
print("slow in other sec:", sum(1 for t in slow_t if t not in l1 and t not in mp))