import json, re

words = json.load(open("words.json", encoding="utf-8"))
# themes: parse from site again
import os, html as H, unicodedata
from urllib.parse import unquote
site = "site"
themes = {}
for fn in os.listdir(site):
    if not fn.endswith(".html") or fn in ("index.html","sobre.html","contato.html"):
        continue
    txt = open(os.path.join(site,fn), encoding="utf-8").read()
    m = re.search(r"<h1>(.*?)</h1>", txt)
    if not m: continue
    w = H.unescape(m.group(1)).strip()
    t = re.search(r'class="tema">Tema:\s*(.*?)</p>', txt)
    themes[w] = H.unescape(t.group(1)).strip() if t else ""

links = json.load(open("result.json", encoding="utf-8"))["relations"]
html = open("universe/index.html", encoding="utf-8").read()
html = html.replace("/*__WORDS__*/null", json.dumps(words, ensure_ascii=False))
html = html.replace("/*__LINKS__*/null", str(links))
html = html.replace("/*__THEMES__*/null", json.dumps(themes, ensure_ascii=False))
html = html.replace("250 palavras, 743 laços", f"{len(words)} palavras, {links} laços")
open("universe/index.html","w",encoding="utf-8").write(html)
print("ok", len(words), links)