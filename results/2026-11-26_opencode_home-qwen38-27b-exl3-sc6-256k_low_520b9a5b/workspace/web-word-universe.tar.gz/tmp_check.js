
import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js";
const WORDS = {"alfaiate": ["sapateiro", "padeiro", "boca", "emprego", "profissão", "susto", "açougueiro"], "amanhã": ["hoje", "eternidade", "hora", "perna", "porta"], "angústia": ["dor", "aflição", "compaixão", "riacho", "medo", "afeto"], "cabeça": ["corpo", "rosto", "mão", "enfermeira"], "café": ["pimenta", "chá", "momento", "água", "trabalho"], "carinho": ["afeto", "ternura", "melancolia", "compaixão", "saudade", "esperança"], "carne": ["mandioca", "peixe", "filho", "arroz", "nação", "ovo", "salário"], "cena": ["teatro", "ator", "melodia", "canção", "ponte", "livro"], "contentamento": ["felicidade", "prazer", "pais"], "dedo": ["mão", "unha", "pé", "sapateiro"], "dente": ["língua", "pescoço", "pulmão", "hoje"], "desenho": ["tela", "escultura", "noite", "dança", "prima"], "dicionário": ["significado", "sinônimo", "voz", "arte"], "época": ["momento", "era", "enfermeira", "leite"], "estômago": ["pulmão", "fígado", "língua", "irmão"], "fala": ["voz", "conversa", "acento", "advogado"], "filha": ["filho", "irmão", "parentesco", "tia", "manteiga", "primo", "nora"], "floresta": ["natureza", "mata", "mar", "medo", "tempo"], "folha": ["raiz", "flor", "tio", "semente", "conto", "silêncio"], "hora": ["tempo", "minuto", "época", "advogado"], "idioma": ["palavra", "linguagem", "madrinha", "apelido", "canção", "gíria"], "jardim": ["fruto", "campo", "pétala", "escultura", "montanha", "praia"], "juiz": ["advogado", "soldado", "porto", "patrão", "engenheiro", "mão"], "madrugada": ["noite", "aurora", "manhã", "nome", "eternidade", "passado", "vila", "arroz", "médico"], "manteiga": ["leite", "açúcar", "milho", "queijo", "almoço", "ansiedade"], "mar": ["lago", "onda", "flor", "vale", "medo"], "mercado": ["estação", "igreja", "mata", "porta", "emprego"], "música": ["arte", "canção", "ano", "verso", "nora", "samba", "pintura"], "nação": ["país", "pátria", "rua", "instante", "vila"], "neto": ["avó", "neta", "mãe", "filho", "romance", "sílaba"], "nome": ["sussurro", "apelido", "madrugada", "voz", "ritmo"], "nora": ["genro", "padrinho", "família", "filha", "peixe", "patrão", "música"], "nostalgia": ["saudade", "melancolia", "esperança", "sílaba", "mágoa"], "ofício": ["trabalho", "profissão", "areia", "padeiro", "livro", "lavrador"], "operário": ["patrão", "pedreiro", "passado", "profissão", "lavrador", "igreja", "soldado"], "parentesco": ["família", "pais", "filha", "médico"], "pastor": ["lavrador", "médico", "ferreiro", "profissão", "mel"], "pergunta": ["acento", "resposta", "grito", "olho"], "perna": ["sangue", "joelho", "amanhã"], "praça": ["avenida", "esquina", "ternura", "pátria", "vale", "lar"], "prima": ["primo", "sobrinho", "herança", "cidade"], "quarto": ["lar", "cozinha", "avenida", "neta"], "refeição": ["comida", "almoço", "milho", "bairro", "água", "fotografia"], "romance": ["rima", "conto", "natureza", "teatro", "arte", "sotaque"], "semana": ["mês", "dia", "futuro", "avô"], "susto": ["pavor", "espanto", "amor", "pétala", "estação", "alfaiate", "tempo"], "trigo": ["farinha", "arroz", "milho", "unha"], "vale": ["serra", "rio", "raiz", "mar", "ponte"], "vila": ["capital", "aldeia", "nação", "madrugada", "porto", "carpinteiro"], "violão": ["samba", "piano", "país", "enfermeira", "rima", "praça", "poesia", "escultura"], "acento": ["sílaba", "pergunta", "fala", "sotaque", "prazer"], "açougueiro": ["padeiro", "pescador", "tarde", "alfaiate", "boca"], "açúcar": ["manteiga", "mel", "pimenta", "unha", "tempo"], "advogado": ["professor", "juiz", "cachoeira", "hora", "coração", "eternidade", "fala", "palavra"], "afeto": ["amor", "carinho", "angústia", "voz"], "aflição": ["angústia", "ansiedade", "felicidade", "escultura", "pavor", "água"], "água": ["vinho", "comida", "ombro", "café", "refeição", "aflição", "professor"], "aldeia": ["vila", "bairro", "capital", "trabalho"], "alegria": ["surpresa", "felicidade", "ternura", "queijo"], "alma": ["pé", "corpo", "amor", "dente", "gíria", "pátria"], "almoço": ["refeição", "jantar", "carne", "patrão", "pimenta", "frase"], "amor": ["paixão", "afeto", "susto", "tristeza", "alma", "árvore"], "ano": ["século", "mês", "crepúsculo", "música"], "ansiedade": ["aflição", "medo", "rua", "paixão", "manteiga"], "apelido": ["nome", "letra", "idioma", "acento", "irmã"], "areia": ["praia", "natureza", "montanha", "ofício", "rima"], "arroz": ["trigo", "feijão", "chá", "madrugada"], "arte": ["fotografia", "música", "samba", "cachoeira", "romance"], "árvore": ["selva", "raiz", "mata", "amor", "serra", "mandioca"], "ator": ["cena", "poesia", "canção", "primo"], "aurora": ["madrugada", "crepúsculo", "prazer", "instante", "professor"], "avenida": ["rua", "praça", "casa", "feijão", "quarto"], "avó": ["avô", "neto", "mãe", "idioma", "genro"], "avô": ["irmã", "avó", "pais", "coração", "semana"], "bairro": ["aldeia", "rua", "igreja", "porta", "refeição"], "boca": ["olho", "língua", "rosto", "ombro", "alfaiate", "açougueiro", "livro"], "braço": ["ombro", "mão", "surpresa", "língua", "janela"], "cachoeira": ["riacho", "lago", "pétala", "semente", "advogado", "linguagem"], "campo": ["jardim", "prado", "selva", "onda", "ponte", "milho"], "canção": ["música", "melodia", "tela", "pai", "cena", "ator", "idioma"], "capital": ["cidade", "vila", "estação", "riacho", "aldeia", "voz", "tempo"], "carpinteiro": ["pedreiro", "ferreiro", "trabalho", "patrão", "vila"], "casa": ["escola", "lar", "avenida", "igreja", "poesia"], "chá": ["café", "vinho", "peixe", "queijo", "dente"], "cidade": ["estado", "capital", "prima", "estação", "jardim"], "cinema": ["escultura", "fotografia", "tela", "pergunta"], "comida": ["água", "refeição", "peito", "farinha", "história"], "compaixão": ["ternura", "esperança", "angústia", "carinho", "contentamento", "sílaba", "ovo"], "conto": ["romance", "livro", "folha", "lar", "verso", "herança", "palavra"], "conversa": ["fala", "silêncio", "grito", "felicidade"], "coração": ["peito", "pulmão", "avô", "rosto", "advogado", "joelho", "jantar"], "corpo": ["alma", "cabeça", "peixe", "pescoço"], "cozinha": ["quarto", "janela", "pai", "fígado", "capital", "voz"], "crepúsculo": ["aurora", "ontem", "cunhado", "segundo", "ano", "época", "gíria", "hoje"], "cunhado": ["sobrinho", "sogra", "pais", "crepúsculo"], "dança": ["tambor", "teatro", "piano", "rima", "voz", "desenho"], "dia": ["semana", "manhã", "tarde", "casa", "letra"], "dor": ["mágoa", "angústia", "saudade", "almoço"], "emprego": ["profissão", "salário", "esperança", "eternidade", "mercado", "alfaiate", "jantar"], "enfermeira": ["médico", "professor", "época", "açougueiro", "violão"], "engenheiro": ["marinheiro", "trabalho", "irmão", "juiz", "lavrador", "ternura"], "era": ["época", "século", "mês", "teatro", "palavra"], "escola": ["igreja", "casa", "esquina", "esperança"], "escultura": ["desenho", "cinema", "jardim", "olho", "violão", "sobrinho"], "espanto": ["susto", "surpresa", "esperança", "país"], "esperança": ["compaixão", "saudade", "nostalgia", "espanto", "carinho", "emprego", "escola"], "esquina": ["praça", "ponte", "cozinha", "pescador", "escola"], "estado": ["pátria", "cidade", "mão", "praça", "médico", "poesia"], "estação": ["porto", "mercado", "tia", "cidade", "capital", "susto"], "eternidade": ["amanhã", "passado", "instante", "madrugada", "emprego", "peixe", "advogado"], "família": ["herança", "parentesco", "nora", "susto"], "farinha": ["pão", "trigo", "vinho", "pescador"], "feijão": ["arroz", "milho", "avenida", "mandioca", "vinho", "palavra"], "felicidade": ["alegria", "contentamento", "aflição", "compaixão", "trigo", "conversa"], "ferreiro": ["carpinteiro", "sapateiro", "segundo", "pastor", "onda"], "fígado": ["estômago", "pele", "futuro", "alma", "cozinha"], "filho": ["pai", "filha", "genro", "carne"], "flor": ["folha", "pétala", "mar", "samba", "semente"], "fotografia": ["cinema", "arte", "soldado", "rima", "teatro", "refeição"], "frase": ["linguagem", "sentido", "tristeza", "letra", "almoço", "gíria", "sussurro"], "fruto": ["semente", "jardim", "natureza", "piano"], "futuro": ["passado", "tempo", "minuto", "século", "fígado"], "genro": ["sogra", "nora", "madrinha", "avó"], "gíria": ["sinônimo", "sotaque", "crepúsculo", "alma", "frase", "idioma"], "grito": ["silêncio", "sussurro", "conversa", "sobrinho", "pergunta"], "herança": ["madrinha", "família", "tio", "neta", "sinônimo", "pimenta", "marinheiro", "conto"], "história": ["resposta", "memória", "comida", "apelido", "surpresa", "tempo"], "hoje": ["ontem", "amanhã", "crepúsculo", "tristeza", "dente"], "igreja": ["mercado", "escola", "bairro", "operário"], "instante": ["segundo", "momento", "eternidade", "almoço", "aurora"], "irmã": ["irmão", "avô", "tia", "pintura", "sal", "apelido"], "irmão": ["filha", "irmã", "pais", "tia", "engenheiro", "ponte"], "janela": ["cozinha", "porta", "braço", "igreja", "nação", "profissão"], "jantar": ["almoço", "pão", "mel", "coração", "emprego"], "joelho": ["perna", "pé", "coração", "pedreiro", "tambor"], "lago": ["cachoeira", "mar", "natureza", "acento"], "lar": ["casa", "quarto", "rua", "ponte", "praça", "conto"], "lavrador": ["pescador", "pastor", "padeiro", "ofício", "selva", "engenheiro"], "leite": ["queijo", "manteiga", "pele", "pão", "mandioca", "época"], "letra": ["apelido", "sílaba", "significado", "dia"], "linguagem": ["idioma", "frase", "riacho", "grito", "cachoeira"], "livro": ["conto", "pintura", "cena", "boca"], "língua": ["boca", "dente", "osso", "tarde"], "madrinha": ["padrinho", "herança", "genro", "neta", "idioma"], "mãe": ["pais", "pai", "neto", "cena", "avó"], "mágoa": ["tristeza", "dor", "melancolia", "nostalgia"], "mandioca": ["milho", "carne", "feijão", "pimenta", "árvore", "leite", "sentido"], "manhã": ["dia", "tarde", "ano", "profissão"], "marinheiro": ["soldado", "engenheiro", "pedreiro", "médico", "advogado", "herança"], "mata": ["floresta", "selva", "fruto", "mercado", "árvore"], "médico": ["pastor", "enfermeira", "estado", "marinheiro", "madrugada"], "medo": ["ansiedade", "pavor", "angústia", "ternura"], "mel": ["açúcar", "sal", "jantar", "pimenta", "melancolia"], "melancolia": ["nostalgia", "tristeza", "carinho", "médico", "mágoa"], "melodia": ["canção", "ritmo", "piano", "cena", "verso"], "memória": ["história", "palavra", "sílaba", "alma"], "milho": ["feijão", "mandioca", "refeição", "trigo", "manteiga", "campo", "tela"], "minuto": ["hora", "segundo", "futuro", "tambor", "noite"], "momento": ["instante", "época", "noite", "café"], "montanha": ["prado", "serra", "jardim", "lavrador", "areia"], "mão": ["braço", "dedo", "pele", "estado"], "mês": ["ano", "semana", "era", "momento", "ferreiro", "sinônimo"], "natureza": ["areia", "floresta", "raiz", "romance"], "neta": ["neto", "tio", "pais", "arroz", "madrinha", "quarto"], "noite": ["tarde", "madrugada", "momento", "minuto", "desenho"], "olho": ["rosto", "boca", "pulmão", "escultura"], "ombro": ["pescoço", "braço", "boca", "água"], "onda": ["mar", "praia", "campo", "riacho", "prado", "ferreiro", "tempo"], "ontem": ["crepúsculo", "hoje", "pavor"], "osso": ["pele", "sangue", "língua", "pescoço", "farinha"], "ovo": ["peixe", "queijo", "carne", "compaixão", "palavra"], "padeiro": ["alfaiate", "açougueiro", "ofício", "lavrador", "capital"], "padrinho": ["nora", "madrinha", "tio", "sotaque"], "pai": ["mãe", "filho", "avó", "cozinha", "canção"], "pais": ["parentesco", "mãe", "contentamento", "irmão", "pavor", "neta", "tia"], "paixão": ["prazer", "amor", "ansiedade", "conto", "unha"], "palavra": ["memória", "idioma", "mágoa", "professor", "cabeça", "tia", "patrão", "dedo", "era", "advogado", "conto", "ovo", "alma", "montanha", "pintura", "feijão"], "pão": ["jantar", "farinha", "leite", "verso"], "passado": ["eternidade", "futuro", "madrugada", "operário"], "pátria": ["nação", "estado", "porto", "alma", "praça", "tempo"], "patrão": ["salário", "operário", "almoço", "juiz", "nora", "carpinteiro", "palavra"], "pavor": ["medo", "susto", "melancolia", "aflição", "pais", "ontem", "ritmo"], "país": ["porta", "nação", "espanto", "cidade", "violão"], "pé": ["joelho", "alma", "rosto", "tela"], "pedreiro": ["operário", "carpinteiro", "joelho", "marinheiro", "osso"], "peito": ["unha", "coração", "pulmão", "comida"], "peixe": ["carne", "ovo", "nora", "chá", "eternidade"], "pele": ["fígado", "osso", "mão", "pulmão", "leite"], "pescador": ["açougueiro", "lavrador", "pedreiro", "amanhã", "verso"], "pescoço": ["dente", "ombro", "corpo", "avô", "sangue"], "pétala": ["flor", "semente", "susto", "cachoeira", "mar"], "piano": ["violão", "tambor", "sobrinho", "fruto", "melodia", "dança", "prado"], "pimenta": ["sal", "café", "mandioca", "açúcar", "mel", "almoço", "herança"], "pintura": ["livro", "tela", "irmã", "música", "janela", "palavra"], "poesia": ["ator", "verso", "casa", "violão", "estado"], "ponte": ["esquina", "porto", "campo", "vale", "lar", "irmão"], "porta": ["janela", "país", "bairro", "amanhã"], "porto": ["ponte", "estação", "pátria", "vila", "juiz"], "prado": ["campo", "montanha", "carinho", "onda", "piano"], "praia": ["onda", "areia", "rio", "jardim", "pescador"], "prazer": ["contentamento", "paixão", "ternura", "aurora", "acento"], "primo": ["tia", "prima", "filha", "professor", "sobrinho", "ator"], "professor": ["enfermeira", "advogado", "primo", "salário", "sapateiro", "água", "palavra"], "profissão": ["ofício", "emprego", "serra", "operário", "janela", "alfaiate"], "pulmão": ["coração", "estômago", "olho", "unha", "peito", "pescoço", "avô", "pele"], "queijo": ["ovo", "leite", "alegria", "manteiga", "poesia", "chá"], "raiz": ["árvore", "folha", "natureza", "serra", "vale"], "resposta": ["pergunta", "história", "letra", "semana"], "riacho": ["rio", "cachoeira", "angústia", "onda", "linguagem", "capital"], "rima": ["verso", "romance", "violão", "fotografia", "areia", "significado"], "rio": ["vale", "riacho", "praia", "pedreiro"], "ritmo": ["melodia", "samba", "teatro", "pavor", "nome"], "rosto": ["cabeça", "olho", "boca", "nora", "pé"], "rua": ["bairro", "avenida", "nação", "lar", "alfaiate"], "sal": ["mel", "pimenta", "irmã"], "salário": ["emprego", "patrão", "professor", "carne"], "samba": ["ritmo", "violão", "flor", "arte", "romance", "música"], "sangue": ["osso", "perna", "pescoço", "sentido"], "sapateiro": ["ferreiro", "alfaiate", "dedo", "professor"], "saudade": ["esperança", "nostalgia", "ansiedade", "dor", "carinho"], "século": ["era", "ano", "minuto"], "segundo": ["minuto", "instante", "crepúsculo", "ferreiro"], "selva": ["mata", "árvore", "campo", "igreja"], "semente": ["pétala", "fruto", "folha", "flor", "mercado", "cachoeira"], "sentido": ["frase", "significado", "sangue", "trabalho", "história", "mandioca"], "serra": ["montanha", "vale", "árvore", "profissão"], "significado": ["sentido", "dicionário", "rima", "letra"], "sílaba": ["letra", "acento", "nostalgia", "compaixão", "frase", "neto", "memória"], "silêncio": ["conversa", "grito", "sussurro", "folha"], "sinônimo": ["dicionário", "gíria", "herança", "sílaba", "mês"], "sobrinho": ["prima", "cunhado", "primo", "piano", "sotaque", "grito"], "sogra": ["cunhado", "genro", "tia", "dente", "tempo"], "soldado": ["juiz", "marinheiro", "operário", "fotografia"], "sotaque": ["gíria", "voz", "vinho", "sobrinho", "acento"], "surpresa": ["espanto", "alegria", "braço", "história"], "sussurro": ["grito", "nome", "silêncio", "frase", "folha"], "tambor": ["piano", "dança", "minuto", "verso", "joelho"], "tarde": ["manhã", "noite", "dia", "açougueiro", "língua"], "teatro": ["dança", "cena", "era", "ritmo", "romance", "pai", "fotografia", "tempo"], "tela": ["pintura", "desenho", "pé", "cinema", "milho"], "tempo": ["futuro", "hora", "rua", "açúcar", "tio", "história", "pátria", "susto", "idioma", "capital", "onda", "teatro", "floresta", "pescador", "prado", "sogra"], "ternura": ["carinho", "compaixão", "alegria", "medo", "praça", "engenheiro"], "tia": ["tio", "primo", "filha", "irmão", "pais", "estação", "sogra"], "tio": ["neta", "tia", "herança", "folha", "tempo"], "trabalho": ["engenheiro", "ofício", "aldeia", "carpinteiro", "sentido"], "tristeza": ["melancolia", "mágoa", "amor", "frase", "hoje"], "unha": ["dedo", "peito", "pulmão", "paixão", "trigo", "açúcar"], "verso": ["poesia", "rima", "pão", "tambor", "melodia", "pescador"], "vinho": ["chá", "água", "farinha", "feijão", "sotaque"], "voz": ["sotaque", "fala", "afeto", "cozinha", "nome", "capital"]};
const LINKS = 743;
const THEMES = {"acento": "linguagem", "açougueiro": "ofícios", "açúcar": "comida", "advogado": "ofícios", "afeto": "sentimentos", "aflição": "sentimentos", "água": "comida", "aldeia": "lugares", "alegria": "sentimentos", "alfaiate": "ofícios", "alma": "corpo", "almoço": "comida", "amanhã": "tempo", "amor": "sentimentos", "angústia": "sentimentos", "ano": "tempo", "ansiedade": "sentimentos", "apelido": "linguagem", "areia": "natureza", "arroz": "comida", "arte": "artes", "árvore": "natureza", "ator": "artes", "aurora": "tempo", "avenida": "lugares", "avó": "família", "avô": "família", "bairro": "lugares", "boca": "corpo", "braço": "corpo", "cabeça": "corpo", "cachoeira": "natureza", "café": "comida", "campo": "natureza", "canção": "artes", "capital": "lugares", "carinho": "sentimentos", "carne": "comida", "carpinteiro": "ofícios", "casa": "lugares", "cena": "artes", "chá": "comida", "cidade": "lugares", "cinema": "artes", "comida": "comida", "compaixão": "sentimentos", "contentamento": "sentimentos", "conto": "artes", "conversa": "linguagem", "coração": "corpo", "corpo": "corpo", "cozinha": "lugares", "crepúsculo": "tempo", "cunhado": "família", "dança": "artes", "dedo": "corpo", "dente": "corpo", "desenho": "artes", "dia": "tempo", "dicionário": "linguagem", "dor": "sentimentos", "emprego": "ofícios", "enfermeira": "ofícios", "engenheiro": "ofícios", "época": "tempo", "era": "tempo", "escola": "lugares", "escultura": "artes", "espanto": "sentimentos", "esperança": "sentimentos", "esquina": "lugares", "estado": "lugares", "estação": "lugares", "estômago": "corpo", "eternidade": "tempo", "fala": "linguagem", "família": "família", "farinha": "comida", "feijão": "comida", "felicidade": "sentimentos", "ferreiro": "ofícios", "fígado": "corpo", "filha": "família", "filho": "família", "flor": "natureza", "floresta": "natureza", "folha": "natureza", "fotografia": "artes", "frase": "linguagem", "fruto": "natureza", "futuro": "tempo", "genro": "família", "gíria": "linguagem", "grito": "linguagem", "herança": "família", "história": "linguagem", "hoje": "tempo", "hora": "tempo", "idioma": "linguagem", "igreja": "lugares", "instante": "tempo", "irmã": "família", "irmão": "família", "janela": "lugares", "jantar": "comida", "jardim": "natureza", "joelho": "corpo", "juiz": "ofícios", "lago": "natureza", "lar": "lugares", "lavrador": "ofícios", "leite": "comida", "letra": "linguagem", "linguagem": "linguagem", "livro": "artes", "língua": "corpo", "madrinha": "família", "madrugada": "tempo", "mãe": "família", "mágoa": "sentimentos", "mandioca": "comida", "manhã": "tempo", "manteiga": "comida", "mar": "natureza", "marinheiro": "ofícios", "mata": "natureza", "médico": "ofícios", "medo": "sentimentos", "mel": "comida", "melancolia": "sentimentos", "melodia": "artes", "memória": "linguagem", "mercado": "lugares", "milho": "comida", "minuto": "tempo", "momento": "tempo", "montanha": "natureza", "música": "artes", "mão": "corpo", "mês": "tempo", "nação": "lugares", "natureza": "natureza", "neta": "família", "neto": "família", "noite": "tempo", "nome": "linguagem", "nora": "família", "nostalgia": "sentimentos", "ofício": "ofícios", "olho": "corpo", "ombro": "corpo", "onda": "natureza", "ontem": "tempo", "operário": "ofícios", "osso": "corpo", "ovo": "comida", "padeiro": "ofícios", "padrinho": "família", "pai": "família", "pais": "família", "paixão": "sentimentos", "palavra": "linguagem", "pão": "comida", "parentesco": "família", "passado": "tempo", "pastor": "ofícios", "pátria": "lugares", "patrão": "ofícios", "pavor": "sentimentos", "país": "lugares", "pé": "corpo", "pedreiro": "ofícios", "peito": "corpo", "peixe": "comida", "pele": "corpo", "pergunta": "linguagem", "perna": "corpo", "pescador": "ofícios", "pescoço": "corpo", "pétala": "natureza", "piano": "artes", "pimenta": "comida", "pintura": "artes", "poesia": "artes", "ponte": "lugares", "porta": "lugares", "porto": "lugares", "praça": "lugares", "prado": "natureza", "praia": "natureza", "prazer": "sentimentos", "prima": "família", "primo": "família", "professor": "ofícios", "profissão": "ofícios", "pulmão": "corpo", "quarto": "lugares", "queijo": "comida", "raiz": "natureza", "refeição": "comida", "resposta": "linguagem", "riacho": "natureza", "rima": "artes", "rio": "natureza", "ritmo": "artes", "romance": "artes", "rosto": "corpo", "rua": "lugares", "sal": "comida", "salário": "ofícios", "samba": "artes", "sangue": "corpo", "sapateiro": "ofícios", "saudade": "sentimentos", "século": "tempo", "segundo": "tempo", "selva": "natureza", "semana": "tempo", "semente": "natureza", "sentido": "linguagem", "serra": "natureza", "significado": "linguagem", "sílaba": "linguagem", "silêncio": "linguagem", "sinônimo": "linguagem", "sobrinho": "família", "sogra": "família", "soldado": "ofícios", "sotaque": "linguagem", "surpresa": "sentimentos", "sussurro": "linguagem", "susto": "sentimentos", "tambor": "artes", "tarde": "tempo", "teatro": "artes", "tela": "artes", "tempo": "tempo", "ternura": "sentimentos", "tia": "família", "tio": "família", "trabalho": "ofícios", "trigo": "comida", "tristeza": "sentimentos", "unha": "corpo", "vale": "natureza", "verso": "artes", "vila": "lugares", "vinho": "comida", "violão": "artes", "voz": "linguagem"};
const words = Object.keys(WORDS);
const idx = new Map(words.map((w,i)=>[w,i]));
const adj = words.map(w=>WORDS[w].map(t=>idx.get(t)));

// --- layout: deterministic 3D positions (Fibonacci sphere + jitter by degree)
const N = words.length;
const R = 60;
const pos = [];
for(let i=0;i<N;i++){
  const y = 1 - (i/(N-1))*2;
  const r = Math.sqrt(1-y*y);
  const th = i*2.399963;
  const s = R*(0.82+0.18*Math.sin(i*12.9898));
  pos.push(new THREE.Vector3(Math.cos(th)*r*s, y*s, Math.sin(th)*r*s));
}

// --- three setup
const canvas = document.getElementById("sky");
const renderer = new THREE.WebGLRenderer({canvas,antialias:true,alpha:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2));
const scene = new THREE.Scene();
scene.fog = new THREE.FogExp2(0x0b0e1a,0.0035);
const cam = new THREE.PerspectiveCamera(55,1,0.1,1000);
cam.position.set(0,0,150);

const themeColor = {};
let ti=0;
for(const t of Object.keys(THEMES)){ themeColor[t] = new THREE.Color().setHSL((ti*0.618)%1,0.55,0.62); ti++; }
const defaultC = new THREE.Color(0x8b8fa3);

// nodes
const nodeGeo = new THREE.SphereGeometry(1,10,10);
const nodes = [];
words.forEach((w,i)=>{
  const m = new THREE.Mesh(nodeGeo, new THREE.MeshBasicMaterial({color:themeColor[THEMES[w]]||defaultC,transparent:true,opacity:0.9}));
  m.position.copy(pos[i]);
  m.scale.setScalar(0.7+Math.sqrt(adj[i].length)*0.35);
  m.userData.i = i;
  scene.add(m); nodes.push(m);
});
// links
{
  const arr=[];
  for(let i=0;i<N;i++) for(const j of adj[i]) if(j>i){ arr.push(pos[i].x,pos[i].y,pos[i].z,pos[j].x,pos[j].y,pos[j].z); }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(arr,3));
  scene.add(new THREE.LineSegments(g,new THREE.LineBasicMaterial({color:0x2a2f45,transparent:true,opacity:0.5})));
}
// highlight lines (rebuilt on selection)
let hlLines = null;
function setHighlight(sel){
  if(hlLines){ scene.remove(hlLines); hlLines.geometry.dispose(); hlLines=null; }
  nodes.forEach((m,i)=>{
    const mat = m.material;
    if(sel==null){ mat.opacity=0.9; mat.color.copy(themeColor[THEMES[words[i]]]||defaultC); }
    else if(i===sel){ mat.opacity=1; mat.color.set(0xe0b34c); }
    else if(adj[sel].includes(i)){ mat.opacity=1; mat.color.copy(themeColor[THEMES[words[i]]]||defaultC); }
    else { mat.opacity=0.12; mat.color.copy(defaultC); }
  });
  if(sel!=null){
    const arr=[];
    for(const j of adj[sel]) arr.push(pos[sel].x,pos[sel].y,pos[sel].z,pos[j].x,pos[j].y,pos[j].z);
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(arr,3));
    hlLines = new THREE.LineSegments(g,new THREE.LineBasicMaterial({color:0xe0b34c,transparent:true,opacity:0.85}));
    scene.add(hlLines);
  }
}

// labels: CSS2D-free, use sprites
function makeLabel(text,color){
  const c = document.createElement("canvas");
  const ctx = c.getContext("2d");
  const fs = 44;
  ctx.font = `600 ${fs}px Inter, sans-serif`;
  const w = Math.ceil(ctx.measureText(text).width)+16;
  c.width = w; c.height = fs+16;
  const ctx2 = c.getContext("2d");
  ctx2.font = `600 ${fs}px Inter, sans-serif`;
  ctx2.fillStyle = color;
  ctx2.fillText(text,8,fs);
  const tex = new THREE.CanvasTexture(c);
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({map:tex,transparent:true,depthWrite:false}));
  sp.scale.set(w/14, (fs+16)/14, 1);
  return sp;
}
const labels = words.map((w,i)=>{
  const s = makeLabel(w, "#e8e4da");
  s.position.copy(pos[i]).add(new THREE.Vector3(0, 2.2+nodes[i].scale.x, 0));
  s.visible = false;
  scene.add(s); return s;
});
function showLabels(sel){
  labels.forEach((s,i)=> s.visible = sel==null ? false : (i===sel || adj[sel].includes(i)));
}

// rotation + drag
let rotY=0, rotX=0, auto=true, dragging=false, px=0, py=0;
addEventListener("resize", fit);
function fit(){
  renderer.setSize(innerWidth,innerHeight);
  cam.aspect = innerWidth/innerHeight; cam.updateProjectionMatrix();
}
fit();
addEventListener("pointerdown",e=>{dragging=true;auto=false;px=e.clientX;py=e.clientY;});
addEventListener("pointerup",()=>{dragging=false;});
addEventListener("pointermove",e=>{
  if(!dragging) return;
  rotY += (e.clientX-px)*0.005; rotX += (e.clientY-py)*0.005;
  rotX = Math.max(-1.2,Math.min(1.2,rotX));
  px=e.clientX;py=e.clientY;
});
const ray = new THREE.Raycaster();
const mouse = new THREE.Vector2();
canvas.addEventListener("click",e=>{
  mouse.x = (e.clientX/innerWidth)*2-1; mouse.y = -(e.clientY/innerHeight)*2+1;
  ray.setFromCamera(mouse,cam);
  const hit = ray.intersectObjects(nodes);
  if(hit.length) select(hit[0].object.userData.i);
});

// card + selection
const card = document.getElementById("card");
function select(i){
  setHighlight(i); showLabels(i);
  const w = words[i];
  const rel = adj[i].map(j=>words[j]);
  card.style.display="block";
  card.innerHTML = `<h2>${w}</h2><div class="tema">${THEMES[w]||"sem tema"}</div>
  <h3>laços (${rel.length})</h3><ul>${rel.map(r=>`<li><a data-w="${r}">${r}</a></li>`).join("")}</ul>
  <div class="deg">compartilha o universo com ${rel.length} outras palavras</div>`;
  card.querySelectorAll("a").forEach(a=>a.onclick=()=>select(idx.get(a.dataset.w)));
  history.replaceState(null,"","?word="+encodeURIComponent(w));
}
function clearSel(){
  setHighlight(null); showLabels(null);
  card.style.display="none";
  history.replaceState(null,"","");
}
card.addEventListener("click",e=>{ if(e.target===card) clearSel(); });

// search
const q = document.getElementById("q");
const list = document.getElementById("list");
q.addEventListener("input",()=>{
  const v = q.value.trim().toLowerCase();
  if(!v){ list.style.display="none"; return; }
  const hits = words.filter(w=>w.includes(v)).slice(0,12);
  list.innerHTML = hits.map(w=>`<div data-w="${w}">${w}<small>${adj[idx.get(w)].length}</small></div>`).join("");
  list.style.display = hits.length?"block":"none";
  list.querySelectorAll("div").forEach(d=>d.onclick=()=>{ select(idx.get(d.dataset.w)); list.style.display="none"; q.value=""; });
});
q.addEventListener("keydown",e=>{
  if(e.key==="Enter"){ const v=q.value.trim().toLowerCase(); const hit=words.find(w=>w===v)||words.find(w=>w.includes(v)); if(hit) select(idx.get(hit)); }
  if(e.key==="Escape"){ q.value=""; list.style.display="none"; }
});
addEventListener("keydown",e=>{ if(e.key==="Escape") clearSel(); });

// stats
document.getElementById("stats").innerHTML =
  `<b>${N}</b> palavras · <b>${LINKS}</b> laços · mais conectada: <b>${words[adj.reduce((a,b,i)=>adj[b].length>adj[a].length?b:a,0)]}</b>`;

// deep link
const m = new URLSearchParams(location.search).get("word");
if(m){
  const w2 = words.find(w=>w.toLowerCase()===m.toLowerCase());
  if(w2) select(idx.get(w2));
}

// animate
const group = new THREE.Group();
scene.add(group);
nodes.forEach(n=>group.add(n));
labels.forEach(l=>group.add(l));
let t=0;
(function loop(){
  requestAnimationFrame(loop);
  t+=0.005;
  if(auto) rotY += 0.0012;
  group.rotation.y = rotY; group.rotation.x = rotX;
  nodes.forEach((n,i)=>{ n.scale.setScalar((0.7+Math.sqrt(adj[i].length)*0.35)*(1+0.06*Math.sin(t*2+i))); });
  renderer.render(scene,cam);
})();
