import re
t = open('universe/index.html', encoding='utf-8').read()
m = re.search(r'<script type="module">([\s\S]*?)</script>', t)
open('tmp_check.js','w',encoding='utf-8').write(m.group(1))
print('len', len(m.group(1)))