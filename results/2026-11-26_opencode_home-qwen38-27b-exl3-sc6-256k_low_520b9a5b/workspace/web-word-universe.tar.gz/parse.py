import re, json, os, html, unicodedata
from urllib.parse import unquote

site = "site"
words = {}   # word -> {"tema": str, "links": [filenames]}
redirect = {}  # filename -> target filename

def norm(w):
    w = w.lower()
    return "".join(c for c in unicodedata.normalize("NFD", w) if unicodedata.category(c) != "Mn")

for fn in sorted(os.listdir(site)):
    if not fn.endswith(".html"):
        continue
    if fn in ("index.html", "sobre.html", "contato.html"):
        continue
    txt = open(os.path.join(site, fn), encoding="utf-8").read()
    m = re.search(r"<h1>(.*?)</h1>", txt)
    if not m:
        r = re.search(r'url=([\w\-]+\.html)', txt)
        if r:
            redirect[fn[:-5]] = r.group(1)[:-5]
        continue
    word = html.unescape(m.group(1)).strip()
    tema = re.search(r'class="tema">Tema:\s*(.*?)</p>', txt)
    tema = html.unescape(tema.group(1)).strip() if tema else ""
    links = []
    for sec in re.findall(r'<section id="(?:sinonimos|analogas)">.*?</section>', txt, re.S):
        for a in re.findall(r'<a href="([^"]+\.html)">', sec):
            links.append(unquote(a)[:-5])
    words[word] = {"tema": tema, "links": links}

canon = set(words.keys())
def resolve(target):
    # follow redirects
    seen = set()
    while target in redirect and target not in seen:
        seen.add(target)
        target = redirect[target]
    if target in canon:
        return target
    t = norm(target)
    for w in canon:
        if norm(w) == t:
            return w
    return None

out = {}
for w, d in words.items():
    resolved = []
    for l in d["links"]:
        r = resolve(l)
        if r and r != w and r not in resolved:
            resolved.append(r)
    out[w] = resolved

json.dump(out, open("words.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

pairs = set()
for w, ls in out.items():
    for l in ls:
        pairs.add(tuple(sorted((w, l))))
deg = {w: len(ls) for w, ls in out.items()}
most = sorted(deg.items(), key=lambda kv: (-kv[1], kv[0]))
result = {"words": len(out), "relations": len(pairs), "most_connected": most[0][0] if most else None}
json.dump(result, open("result.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(json.dumps(result, ensure_ascii=False))
print("top:", most[:5])
unres = set()
for w, d in words.items():
    for l in d["links"]:
        if resolve(l) is None:
            unres.add(l)
print("unresolved:", sorted(unres))