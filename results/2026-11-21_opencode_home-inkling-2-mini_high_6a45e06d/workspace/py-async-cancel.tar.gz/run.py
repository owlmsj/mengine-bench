"""Concurrency-limited batch runner.

Usage:
    from run import run_tasks
    await run_tasks([job_a, job_b, ...], max_concurrent=4)
"""

import asyncio
from collections.abc import Awaitable, Callable, Sequence
from typing import Any

Task = Callable[[], Awaitable[Any]]


async def run_tasks(tasks: Sequence[Task], max_concurrent: int) -> list:
    """Run zero-argument callables that return awaitable jobs.

    At most ``max_concurrent`` jobs run at once. Returns when every job is
    done (including jobs queued behind the limit). If any job raises, all
    jobs are still given a chance to finish, then the first exception is
    re-raised. On KeyboardInterrupt or cancellation, remaining jobs are
    cancelled and awaited so their cleanup code runs before the interrupt
    propagates.

    Returns the list of per-job results (one entry per task, in input order).
    Exceptions are re-raised, not collected.
    """
    if not isinstance(max_concurrent, int) or isinstance(max_concurrent, bool):
        raise TypeError("max_concurrent must be an int")
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent!r}")
    if tasks is None:
        raise TypeError("tasks must be a sequence of zero-argument callables")
    task_list = list(tasks)
    for t in task_list:
        if not callable(t):
            raise TypeError(f"task must be callable, got {t!r}")
    if not task_list:
        return []

    sem = asyncio.Semaphore(max_concurrent)

    async def run_one(task: Task) -> Any:
        async with sem:
            return await task()

    children = [asyncio.ensure_future(run_one(t)) for t in task_list]

    try:
        results = await asyncio.gather(*children, return_exceptions=True)
    except (KeyboardInterrupt, asyncio.CancelledError):
        # Interrupt arrived: cancel in-flight/queued jobs and await them so
        # their finally blocks (cleanup code) run, then let the interrupt
        # propagate.
        for c in children:
            c.cancel()
        await asyncio.gather(*children, return_exceptions=True)
        raise

    for r in results:
        if isinstance(r, BaseException) and not isinstance(r, asyncio.CancelledError):
            raise r
    return results
