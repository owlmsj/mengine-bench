import sqlite3, json

con = sqlite3.connect('analytics.db')
cur = con.cursor()
users = {r[0]: (r[1], r[2]) for r in cur.execute('select user_id, platform, is_test from users')}
events = cur.execute('select user_id, name, ts from events').fetchall()

STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']

by_user = {}
for uid, name, ts in events:
    if uid not in users:
        continue
    plat, is_test = users[uid]
    if is_test:
        continue
    by_user.setdefault(uid, []).append((ts, name))

def first_at_or_after(evts, name, t):
    cands = [ts for ts, n in evts if n == name and ts >= t]
    return min(cands) if cands else None

funnel = {}       # platform -> dict step -> count
convs = {}        # platform -> list of (step, ratio)
details = {}

for uid, evts in by_user.items():
    plat = users[uid][0]
    installs = [ts for ts, n in evts if n == 'install']
    if not installs:
        continue
    t = min(installs)
    reached = {'install': t}
    for step in STEPS[1:]:
        prev = t
        t_next = first_at_or_after(evts, step, prev)
        if t_next is None:
            break
        reached[step] = t_next
        t = t_next
    for plat_step, val in [(p, v) for p, v in reached.items()]:
        pass
    funnel.setdefault(plat, {})
    for step in STEPS:
        if step in reached:
            funnel[plat][step] = funnel[plat].get(step, 0) + 1

# missing steps: count per step as players who reached that step
# (a player who reached install but not tutorial is counted at install only)
# conversion: step players / previous step players
for plat in funnel:
    prev = None
    for step in STEPS:
        cnt = funnel[plat].get(step, 0)
        if prev is None:
            prev = cnt
            continue
        convs.setdefault(plat, []).append((step, cnt / prev if prev else None, cnt, prev))
        prev = cnt

result = {'funnel': {}, 'biggest_drop': {}}
for plat, d in funnel.items():
    result['funnel'][plat] = {s: d.get(s, 0) for s in STEPS}
    conv = convs.get(plat, [])
    if conv:
        best = min(conv, key=lambda x: x[1] if x[1] is not None else float('inf'))
        result['biggest_drop'][plat] = best[0]
    else:
        result['biggest_drop'][plat] = None

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)

print(json.dumps(result, indent=2))
for plat in funnel:
    print(plat, 'conversions:')
    for step, ratio, cnt, prev in convs[plat]:
        print(' ', step, cnt, '/', prev, '=', ratio)
