# H1 2026 — CFO summary (for the investors' board meeting)

Currency: R$ (source data uses Brazilian format). Period: Jan–Jun 2026.

## Headline
- Net revenue grew from R$ 200.5k (Jan) to R$ 272.4k (Jun), +35.9% over the half.
- Gross margin ~69–72% every month (70.0% in Jan, 72.4% in Jun).
- EBITDA was negative all six months, improving steadily: -R$ 210.3k (Jan) to -R$ 193.0k (Jun).
- Burn (avg monthly negative EBITDA, Apr–Jun 2026): R$ 197.3k/month
- Closing cash (30/06/2026): R$ 1.847.350,40
- Runway at the current burn: ~9.4 months (to early ~March 2027)

## Monthly detail
| Month | Revenue | Gross margin % | EBITDA |
|---|---|---|---|
| 2026-01 | 200.510,87 | 70.03 | -210.278,96 |
| 2026-02 | 216.328,06 | 70.29 | -212.300,08 |
| 2026-03 | 219.066,17 | 68.46 | -204.525,45 |
| 2026-04 | 238.163,26 | 70.24 | -196.950,65 |
| 2026-05 | 243.032,89 | 69.56 | -201.945,82 |
| 2026-06 | 272.391,57 | 72.41 | -192.968,22 |

H1 gross profit: R$ 976.022,59.
H1 net revenue: R$ 1.389.492,82
H1 EBITDA: R$ -1.218.969,18 (sum of monthly EBITDA)

## Assumptions
- Revenue = net of refunds/cancellations (3.1.09 is mapped to revenue in the chart of accounts).
- EBITDA = revenue + COGS + opex (sales/marketing, R&D, G&A), excluding financial income and interest (6.1.01/6.1.02), per its definition.
- Burn per board definition (README.md): average monthly negative EBITDA of the last three closed months = April, May, June 2026.
- Runway = latest closing cash balance (30/06/2026, R$ 1.847.350,40) / burn. 31/05/2026 balance (R$ 2.309.188,00) is superseded by the June close.
- The ledger does not reconcile to the cash-balance series (ledger net change over H1 is -R$ 1.179.354,45 vs the balance change of -R$ 461.837,60, a difference of ~R$ 717.516,85). Cash balances are taken as authoritative for runway; the ledger is used for the P&L.

## Presentation line
"Revenue is growing steadily (~3-4%/month), gross margin is stable around 70%, and the monthly EBITDA loss narrowed from ~210k in January to ~193k by June. At a ~197k/month burn and R$ 1.85M of closing cash, runway is ~9.4 months — the business needs ~R$ 197k/month coverage or a funding/cost decision well before the end of H2 2026."
