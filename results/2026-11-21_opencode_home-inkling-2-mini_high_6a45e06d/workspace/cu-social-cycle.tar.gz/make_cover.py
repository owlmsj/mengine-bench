from PIL import Image, ImageDraw, ImageFont
W, H = 1200, 675
img = Image.new("RGB", (W, H))
for y in range(H):
    t = y / H
    if t < 0.62:
        tt = t / 0.62
        r = int(28 + (255 - 28) * tt ** 1.4)
        g = int(42 + (166 - 42) * tt)
        b = int(110 + (80 - 110) * tt)
    else:
        tt = (t - 0.62) / 0.38
        r = int(22 - 10 * tt)
        g = int(66 - 22 * tt)
        b = int(96 - 30 * tt)
    for x in range(W):
        img.putpixel((x, y), (r, g, b))
d = ImageDraw.Draw(img)
sun_r = 95
sun_x, sun_y = 600, 400
d.ellipse([sun_x - sun_r, sun_y - sun_r, sun_x + sun_r, sun_y + sun_r], fill=(255, 214, 140))
d.ellipse([sun_x - sun_r - 18, sun_y - sun_r - 18, sun_x + sun_r + 18, sun_y + sun_r + 18], outline=(255, 230, 170), width=4)
for i in range(14):
    yy = 415 + i * 14
    width = max(60, 320 - i * 20)
    d.rectangle([600 - width // 2, yy, 600 + width // 2, yy + 5], fill=(255, 214, 140))
d.rectangle([0, 430, 210, 500], fill=(16, 24, 40))
d.polygon([(30, 430), (90, 330), (150, 430)], fill=(16, 24, 40))
d.rectangle([45, 555, 72, 675], fill=(16, 24, 40))
d.rectangle([118, 555, 145, 675], fill=(16, 24, 40))
d.rectangle([60, 500, 110, 675], fill=(16, 24, 40))
d.rectangle([900, 300, 962, 470], fill=(24, 30, 48))
d.polygon([(894, 300), (931, 250), (968, 300)], fill=(24, 30, 48))
d.rectangle([917, 210, 945, 255], fill=(255, 214, 140))

def boat(cx, cy, s, color):
    d.polygon([(cx, cy), (cx + int(60 * s), cy + int(30 * s)), (cx - int(60 * s), cy + int(30 * s))], fill=color)
    d.polygon([(cx, cy - int(55 * s)), (cx - int(40 * s), cy - int(2 * s)), (cx, cy - int(2 * s))], fill=(235, 240, 248))
    d.polygon([(cx + int(4 * s), cy - int(48 * s)), (cx + int(38 * s), cy - int(2 * s)), (cx + int(4 * s), cy - int(2 * s))], fill=(200, 214, 232))

boat(430, 505, 1.0, (16, 24, 40))
boat(790, 560, 0.75, (16, 24, 40))
d.rounded_rectangle([140, 78, 1060, 226], radius=26, fill=(10, 18, 34))
f_title = ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf", 96)
f_sub = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 34)
title = "Harbor Day 2026"
bbox = d.textbbox((0, 0), title, font=f_title)
d.text((600 - (bbox[2] - bbox[0]) // 2 - bbox[0], 152 - (bbox[3] - bbox[1]) // 2 - bbox[1]), title, font=f_title, fill=(255, 255, 255))
sub = "Ships out \u00b7 North Cove \u00b7 07:00"
bbox = d.textbbox((0, 0), sub, font=f_sub)
d.text((600 - (bbox[2] - bbox[0]) // 2 - bbox[0], 244 - bbox[1]), sub, font=f_sub, fill=(255, 230, 170))
img.save("cover.png")
print("saved", img.size)
