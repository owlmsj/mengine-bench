const fs = require('fs');
const path = require('path');

const SITE = 'site';
const files = fs.readdirSync(SITE).filter(f => f.endsWith('.html'));
const fileSet = new Set(files);

const CHROME = new Set(['index.html', 'sobre.html', 'contato.html']);

function decode(name) {
  try { return decodeURIComponent(name); } catch (e) { return name; }
}

function targetWord(href) {
  if (!href) return null;
  href = href.split('#')[0].split('?')[0];
  if (!href.endsWith('.html')) return null;
  return decode(href.slice(0, -'.html'.length));
}

const redirects = {}; // alias -> canonical
const canonFiles = new Set();

// Identify redirect pages (meta refresh)
for (const f of files) {
  const html = fs.readFileSync(path.join(SITE, f), 'utf8');
  const m = html.match(/<meta http-equiv="refresh" content="0; url=([^"]+)"/i);
  if (m) {
    const target = decode(m[1].split('#')[0].replace(/\.html$/, ''));
    redirects[f.replace(/\.html$/, '')] = target;
  }
}

const linksFrom = {}; // word -> Set of linked targets
const wordInfo = {};

for (const f of files) {
  if (CHROME.has(f)) continue;
  const stem = f.replace(/\.html$/, '');
  const html = fs.readFileSync(path.join(SITE, f), 'utf8');
  const h1m = html.match(/<main>[\s\S]*?<h1>([\s\S]*?)<\/h1>/);
  const tema = (html.match(/<p class="tema">([\s\S]*?)<\/p>/) || [])[1];
  const word = h1m ? h1m[1].trim() : stem;
  wordInfo[stem] = { file: f, h1: word, tema: tema ? tema.replace(/<[^>]+>/g, '').trim() : null };

  // Redirect alias pages: link only to canonical
  if (redirects[stem]) {
    linksFrom[stem] = new Set([redirects[stem]]);
    continue;
  }

  // Extract links within <main> (sinonimos/analogas)
  const mainM = html.match(/<main>([\s\S]*?)<\/main>/);
  const main = mainM ? mainM[1] : '';
  const linkRe = /<a href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  const set = new Set();
  let m;
  while ((m = linkRe.exec(main)) !== null) {
    const t = targetWord(m[1]);
    if (t) set.add(t);
  }
  linksFrom[stem] = set;
}

// Normalize word forms: dedupe by canonical stem (file stem, decoded)
const words = Object.keys(wordInfo).filter(s => !redirects[s]); // canonical word stems
const allWords = Object.keys(wordInfo); // canonical + aliases

// Sanity: list dangling targets
const dangling = new Set();
for (const [stem, set] of Object.entries(linksFrom)) {
  for (const t of set) {
    if (!fileSet.has(t + '.html')) dangling.add(t);
  }
}

console.log('Total html files:', files.length);
console.log('Redirect aliases:', JSON.stringify(redirects, null, 1));
console.log('Canonical words:', words.length);
console.log('Dangling targets (not existing):', [...dangling]);
console.log('---Sample wordInfo---');
for (const w of ['saudade', 'tempo', 'palavra', 'index']) {
  if (wordInfo[w]) console.log(w, JSON.stringify(wordInfo[w]));
}
