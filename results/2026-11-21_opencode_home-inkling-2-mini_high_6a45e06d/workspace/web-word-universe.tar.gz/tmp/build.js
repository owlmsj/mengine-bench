const fs = require('fs');
const path = require('path');

const SITE = 'site';
const files = fs.readdirSync(SITE).filter(f => f.endsWith('.html'));
const fileSet = new Set(files);
const CHROME = new Set(['index.html', 'sobre.html', 'contato.html']);

function decode(name) { try { return decodeURIComponent(name); } catch (e) { return name; } }
function stemOf(href) {
  if (!href) return null;
  const h = href.split('#')[0].split('?')[0];
  if (!h.endsWith('.html')) return null;
  return decode(h.slice(0, -'.html'.length));
}

// Redirect aliases
const redirects = {};
for (const f of files) {
  const html = fs.readFileSync(path.join(SITE, f), 'utf8');
  const m = html.match(/<meta http-equiv="refresh" content="0; url=([^"]+)"/i);
  if (m) redirects[f.replace(/\.html$/, '')] = stemOf(m[1]);
}

const info = {};   // stem -> {h1, tema, file}
const rel = {};    // stem -> Set of linked stems (canonical targets kept)
const allFound = new Set();

for (const f of files) {
  if (CHROME.has(f)) continue;
  const stem = f.replace(/\.html$/, '');
  if (redirects[stem]) continue; // alias pages aren't words
  const html = fs.readFileSync(path.join(SITE, f), 'utf8');
  const h1m = html.match(/<main>[\s\S]*?<h1>([\s\S]*?)<\/h1>/);
  const temaM = html.match(/<p class="tema">([\s\S]*?)<\/p>/);
  const h1 = h1m ? h1m[1].trim() : stem;
  const tema = temaM ? temaM[1].replace(/<[^>]+>/g, '').trim() : '';
  info[stem] = { h1, tema, file: f };
  rel[stem] = new Set();
  const mainM = html.match(/<main>([\s\S]*?)<\/main>/);
  const main = mainM ? mainM[1] : '';
  // split into sections sinonimos / analogas
  const sections = [...main.matchAll(/<section id="([^"]+)">([\s\S]*?)<\/section>/gi)];
  const linked = new Set();
  for (const sec of sections) {
    const linkRe = /<a href="([^"]+)"[^>]*>/gi;
    let m;
    while ((m = linkRe.exec(sec[2])) !== null) {
      const t = stemOf(m[1]);
      if (t && t !== stem) linked.add(t);
    }
  }
  // Also capture sections' link text names for display (not needed)
  rel[stem] = linked;
  for (const t of linked) allFound.add(t);
}

// Dangling targets found across all word pages
const dangling = new Set();
const danglingFrom = {};
for (const [stem, set] of Object.entries(rel)) {
  for (const t of set) {
    if (!fileSet.has(t + '.html')) { dangling.add(t); (danglingFrom[stem] = danglingFrom[stem] || []).push(t); }
  }
}

// Keep only relations to existing canonical word files
const canonSet = new Set(Object.keys(info));
const data = {};
for (const [stem, set] of Object.entries(rel)) {
  const kept = [...set].filter(t => canonSet.has(t)).sort((a, b) => a.localeCompare(b));
  data[stem] = kept;
  allFound.delete(stem);
}

// Canonical words with no relations: still listed (they exist)
const words = Object.keys(info).sort((a, b) => a.localeCompare(b));

// distinct pairs (canonical words only)
const pairSet = new Set();
for (const [a, list] of Object.entries(data)) {
  for (const b of list) {
    const [x, y] = a < b ? [a, b] : [b, a];
    pairSet.add(x + '|' + y);
  }
}

// degree = count of relations per word (distinct linked words)
const degree = {};
for (const w of words) degree[w] = new Set([...(data[w] || []), ...Object.entries(data).filter(([, l]) => l.includes(w)).map(([s]) => s)]).size;

// most_connected
let most = { word: null, degree: -1 };
for (const w of words) {
  if (degree[w] > most.degree) most = { word: w, degree: degree[w] };
}

// normalize names for display: for words.json use canonical stem (decoded)
// But if h1 differs from stem (e.g. Angustia -> angústia), the display word should be h1.
// Decision: use h1 display name as the "word" key in words.json? Or stem?
// Use stem as key so lookups match filenames; keep h1 as displayName.
const json = {
  words: words.map(w => ({ stem: w, name: info[w].h1, tema: info[w].tema, file: info[w].file })),
  links: {},
  redirects: redirects,
  dangling: [...dangling].sort(),
  danglingFrom: danglingFrom,
};

for (const w of words) {
  json.links[w] = data[w] || [];
}

// counts
const relations = pairSet.size;
const result = {
  words: words.length,
  relations,
  most_connected: { word: info[most.word].h1, stem: most.word, degree: degree[most.word] },
};

fs.writeFileSync('tmp/crawled.json', JSON.stringify({ json, result, data, info, rel, danglingFrom, redirects }, (k, v) => v, 2));
fs.writeFileSync('tmp/pairs.txt', [...pairSet].sort().join('\n'));

console.log('words:', words.length);
console.log('relations:', relations);
console.log('most_connected:', JSON.stringify(result.most_connected));
console.log('dangling:', [...dangling].sort());
console.log('danglingFrom:', JSON.stringify(danglingFrom, (k,v)=>v, 1));
console.log('aliases:', JSON.stringify(redirects));
console.log('sample links saudade:', JSON.stringify(json.links['saudade']));
console.log('sample links palavra:', JSON.stringify(json.links['palavra']));
console.log('sample links tempo:', JSON.stringify(json.links['tempo']));
