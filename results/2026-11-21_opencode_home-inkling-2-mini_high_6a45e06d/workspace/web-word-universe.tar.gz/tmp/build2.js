const fs = require('fs');
const path = require('path');
const SITE = 'site';
const files = fs.readdirSync(SITE).filter(f => f.endsWith('.html'));
const fileSet = new Set(files);
const CHROME = new Set(['index.html', 'sobre.html', 'contato.html']);

function decode(name) { try { return decodeURIComponent(name); } catch (e) { return name; } }
function stemOf(href) {
  if (!href) return null;
  const h = href.split('#')[0].split('?')[0];
  if (!h.endsWith('.html')) return null;
  return decode(h.slice(0, -'.html'.length));
}

// redirect aliases
const redirects = {};   // alias -> canonical stem
const aliasOf = {};     // canonical stem -> alias stem
for (const f of files) {
  const html = fs.readFileSync(path.join(SITE, f), 'utf8');
  const m = html.match(/<meta http-equiv="refresh" content="0; url=([^"]+)"/i);
  if (m) {
    const alias = f.replace(/\.html$/, '');
    const target = stemOf(m[1]);
    redirects[alias] = target;
    aliasOf[target] = alias;
  }
}

const info = {};
const rel = {};
const danglingFrom = {};
const danglingSet = new Set();

for (const f of files) {
  if (CHROME.has(f)) continue;
  const stem = f.replace(/\.html$/, '');
  if (redirects[stem]) continue; // alias pages are not words
  const html = fs.readFileSync(path.join(SITE, f), 'utf8');
  const h1m = html.match(/<main>[\s\S]*?<h1>([\s\S]*?)<\/h1>/);
  const temaM = html.match(/<p class="tema">([\s\S]*?)<\/p>/);
  const h1 = h1m ? h1m[1].trim() : stem;
  const tema = temaM ? temaM[1].replace(/<[^>]+>/g, '').replace(/^Tema:\s*/, '').trim() : '';
  info[stem] = { stem, h1, tema, file: f };

  const mainM = html.match(/<main>([\s\S]*?)<\/main>/);
  const main = mainM ? mainM[1] : '';
  const sections = [...main.matchAll(/<section id="([^"]+)">([\s\S]*?)<\/section>/gi)];
  const byType = {};   // 'sinonimo' | 'analogia' | 'outros' -> [stems]
  const linked = new Set();
  for (const sec of sections) {
    const sid = sec[1].toLowerCase();
    const type = sid.includes('sin') ? 'sinonimo' : (sid.includes('analog') ? 'analogia' : 'outros');
    const linkRe = /<a href="([^"]+)"[^>]*>/gi;
    let mm;
    const list = [];
    while ((mm = linkRe.exec(sec[2])) !== null) {
      const t = stemOf(mm[1]);
      if (!t || t === stem) continue;
      list.push(t);
      linked.add(t);
    }
    if (list.length) byType[type] = (byType[type] || []).concat(list);
  }
  for (const t of linked) {
    if (!fileSet.has(t + '.html')) {
      danglingSet.add(t);
      (danglingFrom[stem] = danglingFrom[stem] || []).push(t);
    }
  }
  rel[stem] = { linked: [...linked], byType };
}

const canonSet = new Set(Object.keys(info));

// build display-name-keyed data
const words = Object.values(info).sort((a, b) => a.h1.localeCompare(b.h1, 'pt-BR'));
const stemToH1 = Object.fromEntries(Object.values(info).map(i => [i.stem, i.h1]));
const h1ToStem = Object.fromEntries(Object.values(info).map(i => [i.h1, i.stem]));

const wordsJson = {};
for (const w of words) {
  const linked = [...rel[w.stem].linked].filter(t => canonSet.has(t)).map(t => stemToH1[t]).sort((a, b) => a.localeCompare(b, 'pt-BR'));
  wordsJson[w.h1] = linked;
}

// themes
const themes = [...new Set(words.map(w => w.tema))].sort((a, b) => a.localeCompare(b, 'pt-BR'));

// related info structures
const inSet = {}; // canonical h1 -> set of h1s that link to it
for (const w of words) {
  for (const t of rel[w.stem].linked) {
    if (!canonSet.has(t)) continue;
    const th = stemToH1[t];
    (inSet[th] = inSet[th] || new Set()).add(w.h1);
  }
}

// pairs
const pairSet = new Set();
for (const [h1, list] of Object.entries(wordsJson)) {
  for (const b of list) {
    const [x, y] = h1 < b ? [h1, b] : [b, h1];
    pairSet.add(x + '|' + y);
  }
}

// degree: distinct distinct neighbors
const degree = {};
for (const w of words) {
  const set = new Set([...(wordsJson[w.h1] || []), ...[...(inSet[w.h1] || new Set())]]);
  degree[w.h1] = set.size;
}

const relations = pairSet.size;
const rawLinks = {};
for (const w of words) rawLinks[w.h1] = (wordsJson[w.h1] || []).length + ((inSet[w.h1] || new Set()).size);
const sortedByDegree = Object.keys(degree).sort((a, b) => (degree[b] - degree[a]) || (rawLinks[b] - rawLinks[a]) || a.localeCompare(b, 'pt-BR'));
const mostConnected = sortedByDegree[0];
const tied = sortedByDegree.filter(w => degree[w] === degree[mostConnected]);

// build per-word details
const wordDetails = {};
for (const w of words) {
  const linkedStems = rel[w.stem].linked;
  const display = [...new Set(linkedStems.filter(t => canonSet.has(t)).map(t => stemToH1[t]))].sort((a, b) => a.localeCompare(b, 'pt-BR'));
  const byType = rel[w.stem].byType;
  wordDetails[w.h1] = {
    h1: w.h1,
    tema: w.tema,
    file: w.file,
    links: display,
    linkedBy: [...(inSet[w.h1] || new Set())].sort((a, b) => a.localeCompare(b, 'pt-BR')),
    outgoing: (rel[w.stem].linked.filter(t => canonSet.has(t))).length,
    incoming: (inSet[w.h1] || new Set()).size,
    degree: degree[w.h1],
    alias: aliasOf[w.stem] ? ({ alias: aliasOf[w.stem], name: (Object.values(info).find(i => i.stem === aliasOf[w.stem]) || {}).h1 }) : null,
    dangling: [...new Set(danglingFrom[w.stem] || [])],
    byType: {
      sinonimo: byType.sinonimo ? [...new Set(byType.sinonimo.filter(t => canonSet.has(t)).map(t => stemToH1[t]))].sort((a, b) => a.localeCompare(b, 'pt-BR')) : [],
      analogia: byType.analogia ? [...new Set(byType.analogia.filter(t => canonSet.has(t)).map(t => stemToH1[t]))].sort((a, b) => a.localeCompare(b, 'pt-BR')) : [],
      outros: byType.outros ? [...new Set(byType.outros.filter(t => canonSet.has(t)).map(t => stemToH1[t]))].sort((a, b) => a.localeCompare(b, 'pt-BR')) : [],
    },
    // alias display name for the canonical word (e.g. saudades -> h1 of saudade)
    aliasName: aliasOf[w.stem] ? aliasOf[w.stem] : null,
  };
}

const redirectAliasDetails = Object.entries(redirects).map(([alias, target]) => ({
  alias,
  canonical: stemToH1[target] || target,
}));

const result = {
  words: words.length,
  relations,
  most_connected: mostConnected,
  most_connected_detail: {
    word: mostConnected,
    degree: degree[mostConnected],
    tied: tied,
    tied_word: tied.length === 1 ? mostConnected : tied.join(' | '),
  },
};

// final words.json keys by h1 display name
const wordsData = {};
for (const w of words) wordsData[w.h1] = wordsJson[w.h1] || [];

fs.writeFileSync('words.json', JSON.stringify(wordsData, null, 2));
fs.writeFileSync('result.json', JSON.stringify({
  words: words.length,
  relations,
  most_connected: mostConnected,
}, null, 2));

// Build inlined data bundle for the universe page
const bundle = {
  words: words.map(w => ({ name: w.h1, tema: w.tema, file: w.file })),
  links: wordsData,                       // name -> linked names (display)
  temaList: themes,
  wordDetails,
  aliases: redirectAliasDetails,
  dangling: [...danglingSet].sort(),
  stats: {
    words: words.length,
    relations,
    most_connected: mostConnected,
    most_connected_degree: degree[mostConnected],
    top: sortedByDegree.slice(0, 12),
    tied,
    themes: themes.length,
  },
};

fs.writeFileSync('tmp/bundle.json', JSON.stringify(bundle));

console.log('words:', words.length);
console.log('relations:', relations);
console.log('most_connected:', mostConnected, 'degree', degree[mostConnected], 'tied:', tied);
console.log('themes:', themes.length, themes.join(', '));
console.log('dangling:', [...danglingSet].sort());
console.log('aliases:', JSON.stringify(redirectAliasDetails));
console.log('sample saudade:', JSON.stringify(wordDetails['saudade'], (k, v) => v, 2));
