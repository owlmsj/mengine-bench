const fs = require('fs');
const data = fs.readFileSync('tmp/bundle.json', 'utf8');
let tpl = fs.readFileSync('tmp/template.html', 'utf8');
if (tpl.includes('%%DATA%%')) {
  tpl = tpl.replace('%%DATA%%', () => data);
} else if (tpl.includes('%%DATA%%')) { // String.replace with $## patterns; use function above instead
}
// safety: if data contains '</script>' it breaks; guard
if (data.includes('</script>')) { console.error('DATA CONTA SCRIPT, ABORTANDO'); process.exit(1); }
fs.writeFileSync('universe/index.html', tpl);
console.log('written universe/index.html', tpl.length, 'bytes');
