# Convert lab values: all in units of the first report (laudo_alfa, 10/02/2026, mg/dL style)
# First report (Alfa, 10/02/2026), reference ranges in own units:
first = {
    "glicose": {"date": "2026-02-10", "value": 92, "ref": (70, 99), "units": "mg/dL"},
    "ldl": {"date": "2026-02-10", "value": 118, "ref": (None, 130), "units": "mg/dL"},  # < 130 desirable
    "creatinina": {"date": "2026-02-10", "value": 0.95, "ref": (0.70, 1.30), "units": "mg/dL"},
    "hba1c": {"date": "2026-02-10", "value": 5.4, "ref": (4.0, 5.6), "units": "%"},
}
# Second report (Beta, 18/08/2026): mmol/L (glucose, LDL), umol/L (creatinine), mmol/mol (HbA1c)
second_raw = {
    "glicose": 6.1,      # mmol/L glucose
    "ldl": 3.70,          # mmol/L cholesterol
    "creatinina": 76,     # umol/L
    "hba1c": 37,           # mmol/mol IFCC
}
conv = {
    "glicose": 18.0182,   # mg/dL per mmol/L (MW 180.16 g/mol)
    "ldl": 38.67,          # mg/dL per mmol/L (cholesterol MW 386.68 g/mol)
    "creatinina": 0.0113,  # mg/dL per umol/L (MW 113.12 g/mol)
    "hba1c": 0.09,         # % per mmol/mol (approx; IFCC mmol/mol / 10.929 = %)
}
def hba1c_pct(v):  # better IFCC formula
    return round(0.0239 * v + 4.0939, 2)

for m, raw in second_raw.items():
    v = conv[m] * raw
    if m == "hba1c":
        v = hba1c_pct(raw)
    first[m]["history"] = {first[m]["date"]: first[m]["value"], "2026-08-18": round(v, 2)}

# Worse = marker worsened (second > first for all these markers) AND second now outside
# the FIRST report's reference range
worse = []
for m in first:
    f, s = first[m]["value"], first[m]["history"]["2026-08-18"]
    lo, hi = first[m]["ref"]
    outside = (s > hi) if lo is None else (s < lo or s > hi)  # LDL: only upper bound (desirable <130)
    got_worse = s > f
    print(m, f, "->", s, "worse" if got_worse else "better", "outside-first-ref" if outside else "inside")
    if got_worse and outside:
        worse.append(m)

result = {
    "history": {m: first[m]["history"] for m in first},
    "worse": worse,
}
import json
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
print(json.dumps(result, indent=2))
