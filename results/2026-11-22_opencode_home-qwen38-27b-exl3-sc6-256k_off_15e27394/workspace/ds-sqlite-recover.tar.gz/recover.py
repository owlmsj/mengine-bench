#!/usr/bin/env python3
"""Recover rows from corrupted SQLite file by scanning for valid record cells."""
import json, struct

data = open("prices.db", "rb").read()
n = len(data)
print("size:", n)

def varint(buf, pos):
    """Read SQLite varint (7 bits per byte, little-endian bit order)."""
    result = 0
    for i in range(9):
        if pos >= len(buf):
            raise ValueError
        b = buf[pos]
        pos += 1
        if i < 8:
            result = (result << 7) | (b & 0x7F)
        else:
            result = (result << 8) | b
        if not (b & 0x80):
            break
    return result, pos

def parse_record(buf, pos):
    """Parse a SQLite record. Returns (col_types, values, end_pos)."""
    serial, pos = varint(buf, pos)
    # Determine column count
    if serial < 12:
        ncols = serial // 2
    else:
        # For serial >= 12: ncols = (serial - 12) // 2 + 1? 
        # Actually from SQLite docs: for serial_type >= 12,
        # the number of columns is (serial_type - 12) // 2 + 1
        # Wait no. Let me use the actual rule:
        # serial_type S:
        #   if S < 12: ncols = S // 2
        #   if S >= 12: 
        #     if S is even (blob): ncols = (S - 12) // 2 + 1  -> no
        # The real rule: S encodes ncols in bits 0-4 for small values,
        # and for S >= 12, the high bits encode ncols differently.
        # From SQLite source (vdbe.c, memStack):
        #   ncols = pRecord->nField
        #   The serial_type is stored separately.
        # For our 2-column table, let's just assume ncols=2 when serial>=12.
        ncols = 2
    values = []
    # First column type is encoded in serial
    # Subsequent columns: their types are in the serial's bit pattern
    # For serial < 12:
    #   col0 type = serial (0-11)
    #   col1 type = serial // 2? No.
    # The actual encoding: serial_type is a single number that encodes
    # the types of ALL columns. For 2 columns:
    #   serial_type = type0 * K + type1? No, it's bit-packed.
    # From the file format spec:
    #   "The serial type is a variable-length integer. The serial type
    #    encodes the number of columns and the type of the first column.
    #    The types of subsequent columns are determined by the serial type."
    #   Specifically:
    #   For serial_type S < 12:
    #     ncols = S // 2
    #     col[i] type = S // (2**(i+1))? No.
    # I think the correct interpretation is:
    #   S = 0: 0 cols
    #   S = 1: 1 col, type=1 (1-byte int? no, type 1 = 0-byte int val 0)
    #   S = 2: 1 col, type=2
    #   S = 3: 1 col, type=3
    #   S = 4: 2 cols, col0 type=0, col1 type=2? 
    # This is getting too speculative. Let me use the actual algorithm:
    # 
    # From SQLite source code (btree.c, sqlite3BtreeNew / record decoding):
    # The serial type S:
    #   if S == 0: no columns
    #   if 1 <= S <= 11:
    #     ncols = S // 2 + 1  (S=1->1col, S=2->2cols, S=3->2cols, S=4->3cols...)
    #     Wait: S=1: 1 col (type 1), S=2: 1 col (type 2)? 
    # 
    # OK let me just use the well-known rule:
    #   S in [0,11]: ncols = S // 2, col types from S
    #   S in [12,127]: text/blob, ncols from high bits
    #   S >= 128: extended
    # 
    # For simplicity, since we expect 2 columns (item TEXT, price numeric):
    # The serial type for 2 cols with col0=TEXT(len L), col1=INT:
    #   L = text length
    #   S = 13 + 2*L  (for odd, text)
    #   Then col1 type follows in the next byte? No, col1 type is also in S.
    # 
    # Actually the real rule (from https://www.sqlite.org/fileformat.html#record_format):
    #   "The record format encodes all column values in a single byte string.
    #    The first field of the record is a variable-length integer that 
    #    specifies the serial type. The serial type encodes both the number 
    #    of columns and the storage format of each column."
    #   
    #   Serial type S:
    #   - 0: 0 columns
    #   - 1: 1 column, 0-byte integer (value 0)
    #   - 2: 1 column, 1-byte integer
    #   - 3: 1 column, 2-byte integer
    #   - 4: 2 columns, both 0-byte? 
    #   This doesn't seem right either.
    #
    # Let me just look at the actual hex data and reverse-engineer.
    # For a 2-column table with item TEXT and price REAL/INTEGER:
    # The serial type should be:
    #   If price is REAL (8-byte float): 
    #     col0 = TEXT (varies), col1 = REAL (type 8)
    #     S = ? 
    #   If price is INTEGER (say 4-byte):
    #     col0 = TEXT, col1 = 4-byte int (type 5)
    #     S = ?
    #
    # I'll just try to parse assuming:
    #   serial_type varint, then:
    #   col0: TEXT of length (S-13)//2 if S is odd and >=13
    #   col1: depends on what follows
    # And see if the parsed item looks like a word.
    
    if serial < 12:
        # ncols = serial // 2
        ncols = serial // 2
        # col0 type = serial (for serial 0-11)
        # For serial in 1-7: integer of (serial-1) bytes? 
        # type 1: 0 bytes (val 0), type 2: 1 byte, type 3: 2 bytes,
        # type 4: 3 bytes, type 5: 4 bytes, type 6: 6 bytes, type 7: 8 bytes
        # type 8: 8-byte float, type 9: 0 (0 bytes), type 10: 1 (0 bytes)
        # type 0: NULL
        col0_type = serial
        if col0_type == 0:
            values.append(None)
        elif col0_type == 8:
            values.append(struct.unpack(">d", buf[pos:pos+8])[0]); pos += 8
        elif col0_type == 9:
            values.append(0)
        elif col0_type == 10:
            values.append(1)
        elif 1 <= col0_type <= 7:
            ln = col0_type - 1
            values.append(int.from_bytes(buf[pos:pos+ln], "big", signed=True)); pos += ln
        else:
            return None
        # col1: type is encoded in serial too
        # For serial < 12, col1 type = ? 
        # I think for S < 12: col0 type = S, col1 type = S//2? No.
        # Let's just try: if ncols >= 2, col1 type = serial // 2
        if ncols >= 2:
            col1_type = serial // 2
            if col1_type == 0:
                values.append(None)
            elif col1_type == 8:
                values.append(struct.unpack(">d", buf[pos:pos+8])[0]); pos += 8
            elif col1_type == 9:
                values.append(0)
            elif col1_type == 10:
                values.append(1)
            elif 1 <= col1_type <= 7:
                ln = col1_type - 1
                values.append(int.from_bytes(buf[pos:pos+ln], "big", signed=True)); pos += ln
            else:
                return None
    else:
        # serial >= 12: first column is TEXT or BLOB
        if serial % 2 == 1:  # odd -> TEXT
            text_len = (serial - 13) // 2
        else:  # even -> BLOB
            text_len = (serial - 12) // 2
        if text_len > 10000 or pos + text_len > n:
            return None
        item_bytes = buf[pos:pos+text_len]
        pos += text_len
        # Check if it looks like printable text
        try:
            item = item_bytes.decode('utf-8')
        except:
            return None
        if not item or not all(32 <= c < 127 for c in item):
            return None
        values.append(item)
        # Now parse price: try common types
        # The price type is encoded in the serial too (high bits)
        # For serial >= 12 and < 128: 
        #   ncols = ? 
        # Let's just try to read the next value as int or float
        # Try 8-byte float first (most common for prices)
        if pos + 8 <= n:
            price = struct.unpack(">d", buf[pos:pos+8])[0]
            values.append(price)
            pos += 8
        # Also try small ints
        for int_len in (1, 2, 3, 4, 6, 8):
            if pos + int_len <= n:
                pass  # already tried float8
    return values, pos

# Strategy: scan every byte offset, try to parse a record there
# A valid record for our table: item TEXT + price (int or float)
results = []
seen = set()
for start in range(n - 4):
    try:
        parsed = parse_record(data, start)
    except:
        continue
    if parsed is None:
        continue
    values, end = parsed
    if len(values) != 2:
        continue
    item, price = values
    if not isinstance(item, str) or not item.strip():
        continue
    if not isinstance(price, (int, float)):
        continue
    if isinstance(price, float) and (price != price or price < 0 or price > 1000000):
        continue
    if isinstance(price, int) and (price < 0 or price > 100000000):
        continue
    key = (item, price)
    if key not in seen:
        seen.add(key)
        results.append({"item": item, "price": price, "offset": start})

print(f"Found {len(results)} candidate rows:")
for r in results:
    print(f"  offset={r['offset']:4d} item={r['item']!r} price={r['price']}")

# Write best-effort output
out = [{"item": r["item"], "price": r["price"]} for r in results]
with open("recovered.json", "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2, ensure_ascii=False)
print(f"Wrote {len(out)} rows to recovered.json")
