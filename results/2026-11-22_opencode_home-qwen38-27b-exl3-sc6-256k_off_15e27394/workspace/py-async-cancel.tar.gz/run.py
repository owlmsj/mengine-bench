"""Helper for batch scripts: run async callables with bounded concurrency.

Usage:
    from run import run_tasks

    await run_tasks([job1, job2, ...], max_concurrent=4)

Each task is a zero-argument callable that returns an awaitable job.
At most ``max_concurrent`` jobs run at the same time.
"""

import asyncio


async def run_tasks(tasks, max_concurrent):
    """Run all tasks, at most ``max_concurrent`` concurrent jobs.

    Returns when every job is done. If the user hits Ctrl+C, the running
    jobs are cancelled so their cleanup code (``finally`` / ``CancelledError``
    handlers) runs; run_tasks then re-raises the KeyboardInterrupt.

    Args:
        tasks: iterable of zero-argument callables returning awaitables.
        max_concurrent: int >= 1; bound on the number of running jobs.

    Returns:
        list of results, one per task, in input order.

    Raises:
        ValueError: if max_concurrent < 1.
    """
    if max_concurrent < 1:
        raise ValueError("max_concurrent must be >= 1, got %r" % (max_concurrent,))

    sem = asyncio.Semaphore(max_concurrent)
    results = [None] * len(tasks)

    async def _wrap(index, task):
        async with sem:
            results[index] = await task()

    try:
        await asyncio.gather(*[_wrap(i, t) for i, t in enumerate(tasks)])
    except (KeyboardInterrupt, asyncio.CancelledError):
        # Ctrl+C: let in-flight jobs run their cleanup, then surface the
        # interrupt so the caller can shut down.
        raise

    return results
