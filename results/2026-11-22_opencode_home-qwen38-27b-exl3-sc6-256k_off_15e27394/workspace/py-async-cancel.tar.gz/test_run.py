import asyncio
import sys
from run import run_tasks

# Test 1: basic results + ordering
async def t1():
    async def job(i):
        await asyncio.sleep(0.01 * i)
        return i * 2
    res = await run_tasks([lambda i=i: job(i) for i in range(5)], 3)
    assert res == [0, 2, 4, 6, 8], res
    print("t1 ok: results", res)

# Test 2: concurrency bound
async def t2():
    running = 0
    peak = 0
    async def job():
        nonlocal running, peak
        running += 1
        peak = max(peak, running)
        await asyncio.sleep(0.05)
        running -= 1
    await run_tasks([lambda: job() for _ in range(8)], 3)
    assert peak <= 3, peak
    assert peak == 3, peak  # with 8 jobs of 0.05s and bound 3, bound is hit
    print("t2 ok: peak", peak)

# Test 3: max_concurrent=1 sequential
async def t3():
    order = []
    async def job(i):
        order.append(("start", i))
        await asyncio.sleep(0.01)
        order.append(("end", i))
        return i
    await run_tasks([lambda i=i: job(i) for i in range(3)], 1)
    assert order == [("start",0),("end",0),("start",1),("end",1),("start",2),("end",2)], order
    print("t3 ok: order", order)

# Test 4: ValueError
async def t4():
    try:
        await run_tasks([], 0)
    except ValueError:
        print("t4 ok: ValueError raised")
    else:
        raise AssertionError("no ValueError")

# Test 5: Ctrl+C -> jobs' cleanup (finally) runs
async def t5():
    cleaned = []
    async def job():
        try:
            await asyncio.sleep(30)
        except asyncio.CancelledError:
            cleaned.append(1)
            raise
    tasks = [lambda: job() for _ in range(3)]
    try:
        # simulate Ctrl+C by cancelling the run_tasks task itself
        coro = run_tasks(tasks, 3)
        task = asyncio.ensure_future(coro)
        await asyncio.sleep(0.05)
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
    except BaseException:
        pass
    await asyncio.sleep(0)
    assert len(cleaned) == 3, cleaned
    print("t5 ok: cleaned", cleaned)

async def main():
    await t1(); await t2(); await t3(); await t4(); await t5()
    print("ALL OK")

asyncio.run(main())
