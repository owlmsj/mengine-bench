$ErrorActionPreference = "Stop"
$site = Join-Path $PSScriptRoot "site"
$files = Get-ChildItem -Path $site -Filter *.html
$words = @{}
foreach ($f in $files) {
    $name = [IO.Path]::GetFileNameWithoutExtension($f.Name)
    if ($name -eq "index" -or $name -eq "sobre" -or $name -eq "contato") { continue }
    $content = [IO.File]::ReadAllText($f.FullName)
    # get display text from h1
    $h1 = [regex]::Match($content, '<h1>([^<]*)</h1>')
    $display = $h1.Success ? $h1.Groups[1].Value.Trim() : $name
    # synonyms
    $syn = @()
    $m = [regex]::Match($content, '<section id="sinonimos">.*?<ul>(.*?)</ul>', [System.Text.RegularExpressions.RegexOptions]::Singleline)
    if ($m.Success) { $syn = [regex]::Matches($m.Groups[1].Value, '<a href="([^"]+)">') | ForEach-Object { $_.Groups[1].Value } }
    # analogous
    $ana = @()
    $m = [regex]::Match($content, '<section id="analogas">.*?<ul>(.*?)</ul>', [System.Text.RegularExpressions.RegexOptions]::Singleline)
    if ($m.Success) { $ana = [regex]::Matches($m.Groups[1].Value, '<a href="([^"]+)">') | ForEach-Object { $_.Groups[1].Value } }
    $words[$name] = @{ display=$display; synonyms=@($syn); analogous=@($ana) }
}
$out = @{ words=$words }
$json = $out | ConvertTo-Json -Depth 5
$dir = Join-Path $PSScriptRoot "tmp"
New-Item -ItemType Directory -Force -Path $dir | Out-Null
[IO.File]::WriteAllText((Join-Path $dir "words_raw.json"), $json)
Write-Host "Words: $($words.Count)"
