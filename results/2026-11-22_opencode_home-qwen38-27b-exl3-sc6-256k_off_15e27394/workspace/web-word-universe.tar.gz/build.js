import { readFileSync, writeFileSync, mkdirSync } from "fs";
import { fileURLToPath } from "url";

const raw = JSON.parse(readFileSync(new URL("./tmp/words_raw.json", import.meta.url), "utf8"));

// read display from raw words
const rawWords = raw.words;
const names = Object.keys(rawWords);

// helper: normalize key = lowercase + strip accents
function norm(s){ return s.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase(); }
function displayOf(name){ return rawWords[name]?.display ?? name; }

// Build mapping: normalized key -> canonical raw name (first occurrence)
const canon = {};
for (const n of names){
  const k = norm(n);
  if (!canon[k]) canon[k] = n;
}

// For each link (href like "foo.html"), resolve to canonical name or null if broken
function resolveLink(href){
  if (!href || href.endsWith(".html") === false) {
    // href without .html
  }
  let base = href.replace(/\.html$/,"");
  // decode
  base = decodeURIComponent(base);
  const k = norm(base);
  if (canon[k]) return canon[k];
  return null; // broken
}

// Build words.json: key = normalized word, value = array of normalized linked words
const wordsJson = {};
for (const n of names){
  const k = norm(n);
  const linked = new Set();
  for (const h of (rawWords[n].synonyms||[])) {
    const c = resolveLink(h);
    if (c) linked.add(norm(c));
  }
  for (const h of (rawWords[n].analogous||[])) {
    const c = resolveLink(h);
    if (c) linked.add(norm(c));
  }
  wordsJson[k] = [...linked].sort();
}

// Count distinct pairs
const pairSet = new Set();
for (const [a, arr] of Object.entries(wordsJson)){
  for (const b of arr){
    if (a === b) continue;
    const pair = [a,b].sort().join("\u0001");
    pairSet.add(pair);
  }
}

// Degree
const deg = {};
for (const [a, arr] of Object.entries(wordsJson)){
  for (const b of arr){
    deg[a]=(deg[a]||0)+1;
    deg[b]=(deg[b]||0)+1;
  }
}
let max=-1, most=[];
for (const [w,d] of Object.entries(deg)){ if(d>max){max=d;most=[w];} else if(d===max){most.push(w);} }
most.sort();

const result = {
  words: Object.keys(wordsJson).length,
  relations: pairSet.size,
  most_connected: { word: most[0], degree: max }
};

mkdirSync(fileURLToPath(new URL("./universe/", import.meta.url)), { recursive: true });
writeFileSync(fileURLToPath(new URL("./words.json", import.meta.url)), JSON.stringify(wordsJson, null, 2));
writeFileSync(fileURLToPath(new URL("./result.json", import.meta.url)), JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
console.log("most connected:", most.join(","));
