import { readFileSync, writeFileSync } from "fs";
import { fileURLToPath } from "url";

const words = JSON.parse(readFileSync(fileURLToPath(new URL("./words.json", import.meta.url)), "utf8"));

// build adjacency for a nicer graph: keep only pairs where both exist in words
const nodes = Object.keys(words);
const links = [];
const seen = new Set();
for (const [a, arr] of Object.entries(words)) {
  for (const b of arr) {
    if (a === b || !words[b]) continue;
    const key = a < b ? a + "|" + b : b + "|" + a;
    if (seen.has(key)) continue;
    seen.add(key);
    links.push([a, b]);
  }
}

// degree
const deg = {};
for (const [a, b] of links) { deg[a]=(deg[a]||0)+1; deg[b]=(deg[b]||0)+1; }

const html = `<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Universo de Palavras</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,300;9..144,500;9..144,700&family=Space+Grotesk:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root{
  --bg:#0b0e1a; --ink:#eef1ff; --dim:#8b93b5; --acc:#ffb4a2; --acc2:#a7c7ff;
  --card:rgba(255,255,255,.045); --line:rgba(255,255,255,.09);
}
*{box-sizing:border-box}
html,body{margin:0;height:100%;overflow:hidden;background:var(--bg);color:var(--ink);
  font-family:'Space Grotesk',system-ui,sans-serif}
#scene{position:fixed;inset:0}
#scene canvas{display:block}
#hud{position:fixed;inset:0;pointer-events:none;z-index:5}
#top{position:absolute;top:0;left:0;right:0;padding:18px 22px;display:flex;gap:14px;align-items:center;
  pointer-events:none}
#brand{font-family:'Fraunces',serif;font-weight:700;font-size:20px;letter-spacing:.5px;
  color:var(--ink);text-shadow:0 2px 20px rgba(0,0,0,.6)}
#brand small{display:block;font-family:'Space Grotesk';font-weight:400;font-size:11px;color:var(--dim);letter-spacing:.2px}
#search{pointer-events:auto;flex:1;max-width:520px;margin-left:auto}
#q{width:100%;background:var(--card);border:1px solid var(--line);color:var(--ink);
  border-radius:999px;padding:11px 18px;font:500 15px 'Space Grotesk';outline:none;backdrop-filter:blur(8px);
  transition:border-color .2s, box-shadow .2s}
#q::placeholder{color:var(--dim)}
#q:focus{border-color:var(--acc2);box-shadow:0 0 0 3px rgba(167,199,255,.18)}
#drop{position:absolute;top:64px;left:auto;right:22px;width:520px;max-height:60vh;overflow:auto;
  background:#11142a;border:1px solid var(--line);border-radius:14px;box-shadow:0 18px 60px rgba(0,0,0,.55);
  backdrop-filter:blur(14px);display:none}
#drop div{padding:11px 18px;cursor:pointer;font-size:14px;display:flex;justify-content:space-between;gap:10px}
#drop div:hover,#drop div.on{background:rgba(255,255,255,.07)}
#drop .d{color:var(--dim);font-size:12px}
#panel{position:absolute;top:76px;right:22px;width:340px;max-height:calc(100% - 110px);overflow:auto;
  background:#101326cc;border:1px solid var(--line);border-radius:16px;backdrop-filter:blur(14px);
  padding:18px 18px 16px;box-shadow:0 18px 60px rgba(0,0,0,.5);pointer-events:auto}
#panel h1{font-family:'Fraunces',serif;font-weight:700;font-size:30px;margin:0 0 2px}
#panel .sub{color:var(--dim);font-size:12px;margin:0 0 12px}
#panel .chips{display:flex;flex-wrap:wrap;gap:7px;margin:8px 0}
.chip{background:var(--card);border:1px solid var(--line);border-radius:999px;padding:5px 12px;
  font-size:13px;cursor:pointer;transition:.15s}
.chip:hover{border-color:var(--acc2);transform:translateY(-1px)}
.chip.here{background:var(--acc);color:#2a1206;border-color:var(--acc);font-weight:600}
#deg{font-size:13px;color:var(--dim);margin:6px 0 14px}
#deg b{color:var(--ink);font-size:16px;font-family:'Fraunces'}
.sec{font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--dim);margin:14px 0 7px;
  font-weight:600}
#hint{position:absolute;bottom:18px;left:22px;color:var(--dim);font-size:12px;
  background:rgba(11,14,26,.55);padding:6px 12px;border-radius:10px;backdrop-filter:blur(6px)}
#stats{position:absolute;bottom:18px;right:22px;color:var(--dim);font-size:12px;
  background:rgba(11,14,26,.55);padding:6px 12px;border-radius:10px;backdrop-filter:blur(6px)}
#stats b{color:var(--ink)}
@media (max-width:720px){#panel{width:calc(100% - 44px)}#drop{width:calc(100% - 44px);right:22px}}
</style></head>
<body>
<div id="scene"></div>
<div id="hud">
  <div id="top">
    <div id="brand">Universo de Palavras<small>Dicionário Criativo</small></div>
    <div id="search"><input id="q" placeholder="Busque uma palavra…" autocomplete="off" spellcheck="false">
      <div id="drop"></div></div>
  </div>
  <aside id="panel" style="display:none">
    <h1 id="pw"></h1>
    <p class="sub" id="psub"></p>
    <div id="deg"></div>
    <div class="sec">Relacionadas</div>
    <div class="chips" id="chips"></div>
  </aside>
  <div id="hint">Clique numa palavra · arraste para girar · role para zoom</div>
  <div id="stats"></div>
</div>
<script type="module">
const WORDS = ${JSON.stringify(words)};
const DEGS = ${JSON.stringify(deg)};
const THREE_URL = "https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js";
const $ = (s)=>document.querySelector(s);
let THREE, ready=false;
import(THREE_URL).then(T=>{THREE=T; ready=true; start();}).catch(e=>fallback(e));

// deterministic layout: force-directed in 3D, seeded
const nodes = Object.keys(WORDS);
const idx = {}; nodes.forEach((n,i)=>idx[n]=i);
const N = nodes.length;
const pos = new Float32Array(N*3);
const vel = new Float32Array(N*3);
// seed
let s=42; const rnd=()=>{ s=(s*1103515245+12345)&0x7fffffff; return s/0x7fffffff; };
for(let i=0;i<N;i++){ pos[i*3]=(rnd()-.5)*40; pos[i*3+1]=(rnd()-.5)*40; pos[i*3+2]=(rnd()-.5)*40; }
const edges=[];
for(const [a,arr] of Object.entries(WORDS)){ for(const b of arr){ if(a===b||!idx[b])continue; edges.push([idx[a],idx[b]]); } }

function simulate(){
  for(let iter=0;iter<160;iter++){
    for(let i=0;i<N;i++) for(let j=i+1;j<N;j++){
      const dx=pos[i*3]-pos[j*3], dy=pos[i*3+1]-pos[j*3+1], dz=pos[i*3+2]-pos[j*3+2];
      let d2=dx*dx+dy*dy+dz*dz+0.01; let f=0.06/d2;
      vel[i*3]+=dx*f; vel[i*3+1]+=dy*f; vel[i*3+2]+=dz*f;
      vel[j*3]-=dx*f; vel[j*3+1]-=dy*f; vel[j*3+2]-=dz*f;
    }
    for(const [a,b] of edges){
      const dx=pos[a*3]-pos[b*3], dy=pos[a*3+1]-pos[b*3+1], dz=pos[a*3+2]-pos[b*3+2];
      const d=Math.sqrt(dx*dx+dy*dy+dz*dz)+0.01; const f=(d-4)*0.02;
      vel[a*3]-=dx/d*f; vel[a*3+1]-=dy/d*f; vel[a*3+2]-=dz/d*f;
      vel[b*3]+=dx/d*f; vel[b*3+1]+=dy/d*f; vel[b*3+2]+=dz/d*f;
    }
    for(let i=0;i<N;i++){
      vel[i*3]-=pos[i*3]*0.008; vel[i*3+1]-=pos[i*3+1]*0.008; vel[i*3+2]-=pos[i*3+2]*0.008;
      vel[i*3]*=0.85; vel[i*3+1]*=0.85; vel[i*3+2]*=0.85;
      pos[i*3]+=vel[i*3]; pos[i*3+1]+=vel[i*3+1]; pos[i*3+2]+=vel[i*3+2];
    }
  }
}
simulate();

function start(){
  const scene=new THREE.Scene(); scene.fog=new THREE.FogExp2(0x0b0e1a,0.011);
  const camera=new THREE.PerspectiveCamera(60,innerWidth/innerHeight,0.1,500);
  camera.position.set(0,0,60);
  const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true});
  renderer.setSize(innerWidth,innerHeight); renderer.setPixelRatio(Math.min(devicePixelRatio,2));
  document.getElementById('scene').appendChild(renderer.domElement);
  scene.add(new THREE.AmbientLight(0xffffff,0.7));
  const dl=new THREE.DirectionalLight(0xffffff,0.6); dl.position.set(20,30,20); scene.add(dl);

  // nodes
  const maxDeg=Math.max(...Object.values(DEGS),1);
  const geo=new THREE.SphereGeometry(1,16,16);
  const group=new THREE.Group();
  const meshes=[];
  nodes.forEach((n,i)=>{
    const d=DEGS[n]||0; const r=0.5+2.4*(d/maxDeg);
    const mat=new THREE.MeshStandardMaterial({color:0x9db4ff,emissive:0x000000,roughness:.5,metalness:.15,transparent:true,opacity:.9});
    const m=new THREE.Mesh(geo,mat); m.scale.setScalar(r);
    m.position.set(pos[i*3],pos[i*3+1],pos[i*3+2]);
    m.userData={name:n,base:0x9db4ff,r}; group.add(m); meshes.push(m);
  });
  scene.add(group);

  // links
  const seenPair=new Set(); const linkSegs=[];
  for(const [a,b] of edges){ const k=a<b?a+'_'+b:b+'_'+a; if(seenPair.has(k))continue; seenPair.add(k);
    linkSegs.push([pos[a*3],pos[a*3+1],pos[a*3+2],pos[b*3],pos[b*3+1],pos[b*3+2]]); }
  const lgeo=new THREE.BufferGeometry();
  const lpos=new Float32Array(linkSegs.length*6);
  linkSegs.forEach((s,i)=>{ for(let k=0;k<6;k++) lpos[i*6+k]=s[k]; });
  lgeo.setAttribute('position',new THREE.BufferAttribute(lpos,3));
  const lmat=new THREE.LineBasicMaterial({color:0x3a4a8a,transparent:true,opacity:.35});
  const lines=new THREE.LineSegments(lgeo,lmat); scene.add(lines);

  // labels for top words
  const labelGroup=new THREE.Group(); scene.add(labelGroup);
  const top=nodes.slice().sort((a,b)=>(DEGS[b]||0)-(DEGS[a]||0)).slice(0,18);
  const labelMeshes=new Map();
  for(const n of top){
    const c=document.createElement('canvas'); const x=c.getContext('2d');
    c.width=512; c.height=96; x.font='600 48px "Space Grotesk",sans-serif';
    x.textAlign='center'; x.textBaseline='middle'; x.fillStyle='#eef1ff';
    x.shadowColor='rgba(0,0,0,.8)'; x.shadowBlur=8; x.fillText(n,256,48);
    const t=new THREE.CanvasTexture(c);
    const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:t,transparent:true,opacity:.9}));
    const i=idx[n]; sp.scale.set(10,2,1); sp.position.set(pos[i*3],pos[i*3+1]+ ( (DEGS[n]||0)/maxDeg*2.4+0.5)+2, pos[i*3+2]);
    labelGroup.add(sp); labelMeshes.set(n,sp);
  }

  // interaction
  const ray=new THREE.Raycaster(); const mouse=new THREE.Vector2();
  let selected=null, hovered=null;
  const panel=$('#panel');
  function neighbors(n){ return new Set(WORDS[n]||[]); }
  function select(n){
    selected=n;
    const nb=neighbors(n);
    meshes.forEach(m=>{
      const on = m.userData.name===n || nb.has(m.userData.name);
      m.material.color.set(on? 0xffc9b8 : 0x46507f);
      m.material.emissive.set(n===m.userData.name? 0x663311 : 0x000000);
      m.material.opacity = on?1:.28;
    });
    // highlight labels
    labelMeshes.forEach((sp,k)=>{ sp.material.opacity = (k===n||nb.has(k))? .95 : .15; });
    // panel
    $('#pw').textContent=n;
    $('#psub').textContent = 'palavra · ' + (DEGS[n]||0) + ' ligações';
    $('#deg').innerHTML='Conecta-se a <b>'+(DEGS[n]||0)+'</b> palavra(s) neste universo.';
    const chips=$('#chips'); chips.innerHTML='';
    (WORDS[n]||[]).filter(w=>WORDS[w]).sort().forEach(w=>{
      const c=document.createElement('span'); c.className='chip'; c.textContent=w;
      c.onclick=(e)=>{e.stopPropagation(); select(w);}; chips.appendChild(c);
    });
    panel.style.display='block';
    history.replaceState(null,'','?word='+encodeURIComponent(n));
  }
  function clearSel(){
    selected=null; meshes.forEach(m=>{ m.material.color.set(0x9db4ff); m.material.emissive.set(0x000000); m.material.opacity=.9; });
    labelMeshes.forEach(sp=>sp.material.opacity=.9);
    panel.style.display='none';
    if(location.search.length>1) history.replaceState(null,'',location.pathname);
  }
  function pick(ev){
    mouse.x=(ev.clientX/innerWidth)*2-1; mouse.y=-(ev.clientY/innerHeight)*2+1;
    ray.setFromCamera(mouse,camera);
    const hit=ray.intersectObjects(meshes,false)[0];
    return hit? hit.object.userData.name : null;
  }
  renderer.domElement.addEventListener('pointermove',(e)=>{ hovered=pick(e); renderer.domElement.style.cursor=hovered?'pointer':'grab'; });
  renderer.domElement.addEventListener('click',(e)=>{ const n=pick(e); if(n) select(n); else clearSel(); });

  // orbit
  let th=0, ph=0.3, dist=60, dragging=false, lx=0,ly=0;
  renderer.domElement.addEventListener('pointerdown',e=>{dragging=true;lx=e.clientX;ly=e.clientY;});
  addEventListener('pointerup',()=>dragging=false);
  addEventListener('pointermove',e=>{ if(!dragging)return; th+=(e.clientX-lx)*0.005; ph+=(e.clientY-ly)*0.005; ph=Math.max(-1.4,Math.min(1.4,ph)); lx=e.clientX;ly=e.clientY; });
  addEventListener('wheel',e=>{ dist=Math.max(15,Math.min(160,dist+e.deltaY*0.05)); },{passive:true});

  // stats
  const wordCount=nodes.length;
  const pairSet=new Set(); for(const [a,b] of edges){ const k=a<b?a+'|'+b:b+'|'+a; pairSet.add(k); }
  $('#stats').innerHTML='<b>'+wordCount+'</b> palavras · <b>'+pairSet.size+'</b> relações';

  function frame(){
    if(!dragging) th+=0.0012;
    camera.position.set(dist*Math.sin(th)*Math.cos(ph), dist*Math.sin(ph), dist*Math.cos(th)*Math.cos(ph));
    camera.lookAt(0,0,0);
    renderer.render(scene,camera);
    requestAnimationFrame(frame);
  }
  frame();
  addEventListener('resize',()=>{ camera.aspect=innerWidth/innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth,innerHeight); });

  // deep link
  const w=new URLSearchParams(location.search).get('word');
  if(w && WORDS[w.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'')]) select(w.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,''));
}
function fallback(e){
  console.error('three failed', e);
  const s=$('#stats'); if(s) s.innerHTML='Three.js indisponível (offline?). Os dados continuam em words.json.';
  const q=$('#q'); if(q) q.placeholder='Busca indisponível: Three.js falhou.';
}
</script></body></html>`;

writeFileSync(fileURLToPath(new URL("./universe/index.html", import.meta.url)), html);
console.log("universe/index.html written", html.length, "bytes");
