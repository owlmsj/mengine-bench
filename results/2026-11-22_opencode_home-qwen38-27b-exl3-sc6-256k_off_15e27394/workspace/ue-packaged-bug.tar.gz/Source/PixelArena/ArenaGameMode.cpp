#include "ArenaGameMode.h"

#include "ArenaHud.h"
#include "ArenaPalette.h"
#include "ArenaScoreTracker.h"
#include "ArenaStats.h"

DEFINE_LOG_CATEGORY_STATIC(LogArena, Log, All);

void AArenaGameMode::BeginPlay()
{
	Super::BeginPlay();

	Hud = NewObject<UArenaHud>(this);
	ScoreTracker = NewObject<UArenaScoreTracker>(this);
	Stats = new FArenaStats();

	Palette = LoadObject<UArenaPalette>(nullptr, TEXT("/Game/Data/Palettes/DA_Primary.DA_Primary"));
	if (!Palette)
	{
		UE_LOG(LogArena, Warning, TEXT("Palette is null, using fallback gray"));
	}
	Hud->ApplyPalette(Palette);
}

void AArenaGameMode::EndPlay(const EEndPlayReason::Type Reason)
{
	delete Stats;
	Stats = nullptr;
	Super::EndPlay(Reason);
}

void AArenaGameMode::OnGoalScored(int32 TeamIndex)
{
	if (Stats == nullptr)
	{
		UE_LOG(LogArena, Warning, TEXT("Stats is null, ignoring goal for team %d"), TeamIndex);
		return;
	}
	Stats->Goals++;

	if (ScoreTracker == nullptr)
	{
		UE_LOG(LogArena, Warning, TEXT("ScoreTracker is null, ignoring points for team %d"), TeamIndex);
		return;
	}
	ScoreTracker->AddPoints(TeamIndex, 1);
	Hud->ShowScore(TeamIndex, ScoreTracker->GetPoints(TeamIndex));
}
