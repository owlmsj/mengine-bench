# Handoff: local-9b Q5 at 128k context

Goal: make the local 9B model run at 128k context on this GPU without spilling to system memory.

Done (all measured, not estimated):
- Baseline: `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024` → decode 37.8 t/s, VRAM 7881 MiB.
- Root cause: 7881 MiB is the WDDM ceiling; the "Shared Usage" counter showed 1494 MiB actually spilled to system memory (that counter does not count against the ceiling).
- Fix: add `--no-mmproj-offload` and `-ub 512`. Result: spill gone, final VRAM 7697 MiB, decode 38.0 t/s (median of 3 runs).
- Q6_K (7.03 GiB) does not fit at 128k — discarded. Q4_K_M fits (7305 MiB, 40.4 t/s) — kept only as fallback.
- Recipe applied in `scripts/start_server.ps1:165` (local9 block) and `profiles/local/local-9b.json`.

Left to do:
1. Evals README still cites `check_vision.ps1`, which no longer exists. Update or delete the reference.
2. Review the names of the scratchpad temp files (noted several times, never addressed).

Assumptions (transcript omits tool output, so I state what I could not verify):
- The transcript shows no git repo was initialized in this workspace; I assume the two file edits above are the only code changes and have not been committed.
- "local-9b" is the 9B model in the local profile; the exact quantization of the kept Q5 is not named in the transcript (baseline is Q5, Q6_K/Q4_K_M are the alternatives tried).
- The 128k figure is treated as 131072 tokens.

Why I trust these numbers: they were produced by the measurement script in step 30 (baseline) and step 42 (fix), each reported by the agent as a single measured run, and the fix was re-verified as the median of 3. The root cause (WDDM ceiling + Shared Usage spill) is the only explanation consistent with a 1494 MiB gap that disappears with `--no-mmproj-offload -ub 512`.
