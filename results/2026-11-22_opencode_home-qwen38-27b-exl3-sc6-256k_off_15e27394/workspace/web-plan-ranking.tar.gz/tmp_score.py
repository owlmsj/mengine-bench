from datetime import date

# launch dates (plan -> launch date)
launch = {
    "Cruzado": date(1986, 3, 1),
    "Bresser": date(1987, 1, 28),
    "Verao": date(1989, 8, 15),
    "Collor I": date(1990, 3, 15),
    "Collor II": date(1991, 3, 15),
    "Real": date(1994, 3, 1),
}
next_plan = {
    "Cruzado": "Bresser",
    "Bresser": "Verao",
    "Verao": "Collor I",
    "Collor I": "Collor II",
    "Collor II": "Real",
    "Real": None,
}
# annual IPCA by calendar year
ipca = {
    1985: 242.23,
    1986: 79.66,
    1987: 363.41,
    1988: 980.21,
    1989: 1972.91,
    1990: 1620.97,
    1991: 472.70,
    1992: 1119.10,
    1993: 2477.15,
    1994: 916.46,
    1995: 22.41,
}

def months_between(a, b):
    # whole calendar months from date a to date b
    m = (b.year - a.year) * 12 + (b.month - a.month)
    if b.day < a.day:
        m -= 1
    return m

for plan, ld in launch.items():
    y = ld.year
    nb = ipca[y - 1]
    na = ipca[y + 1]
    drop = max(0.0, min(1.0, 1 - na / nb))
    np_ = next_plan[plan]
    if np_ is None:
        months = 60
    else:
        months = months_between(ld, launch[np_])
    dur = min(months, 60) / 60
    score = 0.7 * drop + 0.3 * dur
    print(plan, y, "before", nb, "after", na, "months", months, "drop", round(drop, 4), "dur", round(dur, 4), "score", round(score, 4))
