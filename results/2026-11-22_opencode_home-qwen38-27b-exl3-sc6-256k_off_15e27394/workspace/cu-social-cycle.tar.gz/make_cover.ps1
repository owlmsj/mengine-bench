Add-Type -AssemblyName System.Drawing
$b = New-Object System.Drawing.Bitmap 1200,675
$g = [System.Drawing.Graphics]::FromImage($b)
$g.Clear([System.Drawing.Color]::White)
$font = New-Object System.Drawing.Font('Arial', 72, [System.Drawing.FontStyle]::Bold)
$g.DrawString('Harbor Day 2026', $font, [System.Drawing.Brushes]::Black, 120, 250)
$g.Dispose()
$png = Join-Path $PSScriptRoot 'cover.png'
$b.Save($png, [System.Drawing.Imaging.ImageFormat]::Png)
$b.Dispose()
Get-Item $png | Select-Object FullName, Length
