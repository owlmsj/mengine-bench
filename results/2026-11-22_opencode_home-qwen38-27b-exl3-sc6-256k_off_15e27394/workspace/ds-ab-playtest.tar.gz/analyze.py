import csv, math, json

path = r"<WORKSPACE>\telemetry\playtest_ab.csv"
rows = []
with open(path, newline='', encoding='utf-8') as f:
    r = csv.DictReader(f)
    for row in r:
        rows.append(row)

print("total rows:", len(rows))

# dedupe by session_id: ETL resends -> repeated rows are same session.
# Keep first occurrence; verify consistency of completed flag for duplicates.
seen = {}
dup_conflict = 0
dup_rows = 0
for row in rows:
    sid = row['session_id'].strip()
    v = row['variant'].strip().lower()
    c = int(row['completed_tutorial'])
    if sid in seen:
        dup_rows += 1
        if seen[sid]['completed'] != c or seen[sid]['variant'] != v:
            dup_conflict += 1
    else:
        seen[sid] = {'variant': v, 'completed': c}

sessions = list(seen.values())
print("unique sessions:", len(seen))
print("duplicate rows:", dup_rows, "conflicting dups:", dup_conflict)

# sanity: variant values
variants = set(s['variant'] for s in sessions)
print("variant values after normalize:", variants)

def stats(v):
    n = sum(1 for s in sessions if s['variant'] == v)
    comp = sum(1 for s in sessions if s['variant'] == v and s['completed'] == 1)
    return n, comp

na, ca = stats('a')
nb, cb = stats('b')
pa, pb = ca/na, cb/nb
print(f"A: n={na} completed={ca} rate={pa:.4f}")
print(f"B: n={nb} completed={cb} rate={pb:.4f}")

# two-proportion z-test, pooled
p = (ca + cb) / (na + nb)
se = math.sqrt(p * (1 - p) * (1/na + 1/nb))
z = (pb - pa) / se
# two-sided p-value via erfc
pval = math.erfc(abs(z) / math.sqrt(2))
print(f"pooled p={p:.4f} se={se:.6f} z={z:.4f} p={pval:.6f}")

# chi-squared without continuity correction as a cross-check
n = na + nb
exp_a1 = na * p; exp_a0 = na * (1 - p)
exp_b1 = nb * p; exp_b0 = nb * (1 - p)
chi2 = (ca - exp_a1)**2/exp_a1 + (na-ca - exp_a0)**2/exp_a0 + (cb - exp_b1)**2/exp_b1 + (nb-cb - exp_b0)**2/exp_b0
print(f"chi2={chi2:.4f} (should be ~ z^2={z*z:.4f})")

out = {
    "ship_b": bool(pval < 0.05 and pb > pa),
    "sessions_a": na,
    "sessions_b": nb,
    "completion_rate_a": round(pa, 4),
    "completion_rate_b": round(pb, 4),
    "p_value": round(pval, 6),
}
with open(r"<WORKSPACE>\result.json", 'w', encoding='utf-8') as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))
