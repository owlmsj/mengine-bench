"""Concurrent task runner with Ctrl+C-friendly cancellation.

Usage:
    from run import run_tasks

    async def main():
        await run_tasks([job_a, job_b, job_c], max_concurrent=2)

Each task is a zero-argument callable returning an awaitable (e.g. a
coroutine).  At most ``max_concurrent`` jobs run at once.  The function
returns when every job has finished.

Ctrl+C behaviour:  asyncio's event loop converts SIGINT into
``asyncio.CancelledError`` on the running task.  We catch it, cancel the
jobs that are still running, and wait for their ``finally`` /
``except CancelledError`` cleanup blocks to complete before re-raising.
Jobs that have not started yet are simply dropped.
"""

from __future__ import annotations

import asyncio
from typing import Awaitable, Callable, Sequence


async def run_tasks(
    tasks: Sequence[Callable[[], Awaitable[object]]],
    max_concurrent: int,
) -> None:
    """Run *tasks* with at most *max_concurrent* jobs in flight.

    Each element of *tasks* is a zero-argument callable that returns an
    awaitable.  Returns once every job has completed (successfully or
    with an exception, which is swallowed to match "returns when every
    job is done" -- individual job errors are logged to stderr).

    On Ctrl+C (CancelledError from the event loop) the in-flight jobs are
    cancelled and awaited so their cleanup code runs, then the
    CancelledError is re-raised.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent}")

    semaphore = asyncio.Semaphore(max_concurrent)
    workers: list[asyncio.Task] = []

    async def _worker(task: Callable[[], Awaitable[object]]) -> None:
        async with semaphore:
            try:
                await task()
            except asyncio.CancelledError:
                raise
            except Exception:
                # A failing job must not stop the batch.
                import sys
                print(f"job failed: {task!r}", file=sys.stderr, exc_info=True)

    for task in tasks:
        workers.append(asyncio.create_task(_worker(task)))

    try:
        await asyncio.gather(*workers)
    except asyncio.CancelledError:
        # Ctrl+C: cancel in-flight workers and let their cleanup run.
        for worker in workers:
            worker.cancel()
        await asyncio.gather(*workers, return_exceptions=True)
        raise