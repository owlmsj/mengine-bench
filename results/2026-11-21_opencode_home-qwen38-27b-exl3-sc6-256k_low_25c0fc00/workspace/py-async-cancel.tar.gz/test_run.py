import asyncio
import sys
import time
from run import run_tasks

# 1. Concurrency limit
async def test_limit():
    active = 0
    peak = 0
    def make(i):
        async def job():
            nonlocal active, peak
            active += 1
            peak = max(peak, active)
            await asyncio.sleep(0.05)
            active -= 1
        return job
    await run_tasks([make(i) for i in range(10)], max_concurrent=3)
    assert peak <= 3, f"peak {peak} > 3"
    assert peak == 3, f"peak {peak} < 3 (semaphore not used)"
    print(f"limit OK peak={peak}")

# 2. Returns when all done
async def test_done():
    done = []
    def make(i):
        async def job():
            await asyncio.sleep(0.01 * (i % 3 + 1))
            done.append(i)
        return job
    t0 = time.monotonic()
    await run_tasks([make(i) for i in range(9)], max_concurrent=2)
    assert len(done) == 9
    print(f"done OK elapsed={time.monotonic()-t0:.3f}")

# 3. Cleanup on cancel
async def test_cancel():
    cleaned = []
    def make(i):
        async def job():
            try:
                await asyncio.sleep(10)
            finally:
                cleaned.append(i)
        return job
    async def runner():
        await run_tasks([make(i) for i in range(5)], max_concurrent=2)
    task = asyncio.create_task(runner())
    await asyncio.sleep(0.1)
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass
    # in-flight (2) must have cleaned up
    assert len(cleaned) >= 2, f"only {len(cleaned)} cleaned"
    print(f"cancel OK cleaned={sorted(cleaned)}")

asyncio.run(test_limit())
asyncio.run(test_done())
asyncio.run(test_cancel())
print("ALL PASS")