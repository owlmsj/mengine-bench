import sqlite3, json
from collections import defaultdict

c = sqlite3.connect('analytics.db')
STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']

# platforms from non-test users
platforms = sorted(r[0] for r in c.execute(
    "SELECT DISTINCT platform FROM users WHERE is_test = 0"))

# first valid occurrence per user per step, only known non-test players
first = defaultdict(dict)
for uid, name, ts in c.execute(
        "SELECT user_id, name, ts FROM events WHERE name IN (%s)"
        % ','.join('?' * len(STEPS)), STEPS):
    if name not in first[uid]:
        first[uid][name] = ts

funnel = {}
biggest = {}
for p in platforms:
    users = [u for (u,) in c.execute(
        "SELECT user_id FROM users WHERE platform=? AND is_test=0", (p,))]
    counts = []
    for i, step in enumerate(STEPS):
        if i == 0:
            ok = lambda u, s=step: s in first.get(u, {})
        else:
            prev = STEPS[i - 1]
            def ok(u, s=step, pv=prev):
                f = first.get(u, {})
                return s in f and pv in f and f[s] >= f[pv]
        counts.append(sum(1 for u in users if ok(u)))
    funnel[p] = dict(zip(STEPS, counts))
    # biggest drop = step with lowest conversion (step i over step i-1)
    convs = [(counts[i] / counts[i - 1], STEPS[i])
             for i in range(1, len(STEPS)) if counts[i - 1] > 0]
    biggest[p] = min(convs, key=lambda x: x[0])[1]

result = {'funnel': funnel, 'biggest_drop': biggest}
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))