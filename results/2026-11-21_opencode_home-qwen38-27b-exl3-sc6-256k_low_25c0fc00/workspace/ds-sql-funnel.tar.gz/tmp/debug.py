import sqlite3
from collections import defaultdict
c = sqlite3.connect('analytics.db')
STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']
first = defaultdict(dict)
for uid, name, ts in c.execute(
        "SELECT user_id, name, ts FROM events WHERE name IN (?,?,?,?)", STEPS):
    if name not in first[uid]:
        first[uid][name] = ts
platforms = sorted(r[0] for r in c.execute(
    "SELECT DISTINCT platform FROM users WHERE is_test = 0"))
for p in platforms:
    users = [u for (u,) in c.execute(
        "SELECT user_id FROM users WHERE platform=? AND is_test=0", (p,))]
    for i, step in enumerate(STEPS):
        if i == 0:
            ok = lambda u, s=step: s in first.get(u, {})
        else:
            prev = STEPS[i - 1]
            def ok(u, s=step, pv=prev):
                f = first.get(u, {})
                return s in f and pv in f and f[s] >= f[pv]
        print(p, step, sum(1 for u in users if ok(u)))
    # purchases without a prior first_match
    bad = [u for u in users if 'purchase' in first.get(u, {}) and 'first_match' not in first.get(u, {})]
    print(p, 'purchase w/o first_match:', len(bad))
    # purchase before first_match
    bad2 = [u for u in users if 'purchase' in first.get(u, {}) and 'first_match' in first.get(u, {}) and first[u]['purchase'] < first[u]['first_match']]
    print(p, 'purchase before first_match:', len(bad2))
    print()