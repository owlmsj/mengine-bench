import sqlite3
c = sqlite3.connect('analytics.db')
# independent check: per platform, count users reaching each step via
# correlated subqueries on first occurrences
sql = """
WITH f AS (
  SELECT e.user_id, e.name, MIN(e.ts) ts
  FROM events e JOIN users u ON u.user_id = e.user_id
  WHERE u.is_test = 0 AND e.name IN ('install','tutorial_complete','first_match','purchase')
  GROUP BY e.user_id, e.name
)
SELECT u.platform,
  SUM(f.ts IS NOT NULL) install,
  SUM(f2.ts IS NOT NULL) tutorial,
  SUM(f3.ts IS NOT NULL AND f3.ts >= f2.ts) first_match,
  SUM(f4.ts IS NOT NULL AND f4.ts >= f3.ts) purchase
FROM users u
LEFT JOIN f ON f.user_id = u.user_id AND f.name='install'
LEFT JOIN f f2 ON f2.user_id = u.user_id AND f2.name='tutorial_complete'
LEFT JOIN f f3 ON f3.user_id = u.user_id AND f3.name='first_match'
LEFT JOIN f f4 ON f4.user_id = u.user_id AND f4.name='purchase'
WHERE u.is_test = 0
GROUP BY u.platform
"""
for r in c.execute(sql):
    print(r)
# sanity: event name spellings and unknown players
print(c.execute("SELECT DISTINCT name FROM events").fetchall())
print('events by unknown player:', c.execute(
    "SELECT COUNT(*) FROM events e LEFT JOIN users u ON u.user_id=e.user_id WHERE u.user_id IS NULL").fetchone()[0])
print('test users:', c.execute("SELECT COUNT(*) FROM users WHERE is_test=1").fetchone()[0])