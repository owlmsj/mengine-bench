import json

# First report (Alfa, 10/02/2026) values, in its own units
alfa = {
    "glicose em jejum": (92, (70, 99)),       # mg/dL
    "colesterol ldl": (118, (None, 130)),     # mg/dL, desirable < 130
    "creatinina": (0.95, (0.70, 1.30)),       # mg/dL
    "hemoglobina glicada (hba1c)": (5.4, (4.0, 5.6)),  # %
}

# Second report (Beta, 18/08/2026) values converted to alfa units
# glucose: mmol/L * 18.0156 = mg/dL
# LDL: mmol/L * 38.67 = mg/dL
# creatinine: umol/L / 88.42 = mg/dL
# HbA1c: (mmol/mol + 23.5) / 10.929 = %
beta = {
    "glicose em jejum": round(6.1 * 18.0156, 2),
    "colesterol ldl": round(3.70 * 38.67, 2),
    "creatinina": round(76 / 88.42, 2),
    "hemoglobina glicada (hba1c)": round((37 + 23.5) / 10.929, 2),
}

history = {}
for m, (v1, _) in alfa.items():
    history[m] = {"10/02/2026": v1, "18/08/2026": beta[m]}

worse = []
for m, (v1, (lo, hi)) in alfa.items():
    v2 = beta[m]
    if v2 > v1 and (hi is not None and v2 > hi or (lo is not None and v2 < lo)):
        worse.append(m)

result = {"history": history, "worse": worse}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
print(json.dumps(result, ensure_ascii=False, indent=2))