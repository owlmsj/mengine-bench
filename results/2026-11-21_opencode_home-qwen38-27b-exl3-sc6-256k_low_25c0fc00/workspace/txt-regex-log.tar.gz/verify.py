import re
pat = open('regex.txt').read().strip()
log = open('server.log').read()
print(re.findall(pat, log, re.MULTILINE))

# extra edge cases
cases = [
    ("2026-04-02 07:15:09 INFO  gateway accepted 10.12.0.7 for build 2026-04-01", ["2026-04-01"]),
    ("2026-04-02 07:15:11 INFO  cache warm, 412 keys, next sweep 2026-04-03", []),
    ("2026-04-02 07:16:40 WARN  peer 192.168.40.3 slow, retry window 2026-04-02 to 2026-04-05", ["2026-04-05"]),
    ("2026-04-02 07:18:02 INFO  job 7781-20-4410 queued by scheduler", []),
    ("2026-04-02 07:19:30 ERROR upstream 172.20.1.14 refused handshake", []),
    # bad IPs
    ("x 256.1.1.1 2026-01-01", []),
    ("x 010.1.1.1 2026-01-01", []),
    ("x 1.2.3.256 2026-01-01", []),
    # good IP, bad dates
    ("x 1.2.3.4 2026-02-30", []),
    ("x 1.2.3.4 2026-13-01", []),
    ("x 1.2.3.4 2026-04-31", []),
    ("x 1.2.3.4 2026-02-29", ["2026-02-29"]),
    ("x 1.2.3.4 2025-02-29", ["2025-02-29"]),
    # adjacency
    ("x 1.2.3.4 2026-01-015", []),
    ("x 1.2.3.4 52026-01-01", []),
    ("x 1.2.3.4 2026-01-01a", []),
    # multiple dates: last wins
    ("x 1.2.3.4 2026-01-01 2026-01-02 2026-01-03", ["2026-01-03"]),
    # IP at line start / end
    ("1.2.3.4 2026-01-01", ["2026-01-01"]),
    ("2026-01-01 1.2.3.4", ["2026-01-01"]),
    # IP with dot after (1.2.3.4.5) -> not an IP
    ("x 1.2.3.4.5 2026-01-01", []),
    # leading zero parts
    ("x 1.2.3.04 2026-01-01", []),
    # 0 allowed
    ("x 0.0.0.0 2026-01-01", ["2026-01-01"]),
    ("x 255.255.255.255 2026-01-01", ["2026-01-01"]),
]
ok = True
for line, want in cases:
    got = re.findall(pat, line, re.MULTILINE)
    if got != want:
        ok = False
        print("FAIL", repr(line), "got", got, "want", want)
print("ALL OK" if ok else "FAILURES")