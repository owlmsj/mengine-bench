import csv, statistics, json

rows = []
with open(r'capture/presentmon.csv', newline='') as f:
    for r in csv.DictReader(f):
        rows.append(r)

mbp = [float(r['MsBetweenPresents']) for r in rows]
t = [float(r['TimeInSeconds']) for r in rows]
print('frames:', len(rows))
print('capture seconds:', t[-1] - t[0])
mean = statistics.mean(mbp)
print('mean ms:', mean, '-> avg fps:', 1000/mean)
srt = sorted(mbp)
p99 = srt[int(0.99*(len(srt)-1))]
print('p99 ms:', p99, '-> 1% low fps:', 1000/p99)

# find hitch frames (> 3x median)
med = statistics.median(mbp)
hitches = [(i, t[i], mbp[i]) for i in range(len(mbp)) if mbp[i] > 3*med]
print('median ms:', med)
print('hitch count:', len(hitches))
for i, ts, ms in hitches:
    print(f'  frame {i} t={ts:.3f}s ms={ms:.2f}')

# distribution of frame time buckets
buckets = {}
for v in mbp:
    k = int(v)
    buckets[k] = buckets.get(k, 0) + 1
print('ms buckets:', dict(sorted(buckets.items())))

# dropped frames
dropped = sum(int(r['Dropped']) for r in rows)
print('dropped:', dropped)