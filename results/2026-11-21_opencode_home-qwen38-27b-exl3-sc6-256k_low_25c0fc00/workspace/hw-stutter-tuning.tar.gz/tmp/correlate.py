import csv, json

rows = list(csv.DictReader(open(r'capture/sensors.csv', newline='')))
hitch_secs = [2,6,10,14,18,22,26,30,34,38,42,46,50,54,58]
print('t  link dpc_us disk top')
for r in rows:
    t = int(r['time_s'])
    flag = ' HITCH' if t in hitch_secs else ''
    print(f"{t:2d} {r['gpu_pcie_link_state']:4s} {r['dpc_latency_us']:>6s} {r['disk_active_pct']:>4s} {r['top_cpu_process']}{flag}")

# stats
import statistics
dpc = [int(r['dpc_latency_us']) for r in rows]
print('dpc mean/max:', statistics.mean(dpc), max(dpc))
print('L1 count:', sum(1 for r in rows if r['gpu_pcie_link_state']=='L1'))
print('MsMpEng secs:', [r['time_s'] for r in rows if r['top_cpu_process']=='MsMpEng.exe'])