import json

# Annual IPCA (IBGE, calendar year, %), source: https://sidra.ibge.gov.br/tabela/1737
ipca = {
    1985: 242.23, 1986: 79.66, 1987: 363.41, 1988: 980.21,
    1989: 1972.91, 1990: 1620.97, 1991: 472.70, 1992: 1119.10,
    1993: 2477.15, 1994: 916.46, 1995: 22.41,
}

# Launch dates (day, month, year)
plans = [
    ("Cruzado",   (28, 2, 1986)),
    ("Bresser",   (12, 6, 1987)),
    ("Verao",     (15, 1, 1989)),
    ("Collor I",  (16, 3, 1990)),
    ("Collor II", (31, 1, 1991)),
    ("Real",      (1, 7, 1994)),
]

def months_between(d1, d2):
    # whole calendar months from d1 (earlier) to d2 (later); tuples are (day, month, year)
    _, m1, y1 = d1
    _, m2, y2 = d2
    return (y2 - y1) * 12 + (m2 - m1)

results = []
for i, (name, d) in enumerate(plans):
    y = d[2]
    before = ipca[y - 1]
    after = ipca[y + 1]
    drop = max(0.0, min(1.0, 1 - after / before))
    if name == "Real":
        months = 60
    else:
        months = months_between(d, plans[i + 1][1])
        print(f"DEBUG {name}: d={d} next={plans[i+1][1]} months={months}")
    dur = min(months, 60) / 60
    score = 0.7 * drop + 0.3 * dur
    results.append({
        "plan": name,
        "launch_date": "%02d/%02d/%d" % d,
        "ipca_before": before,
        "ipca_after": after,
        "months_lasted": months,
        "score": round(score, 4),
    })

results.sort(key=lambda r: r["score"], reverse=True)
for r in results:
    print(r)
print("top3:", [r["plan"] for r in results[:3]])