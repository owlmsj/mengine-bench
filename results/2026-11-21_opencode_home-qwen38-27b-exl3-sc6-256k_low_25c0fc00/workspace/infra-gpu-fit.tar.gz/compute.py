import csv, json

# Model requirements
weights_gb = 70e9 * 1 / 1e9          # 70B params, FP8 = 1 byte/param -> 70 GB
kv_per_token = 327680                # bytes per token (FP16, all layers, K+V)
ctx = 32768                          # tokens per sequence
seqs = 4
kv_cache_gb = kv_per_token * ctx * seqs / 1e9   # 327680*32768*4 = 42.94967296 GB
overhead_gb = 8.0
total_gb = weights_gb + kv_cache_gb + overhead_gb

print(f"weights_gb   = {weights_gb}")
print(f"kv_cache_gb  = {kv_cache_gb}")
print(f"total_gb     = {total_gb}")

allowed_regions = {"us-east", "us-central", "eu-west"}
rows = list(csv.DictReader(open("offers.csv")))
cands = []
for r in rows:
    if r["in_stock"] != "yes":
        continue
    if r["region"] not in allowed_regions:
        continue
    price = float(r["usd_per_hour"])
    if price > 4.0:
        continue
    mem = int(r["gpu_count"]) * float(r["vram_gb_per_gpu"])
    ok = mem >= total_gb
    print(f"{r['offer_id']}: mem={mem}GB price={price} ok={ok}")
    if ok:
        cands.append((price, r["offer_id"], price * 730))

cands.sort()
best_price, best_id, best_month = cands[0]
result = {
    "weights_gb": weights_gb,
    "kv_cache_gb": kv_cache_gb,
    "total_gb": total_gb,
    "offer_id": best_id,
    "usd_per_hour": best_price,
    "usd_per_month": best_month,
}
json.dump(result, open("result.json", "w"), indent=2)
print("BEST:", result)