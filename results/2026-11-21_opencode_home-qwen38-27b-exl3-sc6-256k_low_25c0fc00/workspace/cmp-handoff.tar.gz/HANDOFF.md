# Handoff: local-9b @ 128k context

## Done (measured)
- Baseline Q5 @ 131072 ctx: decode 37.8 t/s, VRAM 7881 MiB = WDDM ceiling; Shared Usage showed 1494 MiB spilled.
- Fix: `--no-mmproj-offload -ub 512` removes the spill. Final: VRAM 7697 MiB, decode 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k -> discarded. Q4_K_M fits (7305 MiB, 40.4 t/s) -> fallback only.
- Recipe applied in `scripts/start_server.ps1:165` (local9 block) and `profiles/local/local-9b.json`.

## Open
1. Review scratchpad temp-file names (noted 5x, never done).
2. Evals README still cites `check_vision.ps1`, which no longer exists -> update it.

## Assumptions
- "128k" = 131072 ctx; decode measured with `scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`.
- 7881 MiB is the WDDM cap, not true usage; trust Shared Usage for spills. Q5 is the target quant.

## Evidence
Final config verified by the spill disappearing (1494 -> 0 MiB), not by speed alone; decode is median of 3 runs.