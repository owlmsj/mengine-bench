import csv, math, json

path = r"<WORKSPACE>\telemetry\playtest_ab.csv"

sessions = {}
dupes = 0
bad_variant = 0
with open(path, newline="", encoding="utf-8") as f:
    r = csv.DictReader(f)
    for row in r:
        sid = row["session_id"].strip()
        v = row["variant"].strip().lower()
        if v not in ("a", "b"):
            bad_variant += 1
            continue
        comp = int(row["completed_tutorial"])
        if sid in sessions:
            # ETL resend: same session; verify consistent then skip
            prev = sessions[sid]
            if (prev[0], prev[1]) != (v, comp):
                print("INCONSISTENT DUPE:", sid, prev, (v, comp))
            dupes += 1
            continue
        sessions[sid] = (v, comp)

a = [c for v, c in sessions.values() if v == "a"]
b = [c for v, c in sessions.values() if v == "b"]
na, nb = len(a), len(b)
xa, xb = sum(a), sum(b)
pa, pb = xa / na, xb / nb

# two-proportion pooled z-test, two-sided
p = (xa + xb) / (na + nb)
se = math.sqrt(p * (1 - p) * (1 / na + 1 / nb))
z = (pb - pa) / se
# two-sided p via normal CDF
p_value = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))

ship_b = p_value < 0.05 and pb > pa

result = {
    "ship_b": ship_b,
    "sessions_a": na,
    "sessions_b": nb,
    "completion_rate_a": pa,
    "completion_rate_b": pb,
    "p_value": p_value,
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)

print("rows parsed, dupes skipped:", dupes, "bad variant:", bad_variant)
print("A: n=%d completed=%d rate=%.4f" % (na, xa, pa))
print("B: n=%d completed=%d rate=%.4f" % (nb, xb, pb))
print("z=%.4f p=%.6f ship_b=%s" % (z, p_value, ship_b))