import struct, json

data = open(r'prices.db','rb').read()
PAGE = len(data)

def varint(buf, i):
    v = 0
    for n in range(9):
        if i+n >= len(buf): return None
        b = buf[i+n]
        if n == 8:
            return (v << 8) | b, i+9
        v = (v << 7) | (b & 0x7f)
        if not (b & 0x80):
            return v, i+n+1
    return v, i+9

def parse_cell(buf, i):
    r = varint(buf, i); payload_len, i2 = r
    r = varint(buf, i2); rowid, i3 = r
    r = varint(buf, i3); hdr_len, j = r
    hdr_end = i3 + hdr_len
    if hdr_end >= len(buf): return None
    serials = []
    k = i3
    while k < hdr_end:
        r = varint(buf, k)
        if r is None: return None
        s, k = r
        serials.append(s)
    vals = []
    p = hdr_end
    for s in serials:
        if s == 0: vals.append(None)
        elif s == 1: vals.append(struct.unpack('>b', buf[p:p+1])[0]); p += 1
        elif s == 2: vals.append(struct.unpack('>h', buf[p:p+2])[0]); p += 2
        elif s == 3: vals.append(int.from_bytes(buf[p:p+3],'big',signed=True)); p += 3
        elif s == 4: vals.append(struct.unpack('>i', buf[p:p+4])[0]); p += 4
        elif s == 5: vals.append(int.from_bytes(buf[p:p+6],'big',signed=True)); p += 6
        elif s == 6: vals.append(struct.unpack('>q', buf[p:p+8])[0]); p += 8
        elif s == 7: vals.append(struct.unpack('>d', buf[p:p+8])[0]); p += 8
        elif s == 8: vals.append(0)
        elif s == 9: vals.append(1)
        elif s >= 12 and s % 2 == 0:
            n = (s-12)//2; vals.append(buf[p:p+n].decode('utf-8','replace')); p += n
        elif s >= 13 and s % 2 == 1:
            n = (s-13)//2; vals.append(buf[p:p+n]); p += n
        else: return None
        if p > len(buf): return None
    # payload_len must equal (p - i2)
    if payload_len != (p - i2):
        return None
    return rowid, vals, p

# Try every start offset; chain cells until we land exactly on PAGE (or on a zero region)
best = None
for start in range(100, PAGE):
    if data[start] == 0: continue
    i = start
    rows = []
    ok = True
    while i < PAGE:
        r = parse_cell(data, i)
        if r is None: ok = False; break
        rowid, vals, end = r
        rows.append((rowid, vals))
        i = end
    if ok and i == PAGE:
        print('clean chain from', start, 'rows:', len(rows))
        best = (start, rows)

if best:
    start, rows = best
    rows.sort()
    out = []
    for rowid, vals in rows:
        print(rowid, vals)
        if len(vals) == 2 and isinstance(vals[0], str):
            out.append({"item": vals[0], "price": vals[1]})
    json.dump(out, open(r'recovered.json','w',encoding='utf-8'), ensure_ascii=False, indent=2)
    print('wrote', len(out))
else:
    print('no clean chain; dumping parse at 3901..')
    # fallback: parse from 3901 ignoring payload check
    for start in (3900, 3901, 3902):
        print('start', start, data[start:start+40].hex())