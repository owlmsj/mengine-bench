import struct, json, sys

data = open(r'prices.db','rb').read()
print('size', len(data))

# Page 1: header 100 bytes, then page content at offset 100
# Determine page type at offset 100
ptype = data[100]
print('page1 type', ptype)

def varint(buf, i):
    v = 0
    for n in range(9):
        b = buf[i+n]
        if n == 8:
            v = (v << 8) | b
            return v, i+9
        v = (v << 7) | (b & 0x7f)
        if not (b & 0x80):
            return v, i+n+1
    return v, i+9

def parse_cell(buf, i):
    payload_len, i2 = varint(buf, i)
    rowid, i3 = varint(buf, i2)
    hdr_len, j = varint(buf, i3)
    hdr_end = i3 + hdr_len
    serials = []
    k = i3
    while k < hdr_end:
        s, k = varint(buf, k)
        serials.append(s)
    vals = []
    p = hdr_end
    for s in serials:
        if s == 0:
            vals.append(None)
        elif s == 1:
            vals.append(struct.unpack('>b', buf[p:p+1])[0]); p += 1
        elif s == 2:
            vals.append(struct.unpack('>h', buf[p:p+2])[0]); p += 2
        elif s == 3:
            vals.append(int.from_bytes(buf[p:p+3],'big',signed=True)); p += 3
        elif s == 4:
            vals.append(struct.unpack('>i', buf[p:p+4])[0]); p += 4
        elif s == 5:
            vals.append(int.from_bytes(buf[p:p+6],'big',signed=True)); p += 6
        elif s == 6:
            vals.append(struct.unpack('>q', buf[p:p+8])[0]); p += 8
        elif s == 7:
            vals.append(struct.unpack('>d', buf[p:p+8])[0]); p += 8
        elif s == 8:
            vals.append(0)
        elif s == 9:
            vals.append(1)
        elif s >= 12 and s % 2 == 0:
            n = (s-12)//2
            vals.append(buf[p:p+n].decode('utf-8','replace')); p += n
        elif s >= 13 and s % 2 == 1:
            n = (s-13)//2
            vals.append(buf[p:p+n]); p += n
        else:
            raise ValueError('serial %d' % s)
    return rowid, vals

def parse_leaf(buf, off, page_start):
    ncells = struct.unpack('>H', buf[off+3:off+5])[0]
    print('  leaf cells:', ncells)
    rows = []
    for c in range(ncells):
        ptr = struct.unpack('>H', buf[off+8+2*c:off+10+2*c])[0]
        i = page_start + ptr
        rowid, vals = parse_cell(buf, i)
        rows.append((rowid, vals))
    return rows

# page 1 content
if ptype == 13:  # table b-tree leaf
    rows = parse_leaf(data, 100, 0)
    for r in rows:
        print(r)
elif ptype == 5:  # interior page: sqlite_master
    ncells = struct.unpack('>H', data[103:105])[0]
    print('  interior cells:', ncells)
    for c in range(ncells):
        ptr = struct.unpack('>H', data[112+2*c:114+2*c])[0]
        print('  child page ptr at', 100+ptr, '=', data[100+ptr])
    # right-most child
    right = struct.unpack('>I', data[108:112])[0]
    print('  right child page', right)