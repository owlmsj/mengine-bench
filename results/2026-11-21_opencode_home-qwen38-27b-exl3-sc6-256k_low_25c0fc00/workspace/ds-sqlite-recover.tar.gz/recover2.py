import struct, json

data = open(r'prices.db','rb').read()

def varint(buf, i):
    v = 0
    for n in range(9):
        b = buf[i+n]
        if n == 8:
            return (v << 8) | b, i+9
        v = (v << 7) | (b & 0x7f)
        if not (b & 0x80):
            return v, i+n+1
    return v, i+9

def parse_cell(buf, i):
    payload_len, i2 = varint(buf, i)
    rowid, i3 = varint(buf, i2)
    hdr_len, j = varint(buf, i3)
    hdr_end = i3 + hdr_len
    serials = []
    k = i3
    while k < hdr_end:
        s, k = varint(buf, k)
        serials.append(s)
    vals = []
    p = hdr_end
    for s in serials:
        if s == 0: vals.append(None)
        elif s == 1: vals.append(struct.unpack('>b', buf[p:p+1])[0]); p += 1
        elif s == 2: vals.append(struct.unpack('>h', buf[p:p+2])[0]); p += 2
        elif s == 3: vals.append(int.from_bytes(buf[p:p+3],'big',signed=True)); p += 3
        elif s == 4: vals.append(struct.unpack('>i', buf[p:p+4])[0]); p += 4
        elif s == 5: vals.append(int.from_bytes(buf[p:p+6],'big',signed=True)); p += 6
        elif s == 6: vals.append(struct.unpack('>q', buf[p:p+8])[0]); p += 8
        elif s == 7: vals.append(struct.unpack('>d', buf[p:p+8])[0]); p += 8
        elif s == 8: vals.append(0)
        elif s == 9: vals.append(1)
        elif s >= 12 and s % 2 == 0:
            n = (s-12)//2; vals.append(buf[p:p+n].decode('utf-8','replace')); p += n
        elif s >= 13 and s % 2 == 1:
            n = (s-13)//2; vals.append(buf[p:p+n]); p += n
        else: raise ValueError('serial %d' % s)
    return rowid, vals, p

# Scan from end of page: cells are packed contiguously from page end backward.
# Each cell: payload varint, rowid varint, record. Parse forward from first cell.
# Find first cell start: walk backward from end? Easier: try parsing at every offset and see which chains cleanly.
# From hex: cell at 3901: 19 0a 04 00 27 ... payload=0x19=25, rowid=0x0a=10, hdr 04, serials 00 27 -> text len (0x27-12)/2 = 7? 0x27=39, (39-12)/2=13.5 no. Wait serial 0x27=39 is odd -> blob (39-13)/2=13 bytes? Hmm.
# Actually record header: hdr_len=04 means 4 bytes of serials: 00 27 07 66? no...
# Let's just parse forward from 3901 and see.
i = 3901
rows = []
while i < len(data):
    try:
        rowid, vals, end = parse_cell(data, i)
    except Exception as e:
        print('stop at', i, e); break
    rows.append((rowid, vals))
    print(rowid, vals)
    # next cell: after record end. But payload_len includes header+data.
    # end is exactly the next cell start.
    i = end
    if i >= len(data): break

# sort by rowid
rows.sort()
out = []
for rowid, vals in rows:
    # expect (item, price)
    if len(vals) == 2 and isinstance(vals[0], str):
        out.append({"item": vals[0], "price": vals[1]})
json.dump(out, open(r'recovered.json','w',encoding='utf-8'), ensure_ascii=False, indent=2)
print('wrote', len(out))