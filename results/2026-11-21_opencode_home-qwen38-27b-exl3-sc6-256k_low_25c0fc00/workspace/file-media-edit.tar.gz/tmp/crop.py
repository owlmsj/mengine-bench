from PIL import Image

im = Image.open('launch.jpg').convert('RGB')
W, H = im.size  # 3000x2000

# balloon bounds
bx0, by0, bx1, by1 = 2350, 500, 2750, 900
bcx, bcy = (bx0 + bx1) / 2, (by0 + by1) / 2
print('balloon center', bcx, bcy)

cw, ch = 1080, 1350
# scale: crop from 3000x2000 to 1080x1350
# choose crop window in source pixels: 4:5 ratio.
# source options: width 1200 -> height 1500; width 1333.33 -> height 1666.67 (too tall? H=2000 ok)
# pick the largest 4:5 window that fits: height-limited: ch_src = 2000 -> cw_src = 1600
cw_src, ch_src = 1600, 2000
# center on balloon, clamp
cx = min(max(bcx, cw_src / 2), W - cw_src / 2)
cy = min(max(bcy, ch_src / 2), H - ch_src / 2)
x0 = int(round(cx - cw_src / 2))
y0 = int(round(cy - ch_src / 2))
print('crop box', x0, y0, x0 + cw_src, y0 + ch_src)

# check balloon fully inside
assert bx0 >= x0 and bx1 <= x0 + cw_src and by0 >= y0 and by1 <= y0 + ch_src, 'balloon not fully in crop!'
print('balloon fully inside crop: OK')

crop = im.crop((x0, y0, x0 + cw_src, y0 + ch_src))
crop = crop.resize((cw, ch), Image.LANCZOS)
import os
os.makedirs('out', exist_ok=True)
crop.save('out/feed-photo.jpg', 'JPEG', quality=92)
print('saved out/feed-photo.jpg', crop.size)