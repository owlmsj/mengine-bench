import pypdf

r = pypdf.PdfReader('permit-form.pdf')
w = pypdf.PdfWriter()
w.append(r)
w.update_page_form_field_values(
    w.pages[0],
    {
        'organizer': 'Tidewater Studio',
        'event_date': '2026-12-05',
        'location': 'North Cove Lawn',
        'attendees': 'about 40',
    },
    auto_regenerate=False,
)
# flatten: remove field interactivity
try:
    w.flatten()
    print('flatten() called')
except Exception as e:
    print('flatten failed:', e)
with open('out/permit-filled.pdf', 'wb') as f:
    w.write(f)
print('saved out/permit-filled.pdf')

# verify
r2 = pypdf.PdfReader('out/permit-filled.pdf')
f2 = r2.get_fields()
for k, v in (f2 or {}).items():
    print(k, '->', v.get('/V'))