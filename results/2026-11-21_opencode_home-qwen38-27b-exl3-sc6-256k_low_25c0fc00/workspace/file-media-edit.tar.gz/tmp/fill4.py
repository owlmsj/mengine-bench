import pypdf
from pypdf.generic import NameObject, ArrayObject, DecodedStreamObject

r = pypdf.PdfReader('permit-form.pdf')
w = pypdf.PdfWriter()
w.append(r)
w.update_page_form_field_values(
    w.pages[0],
    {
        'organizer': 'Tidewater Studio',
        'event_date': '2026-12-05',
        'location': 'North Cove Lawn',
        'attendees': 'about 40',
    },
    auto_regenerate=False,
)

page = w.pages[0]
chunks = []
for a in page.get('/Annots', []):
    obj = a.get_object()
    if obj.get('/Subtype') != '/Widget':
        continue
    rect = [float(x) for x in obj['/Rect']]
    x, y, x2, y2 = rect
    n = obj['/AP']['/N'].get_object()
    data = n.get_data()
    # wrap in cm transform so local (0,0) maps to the field's bottom-left
    chunks.append(b'q\n%.4f 0 0 %.4f %.4f %.4f cm\n' % (x2 - x, y2 - y, x, y) + data + b'\nQ\n')

existing = page.get_contents()
existing_data = existing.get_data() if existing is not None else b''
new_data = existing_data + b'\n' + b'\n'.join(chunks) + b'\n'
cs = DecodedStreamObject()
cs.set_data(new_data)
page[NameObject('/Contents')] = cs

annots = page.get('/Annots', [])
kept = [a for a in annots if a.get_object().get('/Subtype') != '/Widget']
if kept:
    page[NameObject('/Annots')] = ArrayObject(kept)
else:
    del page['/Annots']

if '/AcroForm' in w._root_object:
    del w._root_object['/AcroForm']

with open('out/permit-filled.pdf', 'wb') as f:
    w.write(f)
print('saved; chunks:', len(chunks))

r2 = pypdf.PdfReader('out/permit-filled.pdf')
print('fields after:', r2.get_fields())
import re
data = r2.pages[0].get_contents().get_data().decode('latin-1')
for m in re.finditer(r'\((.*?)\)\s*Tj', data):
    print('Tj:', m.group(1))