import pypdf
from pypdf.generic import NameObject, ArrayObject

r = pypdf.PdfReader('permit-form.pdf')
w = pypdf.PdfWriter()
w.append(r)
w.update_page_form_field_values(
    w.pages[0],
    {
        'organizer': 'Tidewater Studio',
        'event_date': '2026-12-05',
        'location': 'North Cove Lawn',
        'attendees': 'about 40',
    },
    auto_regenerate=False,
)

page = w.pages[0]
# Collect appearance streams from widget annotations, in order
appearance_chunks = []
for a in page.get('/Annots', []):
    obj = a.get_object()
    if obj.get('/Subtype') != '/Widget':
        continue
    ap = obj.get('/AP')
    if ap is None:
        continue
    n = ap.get('/N')
    if n is None:
        continue
    nobj = n.get_object()
    if hasattr(nobj, 'get_data'):
        appearance_chunks.append(nobj.get_data())
    else:
        # may be a dict of states
        for k, v in nobj.items():
            vo = v.get_object()
            if hasattr(vo, 'get_data'):
                appearance_chunks.append(vo.get_data())

# Append appearance content to the page's existing content stream
existing = page.get_contents()
existing_data = existing.get_data() if existing is not None else b''
new_data = existing_data + b'\n' + b'\n'.join(appearance_chunks) + b'\n'
from pypdf.generic import DecodedStreamObject
cs = DecodedStreamObject()
cs.set_data(new_data)
page[NameObject('/Contents')] = cs

# Remove widget annotations
annots = page.get('/Annots', [])
kept = [a for a in annots if a.get_object().get('/Subtype') != '/Widget']
if kept:
    page[NameObject('/Annots')] = ArrayObject(kept)
else:
    del page['/Annots']

if '/AcroForm' in w._root_object:
    del w._root_object['/AcroForm']

with open('out/permit-filled.pdf', 'wb') as f:
    w.write(f)
print('saved; appearance chunks:', len(appearance_chunks))

r2 = pypdf.PdfReader('out/permit-filled.pdf')
print('fields after:', r2.get_fields())
import re
data = r2.pages[0].get_contents().get_data().decode('latin-1')
for m in re.finditer(r'\((.*?)\)\s*Tj', data):
    print('Tj:', m.group(1))