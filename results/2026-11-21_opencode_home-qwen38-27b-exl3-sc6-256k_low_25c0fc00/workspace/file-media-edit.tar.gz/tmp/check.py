import pypdf

r = pypdf.PdfReader('out/permit-filled.pdf')
page = r.pages[0]
print('page keys:', list(page.keys()))
# look for /AP in any remaining content
# pypdf stores generated appearances in the page's content or in a separate stream
# Check page content stream for text operators
content = page.get_contents()
if content is not None:
    data = content.get_data().decode('latin-1')
    print('content length:', len(data))
    # find text-showing operators
    import re
    for m in re.finditer(r'\((.*?)\)\s*Tj', data):
        print('Tj text:', m.group(1))
    for m in re.finditer(r'\[(.*?)\]\s*TJ', data):
        print('TJ text:', m.group(1)[:200])
else:
    print('no contents')