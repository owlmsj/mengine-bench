import pypdf

r = pypdf.PdfReader('permit-form.pdf')
page = r.pages[0]
for a in page['/Annots']:
    o = a.get_object()
    if o.get('/Subtype') == '/Widget':
        t = o.get('/T')
        rect = [float(x) for x in o['/Rect']]
        ap = o.get('/AP', {}).get('/N')
        apd = ap.get_object().get_data().decode('latin-1')
        # extract Tm positions
        import re
        pos = re.findall(r'([\d.]+) 0 0 ([\d.]+) ([\d.]+) ([\d.]+) Tm', apd)
        txt = re.findall(r'\((.*?)\)\s*Tj', apd)
        print(t, 'rect', rect, 'Tm', pos, 'txt', txt)
print('mediabox', page['/MediaBox'])