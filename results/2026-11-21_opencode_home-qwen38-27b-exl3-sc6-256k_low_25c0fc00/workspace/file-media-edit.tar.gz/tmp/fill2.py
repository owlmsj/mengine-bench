import pypdf

r = pypdf.PdfReader('permit-form.pdf')
w = pypdf.PdfWriter()
w.append(r)
w.update_page_form_field_values(
    w.pages[0],
    {
        'organizer': 'Tidewater Studio',
        'event_date': '2026-12-05',
        'location': 'North Cove Lawn',
        'attendees': 'about 40',
    },
    auto_regenerate=False,
)

# Flatten: remove form fields from the page (values remain as drawn content
# via the appearance streams pypdf generated).
page = w.pages[0]
if '/Annots' in page:
    annots = page['/Annots']
    kept = []
    for a in annots:
        obj = a.get_object()
        if obj.get('/Subtype') == '/Widget':
            continue  # drop widget annotations
        kept.append(a)
    if kept:
        page[NameObject('/Annots')] = ArrayObject(kept)
    else:
        del page['/Annots']

# Drop the AcroForm so no fields remain interactive
if '/AcroForm' in w._root_object:
    del w._root_object['/AcroForm']

with open('out/permit-filled.pdf', 'wb') as f:
    w.write(f)
print('saved')

# verify: no fields left, page renders
r2 = pypdf.PdfReader('out/permit-filled.pdf')
print('fields after:', r2.get_fields())
print('pages:', len(r2.pages))
print('text:', r2.pages[0].extract_text()[:500])