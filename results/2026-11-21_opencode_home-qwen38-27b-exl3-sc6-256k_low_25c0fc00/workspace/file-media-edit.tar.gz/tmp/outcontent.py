import pypdf

r = pypdf.PdfReader('out/permit-filled.pdf')
data = r.pages[0].get_contents().get_data().decode('latin-1')
print(data)