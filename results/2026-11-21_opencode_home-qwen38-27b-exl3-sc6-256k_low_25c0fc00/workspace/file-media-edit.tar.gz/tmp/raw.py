import pypdf

r = pypdf.PdfReader('permit-form.pdf')
page = r.pages[0]
for a in page['/Annots']:
    o = a.get_object()
    if o.get('/Subtype') == '/Widget':
        t = o.get('/T')
        ap = o.get('/AP', {}).get('/N').get_object()
        print('===', t, '===')
        print(ap.get_data().decode('latin-1'))