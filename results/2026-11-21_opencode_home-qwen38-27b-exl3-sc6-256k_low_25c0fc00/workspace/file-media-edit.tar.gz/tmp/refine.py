from PIL import Image

im = Image.open('launch.jpg').convert('RGB')
px = im.load()
w, h = im.size

# search region around the coarse bounds
x0, x1 = 2250, 2850
y0, y1 = 400, 1000
minx, maxx, miny, maxy = x1, x0, y1, y0
for y in range(y0, y1):
    for x in range(x0, x1):
        r, g, b = px[x, y]
        if r > 140 and g < 120 and b > 100 and (r - g) > 60:
            if x < minx: minx = x
            if x > maxx: maxx = x
            if y < miny: miny = y
            if y > maxy: maxy = y
print('bounds', minx, miny, maxx, maxy)
print('size', maxx - minx + 1, maxy - miny + 1)
print('image', w, h)