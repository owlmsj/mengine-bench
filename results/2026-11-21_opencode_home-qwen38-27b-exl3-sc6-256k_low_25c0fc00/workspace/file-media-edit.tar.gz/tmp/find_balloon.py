from PIL import Image
import colorsys

im = Image.open('launch.jpg').convert('RGB')
w, h = im.size
px = im.load()

# magenta: high R, low G, high B
best = []
step = 5
for y in range(0, h, step):
    for x in range(0, w, step):
        r, g, b = px[x, y]
        if r > 150 and g < 110 and b > 110:
            best.append((x, y, r, g, b))

if best:
    xs = [p[0] for p in best]
    ys = [p[1] for p in best]
    print('count', len(best))
    print('x range', min(xs), max(xs))
    print('y range', min(ys), max(ys))
    # sample a few
    for p in best[:10]:
        print(p)
else:
    print('no magenta found with strict thresholds')