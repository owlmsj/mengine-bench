import csv, re, json
from decimal import Decimal
from collections import defaultdict

base = r"<WORKSPACE>\backoffice"

invoices = {}
with open(f"{base}/invoices.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = Decimal(row["amount"])

payments = defaultdict(list)  # id -> list of amounts
ignored = []
with open(f"{base}/bank_statement_june.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        m = re.search(r"(?:inv|invoice)[- ]?(\d{4})", memo, re.IGNORECASE)
        if not m:
            ignored.append((memo, row["amount"]))
            continue
        pid = "INV-" + m.group(1)
        if pid not in invoices:
            ignored.append((memo, row["amount"]))
            continue
        payments[pid].append(Decimal(row["amount"]))

unpaid, duplicated, mismatched = [], [], []
for pid in sorted(invoices):
    pays = payments.get(pid, [])
    if not pays:
        unpaid.append(pid)
    elif len(pays) > 1:
        duplicated.append(pid)
    elif pays[0] != invoices[pid]:
        mismatched.append({"id": pid, "invoiced": str(invoices[pid]), "paid": str(pays[0])})

result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)

print("ignored rows:", ignored)
print(json.dumps(result, indent=2, ensure_ascii=False))