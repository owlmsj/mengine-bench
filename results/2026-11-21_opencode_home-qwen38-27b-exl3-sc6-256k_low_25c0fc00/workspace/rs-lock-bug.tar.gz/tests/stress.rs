use arena_scores::Board;
use std::thread;

#[test]
fn concurrent_wards_do_not_lose_points() {
    let board = Board::new();
    board.join(1, 0);
    let mut handles = Vec::new();
    for _ in 0..8 {
        let b = board.clone();
        handles.push(thread::spawn(move || {
            for _ in 0..2000 {
                b.award(1, 1);
            }
        }));
    }
    for h in handles {
        h.join().unwrap();
    }
    assert_eq!(board.score(1), 16000);
    assert_eq!(board.total(), 16000);
}

#[test]
fn opposite_transfers_do_not_deadlock() {
    let board = Board::new();
    board.join(1, 100);
    board.join(2, 100);
    let mut handles = Vec::new();
    for _ in 0..4 {
        let b = board.clone();
        handles.push(thread::spawn(move || {
            for _ in 0..2000 {
                b.transfer(1, 2, 1);
            }
        }));
        let b = board.clone();
        handles.push(thread::spawn(move || {
            for _ in 0..2000 {
                b.transfer(2, 1, 1);
            }
        }));
    }
    for h in handles {
        h.join().unwrap();
    }
    assert_eq!(board.score(1), 100);
    assert_eq!(board.score(2), 100);
    assert_eq!(board.total(), 200);
}

#[test]
fn rejoin_replaces_score_without_double_counting() {
    let board = Board::new();
    board.join(1, 10);
    board.join(1, 7);
    assert_eq!(board.score(1), 7);
    assert_eq!(board.total(), 7);
}