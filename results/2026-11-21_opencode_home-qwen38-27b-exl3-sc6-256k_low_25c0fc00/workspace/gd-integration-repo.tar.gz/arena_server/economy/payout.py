"""Match payout. Rules live in docs/ECONOMY.md."""

from decimal import ROUND_HALF_UP, Decimal


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    raw = (base + kills * cfg["kill_bonus"]) * cfg["event_multiplier"]
    # Decimal keeps .5 exact; float floor(x/10 + 0.5) rounds halves down (1425 -> 1420).
    return int(Decimal(str(raw)).quantize(Decimal("10"), rounding=ROUND_HALF_UP))
