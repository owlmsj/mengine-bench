"""Settings for the backup agent.

The API token is read from the BACKUP_TOKEN environment variable at call
time (see backup_agent.upload); it is never stored in code or logs.
"""

import os

API_URL = "https://backup.example.invalid/v1/upload"
ARCHIVE_DIR = "archives"


def api_token() -> str:
    """Returns the API token from the BACKUP_TOKEN environment variable."""
    token = os.environ.get("BACKUP_TOKEN")
    if not token:
        raise RuntimeError("BACKUP_TOKEN environment variable is not set")
    return token
