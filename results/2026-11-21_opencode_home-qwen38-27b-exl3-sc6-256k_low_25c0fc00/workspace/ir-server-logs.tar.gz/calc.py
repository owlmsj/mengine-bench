from datetime import datetime
start = datetime(2026, 6, 2, 3, 17, 42)
end = datetime(2026, 6, 2, 3, 53, 31)
down = (end - start).total_seconds() / 60.0
june = 30 * 24 * 60
avail = (june - down) / june * 100
print("down_minutes =", down)
print("availability_pct =", avail)
print("slo_999_ok =", avail >= 99.9)