import csv, json
from collections import defaultdict

def parse_amount(s):
    s = s.strip().replace('.', '').replace(',', '.')
    return float(s)

coa = {}
with open('chart_of_accounts.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        coa[row['account']] = row['pnl_line']

months = ['2026-01','2026-02','2026-03','2026-04','2026-05','2026-06']
sums = {m: defaultdict(float) for m in months}

with open('ledger.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        d = row['date'].split('/')
        m = f"2026-{d[1]}"
        line = coa[row['account']]
        sums[m][line] += parse_amount(row['amount'])

result = {}
for m in months:
    s = sums[m]
    rev = s['revenue']
    cogs = s['cogs']
    gm_pct = (rev + cogs) / rev * 100 if rev else 0.0
    ebitda = rev + s['cogs'] + s['sales_marketing'] + s['rnd'] + s['ga']
    result[m] = (rev, gm_pct, ebitda)
    print(m, f"rev={rev:,.2f} gm={gm_pct:.2f}% ebitda={ebitda:,.2f}")

eb = [result[m][2] for m in months]
burn = -sum(eb[3:6]) / 3  # last three closed months: Apr, May, Jun
cash = 1847350.40
runway = cash / burn
print(f"burn={burn:,.2f} cash={cash:,.2f} runway={runway:.2f}")

out = {
    "revenue": {m: round(result[m][0], 2) for m in months},
    "gross_margin_pct": {m: round(result[m][1], 2) for m in months},
    "ebitda": {m: round(result[m][2], 2) for m in months},
    "burn": round(burn, 2),
    "runway_months": round(runway, 2),
}
with open('../result.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))