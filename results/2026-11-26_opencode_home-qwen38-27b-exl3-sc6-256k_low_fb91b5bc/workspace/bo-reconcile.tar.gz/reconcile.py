import csv, re, json
from collections import defaultdict

base = r"<WORKSPACE>\backoffice"

invoices = {}
with open(f"{base}/invoices.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = float(row["amount"])

payments = defaultdict(list)  # inv_id -> [amounts]
skipped = []
with open(f"{base}/bank_statement_june.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        amt = float(row["amount"])
        m = re.search(r"(?:inv|invoice)\s*-?(\d{4})", memo, re.IGNORECASE)
        if not m:
            skipped.append((row["date"], memo, amt))
            continue
        inv_id = f"INV-{m.group(1)}"
        if inv_id not in invoices:
            skipped.append((row["date"], memo, amt))
            continue
        payments[inv_id].append(amt)

unpaid = sorted(set(invoices) - set(payments))
duplicated = sorted(inv for inv, amts in payments.items() if len(amts) > 1)
mismatched = []
for inv, amts in payments.items():
    if len(amts) == 1 and abs(amts[0] - invoices[inv]) > 0.005:
        mismatched.append({"id": inv, "invoiced": invoices[inv], "paid": amts[0]})
mismatched.sort(key=lambda x: x["id"])

result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)

print(json.dumps(result, indent=2, ensure_ascii=False))
print("SKIPPED:", skipped)
print("paid count:", len(payments), "unpaid:", len(unpaid), "dup:", len(duplicated), "mismatch:", len(mismatched))