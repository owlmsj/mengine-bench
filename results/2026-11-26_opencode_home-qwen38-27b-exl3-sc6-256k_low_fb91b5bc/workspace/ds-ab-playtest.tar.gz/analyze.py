import csv, json, math

rows = []
with open(r"<WORKSPACE>\telemetry\playtest_ab.csv", newline="", encoding="utf-8") as f:
    r = csv.DictReader(f)
    for row in r:
        rows.append(row)

print("total rows:", len(rows))

# Dedupe by session_id (unique key per README). Keep first occurrence.
seen = {}
for row in rows:
    sid = row["session_id"].strip()
    if sid not in seen:
        seen[sid] = row

sessions = list(seen.values())
print("unique sessions:", len(sessions))

# Normalize variant: strip, lowercase
def norm(v):
    return v.strip().lower()

a = [s for s in sessions if norm(s["variant"]) == "a"]
b = [s for s in sessions if norm(s["variant"]) == "b"]
other = [s for s in sessions if norm(s["variant"]) not in ("a", "b")]
print("variant a:", len(a), "variant b:", len(b), "other:", len(other))
if other:
    print("other variants:", set(norm(s["variant"]) for s in other))

def rate(group):
    n = len(group)
    k = sum(1 for s in group if s["completed_tutorial"].strip() == "1")
    return n, k, k / n if n else 0.0

na, ka, ra = rate(a)
nb, kb, rb = rate(b)
print(f"A: n={na} completed={ka} rate={ra:.6f}")
print(f"B: n={nb} completed={kb} rate={rb:.6f}")

# Two-proportion z-test, two-sided, H0: pA = pB
p_pool = (ka + kb) / (na + nb)
se = math.sqrt(p_pool * (1 - p_pool) * (1/na + 1/nb))
z = (rb - ra) / se
# two-sided p-value
p_value = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))
print(f"pooled p={p_pool:.6f} se={se:.6f} z={z:.6f} p={p_value:.6g}")

ship_b = p_value < 0.05 and rb > ra
print("ship_b:", ship_b)

result = {
    "ship_b": bool(ship_b),
    "sessions_a": na,
    "sessions_b": nb,
    "completion_rate_a": round(ra, 6),
    "completion_rate_b": round(rb, 6),
    "p_value": round(p_value, 6),
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))