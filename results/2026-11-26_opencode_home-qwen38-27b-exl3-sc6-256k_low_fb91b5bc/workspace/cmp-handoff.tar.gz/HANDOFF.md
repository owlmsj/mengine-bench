# Handoff: local-9b Q5 @ 128k context

## Done (measured)
- local-9b Q5_K, ctx 131072, 1024 predict: 37.8 t/s, VRAM 7881 MiB (WDDM ceiling; 1494 MiB spilled -> does not count).
- Fix: `--no-mmproj-offload` + `-ub 512` removes spill: VRAM 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k; discarded. Q4_K_M fits (7305 MiB, 40.4 t/s) - fallback only.
- Recipe applied in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

## Pending
1. Update evals README: still cites check_vision.ps1, which no longer exists.
2. Review scratchpad temp file names (noted several times, never done).

## Assumptions
- "The recipe" = no-mmproj-offload + ub 512 flags above.
- 38.0 t/s median-of-3 is the number to report.

## How I know it is right
Numbers come from the measurement runs in the transcript (steps 10, 42, 45): spill confirmed via Shared Usage counter, fix re-measured 3x. Re-run scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024 to confirm.