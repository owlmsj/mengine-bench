import json, struct

data = open('prices.db','rb').read()

def varint(buf, pos):
    result = 0
    for i in range(9):
        b = buf[pos+i]
        if i == 8:
            result = (result << 8) | b
            return result, pos+9
        result = (result << 7) | (b & 0x7f)
        if not (b & 0x80):
            return result, pos+i+1
    return result, pos+9

def read_record(buf, pos):
    payload_len, p = varint(buf, pos)
    rowid, p = varint(buf, p)
    hdr_start = p
    hdr_len, p = varint(buf, p)
    hdr_end = hdr_start + hdr_len
    if hdr_end > len(buf):
        return None
    serials = []
    q = p
    while q < hdr_end:
        s, q = varint(buf, q)
        serials.append(s)
    body = hdr_end
    vals = []
    ok = True
    for s in serials:
        if s == 0:
            vals.append(None)
        elif s == 1:
            if body+1>len(buf): ok=False; break
            vals.append(struct.unpack('>b', buf[body:body+1])[0]); body += 1
        elif s == 2:
            if body+2>len(buf): ok=False; break
            vals.append(struct.unpack('>h', buf[body:body+2])[0]); body += 2
        elif s == 3:
            if body+3>len(buf): ok=False; break
            vals.append(int.from_bytes(buf[body:body+3],'big',signed=True)); body += 3
        elif s == 4:
            if body+4>len(buf): ok=False; break
            vals.append(struct.unpack('>i', buf[body:body+4])[0]); body += 4
        elif s == 5:
            if body+6>len(buf): ok=False; break
            vals.append(struct.unpack('>q', buf[body:body+6])[0]); body += 6
        elif s == 6:
            if body+8>len(buf): ok=False; break
            vals.append(struct.unpack('>q', buf[body:body+8])[0]); body += 8
        elif s == 7:
            if body+8>len(buf): ok=False; break
            vals.append(struct.unpack('>d', buf[body:body+8])[0]); body += 8
        elif s >= 12 and s % 2 == 0:
            n = (s-12)//2
            if body+n>len(buf): ok=False; break
            vals.append(buf[body:body+n].decode('utf-8','replace')); body += n
        elif s >= 13 and s % 2 == 1:
            n = (s-13)//2
            if body+n>len(buf): ok=False; break
            vals.append(buf[body:body+n]); body += n
        else:
            vals.append(None)
    if not ok:
        return None
    return (rowid, vals, body)

idx = data.find(b'first aid kit')
rec_start = idx - 6
pos = rec_start
rows = []
while pos < len(data):
    r = read_record(data, pos)
    if r is None:
        break
    rowid, vals, next_pos = r
    rows.append((rowid, vals))
    pos = next_pos

out = []
for rowid, vals in rows:
    # vals = [None, item_bytes, price]
    item = vals[1]
    if isinstance(item, bytes):
        item = item.decode('utf-8')
    price = vals[2]
    if isinstance(price, float) and price.is_integer():
        price = int(price)
    if isinstance(item, str) and price is not None:
        out.append({"item": item, "price": price})
    else:
        print('SKIPPED (incomplete):', rowid, vals)

json.dump(out, open('recovered.json','w'), indent=2)
print('wrote', len(out), 'rows')
for o in out:
    print(o)