import urllib.request, struct, wave, os, io, re

text = "Welcome aboard the evening ferry, please keep your bags clear of the doors."
url = "https://translate.google.com/translate_tts?ie=UTF-8&tl=en&client=tw-ob&q=" + urllib.parse.quote(text)
req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
data = urllib.request.urlopen(req, timeout=30).read()
print("mp3 bytes:", len(data))

# Decode MP3 frames minimally: use a small pure-python MP3 decoder is overkill.
# Instead, check if ffmpeg is available to convert.
import shutil, subprocess
ff = shutil.which("ffmpeg")
print("ffmpeg:", ff)
if ff:
    mp3 = os.path.join(os.path.dirname(__file__), "tmp.mp3")
    wav = os.path.join(os.path.dirname(__file__), "announcement.wav")
    with open(mp3, "wb") as f:
        f.write(data)
    subprocess.run([ff, "-y", "-i", mp3, "-ar", "24000", "-ac", "1", wav], check=True)
    print("wav written")
else:
    print("no ffmpeg; need another path")