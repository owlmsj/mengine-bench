Add-Type -AssemblyName System.Speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
$s.Rate = 0
$s.SaveToWav('<WORKSPACE>\announcement.wav', 'Welcome aboard the evening ferry, please keep your bags clear of the doors.')
$s.Dispose()
Write-Host 'ok'