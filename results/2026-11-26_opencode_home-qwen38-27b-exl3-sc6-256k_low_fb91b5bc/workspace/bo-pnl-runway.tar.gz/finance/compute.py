import csv, json, os
from collections import defaultdict

BASE = os.path.dirname(os.path.abspath(__file__))

months = ["2026-01","2026-02","2026-03","2026-04","2026-05","2026-06"]
line = {}
with open(os.path.join(BASE, "chart_of_accounts.csv"), encoding="utf-8") as f:
    r = csv.reader(f, delimiter=";")
    next(r)
    for row in r:
        line[row[0]] = row[2]

agg = {m: defaultdict(float) for m in months}
with open(os.path.join(BASE, "ledger.csv"), encoding="utf-8") as f:
    r = csv.reader(f, delimiter=";")
    next(r)
    for d, acct, desc, amt in r:
        dd, mm, yyyy = d.split("/")
        m = f"{yyyy}-{mm}"
        val = float(amt.replace(".", "").replace(",", "."))
        agg[m][line[acct]] += val

out = {"revenue": {}, "gross_margin_pct": {}, "ebitda": {}}
eb = {}
for m in months:
    a = agg[m]
    rev = a["revenue"]
    cogs = -a["cogs"]
    gm = (rev - cogs) / rev * 100 if rev else 0.0
    ebitda = rev - cogs + a["sales_marketing"] + a["rnd"] + a["ga"]
    eb[m] = ebitda
    out["revenue"][m] = round(rev, 2)
    out["gross_margin_pct"][m] = round(gm, 2)
    out["ebitda"][m] = round(ebitda, 2)

# board rule: burn = average monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = [eb[m] for m in ["2026-04","2026-05","2026-06"]]
burn = -sum(last3)/3
cash = 1847350.40  # 30/06/2026 consolidated balance
out["burn"] = round(burn, 2)
out["runway_months"] = round(cash / burn, 2)

with open(os.path.join(BASE, "..", "result.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))
print("last3 ebitda:", [round(x,2) for x in last3])