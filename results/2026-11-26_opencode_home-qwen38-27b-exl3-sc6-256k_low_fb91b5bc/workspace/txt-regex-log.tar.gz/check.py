import re

pat = open("regex.txt").read().strip()
log = open("server.log").read()
print("sample:", re.findall(pat, log, re.MULTILINE))

cases = [
    # (line, expected)
    ("2026-04-02 07:15:09 INFO  gateway accepted 10.12.0.7 for build 2026-04-01", ["2026-04-01"]),
    ("2026-04-02 07:15:11 INFO  cache warm, 412 keys, next sweep 2026-04-03", []),
    ("2026-04-02 07:16:40 WARN  peer 192.168.40.3 slow, retry window 2026-04-02 to 2026-04-05", ["2026-04-05"]),
    ("2026-04-02 07:18:02 INFO  job 7781-20-4410 queued by scheduler", []),
    ("2026-04-02 07:19:30 ERROR upstream 172.20.1.14 refused handshake", []),
    # boundary: letter/digit before or after date
    ("x2026-04-02 from 10.0.0.1", []),
    ("2026-04-02x from 10.0.0.1", []),
    ("92026-04-02 from 10.0.0.1", []),
    ("2026-04-029 from 10.0.0.1", []),
    # boundary: letter/digit before or after address
    ("2026-04-02 from a10.0.0.1", []),
    ("2026-04-02 from 10.0.0.1a", []),
    ("2026-04-02 from 110.0.0.1", []),
    ("2026-04-02 from 10.0.0.11", []),
    # bad address parts
    ("2026-04-02 from 256.0.0.1", []),
    ("2026-04-02 from 10.0.0.01", []),
    ("2026-04-02 from 010.0.0.1", []),
    ("2026-04-02 from 10.0.0", []),
    ("2026-04-02 from 10.0.0.1.2", []),
    # good addresses
    ("2026-04-02 from 0.0.0.0", ["2026-04-02"]),
    ("2026-04-02 from 255.255.255.255", ["2026-04-02"]),
    ("2026-04-02 from 1.2.3.4", ["2026-04-02"]),
    # bad dates
    ("2026-04-02 from 10.0.0.1 bad 2026-02-30", []),
    ("2026-04-02 from 10.0.0.1 bad 2026-13-01", []),
    ("2026-04-02 from 10.0.0.1 bad 2026-00-10", []),
    ("2026-04-02 from 10.0.0.1 bad 2026-04-31", []),
    ("2026-04-02 from 10.0.0.1 bad 2026-06-31", []),
    ("2026-04-02 from 10.0.0.1 bad 2026-09-31", []),
    # feb 29 allowed every year per brief
    ("2026-04-02 from 10.0.0.1 ok 2026-02-29", ["2026-02-29"]),
    ("2026-04-02 from 10.0.0.1 ok 2023-02-29", ["2023-02-29"]),
    # last date on line wins
    ("2026-04-02 from 10.0.0.1 a 2026-04-03 b 2026-04-04", ["2026-04-04"]),
    # date before address only
    ("2026-04-02 from 10.0.0.1", ["2026-04-02"]),
    # no address, dates only
    ("2026-04-02 then 2026-04-03", []),
    # address with no date
    ("just 10.0.0.1 here", []),
    # year 19xx
    ("1999-12-31 from 10.0.0.1", ["1999-12-31"]),
    # 3-digit year not a date
    ("12026-04-02 from 10.0.0.1", []),
    # date at line start / end
    ("2026-04-02 10.0.0.1", ["2026-04-02"]),
    ("10.0.0.1 2026-04-02", ["2026-04-02"]),
]

ok = True
for line, exp in cases:
    got = re.findall(pat, line + "\n", re.MULTILINE)
    if got != exp:
        ok = False
        print("FAIL", repr(line), "expected", exp, "got", got)
print("ALL OK" if ok else "FAILURES")