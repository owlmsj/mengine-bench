import sqlite3, json

STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']
con = sqlite3.connect('analytics.db')

# real players only
players = {uid: plat for uid, plat, test in con.execute(
    "SELECT user_id, platform, is_test FROM users WHERE is_test = 0")}

# first valid occurrence per player per step, respecting order:
# a step counts only at or after the same player's previous step
first = {}  # (uid, step) -> ts
for uid, name, ts in con.execute("SELECT user_id, name, ts FROM events"):
    if uid not in players or name not in STEPS:
        continue  # unknown players or non-funnel events don't count
    key = (uid, name)
    if key not in first or ts < first[key]:
        first[key] = ts

funnel = {}
for plat in sorted({p for p in players.values()}):
    counts = {}
    prev_ts = None
    for step in STEPS:
        n = 0
        for uid, p in players.items():
            if p != plat:
                continue
            ts = first.get((uid, step))
            if ts is None:
                continue
            if prev_ts is not None and ts < prev_ts:
                continue  # step before previous step's time -> invalid
            n += 1
        counts[step] = n
    funnel[plat] = counts

# biggest drop: step with lowest conversion (players / previous step's players)
biggest_drop = {}
for plat, counts in funnel.items():
    best_step, best_conv = None, None
    for i, step in enumerate(STEPS):
        if i == 0:
            continue
        prev = counts[STEPS[i-1]]
        conv = counts[step] / prev if prev else 0.0
        if best_conv is None or conv < best_conv:
            best_conv, best_step = conv, step
    biggest_drop[plat] = best_step

result = {'funnel': funnel, 'biggest_drop': biggest_drop}
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))