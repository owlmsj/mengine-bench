import sqlite3
con = sqlite3.connect('analytics.db')
STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']
# check: any real player with a step event earlier than their previous step's first event?
bad = 0
for uid, plat in con.execute("SELECT user_id, platform FROM users WHERE is_test=0"):
    ts = {}
    for name, t in con.execute("SELECT name, MIN(ts) FROM events WHERE user_id=? AND name IN ('install','tutorial_complete','first_match','purchase') GROUP BY name", (uid,)):
        ts[name] = t
    prev = None
    for s in STEPS:
        if s in ts:
            if prev is not None and ts[s] < prev:
                bad += 1
            prev = ts[s]
print('players with out-of-order steps:', bad)
# test accounts and unknown players
print('test accounts:', con.execute("SELECT COUNT(*) FROM users WHERE is_test=1").fetchone()[0])
print('events from unknown players:', con.execute("SELECT COUNT(*) FROM events e WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.user_id=e.user_id)").fetchone()[0])
print('distinct event names:', [r[0] for r in con.execute("SELECT DISTINCT name FROM events")])