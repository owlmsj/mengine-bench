"""Tests for run.run_tasks: concurrency cap, completion, cancellation cleanup."""

import asyncio
import run


def test_cap_and_completion():
    active = 0
    peak = 0
    done = 0

    def make_task(i):
        async def job():
            nonlocal active, peak, done
            active += 1
            peak = max(peak, active)
            await asyncio.sleep(0.01)
            active -= 1
            done += 1
            return i
        return job

    results = asyncio.run(run.run_tasks([make_task(i) for i in range(10)], 3))
    assert results == list(range(10)), results
    assert peak <= 3, peak
    assert done == 10, done
    print("cap+completion OK, peak =", peak)


def test_cleanup_on_cancel():
    cleaned = []

    def make_task(i):
        async def job():
            try:
                await asyncio.sleep(10)
            finally:
                cleaned.append(i)
        return job

    async def main():
        coro = run.run_tasks([make_task(i) for i in range(4)], 2)
        await asyncio.sleep(0.05)  # let 2 jobs start
        # Simulate Ctrl+C: cancel the run.
        task = asyncio.current_task()
        # Cancel from outside via a watchdog.
        async def cancel_later():
            await asyncio.sleep(0.1)
            task.cancel()
        asyncio.get_running_loop().create_task(cancel_later())
        try:
            await coro
        except asyncio.CancelledError:
            pass
        # Give cleanup a moment to finish.
        await asyncio.sleep(0.05)

    asyncio.run(main())
    assert sorted(cleaned) == [0, 1], cleaned
    print("cleanup-on-cancel OK, cleaned =", sorted(cleaned))


if __name__ == "__main__":
    test_cap_and_completion()
    test_cleanup_on_cancel()
    print("all tests passed")