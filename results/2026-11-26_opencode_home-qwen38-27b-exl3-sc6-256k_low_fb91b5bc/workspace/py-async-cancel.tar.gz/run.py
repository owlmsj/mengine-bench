"""Async task runner: run zero-argument callables that return awaitables,
bounded to max_concurrent jobs at once, with cancellation-safe cleanup."""

import asyncio


async def run_tasks(tasks, max_concurrent):
    """Run each task (a zero-arg callable returning an awaitable) as a job.

    At most max_concurrent jobs run at once. Returns when every job is done.
    If the run is cancelled (e.g. Ctrl+C), every running job is cancelled and
    awaited so its cleanup code (finally blocks, context managers) runs before
    run_tasks returns.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent!r}")

    sem = asyncio.Semaphore(max_concurrent)
    running = set()

    async def run_one(task):
        async with sem:
            job = task()
            running.add(job)
            try:
                return await job
            finally:
                running.discard(job)

    try:
        return await asyncio.gather(*(run_one(t) for t in tasks))
    except BaseException:
        # Cancellation (or any failure): stop the jobs and let their cleanup
        # code run before propagating.
        for job in list(running):
            job.cancel()
        if running:
            await asyncio.gather(*running, return_exceptions=True)
        raise