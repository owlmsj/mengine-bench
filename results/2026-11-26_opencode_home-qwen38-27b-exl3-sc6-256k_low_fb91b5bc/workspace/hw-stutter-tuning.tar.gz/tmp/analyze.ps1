[Console]::OutputEncoding = [Text.Encoding]::UTF8
$inv = [CultureInfo]::InvariantCulture
$p = '<WORKSPACE>\capture\presentmon.csv'
$rows = Import-Csv $p
$times = [double[]]($rows | ForEach-Object { [double]::Parse($_.MsBetweenPresents, $inv) })
$avgMs = ($times | Measure-Object -Average).Average
$avgFps = 1000.0 / $avgMs
$s = [double[]]($times | Sort-Object)
$n = $s.Length
$idx = 0.99 * ($n - 1)
$lo = [math]::Floor($idx); $hi = [math]::Ceiling($idx); $frac = $idx - $lo
$p99 = $s[$lo] + ($s[$hi] - $s[$lo]) * $frac
$low1 = 1000.0 / $p99
Write-Output ("frames={0} avgMs={1} avgFps={2} p99Ms={3} low1={4}" -f $n, $avgMs.ToString('F3',$inv), $avgFps.ToString('F2',$inv), $p99.ToString('F3',$inv), $low1.ToString('F2',$inv))
$hitch = $rows | Where-Object { [double]::Parse($_.MsBetweenPresents, $inv) -gt 33 }
Write-Output ("hitchCount={0}" -f $hitch.Count)
$hitch | ForEach-Object { Write-Output (("{0} {1}" -f $_.TimeInSeconds, $_.MsBetweenPresents)) }