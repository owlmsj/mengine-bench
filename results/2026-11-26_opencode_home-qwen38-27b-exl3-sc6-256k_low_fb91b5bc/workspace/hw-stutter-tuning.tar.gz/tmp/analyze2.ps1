[Console]::OutputEncoding = [Text.Encoding]::UTF8
$inv = [CultureInfo]::InvariantCulture
$p = '<WORKSPACE>\capture\presentmon.csv'
$rows = Import-Csv $p | ForEach-Object { [pscustomobject]@{ t=[double]::Parse($_.TimeInSeconds,$inv); ms=[double]::Parse($_.MsBetweenPresents,$inv) } }
$worst = $rows | Sort-Object ms -Descending | Select-Object -First 30
$worst | ForEach-Object { Write-Output (("{0:F2} {1:F2}" -f $_.t, $_.ms)) }
Write-Output '--- histogram of ms buckets ---'
$groups = $rows | Group-Object { [math]::Floor($_.ms / 10) * 10 } | Sort-Object Name
$groups | ForEach-Object { Write-Output (("{0}-{1}ms: {2}" -f $_.Name, ([int]$_.Name + 10), $_.Count)) }