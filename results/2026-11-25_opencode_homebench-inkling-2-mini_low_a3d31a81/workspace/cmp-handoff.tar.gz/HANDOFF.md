# Handoff: local-9b Q5 @ 128k context measurement

Task: measure local-9b Q5 at 128k context for the local model.

State:
- Measured: `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024` gave decode 37.8 t/s, VRAM 7881 MiB.
- Caution: 7881 MiB is the WDDM ceiling; Shared Usage counter shows 1494 MiB spilled. That number does not count. Do not trust the 7881 figure as clean VRAM; verify the counter/spill or rerun in a WDDM-free/clean state before publishing.
- Recipe applied in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json; the download may still have been running / verification pending at handoff.
- Pending: evals README still cites check_vision.ps1, which no longer exists. Update it.
- Unresolved: names of scratchpad temp files flagged "for later"; never confirmed.

How to finish:
1. Confirm the local9 start recipe and profile are consistent; ensure server is up and not mid-download.
2. Re-measure cleanly; record decode t/s and real VRAM (separate from WDDM ceiling and spilled shared usage).
3. Update evals README (remove/replace check_vision.ps1 reference).
4. Review scratchpad temp file names.

Assumptions: workspace is read-only reference plus this file; the scripts/profile paths live outside this workspace and were not re-verified here. No measurement in this handoff beyond the transcript's 37.8 t/s; treat 37.8 t/s as unverified.
