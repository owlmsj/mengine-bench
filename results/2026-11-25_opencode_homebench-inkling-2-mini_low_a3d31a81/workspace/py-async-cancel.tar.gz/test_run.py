import asyncio
from run import run_tasks

async def main():
    running = 0
    peak = 0
    done = []

    async def job(i, delay=0.05):
        nonlocal running, peak
        running += 1
        peak = max(peak, running)
        try:
            await asyncio.sleep(delay)
            done.append(i)
            return i
        finally:
            running -= 1

    results = await run_tasks([lambda i=i: job(i) for i in range(10)], 3)
    assert sorted(results) == list(range(10))
    assert peak <= 3, peak
    assert sorted(done) == list(range(10))
    print("OK peak=%d results=%d" % (peak, len(results)))

asyncio.run(main())
