import asyncio


async def run_tasks(tasks, max_concurrent):
    if max_concurrent < 1:
        raise ValueError("max_concurrent must be >= 1")
    sem = asyncio.Semaphore(max_concurrent)

    async def _run(task):
        async with sem:
            return await task()

    pending = [asyncio.ensure_future(_run(t)) for t in tasks]
    try:
        return await asyncio.gather(*pending)
    except (KeyboardInterrupt, asyncio.CancelledError):
        for p in pending:
            p.cancel()
        await asyncio.gather(*pending, return_exceptions=True)
        raise
