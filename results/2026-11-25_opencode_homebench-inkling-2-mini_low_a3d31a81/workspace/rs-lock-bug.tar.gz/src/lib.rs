//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        *slot.lock().unwrap() += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return;
        }
        let from_slot = self.slot(from);
        let to_slot = self.slot(to);
        // Lock both slots in a consistent order to avoid lock-order deadlock.
        // Lock slots in PlayerId order to avoid lock-order deadlock.
        let (low_id, high_id) = if from < to { (from, to) } else { (to, from) };
        let low_slot = if from == low_id { from_slot.clone() } else { to_slot.clone() };
        let high_slot = if from == high_id { from_slot.clone() } else { to_slot.clone() };
        let mut low_g = low_slot.lock().unwrap();
        let mut high_g = high_slot.lock().unwrap();
        if from == low_id {
            *low_g -= points;
            *high_g += points;
        } else {
            *high_g -= points;
            *low_g += points;
        }
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}
