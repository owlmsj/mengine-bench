import csv, json, math
from collections import Counter

rows = []
with open(r"telemetry/playtest_ab.csv", newline="", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        rows.append(r)

print("total rows:", len(rows))

# normalize variant
def norm(v):
    return v.strip().lower()

# dedupe by session_id, keep first; check conflicts
seen = {}
conflicts = []
dup_count = 0
for r in rows:
    sid = r["session_id"].strip()
    v = norm(r["variant"])
    c = int(r["completed_tutorial"])
    if sid in seen:
        dup_count += 1
        if seen[sid] != (v, c):
            conflicts.append((sid, seen[sid], (v, c)))
    else:
        seen[sid] = (v, c)

print("unique sessions:", len(seen))
print("duplicate rows removed:", dup_count)
print("conflicting duplicates:", conflicts)

a = [c for (v, c) in seen.values() if v == "a"]
b = [c for (v, c) in seen.values() if v == "b"]
other = [v for (v, c) in seen.values() if v not in ("a", "b")]
print("other variants:", Counter(other))

na, nb = len(a), len(b)
ca, cb = sum(a), sum(b)
pa, pb = ca / na, cb / nb
print(f"A: n={na} completed={ca} rate={pa:.6f}")
print(f"B: n={nb} completed={cb} rate={pb:.6f}")
print(f"abs diff B-A = {pb-pa:.6f}")

# two-proportion z-test (pooled), two-sided
p = (ca + cb) / (na + nb)
se = math.sqrt(p * (1 - p) * (1 / na + 1 / nb))
z = (pb - pa) / se
# two-sided p via normal CDF
def norm_cdf(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))
p_two = 2 * (1 - norm_cdf(abs(z)))
p_one = 1 - norm_cdf(z)  # one-sided, B > A
print(f"z = {z:.6f}")
print(f"p two-sided = {p_two:.6f}")
print(f"p one-sided (B>A) = {p_one:.6f}")

# chi-square check (no continuity correction)
table = [[ca, na - ca], [cb, nb - cb]]
tot = na + nb
exp = [[na * ca + na * cb] and None]  # placeholder
# proper chi2
exp_a1 = na * (ca + cb) / tot
exp_a0 = na * tot - na * (ca + cb)
exp_b1 = nb * (ca + cb) / tot
exp_b0 = nb * tot - nb * (ca + cb)
chi2 = (ca - exp_a1) ** 2 / exp_a1 + (na - ca - exp_a0) ** 2 / exp_a0 + \
       (cb - exp_b1) ** 2 / exp_b1 + (nb - cb - exp_b0) ** 2 / exp_b0
print(f"chi2 = {chi2:.6f} (should equal z^2 = {z*z:.6f})")

ship_b = (pb > pa) and (p_two < 0.05)
print("ship_b (two-sided 5%):", ship_b)

result = {
    "ship_b": ship_b,
    "sessions_a": na,
    "sessions_b": nb,
    "completion_rate_a": round(pa, 6),
    "completion_rate_b": round(pb, 6),
    "p_value": round(p_two, 6),
}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))