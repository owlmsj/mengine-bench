# -*- coding: utf-8 -*-
import os, re
from urllib.parse import unquote
site = os.path.join(os.path.dirname(__file__), "..", "site")
files = [f for f in os.listdir(site) if f.lower().endswith(".html")]
keys = {unquote(f)[:-5] for f in files}
targets = {}
for f in files:
    raw = open(os.path.join(site, f), encoding="utf-8").read()
    for sec in ("sinonimos", "analogas"):
        s = re.search(r'<section id="%s">(.*?)</section>' % sec, raw, re.S)
        if s:
            for h in re.findall(r'<a href="([^"]+)">', s.group(1)):
                k = unquote(h)[:-5]
                if k not in keys:
                    targets.setdefault(k, []).append(f)
for k, v in sorted(targets.items()):
    print(repr(k), "<-", sorted(set(v)))