# -*- coding: utf-8 -*-
import json
w = json.load(open(r"<WORKSPACE>\words.json", encoding="utf-8"))
out = {k: len(v) for k, v in w.items()}
inn = {k: 0 for k in w}
for k, v in w.items():
    for t in v:
        inn[t] += 1
deg = {k: out[k] + inn[k] for k in w}
top = sorted(deg.items(), key=lambda kv: (-kv[1], kv[0]))[:5]
print("top:", top)
print("palavra out/in:", out["palavra"], inn["palavra"])
print("tempo out/in:", out["tempo"], inn["tempo"])
# self loops?
print("self loops:", [k for k, v in w.items() if k in v])
# targets missing as keys?
missing = {t for v in w.values() for t in v if t not in w}
print("missing targets:", missing)