# -*- coding: utf-8 -*-
"""Inject words.json + meta.json into template.html -> universe/index.html"""
import json, os
BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "..")
words = json.load(open(os.path.join(OUT, "words.json"), encoding="utf-8"))
meta = json.load(open(os.path.join(BASE, "meta.json"), encoding="utf-8"))
tpl = open(os.path.join(BASE, "template.html"), encoding="utf-8").read()
data = json.dumps({"words": words, "meta": meta}, ensure_ascii=False, separators=(",", ":"))
assert "/*__DATA__*/null" in tpl
html = tpl.replace("/*__DATA__*/null", data)
os.makedirs(os.path.join(OUT, "universe"), exist_ok=True)
open(os.path.join(OUT, "universe", "index.html"), "w", encoding="utf-8").write(html)
print("wrote universe/index.html", len(html), "bytes")