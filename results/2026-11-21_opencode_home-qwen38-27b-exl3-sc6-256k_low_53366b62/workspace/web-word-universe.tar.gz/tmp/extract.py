# -*- coding: utf-8 -*-
import re
html = open(r"<WORKSPACE>\universe\index.html", encoding="utf-8").read()
m = re.search(r'<script type="module">(.*?)</script>', html, re.S)
open(r"<WORKSPACE>\tmp\module.mjs", "w", encoding="utf-8").write(m.group(1))
print("extracted", len(m.group(1)))