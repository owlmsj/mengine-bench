# -*- coding: utf-8 -*-
"""Parse site/ -> words.json + result.json. Resolves redirect pages."""
import json, re, os
from urllib.parse import unquote

BASE = os.path.dirname(os.path.abspath(__file__))
SITE = os.path.join(BASE, "..", "site")
OUT = os.path.join(BASE, "..")

def key_of(href):
    h = unquote(href)
    return h[:-5] if h.lower().endswith(".html") else h

files = sorted(f for f in os.listdir(SITE) if f.lower().endswith(".html"))
pages = {}   # key -> raw html
for fn in files:
    pages[key_of(fn)] = open(os.path.join(SITE, fn), encoding="utf-8").read()

# 1) redirect map: pages with meta refresh
redirects = {}
for k, raw in pages.items():
    m = re.search(r'<meta http-equiv="refresh" content="0; url=([^"]+)"', raw)
    if m:
        redirects[k] = key_of(m.group(1))
print("redirects:", redirects)

def resolve(k):
    seen = set()
    while k in redirects and k not in seen:
        seen.add(k)
        k = redirects[k]
    return k

# 2) word pages: have a tema
words = {}
for k, raw in pages.items():
    t = re.search(r'class="tema">Tema:\s*(.*?)</p>', raw)
    if not t:
        continue
    m = re.search(r"<h1>(.*?)</h1>", raw)
    name = m.group(1).strip() if m else k
    links = {}
    for sec in ("sinonimos", "analogas"):
        s = re.search(r'<section id="%s">(.*?)</section>' % sec, raw, re.S)
        if s:
            for h in re.findall(r'<a href="([^"]+)">', s.group(1)):
                tgt = resolve(key_of(h))
                links.setdefault(tgt, set()).add(sec)
    words[k] = {"name": name, "tema": t.group(1).strip(), "links": {a: sorted(b) for a, b in links.items()},
                "aliases": sorted(a for a, b in redirects.items() if b == k)}

# 3) orphan targets (linked but no page)
orphans = sorted({t for w in words.values() for t in w["links"] if t not in words})
for o in orphans:
    words[o] = {"name": o, "tema": None, "links": {}, "aliases": []}
print("orphans:", orphans)

words_json = {k: sorted(v["links"].keys()) for k, v in sorted(words.items())}
with open(os.path.join(OUT, "words.json"), "w", encoding="utf-8") as f:
    json.dump(words_json, f, ensure_ascii=False, indent=1)

meta = {k: {"name": v["name"], "tema": v["tema"], "aliases": v["aliases"],
            "typed": {t: s for t, s in v["links"].items()}} for k, v in words.items()}
with open(os.path.join(OUT, "tmp", "meta.json"), "w", encoding="utf-8") as f:
    json.dump(meta, f, ensure_ascii=False, indent=1)

pairs = set()
for k, v in words_json.items():
    for t in v:
        pairs.add(tuple(sorted((k, t))))
deg = {k: 0 for k in words_json}
for a, b in pairs:
    deg[a] += 1
    deg[b] += 1
top = sorted(deg.items(), key=lambda kv: (-kv[1], kv[0]))
result = {"words": len(words_json), "relations": len(pairs), "most_connected": top[0][0]}
with open(os.path.join(OUT, "result.json"), "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=1)

print("words:", len(words_json), "relations:", len(pairs))
print("top:", top[:6])
print("saudade:", words_json["saudade"])
print("saudade meta:", meta["saudade"])