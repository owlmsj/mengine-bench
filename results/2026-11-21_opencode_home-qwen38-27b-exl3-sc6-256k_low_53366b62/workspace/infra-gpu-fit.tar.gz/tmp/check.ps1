$kv = 327680 * 32768 * 4 / 1e9
$tot = 70 + $kv + 8
"kv=$kv"
"total=$tot"
"monthly=" + (3.58*730)