//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        // Single lock per read-modify-write so concurrent awards cannot
        // lose updates (the old code read, released, then wrote).
        let slot = self.slot(id);
        *slot.lock().unwrap() += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        // Self-transfer is a no-op; locking the same slot twice would
        // deadlock (std Mutex is not reentrant).
        if from == to {
            return;
        }
        // Lock slots in a consistent (ascending id) order so that
        // transfer(a, b) and transfer(b, a) from different threads
        // cannot deadlock each other.
        let (lo, hi) = if from < to { (from, to) } else { (to, from) };
        let lo_slot = self.slot(lo);
        let hi_slot = self.slot(hi);
        let mut lo_score = lo_slot.lock().unwrap();
        let mut hi_score = hi_slot.lock().unwrap();
        if from < to {
            *lo_score -= points;
            *hi_score += points;
        } else {
            *lo_score += points;
            *hi_score -= points;
        }
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}
