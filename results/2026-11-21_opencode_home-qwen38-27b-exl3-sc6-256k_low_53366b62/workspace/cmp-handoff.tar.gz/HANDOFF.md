# HANDOFF — local-9b @ 128k context

## Done
- Measured local-9b Q5 at Ctx 131072, 1024 predict: 37.8 t/s, VRAM 7881 MiB — but 7881 is the WDDM ceiling and Shared Usage showed 1494 MiB spilled, so that number does not count.
- Root cause fixed: `--no-mmproj-offload` + `-ub 512` removes the spill → 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k — discarded. Q4_K_M (7305 MiB, 40.4 t/s) kept only as fallback.
- Recipe applied in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

## Left
1. evals README still cites check_vision.ps1 — the file no longer exists; update it.
2. Review the names of the scratchpad temp files (noted repeatedly, never done).

## Verify
`pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024` → expect ~38 t/s, VRAM ~7697 MiB, no Shared Usage spill.