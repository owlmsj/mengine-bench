import csv, json

rows = list(csv.DictReader(open(r'capture/presentmon.csv')))
mbp = [float(r['MsBetweenPresents']) for r in rows]
n = len(mbp)
avg_fps = round(1000.0 / (sum(mbp) / n), 2)
srt = sorted(mbp)
p99 = srt[int(0.99 * (n - 1))]
low1 = round(1000.0 / p99, 2)

result = {
    "avg_fps": avg_fps,
    "low_1pct_fps": low1,
    "cause": "The GPU's PCIe link periodically drops into the ASPM L1 low-power state (BIOS setting pcie_aspm_rp1_gpu = L1). The sensor log shows the link in L1 at seconds 2, 6, 10, ..., 58 (every 4 s), and each L1 entry starts a burst of ~11 frames at ~21-23 ms (vs ~7 ms normal): the 177 slow frames all fall inside those bursts. L1 exit latency stalls GPU traffic, producing the periodic hitches and the poor 1% lows while the average FPS stays high.",
    "changes": [
        {"setting": "pcie_aspm_rp1_gpu", "from": "L1", "to": "disabled"}
    ]
}
with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
print(json.dumps(result, indent=2))