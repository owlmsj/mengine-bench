import csv, statistics

# --- PresentMon ---
rows = list(csv.DictReader(open(r'capture/presentmon.csv')))
mbp = [float(r['MsBetweenPresents']) for r in rows]
n = len(mbp)
avg_fps = 1000.0 / (sum(mbp) / n)
srt = sorted(mbp)
p99 = srt[int(0.99 * (n - 1))]
low1 = 1000.0 / p99
print(f"frames={n} avg_fps={avg_fps:.2f} p99_ms={p99:.3f} low1_fps={low1:.2f}")

# hitch events: frame time > 3x median
med = statistics.median(mbp)
hitches = [(i, t, f) for i, (t, f) in enumerate(zip([float(r['TimeInSeconds']) for r in rows], mbp)) if f > 3 * med]
print(f"median_ms={med:.2f} hitches(>3x med)={len(hitches)}")
for i, t, f in hitches[:30]:
    print(f"  t={t:.3f}s frame={i} ms={f:.1f}")

# --- Sensors ---
srows = list(csv.DictReader(open(r'capture/sensors.csv')))
print(f"sensor rows={len(srows)}")
l1 = [(int(r['time_s']), r['gpu_pcie_link_state']) for r in srows if r['gpu_pcie_link_state'] == 'L1']
print(f"L1 seconds={len(l1)}: {[t for t,_ in l1]}")

# correlation: for each hitch, sensor state at that second
import math
for i, t, f in hitches:
    s = int(round(t))
    if s < len(srows):
        r = srows[s]
        print(f"  hitch t={t:.3f} ms={f:.1f} -> sensor t={s}: link={r['gpu_pcie_link_state']} dpc={r['dpc_latency_us']} disk={r['disk_active_pct']} top={r['top_cpu_process']}")

# distribution of frame times
buckets = {}
for f in mbp:
    b = int(f // 5) * 5
    buckets[b] = buckets.get(b, 0) + 1
for b in sorted(buckets):
    print(f"  {b}-{b+5}ms: {buckets[b]}")