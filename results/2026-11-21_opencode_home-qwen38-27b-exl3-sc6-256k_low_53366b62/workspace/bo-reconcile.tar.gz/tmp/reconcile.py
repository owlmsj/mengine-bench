import csv, json, re, os

base = r"<WORKSPACE>"
inv = {}
with open(os.path.join(base, "backoffice", "invoices.csv"), encoding="utf-8") as f:
    for row in csv.DictReader(f):
        inv[row["id"]] = float(row["amount"])

payments = {}  # id -> list of amounts
with open(os.path.join(base, "backoffice", "bank_statement_june.csv"), encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        m = re.search(r"(?:INV[-\s]?|invoice\s*)?(\d{4})", memo)
        if not m:
            continue  # fees, interest, unidentified
        inv_id = "INV-" + m.group(1)
        if inv_id not in inv:
            continue
        payments.setdefault(inv_id, []).append(float(row["amount"]))

unpaid = sorted(i for i in inv if i not in payments)
duplicated = sorted(i for i, a in payments.items() if len(a) > 1)
mismatched = []
for i, a in sorted(payments.items()):
    if len(a) == 1 and abs(a[0] - inv[i]) > 0.005:
        mismatched.append({"id": i, "invoiced": inv[i], "paid": a[0]})

result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
out = os.path.join(base, "result.json")
with open(out, "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
print("paid count:", len(payments), "invoice count:", len(inv))