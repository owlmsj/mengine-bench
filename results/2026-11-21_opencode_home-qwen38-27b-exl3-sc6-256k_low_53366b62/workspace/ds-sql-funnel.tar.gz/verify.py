import sqlite3, json
c = sqlite3.connect('analytics.db')
print('event names:', c.execute("select name, count(*) from events group by name").fetchall())
print('test users:', c.execute("select count(*) from users where is_test=1").fetchone()[0])
print('unknown player events:', c.execute(
    "select count(*) from events e where not exists (select 1 from users u where u.user_id=e.user_id)").fetchone()[0])
print('users per platform:', c.execute("select platform, count(*) from users group by platform").fetchall())
print('test users per platform:', c.execute("select platform, count(*) from users where is_test=1 group by platform").fetchall())

# independent cross-check: per user, step reached = longest valid prefix via SQL
rows = c.execute("""
select u.platform,
  sum(case when e1.ts is not null then 1 else 0 end),
  sum(case when e1.ts is not null and e2.ts is not null and e2.ts>=e1.ts then 1 else 0 end),
  sum(case when e1.ts is not null and e2.ts is not null and e2.ts>=e1.ts
            and e3.ts is not null and e3.ts>=e2.ts then 1 else 0 end),
  sum(case when e1.ts is not null and e2.ts is not null and e2.ts>=e1.ts
            and e3.ts is not null and e3.ts>=e2.ts
            and e4.ts is not null and e4.ts>=e3.ts then 1 else 0 end)
from users u
left join (select user_id, min(ts) ts from events where name='install' group by 1) e1 on e1.user_id=u.user_id
left join (select user_id, min(ts) ts from events where name='tutorial_complete' group by 1) e2 on e2.user_id=u.user_id
left join (select user_id, min(ts) ts from events where name='first_match' group by 1) e3 on e3.user_id=u.user_id
left join (select user_id, min(ts) ts from events where name='purchase' group by 1) e4 on e4.user_id=u.user_id
where u.is_test=0
group by u.platform
""").fetchall()
print('SQL cross-check (platform, install, tut, match, purchase):', rows)
print('result.json on disk:', json.load(open('result.json', encoding='utf-8')))