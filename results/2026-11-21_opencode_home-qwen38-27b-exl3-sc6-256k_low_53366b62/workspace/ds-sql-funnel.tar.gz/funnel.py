import sqlite3, json

STEPS = ["install", "tutorial_complete", "first_match", "purchase"]
c = sqlite3.connect('analytics.db')

users = {uid: (platform, is_test) for uid, platform, is_test in
         c.execute("select user_id, platform, is_test from users")}

# first event time per user per step
first = {}
for uid, name, ts in c.execute("select user_id, name, ts from events"):
    if name not in STEPS:
        continue
    cur = first.get((uid, name))
    if cur is None or ts < cur:
        first[(uid, name)] = ts

funnel = {}  # platform -> {step: players}
biggest = {}  # platform -> step
for uid, (platform, is_test) in users.items():
    if is_test:
        continue
    # walk steps in order; each step needs a first occurrence at/after previous step time
    prev_t = None
    reached = {}
    for s in STEPS:
        t = first.get((uid, s))
        if t is not None and (prev_t is None or t >= prev_t):
            reached[s] = t
            prev_t = t
        else:
            break
    funnel.setdefault(platform, {s: 0 for s in STEPS})
    for s in reached:
        funnel[platform][s] += 1

result = {"funnel": funnel, "biggest_drop": {}}
for platform, counts in funnel.items():
    worst, worst_conv = None, None
    for i in range(1, len(STEPS)):
        prev, cur = counts[STEPS[i-1]], counts[STEPS[i]]
        conv = (cur / prev) if prev else 0.0
        if worst_conv is None or conv < worst_conv:
            worst_conv, worst = conv, STEPS[i]
    result["biggest_drop"][platform] = worst

with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))