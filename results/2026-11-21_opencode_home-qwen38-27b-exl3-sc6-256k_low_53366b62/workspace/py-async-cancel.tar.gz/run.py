"""Concurrency helper: run awaitable-returning tasks with a bound on concurrency.

Usage:
    from run import run_tasks
    await run_tasks([make_job_1, make_job_2, ...], max_concurrent=4)

Each task is a zero-argument callable that returns an awaitable (e.g. a
coroutine). At most ``max_concurrent`` jobs run at the same time. The function
returns once every job has finished.

Ctrl+C behaviour: when the run is interrupted, asyncio cancels the main task,
which cancels every in-flight job. Cancellation is delivered at the next
``await`` and ``finally`` blocks run on cancellation, so each job's cleanup
code executes before the run unwinds.
"""

from __future__ import annotations

import asyncio


async def run_tasks(tasks, max_concurrent):
    """Run ``tasks`` with at most ``max_concurrent`` jobs in flight.

    Args:
        tasks: iterable of zero-argument callables; each returns an awaitable.
        max_concurrent: maximum number of jobs allowed to run at once (>= 1).

    Returns:
        The list of job results, in the same order as ``tasks``.

    On cancellation (e.g. Ctrl+C) every in-flight job is cancelled and its
    cleanup (``finally``) code runs before this returns.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent!r}")

    sem = asyncio.Semaphore(max_concurrent)

    async def _run(task):
        async with sem:
            return await task()

    return await asyncio.gather(*(_run(t) for t in tasks))