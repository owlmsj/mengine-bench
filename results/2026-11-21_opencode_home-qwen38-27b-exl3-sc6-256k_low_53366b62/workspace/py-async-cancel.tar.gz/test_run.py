import asyncio
import run


async def test_concurrency_bound():
    running = 0
    max_seen = 0

    def make_job(i):
        async def job():
            nonlocal running, max_seen
            running += 1
            max_seen = max(max_seen, running)
            try:
                await asyncio.sleep(0.01)
                return i
            finally:
                running -= 1
        return job

    tasks = [make_job(i) for i in range(10)]
    out = await run.run_tasks(tasks, max_concurrent=3)
    assert sorted(out) == list(range(10)), out
    assert max_seen <= 3, max_seen
    assert max_seen == 3, max_seen  # should actually hit the bound
    print("concurrency bound OK, max_seen =", max_seen)


async def test_cleanup_on_cancel():
    # Simulates Ctrl+C: asyncio.run cancels the main task on KeyboardInterrupt.
    cleaned = []

    def make_job(i):
        async def job():
            try:
                await asyncio.sleep(10)
            finally:
                cleaned.append(i)
        return job

    async def main():
        task = asyncio.ensure_future(run.run_tasks([make_job(i) for i in range(4)], 2))
        await asyncio.sleep(0.05)
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        return cleaned

    cleaned = await main()
    # 2 jobs were running -> their finally ran. 2 were waiting on the
    # semaphore and never started -> no cleanup.
    assert len(cleaned) == 2, cleaned
    print("cleanup on cancel OK, cleaned =", sorted(cleaned))


async def test_empty():
    out = await run.run_tasks([], 4)
    assert out == [], out
    print("empty OK")


async def test_invalid():
    try:
        await run.run_tasks([], 0)
    except ValueError:
        print("invalid max_concurrent OK")
    else:
        raise AssertionError("expected ValueError")


asyncio.run(test_concurrency_bound())
asyncio.run(test_cleanup_on_cancel())
asyncio.run(test_empty())
asyncio.run(test_invalid())
print("ALL TESTS PASSED")