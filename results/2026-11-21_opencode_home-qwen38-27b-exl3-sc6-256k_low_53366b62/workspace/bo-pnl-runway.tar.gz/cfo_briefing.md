# H1 2026 close — CFO briefing

Source: finance/ledger.csv (86 entries, Jan–Jun 2026), chart_of_accounts.csv,
cash_balance.txt, README.md (board's burn/runway definitions).

## Monthly P&L (R$, accrual, from ledger)

| Month   | Revenue   | Gross margin | EBITDA     |
|---------|-----------|--------------|------------|
| 2026-01 | 200,510.87 | 70.03%      | -210,278.96 |
| 2026-02 | 216,328.06 | 70.29%      | -212,300.08 |
| 2026-03 | 219,066.17 | 68.46%      | -204,525.45 |
| 2026-04 | 238,163.26 | 70.24%      | -196,950.65 |
| 2026-05 | 243,032.89 | 69.56%      | -201,945.82 |
| 2026-06 | 272,391.57 | 72.41%      | -192,968.22 |

## Cash and runway
- Cash 31/05/2026: R$ 2,309,188.00
- Cash 30/06/2026 (latest close): R$ 1,847,350.40
- Burn (board definition: average monthly negative EBITDA of the last three
  closed months, Apr–Jun): R$ 197,288.23/month
- Runway = 1,847,350.40 / 197,288.23 = 9.36 months (≈ mid-September 2027)

## Assumptions
- Revenue nets refunds (3.1.09) per chart of accounts.
- EBITDA = revenue + COGS + S&M + R&D + G&A; financial items (6.x) excluded.
- Ledger amounts are signed (expenses negative); gross margin = (rev + COGS)/rev.
- June cash drop (R$ 461.8k) exceeds June EBITDA loss (R$ 193.0k): the gap is
  working-capital/other movements not itemized in this P&L ledger; runway uses
  the board's definition (closing cash / burn), per README.