import csv, json
from collections import defaultdict

base = r"<WORKSPACE>\finance"

coa = {}
with open(f"{base}/chart_of_accounts.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        coa[row["account"]] = row["pnl_line"]

months = ["2026-01","2026-02","2026-03","2026-04","2026-05","2026-06"]
tot = {m: defaultdict(float) for m in months}

with open(f"{base}/ledger.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        d = row["date"].strip()
        dd, mm, yy = d.split("/")
        m = f"{yy}-{mm}"
        amt = float(row["amount"].replace(".", "").replace(",", "."))
        line = coa[row["account"].strip()]
        tot[m][line] += amt

out = {"revenue": {}, "gross_margin_pct": {}, "ebitda": {}}
for m in months:
    t = tot[m]
    rev = t["revenue"]
    cogs = t["cogs"]
    opex = t["sales_marketing"] + t["rnd"] + t["ga"]
    ebitda = rev + cogs + opex  # expense lines are negative in the ledger
    out["revenue"][m] = round(rev, 2)
    out["gross_margin_pct"][m] = round((rev + cogs) / rev * 100, 2)
    out["ebitda"][m] = round(ebitda, 2)

# Burn: average monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = [tot[m]["revenue"] + tot[m]["cogs"] + tot[m]["sales_marketing"] + tot[m]["rnd"] + tot[m]["ga"]
         for m in ["2026-04","2026-05","2026-06"]]
burn = -sum(last3) / 3
cash = 1847350.40  # consolidated balance 30/06/2026
runway = cash / burn
out["burn"] = round(burn, 2)
out["runway_months"] = round(runway, 2)

with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2)

print(json.dumps(out, indent=2))
print("last3 EBITDA:", [round(x,2) for x in last3])