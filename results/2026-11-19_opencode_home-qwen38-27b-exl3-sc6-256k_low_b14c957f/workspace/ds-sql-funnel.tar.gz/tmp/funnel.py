import sqlite3, json
from collections import defaultdict

c = sqlite3.connect('analytics.db')
users = {uid: (plat, test) for uid, plat, test in c.execute("select user_id, platform, is_test from users")}
events = defaultdict(list)
for uid, name, ts in c.execute("select user_id, name, ts from events"):
    events[uid].append((ts, name))

steps = ['install', 'tutorial_complete', 'first_match', 'purchase']
funnel = defaultdict(lambda: [0]*4)
for uid, (plat, test) in users.items():
    if test:
        continue
    evs = sorted(events[uid])
    prev = None
    for i, s in enumerate(steps):
        t = None
        for ts, name in evs:
            if name == s and (prev is None or ts >= prev):
                t = ts
                break
        if t is None:
            break
        funnel[plat][i] += 1
        prev = t

result = {
    'funnel': {p: dict(zip(steps, v)) for p, v in sorted(funnel.items())},
    'biggest_drop': {},
}
for p, v in funnel.items():
    convs = [(steps[i+1], v[i+1]/v[i]) for i in range(3) if v[i] > 0]
    result['biggest_drop'][p] = min(convs, key=lambda x: x[1])[0]

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
for p, v in funnel.items():
    print(p, v, [round(v[i+1]/v[i],3) if v[i] else None for i in range(3)])