import sqlite3
c = sqlite3.connect('analytics.db')
for name, sql in c.execute("select name, sql from sqlite_master where type='table'"):
    print(sql, end='\n\n')
for (t,) in c.execute("select name from sqlite_master where type='table'"):
    print(t, c.execute(f'select count(*) from "{t}"').fetchone())
    for row in c.execute(f'select * from "{t}" limit 5'):
        print(row)
    print()