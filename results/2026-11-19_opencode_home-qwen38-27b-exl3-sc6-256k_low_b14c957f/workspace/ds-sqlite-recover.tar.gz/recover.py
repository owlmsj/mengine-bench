import json

data = open('prices.db','rb').read()

def varint(buf, i):
    v = 0
    for n in range(9):
        b = buf[i]; i += 1
        if n == 8:
            return (v << 8) | b, i
        v = (v << 7) | (b & 0x7F)
        if not b & 0x80:
            return v, i

def parse_record(buf, i):
    hdr_len, i = varint(buf, i)
    hdr_end = i
    serials = []
    j = i
    while j < hdr_end:
        s, j = varint(buf, j)
        serials.append(s)
    vals = []
    j = hdr_end
    for s in serials:
        if s == 0:
            vals.append(None)
        elif 1 <= s <= 6:
            n = {1:1,2:2,3:3,4:4,5:6,6:8}[s]
            vals.append(int.from_bytes(buf[j:j+n],'big',signed=True)); j += n
        elif s == 8:
            vals.append(0)
        elif s == 9:
            vals.append(1)
        elif s >= 13 and s % 2 == 1:
            n = (s-13)//2
            vals.append(buf[j:j+n].decode('utf-8','replace')); j += n
        elif s >= 12 and s % 2 == 0:
            n = (s-12)//2
            vals.append(buf[j:j+n]); j += n
        else:
            vals.append(None)
    return vals

rows = []
i = 0
n = len(data)
while i < n - 4:
    pl = data[i]
    if not (5 <= pl <= 64):
        i += 1; continue
    rowid, i2 = varint(data, i+1)
    if rowid > 100000:
        i += 1; continue
    hdr_len = data[i2]
    if not (2 <= hdr_len <= 12):
        i += 1; continue
    j = i2+1
    serials = []
    ok = True
    while j < i2+1+hdr_len:
        s, j = varint(data, j)
        if not (s == 0 or 1 <= s <= 9 or s >= 12):
            ok = False; break
        serials.append(s)
    if not ok or j != i2+1+hdr_len:
        i += 1; continue
    # find exactly one text (odd>=13) and one int (0..9) among serials
    texts = [s for s in serials if s >= 13 and s % 2 == 1]
    ints = [s for s in serials if s in (0,1,2,3,4,5,6,8,9)]
    if len(texts) != 1 or len(ints) != 1:
        i += 1; continue
    tl = texts[0]; il = ints[0]
    textlen = (tl-13)//2
    intlen = {0:0,1:1,2:2,3:3,4:4,5:6,6:8,8:0,9:0}[il]
    end = i2+1+hdr_len+textlen+intlen
    if end > n:
        i += 1; continue
    vals = parse_record(data, i2)
    item = next(v for v in vals if isinstance(v, str))
    price = next(v for v in vals if isinstance(v, int))
    if not item.strip():
        i += 1; continue
    rows.append({'item': item, 'price': price})
    i = end

print(json.dumps(rows, indent=1))
with open('recovered.json','w',encoding='utf-8') as f:
    json.dump(rows, f, ensure_ascii=False, indent=1)