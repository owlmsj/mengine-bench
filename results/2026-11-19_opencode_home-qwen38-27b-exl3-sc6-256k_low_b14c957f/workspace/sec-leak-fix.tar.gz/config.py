"""Settings for the backup agent."""

import os

API_URL = "https://backup.example.invalid/v1/upload"
# The API token is read from the environment (BACKUP_TOKEN); it is never
# stored in code or printed to logs.
API_TOKEN = [REDACTED:env]"BACKUP_TOKEN", "")
ARCHIVE_DIR = "archives"