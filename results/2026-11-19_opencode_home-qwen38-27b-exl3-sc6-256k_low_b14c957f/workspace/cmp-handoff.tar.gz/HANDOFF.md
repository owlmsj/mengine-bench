# Handoff: local-9b @ 128k

## Done
- Measured local-9b Q5_K at 128k (measure_decode.ps1 -Ctx 131072 -NPredict 1024): 37.8 t/s, 7881 MiB.
- Root cause of VRAM ceiling: mmproj offload. With `--no-mmproj-offload` + `-ub 512`: 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) doesn't fit at 128k, discarded. Q4_K_M fits (7305 MiB, 40.4 t/s), fallback only.
- Recipe applied: scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

## Remaining
1. Evals README still cites check_vision.ps1, which no longer exists.
2. Review scratchpad temp file names (noted repeatedly, never done).

## Assumptions
- "Q5" = the Q5_K GGUF in the local model dir (only Q5 variant).
- 128k = 131072; decode at 1024 predicted tokens.
- 7881 MiB is the WDDM ceiling; the 1494 MiB Shared Usage spill is a counter artifact, discounted.

## How I know it's right
- Post-fix numbers are median of 3 runs, not one sample.
- Spill vanishes exactly when mmproj offload is disabled: causality confirmed.
- Recipe is in both launch paths (script + profile), so it persists.