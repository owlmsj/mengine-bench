"""Run a batch of async jobs with a concurrency limit.

Usage:
    from run import run_tasks
    await run_tasks([job_factory, ...], max_concurrent=4)

Each task is a zero-argument callable returning an awaitable.
At most max_concurrent run at the same time.

On Ctrl+C (the running task is cancelled), every job's cleanup code
(finally blocks) still runs before run_tasks re-raises.

Requires Python 3.11+ (Task.uncancel).
"""

import asyncio


async def run_tasks(tasks, max_concurrent):
    sem = asyncio.Semaphore(max_concurrent)
    results = [None] * len(tasks)

    async def _run(i, task):
        async with sem:
            results[i] = await task()

    tasks_ = [asyncio.ensure_future(_run(i, t)) for i, t in enumerate(tasks)]
    try:
        await asyncio.gather(*tasks_)
    except (asyncio.CancelledError, KeyboardInterrupt):
        # Cancel every job that has not finished yet so its cleanup runs.
        for t in tasks_:
            if not t.done():
                t.cancel()
        # We are ourselves cancelled, so a plain await would raise
        # CancelledError again.  Remove our own cancellation, wait for
        # all cleanups to finish, then re-raise.
        me = asyncio.current_task()
        me.uncancel()
        await asyncio.gather(*tasks_, return_exceptions=True)
        raise

    return results