from PIL import Image
im = Image.open('launch.jpg')
crop = im.crop((1400, 0, 3000, 2000))
out = crop.resize((1080, 1350), Image.LANCZOS)
out.save('out/feed-photo.jpg', quality=90)
print(out.size)