import pypdf
from PIL import Image
import numpy as np

# feed photo
im = Image.open('out/feed-photo.jpg')
print('feed', im.size, im.format)
a = np.array(im)
mask = (a[:,:,0]>150) & (a[:,:,1]<120) & (a[:,:,2]>150)
ys, xs = np.where(mask)
print('balloon px in output:', len(xs))
print('x', xs.min(), xs.max(), 'y', ys.min(), ys.max())
assert xs.min() >= 0 and xs.max() < im.size[0] and ys.min() >= 0 and ys.max() < im.size[1]

# pdf
r = pypdf.PdfReader('out/permit-filled.pdf')
p = r.pages[0]
annots = p.get('/Annots')
print('annots:', len(annots) if annots else 0)
text = p.extract_text()
print('---text---')
print(text)
for k in ['Tidewater Studio', '5 December 2026', 'North Cove Lawn', '40']:
    assert k in text, k
print('OK')