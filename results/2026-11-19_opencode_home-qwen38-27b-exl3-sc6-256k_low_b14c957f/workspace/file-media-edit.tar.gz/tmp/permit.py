import io, pypdf
from pypdf.generic import NameObject, TextStringObject, ArrayObject, NumberObject

def esc(s):
    return s.replace('\\', r'\\').replace('(', r'\(').replace(')', r'\)')

def overlay_pdf(text, x, y, w, h):
    # minimal 1-page PDF, page size 1x1 pt, text drawn at (x,y) with 10pt font
    content = f"BT /F1 10 Tf {x} {y} Td ({esc(text)}) Tj ET".encode()
    objs = []
    objs.append(b"<< /Type /Catalog /Pages 2 0 R >>")
    objs.append(b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>")
    objs.append(b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 1 1] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>")
    objs.append(b"<< /Length " + str(len(content)).encode() + b" >>\nstream\n" + content + b"\nendstream")
    objs.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
    out = io.BytesIO()
    out.write(b"%PDF-1.4\n")
    offsets = []
    for i, o in enumerate(objs, 1):
        offsets.append(out.tell())
        out.write(f"{i} 0 obj\n".encode())
        out.write(o)
        out.write(b"\nendobj\n")
    xref = out.tell()
    out.write(f"xref\n0 {len(objs)+1}\n".encode())
    out.write(b"0000000000 65535 f \n")
    for off in offsets:
        out.write(f"{off:010d} 00000 n \n".encode())
    out.write(f"trailer\n<< /Size {len(objs)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF".encode())
    return out.getvalue()

r = pypdf.PdfReader('permit-form.pdf')
w = pypdf.PdfWriter()
w.append(r)
vals = {'organizer': 'Tidewater Studio', 'event_date': 'Saturday 5 December 2026',
        'location': 'North Cove Lawn', 'attendees': 'about 40'}
page = w.pages[0]
# fill values
for f in page.get('/Annots', []):
    fo = f.get_object()
    t = fo.get('/T')
    if t in vals:
        fo.update({NameObject('/V'): TextStringObject(vals[t])})
        fo.update({NameObject('/AS'): TextStringObject(vals[t])})
# flatten: overlay text, then remove annots
for f in list(page.get('/Annots', [])):
    fo = f.get_object()
    t = fo.get('/T')
    if t not in vals:
        continue
    rect = fo.get('/Rect')
    x, y, x2, y2 = (float(v) for v in rect)
    ov = pypdf.PdfReader(io.BytesIO(overlay_pdf(vals[t], x + 4, y + 4, x2 - x, y2 - y)))
    page.merge_page(ov.pages[0])
    annots = page['/Annots']
    annots.remove(f)
with open('out/permit-filled.pdf', 'wb') as fh:
    w.write(fh)
print('done')