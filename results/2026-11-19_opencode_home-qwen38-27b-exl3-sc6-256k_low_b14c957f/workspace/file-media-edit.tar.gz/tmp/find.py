from PIL import Image
import numpy as np
im = Image.open('launch.jpg')
a = np.array(im)
mask = (a[:,:,0]>150) & (a[:,:,1]<120) & (a[:,:,2]>150)
ys, xs = np.where(mask)
print(len(xs))
print('x', xs.min(), xs.max(), 'y', ys.min(), ys.max())
print('cx', xs.mean(), 'cy', ys.mean())