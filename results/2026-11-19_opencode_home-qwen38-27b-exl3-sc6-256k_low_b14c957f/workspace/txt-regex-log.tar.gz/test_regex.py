import re

pattern = open('regex.txt').read().strip()
print("Pattern:", pattern)
print()

# Test 1: the actual server.log
log = open('server.log').read()
result = re.findall(pattern, log, re.MULTILINE)
print("server.log result:", result)
# Expected: line1 has IP 10.12.0.7, last date 2026-04-01
# line2 no IP -> nothing
# line3 has IP 192.168.40.3, last date 2026-04-05
# line4 no IP -> nothing
# line5 has IP 172.20.1.14, no other date -> nothing (the 2026-04-02 at start is a date but it's the only date, so last date = 2026-04-02)
# Wait: line5 "2026-04-02 07:19:30 ERROR upstream 172.20.1.14 refused handshake"
# The only date is 2026-04-02 at the start. Last date on line = 2026-04-02.
expected = ['2026-04-01', '2026-04-05', '2026-04-02']
print("Expected:      ", expected)
print("PASS" if result == expected else "FAIL")
print()

# Test 2: edge cases
tests = [
    # (line, expected_match or None)
    ("2026-04-02 INFO 10.0.0.1 done 2026-04-03", "2026-04-03"),  # last date
    ("2026-04-02 INFO no ip here 2026-04-03", None),  # no IP
    ("2026-04-02 INFO 999.0.0.1 bad ip", None),  # invalid IP
    ("2026-04-02 INFO 01.0.0.1 leading zero", None),  # leading zero
    ("2026-04-02 INFO 1.0.0.1 ok 2026-02-29", "2026-02-29"),  # Feb 29 allowed every year
    ("2026-04-02 INFO 1.0.0.1 ok 2026-02-30", None),  # Feb 30 invalid
    ("2026-04-02 INFO 1.0.0.1 ok 2026-13-01", None),  # month 13 invalid
    ("2026-04-02 INFO 1.0.0.1 ok 2026-00-15", None),  # month 00 invalid
    ("2026-04-02 INFO 1.0.0.1 ok 2026-04-32", None),  # day 32 invalid
    ("2026-04-02 INFO 1.0.0.1 ok 2026-04-00", None),  # day 00 invalid
    ("2026-04-02 INFO x1.0.0.1 letter before", None),  # letter before IP
    ("2026-04-02 INFO 1.0.0.1x letter after", None),  # letter after IP
    ("2026-04-02 INFO 1.0.0.12 digit after", None),  # digit after IP
    ("2026-04-02 INFO 12.0.0.1 digit before", None),  # digit before IP
    ("2026-04-02 INFO 1.0.0.1 ok 2026-04-01x", None),  # letter after date
    ("2026-04-02 INFO 1.0.0.1 ok x2026-04-01", None),  # letter before date
    ("2026-04-02 INFO 1.0.0.1 ok 2026-04-012", None),  # digit after date
    ("2026-04-02 INFO 1.0.0.1 ok 12026-04-01", None),  # digit before date
    ("2026-04-02 INFO 255.255.255.255 max ip 2026-12-31", "2026-12-31"),  # max IP, max date
    ("2026-04-02 INFO 0.0.0.0 min ip 2026-01-01", "2026-01-01"),  # min IP, min date
    ("2026-04-02 INFO 256.0.0.1 over 255", None),  # 256 invalid
    ("2026-04-02 INFO 1.2.3.4.5 five parts", None),  # five parts
    ("2026-04-02 INFO 1.2.3 four parts", None),  # four parts
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-29 2026-02-28", "2026-02-28"),  # last date
    ("2026-04-02 INFO 1.2.3.4 ok 2026-04-31", "2026-04-31"),  # Apr 31 invalid -> no date match, but line has IP
    # Actually 2026-04-31 is not a valid date so no date found -> None
    # Let me reconsider: the line has an IP but no valid date -> should give nothing
    ("2026-04-02 INFO 1.2.3.4 ok 2026-04-31", None),  # corrected
    ("2026-04-02 INFO 1.2.3.4 ok 2026-06-31", None),  # Jun 31 invalid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-06-30", "2026-06-30"),  # Jun 30 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-09-30", "2026-09-30"),  # Sep 30 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-09-31", None),  # Sep 31 invalid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-11-30", "2026-11-30"),  # Nov 30 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-11-31", None),  # Nov 31 invalid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-01-31", "2026-01-31"),  # Jan 31 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-12-31", "2026-12-31"),  # Dec 31 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-29", "2026-02-29"),  # Feb 29 allowed every year per brief
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-28", "2026-02-28"),  # Feb 28 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-27", "2026-02-27"),  # Feb 27 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-26", "2026-02-26"),  # Feb 26 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-25", "2026-02-25"),  # Feb 25 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-24", "2026-02-24"),  # Feb 24 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-23", "2026-02-23"),  # Feb 23 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-22", "2026-02-22"),  # Feb 22 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-21", "2026-02-21"),  # Feb 21 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-20", "2026-02-20"),  # Feb 20 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-19", "2026-02-19"),  # Feb 19 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-18", "2026-02-18"),  # Feb 18 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-17", "2026-02-17"),  # Feb 17 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-16", "2026-02-16"),  # Feb 16 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-15", "2026-02-15"),  # Feb 15 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-14", "2026-02-14"),  # Feb 14 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-13", "2026-02-13"),  # Feb 13 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-12", "2026-02-12"),  # Feb 12 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-11", "2026-02-11"),  # Feb 11 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-10", "2026-02-10"),  # Feb 10 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-09", "2026-02-09"),  # Feb 09 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-08", "2026-02-08"),  # Feb 08 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-07", "2026-02-07"),  # Feb 07 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-06", "2026-02-06"),  # Feb 06 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-05", "2026-02-05"),  # Feb 05 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-04", "2026-02-04"),  # Feb 04 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-03", "2026-02-03"),  # Feb 03 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-02", "2026-02-02"),  # Feb 02 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-01", "2026-02-01"),  # Feb 01 valid
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-00", None),  # Feb 00 invalid
    # multiple IPs
    ("2026-04-02 INFO 1.2.3.4 and 5.6.7.8 done 2026-04-05", "2026-04-05"),
    # IP at start of line
    ("1.2.3.4 2026-04-02 ok 2026-04-03", "2026-04-03"),
    # IP at end of line
    ("2026-04-02 ok 1.2.3.4", "2026-04-02"),
    # date at start of line
    ("2026-04-02 1.2.3.4 ok", "2026-04-02"),
    # date at end of line
    ("2026-04-02 1.2.3.4 ok 2026-04-03", "2026-04-03"),
    # no date at all but has IP
    ("2026-04-02 1.2.3.4 no other dates", "2026-04-02"),
    # only timestamp-like, no real date besides the log date
    ("2026-04-02 07:15:09 1.2.3.4", "2026-04-02"),
    # 1900s dates
    ("2026-04-02 INFO 1.2.3.4 ok 1999-12-31", "1999-12-31"),
    # 2000s dates
    ("2026-04-02 INFO 1.2.3.4 ok 2000-01-01", "2000-01-01"),
    # year 2099
    ("2026-04-02 INFO 1.2.3.4 ok 2099-06-15", "2099-06-15"),
    # year 1900
    ("2026-04-02 INFO 1.2.3.4 ok 1900-01-01", "1900-01-01"),
    # year 1899 - not 19xx or 20xx
    ("2026-04-02 INFO 1.2.3.4 ok 1899-01-01", None),
    # year 2100 - not 19xx or 20xx
    ("2026-04-02 INFO 1.2.3.4 ok 2100-01-01", None),
    # IP with leading zero in one part
    ("2026-04-02 INFO 1.02.3.4 bad", None),
    ("2026-04-02 INFO 1.2.03.4 bad", None),
    ("2026-04-02 INFO 1.2.3.04 bad", None),
    ("2026-04-02 INFO 01.2.3.4 bad", None),
    # valid: single digit parts
    ("2026-04-02 INFO 1.2.3.4 ok 2026-05-01", "2026-05-01"),
    # valid: 100.x
    ("2026-04-02 INFO 100.2.3.4 ok 2026-05-01", "2026-05-01"),
    # valid: 199.x
    ("2026-04-02 INFO 199.2.3.4 ok 2026-05-01", "2026-05-01"),
    # valid: 249.x
    ("2026-04-02 INFO 249.2.3.4 ok 2026-05-01", "2026-05-01"),
    # valid: 250.x
    ("2026-04-02 INFO 250.2.3.4 ok 2026-05-01", "2026-05-01"),
    # valid: 254.x
    ("2026-04-02 INFO 254.2.3.4 ok 2026-05-01", "2026-05-01"),
    # valid: 255.x
    ("2026-04-02 INFO 255.2.3.4 ok 2026-05-01", "2026-05-01"),
    # invalid: 256.x
    ("2026-04-02 INFO 256.2.3.4 bad", None),
    # invalid: 300.x
    ("2026-04-02 INFO 300.2.3.4 bad", None),
    # invalid: 999.x
    ("2026-04-02 INFO 999.2.3.4 bad", None),
    # IP with hyphen before
    ("2026-04-02 INFO -1.2.3.4 bad", "2026-04-02"),  # hyphen is not letter/digit, so IP still counts
    # IP with dot before (like version number)
    ("2026-04-02 INFO v1.2.3.4 bad", None),  # letter v before
    # IP with dot before
    ("2026-04-02 INFO 1.1.2.3.4 bad", None),  # this is 5 parts
    # date with hyphen before
    ("2026-04-02 INFO 1.2.3.4 ok -2026-05-01", None),  # hyphen before date... wait
    # Actually the brief says "letter or digit right before or after" - hyphen is neither, so it should count
    # Let me re-read: "A date or an address with a letter or digit right before or after it does not count."
    # So only letters and digits disqualify. Hyphens, dots, spaces are fine.
    ("2026-04-02 INFO 1.2.3.4 ok -2026-05-01", "2026-05-01"),  # hyphen before is OK
    # But wait, -2026-05-01 - the hyphen is right before the date. The date is 2026-05-01.
    # The character before '2' is '-'. That's not a letter or digit, so it counts.
    # But actually, is the date "2026-05-01" or is it part of "-2026-05-01"?
    # The regex should match 2026-05-01 as a date. The lookbehind checks the char before '2' which is '-'.
    # That's fine.
    # date with dot before
    ("2026-04-02 INFO 1.2.3.4 ok .2026-05-01", "2026-05-01"),  # dot before is OK
    # IP with dot before
    ("2026-04-02 INFO 1.2.3.4 ok 5.6.7.8.9", None),  # 5.6.7.8.9 - the IP 5.6.7.8 has .9 after
    # Actually 5.6.7.8.9: the regex would try to match 5.6.7.8 but then .9 follows.
    # The lookahead (?![0-9A-Za-z]) checks after the last part. After 8 is '.', which is not letter/digit.
    # So 5.6.7.8 would match! But then .9 remains.
    # Hmm, but the IP is 5.6.7.8.9 which is 5 parts - not a valid IP.
    # The regex would match 5.6.7.8 as a valid IP (each part 0-255, no leading zeros).
    # This is a problem. But the brief says "Addresses are dotted decimal, each part 0 to 255 with no leading zeros."
    # 5.6.7.8.9 is not a valid dotted-decimal IPv4 address.
    # However, the regex can't easily distinguish 5.6.7.8 (followed by .9) from a valid IP.
    # The brief says "A date or an address with a letter or digit right before or after it does not count."
    # A dot is not a letter or digit, so 5.6.7.8 followed by .9 would still count as an IP.
    # This is an edge case that the brief doesn't explicitly address.
    # I'll assume that 5.6.7.8.9 contains a valid IP 5.6.7.8 (the first 4 parts) and the .9 is just trailing text.
    # Actually wait - the regex matches the IP as a whole. If the text is "5.6.7.8.9", the regex would match "5.6.7.8" as the IP, and ".9" would be left over.
    # The lookahead after the IP checks the next char is not letter/digit. After "8" is ".", which passes.
    # So yes, 5.6.7.8 would be found as an IP. This seems like a reasonable interpretation.
    # Let me just test what happens:
    ("2026-04-02 INFO 5.6.7.8.9 done 2026-05-01", "2026-05-01"),  # 5.6.7.8 matches as IP
]

# Fix the duplicate entry issue - I had two entries for the same line with different expected values
# Let me rebuild the list properly
tests = [
    ("2026-04-02 INFO 10.0.0.1 done 2026-04-03", "2026-04-03"),
    ("2026-04-02 INFO no ip here 2026-04-03", None),
    ("2026-04-02 INFO 999.0.0.1 bad ip", None),
    ("2026-04-02 INFO 01.0.0.1 leading zero", None),
    ("2026-04-02 INFO 1.0.0.1 ok 2026-02-29", "2026-02-29"),
    ("2026-04-02 INFO 1.0.0.1 ok 2026-02-30", None),
    ("2026-04-02 INFO 1.0.0.1 ok 2026-13-01", None),
    ("2026-04-02 INFO 1.0.0.1 ok 2026-00-15", None),
    ("2026-04-02 INFO 1.0.0.1 ok 2026-04-32", None),
    ("2026-04-02 INFO 1.0.0.1 ok 2026-04-00", None),
    ("2026-04-02 INFO x1.0.0.1 letter before", None),
    ("2026-04-02 INFO 1.0.0.1x letter after", None),
    ("2026-04-02 INFO 1.0.0.12 digit after", None),
    ("2026-04-02 INFO 12.0.0.1 digit before", None),
    ("2026-04-02 INFO 1.0.0.1 ok 2026-04-01x", None),
    ("2026-04-02 INFO 1.0.0.1 ok x2026-04-01", None),
    ("2026-04-02 INFO 1.0.0.1 ok 2026-04-012", None),
    ("2026-04-02 INFO 1.0.0.1 ok 12026-04-01", None),
    ("2026-04-02 INFO 255.255.255.255 max ip 2026-12-31", "2026-12-31"),
    ("2026-04-02 INFO 0.0.0.0 min ip 2026-01-01", "2026-01-01"),
    ("2026-04-02 INFO 256.0.0.1 over 255", None),
    ("2026-04-02 INFO 1.2.3.4.5 five parts", "2026-04-02"),  # 1.2.3.4 matches, .5 trailing
    ("2026-04-02 INFO 1.2.3 four parts", None),
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-29 2026-02-28", "2026-02-28"),
    ("2026-04-02 INFO 1.2.3.4 ok 2026-04-31", None),
    ("2026-04-02 INFO 1.2.3.4 ok 2026-06-31", None),
    ("2026-04-02 INFO 1.2.3.4 ok 2026-06-30", "2026-06-30"),
    ("2026-04-02 INFO 1.2.3.4 ok 2026-09-30", "2026-09-30"),
    ("2026-04-02 INFO 1.2.3.4 ok 2026-09-31", None),
    ("2026-04-02 INFO 1.2.3.4 ok 2026-11-30", "2026-11-30"),
    ("2026-04-02 INFO 1.2.3.4 ok 2026-11-31", None),
    ("2026-04-02 INFO 1.2.3.4 ok 2026-01-31", "2026-01-31"),
    ("2026-04-02 INFO 1.2.3.4 ok 2026-12-31", "2026-12-31"),
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-29", "2026-02-29"),
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-28", "2026-02-28"),
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-01", "2026-02-01"),
    ("2026-04-02 INFO 1.2.3.4 ok 2026-02-00", None),
    ("2026-04-02 INFO 1.2.3.4 and 5.6.7.8 done 2026-04-05", "2026-04-05"),
    ("1.2.3.4 2026-04-02 ok 2026-04-03", "2026-04-03"),
    ("2026-04-02 ok 1.2.3.4", "2026-04-02"),
    ("2026-04-02 1.2.3.4 ok", "2026-04-02"),
    ("2026-04-02 07:15:09 1.2.3.4", "2026-04-02"),
    ("2026-04-02 INFO 1.2.3.4 ok 1999-12-31", "1999-12-31"),
    ("2026-04-02 INFO 1.2.3.4 ok 2000-01-01", "2000-01-01"),
    ("2026-04-02 INFO 1.2.3.4 ok 2099-06-15", "2099-06-15"),
    ("2026-04-02 INFO 1.2.3.4 ok 1900-01-01", "1900-01-01"),
    ("2026-04-02 INFO 1.2.3.4 ok 1899-01-01", None),
    ("2026-04-02 INFO 1.2.3.4 ok 2100-01-01", None),
    ("2026-04-02 INFO 1.02.3.4 bad", None),
    ("2026-04-02 INFO 1.2.03.4 bad", None),
    ("2026-04-02 INFO 1.2.3.04 bad", None),
    ("2026-04-02 INFO 01.2.3.4 bad", None),
    ("2026-04-02 INFO 1.2.3.4 ok 2026-05-01", "2026-05-01"),
    ("2026-04-02 INFO 100.2.3.4 ok 2026-05-01", "2026-05-01"),
    ("2026-04-02 INFO 199.2.3.4 ok 2026-05-01", "2026-05-01"),
    ("2026-04-02 INFO 249.2.3.4 ok 2026-05-01", "2026-05-01"),
    ("2026-04-02 INFO 250.2.3.4 ok 2026-05-01", "2026-05-01"),
    ("2026-04-02 INFO 254.2.3.4 ok 2026-05-01", "2026-05-01"),
    ("2026-04-02 INFO 255.2.3.4 ok 2026-05-01", "2026-05-01"),
    ("2026-04-02 INFO 256.2.3.4 bad", None),
    ("2026-04-02 INFO 300.2.3.4 bad", None),
    ("2026-04-02 INFO 999.2.3.4 bad", None),
    ("2026-04-02 INFO v1.2.3.4 bad", None),
    ("2026-04-02 INFO 5.6.7.8.9 done 2026-05-01", "2026-05-01"),
    # date at very end of line
    ("2026-04-02 INFO 1.2.3.4 ok 2026-04-03", "2026-04-03"),
    # multiple dates, IP present
    ("2026-04-02 INFO 1.2.3.4 from 2026-01-01 to 2026-06-15", "2026-06-15"),
    # IP but date is the log timestamp date only
    ("2026-04-02 07:15:09 1.2.3.4", "2026-04-02"),
    # no IP, has dates
    ("2026-04-02 07:15:09 no ip 2026-04-03", None),
    # IP with underscore before
    ("2026-04-02 INFO _1.2.3.4 ok 2026-05-01", "2026-05-01"),  # underscore is not letter/digit
    # IP with underscore after
    ("2026-04-02 INFO 1.2.3.4_ ok 2026-05-01", "2026-05-01"),  # underscore is not letter/digit
    # date with underscore before
    ("2026-04-02 INFO 1.2.3.4 ok _2026-05-01", "2026-05-01"),  # underscore is not letter/digit
    # date with underscore after
    ("2026-04-02 INFO 1.2.3.4 ok 2026-05-01_", "2026-05-01"),  # underscore is not letter/digit
]

passed = 0
failed = 0
for line, expected in tests:
    result = re.findall(pattern, line, re.MULTILINE)
    actual = result[0] if result else None
    if actual == expected:
        passed += 1
    else:
        failed += 1
        print(f"FAIL: {line!r}")
        print(f"  expected: {expected!r}")
        print(f"  actual:   {actual!r}")

print(f"\n{passed} passed, {failed} failed out of {len(tests)} tests")