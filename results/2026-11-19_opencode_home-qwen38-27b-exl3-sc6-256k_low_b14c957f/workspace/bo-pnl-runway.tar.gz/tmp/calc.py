import csv, json
from collections import defaultdict

coa = {}
with open(r'finance/chart_of_accounts.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        coa[row['account']] = row['pnl_line']

months = ['2026-01','2026-02','2026-03','2026-04','2026-05','2026-06']
agg = {m: defaultdict(float) for m in months}

with open(r'finance/ledger.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        d = row['date'].split('/')
        m = f'{d[2]}-{d[1]}'
        amt = float(row['amount'].replace('.','').replace(',','.'))
        agg[m][coa[row['account']]] += amt

out = {}
for m in months:
    a = agg[m]
    rev = a['revenue']
    cogs = -a['cogs']
    ebitda = rev - cogs + a['sales_marketing'] + a['rnd'] + a['ga']
    out[m] = dict(revenue=round(rev,2), cogs=round(cogs,2),
                  gm=round((rev-cogs)/rev*100,2), ebitda=round(ebitda,2))
    print(m, f"rev={rev:,.2f} cogs={cogs:,.2f} gm={(rev-cogs)/rev*100:.2f}% ebitda={ebitda:,.2f}")

eb = [out[m]['ebitda'] for m in ['2026-04','2026-05','2026-06']]
burn = -sum(eb)/3
cash = 1847350.40
print("last3 ebitda:", eb)
print("burn:", round(burn,2), "runway:", round(cash/burn,2))
res = {
 "revenue": {m: out[m]["revenue"] for m in months},
 "gross_margin_pct": {m: out[m]["gm"] for m in months},
 "ebitda": {m: out[m]["ebitda"] for m in months},
 "burn": round(burn,2),
 "runway_months": round(cash/burn,2),
}
with open(r'result.json','w',encoding='utf-8') as f:
    json.dump(res,f)
print("wrote result.json")