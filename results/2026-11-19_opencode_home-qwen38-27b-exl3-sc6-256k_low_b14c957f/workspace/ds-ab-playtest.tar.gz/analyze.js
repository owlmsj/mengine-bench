const fs = require('fs');
const lines = fs.readFileSync('telemetry/playtest_ab.csv', 'utf8').trim().split('\n');
const rows = lines.slice(1).map(l => l.split(','));
const seen = new Map();
for (const [sid, variant, pid, comp, mm] of rows) {
  const v = variant.trim().toLowerCase();
  if (!['a','b'].includes(v)) throw new Error('bad variant: ' + JSON.stringify(variant));
  if (!seen.has(sid)) seen.set(sid, { v, c: Number(comp) });
}
let a = 0, b = 0, ac = 0, bc = 0;
for (const { v, c } of seen.values()) {
  if (v === 'a') { a++; ac += c; } else { b++; bc += c; }
}
const pa = ac / a, pb = bc / b;
const p = (ac + bc) / (a + b);
const z = (pb - pa) / Math.sqrt(p * (1 - p) * (1/a + 1/b));
// two-sided p-value via normal CDF (erf approximation)
function erf(x){const s=Math.sign(x);x=Math.abs(x);const t=1/(1+0.3275911*x);
const y=1-((((1.061405429*t-1.453152027)*t+1.421413741)*t-0.284496736)*t+0.254829592)*t*Math.exp(-x*x);
return s*y;}
const pval = 2 * (1 - (0.5*(1+erf(z/Math.SQRT2))));
console.log(JSON.stringify({a, b, ac, bc, pa, pb, z, pval}, null, 2));