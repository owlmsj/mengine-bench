import struct, json

data = open(r'<WORKSPACE>\prices.db', 'rb').read()
ncell = 10
offsets = [struct.unpack('>H', data[2*i:2*i+2])[0] for i in range(ncell)]

def varint(buf, pos):
    n = 0
    for i in range(9):
        if pos + i >= len(buf):
            raise IndexError('varint past EOF at %d' % pos)
        b = buf[pos + i]
        if i == 8:
            return (n << 8) | b, pos + 9
        n = (n << 7) | (b & 0x7F)
        if not (b & 0x80):
            return n, pos + i + 1

def serial_value(buf, pos, st):
    if st == 0: return None, pos
    if 1 <= st <= 6:
        size = {1:1,2:2,3:3,4:4,5:6,6:8}[st]
        return int.from_bytes(buf[pos:pos+size], 'big', signed=True), pos + size
    if st == 8: return 0, pos
    if st == 9: return 1, pos
    if st >= 13 and st % 2 == 1:
        size = (st - 13) // 2
        return buf[pos:pos+size].decode('utf-8'), pos + size
    if st >= 12:
        size = (st - 12) // 2
        return ('BLOB', size), pos + size
    if st == 7:
        # non-standard: 8-byte IEEE-754 float64 price
        return struct.unpack('>d', buf[pos:pos+8])[0], pos + 8
    raise ValueError('bad serial type %d' % st)

rows = []
for off in offsets:
    if off == 0 or off >= len(data):
        continue
    try:
        payload_len, p = varint(data, off)
        rowid, p = varint(data, p)
        hdr_len, h = varint(data, p)
        hdr_end = p + hdr_len
        types = []
        while h < hdr_end:
            st, h = varint(data, h)
            types.append(st)
        pos = hdr_end
        vals = []
        for st in types:
            v, pos = serial_value(data, pos, st)
            vals.append(v)
        # rows are (NULL, item, price): item = first str, price = last int
        item = next((v for v in vals if isinstance(v, str)), None)
        price = next((v for v in reversed(vals) if isinstance(v, (int, float)) and not isinstance(v, bool)), None)
        if item is not None and price is not None:
            rows.append({'item': item, 'price': price})
            print('rowid', rowid, '->', item, price)
        else:
            print('rowid', rowid, '-> (skipped)', vals)
    except Exception as e:
        print('offset %d: %s' % (off, e))

with open(r'<WORKSPACE>\recovered.json', 'w', encoding='utf-8') as f:
    json.dump(rows, f, ensure_ascii=False, indent=2)
print('wrote', len(rows), 'rows')