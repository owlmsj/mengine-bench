import re, datetime

pat = open("regex.txt").read().strip()
log = open("server.log").read()
got = re.findall(pat, log, re.MULTILINE)
print("sample log:", got)

cases = [
    # (line, expected)
    ("2026-04-02 07:15:09 INFO  gateway accepted 10.12.0.7 for build 2026-04-01", ["2026-04-01"]),
    ("2026-04-02 07:15:11 INFO  cache warm, 412 keys, next sweep 2026-04-03", []),
    ("2026-04-02 07:16:40 WARN  peer 192.168.40.3 slow, retry window 2026-04-02 to 2026-04-05", ["2026-04-05"]),
    ("2026-04-02 07:18:02 INFO  job 7781-20-4410 queued by scheduler", []),
    ("2026-04-02 07:19:30 ERROR upstream 172.20.1.14 refused handshake", []),
    # ip variants
    ("x 255.255.255.255 2026-02-29", ["2026-02-29"]),
    ("x 0.0.0.0 2026-02-29", ["2026-02-29"]),
    ("x 1.2.3.4 2026-02-29", ["2026-02-29"]),
    ("x 256.1.1.1 2026-02-29", []),
    ("x 1.2.3.256 2026-02-29", []),
    ("x 01.2.3.4 2026-02-29", []),
    ("x 1.2.3.04 2026-02-29", []),
    ("x 1.2.3 2026-02-29", []),
    ("x 1.2.3.4.5 2026-02-29", []),
    ("x 9.9.9.9a 2026-02-29", []),
    ("x a9.9.9.9 2026-02-29", []),
    ("x 192.168.001.1 2026-02-29", []),
    # date variants
    ("x 1.2.3.4 2026-13-01", []),
    ("x 1.2.3.4 2026-00-10", []),
    ("x 1.2.3.4 2026-01-00", []),
    ("x 1.2.3.4 2026-01-32", []),
    ("x 1.2.3.4 2026-04-31", []),
    ("x 1.2.3.4 2026-02-30", []),
    ("x 1.2.3.4 2026-02-29", ["2026-02-29"]),
    ("x 1.2.3.4 2023-02-29", ["2023-02-29"]),
    ("x 1.2.3.4 2026-02-291", []),
    ("x 1.2.3.4 12026-02-29", []),
    ("x 1.2.3.4 a2026-02-29", []),
    ("x 1.2.3.4 2026-02-29a", []),
    # last date on line
    ("x 1.2.3.4 2026-01-01 mid 2026-01-02 end 2026-01-03", ["2026-01-03"]),
    # no ip, dates only
    ("2026-01-01 2026-01-02", []),
    # ip at line start / end
    ("1.2.3.4 2026-05-05", ["2026-05-05"]),
    ("date 2026-05-05 ip 1.2.3.4", ["2026-05-05"]),
    # multiple ips
    ("1.2.3.4 and 5.6.7.8 2026-06-06", ["2026-06-06"]),
    # date before ip only
    ("2026-06-06 ip 1.2.3.4", ["2026-06-06"]),
]

ok = True
for line, exp in cases:
    got = re.findall(pat, line, re.MULTILINE)
    if got != exp:
        ok = False
        print("FAIL", repr(line), "got", got, "exp", exp)
print("ALL OK" if ok else "FAILURES")

# real-calendar check: month/day validity
md = {1:31,2:29,3:31,4:30,5:31,6:30,7:31,8:31,9:30,10:31,11:30,12:31}
dpat = re.compile(r"(?<![0-9A-Za-z])(\d{4})-(\d{2})-(\d{2})(?![0-9A-Za-z])")
bad = []
for y in range(1990, 2040):
    for m in range(1, 13):
        for d in range(0, 32):
            s = f"{y:04d}-{m:02d}-{d:02d}"
            try:
                datetime.date(y, m, d)
                real = True
            except ValueError:
                real = False
            line = f"1.2.3.4 {s}"
            got = re.findall(pat, line, re.MULTILINE)
            if real and got != [s]:
                bad.append((s, "should match", got))
            if not real and got:
                bad.append((s, "should not match", got))
print("calendar check:", "OK" if not bad else bad[:10])