$text = "Welcome aboard the evening ferry, please keep your bags clear of the doors."
$out = "<WORKSPACE>\announcement.wav"
$voice = New-Object -ComObject SAPI.SpVoice
# Use a file stream so SAPI writes the WAV directly
$stream = New-Object -ComObject SAPI.SpFileStream
$stream.Open($out, 3, $false)  # 3 = spfOpenForWriting, create if missing
$voice.AudioOutputStream = $stream
$voice.Rate = 1
$voice.Speak($text, 0) | Out-Null
$stream.Close()
$voice = $null
$stream = $null
Write-Output "written $out"
Get-Item $out | Select-Object Length, LastWriteTime