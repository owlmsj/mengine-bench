import csv, json, math

rows = []
with open("telemetry/playtest_ab.csv", newline="", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        rows.append(r)

# Dedupe: session_id is the unique key (ETL resends sessions).
# Keep first occurrence; verify duplicates are consistent.
sessions = {}
dup_conflicts = 0
for r in rows:
    sid = r["session_id"].strip()
    v = r["variant"].strip().lower()
    c = int(r["completed_tutorial"])
    if sid in sessions:
        if sessions[sid] != (v, c):
            dup_conflicts += 1
    else:
        sessions[sid] = (v, c)

a_n = a_c = b_n = b_c = 0
for sid, (v, c) in sessions.items():
    if v == "a":
        a_n += 1; a_c += c
    elif v == "b":
        b_n += 1; b_c += c
    else:
        raise SystemExit(f"bad variant: {v!r}")

pa = a_c / a_n
pb = b_c / b_n
p = (a_c + b_c) / (a_n + b_n)
se = math.sqrt(p * (1 - p) * (1 / a_n + 1 / b_n))
z = (pb - pa) / se
# two-sided p-value
p_value = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))

result = {
    "ship_b": p_value < 0.05 and pb > pa,
    "sessions_a": a_n,
    "sessions_b": b_n,
    "completion_rate_a": round(pa, 4),
    "completion_rate_b": round(pb, 4),
    "p_value": round(p_value, 4),
}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)

print(f"raw rows: {len(rows)}, unique sessions: {len(sessions)}, dup conflicts: {dup_conflicts}")
print(f"A: {a_c}/{a_n} = {pa:.4f}")
print(f"B: {b_c}/{b_n} = {pb:.4f}")
print(f"z = {z:.4f}, two-sided p = {p_value:.6f}")
print(json.dumps(result, indent=2))