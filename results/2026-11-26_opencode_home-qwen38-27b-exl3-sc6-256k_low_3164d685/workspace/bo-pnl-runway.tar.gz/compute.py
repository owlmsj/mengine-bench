import csv, json
from collections import defaultdict

months = ["2026-01","2026-02","2026-03","2026-04","2026-05","2026-06"]
pnl = {}
with open("finance/chart_of_accounts.csv", encoding="utf-8") as f:
    r = csv.reader(f, delimiter=";")
    next(r)
    for row in r:
        pnl[row[0]] = row[2]

def val(s):
    s = s.strip().replace("R$","").strip()
    neg = s.startswith("-")
    s = s.lstrip("-").replace(".","").replace(",",".")
    v = float(s)
    return -v if neg else v

tot = {m: defaultdict(float) for m in months}
with open("finance/ledger.csv", encoding="utf-8") as f:
    r = csv.reader(f, delimiter=";")
    next(r)
    for row in r:
        d, acc, desc, amt = row
        dd, mm, yy = d.split("/")
        m = f"{yy}-{mm}"
        tot[m][pnl[acc]] += val(amt)

out = {"revenue":{}, "gross_margin_pct":{}, "ebitda":{}, "burn":None, "runway_months":None}
eb = {}
for m in months:
    rev = tot[m]["revenue"]
    cogs = tot[m]["cogs"]
    ebitda = rev + cogs + tot[m]["sales_marketing"] + tot[m]["rnd"] + tot[m]["ga"] + tot[m]["financial"]
    eb[m] = ebitda
    out["revenue"][m] = round(rev, 2)
    out["gross_margin_pct"][m] = round((rev + cogs) / rev * 100, 2)
    out["ebitda"][m] = round(ebitda, 2)

# board definition: burn = average monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = [eb[m] for m in ["2026-04","2026-05","2026-06"]]
burn = -sum(last3)/3
cash = 1847350.40
out["burn"] = round(burn, 2)
out["runway_months"] = round(cash / burn, 2)

with open("result.json","w",encoding="utf-8") as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))
print("EBITDA last3:", [round(x,2) for x in last3])