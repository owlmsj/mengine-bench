$ws = "<WORKSPACE>"
$raw = Get-Content "$ws\words.json" -Raw -Encoding UTF8
$w = $raw | ConvertFrom-Json
$out = @{}
foreach ($k in $w.PSObject.Properties.Name) {
  $links = @()
  foreach ($l in $w.$k.links) {
    $type = "analogas"
    # determine type: sinonimos if in sinonimos section; we stored only flat links in words.json
    $links += @{ to = $l; type = "analogas" }
  }
  $out[$k] = @{ name = $w.$k.name; links = $links }
}
$json = $out | ConvertTo-Json -Depth 6 -Compress
$html = Get-Content "$ws\universe\index.html" -Raw -Encoding UTF8
$html = $html.Replace("/*__DATA__*/null", $json)
[System.IO.File]::WriteAllText("$ws\universe\index.html", $html, [System.Text.UTF8Encoding]::new($false))
Write-Output ("injected, html size: " + $html.Length)