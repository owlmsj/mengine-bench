$w = Get-Content "<WORKSPACE>\words.json" -Raw -Encoding UTF8 | ConvertFrom-Json
$pairs = @{}
$deg = @{}
foreach ($k in $w.PSObject.Properties.Name) {
  $deg[$k] = 0
  foreach ($l in $w.$k.links) {
    $a = $k; $b = $l
    if ($a -gt $b) { $t=$a; $a=$b; $b=$t }
    $pairs["$a|$b"] = $true
    $deg[$k]++
  }
}
Write-Output ("distinct pairs: " + $pairs.Count)
$top = $deg.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 5
foreach ($t in $top) { Write-Output ($t.Key + " = " + $t.Value) }
# check dangling links (link target not a word key)
$dang = @{}
foreach ($k in $w.PSObject.Properties.Name) {
  foreach ($l in $w.$k.links) { if (-not $deg.ContainsKey($l)) { $dang[$l] = $true } }
}
Write-Output ("dangling: " + $dang.Count)
$dang.Keys | ForEach-Object { Write-Output ("  " + $_) }