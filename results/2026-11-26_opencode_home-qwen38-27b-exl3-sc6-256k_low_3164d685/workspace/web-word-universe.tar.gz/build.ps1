$ws = "<WORKSPACE>"
$site = "$ws\site"
$words = @{}
Get-ChildItem $site -Filter *.html | ForEach-Object {
  $html = Get-Content $_.FullName -Raw -Encoding UTF8
  $key = $_.BaseName
  $links = @()
  foreach ($id in @("sinonimos","analogas")) {
    if ($html -match ('<section id="' + $id + '">.*?</section>')) {
      $sec = $Matches[0]
      [regex]::Matches($sec, '<a href="([^"]+)">') | ForEach-Object {
        $href = $_.Groups[1].Value
        if ($href -ne "index.html") {
          $h = [System.Uri]::UnescapeDataString(($href -replace '\.html$',''))
          $links += @{ to = $h; type = $id }
        }
      }
    }
  }
  if ($html -match '<h1>([^<]+)</h1>') { $name = $Matches[1] } else { $name = $key }
  $words[$key] = @{ name = $name; links = $links }
}
$json = $words | ConvertTo-Json -Depth 6 -Compress
[System.IO.File]::WriteAllText("$ws\words.json", ($words | ConvertTo-Json -Depth 5), [System.Text.UTF8Encoding]::new($false))
$html = Get-Content "$ws\universe\index.html" -Raw -Encoding UTF8
$html = $html.Replace("/*__DATA__*/null", $json)
[System.IO.File]::WriteAllText("$ws\universe\index.html", $html, [System.Text.UTF8Encoding]::new($false))
Write-Output ("words: " + $words.Count + " html size: " + $html.Length)