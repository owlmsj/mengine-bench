$w = Get-Content "<WORKSPACE>\words.json" -Raw -Encoding UTF8 | ConvertFrom-Json
$n = ($w.PSObject.Properties.Name).Count
$s = $w.saudade
Write-Output ("words=" + $n + " saudade.name=" + $s.name + " saudade.links=" + $s.links.Count)