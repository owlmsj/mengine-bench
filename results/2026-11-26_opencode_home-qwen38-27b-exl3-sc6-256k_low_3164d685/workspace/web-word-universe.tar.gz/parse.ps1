$site = "<WORKSPACE>\site"
$words = @{}
Get-ChildItem $site -Filter *.html | ForEach-Object {
  $html = Get-Content $_.FullName -Raw -Encoding UTF8
  $key = $_.BaseName
  $links = @()
  foreach ($id in @("sinonimos","analogas")) {
    if ($html -match ('<section id="' + $id + '">.*?</section>')) {
      $sec = $Matches[0]
      [regex]::Matches($sec, '<a href="([^"]+)">') | ForEach-Object {
        $href = $_.Groups[1].Value
        if ($href -ne "index.html") {
          $h = $href -replace '\.html$',''
          $links += [System.Uri]::UnescapeDataString($h)
        }
      }
    }
  }
  if ($html -match '<h1>([^<]+)</h1>') { $name = $Matches[1] } else { $name = $key }
  $words[$key] = @{ name = $name; links = $links }
}
$json = $words | ConvertTo-Json -Depth 5
[System.IO.File]::WriteAllText("<WORKSPACE>\words.json", $json, [System.Text.UTF8Encoding]::new($false))
Write-Output ("words: " + $words.Count)
$pairCount = 0
foreach ($k in $words.Keys) { foreach ($l in $words[$k].links) { $pairCount++ } }
Write-Output ("link refs: " + $pairCount)