import csv, json

rows = list(csv.DictReader(open('capture/presentmon.csv')))
btw = [float(r['MsBetweenPresents']) for r in rows if r['MsBetweenPresents']]
avg_fps = 1000.0 / (sum(btw)/len(btw))
srt = sorted(btw)
p99 = srt[int(0.99*len(srt))]
low1 = 1000.0/p99
print('frames', len(rows), 'avg_fps %.2f' % avg_fps, 'p99_ms %.2f' % p99, 'low1 %.2f' % low1)

# spikes: frames slower than 3x median
med = srt[len(srt)//2]
spikes = [(i, float(r['MsBetweenPresents']), float(r['TimeInSeconds'])) for i, r in enumerate(rows)
          if r['MsBetweenPresents'] and float(r['MsBetweenPresents']) > 3*med]
print('median ms %.2f, spikes >3x: %d' % (med, len(spikes)))
for i, ms, t in spikes[:40]:
    print('  t=%.2f ms=%.1f' % (t, ms))

# sensor log
srows = list(csv.DictReader(open('capture/sensors.csv')))
print('sensors:', srows[0].keys(), 'rows', len(srows))
for r in srows[:3]:
    print(r)