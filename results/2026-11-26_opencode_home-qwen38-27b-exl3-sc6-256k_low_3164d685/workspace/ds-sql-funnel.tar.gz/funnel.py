import sqlite3, json

c = sqlite3.connect('analytics.db')
steps = ['install', 'tutorial_complete', 'first_match', 'purchase']

# valid players: known (in users) and not test
players = {uid: plat for uid, plat, is_test in c.execute("SELECT user_id, platform, is_test FROM users") if not is_test}

# first occurrence of each event per player, but a step counts only at/after the previous step
first = {}  # (uid, step) -> ts
for uid, name, ts in c.execute("SELECT user_id, name, ts FROM events"):
    if uid not in players or name not in steps:
        continue
    k = (uid, name)
    if k not in first or ts < first[k]:
        k and first.__setitem__(k, ts)

funnel = {}
biggest = {}
for plat in sorted({p for p in players.values()}):
    pids = [u for u, p in players.items() if p == plat]
    counts = {}
    for i, s in enumerate(steps):
        prev = steps[i-1] if i > 0 else None
        n = 0
        for u in pids:
            t = first.get((u, s))
            if t is None:
                continue
            if prev is None:
                n += 1
            else:
                tp = first.get((u, prev))
                if tp is not None and t >= tp:
                    n += 1
        counts[s] = n
    funnel[plat] = counts
    # conversions
    convs = {}
    for i, s in enumerate(steps):
        if i == 0:
            convs[s] = None
        else:
            prev = steps[i-1]
            convs[s] = (counts[s] / counts[prev]) if counts[prev] else None
    valid = {s: v for s, v in convs.items() if v is not None}
    biggest[plat] = min(valid, key=valid.get)

out = {"funnel": funnel, "biggest_drop": biggest}
with open('result.json', 'w') as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))