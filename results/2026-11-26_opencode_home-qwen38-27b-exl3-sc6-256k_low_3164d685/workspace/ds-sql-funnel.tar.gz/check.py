import sqlite3

c = sqlite3.connect('analytics.db')
steps = ['install', 'tutorial_complete', 'first_match', 'purchase']

# Independent check: per platform, per step, count players whose first valid
# occurrence of the step is >= first valid occurrence of previous step.
sql = """
WITH firsts AS (
  SELECT e.user_id, e.name, MIN(e.ts) AS ts
  FROM events e JOIN users u ON u.user_id = e.user_id
  WHERE u.is_test = 0 AND e.name IN ('install','tutorial_complete','first_match','purchase')
  GROUP BY e.user_id, e.name
)
SELECT u.platform,
  SUM(CASE WHEN f1.ts IS NOT NULL THEN 1 ELSE 0 END),
  SUM(CASE WHEN f2.ts IS NOT NULL AND f1.ts IS NOT NULL AND f2.ts >= f1.ts THEN 1 ELSE 0 END),
  SUM(CASE WHEN f3.ts IS NOT NULL AND f2.ts IS NOT NULL AND f3.ts >= f2.ts THEN 1 ELSE 0 END),
  SUM(CASE WHEN f4.ts IS NOT NULL AND f3.ts IS NOT NULL AND f4.ts >= f3.ts THEN 1 ELSE 0 END)
FROM users u
LEFT JOIN firsts f1 ON f1.user_id = u.user_id AND f1.name = 'install'
LEFT JOIN firsts f2 ON f2.user_id = u.user_id AND f2.name = 'tutorial_complete'
LEFT JOIN firsts f3 ON f3.user_id = u.user_id AND f3.name = 'first_match'
LEFT JOIN firsts f4 ON f4.user_id = u.user_id AND f4.name = 'purchase'
WHERE u.is_test = 0
GROUP BY u.platform
"""
for row in c.execute(sql):
    print(row)

# sanity: event names present
print(c.execute("SELECT DISTINCT name FROM events").fetchall())
print(c.execute("SELECT COUNT(*) FROM users WHERE is_test=1").fetchone())