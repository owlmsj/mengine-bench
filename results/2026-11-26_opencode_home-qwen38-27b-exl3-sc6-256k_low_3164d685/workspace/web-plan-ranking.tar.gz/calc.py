import json

# IPCA monthly % (BCB series 433), 1985-1995
m = {
1985: [11.76,10.87,10.16,8.20,7.20,8.49,10.31,12.05,11.12,10.62,13.97,15.07],
1986: [14.37,12.72,4.77,0.78,1.40,1.27,1.71,3.55,1.72,1.90,5.45,11.65],
1987: [13.21,12.64,16.37,19.10,21.45,19.71,9.21,4.87,7.78,11.22,15.08,14.15],
1988: [18.89,15.70,17.60,19.29,17.42,22.00,21.91,21.59,27.45,25.62,27.94,28.70],
1989: [37.49,16.78,6.82,8.33,17.92,28.65,27.74,33.71,37.56,39.77,47.82,51.50],
1990: [67.55,75.73,82.39,15.52,7.59,11.75,12.92,12.88,14.41,14.36,16.81,18.44],
1991: [20.75,20.72,11.92,4.99,7.43,11.19,12.41,15.63,15.63,20.23,25.21,23.71],
1992: [25.94,24.32,21.40,19.93,24.86,20.21,21.83,22.14,24.63,25.24,22.49,25.24],
1993: [30.35,24.98,27.26,27.75,27.69,30.07,30.72,32.96,35.69,33.92,35.56,36.84],
1994: [41.31,40.27,42.75,42.68,44.03,47.43,6.84,1.86,1.53,2.62,2.81,1.71],
1995: [1.70,1.02,1.55,2.43,2.67,2.26,2.36,0.99,0.99,1.41,1.47,1.56],
}
annual = {y: round(((1 + sum((1+v/100 for v in vals), 0) and 0) or 0), 2) for y, vals in []}
# proper compounding
def comp(vals):
    f = 1.0
    for v in vals:
        f *= (1 + v/100)
    return (f - 1) * 100
annual = {y: round(comp(vals), 2) for y, vals in m.items()}

plans = [
 ("Cruzado",  "1986-02-28", "Bresser",  "1987-06-12"),
 ("Bresser",  "1987-06-12", "Verao",    "1989-01-15"),
 ("Verao",    "1989-01-15", "Collor I", "1990-03-16"),
 ("Collor I", "1990-03-16", "Collor II","1991-01-31"),
 ("Collor II","1991-01-31", "Real",     "1994-07-01"),
 ("Real",     "1994-07-01", None,       None),
]
from datetime import date
def d(s):
    y,mo,dd = map(int, s.split("-")); return date(y,mo,dd)
def months(a,b):
    return (b.year - a.year)*12 + (b.month - a.month)

out = []
for name, launch, nxt, nxtdate in plans:
    y = int(launch[0:4])
    before = annual[y-1]
    after = annual[y+1]
    drop = max(0.0, min(1.0, 1 - after/before))
    if nxt is None:
        ml = 60
    else:
        ml = months(d(launch), d(nxtdate))
    dur = min(ml, 60)/60
    score = round(0.7*drop + 0.3*dur, 4)
    out.append(dict(plan=name, launch_date=launch, ipca_before=before, ipca_after=after,
                    months_lasted=ml, score=score,
                    score_drop=round(drop,4), score_durability=round(dur,4)))

for o in out:
    print(o)
ranked = sorted(out, key=lambda o: -o["score"])
print("TOP3:", [o["plan"] for o in ranked[:3]])
json.dump(out, open("calc_out.json","w"), indent=1)