# HANDOFF — local-9b Q5 @ 128k

Task: measure local-9b Q5 at 128k context.

Done (measured, from session transcript):
- Baseline: decode 37.8 t/s, VRAM 7881 MiB = WDDM ceiling; Shared Usage shows 1494 MiB spilled — that number does not count.
- Fix: `--no-mmproj-offload` + `-ub 512` → spill gone, VRAM 7697 MiB, decode 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k — discarded. Q4_K_M fits: 7305 MiB, 40.4 t/s — fallback only.
- Recipe applied: scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

Left:
1. Update evals README — still cites check_vision.ps1, which no longer exists.
2. Review names of the scratchpad temp files (noted repeatedly, never done).

Assumptions: "Q5" = Q5_K build; 128k = 131072 ctx; recipe is the accepted fix.

Found: 128k works at 38.0 t/s, no spill, after two flags; Q4_K_M is the fallback.
How I know: transcript records the measurements (steps 10, 42, 45) and recipe (step 63); the open items are its only pending notes.