import csv, json

weights_gb = 70e9 / 1e9  # 70B params, FP8 = 1 byte/param -> 70 GB
kv_per_token = 327_680
kv_gb = 4 * 32_768 * kv_per_token / 1e9
overhead_gb = 8.0
total_gb = weights_gb + kv_gb + overhead_gb

print(f"weights_gb={weights_gb} kv_cache_gb={kv_gb} total_gb={total_gb}")

rows = list(csv.DictReader(open("offers.csv")))
ok = []
for r in rows:
    if r["in_stock"] != "yes":
        print(f"skip {r['offer_id']}: out of stock")
        continue
    if r["region"] not in ("us-east", "us-central", "eu-west"):
        print(f"skip {r['offer_id']}: region {r['region']}")
        continue
    price = float(r["usd_per_hour"])
    if price > 4.0:
        print(f"skip {r['offer_id']}: ${price}/h over cap")
        continue
    vram = int(r["gpu_count"]) * float(r["vram_gb_per_gpu"])
    if vram < total_gb:
        print(f"skip {r['offer_id']}: vram {vram} < total {total_gb}")
        continue
    ok.append((price, r["offer_id"], vram))

ok.sort()
print("candidates:", ok)
best = ok[0]
result = {
    "weights_gb": weights_gb,
    "kv_cache_gb": kv_gb,
    "total_gb": total_gb,
    "offer_id": best[1],
    "usd_per_hour": best[0],
    "usd_per_month": round(best[0] * 730, 2),
}
json.dump(result, open("result.json", "w"), indent=2)
print(json.dumps(result, indent=2))