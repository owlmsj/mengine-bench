"""Match payout. Rules live in docs/ECONOMY.md."""

def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    raw = (base + kills * cfg["kill_bonus"]) * cfg["event_multiplier"]
    # Round to nearest ten, halves up, without float error (1585 -> 1590).
    return (int(raw) + 5) // 10 * 10
