"""Task runner: run zero-arg async callables with bounded concurrency.

`run_tasks(tasks, max_concurrent)` runs each task (a zero-argument callable
returning an awaitable) with at most `max_concurrent` jobs in flight, and
returns when every job is done.

Ctrl+C behavior: the first SIGINT cancels all in-flight jobs and waits for
their cleanup code (finally blocks, async with, async for) to finish before
re-raising KeyboardInterrupt. A second SIGINT during cleanup restores the
default handler and re-sends SIGINT to abort immediately (standard Python
behavior).
"""

import asyncio
import os
import signal


async def run_tasks(tasks, max_concurrent):
    sem = asyncio.Semaphore(max_concurrent)
    interrupted = False

    async def worker(task):
        async with sem:
            await task()

    workers = [asyncio.ensure_future(worker(t)) for t in tasks]

    def _on_sigint():
        nonlocal interrupted
        if interrupted:
            # Second Ctrl+C: abort immediately via the default handler.
            signal.signal(signal.SIGINT, signal.SIG_DFL)
            os.kill(os.getpid(), signal.SIGINT)
            return
        interrupted = True
        for w in workers:
            w.cancel()

    old_handler = signal.signal(signal.SIGINT, _on_sigint)
    try:
        results = await asyncio.gather(*workers)
    except asyncio.CancelledError:
        raise KeyboardInterrupt()
    finally:
        signal.signal(signal.SIGINT, old_handler)
    return results