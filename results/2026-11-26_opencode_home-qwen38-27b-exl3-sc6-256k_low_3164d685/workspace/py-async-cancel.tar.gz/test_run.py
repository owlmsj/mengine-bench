import asyncio
import os
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
from run import run_tasks


async def test_basic():
    order = []

    async def job(i):
        order.append(("start", i))
        await asyncio.sleep(0.05)
        order.append(("end", i))

    t0 = time.monotonic()
    await run_tasks([lambda i=i: job(i) for i in range(6)], 2)
    dt = time.monotonic() - t0
    assert len(order) == 12
    assert dt < 0.5, dt
    print("basic ok", round(dt, 3))


async def test_bound():
    running = 0
    peak = 0

    async def job():
        nonlocal running, peak
        running += 1
        peak = max(peak, running)
        await asyncio.sleep(0.02)
        running -= 1

    await run_tasks([job for _ in range(10)], 3)
    assert peak <= 3, peak
    print("bound ok", peak)


async def main():
    await test_basic()
    await test_bound()
    print("ALL OK")

asyncio.run(main())