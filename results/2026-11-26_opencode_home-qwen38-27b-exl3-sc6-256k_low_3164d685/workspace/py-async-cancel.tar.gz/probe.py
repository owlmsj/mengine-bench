import asyncio, os, signal, sys
sys.path.insert(0, os.path.dirname(__file__))
from run import run_tasks
print("start", flush=True)

async def job():
    try:
        await asyncio.sleep(10)
    finally:
        await asyncio.sleep(0.05)
        print("cleaned one", flush=True)

async def main():
    print("main entered", flush=True)
    try:
        await run_tasks([job, job, job], 3)
    except KeyboardInterrupt:
        print("got KI", flush=True)
    print("done", flush=True)

loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)
loop.call_later(0.1, lambda: (print("sending SIGINT", flush=True), os.kill(os.getpid(), signal.SIGINT)))
loop.run_until_complete(main())