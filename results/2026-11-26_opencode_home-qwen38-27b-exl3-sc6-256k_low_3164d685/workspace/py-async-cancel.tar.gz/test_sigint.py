import asyncio, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from run import run_tasks

cleaned = []

async def job():
    try:
        await asyncio.sleep(10)
    finally:
        await asyncio.sleep(0.05)
        cleaned.append(1)

async def main():
    # Simulate what the SIGINT handler does: cancel all workers.
    # We do this by cancelling the run_tasks task from outside.
    task = asyncio.ensure_future(run_tasks([job, job, job], 3))
    await asyncio.sleep(0.1)
    task.cancel()
    try:
        await task
    except (KeyboardInterrupt, asyncio.CancelledError):
        pass
    print("cleaned:", len(cleaned), flush=True)
    assert len(cleaned) == 3, cleaned
    print("CLEANUP OK", flush=True)

asyncio.run(main())