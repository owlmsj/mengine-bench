import {spawn} from 'node:child_process';
import {writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const path = pathToFileURL(resolve('scene/index.html')).href;
const port=19357;
const proc=spawn('C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',[
 '--headless=new','--no-first-run','--disable-background-networking','--disable-extensions',
 '--enable-unsafe-swiftshader','--use-angle=swiftshader','--ignore-certificate-errors',
 '--remote-debugging-port='+port,'--user-data-dir='+resolve('tmp/edge'), 'about:blank'
],{stdio:'ignore'});
let ws;
try {
 let pages;
 for(let i=0;i<70;i++){
   try{ pages=await (await fetch('http://127.0.0.1:'+port+'/json/list')).json(); if(pages.length) break; }catch{}
   await new Promise(r=>setTimeout(r,180));
 }
 ws=new WebSocket(pages.find(p=>p.type==='page').webSocketDebuggerUrl);
 await new Promise(r=>ws.addEventListener('open',r,{once:true}));
 let id=0;
 const pending=new Map();
 const urls=new Set();
 ws.addEventListener('message',({data})=>{
   const msg=JSON.parse(data);
   if(msg.id){const p=pending.get(msg.id);pending.delete(msg.id);msg.error?p.reject(msg.error):p.resolve(msg.result);}
   if(msg.method==='Runtime.exceptionThrown') console.log('Exception:',msg.params.exceptionDetails.text);
   if(msg.method==='Network.requestWillBeSent') urls.add(msg.params.request.url);
 });
 function call(method,params={}){
   return new Promise((resolve,reject)=>{
     pending.set(++id,{resolve,reject});ws.send(JSON.stringify({id,method,params}));
   });
 }
 await call('Page.enable');
 await call('Runtime.enable');
 await call('Network.enable');
 await call('Network.setBlockedURLs',{urls:['http://*','https://*'],urlPatterns:[
  {urlPattern:'https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js',block:false},
  {urlPattern:'http*://*',block:true}
 ]}).catch(()=>{});
 await call('Emulation.setDeviceMetricsOverride',{width:1280,height:860,deviceScaleFactor:1,mobile:false});
 await call('Page.navigate',{url:path});
 const read=async expression=>(await call('Runtime.evaluate',{expression,returnByValue:true})).result.value;
 let state;
 for(let i=0;i<60;i++){
   await new Promise(r=>setTimeout(r,300));
   state=await read('({ready:document.body?.dataset.scene,status:document.querySelector("#status")?.textContent,canvases:document.querySelectorAll("canvas").length})');
   if(state?.ready||state?.status?.startsWith('The scene requires'))break;
 }
 console.log('Browser:',JSON.stringify(state));
 console.log('Remote requests:',[...urls].filter(url=>url.startsWith('http')).join(', '));
 if(state?.ready!=='ready')throw Error('Scene did not render');
 async function shot(file){
   const {data}=await call('Page.captureScreenshot',{format:'png'});
   const buf=Buffer.from(data,'base64');
   await writeFile(resolve('tmp',file),buf);
   return buf;
 }
 const a=await shot('frame.png');
 await new Promise(r=>setTimeout(r,1450));
 const b=await shot('motion.png');
 if(a.equals(b))throw Error('Animation frames identical');
 console.log('Animation: screenshots differ across frames');
 await call('Emulation.setEmulatedMedia',{features:[{name:'prefers-reduced-motion',value:'reduce'}]});
 await new Promise(r=>setTimeout(r,500));
 const c=await shot('still.png');
 await new Promise(r=>setTimeout(r,500));
 const d=await shot('still-check.png');
 if(!c.equals(d))throw Error('Reduced-motion frames differ');
 console.log('Reduced motion: screenshots match across frames');
 await call('Emulation.setDeviceMetricsOverride',{width:1280,height:720,deviceScaleFactor:1,mobile:false}); await new Promise(r=>setTimeout(r,500)); await shot('wide.png'); await call('Browser.close').catch(()=>{});
} finally{
 ws?.close();
 if(proc.exitCode===null){proc.kill(); await new Promise(r=>proc.once('exit',r));}
 console.log('Browser process closed');
}

