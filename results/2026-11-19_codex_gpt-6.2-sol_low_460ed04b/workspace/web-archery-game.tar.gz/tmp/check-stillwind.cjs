const {spawn}=require('node:child_process');
const fs=require('node:fs');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const browser=spawn('C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',['--headless=new','--remote-debugging-port=0','--user-data-dir='+path.resolve('tmp/edge-stillwind'),'--no-first-run','--disable-extensions','--disable-features=msEdgeSync,msEdgeSignIn','--disable-background-networking','--mute-audio','--window-size=1440,940','about:blank'],{stdio:['ignore','ignore','pipe'],windowsHide:true});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function test(){
 const port=await new Promise((resolve,reject)=>{
  browser.stderr.on('data',b=>{const m=String(b).match(/DevTools listening on ws:\/\/127\.0\.0\.1:(\d+)/);if(m)resolve(m[1]);});
  browser.once('exit',reject);
  setTimeout(()=>reject(Error('Edge startup timeout')),10000).unref();
 });
 const tabs=await (await fetch('http://127.0.0.1:'+port+'/json/list')).json(); const tab=tabs.find(t=>t.url==='about:blank');
 const ws=new WebSocket(tab.webSocketDebuggerUrl);
 await new Promise(r=>ws.addEventListener('open',r,{once:true}));
 let id=0;const requests=new Map(),errors=[];
 ws.onmessage=({data})=>{const m=JSON.parse(data);if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.text);if(requests.has(m.id)){requests.get(m.id)(m);requests.delete(m.id);}};
 async function send(method,params={}){const key=++id;ws.send(JSON.stringify({id:key,method,params}));const response=await new Promise(r=>requests.set(key,r));if(response.error)throw Error(JSON.stringify(response.error));return response.result;}
 async function evaluate(expression){const o=await send('Runtime.evaluate',{expression,returnByValue:true});if(o.exceptionDetails)throw Error(JSON.stringify(o.exceptionDetails));return o.result.value;}
 function check(ok,line){if(!ok)throw Error(line);console.log(line);}
 async function screenshot(name){fs.writeFileSync('tmp/'+name+'.png',Buffer.from((await send('Page.captureScreenshot')).data,'base64'));}
 async function mouse(type,x,y){await send('Input.dispatchMouseEvent',{type,x,y,button:type==='mouseMoved'?'none':'left',buttons:type==='mouseReleased'?0:1,clickCount:1});}
 async function click(id){const [x,y]=await evaluate(`(()=>{const r=document.getElementById('${id}').getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2]})()`);await mouse('mousePressed',x,y);await mouse('mouseReleased',x,y);}
 async function shot(dx,dy,inspect=false){
 const coords=await evaluate(`(()=>{const r=canvas.getBoundingClientRect();return [r.left+r.width*.4,r.top+r.height*.54,r.width/W,r.height/H]})()`);
 const [x,y,sx,sy]=coords;await mouse('mousePressed',x,y);await mouse('mouseMoved',x-dx*sx,y-dy*sy);if(inspect)await screenshot('draw');await mouse('mouseReleased',x-dx*sx,y-dy*sy);
 }
 try{
 await send('Page.enable');await send('Runtime.enable');
 await send('Page.navigate',{url:pathToFileURL(path.resolve('game/index.html')).href});
 for(let i=0;i<60;i++){if(await evaluate('typeof phase!=="undefined"'))break;await sleep(100);}
 await sleep(400);await screenshot('intro');
 check(await evaluate("phase==='intro' && $('hud').hidden && !$('overlay').hidden"),'PASS local file opens on the title screen');
 await click('start');
 check(await evaluate("phase==='play' && ammo===10 && audio.state==='running'"),'PASS start opens a ten-arrow round and unlocks Web Audio');
 await shot(119,-51,true);await sleep(920);
 const scored=await evaluate('({points,popped,ammo})');
 check(scored.popped>=2 && scored.points>=300 && scored.ammo===9,'PASS mouse drag produced a multi-pop: '+JSON.stringify(scored));
 for(let i=0;i<9;i++)await shot(20,115);
 await sleep(1550);
 check(await evaluate("phase==='end' && $('title').textContent==='Out of arrows.'"),'PASS quiver depletion reveals the loss screen');
 await screenshot('loss');await click('start');
 check(await evaluate("phase==='play' && ammo===10 && points===0 && targets.every(t=>!t.dead)"),'PASS retry resets arrows, score and balloons');
 await click('sound');
 check(await evaluate("muted && $('sound').getAttribute('aria-pressed')==='false'"),'PASS sound toggle mutes the round');
 await click('sound');
 await shot(119,-51);
 await sleep(930);
 while(await evaluate("phase==='play' && ammo>0 && popped<targets.length")){
  const [dx,dy]=await evaluate(`(()=>{
   const target=targets.find(t=>!t.dead), x=target.x-origin.x, y=target.y-origin.y;
   let dir=Math.atan2(y,x);
   for(let i=0;i<8;i++){const t=x/(1150*Math.cos(dir));dir=Math.atan2(y-.5*gravity*t*t,x);}
   return [133*Math.cos(dir),133*Math.sin(dir)];
  })()`);
  await shot(dx,dy);await sleep(925);
 }
 await sleep(750);
 const win=await evaluate("({phase, points,popped,ammo,title:$('title').textContent})");
 check(win.phase==='end'&&win.popped===12&&win.title==='Clear skies.','PASS full mouse-played clear: '+JSON.stringify(win));
 check(!errors.length,'PASS no uncaught browser exceptions');
 } finally {await Promise.race([send('Browser.close'),sleep(700)]).catch(()=>{});ws.close();if(browser.exitCode===null)browser.kill();}
}
test().catch(e=>{console.error(e);process.exitCode=1;browser.kill();});


