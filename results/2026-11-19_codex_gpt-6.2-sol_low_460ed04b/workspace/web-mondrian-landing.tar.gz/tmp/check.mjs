import { spawn } from 'node:child_process';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const profile = resolve('tmp/browser-final');
const edge = spawn('C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', [
  '--headless=new', '--disable-gpu', '--no-first-run', '--disable-background-networking',
  '--remote-debugging-port=0', '--user-data-dir=' + profile, 'about:blank'
], { stdio: 'ignore' });
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
let socket;
try {
  let port;
  for (let attempt = 0; attempt < 50 && !port; attempt++) {
    try { port = (await readFile(resolve(profile, 'DevToolsActivePort'), 'utf8')).split('\n')[0]; }
    catch { await pause(150); }
  }
  const targets = await (await fetch('http://127.0.0.1:' + port + '/json/list')).json();
  socket = new WebSocket(targets.find(target => target.type === 'page').webSocketDebuggerUrl);
  await new Promise((resolve, reject) => { socket.onopen = resolve; socket.onerror = reject; });
  let id = 0;
  const call = (method, params = {}) => new Promise((resolve, reject) => {
    const requestId = ++id;
    const handler = ({ data }) => {
      const response = JSON.parse(data);
      if (response.id !== requestId) return;
      socket.removeEventListener('message', handler);
      response.error ? reject(response.error) : resolve(response.result);
    };
    socket.addEventListener('message', handler);
    socket.send(JSON.stringify({ id: requestId, method, params }));
  });
  const evaluate = async expression => (await call('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })).result.value;
  await call('Page.navigate', { url: pathToFileURL(resolve('landing/index.html')).href });
  for (let attempt = 0; attempt < 50; attempt++) {
    if (await evaluate("Boolean(document.querySelector('h1')) && document.readyState === 'complete'")) break;
    await pause(150);
  }
  await evaluate("document.fonts.ready.then(() => true)");
  for (const [width, height] of [[1440, 960], [390, 844], [320, 720]]) {
    await call('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: 1, mobile: width < 500 });
    const checks = await evaluate(`(() => {
      const link = document.querySelector('footer a');
      const title = document.querySelector('h1');
      const art = document.querySelector('.canvas');
      return {
        squareBlocks: [...art.querySelectorAll('.red, .blue')].every(block => Math.abs(block.offsetWidth - block.offsetHeight) <= 1),
        overflow: document.documentElement.scrollWidth > innerWidth,
        title: title.innerText.replace(/\\n/g, ' '),
        source: link.getAttribute('href'),
        canvas: [art.offsetWidth, art.offsetHeight],
        ctaBottom: Math.round(link.getBoundingClientRect().bottom),
        browserFont: [...document.fonts].some(font => font.status === 'loaded')
      };
    })()`);
    if (!checks.squareBlocks || checks.overflow || checks.title !== 'Composition with Red, Blue and Yellow' ||
        checks.source !== 'https://en.wikipedia.org/wiki/Composition_with_Red,_Blue_and_Yellow' ||
        checks.canvas[0] !== checks.canvas[1]) throw new Error(JSON.stringify(checks));
    console.log(width + 'px: title and source match; square diagram and red/blue blocks; no horizontal overflow. ' +
      'Google font loaded: ' + checks.browserFont + '. CTA bottom: ' + checks.ctaBottom + 'px.');
    if (width !== 320) {
      const { contentSize } = await call('Page.getLayoutMetrics');
      const shot = await call('Page.captureScreenshot', { captureBeyondViewport: true,
        clip: { x: 0, y: 0, width, height: Math.ceil(contentSize.height), scale: 1 } });
      await writeFile(resolve('tmp/' + width + '.png'), Buffer.from(shot.data, 'base64'));
    }
  }
  await call('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Tab', code: 'Tab', windowsVirtualKeyCode: 9 });
  await call('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Tab', code: 'Tab', windowsVirtualKeyCode: 9 });
  if (!(await evaluate("document.activeElement.matches('footer a:focus-visible')"))) throw new Error('Source link missed keyboard focus');
  console.log('Tab reached the Wikipedia link with visible focus.');
  await call('Browser.close');
} finally {
  socket?.close();
  if (edge.exitCode === null) {
    await Promise.race([new Promise(resolve => edge.once('exit', resolve)), pause(2000)]);
    if (edge.exitCode === null) edge.kill();
  }
}
