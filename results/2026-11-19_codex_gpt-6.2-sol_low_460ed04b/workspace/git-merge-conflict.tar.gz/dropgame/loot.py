"""Loot drops for the dungeon crawler."""

RARE_CHANCE = 0.05
PITY_LIMIT = 10


class LootTable:
    """Decides what one defeated monster drops."""

    def __init__(self, event_multiplier: float = 1.0) -> None:
        self.event_multiplier = event_multiplier
        self.misses = 0

    def drop(self, roll: float) -> str:
        """Return "rare" or "common" for a roll in [0, 1).

        A roll below the event-adjusted rare chance drops a rare.
        After PITY_LIMIT consecutive common drops, the next drop is rare.
        Every rare resets the count of consecutive common drops.
        """
        chance = min(1.0, RARE_CHANCE * self.event_multiplier)
        if self.misses >= PITY_LIMIT or roll < chance:
            self.misses = 0
            return "rare"
        self.misses += 1
        return "common"
