//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    // Keep player scores and the total under one lock so updates commit together.
    state: Arc<Mutex<BoardState>>,
}

#[derive(Default)]
struct BoardState {
    players: HashMap<PlayerId, i64>,
    total: i64,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        let mut state = self.state.lock().unwrap();
        let previous = state.players.get(&id).copied().unwrap_or(0);
        let total =
            i64::try_from(i128::from(state.total) - i128::from(previous) + i128::from(score))
                .expect("board total must fit in i64");
        state.players.insert(id, score);
        state.total = total;
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let mut state = self.state.lock().unwrap();
        let total = state.total + points;
        *state.players.get_mut(&id).unwrap() += points;
        state.total = total;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return;
        }

        let mut state = self.state.lock().unwrap();
        let from_score = state.players[&from] - points;
        let to_score = state.players[&to] + points;
        *state.players.get_mut(&from).unwrap() = from_score;
        *state.players.get_mut(&to).unwrap() = to_score;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        self.state.lock().unwrap().players[&id]
    }

    pub fn total(&self) -> i64 {
        self.state.lock().unwrap().total
    }
}

#[cfg(test)]
mod tests {
    use super::Board;
    use std::sync::{mpsc, Arc, Barrier};
    use std::thread;
    use std::time::Duration;

    #[test]
    fn concurrent_updates_finish_and_preserve_scores() {
        const WORKERS: u32 = 4;
        const ROUNDS: i64 = 1_000;

        let board = Board::new();
        board.join(1, 10);
        board.join(2, 20);

        let start = Arc::new(Barrier::new(WORKERS as usize));
        let (done, completed) = mpsc::channel();
        for worker in 0..WORKERS {
            let board = board.clone();
            let start = Arc::clone(&start);
            let done = done.clone();
            thread::spawn(move || {
                start.wait();
                board.transfer(1, 1, 7);
                let (from, to) = if worker % 2 == 0 { (1, 2) } else { (2, 1) };
                for _ in 0..ROUNDS {
                    board.award(1, 1);
                    board.award(2, 2);
                    board.transfer(from, to, 3);
                }
                done.send(()).unwrap();
            });
        }
        drop(done);
        for _ in 0..WORKERS {
            completed
                .recv_timeout(Duration::from_secs(5))
                .expect("score updates should finish");
        }

        let awards = i64::from(WORKERS) * ROUNDS;
        assert_eq!(board.score(1), 10 + awards);
        assert_eq!(board.score(2), 20 + 2 * awards);
        assert_eq!(board.total(), 30 + 3 * awards);

        board.join(1, -5);
        assert_eq!(board.score(1), -5);
        assert_eq!(board.total(), 15 + 2 * awards);
    }
}
