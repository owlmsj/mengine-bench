from pathlib import Path
page = Path('universe/index.html')
html = page.read_text(encoding='utf-8')
html = html.replace('max-height:65vh','max-height:59vh').replace('padding:16px 19px;border-bottom','min-height:53px;padding:12px 19px;border-bottom')
html = html.replace('Selecione um ponto para ver suas relações ou clique em um tema para explorar suas palavras.', 'Selecione um ponto ou tema no mapa, ou comece por '+"""<a data-word="saudade" href="?word=saudade">saudade</a>.""")
html = html.replace("+\'</div><h3>Uma palavra para explorar</h3><div class=\"words\">\'+chip(\"saudade\")+\'</div>\';", "+\'</div>\';")
html = html.replace('return adjacency.has(clean)?clean:aliases[clean]||words.find(word=>fold(word)===fold(clean));','if(adjacency.has(clean))return clean;\n  if(Object.hasOwn(aliases,clean))return aliases[clean];\n  return words.find(word=>fold(word)===fold(clean));')
page.write_text(html, encoding='utf-8')
