const fs=require('node:fs'),path=require('node:path'),{spawn}=require('node:child_process'),{pathToFileURL}=require('node:url');
const assert=require('node:assert/strict');
const profile=path.resolve('tmp/edge-qa-'+process.pid);
const edge=spawn('C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',['--headless=new','--no-first-run','--disable-gpu','--disable-background-networking','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'],{stdio:'ignore',windowsHide:true});
const delay=ms=>new Promise(r=>setTimeout(r,ms));
let ws;
(async()=>{
  let port;
  for(let i=0;i<100&&!port;i++){try{port=fs.readFileSync(path.join(profile,'DevToolsActivePort'),'utf8').split(/\r?\n/)[0];}catch{await delay(100);}}
  assert.ok(port,'browser startup');
  const info=await (await fetch('http://127.0.0.1:'+port+'/json/list')).json();
  ws=new WebSocket(info.find(x=>x.type==='page').webSocketDebuggerUrl);
  await new Promise((resolve,reject)=>{ws.onopen=resolve;ws.onerror=reject;});
  let seq=0;
  const pending=new Map(), errors=[];
  ws.onmessage=e=>{
    const m=JSON.parse(e.data);
    if(m.id){const {resolve,reject}=pending.get(m.id);pending.delete(m.id);m.error?reject(Error(JSON.stringify(m.error))):resolve(m.result);}
    if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text);
  };
  const send=(method,params={})=>new Promise((resolve,reject)=>{const id=++seq;pending.set(id,{resolve,reject});ws.send(JSON.stringify({id,method,params}));});
  const ev=async expression=>{
    const response=await send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});
    if(response.exceptionDetails)throw Error(response.exceptionDetails.exception?.description||response.exceptionDetails.text);
    return response.result.value;
  };
  const waitFor=async expression=>{for(let i=0;i<100;i++){if(await ev(expression))return;await delay(80);}throw Error('Timed out: '+expression+' '+errors.join('; '));};
  const viewport=async(width,height,mobile=false)=>send('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile});
  const shot=async name=>fs.writeFileSync('tmp/'+name+'.png',Buffer.from((await send('Page.captureScreenshot',{format:'png'})).data,'base64'));
  const address=pathToFileURL(path.resolve('universe/index.html')).href;
  await send('Runtime.enable');
  await viewport(1440,900);
  await send('Page.navigate',{url:address});
  await waitFor("document.querySelectorAll('.dot').length===250");
  await Promise.race([ev('document.fonts.ready.then(()=>true)'),delay(2500)]);
  await shot('desktop-overview');
  assert.equal(await ev("document.querySelectorAll('#chart .edge').length"),743);
  const names=()=>ev("[...document.querySelectorAll('#detail .words a')].map(a=>a.textContent).sort().join(', ')");
  await send('Page.navigate',{url:address+'?word=saudade'});
  await waitFor("document.querySelector('#detail h2')?.textContent==='saudade'");
  assert.equal(await names(),'ansiedade, carinho, dor, esperança, nostalgia');
  assert.equal(await ev("document.querySelectorAll('#chart .edge.lit').length"),5);
  await shot('desktop-saudade');
  await ev("document.querySelector('[data-word=nostalgia]').click()");
  assert.equal(await ev("location.search"),'?word=nostalgia');
  await ev("history.back()");
  await waitFor("document.querySelector('#detail h2')?.textContent==='saudade'");
  await ev("query.focus();query.value='esper';query.dispatchEvent(new Event('input'))");
  for(const key of ['ArrowDown','Enter']){
    await send('Input.dispatchKeyEvent',{type:'keyDown',key,code:key,windowsVirtualKeyCode:key==='Enter'?13:40,text:key==='Enter'?'\r':''});
    await send('Input.dispatchKeyEvent',{type:'keyUp',key,windowsVirtualKeyCode:key==='Enter'?13:40});
  }
  assert.equal(await ev("document.querySelector('#detail h2').textContent"),'esperança');
  await ev("document.querySelector('#reset').click();document.querySelector('[data-theme=natureza]').click()");
  assert.equal(await ev("document.querySelectorAll('#detail .words a').length"),25);
  await ev("query.value='__missing__';query.dispatchEvent(new Event('input'));document.querySelector('#search').requestSubmit()");
  assert.equal(await ev("document.querySelector('#feedback').hidden"),false);
  await viewport(390,844,true);
  await send('Page.navigate',{url:address+'?word=saudade'});
  await waitFor("document.querySelector('#detail h2')?.textContent==='saudade'");
  assert.equal(await ev("document.documentElement.scrollWidth"),390);
  await shot('mobile-saudade');
  assert.deepEqual(errors,[]);
  console.log('Edge file://: 250 nodes, 743 edges; saudade: ansiedade, carinho, dor, esperança, nostalgia');
  console.log('Edge: keyboard search, related links, back navigation, theme filter, missing word, 390px layout passed.');
  await Promise.race([send('Browser.close').catch(()=>{}),delay(300)]);
})().catch(error=>{console.error(error);process.exitCode=1;}).finally(()=>{if(ws)ws.close();if(edge.exitCode===null)edge.kill();});

