import json
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote

class Page(HTMLParser):
    def __init__(self, path):
        super().__init__()
        self.heading = ''
        self.h1 = False
        self.section = None
        self.links = []
        self.is_entry = False
        self.redirect = None
        self.feed(path.read_text(encoding='utf-8'))
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'h1':
            self.h1 = True
        if tag == 'section':
            self.section = attrs.get('id')
            self.is_entry |= self.section in ('sinonimos', 'analogas')
        if tag == 'a' and self.section in ('sinonimos','analogas'):
            self.links.append((self.section, unquote(attrs['href']).lower()))
        if tag == 'meta' and attrs.get('http-equiv') == 'refresh':
            self.redirect = unquote(attrs['content'].split('url=')[1]).lower()
    def handle_endtag(self, tag):
        if tag == 'h1':
            self.h1 = False
        if tag == 'section':
            self.section = None
    def handle_data(self, data):
        if self.h1:
            self.heading += data

pages = {file.name.lower():Page(file) for file in Path('site').glob('*.html')}
live = {name:p.heading.lower() for name,p in pages.items() if p.is_entry}
pairs = {}
missing = Counter()
for name,word in live.items():
    for section,target in pages[name].links:
        if target in pages and pages[target].redirect:
            target = pages[target].redirect
        if target not in live:
            missing[target] += 1
        elif word != live[target]:
            pair = tuple(sorted((word,live[target])))
            pairs[pair] = pairs.get(pair,0) | (1 if section == 'sinonimos' else 2)

adj = json.loads(Path('words.json').read_text(encoding='utf-8'))
report = json.loads(Path('result.json').read_text(encoding='utf-8'))
assert set(adj) == set(live.values())
assert all(len(ns) == len(set(ns)) and k not in ns and all(k in adj[n] for n in ns) for k,ns in adj.items())
assert {tuple(sorted((a,b))) for a in adj for b in adj[a]} == pairs.keys()
degree = max(map(len,adj.values()))
assert report == dict(words=len(adj),relations=len(pairs),most_connected=min(a for a in adj if len(adj[a])==degree))
page=Path('universe/index.html').read_text(encoding='utf-8')
data=json.loads(page.split('id="dictionary" type="application/json">')[1].split('</script>')[0])
assert data['result']==report and {(a,b):flags for a,b,flags in data['edges']} == pairs
print(f'HTMLParser cross-check: {len(adj)} entries, {len(pairs)} unordered pairs, {sum(missing.values())} unresolved links.')
print('Maximum degree:',degree,','.join(a for a in adj if len(adj[a])==degree))
print('Adjacency, summary and inline HTML data match the source.')
