import html, json, re, unicodedata
from collections import Counter
from pathlib import Path
from urllib.parse import unquote

def key(s):
    return unicodedata.normalize('NFC', unquote(s)).casefold()

pages = {}
redirects = {}
for file in sorted(Path('site').glob('*.html')):
    raw = file.read_text(encoding='utf-8')
    theme = re.search(r'<p class="tema">Tema: ([^<]+)', raw)
    redirect = re.search(r'http-equiv="refresh" content="0; url=([^"]+)', raw)
    if redirect:
        redirects[key(file.name)] = key(redirect[1])
    if theme:
        word = key(html.unescape(re.search(r'<main><h1>([^<]+)', raw)[1]))
        pages[key(file.name)] = (word, html.unescape(theme[1]), raw)

themes = {}
pairs = {}
missing = Counter()
for word, theme, raw in pages.values():
    themes[word] = theme
    for section, kind in [('sinonimos', 1), ('analogas', 2)]:
        content = re.search(r'<section id="' + section + r'">(.*?)</section>', raw, re.S)[1]
        for href in re.findall(r'<a href="([^"]+)"', content):
            target = key(html.unescape(href))
            target = redirects.get(target, target)
            if target not in pages:
                missing[target] += 1
                continue
            other = pages[target][0]
            if word == other:
                continue
            pair = tuple(sorted((word, other)))
            pairs[pair] = pairs.get(pair, 0) | kind

adjacency = {word: [] for word in sorted(themes)}
for a,b in sorted(pairs):
    adjacency[a].append(b)
    adjacency[b].append(a)
for neighbors in adjacency.values():
    neighbors.sort()
assert len(pages) == len(adjacency)
ranking = sorted(adjacency, key=lambda x: (-len(adjacency[x]), x))
result = dict(words=len(adjacency), relations=len(pairs), most_connected=ranking[0])
for name, data in [('words.json', adjacency), ('result.json', result)]:
    Path(name).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
payload = dict(themes=themes, edges=[[a,b,k] for (a,b),k in sorted(pairs.items())], result=result,
               aliases={a.removesuffix('.html'):pages[b][0] for a,b in redirects.items()})
Path('tmp/payload.json').write_text(json.dumps(payload, ensure_ascii=False, separators=(',',':')), encoding='utf-8')
print(result, 'degrees:', [(w,len(adjacency[w])) for w in ranking[:6]])
print('Unresolved:', missing)
print('saudade:', ', '.join(adjacency['saudade']))
