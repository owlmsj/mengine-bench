"""Run batches of asynchronous jobs with a concurrency limit."""

import asyncio
from collections.abc import Awaitable, Callable, Iterable


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[object]]], max_concurrent: int
) -> None:
    """Run a finite batch and discard job results.

    On failure or caller cancellation, cancel unfinished jobs and wait for
    their cleanup. Job failures propagate through asyncio.TaskGroup.
    """
    if isinstance(max_concurrent, bool) or not isinstance(max_concurrent, int):
        raise TypeError(f"max_concurrent must be a positive integer, got {max_concurrent!r}")
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be a positive integer, got {max_concurrent!r}")

    slots = asyncio.Semaphore(max_concurrent)

    async def run_job(job: Callable[[], Awaitable[object]]) -> None:
        async with slots:
            await job()

    async with asyncio.TaskGroup() as group:
        for job in tasks:
            group.create_task(run_job(job))
