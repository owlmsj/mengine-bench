"""Runtime config. Precedence, lowest to highest: DEFAULTS < JSON file < env (docs/CONFIG.md)."""

from __future__ import annotations

import json
import os
from collections.abc import Mapping

from arena_server.config.defaults import DEFAULTS


def _coerce(raw, like):
    return type(like)(raw)


def load_config(
    file_path: str | os.PathLike[str] | None = None,
    env: Mapping[str, str] | None = None,
) -> dict[str, int | float]:
    cfg = dict(DEFAULTS)
    if file_path:
        with open(file_path, encoding="utf-8") as fh:
            cfg.update(json.load(fh))
    env = os.environ if env is None else env
    for key, default in DEFAULTS.items():
        value = env.get(f"ARENA_{key.upper()}")
        if value is not None:
            cfg[key] = _coerce(value, default)
    return cfg
