"""Match payout. Rules live in docs/ECONOMY.md."""

from __future__ import annotations

from collections.abc import Mapping
from fractions import Fraction


def match_payout(won: bool, kills: int, cfg: Mapping[str, int | float]) -> int:
    base = cfg["win_base"] if won else cfg["loss_base"]
    # Preserve decimal ties through multiplication as required by docs/ECONOMY.md.
    subtotal = Fraction(str(base)) + kills * Fraction(str(cfg["kill_bonus"]))
    raw = subtotal * Fraction(str(cfg["event_multiplier"]))
    return ((raw + 5) // 10) * 10
