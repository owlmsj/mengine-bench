import unittest

from arena_server.config.loader import load_config
from arena_server.economy.payout import match_payout


class MatchPayout(unittest.TestCase):
    def test_decimal_half_rounds_up_to_the_next_ten(self) -> None:
        cfg = load_config(env={"ARENA_EVENT_MULTIPLIER": "1.005"})

        self.assertEqual(match_payout(won=True, kills=2, cfg=cfg), 1010)
