from hashlib import sha256
from pathlib import Path
from PIL import Image
from pypdf import PdfReader

expected_hashes = {
    'launch.jpg': 'db8aa0590fa2f8e029bd0dffffb521e7c64e300b19cb6d79e444887222f0d640',
    'permit-form.pdf': 'f45568028b2a85d0b030e550b6b7660c4f61dd597947b22fc190f9f161584625',
    'event-details.txt': 'c6a6e7308e7aca49f85aafeec8b6be78e46df775eb00a0644b303652a09ca2a8',
}
for name, expected in expected_hashes.items():
    assert sha256(Path(name).read_bytes()).hexdigest() == expected
print('Originals: 3 of 3 SHA-256 hashes match')
with Image.open('out/feed-photo.jpg') as photo:
    assert photo.format == 'JPEG' and photo.size == (1080, 1350)
    print('JPEG: 1080 x 1350')
    photo.thumbnail((480, 600))
    photo.save('tmp/feed-preview.jpg')
pdf = PdfReader('out/permit-filled.pdf')
widgets = [a for p in pdf.pages for a in p.get('/Annots', []) if a.get_object().get('/Subtype') == '/Widget']
assert not widgets and '/AcroForm' not in pdf.root_object
print('PDF: 0 widgets, no AcroForm')
