from PIL import Image
from pypdf import PdfReader, PdfWriter
from pypdf.generic import NameObject

with Image.open('launch.jpg') as source:
    options = {'icc_profile': source.info['icc_profile']} if source.info.get('icc_profile') else {}
    source.crop((1600, 100, 3000, 1850)).resize((1080, 1350), Image.Resampling.LANCZOS).save(
        'out/feed-photo.jpg', quality=95, subsampling=0, **options
    )

values = {
    'organizer': 'Tidewater Studio',
    'event_date': '2026-12-05',
    'location': 'North Cove Lawn',
    'attendees': '40',
}
writer = PdfWriter(clone_from='permit-form.pdf')
assert set(writer.get_fields()) == set(values)
writer.update_page_form_field_values(None, values, auto_regenerate=False, flatten=True)
writer.remove_annotations(subtypes='/Widget')
writer.root_object.pop(NameObject('/AcroForm'), None)
writer.write('out/permit-filled.pdf')
