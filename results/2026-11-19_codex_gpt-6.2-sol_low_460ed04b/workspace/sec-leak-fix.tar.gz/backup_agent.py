"""Backup agent: packs a folder chosen in the intranet web form and uploads it to the backup API."""

from __future__ import annotations

import os
import tarfile
import urllib.request
from pathlib import Path

import config


def archive_folder(folder: str, out_dir: str = config.ARCHIVE_DIR) -> Path:
    """Packs `folder` into `out_dir/<folder name>.tar.gz` and returns the archive path."""
    folder_path = Path(folder)
    if not folder_path.is_dir():
        raise NotADirectoryError(folder)

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    folder_name = folder_path.name
    if not folder_name or folder_name == "..":
        folder_name = folder_path.resolve().name or "root"
    target = out / (folder_name + ".tar.gz")
    with tarfile.open(target, "w:gz") as archive:
        archive.add(folder_path, arcname=folder_name)
    return target


def send_archive(path: Path, url: str, token: str) -> int:
    """Uploads one archive to the backup API and returns the HTTP status."""
    if not token or any(not "!" <= character <= "~" for character in token):
        raise ValueError("Backup API token must contain only visible ASCII characters")
    request = urllib.request.Request(url, data=path.read_bytes(), method="POST",
                                     headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.status


def upload(path: Path) -> int:
    token = os.environ.get("BACKUP_TOKEN")
    if not token:
        raise RuntimeError("BACKUP_TOKEN must be set to a non-empty value")
    return send_archive(path, config.API_URL, token)


def handle_form(form: dict[str, str]) -> int:
    """Web form handler: backs up the folder the user typed."""
    archive = archive_folder(form["folder"])
    return upload(archive)
