# local-9b Q5 at 128k

Assumption: keep Q5 as the target. The benchmark used a short prompt with a 131072-token context configured. Full-context throughput remains unmeasured.

The prior session applied `--no-mmproj-offload` and `-ub 512` in `scripts/start_server.ps1:165` (local9 block) and `profiles/local/local-9b.json`. Confirm both edits in the project checkout. Update the evals README's stale reference to the removed `check_vision.ps1`. Q6_K (7.03 GiB) did not fit. Q4_K_M is fallback only (7305 MiB, 40.4 t/s).

Reproduce with `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024` and watch WDDM Shared Usage. The initial 37.8 t/s run hit the 7881 MiB WDDM ceiling and spilled 1494 MiB into shared memory, invalidating it as a VRAM-fit result. With both flags, the spill disappeared and Q5 measured 7697 MiB VRAM and 38.0 t/s median across three runs.
