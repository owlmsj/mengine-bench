import os, re, json, html, math, random
from urllib.parse import unquote

SITE = 'site'
files = sorted(f for f in os.listdir(SITE) if f.endswith('.html'))

word_pages = {}   # stem -> label
redirects = {}    # stub stem -> real stem
for f in files:
    src = open(os.path.join(SITE, f), encoding='utf-8').read()
    m = re.search(r'<main><h1>(.*?)</h1><p class="tema">Tema: (.*?)</p>', src)
    if m:
        stem = f[:-5]
        word_pages[stem] = {'label': html.unescape(m.group(1)), 'tema': html.unescape(m.group(2))}
        continue
    r = re.search(r'url=([^"]+)\.html', src)
    if r:
        redirects[f[:-5]] = unquote(r.group(1))

links = {}        # stem -> set of stems (outgoing, from sinonimos+analogas only)
dead = set()
for f in files:
    stem = f[:-5]
    if stem not in word_pages:
        continue
    src = open(os.path.join(SITE, f), encoding='utf-8').read()
    out = set()
    for sec in re.finditer(r'<section id="(?:sinonimos|analogas)">.*?</section>', src):
        for href in re.finditer(r'href="([^"]+)\.html"', sec.group(0)):
            t = unquote(href.group(1))
            t = redirects.get(t, t)
            if t == stem:
                continue
            if t in word_pages:
                out.add(t)
            else:
                dead.add((stem, t))
    links[stem] = out

# undirected union adjacency
adj = {s: set() for s in word_pages}
for s, outs in links.items():
    for t in outs:
        adj[s].add(t)
        adj[t].add(s)

# symmetry stats
asym = sum(1 for s, outs in links.items() for t in outs if s not in links.get(t, ()))
print('word pages:', len(word_pages))
print('directed links:', sum(len(v) for v in links.values()))
print('asymmetric directed links:', asym)
print('distinct undirected pairs:', sum(len(v) for v in adj.values()) // 2)
print('dead link targets:', sorted(dead))
print('isolated words:', [s for s in adj if not adj[s]])

words = {s: sorted(adj[s]) for s in sorted(adj)}
json.dump(words, open('words.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

deg = {s: len(v) for s, v in adj.items()}
mx = max(deg.values())
top = sorted(s for s, d in deg.items() if d == mx)
print('max degree:', mx, 'top:', [(s, word_pages[s]['label']) for s in top])

themes = {}
for s, w in word_pages.items():
    themes.setdefault(w['tema'], []).append(s)
print('themes:', {k: len(v) for k, v in sorted(themes.items())})

# ---- 3D force layout (Fruchterman-Reingold-ish, deterministic) ----
random.seed(42)
ids = sorted(word_pages)
n = len(ids)
idx = {s: i for i, s in enumerate(ids)}
pos = [[random.uniform(-1, 1) for _ in range(3)] for _ in range(ids and n)]
edges = [(idx[a], idx[b]) for a in adj for b in adj[a] if idx[a] < idx[b]]
k = 1.2 / math.sqrt(n)
for it in range(400):
    t = 0.12 * (1 - it / 400)
    disp = [[0.0, 0.0, 0.0] for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            d = [pos[i][c] - pos[j][c] for c in range(3)]
            dist = max(math.sqrt(sum(x * x for x in d)), 1e-3)
            rep = k * k / dist
            for c in range(3):
                disp[i][c] += d[c] / dist * rep
                disp[j][c] -= d[c] / dist * rep
    for a, b in edges:
        d = [pos[a][c] - pos[b][c] for c in range(3)]
        dist = max(math.sqrt(sum(x * x for x in d)), 1e-3)
        att = dist * dist / k * 3.0
        for c in range(3):
            disp[a][c] -= d[c] / dist * att
            disp[b][c] += d[c] / dist * att
    for i in range(n):
        dl = max(math.sqrt(sum(x * x for x in disp[i])), 1e-6)
        for c in range(3):
            pos[i][c] += disp[i][c] / dl * min(dl, t)
# center + scale to radius 100
cx = [sum(p[c] for p in pos) / n for c in range(3)]
for p in pos:
    for c in range(3):
        p[c] -= cx[c]
rmax = max(math.sqrt(sum(x * x for x in p)) for p in pos)
for p in pos:
    for c in range(3):
        p[c] = round(p[c] / rmax * 100, 2)

json.dump({'ids': ids, 'pos': pos}, open('tmp_layout.json', 'w', encoding='utf-8'), ensure_ascii=False)
print('layout done')