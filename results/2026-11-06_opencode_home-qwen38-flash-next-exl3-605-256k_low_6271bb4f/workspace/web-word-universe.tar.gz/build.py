import os, re, json, html
from urllib.parse import unquote

SITE = 'site'
THEMES = [
    ('sentimentos', '#f06292'), ('artes', '#b388ff'), ('comida', '#ffc94d'),
    ('corpo', '#ff7043'), ('família', '#4dd0e1'), ('linguagem', '#aed581'),
    ('lugares', '#26a69a'), ('natureza', '#66bb6a'), ('ofícios', '#ffa726'),
    ('tempo', '#90a4ae'),
]
theme_ix = {n: i for i, (n, _) in enumerate(THEMES)}

meta = {}
for f in sorted(os.listdir(SITE)):
    if not f.endswith('.html'):
        continue
    src = open(os.path.join(SITE, f), encoding='utf-8').read()
    m = re.search(r'<main><h1>(.*?)</h1><p class="tema">Tema: (.*?)</p>', src)
    if m:
        meta[f[:-5]] = (html.unescape(m.group(1)), html.unescape(m.group(2)))

words = json.load(open('words.json', encoding='utf-8'))
assert set(words) == set(meta), 'words.json vs site mismatch'
ids = sorted(words)
idx = {w: i for i, w in enumerate(ids)}
lay = json.loads(open('tmp_layout.json', 'rb').read().decode('cp1252'))  # written with default ANSI codec by extract.py
assert lay['ids'] == ids, 'layout order mismatch'

D = {
    'W': ids,
    'L': [meta[w][0] for w in ids],
    'T': [theme_ix[meta[w][1]] for w in ids],
    'THEMES': [{'n': n, 'c': c} for n, c in THEMES],
    'P': lay['pos'],
    'A': [[idx[t] for t in words[w]] for w in ids],
    'E': [[idx[a], idx[b]] for a in ids for b in words[a] if idx[a] < idx[b]],
    'TOP': json.load(open('result.json', encoding='utf-8'))['most_connected'],
}
tpl = open('template.html', encoding='utf-8').read()
out = tpl.replace('__DATA__', json.dumps(D, ensure_ascii=False, separators=(',', ':')))
os.makedirs('universe', exist_ok=True)
open('universe/index.html', 'w', encoding='utf-8').write(out)
print('words', len(ids), 'edges', len(D['E']), 'bytes', len(out.encode('utf-8')))