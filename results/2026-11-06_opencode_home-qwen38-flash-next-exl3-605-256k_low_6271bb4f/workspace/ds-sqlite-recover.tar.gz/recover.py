import struct, json

d = open('prices.db', 'rb').read()

def varint(b, i):
    v = 0
    for k in range(9):
        c = b[i + k]
        v = (v << 7) | (c & 0x7F)
        i += 1
        if not c & 0x80:
            break
    return v, i

def serial(b, i, t):
    if t == 0:
        return None, i
    if t == 1:
        return struct.unpack('>b', b[i:i+1])[0], i+1
    if t == 2:
        return struct.unpack('>h', b[i:i+2])[0], i+2
    if t == 3:
        return int.from_bytes(b[i:i+3], 'big', signed=True), i+3
    if t == 4:
        return struct.unpack('>i', b[i:i+4])[0], i+4
    if t == 5:
        return int.from_bytes(b[i:i+6], 'big', signed=True), i+6
    if t == 6:
        return struct.unpack('>q', b[i:i+8])[0], i+8
    if t == 7:
        return struct.unpack('>d', b[i:i+8])[0], i+8
    if t == 8:
        return 0, i
    if t == 9:
        return 1, i
    if t >= 13 and t % 2 == 1:
        n = (t - 13) // 2
        return b[i:i+n].decode('utf-8'), i+n
    if t >= 12 and t % 2 == 0:
        n = (t - 12) // 2
        return b[i:i+n], i+n
    raise ValueError('unknown serial type %d at %d' % (t, i))

assert d[0] == 0x0D, 'not a leaf table b-tree page: 0x%02x' % d[0]
ncell = struct.unpack('>H', d[3:5])[0]
content = struct.unpack('>H', d[5:7])[0]
freeblk = struct.unpack('>H', d[1:3])[0]
frag = d[7]
print('cells=%d content_start=%d first_freeblock=%d fragmented=%d' % (ncell, content, freeblk, frag))

slack = d[8 + 2*ncell:content]
print('unallocated slack all zero:', set(slack) == {0}, 'len', len(slack))

rows = []
for p in range(ncell):
    off = struct.unpack('>H', d[8 + 2*p:10 + 2*p])[0]
    plen, i = varint(d, off)
    rowid, i = varint(d, i)
    hdr_start = i
    hlen, j = varint(d, i)
    types = []
    while j < hdr_start + hlen:
        t, j = varint(d, j)
        types.append(t)
    vals = []
    for t in types:
        v, j = serial(d, j, t)
        vals.append(v)
    assert j == hdr_start + plen, 'cell size mismatch at %d' % off
    print('cell off=%d rowid=%d payload=%d consumed=%d vals=%r' % (off, rowid, plen, j - off, vals))
    rows.append(vals)

out = []
for vals in rows:
    nonnull = [v for v in vals if v is not None]
    item = next(v for v in nonnull if isinstance(v, str))
    price = next(v for v in nonnull if isinstance(v, (int, float)))
    out.append({'item': item, 'price': price})

with open('recovered.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print('wrote', len(out), 'rows')