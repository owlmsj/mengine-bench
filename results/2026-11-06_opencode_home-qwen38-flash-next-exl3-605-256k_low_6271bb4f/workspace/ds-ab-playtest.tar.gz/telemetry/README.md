# Playtest A/B - Pixel Arena tutorial

Export from arena-panel. The ETL resends sessions: `session_id` is the unique key (repeated rows are the same session). `variant` may come lowercase or with a leading space. `completed_tutorial` is 0/1.

Release rule: a variant ships only when its gain in tutorial completion is statistically significant at the 5% level.
