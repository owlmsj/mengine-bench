import csv, random, math
from collections import defaultdict

rows = list(csv.DictReader(open('telemetry/playtest_ab.csv', newline='', encoding='utf-8-sig')))
sess = {}
for r in rows:
    sess[r['session_id'].strip()] = (r['variant'].strip().lower(), r['player_id'].strip(), int(r['completed_tutorial']))

# cluster = player
by_player = defaultdict(lambda: {'a': [], 'b': []})
for sid, (v, p, c) in sorted(sess.items()):
    by_player[p][v].append(c)

players = list(by_player)
na = sum(len(by_player[p]['a']) for p in players)
nb = sum(len(by_player[p]['b']) for p in players)
ka = sum(sum(by_player[p]['a']) for p in players)
kb = sum(sum(by_player[p]['b']) for p in players)
pa, pb = ka / na, kb / nb
print(f'sessions A={na} B={nb}  players={len(players)}  sessions/player max={max(len(by_player[p]["a"])+len(by_player[p]["b"]) for p in players)}')
print(f'naive: pa={pa:.4f} pb={pb:.4f} diff={pb-pa:.4f}')

# ICC of completion within player (across arms, overall)
allsess = [c for p in players for c in by_player[p]['a'] + by_player[p]['b']]
gm = sum(allsess) / len(allsess)
num = 0.0; den = 0.0
for p in players:
    v = by_player[p]['a'] + by_player[p]['b']
    n = len(v); m = sum(v) / n
    num += n * (m - gm) ** 2
    den += (n - 1) * (gm * (1 - gm))
icc = (num - (len(players) - 1) * gm * (1 - gm) * 0) / (num + den) if False else num / (num + den)
deff = 1 + (sum(len(by_player[p]['a']) + len(by_player[p]['b']) for p in players) / len(players) - 1) * icc
print(f'ICC(player)={icc:.3f}  design effect~{deff:.2f}')

# cluster bootstrap over players
random.seed(7)
B = 20000
obs = pb - pa
cnt = 0
diffs = []
for _ in range(B):
    sa = []; sb = []
    for _ in range(len(players)):
        d = by_player[random.choice(players)]
        sa += d['a']; sb += d['b']
    d = (sum(sb) / len(sb)) - (sum(sa) / len(sa)) if sa and sb else 0.0
    diffs.append(d)
lo, hi = sorted(diffs)[int(0.025 * B)], sorted(diffs)[int(0.975 * B)]
boot_p = 2 * min(sum(1 for d in diffs if d <= 0), sum(1 for d in diffs if d >= 0)) / B
print(f'cluster bootstrap: diff 95% CI [{lo:.4f}, {hi:.4f}]  p={boot_p:.4f}')

# within-player paired (McNemar) on players with sessions in both arms
b_only = sum(1 for p in players if by_player[p]['a'] and by_player[p]['b']
             and sum(by_player[p]['b']) / len(by_player[p]['b']) == 1 and sum(by_player[p]['a']) / len(by_player[p]['a']) == 0)
c_only = sum(1 for p in players if by_player[p]['a'] and by_player[p]['b']
             and sum(by_player[p]['a']) / len(by_player[p]['a']) == 1 and sum(by_player[p]['b']) / len(by_player[p]['b']) == 0)
n_pair = sum(1 for p in players if by_player[p]['a'] and by_player[p]['b'])
print(f'players in both arms={n_pair}  B-only-completers={b_only}  A-only-completers={c_only}')
n = b_only + c_only
if n:
    ph = b_only / n
    se = math.sqrt(ph * (1 - ph) / n)
    z = (ph - 0.5) / se
    print(f'McNemar z={z:.3f} p={math.erfc(abs(z)/math.sqrt(2)):.4g}')