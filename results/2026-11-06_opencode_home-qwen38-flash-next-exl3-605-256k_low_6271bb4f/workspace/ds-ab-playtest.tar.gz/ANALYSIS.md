# Pixel Arena tutorial A/B: ship B

Recommendation: ship B. The gain clears the 5% release bar under every analysis
that fits the export, including the conservative ones.

## Data handling (telemetry/playtest_ab.csv)
- 1870 raw rows, 1800 unique `session_id`. 70 duplicate rows dropped as ETL resends
  (README: repeated rows are the same session). Zero duplicate ids with conflicting
  variant/completion values, so dedupe is lossless.
- `variant` normalized: stripped and lowercased (`" B"`, `"b"` etc.). After that:
  900 sessions per arm, no unknown variants, `completed_tutorial` all 0/1.
- Completion is counted per session (the export's unit), not per player.

## Result
| arm | sessions | completions | rate |
|-----|----------|-------------|------|
| A   | 900      | 342         | 38.00% |
| B   | 900      | 420         | 46.67% |

Difference +8.67 points. Two-proportion z-test (pooled), two-sided:
z = 3.721, p = 0.000198. Fisher exact two-sided agrees: p = 0.0002.

## Why this survives a skeptical review
Randomization is at session level, and 763 players contribute up to 8 sessions,
366 of them in both arms. Sessions are therefore not independent, and the naive
p is optimistic. Both robustness checks still reject at 5%:

- Player-cluster bootstrap (resample players, 20k reps): diff 95% CI
  [0.040, 0.134], p = 0.0001. ICC within player ~0.42, design effect ~1.58.
- Within-player McNemar on the 366 players seen in both arms: 66 players complete
  only under B vs 41 only under A, z = 2.49, p = 0.013. This removes player skill
  and motivation as confounders entirely.
- Naive Wald CI: [0.041, 0.132].

The effect is also practically meaningful (+8.7 points on tutorial completion).

## Assumptions
- The release rule's "statistically significant at the 5% level" means a two-sided
  test on the completion-rate difference.
- `session_id` is the unit of analysis; a player's repeat sessions are separate
  playtests (that is what the panel exports).
- No missing or malformed rows beyond the variant formatting the README warns about.

## Caveat for the next test
Crossover (366 players in both arms) and repeat playtests make this a weaker design
than a clean per-player split. Randomize by `player_id` next time; the conclusion
here is robust enough to ship, but the interval is wider than the naive CI suggests.

Reproduce: `python analyze.py` (counts, z-test, Fisher), `python cluster.py`
(ICC, cluster bootstrap, McNemar).