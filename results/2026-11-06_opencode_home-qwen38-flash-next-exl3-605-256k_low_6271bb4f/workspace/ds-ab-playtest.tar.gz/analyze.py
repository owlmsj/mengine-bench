import csv, math
from collections import defaultdict

rows = list(csv.DictReader(open('telemetry/playtest_ab.csv', newline='', encoding='utf-8-sig')))
print('raw rows:', len(rows))

# dedupe by session_id (repeated rows are the same session)
by_id = {}
conflicts = 0
for r in rows:
    sid = r['session_id'].strip()
    rec = (r['variant'].strip().lower(), int(r['completed_tutorial']))
    if sid in by_id and by_id[sid] != rec:
        conflicts += 1
    by_id[sid] = rec
print('unique sessions:', len(by_id), 'conflicting dup ids:', conflicts)

# check odd values
bad = [s for s, (v, c) in by_id.items() if v not in ('a', 'b') or c not in (0, 1)]
print('bad records:', len(bad), bad[:5])

a = [c for v, c in by_id.values() if v == 'a']
b = [c for v, c in by_id.values() if v == 'b']
na, nb = len(a), len(b)
ka, kb = sum(a), sum(b)
pa, pb = ka / na, kb / nb
print(f'A: {ka}/{na} = {pa:.4f}')
print(f'B: {kb}/{nb} = {pb:.4f}')

# two-proportion z-test (pooled)
p = (ka + kb) / (na + nb)
se = math.sqrt(p * (1 - p) * (1 / na + 1 / nb))
z = (pb - pa) / se
pval = math.erfc(abs(z) / math.sqrt(2))
print(f'z = {z:.4f}, two-sided p = {pval:.4f}')

# sanity: Fisher exact two-sided
from itertools import combinations
def fisher_p(k1, n1, k2, n2):
    from math import comb
    tot = k1 + k2
    lo, hi = max(0, tot - n2), min(n1, tot)
    def p_at(x):
        return comb(n1, x) * comb(n2, tot - x) / comb(n1 + n2, tot)
    p_obs = p_at(k1)
    return sum(p_at(x) for x in range(lo, hi + 1) if p_at(x) <= p_obs * (1 + 1e-9))

fp = fisher_p(ka, na, kb, nb)
print(f'fisher two-sided p = {fp:.4f}')