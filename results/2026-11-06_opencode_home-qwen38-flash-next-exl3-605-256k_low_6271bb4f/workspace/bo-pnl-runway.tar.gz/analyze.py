import csv, json
from collections import defaultdict

# account -> pnl_line
pnl = {}
with open('finance/chart_of_accounts.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        pnl[row['account']] = row['pnl_line']

def br(x):
    return float(x.replace('.', '').replace(',', '.'))

# month -> pnl_line -> sum
m = defaultdict(lambda: defaultdict(float))
with open('finance/ledger.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        d, mo, y = row['date'].split('/')
        key = f'{y}-{mo}'
        m[key][pnl[row['account']]] += br(row['amount'])

months = [f'2026-{i:02d}' for i in range(1, 7)]
rev, gm, ebitda = {}, {}, {}
for k in months:
    r = m[k]['revenue']
    cogs = m[k]['cogs']
    opex = m[k]['sales_marketing'] + m[k]['rnd'] + m[k]['ga']
    eb = r + cogs + opex  # cogs/opex are negative
    rev[k] = round(r, 2)
    gm[k] = round((r + cogs) / r * 100, 2)
    ebitda[k] = round(eb, 2)

# burn = avg monthly negative EBITDA of last 3 closed months (Apr,May,Jun)
last3 = months[-3:]
neg = [-ebitda[k] for k in last3]
burn = round(sum(neg) / len(neg), 2)
cash = 1847350.40  # latest closing balance 30/06/2026
runway = round(cash / burn, 2)

out = {
    'revenue': rev,
    'gross_margin_pct': gm,
    'ebitda': ebitda,
    'burn': burn,
    'runway_months': runway,
}
with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, indent=2)

for k in months:
    print(k, 'rev', rev[k], 'gm%', gm[k], 'ebitda', ebitda[k],
          'cogs', round(m[k]['cogs'], 2), 'fin', round(m[k]['financial'], 2))
print('burn', burn, 'runway', runway, 'cash', cash)