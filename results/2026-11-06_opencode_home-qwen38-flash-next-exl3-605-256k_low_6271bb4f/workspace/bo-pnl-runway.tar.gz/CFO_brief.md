# CFO Brief - H1 2026 Close (for investor meeting)

Currency: BRL (R$). Source: `finance/ledger.csv`, `finance/chart_of_accounts.csv`,
`finance/cash_balance.txt`. Definitions follow `finance/README.md` (board's notes).

## Headline
- Revenue grew every month of H1: R$ 200.5k (Jan) to R$ 272.4k (Jun), +35.9%.
- Gross margin held near 70% (68.5%-72.4%), ending at the H1 high of 72.4% in Jun.
- EBITDA still negative but improving: -R$ 210.3k (Jan) to -R$ 193.0k (Jun).
- Burn (board definition) = R$ 197,288.23/month. Runway = 9.36 months from 30/06/2026.
- Cash on 30/06/2026: R$ 1,847,350.40.

## Monthly (H1 2026)
| Month | Revenue | Gross margin % | EBITDA |
|-------|---------|----------------|--------|
| 2026-01 | 200,510.87 | 70.03 | -210,278.96 |
| 2026-02 | 216,328.06 | 70.29 | -212,300.08 |
| 2026-03 | 219,066.17 | 68.46 | -204,525.45 |
| 2026-04 | 238,163.26 | 70.24 | -196,950.65 |
| 2026-05 | 243,032.89 | 69.56 | -201,945.82 |
| 2026-06 | 272,391.57 | 72.41 | -192,968.22 |

## Burn and runway (board method)
- Burn = average monthly negative EBITDA of the last three closed months (Apr, May, Jun):
  (196,950.65 + 201,945.82 + 192,968.22) / 3 = **R$ 197,288.23**.
- Runway = latest closing cash (R$ 1,847,350.40) / burn = **9.36 months**
  (cash-out around late March 2027 if nothing changes).

## Method / assumptions
- Revenue = SaaS subs (3.1.01) + onboarding (3.1.02) + refunds (3.1.09, negative).
- Gross margin = (revenue - COGS) / revenue; COGS = cloud/GPUs (4.1.01) + support (4.1.02).
- EBITDA = revenue - COGS - opex (S&M, R&D, G&A). The financial line (6.1.x,
  investment income and interest/IOF) is excluded, as it sits below EBITDA.
- Runway uses the given 30/06/2026 consolidated balance (R$ 1,847,350.40), not a
  ledger-derived figure; capex and working-capital moves are not in this ledger.
- Note: June cash fell R$ 461.8k vs the R$ 193.0k EBITDA loss, so non-EBITDA cash
  outflows (capex/working capital) are material; runway on EBITDA burn is optimistic.

## Talking points
1. Growth and margin are on track; cost base is flat, so operating leverage is showing.
2. Losses narrowing month over month; on current trend, EBITDA breakeven is not in H2.
3. ~9 months of runway means a raise or cost action is needed before year end.
4. Flag the June cash gap so the runway number is not read as pure operating burn.