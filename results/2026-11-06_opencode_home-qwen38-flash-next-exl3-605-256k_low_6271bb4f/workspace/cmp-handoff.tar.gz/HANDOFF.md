# HANDOFF: local-9b Q5 at 128k context

Goal: run local-9b Q5 at 128k on this Windows/WDDM box without VRAM spill.

Done:
- Baseline `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`: 37.8 t/s, 7881 MiB. That VRAM is the WDDM ceiling: Shared Usage showed 1494 MiB spilled, so the measurement did not count.
- Fix: `--no-mmproj-offload` + `-ub 512` removes the spill. Final: 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k; dropped. Q4_K_M fits (7305 MiB, 40.4 t/s), kept only as fallback.
- Recipe applied in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

Open:
- evals README still cites check_vision.ps1, a deleted file; update it.
- Relaunch via start_server.ps1 and rerun measure_decode.ps1 to confirm the committed recipe reproduces 7697 MiB / 38.0 t/s.

Assumptions: numbers above are the recorded measurements; other diffs seen were formatting-only.