import csv, statistics
rows = list(csv.DictReader(open('capture/presentmon.csv')))
t = [float(r['TimeInSeconds']) for r in rows]
ms = [float(r['MsBetweenPresents']) for r in rows]
rc = [float(r['MsUntilRenderComplete']) for r in rows]
med = statistics.median(ms)
def win(a, b):
    x = [m for tt, m in zip(t, ms) if a <= tt < b]
    return (len(x), round(statistics.median(x), 2), round(max(x), 2))
print('normal 20-21', win(20, 21))
print('defender 43-46', win(43, 46))
print('hitch 2.4-2.7', win(2.4, 2.7))
# per-second max
per = {}
for tt, m in zip(t, ms):
    per.setdefault(int(tt), []).append(m)
for s in sorted(per):
    print(s, round(max(per[s]), 1), round(statistics.median(per[s]), 2), len(per[s]))
# render complete during hitch vs normal
h = [r for r, m in zip(rc, ms) if m > 3 * med]
n = [r for r, m in zip(rc, ms) if m <= 3 * med]
print('MsUntilRenderComplete hitch mean', round(statistics.mean(h), 2), 'normal mean', round(statistics.mean(n), 2))
s = sorted(ms)
print('p99', s[int(round(0.99*len(s)))-1], 'avg', round(1000/statistics.mean(ms),2), '1low', round(1000/s[int(round(0.99*len(s)))-1],2))
print('hitch frames', len(h), 'bursts', 15)