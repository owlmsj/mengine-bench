import csv, json, statistics
r = json.load(open('result.json'))
rows = list(csv.DictReader(open('capture/presentmon.csv')))
t = [float(x['TimeInSeconds']) for x in rows]
ms = [float(x['MsBetweenPresents']) for x in rows]
s = sorted(ms)
p99 = s[int(round(0.99*len(s)))-1]
avg = round(1000/statistics.mean(ms), 2)
low = round(1000/p99, 2)
print('json', r['avg_fps'], r['low_1pct_fps'], 'calc', avg, low, 'match', avg == r['avg_fps'] and low == r['low_1pct_fps'])
sen = list(csv.DictReader(open('capture/sensors.csv')))
l1 = sorted(int(x['time_s']) for x in sen if x['gpu_pcie_link_state'] == 'L1')
med = statistics.median(ms)
hs = sorted(set(int(a) for a, b in zip(t, ms) if b > 3*med))
print('L1 secs', l1)
print('hitch secs', hs)
print('identical', l1 == hs)
print('burst frames', sum(1 for b in ms if b > 3*med), 'pct', round(100*sum(1 for b in ms if b>3*med)/len(ms), 2))
print('max frame in s43-45', round(max(m for a, m in zip(t, ms) if 43 <= a < 46), 2))
print('settings present:', [x for x in json.load(open('settings.json'))['settings'] if x['setting'].startswith('pcie_aspm')])