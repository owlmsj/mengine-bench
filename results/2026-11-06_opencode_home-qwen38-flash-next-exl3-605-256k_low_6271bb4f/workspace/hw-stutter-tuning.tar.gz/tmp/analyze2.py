import csv, statistics
sen = list(csv.DictReader(open('capture/sensors.csv')))
print(len(sen))
rows = list(csv.DictReader(open('capture/presentmon.csv')))
t = [float(r['TimeInSeconds']) for r in rows]
ms = [float(r['MsBetweenPresents']) for r in rows]
med = statistics.median(ms)
hitch_sec = set()
for a, b in zip(t, ms):
    if b > 3 * med:
        hitch_sec.add(int(a))
print('hitch seconds', sorted(hitch_sec))
hdr = list(sen[0].keys())
print(','.join(hdr))
for r in sen:
    mark = 'HITCH' if int(r['time_s']) in hitch_sec else ''
    print(','.join(r[h] for h in hdr), mark)