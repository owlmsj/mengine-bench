import csv, statistics, collections
rows = list(csv.DictReader(open('capture/presentmon.csv')))
t = [float(r['TimeInSeconds']) for r in rows]
ms = [float(r['MsBetweenPresents']) for r in rows]
print('n', len(rows), 'span', t[-1])
mean = statistics.mean(ms)
s = sorted(ms)
p99 = s[int(round(0.99 * len(s))) - 1]
print('avg fps', round(1000 / mean, 2), 'p99 ms', p99, '1pct low', round(1000 / p99, 2))
print(collections.Counter(r['Dropped'] for r in rows))
med = statistics.median(ms)
print('median', med)
hi = [(a, b) for a, b in zip(t, ms) if b > 3 * med]
print('num hitches', len(hi))
print([(round(a, 2), b) for a, b in hi[:30]])
gaps = [round(hi[i + 1][0] - hi[i][0], 2) for i in range(len(hi) - 1)]
print('gaps', gaps[:40])
print('mean gap', statistics.mean(gaps) if gaps else None)