use arena_scores::Board;
use std::sync::Arc;
use std::thread;

// Regression: transfer(x, x, _) deadlocked on the same per-player mutex,
// and award()'s unlocked read-modify-write lost concurrent updates.
#[test]
fn many_threads_keep_the_scores() {
    const THREADS: u64 = 8;
    const ROUNDS: u64 = 2000;

    let board = Arc::new(Board::new());
    board.join(1, 0);
    board.join(2, 0);

    let handles: Vec<_> = (0..THREADS)
        .map(|_| {
            let board = Arc::clone(&board);
            thread::spawn(move || {
                for _ in 0..ROUNDS {
                    board.award(1, 1);
                    // Same-player transfer: must be a no-op, not a hang.
                    board.transfer(1, 1, 1);
                    board.transfer(1, 2, 1);
                    board.transfer(2, 1, 1);
                }
            })
        })
        .collect();
    for h in handles {
        h.join().unwrap();
    }

    let awarded = THREADS as i64 * ROUNDS as i64;
    assert_eq!(board.total(), awarded, "lost updates in total");
    assert_eq!(board.score(1) + board.score(2), awarded, "lost updates in scores");
}