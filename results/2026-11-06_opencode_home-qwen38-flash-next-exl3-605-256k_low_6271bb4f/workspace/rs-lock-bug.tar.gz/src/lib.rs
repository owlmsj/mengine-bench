//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

#[derive(Default)]
struct Inner {
    players: HashMap<PlayerId, i64>,
    total: i64,
}

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    inner: Arc<Mutex<Inner>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        let mut inner = self.inner.lock().unwrap();
        inner.players.insert(id, score);
        inner.total += score;
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let mut inner = self.inner.lock().unwrap();
        *inner.players.entry(id).or_insert(0) += points;
        inner.total += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let mut inner = self.inner.lock().unwrap();
        if from == to {
            return;
        }
        *inner.players.entry(from).or_insert(0) -= points;
        *inner.players.entry(to).or_insert(0) += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        self.inner.lock().unwrap().players.get(&id).copied().unwrap_or(0)
    }

    pub fn total(&self) -> i64 {
        self.inner.lock().unwrap().total
    }
}