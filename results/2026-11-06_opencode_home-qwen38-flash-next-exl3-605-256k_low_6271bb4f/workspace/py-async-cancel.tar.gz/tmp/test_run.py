import asyncio
import time

from run import run_tasks

running = 0
peak = 0
cleaned = []
results = []


async def check(name, dur, fail=False):
    global running, peak
    running += 1
    peak = max(peak, running)
    try:
        await asyncio.sleep(dur)
        if fail:
            raise RuntimeError(name)
        results.append(name)
        return name
    finally:
        running -= 1
        cleaned.append(name)


async def t1():
    global peak, results, cleaned
    peak = 0
    results = []
    cleaned = []
    out = await run_tasks([lambda d=d: check(f"j{d}", d / 10) for d in range(6)], 2)
    assert out == [f"j{d}" for d in range(6)], out
    assert peak == 2, peak
    assert cleaned == [f"j{d}" for d in range(6)]
    print("T1 cap+order+done OK, peak =", peak)


async def t2():
    global peak, cleaned
    peak = 0
    cleaned = []
    runner = asyncio.create_task(run_tasks([lambda: check("c", 5)], 2))
    await asyncio.sleep(0.1)
    runner.cancel()  # simulates Ctrl+C: asyncio.run cancels the main task
    try:
        await runner
        raise AssertionError("expected CancelledError")
    except asyncio.CancelledError:
        pass
    assert cleaned == ["c"], cleaned
    print("T2 cleanup-on-cancel OK, cleaned =", cleaned)


async def t3():
    global cleaned
    cleaned = []
    try:
        await run_tasks(
            [lambda: check("ok", 0.05), lambda: check("bad", 0.05, fail=True)], 2
        )
        raise AssertionError("expected RuntimeError")
    except RuntimeError as e:
        assert str(e) == "bad"
    assert sorted(cleaned) == ["bad", "ok"], cleaned
    print("T3 error-after-all-done OK, cleaned =", cleaned)


async def main():
    await t1()
    await t2()
    await t3()
    print("ALL OK")


asyncio.run(main())