"""Batch helper: run zero-argument async task callables with a concurrency cap.

Usage:
    from run import run_tasks

    async def main():
        await run_tasks([make_job_a, make_job_b], max_concurrent=4)

Each task is a zero-argument callable that returns an awaitable job.
At most `max_concurrent` jobs run at once. run_tasks returns when every
job is done.

Assumptions (the brief leaves these open):
- On Ctrl+C (KeyboardInterrupt) or task cancellation, every running job is
  cancelled and then awaited, so each job's cleanup (finally blocks, async
  context managers) finishes before the interrupt propagates. Jobs that have
  not started yet are cancelled too; their bodies never run.
- KeyboardInterrupt is re-raised after cleanup so the caller sees the stop.
- If a job raises, the first exception is re-raised after all jobs finish;
  remaining jobs are not cancelled (a failing job should not kill the batch).
- max_concurrent must be >= 1.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Iterable
from typing import Any, TypeVar

T = TypeVar("T")


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[T]]],
    max_concurrent: int,
) -> list[T]:
    """Run all tasks, at most `max_concurrent` jobs in flight, until done.

    Args:
        tasks: zero-argument callables, each returning an awaitable job.
        max_concurrent: maximum number of jobs running simultaneously.

    Returns:
        Job results in task order.

    Raises:
        ValueError: if max_concurrent < 1.
        Exception: the first job error, after all jobs have finished.
        KeyboardInterrupt / CancelledError: after all cleanup has run.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent}")

    semaphore = asyncio.Semaphore(max_concurrent)

    async def guarded(task: Callable[[], Awaitable[T]]) -> T:
        async with semaphore:
            return await task()

    jobs = [asyncio.ensure_future(guarded(t)) for t in tasks]
    try:
        return await asyncio.gather(*jobs)
    except (KeyboardInterrupt, asyncio.CancelledError):
        # Stop the run, but let every job finish its cleanup first.
        for job in jobs:
            job.cancel()
        # return_exceptions=True: collect cleanup-time errors, do not mask
        # the interrupt; finally blocks still run to completion.
        await asyncio.gather(*jobs, return_exceptions=True)
        raise
    except BaseException:
        # A job raised: let the others finish normally, then re-raise the
        # first error. gather() already delivered this exception, so the
        # remaining jobs are still running; wait for them.
        await asyncio.gather(*jobs, return_exceptions=True)
        raise