import sqlite3
con = sqlite3.connect('analytics.db')
for name, sql in con.execute("SELECT name, sql FROM sqlite_master WHERE type='table'"):
    print(name, '|', sql)
    print('rows:', con.execute(f'SELECT COUNT(*) FROM "{name}"').fetchone()[0])
    for row in con.execute(f'SELECT * FROM "{name}" LIMIT 5'):
        print(row)