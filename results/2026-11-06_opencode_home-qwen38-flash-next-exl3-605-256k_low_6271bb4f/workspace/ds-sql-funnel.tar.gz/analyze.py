import json, sqlite3
from collections import defaultdict

STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']
con = sqlite3.connect('analytics.db')

users = {u: (p, t) for u, p, t in con.execute('SELECT user_id, platform, is_test FROM users')}

# events per (user, step) -> list of ts, skipping unknown players and test accounts
ev = defaultdict(lambda: defaultdict(list))
for u, name, ts in con.execute('SELECT user_id, name, ts FROM events'):
    if u not in users or users[u][1] or name not in STEPS:
        continue
    ev[u][name].append(ts)

counts = defaultdict(lambda: {s: 0 for s in STEPS})
for u, by_step in ev.items():
    platform = users[u][0]
    prev = ''  # no time limit; '' sorts before any ts
    for s in STEPS:
        ok = [t for t in by_step.get(s, []) if t >= prev]
        if not ok:
            break
        prev = min(ok)  # first valid occurrence
        counts[platform][s] += 1

funnel = {p: counts[p] for p in sorted(counts)}
biggest = {}
for p, c in funnel.items():
    convs = {}
    for prev_s, s in zip(STEPS, STEPS[1:]):
        convs[s] = c[s] / c[prev_s] if c[prev_s] else 0.0
    biggest[p] = min(convs, key=convs.get)
    print(p, funnel[p], {k: round(v, 3) for k, v in convs.items()})

with open('result.json', 'w') as f:
    json.dump({'funnel': funnel, 'biggest_drop': biggest}, f, indent=2)
print('unknown-player events skipped:',
      con.execute('SELECT COUNT(*) FROM events WHERE user_id NOT IN (SELECT user_id FROM users)').fetchone()[0])