import csv, json, re
from collections import defaultdict

inv = {}
with open("backoffice/invoices.csv", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        inv[r["id"]] = float(r["amount"])

pay = defaultdict(list)
with open("backoffice/bank_statement_june.csv", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        m = re.search(r"(?:invoice |inv-?)(\d{4})", r["memo"], re.I)
        if not m:
            continue  # fees, interest, unidentified PIX
        iid = f"INV-{m.group(1)}"
        if iid in inv:
            pay[iid].append(float(r["amount"]))

unpaid = [i for i in inv if i not in pay]
duplicated = [i for i in inv if len(pay[i]) > 1]
mismatched = [{"id": i, "invoiced": inv[i], "paid": pay[i][0]}
              for i in inv if len(pay[i]) == 1 and abs(pay[i][0] - inv[i]) > 0.005]

result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
print(json.dumps(result, indent=2, ensure_ascii=False))
print("counts:", len(unpaid), len(duplicated), len(mismatched),
      "total invoices:", len(inv), "paid ids:", len(pay))