import re
pat = open('regex.txt', encoding='utf-8').read().strip()
rx = re.compile(pat, re.MULTILINE)

cases = [
    # (line, expected findall results)
    ("2026-04-02 07:15:09 INFO  gateway accepted 10.12.0.7 for build 2026-04-01", ["2026-04-01"]),
    ("2026-04-02 07:15:11 INFO  cache warm, 412 keys, next sweep 2026-04-03", []),
    ("2026-04-02 07:16:40 WARN  peer 192.168.40.3 slow, retry window 2026-04-02 to 2026-04-05", ["2026-04-05"]),
    ("2026-04-02 07:18:02 INFO  job 7781-20-4410 queued by scheduler", []),
    ("2026-04-02 07:19:30 ERROR upstream 172.20.1.14 refused handshake", ["2026-04-02"]),
    # invalid dates
    ("ip 1.1.1.1 bad 2026-02-30 ok 2026-02-29", ["2026-02-29"]),
    ("ip 1.1.1.1 bad 2026-04-31", []),
    ("ip 1.1.1.1 bad 2026-13-01", []),
    ("ip 1.1.1.1 2026-00-10", []),
    ("ip 1.1.1.1 2026-01-00", []),
    ("ip 1.1.1.1 2025-12-31 2026-02-29 2026-01-31", ["2026-01-31"]),
    # adjacency
    ("x2026-04-01 ip 1.1.1.1 2026-04-02", ["2026-04-02"]),
    ("ip 1.1.1.1 2026-04-02x", []),
    ("ip 1.1.1.1 92026-04-02", []),
    ("ip 1.1.1.1 2026-04-021", []),
    ("ip91.1.1.1 2026-04-02", []),
    ("ip 1.1.1.19 2026-04-02", []),
    ("ip 1.1.1.1.2 2026-04-02", ["2026-04-02"]),  # dot adjacency allowed per brief
    # octets
    ("ip 255.255.255.255 2026-04-02", ["2026-04-02"]),
    ("ip 256.1.1.1 2026-04-02", []),
    ("ip 010.1.1.1 2026-04-02", []),
    ("ip 10.1.1.01 2026-04-02", []),
    ("ip 0.0.0.0 2026-04-02", ["2026-04-02"]),
    # ip after last date still counts
    ("2026-04-02 then 2026-04-03 text 10.0.0.1", ["2026-04-03"]),
    # no date, has ip
    ("just 10.0.0.1 no date", []),
    # underscore adjacency: brief says only letter/digit disqualify
    ("_2026-04-02_ ip 1.1.1.1", ["2026-04-02"]),
    # ipv6-ish / long digit runs
    ("ip 1.1.1.1 12026-04-02", []),
    ("ip 1.1.1.1 2026-04-02 2026-6-1", ["2026-04-02"]),
]
ok = True
for line, exp in cases:
    got = rx.findall(line)
    if got != exp:
        ok = False
        print("FAIL", repr(line), "exp", exp, "got", got)

text = open('server.log', encoding='utf-8').read()
res = rx.findall(text, re.MULTILINE)
print("server.log:", res)
print("ALL PASS" if ok else "FAILURES")