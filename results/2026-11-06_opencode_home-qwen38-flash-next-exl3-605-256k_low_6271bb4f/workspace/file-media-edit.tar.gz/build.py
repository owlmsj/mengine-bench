import io, os
from PIL import Image
from pypdf import PdfReader, PdfWriter
from pypdf.generic import (NameObject, NumberObject, TextStringObject,
                           DictionaryObject, ArrayObject, StreamObject)

os.makedirs('out', exist_ok=True)

# 1) feed photo: 1080x1350 crop containing the magenta balloon fully
im = Image.open('launch.jpg').convert('RGB')
W, H = im.size
arr = __import__('numpy').asarray(im).astype(int)
r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
mag = (r - g > 25) & (b - g > 10) & (r > 90)
ys, xs = __import__('numpy').nonzero(mag)
bx0, bx1, by0, by1 = xs.min(), xs.max(), ys.min(), ys.max()
bw, bh = bx1 - bx0 + 1, by1 - by0 + 1
cx, cy = (bx0 + bx1) / 2, (by0 + by1) / 2

# target 4:5 portrait, balloon centred with margin, inside the source
crop_w = max(1080, int(bw * 3))
crop_w = min(crop_w, W, int(H * 0.8))
crop_h = int(crop_w / 1080 * 1350)
x0 = min(max(int(cx - crop_w / 2), 0), W - crop_w)
y0 = min(max(int(cy - crop_h / 2), 0), H - crop_h)
crop = im.crop((x0, y0, x0 + crop_w, y0 + crop_h)).resize((1080, 1350), Image.LANCZOS)
crop.save('out/feed-photo.jpg', 'JPEG', quality=92)
print('crop box', (x0, y0, x0 + crop_w, y0 + crop_h), 'balloon bbox',
      (bx0, by0, bx1, by1), 'size', crop.size)

# 2) permit form: fill + flatten (values from event-details.txt)
VALUES = {
    'organizer': 'Tidewater Studio',
    'event_date': '2026-12-05',   # form label: Event date (YYYY-MM-DD)
    'location': 'North Cove Lawn',
    'attendees': 'about 40',
}
reader = PdfReader('permit-form.pdf')
writer = PdfWriter(clone_from=reader)
HELV = {  # Helvetica widths /1000 for the chars used
    ' ': 278, 'a': 556, 'b': 556, 'c': 500, 'd': 556, 'e': 556, 'f': 278,
    'g': 556, 'h': 556, 'i': 222, 'j': 222, 'k': 500, 'l': 222, 'm': 833,
    'n': 556, 'o': 556, 'p': 556, 'q': 556, 'r': 333, 's': 500, 't': 278,
    'u': 556, 'v': 500, 'w': 722, 'x': 500, 'y': 500, 'z': 500,
    '0': 556, '1': 556, '2': 556, '3': 556, '4': 556, '5': 556, '6': 556,
    '7': 556, '8': 556, '9': 556, '-': 333, '(': 333, ')': 333, '.': 278,
    'T': 611, 'S': 667, 'N': 722, 'D': 722, 'I': 278, 'P': 667,
}
def _helv_font(writer):
    f = DictionaryObject()
    f[NameObject('/Type')] = NameObject('/Font')
    f[NameObject('/Subtype')] = NameObject('/Type1')
    f[NameObject('/BaseFont')] = NameObject('/Helvetica')
    f[NameObject('/Encoding')] = NameObject('/WinAnsiEncoding')
    return f


count = 0
for page in writer.pages:
    annots = page.get('/Annots')
    if not annots:
        continue
    keep = ArrayObject()
    extra_ops = []
    for ref in list(annots):
        a = ref.get_object()
        if a.get('/FT') != '/Tx':
            keep.append(ref)
            continue
        name = str(a.get('/T'))
        text = VALUES[name]
        rect = [float(v) for v in a['/Rect']]
        w, h = rect[2] - rect[0], rect[3] - rect[1]
        size = 11.0
        tw = sum(HELV.get(c, 556) for c in text) / 1000 * size
        esc = text.replace('\\', r'\\').replace('(', r'\(').replace(')', r'\)')
        ap = StreamObject()
        ap[NameObject('/Type')] = NameObject('/XObject')
        ap[NameObject('/Subtype')] = NameObject('/Form')
        ap[NameObject('/BBox')] = ArrayObject([NumberObject(0), NumberObject(0),
                                               NumberObject(int(w)), NumberObject(int(h))])
        fonts = DictionaryObject()
        fonts[NameObject('/Helv')] = writer._add_object(_helv_font(writer))
        ap[NameObject('/Resources')] = DictionaryObject({
            NameObject('/Font'): fonts,
            NameObject('/ProcSet'): ArrayObject([NameObject('/PDF'), NameObject('/Text')]),
        })
        ap.set_data(f'BT /Helv {size:g} Tf 1 0 0 1 3 {(h - size) / 2 + 2:g} Tm '
                    f'({esc}) Tj ET'.encode())
        xobj_name = f'/Flt{count}'
        page['/Resources'].setdefault(NameObject('/XObject'), DictionaryObject())
        page['/Resources']['/XObject'][NameObject(xobj_name)] = writer._add_object(ap)
        extra_ops.append(f'\nq 1 0 0 1 {rect[0]:g} {rect[1]:g} cm '
                         f'{xobj_name} Do Q\n')
        count += 1
    merged = StreamObject()
    merged.set_data(page._get_contents_as_bytes() + ''.join(extra_ops).encode())
    page.replace_contents(merged)
    if len(keep) == 0:
        del page['/Annots']
    else:
        page[NameObject('/Annots')] = keep
if '/AcroForm' in writer._root_object:
    del writer._root_object['/AcroForm']
with open('out/permit-filled.pdf', 'wb') as f:
    writer.write(f)
print('flattened fields:', count)