import struct

data = open(r'prices.db', 'rb').read()
print('file_len', len(data))
print('magic', data[:16])
page_size = struct.unpack('>H', data[16:18])[0]
print('page_size', page_size)
db_size_pages = struct.unpack('>I', data[28:32])[0]
print('db_size_pages', db_size_pages)
print('hdr100_200', data[100:200])
print()
print('hex 0-100:', data[:100].hex())