import struct

data = open(r'prices.db', 'rb').read()
n = len(data)

# check for page boundaries at common page sizes
for ps in (512, 1024, 2048, 4096, 8192, 16384, 32768, 65536):
    if n % ps == 0 and n > ps:
        marks = [data[i] for i in range(0, n, ps)]
        print(ps, 'boundary bytes:', marks)

print()
# assume single 4096-byte table leaf page
b0 = data[0]
ncells = struct.unpack('>H', data[3:5])[0]
cell_start = struct.unpack('>H', data[5:7])[0]
print('type', b0, 'ncells', ncells, 'cell_start', cell_start)
ptrs = [struct.unpack('>H', data[8+2*i:10+2*i])[0] for i in range(ncells)]
print('cell ptrs', [hex(p) for p in ptrs])

def varint(buf, off):
    v = 0
    for i in range(9):
        b = buf[off+i]
        if i == 8:
            v = (v << 8) | b
            return v, off+9
        v = (v << 7) | (b & 0x7F)
        if not (b & 0x80):
            return v, off+i+1
    return v, off+9

def serial_type_size(st):
    if st >= 12:
        return (st-12)//2
    return {0:0,1:1,2:2,3:3,4:4,5:6,6:8,7:8,8:0,9:0}.get(st, 0)

rows = []
for p in ptrs:
    payload_len, o = varint(data, p)
    rowid, o = varint(data, o)
    # payload may be overflowed; assume local (page 4096, max local = 4096-35=4061)
    hdr_len, ho = varint(data, o)
    hdr_end = o + hdr_len
    stypes = []
    q = ho
    while q < hdr_end:
        st, q = varint(data, q)
        stypes.append(st)
    vals = []
    vo = hdr_end
    for st in stypes:
        sz = serial_type_size(st)
        raw = data[vo:vo+sz]
        vo += sz
        if st == 0:
            vals.append(None)
        elif st in (1,2,3,4,5,6,8):
            vals.append(int.from_bytes(raw, 'big', signed=True))
        elif st == 7:
            vals.append(struct.unpack('>d', raw)[0])
        elif st >= 13 and st % 2 == 1:
            vals.append(raw.decode('utf-8', 'replace'))
        else:
            vals.append(raw)
    rows.append((rowid, vals))
    print('rowid', rowid, 'payload_len', payload_len, 'stypes', stypes, 'vals', vals)

print()
print('total rows', len(rows))