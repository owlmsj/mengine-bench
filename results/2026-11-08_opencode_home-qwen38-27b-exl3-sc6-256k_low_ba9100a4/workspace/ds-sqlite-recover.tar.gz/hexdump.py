data = open(r'prices.db', 'rb').read()
for p in (0xff1, 0xfe3, 0xfcb):
    print(hex(p), data[p:p+30].hex(' '))
print()
print(data[3901:4096].hex(' '))