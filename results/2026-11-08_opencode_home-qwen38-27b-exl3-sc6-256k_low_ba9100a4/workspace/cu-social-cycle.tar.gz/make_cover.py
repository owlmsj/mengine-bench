from PIL import Image, ImageDraw, ImageFont

W, H = 1200, 675
img = Image.new("RGB", (W, H), (18, 42, 74))
draw = ImageDraw.Draw(img)

# simple decorative horizon / water bands
draw.rectangle([0, int(H * 0.62), W, H], fill=(30, 70, 110))
draw.ellipse([W - 260, 60, W - 120, 200], fill=(255, 214, 120))  # sun

def font(size):
    for p in (
        r"C:\Windows\Fonts\arialbd.ttf",
        r"C:\Windows\Fonts\arial.ttf",
    ):
        try:
            return ImageFont.truetype(p, size)
        except OSError:
            continue
    return ImageFont.load_default()

title = "Harbor Day 2026"
f = font(110)
bbox = draw.textbbox((0, 0), title, font=f)
tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
x = (W - tw) / 2 - bbox[0]
y = (H - th) / 2 - bbox[1]
# outline for legibility
for dx in (-4, 0, 4):
    for dy in (-4, 0, 4):
        draw.text((x + dx, y + dy), title, font=f, fill=(10, 20, 40))
draw.text((x, y), title, font=f, fill=(255, 255, 255))

img.save("cover.png")
print("saved cover.png", img.size)