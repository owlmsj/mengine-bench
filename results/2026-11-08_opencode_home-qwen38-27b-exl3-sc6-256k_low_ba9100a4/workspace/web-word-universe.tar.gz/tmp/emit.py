# -*- coding: utf-8 -*-
import json, os
ROOT = os.path.join(os.path.dirname(__file__), "..")
tpl = open(os.path.join(ROOT, "tmp", "template.html"), encoding="utf-8").read()
data = open(os.path.join(ROOT, "tmp", "data.json"), encoding="utf-8").read()
assert "/*__DATA__*/" in tpl
out = tpl.replace("/*__DATA__*/", "const DATA = " + data + ";")
os.makedirs(os.path.join(ROOT, "universe"), exist_ok=True)
with open(os.path.join(ROOT, "universe", "index.html"), "w", encoding="utf-8") as fh:
    fh.write(out)
print("wrote universe/index.html", len(out), "bytes")