# -*- coding: utf-8 -*-
"""Independent cross-check of the parsed graph."""
import json, os, re, urllib.parse

ROOT = os.path.join(os.path.dirname(__file__), "..")
SITE = os.path.join(ROOT, "site")
files = [f for f in os.listdir(SITE) if f.lower().endswith(".html")]

# count links inside main sections, per file, raw (no redirect resolution)
total_links = 0
per_file = {}
for f in files:
    txt = open(os.path.join(SITE, f), encoding="utf-8").read()
    m = re.search(r"<main>(.*?)</main>", txt, re.S)
    if not m:
        continue
    main = m.group(1)
    if 'class="tema"' not in main and 'id="sinonimos"' not in main:
        continue
    n = len(re.findall(r'<a href="[^"]+\.html"', main))
    total_links += n
    per_file[f] = n

print("directed links total (raw):", total_links)

# words.json check
w = json.load(open(os.path.join(ROOT, "words.json"), encoding="utf-8"))
print("words.json entries:", len(w))
print("sum of linked lists:", sum(len(v) for v in w.values()))
print("saudade:", w["saudade"])
print("esperança present:", "esperança" in w["saudade"])
print("palavra:", w["palavra"])
print("tempo:", w["tempo"])

# distinct pairs from words.json (undirected, name-based)
pairs = set()
for a, lst in w.items():
    for b in lst:
        pairs.add(frozenset((a, b)))
print("distinct name-pairs in words.json:", len(pairs))

r = json.load(open(os.path.join(ROOT, "result.json"), encoding="utf-8"))
print("result.json:", r)

# every linked name must be a key OR a known dangling label
dangling_labels = {"rascunho-3", "em-construcao", "link-antigo", "pagina-removida", "xpto-2"}
keys = set(w.keys())
missing = set()
for a, lst in w.items():
    for b in lst:
        if b not in keys and b not in dangling_labels:
            missing.add(b)
print("unexplained linked names:", missing)