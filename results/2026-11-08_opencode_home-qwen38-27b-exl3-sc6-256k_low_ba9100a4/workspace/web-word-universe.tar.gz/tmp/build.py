# -*- coding: utf-8 -*-
"""Parse ./site word pages into a graph, compute a 3D layout, emit artifacts."""
import json, math, os, re, random, urllib.parse, html as htmllib

SITE = os.path.join(os.path.dirname(__file__), "..", "site")
OUT = os.path.join(os.path.dirname(__file__), "..")

files = sorted(os.listdir(SITE))
html_files = [f for f in files if f.lower().endswith(".html")]
print("html files:", len(html_files))

def unquote(s):
    return urllib.parse.unquote(s)

# filename (unquoted) -> display word
pages = {}   # key: unquoted filename without .html
for f in html_files:
    key = unquote(f)[:-5]
    pages[key] = f

word_pages = {}  # key -> dict(name, theme, synonyms, analogs)
non_word = []
redirects = {}  # key -> target key (meta refresh pages)
for key, fname in pages.items():
    with open(os.path.join(SITE, fname), encoding="utf-8") as fh:
        txt = fh.read()
    m = re.search(r'<meta http-equiv="refresh" content="0; url=([^"]+)"', txt)
    if m:
        redirects[key] = unquote(m.group(1))[:-5]
        non_word.append(key)
        continue
    m = re.search(r"<main>(.*?)</main>", txt, re.S)
    if not m:
        non_word.append(key); continue
    main = m.group(1)
    h1 = re.search(r"<h1>(.*?)</h1>", main, re.S)
    tema = re.search(r'<p class="tema">Tema:\s*(.*?)</p>', main, re.S)
    sin = re.search(r'<section id="sinonimos">(.*?)</section>', main, re.S)
    ana = re.search(r'<section id="analogas">(.*?)</section>', main, re.S)
    if not tema and not sin and not ana:
        non_word.append(key); continue
    def links(sec):
        if not sec: return []
        out = []
        for href, label in re.findall(r'<a href="([^"]+)">(.*?)</a>', sec.group(1), re.S):
            out.append((unquote(href)[:-5], htmllib.unescape(label.strip())))
        return out
    word_pages[key] = {
        "name": htmllib.unescape(h1.group(1).strip()) if h1 else key,
        "theme": htmllib.unescape(tema.group(1).strip()) if tema else None,
        "synonyms": links(sin),
        "analogs": links(ana),
    }

print("word pages:", len(word_pages), "non-word:", non_word)
print("redirects:", redirects)
names = [w["name"] for w in word_pages.values()]
dupes = {n for n in names if names.count(n) > 1}
print("duplicate display names:", dupes)

# Build node set: every word page key + every dangling target (by label)
nodes = {}  # id -> dict(name, theme, exists)
for key, w in word_pages.items():
    nodes[key] = {"name": w["name"], "theme": w["theme"], "exists": True}

def resolve(target):
    seen = set()
    while target in redirects and target not in seen:
        seen.add(target)
        target = redirects[target]
    return target

def node_for(target, label):
    target = resolve(target)
    if target in nodes:
        return target
    # dangling: use label as name
    nid = "dangling:" + target
    nodes[nid] = {"name": label, "theme": None, "exists": False}
    adj[nid] = set()
    return nid

edges = set()  # frozenset({a,b})
adj = {k: set() for k in nodes}
for key, w in word_pages.items():
    for kind, lst in (("syn", w["synonyms"]), ("ana", w["analogs"])):
        for target, label in lst:
            nid = node_for(target, label)
            edges.add(frozenset((key, nid)))
            adj[key].add(nid); adj[nid].add(key)

print("nodes:", len(nodes), "edges:", len(edges))
dangling = [k for k in nodes if not nodes[k]["exists"]]
print("dangling targets:", dangling)

# distinct pairs already = edges (frozenset). count:
relations = len(edges)

# most connected: by degree over node ids; tie -> alphabetical by name
deg = {k: len(adj[k]) for k in nodes}
top = max(deg.values())
cands = sorted([k for k, d in deg.items() if d == top], key=lambda k: nodes[k]["name"].lower())
most = cands[0]
print("most_connected:", nodes[most]["name"], top, "cands:", [nodes[k]["name"] for k in cands])

# ---------- 3D force layout ----------
random.seed(7)
N = len(nodes)
ids = list(nodes.keys())
idx = {k: i for i, k in enumerate(ids)}
pos = [[random.uniform(-50, 50), random.uniform(-50, 50), random.uniform(-50, 50)] for _ in ids]
vel = [[0.0, 0.0, 0.0] for _ in ids]
edge_list = [(idx[a], idx[b]) for a, b in edges]

def layout(iters=400, k=18.0):
    for it in range(iters):
        t = 1.0 - it / iters
        # repulsion (O(N^2) fine for ~260)
        for i in range(N):
            pi = pos[i]
            for j in range(i + 1, N):
                pj = pos[j]
                dx, dy, dz = pi[0]-pj[0], pi[1]-pj[1], pi[2]-pj[2]
                d2 = dx*dx + dy*dy + dz*dz + 0.01
                f = (k*k) / d2 * 0.02
                d = math.sqrt(d2)
                fx, fy, fz = dx/d*f, dy/d*f, dz/d*f
                vel[i][0]+=fx; vel[i][1]+=fy; vel[i][2]+=fz
                vel[j][0]-=fx; vel[j][1]-=fy; vel[j][2]-=fz
        # springs
        for a, b in edge_list:
            pa, pb = pos[a], pos[b]
            dx, dy, dz = pb[0]-pa[0], pb[1]-pa[1], pb[2]-pa[2]
            d = math.sqrt(dx*dx+dy*dy+dz*dz) + 0.01
            f = (d - k) * 0.02
            fx, fy, fz = dx/d*f, dy/d*f, dz/d*f
            vel[a][0]+=fx; vel[a][1]+=fy; vel[a][2]+=fz
            vel[b][0]-=fx; vel[b][1]-=fy; vel[b][2]-=fz
        # gravity to center + integrate
        for i in range(N):
            p = pos[i]; v = vel[i]
            v[0] -= p[0]*0.002; v[1] -= p[1]*0.002; v[2] -= p[2]*0.002
            cap = 3.0 * t + 0.05
            for ax in range(3):
                if v[ax] > cap: v[ax] = cap
                if v[ax] < -cap: v[ax] = -cap
            p[0]+=v[0]; p[1]+=v[1]; p[2]+=v[2]
            v[0]*=0.85; v[1]*=0.85; v[2]*=0.85
layout()

# normalize scale: max radius ~ 60
mx = max(math.sqrt(x*x+y*y+z*z) for x,y,z in pos)
scale = 60.0 / mx
for p in pos:
    p[0]*=scale; p[1]*=scale; p[2]*=scale

# ---------- emit data ----------
# words.json: word name -> list of linked word names (dedup, sorted)
words_json = {}
for key, w in word_pages.items():
    linked = []
    for target, label in w["synonyms"] + w["analogs"]:
        nm = nodes[node_for(target, label)]["name"]
        if nm not in linked:
            linked.append(nm)
    words_json[w["name"]] = sorted(linked, key=str.lower)

with open(os.path.join(OUT, "words.json"), "w", encoding="utf-8") as fh:
    json.dump(words_json, fh, ensure_ascii=False, indent=1)

result = {"words": len(word_pages), "relations": relations, "most_connected": nodes[most]["name"]}
with open(os.path.join(OUT, "result.json"), "w", encoding="utf-8") as fh:
    json.dump(result, fh, ensure_ascii=False, indent=1)

# embed data for the html
data = {
    "nodes": [{"id": k, "name": nodes[k]["name"], "theme": nodes[k]["theme"],
               "exists": nodes[k]["exists"],
               "pos": [round(pos[idx[k]][0],2), round(pos[idx[k]][1],2), round(pos[idx[k]][2],2)],
               "deg": deg[k]} for k in ids],
    "edges": [[idx[a], idx[b]] for a, b in edges],
    "typed": {},  # word page name -> {syn:[names], ana:[names]}
}
for key, w in word_pages.items():
    data["typed"][w["name"]] = {
        "syn": [nodes[node_for(t, l)]["name"] for t, l in w["synonyms"]],
        "ana": [nodes[node_for(t, l)]["name"] for t, l in w["analogs"]],
    }
with open(os.path.join(os.path.dirname(__file__), "data.json"), "w", encoding="utf-8") as fh:
    json.dump(data, fh, ensure_ascii=False)

# theme list
themes = sorted({w["theme"] for w in word_pages.values() if w["theme"]})
print("themes:", themes)
print("result:", result)
print("sample words.json['saudade']:", words_json.get("saudade"))