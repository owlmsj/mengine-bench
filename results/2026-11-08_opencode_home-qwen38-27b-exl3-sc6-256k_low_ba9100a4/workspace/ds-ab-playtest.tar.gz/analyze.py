import csv
import math
import json
from collections import OrderedDict

rows = []
with open(r"telemetry\playtest_ab.csv", newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for r in reader:
        rows.append(r)

print(f"Total raw rows: {len(rows)}")

# Dedupe by session_id (README: session_id is the unique key, repeated rows = same session)
# Keep first occurrence; verify consistency of variant and completed_tutorial
sessions = OrderedDict()
inconsistent = 0
for r in rows:
    sid = r["session_id"].strip()
    variant_raw = r["variant"]
    completed = r["completed_tutorial"].strip()
    if sid in sessions:
        prev = sessions[sid]
        # Check consistency
        if prev["completed"] != completed:
            inconsistent += 1
        # Also check variant consistency after normalization
        if prev["variant_norm"] != variant_raw.strip().lower():
            inconsistent += 1
    else:
        sessions[sid] = {
            "variant_raw": variant_raw,
            "variant_norm": variant_raw.strip().lower(),
            "completed": completed,
        }

print(f"Unique sessions: {len(sessions)}")
print(f"Inconsistent duplicate rows: {inconsistent}")

# Check variant values
variant_values = set()
for s in sessions.values():
    variant_values.add(s["variant_norm"])
print(f"Variant values after normalization: {variant_values}")

# Check completed values
completed_values = set()
for s in sessions.values():
    completed_values.add(s["completed"])
print(f"Completed values: {completed_values}")

# Compute stats per variant
stats = {}
for v in ["a", "b"]:
    total = 0
    completed = 0
    for s in sessions.values():
        if s["variant_norm"] == v:
            total += 1
            if s["completed"] == "1":
                completed += 1
    stats[v] = {"n": total, "completed": completed, "rate": completed / total if total else 0}
    print(f"Variant {v.upper()}: n={total}, completed={completed}, rate={completed/total:.6f}")

n_a = stats["a"]["n"]
n_b = stats["b"]["n"]
x_a = stats["a"]["completed"]
x_b = stats["b"]["completed"]
p_a = x_a / n_a
p_b = x_b / n_b

# Two-proportion z-test (pooled)
p_pool = (x_a + x_b) / (n_a + n_b)
se = math.sqrt(p_pool * (1 - p_pool) * (1/n_a + 1/n_b))
z = (p_b - p_a) / se

# Two-sided p-value
from math import erf, sqrt
def norm_cdf(x):
    return 0.5 * (1 + erf(x / sqrt(2)))

p_two_sided = 2 * (1 - norm_cdf(abs(z)))
# One-sided p-value (B > A)
p_one_sided = 1 - norm_cdf(z)

print(f"\np_pool = {p_pool:.6f}")
print(f"SE = {se:.6f}")
print(f"z = {z:.6f}")
print(f"p (two-sided) = {p_two_sided:.6f}")
print(f"p (one-sided, B>A) = {p_one_sided:.6f}")
print(f"p (one-sided, B<A) = {norm_cdf(z):.6f}")

# Also compute with continuity correction for robustness
# z_cc = (|p_b - p_a| - 0.5*(1/n_a + 1/n_b)) / se
cc = 0.5 * (1/n_a + 1/n_b)
z_cc = (abs(p_b - p_a) - cc) / se
p_two_sided_cc = 2 * (1 - norm_cdf(abs(z_cc)))
print(f"\nWith continuity correction:")
print(f"z_cc = {z_cc:.6f}")
print(f"p (two-sided, cc) = {p_two_sided_cc:.6f}")

# Also try un-pooled SE (Wald test)
se_unpooled = math.sqrt(p_a*(1-p_a)/n_a + p_b*(1-p_b)/n_b)
z_unpooled = (p_b - p_a) / se_unpooled
p_two_sided_unpooled = 2 * (1 - norm_cdf(abs(z_unpooled)))
print(f"\nUn-pooled (Wald):")
print(f"z = {z_unpooled:.6f}")
print(f"p (two-sided) = {p_two_sided_unpooled:.6f}")

# Fisher's exact test (for small sample robustness)
# Use the hypergeometric distribution
# For a 2x2 table:
#            Completed  Not completed  Total
# A           x_a        n_a - x_a      n_a
# B           x_b        n_b - x_b      n_b
# Total       x_a+x_b    n_a+n_b-x_a-x_b  n_a+n_b

from math import comb, log, exp

def fisher_exact_two_sided(x_a, n_a, x_b, n_b):
    """Compute two-sided Fisher's exact test p-value."""
    total = n_a + n_b
    total_completed = x_a + x_b
    
    # P(X = k) for hypergeometric: C(total_completed, k) * C(total - total_completed, n_a - k) / C(total, n_a)
    # X = number of completions in group A
    
    log_denom = log(comb(total, n_a))
    
    p_obs = None
    p_values = {}
    
    # Range of possible values for X
    x_min = max(0, n_a - (total - total_completed))
    x_max = min(n_a, total_completed)
    
    for k in range(x_min, x_max + 1):
        log_p = log(comb(total_completed, k)) + log(comb(total - total_completed, n_a - k)) - log_denom
        p = exp(log_p)
        p_values[k] = p
    
    p_obs = p_values[x_a]
    
    # Two-sided: sum of all probabilities <= p_obs
    p_two = sum(p for p in p_values.values() if p <= p_obs + 1e-15)
    
    return p_two, p_values

p_fisher, _ = fisher_exact_two_sided(x_a, n_a, x_b, n_b)
print(f"\nFisher's exact test (two-sided):")
print(f"p = {p_fisher:.6f}")

# Decision
print("\n=== DECISION ===")
alpha = 0.05
if p_two_sided < alpha and p_b > p_a:
    print(f"Ship B: two-sided p={p_two_sided:.6f} < {alpha}, and B rate ({p_b:.4f}) > A rate ({p_a:.4f})")
    ship_b = True
elif p_one_sided < alpha and p_b > p_a:
    print(f"Ship B: one-sided p={p_one_sided:.6f} < {alpha}, and B rate ({p_b:.4f}) > A rate ({p_a:.4f})")
    ship_b = True
else:
    print(f"Do NOT ship B: p={p_two_sided:.6f} (two-sided) >= {alpha} or B not better")
    ship_b = False

# Write result.json
result = {
    "ship_b": ship_b,
    "sessions_a": n_a,
    "sessions_b": n_b,
    "completion_rate_a": round(p_a, 6),
    "completion_rate_b": round(p_b, 6),
    "p_value": round(p_two_sided, 6),
}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(f"\nresult.json written: {json.dumps(result, indent=2)}")