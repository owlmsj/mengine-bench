import json

# First report: Alfa, 2026-02-10 (units: mg/dL, mg/dL, mg/dL, %)
# Second report: Beta, 2026-08-18 (units: mmol/L, mmol/L, umol/L, mmol/mol)
# Standard conversion factors:
#   glucose: 1 mmol/L = 18.0156 mg/dL
#   cholesterol: 1 mmol/L = 38.67 mg/dL
#   creatinine: 1 mg/dL = 88.4 umol/L
#   HbA1c IFCC -> NGSP %: pct = 0.099 * mmol/mol + 2.15

history = {
    "Glicose em jejum": {
        "2026-02-10": 92.0,
        "2026-08-18": round(6.1 * 18.0156, 1),
    },
    "Colesterol LDL": {
        "2026-02-10": 118.0,
        "2026-08-18": round(3.70 * 38.67, 1),
    },
    "Creatinina": {
        "2026-02-10": 0.95,
        "2026-08-18": round(76 / 88.4, 2),
    },
    "Hemoglobina glicada (HbA1c)": {
        "2026-02-10": 5.4,
        "2026-08-18": round(0.099 * 37 + 2.15, 2),
    },
}

# First report reference ranges (in first report's units). All four markers
# are "higher is worse" analytes.
ranges = {
    "Glicose em jejum": (70.0, 99.0),
    "Colesterol LDL": (None, 130.0),  # desirable: below 130
    "Creatinina": (0.70, 1.30),
    "Hemoglobina glicada (HbA1c)": (4.0, 5.6),
}

worse = []
for marker, vals in history.items():
    v1 = vals["2026-02-10"]
    v2 = vals["2026-08-18"]
    lo, hi = ranges[marker]
    outside = (lo is not None and v2 < lo) or (hi is not None and v2 > hi)
    got_worse = v2 > v1  # all markers: higher = worse
    print(f"{marker}: {v1} -> {v2}, worse={got_worse}, outside_first_range={outside}")
    if got_worse and outside:
        worse.append(marker)

result = {"history": history, "worse": worse}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
print(json.dumps(result, ensure_ascii=False, indent=2))