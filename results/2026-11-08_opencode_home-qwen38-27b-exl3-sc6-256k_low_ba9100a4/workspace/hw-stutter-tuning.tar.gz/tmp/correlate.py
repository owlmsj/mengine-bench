import csv

CAP = r"<WORKSPACE>\capture"
rows = []
with open(CAP + r"\presentmon.csv") as f:
    for r in csv.DictReader(f):
        rows.append(r)
t0 = float(rows[0]["TimeInSeconds"])
sens = {}
with open(CAP + r"\sensors.csv") as f:
    for r in csv.DictReader(f):
        sens[int(r["time_s"])] = r

# all frames > 18ms, bucketed by sensor second
from collections import defaultdict
bysec = defaultdict(list)
for r in rows:
    ms = float(r["MsBetweenPresents"])
    if ms > 18:
        t = t0 + float(r["TimeInSeconds"])
        sec = int(t)
        bysec[sec].append(ms)

print("frames >18ms grouped by sensor second (count, max_ms, sensor flags):")
for sec in sorted(bysec):
    s = sens.get(sec, {})
    flags = []
    if s:
        if s["gpu_pcie_link_state"] == "L1": flags.append("L1")
        if int(s["dpc_latency_us"]) > 200: flags.append(f"DPC={s['dpc_latency_us']}")
        if int(s["disk_active_pct"]) > 50: flags.append(f"disk={s['disk_active_pct']}")
        if s["top_cpu_process"] != "Arena.exe": flags.append(s["top_cpu_process"])
    vals = bysec[sec]
    print(f"  t={sec:2d}  n={len(vals):3d}  max={max(vals):6.2f}  {','.join(flags)}")

# distribution of the >18ms frames
big = [float(r["MsBetweenPresents"]) for r in rows if float(r["MsBetweenPresents"]) > 18]
print(f"\ntotal >18ms: {len(big)}  min={min(big):.2f} max={max(big):.2f}")
# how many in 18-20, 20-25, >25
for lo,hi in [(18,20),(20,25),(25,100)]:
    c = sum(1 for v in big if lo<=v<hi)
    print(f"  {lo}-{hi}: {c}")

# check 43-45 region specifically
print("\nframes 42.5-46.5s (all ms):")
for r in rows:
    t = t0 + float(r["TimeInSeconds"])
    if 42.5 <= t <= 46.5:
        pass
seg = [(t0+float(r["TimeInSeconds"]), float(r["MsBetweenPresents"])) for r in rows if 42.5 <= t0+float(r["TimeInSeconds"]) <= 46.5]
mx = max(seg, key=lambda x: x[1])
print(f"  count={len(seg)} max={mx[1]:.2f} at t={mx[0]:.3f}")
print(f"  >18ms in region: {sum(1 for _,v in seg if v>18)}")