import csv

CAP = r"<WORKSPACE>\capture"
rows = []
with open(CAP + r"\presentmon.csv") as f:
    for r in csv.DictReader(f):
        rows.append(r)
t0 = float(rows[0]["TimeInSeconds"])
mbp = [float(r["MsBetweenPresents"]) for r in rows]
n = len(mbp)

def p99(v):
    s = sorted(v)
    # nearest-rank
    idx = max(0, min(len(s)-1, int(round(0.99*(len(s)-1)))))
    return s[idx]

avg_fps = 1000.0/sum(mbp)/n
low1 = 1000.0/p99(mbp)
print(f"frames={n}  avg_fps={avg_fps:.2f}  p99_ms={p99(mbp):.3f}  low1pct={low1:.2f}")

# which frames are the L1 hitches: >18ms
l1_frames = [v for v in mbp if v > 18]
clean = [v for v in mbp if v <= 18]
print(f"L1 hitch frames (>18ms)={len(l1_frames)}  clean frames={len(clean)}")
print(f"IF L1 FIXED: avg_fps={1000.0/sum(clean)/len(clean):.2f}  p99_ms={p99(clean):.3f}  low1pct={1000.0/p99(clean):.2f}")

# max clean frame time
print(f"max clean frame time = {max(clean):.2f} ms  -> floor fps = {1000/max(clean):.1f}")

# confirm every >18ms frame is in an L1 second
sens = {}
with open(CAP + r"\sensors.csv") as f:
    for r in csv.DictReader(f):
        sens[int(r["time_s"])] = r["gpu_pcie_link_state"]
bad = 0
for r in rows:
    if float(r["MsBetweenPresents"]) > 18:
        sec = int(t0 + float(r["TimeInSeconds"]))
        if sens.get(sec) != "L1":
            bad += 1
print(f">18ms frames NOT in an L1 second: {bad}")

# numpy cross-check if available
try:
    import numpy as np
    a = np.array(mbp)
    print(f"numpy p99 (linear)={np.percentile(a,99):.3f}  -> low1={1000/np.percentile(a,99):.2f}")
    print(f"numpy mean={a.mean():.4f} -> avg={1000/a.mean():.2f}")
except Exception as e:
    print("numpy n/a:", e)