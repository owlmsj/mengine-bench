import csv, statistics, json

CAP = r"<WORKSPACE>\capture"

# ---- PresentMon ----
rows = []
with open(CAP + r"\presentmon.csv") as f:
    for r in csv.DictReader(f):
        rows.append(r)

mbp = [float(r["MsBetweenPresents"]) for r in rows]
t0 = float(rows[0]["TimeInSeconds"])
t1 = float(rows[-1]["TimeInSeconds"])
n = len(mbp)

mean_mbp = sum(mbp) / n
pct = lambda p: sorted(mbp)[int(round((p/100)*(n-1)))]
p99 = pct(99)
avg_fps = 1000.0 / mean_mbp
low1 = 1000.0 / p99

print(f"frames={n}  span_s={t1-t0:.3f}")
print(f"mean_mbp={mean_mbp:.3f}  p99_mbp={p99:.3f}")
print(f"avg_fps={avg_fps:.2f}  low1pct={low1:.2f}")

# top 15 slowest frames with their capture time
idx = sorted(range(n), key=lambda i: -mbp[i])[:15]
print("\ntop-15 slowest frames (t_s, ms):")
for i in sorted(idx):
    print(f"  t={t0+float(rows[i]['TimeInSeconds']):7.3f}  ms={mbp[i]:8.2f}")

# histogram of frame time buckets
buckets = {}
for v in mbp:
    b = int(v // 10) * 10
    buckets[b] = buckets.get(b, 0) + 1
print("\nframe-time histogram (ms bucket: count):")
for b in sorted(buckets):
    if b >= 15:
        print(f"  {b}-{b+10}: {buckets[b]}")

# ---- sensors ----
sens = []
with open(CAP + r"\sensors.csv") as f:
    for r in csv.DictReader(f):
        sens.append(r)

print("\nsensor anomalies:")
for s in sens:
    t = int(s["time_s"])
    dpc = int(s["dpc_latency_us"])
    disk = int(s["disk_active_pct"])
    link = s["gpu_pcie_link_state"]
    top = s["top_cpu_process"]
    flags = []
    if dpc > 200: flags.append(f"DPC={dpc}us")
    if disk > 50: flags.append(f"disk={disk}%")
    if link == "L1": flags.append("PCIe-L1")
    if top != "Arena.exe": flags.append(f"top={top}")
    if flags:
        print(f"  t={t:2d}  " + "  ".join(flags))

# L1 transitions list
l1 = [int(s["time_s"]) for s in sens if s["gpu_pcie_link_state"] == "L1"]
print("\nL1 seconds:", l1)
dpc_hi = [(int(s["time_s"]), int(s["dpc_latency_us"])) for s in sens if int(s["dpc_latency_us"]) > 200]
print("DPC>200us:", dpc_hi)
disk_hi = [(int(s["time_s"]), int(s["disk_active_pct"])) for s in sens if int(s["disk_active_pct"]) > 50]
print("disk>50%:", disk_hi)