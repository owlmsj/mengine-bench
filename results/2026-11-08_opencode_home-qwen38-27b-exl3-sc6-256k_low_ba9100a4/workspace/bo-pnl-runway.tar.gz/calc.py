import csv, json
from collections import defaultdict

def parse_br(s):
    # Brazilian format: 56.661,03 -> 56661.03
    s = s.replace('.', '').replace(',', '.')
    return float(s)

# Load chart of accounts
coa = {}
with open('finance/chart_of_accounts.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        coa[row['account']] = row['pnl_line']

# Load ledger
monthly = defaultdict(lambda: defaultdict(float))  # month -> pnl_line -> amount
with open('finance/ledger.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        d = row['date']  # dd/mm/yyyy
        month = d[3:]  # mm/yyyy
        acct = row['account']
        amt = parse_br(row['amount'])
        line = coa.get(acct, 'unknown')
        monthly[month][line] += amt

months = ['01/2026','02/2026','03/2026','04/2026','05/2026','06/2026']
labels = ['2026-01','2026-02','2026-03','2026-04','2026-05','2026-06']

revenue = {}
gross_margin_pct = {}
ebitda = {}

for m, label in zip(months, labels):
    rev = monthly[m].get('revenue', 0.0)
    cogs = monthly[m].get('cogs', 0.0)
    sm = monthly[m].get('sales_marketing', 0.0)
    rnd = monthly[m].get('rnd', 0.0)
    ga = monthly[m].get('ga', 0.0)
    fin = monthly[m].get('financial', 0.0)
    
    gross = rev + cogs  # cogs is negative
    gm = (gross / rev * 100) if rev != 0 else 0.0
    # EBITDA = gross profit - opex (opex is negative, so add)
    e = gross + sm + rnd + ga  # all opex lines are negative
    
    revenue[label] = round(rev, 2)
    gross_margin_pct[label] = round(gm, 2)
    ebitda[label] = round(e, 2)
    
    print(f"{label}: rev={rev:.2f} cogs={cogs:.2f} sm={sm:.2f} rnd={rnd:.2f} ga={ga:.2f} fin={fin:.2f} gross={gross:.2f} gm={gm:.2f}% ebitda={e:.2f}")

# Burn: average monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = [ebitda['2026-04'], ebitda['2026-05'], ebitda['2026-06']]
neg_vals = [abs(v) for v in last3 if v < 0]
burn = sum(neg_vals) / len(neg_vals) if neg_vals else 0.0
print(f"\nLast 3 EBITDA: {last3}")
print(f"Negative values (abs): {neg_vals}")
print(f"Burn = {burn:.2f}")

# Runway: latest closing cash / burn
cash = 1847350.40
runway = cash / burn if burn else 0.0
print(f"Cash = {cash:.2f}")
print(f"Runway = {runway:.2f} months")

result = {
    "revenue": revenue,
    "gross_margin_pct": gross_margin_pct,
    "ebitda": ebitda,
    "burn": round(burn, 2),
    "runway_months": round(runway, 2)
}

with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2)
print("\nWrote result.json")