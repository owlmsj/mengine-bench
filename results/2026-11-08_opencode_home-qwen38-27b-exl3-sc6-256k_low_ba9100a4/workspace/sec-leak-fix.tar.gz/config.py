"""Settings for the backup agent."""
import os

API_URL = "https://backup.example.invalid/v1/upload"
ARCHIVE_DIR = "archives"


def api_token() -> str:
    """The backup API token, read from the environment at use time.

    The token is never stored in the code and never written to logs.
    """
    return os.environ.get("BACKUP_TOKEN", "")