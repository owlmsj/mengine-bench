"""Fill permit-form.pdf with Ines's details and flatten so fields can't be edited.

Values from event-details.txt:
  organizer   -> Tidewater Studio
  event_date  -> Saturday 5 December 2026
  location    -> North Cove Lawn
  attendees   -> about 40
"""
import os
import pymupdf as fitz

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "..", "permit-form.pdf")
OUT = os.path.join(HERE, "..", "out", "permit-filled.pdf")

VALUES = {
    "organizer": "Tidewater Studio",
    "event_date": "Saturday 5 December 2026",
    "location": "North Cove Lawn",
    "attendees": "about 40",
}

doc = fitz.open(SRC)
filled = {}
for page in doc:
    for w in page.widgets() or []:
        name = w.field_name
        if name in VALUES:
            w.field_value = VALUES[name]
            w.update()
            filled[name] = VALUES[name]

# Flatten: bake field values (and any annotations) into page content and remove
# the interactive form fields, so the answers can no longer be edited.
doc.flatten()

os.makedirs(os.path.dirname(OUT), exist_ok=True)
doc.save(OUT, garbage=4, deflate=True)
doc.close()

# Verify
check = fitz.open(OUT)
remaining = []
for page in check:
    for w in page.widgets() or []:
        remaining.append(w.field_name)
print("filled:", filled)
print("remaining widgets after flatten:", remaining)
print("has AcroForm:", check.is_form_pdf)
# Extract text to confirm values are baked in
text = "\n".join(p.get_text() for p in check)
for v in VALUES.values():
    print("contains %r:" % v, v in text)
check.close()
print("saved", OUT)