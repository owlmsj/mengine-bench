"""Crop launch.jpg to a 1080x1350 (4:5) feed photo keeping the magenta balloon fully in frame.

Source is 3000x2000 (3:2). Target 4:5 portrait. The whole balloon
(envelope + ropes + basket) spans x 2350-2749, y 500-1070.
Crop box (1800,300,3000,1800) = 1200x1500 (4:5), fully contains the balloon
with margin (left 550, right 251, top 200, bottom 730 to basket).
Scale 1200x1500 -> 1080x1350 is uniform 0.9, no distortion.
"""
from PIL import Image
import os

SRC = os.path.join(os.path.dirname(__file__), "..", "launch.jpg")
OUT = os.path.join(os.path.dirname(__file__), "..", "out", "feed-photo.jpg")

im = Image.open(SRC).convert("RGB")
crop = im.crop((1800, 300, 3000, 1800))  # 1200x1500
out = crop.resize((1080, 1350), Image.LANCZOS)
os.makedirs(os.path.dirname(OUT), exist_ok=True)
out.save(OUT, "JPEG", quality=92)
print("saved", OUT, out.size)