# HANDOFF

Task: measure local-9b Q5 at 128k ctx (131072).

Done
- Baseline decode 37.8 t/s, VRAM 7881 MiB. 7881 is the WDDM ceiling; Shared Usage shows 1494 MiB spilled, so it does not count.
- Fix: --no-mmproj-offload + -ub 512 removes the spill. Final VRAM 7697 MiB, decode 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k; discarded. Q4_K_M fits (7305 MiB, 40.4 t/s), fallback only.
- Recipe applied: scripts/start_server.ps1:165 (local9 block), profiles/local/local-9b.json.

Left
- Update evals README: still cites check_vision.ps1 (file no longer exists).
- Review scratchpad temp-file names (noted for later, never done).

Assumptions
- "Recipe" = --no-mmproj-offload + -ub 512.
- Final config is Q5 (task target); Q4_K_M is fallback.

Found: 7881 MiB was a WDDM ceiling artifact; the two flags remove the 1494 MiB spill, landing at 7697 MiB / 38.0 t/s.
How I know: scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024, median of 3, cross-checked vs the Shared Usage counter.