Add-Type -AssemblyName System.Speech
$dir = "<WORKSPACE>"
$out = Join-Path $dir "announcement.wav"
if (Test-Path $out) { Remove-Item $out }
$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
$rate = [int]$args[0]
$synth.Rate = $rate
$synth.SetOutputToWaveFile($out)
$synth.Speak("Welcome aboard the evening ferry, please keep your bags clear of the doors.")
$synth.Dispose()
# read back duration from header
$fs = [System.IO.File]::OpenRead($out)
$br = New-Object System.IO.BinaryReader($fs)
$br.ReadBytes(12) | Out-Null
$br.ReadBytes(4) | Out-Null   # "fmt "
$br.ReadUInt32() | Out-Null   # fmt chunk size
$audioFormat = $br.ReadUInt16()
$channels = $br.ReadUInt16()
$sampleRate = $br.ReadUInt32()
$byteRate = $br.ReadUInt32()
$br.Close()
$fs.Close()
$len = (Get-Item $out).Length
$duration = ($len - 44) / $byteRate
Write-Output "audioFormat=$audioFormat channels=$channels sampleRate=$sampleRate byteRate=$byteRate bytes=$len duration=$([math]::Round($duration,2))s"