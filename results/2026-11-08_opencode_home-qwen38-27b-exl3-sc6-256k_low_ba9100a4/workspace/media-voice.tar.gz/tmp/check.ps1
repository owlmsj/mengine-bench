$p = "<WORKSPACE>\announcement.wav"
$fs = [System.IO.File]::OpenRead($p)
$br = New-Object System.IO.BinaryReader($fs)
$fs.Seek(12,'Begin') | Out-Null
$br.ReadBytes(4) | Out-Null
$br.ReadUInt32() | Out-Null
$fmt = $br.ReadUInt16()
$ch = $br.ReadUInt16()
$sr = $br.ReadUInt32()
$brRate = $br.ReadUInt32()
$fs.Close()
$len = (Get-Item $p).Length
$dur = ($len - 44) / $brRate
# peak amplitude check (16-bit samples)
$bytes = [System.IO.File]::ReadAllBytes($p)
$peak = 0
for ($i = 44; $i + 1 -lt $bytes.Length; $i += 2) {
  $s = [BitConverter]::ToInt16($bytes, $i)
  $a = [math]::Abs($s)
  if ($a -gt $peak) { $peak = $a }
}
Write-Output "peak=$peak"
Write-Output "format=$fmt channels=$ch sampleRate=$sr byteRate=$brRate bytes=$len duration=$([math]::Round($dur,2))s"
if ($fmt -ne 0) { Write-Output "NOT PCM" }
if ($dur -lt 4 -or $dur -gt 8) { Write-Output "DURATION OUT OF RANGE" } else { Write-Output "DURATION OK" }