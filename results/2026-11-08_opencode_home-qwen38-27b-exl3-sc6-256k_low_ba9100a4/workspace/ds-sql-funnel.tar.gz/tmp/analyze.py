import sqlite3, json
from collections import Counter, defaultdict

c = sqlite3.connect('analytics.db')
users = {uid: (plat, is_test) for uid, plat, is_test in c.execute("SELECT user_id, platform, is_test FROM users")}
events = list(c.execute("SELECT user_id, name, ts FROM events"))
print('event names:', Counter(n for _, n, _ in events))
print('platforms:', Counter(p for _, (p, t) in users.items()))
print('test users:', sum(1 for _, t in users.values() if t))
unknown = [e for e in events if e[0] not in users]
print('unknown-player events:', len(unknown))
# sanity: any non-funnel event names?
print('ts range:', min(e[2] for e in events), max(e[2] for e in events))

STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']
by_user = defaultdict(list)
for uid, name, ts in events:
    if uid in users and not users[uid][1] and name in STEPS:
        by_user[uid].append((ts, name))

funnel = {p: {s: 0 for s in STEPS} for p in set(p for p, _ in users.values())}
reached = {p: {s: 0 for s in STEPS} for p in set(p for p, _ in users.values())}
for uid, evs in by_user.items():
    plat = users[uid][0]
    prev_ts = None
    for i, s in enumerate(STEPS):
        valid = [ts for ts, n in evs if n == s and (prev_ts is None or ts >= prev_ts)]
        if not valid:
            break
        first = min(valid)
        prev_ts = first
        funnel[plat][s] += 1
        # reached includes this step and all before
    # reached: count steps up to the last reached
    # recompute reached properly below

# recompute reached (steps up to and including the last reached)
reached = {p: {s: 0 for s in STEPS} for p in set(p for p, _ in users.values())}
for uid, evs in by_user.items():
    plat = users[uid][0]
    prev_ts = None
    last = -1
    for i, s in enumerate(STEPS):
        valid = [ts for ts, n in evs if n == s and (prev_ts is None or ts >= prev_ts)]
        if not valid:
            break
        prev_ts = min(valid)
        last = i
    for j in range(last + 1):
        reached[plat][STEPS[j]] += 1

result = {'funnel': {}, 'biggest_drop': {}}
for plat in sorted(funnel):
    f = funnel[plat]
    result['funnel'][plat] = f
    convs = {}
    for i, s in enumerate(STEPS):
        if i == 0:
            convs[s] = None
        else:
            prev = f[STEPS[i-1]]
            convs[s] = (f[s] / prev) if prev else None
    # biggest drop = step with lowest conversion (among steps 1..3)
    drops = {s: v for s, v in convs.items() if v is not None}
    bd = min(drops, key=lambda s: drops[s])
    result['biggest_drop'][plat] = bd
    print(plat, f, {s: (round(v,4) if v is not None else None) for s, v in convs.items()}, '->', bd)

with open('result.json', 'w') as fh:
    json.dump(result, fh, indent=2)
print('written result.json')