import sqlite3
c = sqlite3.connect('analytics.db')
for name, sql in c.execute("SELECT name, sql FROM sqlite_master WHERE type='table'"):
    print('==', name)
    print(sql)
    for row in c.execute(f"SELECT * FROM {name} LIMIT 8"):
        print(row)
    print('count:', c.execute(f"SELECT COUNT(*) FROM {name}").fetchone()[0])