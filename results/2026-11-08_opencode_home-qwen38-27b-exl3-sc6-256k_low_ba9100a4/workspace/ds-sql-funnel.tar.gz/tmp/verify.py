import sqlite3
from collections import defaultdict

c = sqlite3.connect('analytics.db')
users = {uid: (plat, is_test) for uid, plat, is_test in c.execute("SELECT user_id, platform, is_test FROM users")}
STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']

# independent: chronological walk per player
ev = defaultdict(list)
for uid, name, ts in c.execute("SELECT user_id, name, ts FROM events"):
    if uid in users and not users[uid][1] and name in STEPS:
        ev[uid].append((ts, name))

funnel = defaultdict(lambda: [0]*4)
for uid, lst in ev.items():
    plat = users[uid][0]
    lst.sort()
    stage = 0
    for ts, name in lst:
        if stage < 4 and name == STEPS[stage]:
            funnel[plat][stage] += 1
            stage += 1

for plat in sorted(funnel):
    f = funnel[plat]
    print(plat, dict(zip(STEPS, f)))
    convs = [f[i]/f[i-1] for i in range(1,4)]
    print('  convs:', [round(x,6) for x in convs], 'exact:', [f'{f[i]}/{f[i-1]}' for i in range(1,4)])

# edge checks
dup_install = 0
out_of_order = 0
for uid, lst in ev.items():
    names = [n for _, n in sorted(lst)]
    if names.count('install') > 1: dup_install += 1
    # first_match before any tutorial?
    if 'first_match' in names and 'tutorial_complete' not in names: out_of_order += 1
print('players w/ >1 install:', dup_install, '| first_match w/o tutorial:', out_of_order)

# cross-check: raw install events per platform (incl. test/unknown)
for plat in ('pc','steamdeck'):
    n = c.execute("SELECT COUNT(DISTINCT e.user_id) FROM events e JOIN users u ON u.user_id=e.user_id WHERE e.name='install' AND u.platform=?", (plat,)).fetchone()[0]
    print(plat, 'distinct users w/ install event (any status):', n)