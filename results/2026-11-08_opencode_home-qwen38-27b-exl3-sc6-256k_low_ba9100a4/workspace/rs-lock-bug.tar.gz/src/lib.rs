//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        let score = *slot.lock().unwrap();
        *slot.lock().unwrap() = score + points;
        let total = *self.total.lock().unwrap();
        *self.total.lock().unwrap() = total + points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let from_slot = self.slot(from);
        let to_slot = self.slot(to);
        let mut from_score = from_slot.lock().unwrap();
        let mut to_score = to_slot.lock().unwrap();
        *from_score -= points;
        *to_score += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::mpsc;
    use std::thread;
    use std::time::Duration;

    /// Concurrent awards to the same player must not lose points.
    #[test]
    fn concurrent_awards_keep_every_point() {
        let board = Board::new();
        board.join(1, 0);
        let mut handles = Vec::new();
        for _ in 0..8 {
            let b = board.clone();
            handles.push(thread::spawn(move || {
                for _ in 0..1000 {
                    b.award(1, 1);
                }
            }));
        }
        for h in handles {
            h.join().unwrap();
        }
        assert_eq!(board.score(1), 8000);
        assert_eq!(board.total(), 8000);
    }

    /// Opposite-direction transfers must not deadlock.
    #[test]
    fn opposite_transfers_do_not_deadlock() {
        let board = Board::new();
        board.join(1, 100);
        board.join(2, 100);
        let (tx, rx) = mpsc::channel();
        let tx1 = tx.clone();
        let b1 = board.clone();
        let t1 = thread::spawn(move || {
            for _ in 0..1000 {
                b1.transfer(1, 2, 1);
            }
            tx1.send(()).unwrap();
        });
        let b2 = board.clone();
        let t2 = thread::spawn(move || {
            for _ in 0..1000 {
                b2.transfer(2, 1, 1);
            }
            tx.send(()).unwrap();
        });
        // Time out instead of hanging forever if the transfers deadlock.
        assert!(rx.recv_timeout(Duration::from_secs(10)).is_ok());
        assert!(rx.recv_timeout(Duration::from_secs(10)).is_ok());
        t1.join().unwrap();
        t2.join().unwrap();
        assert_eq!(board.total(), 200);
        assert_eq!(board.score(1) + board.score(2), 200);
    }

    /// A self-transfer changes nothing (and must not deadlock).
    #[test]
    fn self_transfer_changes_nothing() {
        let board = Board::new();
        board.join(1, 42);
        board.transfer(1, 1, 10);
        assert_eq!(board.score(1), 42);
        assert_eq!(board.total(), 42);
    }
}