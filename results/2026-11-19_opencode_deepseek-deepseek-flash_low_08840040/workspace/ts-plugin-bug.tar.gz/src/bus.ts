/**
 * Hook bus for harness plugins (OpenCode-style hooks). The README states the contract:
 * handlers run one after another in subscription order, emit resolves after all of them,
 * a handler error rejects emit, and unsubscribing during an emit does not stop the others.
 */

export type Handler<T> = (payload: T) => void | Promise<void>;

export class HookBus {
  private handlers: Map<string, Handler<unknown>[]> = new Map();

  /** Subscribes a handler to an event; returns the function that unsubscribes it. */
  on<T>(event: string, handler: Handler<T>): () => void {
    const list = this.handlers.get(event) ?? [];
    list.push(handler as Handler<unknown>);
    this.handlers.set(event, list);
    return () => {
      const current = this.handlers.get(event);
      if (!current) {
        return;
      }
      const index = current.indexOf(handler as Handler<unknown>);
      if (index >= 0) {
        current.splice(index, 1);
      }
      if (current.length === 0) {
        this.handlers.delete(event);
      }
    };
  }

  /** Runs the handlers of an event with the payload, one at a time, in subscription order. */
  async emit<T>(event: string, payload: T): Promise<void> {
    // Snapshot: subscriptions made or removed during this emit apply from the next emit on.
    const list = [...(this.handlers.get(event) ?? [])];
    for (const handler of list) {
      // Sequential await: a rejection stops the remaining handlers and rejects emit.
      await handler(payload as unknown);
    }
  }

  /** How many handlers an event has. */
  count(event: string): number {
    return (this.handlers.get(event) ?? []).length;
  }
}
