"""Bounded-concurrency helper for batch scripts.

    from run import run_tasks
    await run_tasks(tasks, max_concurrent=8)

Each task is a zero-argument callable returning an awaitable job (coroutine or
any awaitable). At most ``max_concurrent`` jobs run at once. The coroutine
returns once every job has finished.

Ctrl+C (KeyboardInterrupt): jobs that already started are cancelled so their
own cleanup (``try/finally``, async context managers, ``__del__``-free orderly
teardown) runs, and we wait for each to settle before re-raising. Tasks not yet
started are never invoked. A repeated Ctrl+C during the drain does not abort
cleanup; we keep draining.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Iterable
from typing import Any

__all__ = ["run_tasks"]

Task = Callable[[], Awaitable[Any]]


def _check_limit(max_concurrent: object) -> int:
    if isinstance(max_concurrent, bool) or not isinstance(max_concurrent, int):
        raise TypeError(f"max_concurrent must be an int, got {max_concurrent!r}")
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent!r}")
    return max_concurrent


async def run_tasks(tasks: Iterable[Task], max_concurrent: int) -> None:
    """Run every task with at most ``max_concurrent`` jobs in flight.

    A job that raises cancels the other in-flight jobs, awaits their cleanup,
    then the first exception is re-raised. On KeyboardInterrupt the same cancel
    and drain happens, then the interrupt is re-raised.
    """
    limit = _check_limit(max_concurrent)

    task_iter = iter(tasks)
    pending: set[asyncio.Future] = set()
    exhausted = False

    async def cancel_and_drain() -> None:
        # Cancel first, then keep waiting even if we get cancelled again.
        for fut in list(pending):
            fut.cancel()
        while pending:
            try:
                await asyncio.gather(*pending, return_exceptions=True)
            except asyncio.CancelledError:
                continue
            break
        pending.clear()

    try:
        while True:
            # Fill the window (lazily; an infinite generator is fine).
            while len(pending) < limit and not exhausted:
                try:
                    task = next(task_iter)
                except StopIteration:
                    exhausted = True
                    break
                try:
                    job = task()
                except BaseException:
                    # A task that blows up before returning an awaitable counts
                    # like a failed job: clean up the others, then raise it.
                    await cancel_and_drain()
                    raise
                pending.add(asyncio.ensure_future(job))

            if not pending:
                if exhausted:
                    return
                continue

            done, still_running = await asyncio.wait(
                pending, return_when=asyncio.FIRST_COMPLETED
            )
            pending = set(still_running)

            first_error: BaseException | None = None
            for fut in done:
                if fut.cancelled():
                    continue
                exc = fut.exception()
                if exc is not None and first_error is None:
                    first_error = exc
            if first_error is not None:
                await cancel_and_drain()
                raise first_error
    except (KeyboardInterrupt, asyncio.CancelledError):
        await cancel_and_drain()
        raise
