# Handoff: local-9b Q5 @ 128k

Goal: measure local-9b Q5 at 128k context.

State
- Run 1 (`scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`): 37.8 t/s, VRAM 7881 MiB. INVALID: 7881 MiB is the WDDM ceiling and Shared Usage showed 1494 MiB spilled, so the number is contaminated.
- Fix: `--no-mmproj-offload` + `-ub 512`. Spill gone: 7697 MiB VRAM, 38.0 t/s decode (median of 3). This is the current result.
- Q6_K (7.03 GiB) does not fit at 128k; discarded. Q4_K_M fits (7305 MiB, 40.4 t/s), kept only as fallback.
- Recipe applied in `scripts/start_server.ps1:165` (local9 block) and `profiles/local/local-9b.json`.

Next
- Update evals README: it still cites `check_vision.ps1`, which no longer exists.
- Re-measure on a clean GPU and confirm the server log shows no spill.

Assumptions: the repo files above are absent from this workspace, so those edits are unverified here; all state comes from the session log and no number was re-measured.
