import csv, collections, math, random

rows = list(csv.DictReader(open('telemetry/playtest_ab.csv', encoding='utf-8')))
recs = {}
full = collections.defaultdict(list)
for r in rows:
    sid = (r['session_id'] or '').strip()
    full[sid].append(r)
    if sid not in recs:
        recs[sid] = ((r['variant'] or '').strip().lower(), int(r['completed_tutorial']),
                     r['player_id'].strip(), float(r['match_minutes']))

# do duplicate rows match exactly after normalization?
mismatch = 0
for sid, rs in full.items():
    sig = {(x['variant'].strip().lower(), x['completed_tutorial'].strip(), x['player_id'].strip(), x['match_minutes'].strip()) for x in rs}
    if len(sig) > 1:
        mismatch += 1
        if mismatch <= 3: print("dup mismatch", sid, rs)
print("duplicate groups with differing data:", mismatch)

data = list(recs.items())
random.seed(12345)
b_obs = sum(c for _, (v, c, _, _) in data if v == 'b') / sum(1 for _, (v, _, _, _) in data if v == 'b')
a_obs = sum(c for _, (v, c, _, _) in data if v == 'a') / sum(1 for _, (v, _, _, _) in data if v == 'a')
obs = b_obs - a_obs
cnt = 0
N = 20000
for _ in range(N):
    vals = [c for _, (v, c, _, _) in data]
    random.shuffle(vals)
    kb = sum(vals[:900]); ka = sum(vals[900:])
    if abs(kb/900 - ka/900) >= abs(obs): cnt += 1
print("permutation two-sided p (20000):", (cnt+1)/(N+1))

# within-player paired analysis
pp = collections.defaultdict(lambda: {'a': [0,0], 'b': [0,0]})
for sid, (v, c, p, m) in recs.items():
    pp[p][v][0] += 1; pp[p][v][1] += c
both = {p: d for p, d in pp.items() if d['a'][0] and d['b'][0]}
diffs = []
for p, d in both.items():
    diffs.append(d['b'][1]/d['b'][0] - d['a'][1]/d['a'][0])
n = len(diffs); mean = sum(diffs)/n
sd = math.sqrt(sum((x-mean)**2 for x in diffs)/(n-1))
t = mean/(sd/math.sqrt(n))
print("paired players", n, "mean within-player diff %.4f sd %.4f t %.3f" % (mean, sd, t))
# normal approx p
p = math.erfc(abs(t)/math.sqrt(2))
print("paired p approx %.6f" % p)

# how many sessions per player by arm, check equal exposure
for arm in ('a','b'):
    ns = [d[arm][0] for d in pp.values() if d[arm][0]]
    print(arm, "players", len(ns), "mean sessions %.2f" % (sum(ns)/len(ns)))
