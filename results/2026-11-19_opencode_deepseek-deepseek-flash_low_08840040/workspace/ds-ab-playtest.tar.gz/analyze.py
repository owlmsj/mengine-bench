import csv, collections, math

rows = list(csv.DictReader(open('telemetry/playtest_ab.csv', encoding='utf-8')))
print("rows", len(rows))
print("fields", rows[0].keys())

# normalize
recs = collections.defaultdict(list)
bad = 0
for r in rows:
    sid = (r['session_id'] or '').strip()
    var = (r['variant'] or '').strip().lower()
    comp = (r['completed_tutorial'] or '').strip()
    if not sid or var not in ('a', 'b') or comp not in ('0', '1'):
        bad += 1
        continue
    recs[sid].append((var, int(comp), r['player_id'].strip(), r['match_minutes'].strip()))

print("bad skipped", bad)
print("unique sessions", len(recs))
dups = {k: v for k, v in recs.items() if len(v) > 1}
print("duplicated session_ids", len(dups))
print("dup row counts", collections.Counter(len(v) for v in dups.values()))

conflict = 0
for k, v in dups.items():
    if len({x[0] for x in v}) > 1 or len({x[1] for x in v}) > 1:
        conflict += 1
        if conflict <= 5:
            print("conflict", k, v)
print("sessions with conflicting variant/completion", conflict)

# also check session_id case/whitespace variants? and player duplicates
print("raw variant values", collections.Counter(r['variant'] for r in rows))
print("raw completed values", collections.Counter(r['completed_tutorial'] for r in rows))
