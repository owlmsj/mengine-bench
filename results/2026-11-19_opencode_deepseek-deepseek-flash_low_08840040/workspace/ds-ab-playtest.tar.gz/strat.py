import csv, collections, math
rows = list(csv.DictReader(open('telemetry/playtest_ab.csv', encoding='utf-8')))
recs = {}
for r in rows:
    sid = r['session_id'].strip()
    if sid not in recs:
        recs[sid] = (r['variant'].strip().lower(), int(r['completed_tutorial']),
                     r['player_id'].strip(), float(r['match_minutes']))

# near-duplicate events: same player+minutes+completion different session_id
sig = collections.defaultdict(list)
for sid, (v,c,p,m) in recs.items():
    sig[(p, m, c)].append(sid)
near = {k: v for k, v in sig.items() if len(v) > 1}
print("near-duplicate (player,minutes,completion) groups:", len(near), "extra rows", sum(len(v)-1 for v in near.values()))
for k, v in list(near.items())[:5]:
    print(k, v, [recs[s][0] for s in v])

# stratified by minutes decile
vals = sorted(recs.items(), key=lambda kv: kv[1][3])
nb = 10; per = len(vals)/nb
print("\nminutes stratum | n_a rate_a | n_b rate_b | diff")
tot_chi = 0
for i in range(nb):
    chunk = vals[int(i*per):int((i+1)*per)]
    a = [(c) for _, (v,c,p,m) in chunk if v=='a']
    b = [(c) for _, (v,c,p,m) in chunk if v=='b']
    if not a or not b: continue
    print("%5.1f-%5.1f | %3d %.3f | %3d %.3f | %+.3f" % (chunk[0][1][3], chunk[-1][1][3], len(a), sum(a)/len(a), len(b), sum(b)/len(b), sum(b)/len(b)-sum(a)/len(a)))

# Mantel-Haenszel pooled odds ratio over deciles
num = den = 0
for i in range(nb):
    chunk = vals[int(i*per):int((i+1)*per)]
    a = [c for _, (v,c,p,m) in chunk if v=='a']
    b = [c for _, (v,c,p,m) in chunk if v=='b']
    if not a or not b: continue
    a1, a0 = sum(a), len(a)-sum(a)
    b1, b0 = sum(b), len(b)-sum(b)
    n = a1+a0+b1+b0
    num += a1*b0/n; den += a0*b1/n
print("\nMH OR (B vs A) = %.3f" % (num/den))
