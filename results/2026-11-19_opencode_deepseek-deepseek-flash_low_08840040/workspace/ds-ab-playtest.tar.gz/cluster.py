import csv, collections, math

rows = list(csv.DictReader(open('telemetry/playtest_ab.csv', encoding='utf-8')))
recs = {}
for r in rows:
    sid = (r['session_id'] or '').strip()
    if sid not in recs:
        recs[sid] = ((r['variant'] or '').strip().lower(), int(r['completed_tutorial']),
                     r['player_id'].strip(), float(r['match_minutes']), r['session_id'].strip())

per_player = collections.defaultdict(list)
for sid, (v, c, p, m, raw_sid) in recs.items():
    per_player[p].append((v, c, sid))

sizes = collections.Counter(len(s) for s in per_player.values())
print("players", len(per_player), "sessions/player dist", sorted(sizes.items())[:10], "max", max(sizes))
both = {p: s for p, s in per_player.items() if len({x[0] for x in s}) > 1}
print("players in both arms", len(both), "sessions involved", sum(len(s) for s in both.values()))
multi_same = {p: s for p, s in per_player.items() if len(s) > 1 and len({x[0] for x in s}) == 1}
print("players with >1 session same arm", len(multi_same))

# cluster-robust: player-level proportions (any completed / sessions per player)
# Use player as unit: rate of players with >=1 completion? biased by sessions count.
# Better: cluster-robust variance for difference in proportions.
# Compute per-arm per-player sums and counts, then cluster variance of mean.
import statistics
def cluster_stats(arm):
    sums = []
    for p, s in per_player.items():
        ss = [x for x in s if x[0] == arm]
        if ss:
            sums.append((sum(x[1] for x in ss), len(ss)))
    return sums

for arm in ('a','b'):
    cl = cluster_stats(arm)
    n = sum(c for _, c in cl)
    k = sum(s for s, _ in cl)
    print("cluster", arm, "players", len(cl), "sessions", n, "rate %.5f" % (k/n))

# cluster-robust SE of difference using delta method on ratio estimator with clusters
def ratio_cluster(arm):
    cl = cluster_stats(arm)
    n = sum(c for _, c in cl)
    k = sum(s for s, _ in cl)
    r = k/n
    # influence function per cluster: (s_i - r*c_i)/n
    var = sum(((s - r*c)/n)**2 for s, c in cl) * len(cl)/(len(cl)-1)
    return n, k, r, var

na, ka, ra, va = ratio_cluster('a')
nb, kb, rb, vb = ratio_cluster('b')
se = math.sqrt(va + vb)
z = (rb - ra)/se
p = math.erfc(abs(z)/math.sqrt(2))
print("cluster-robust diff %.5f se %.6f z %.4f p %.6f" % (rb-ra, se, z, p))
print("design effect ~ %.2f" % ((se**2) / (0.42333*(1-0.42333)*(1/na+1/nb))))
