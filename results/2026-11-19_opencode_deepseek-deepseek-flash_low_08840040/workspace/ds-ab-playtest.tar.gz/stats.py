import csv, collections, math

rows = list(csv.DictReader(open('telemetry/playtest_ab.csv', encoding='utf-8')))
recs = {}
order = []
for r in rows:
    sid = (r['session_id'] or '').strip()
    var = (r['variant'] or '').strip().lower()
    comp = int((r['completed_tutorial'] or '').strip())
    if sid not in recs:
        recs[sid] = (var, comp, r['player_id'].strip(), float(r['match_minutes']))
        order.append(sid)

agg = collections.defaultdict(lambda: [0, 0])
comp_by = collections.defaultdict(list)
for sid in order:
    var, comp, pid, mins = recs[sid]
    agg[var][0] += 1
    agg[var][1] += comp
    comp_by[var].append((comp, mins, pid))

res = {}
for v in ('a', 'b'):
    n, k = agg[v]
    res[v] = (n, k, k / n)
    print(v, "n=%d completes=%d rate=%.5f" % (n, k, k / n))

na, ka, pa = res['a']
nb, kb, pb = res['b']
pool = (ka + kb) / (na + nb)
se = math.sqrt(pool * (1 - pool) * (1 / na + 1 / nb))
z = (pb - pa) / se
p = math.erfc(abs(z) / math.sqrt(2))
print("diff (b-a) = %.5f  relative %+.2f%%" % (pb - pa, 100 * (pb - pa) / pa))
print("pooled p = %.5f  se = %.6f  z = %.4f  two-sided p = %.6f" % (pool, se, z, p))

# 95% CI on difference (unpooled)
seu = math.sqrt(pa * (1 - pa) / na + pb * (1 - pb) / nb)
print("95%% CI diff: [%.4f, %.4f]" % ((pb - pa) - 1.959964 * seu, (pb - pa) + 1.959964 * seu))

# chi-square 2x2 as cross-check (with Yates)
import itertools
def chi2_yates(a, b, c, d):
    n = a + b + c + d
    num = n * (abs(a*d - b*c) - n/2)**2
    den = (a+b)*(c+d)*(a+c)*(b+d)
    return num/den
chi = chi2_yates(kb, nb-kb, ka, na-ka)
print("chi2 yates = %.4f  p = %.6f" % (chi, math.erfc(math.sqrt(chi/2))))

# player overlap
pa_set = {p for _, _, p in comp_by['a']}
pb_set = {p for _, _, p in comp_by['b']}
print("unique players a", len(pa_set), "b", len(pb_set), "overlap", len(pa_set & pb_set))

# match_minutes sanity
for v in ('a','b'):
    mins = sorted(m for _, m, _ in comp_by[v])
    print(v, "minutes median %.1f mean %.2f max %.1f" % (mins[len(mins)//2], sum(mins)/len(mins), mins[-1]))

# sensitivity: naive all rows (no dedup)
raw = collections.defaultdict(lambda: [0,0])
for r in rows:
    v = r['variant'].strip().lower()
    raw[v][0]+=1; raw[v][1]+=int(r['completed_tutorial'])
for v in ('a','b'):
    n,k=raw[v]; print("RAW", v, n, k, "%.5f"%(k/n))
na2,ka2=raw['a']; nb2,kb2=raw['b']
pool2=(ka2+kb2)/(na2+nb2); se2=math.sqrt(pool2*(1-pool2)*(1/na2+1/nb2))
z2=((kb2/nb2)-(ka2/na2))/se2
print("RAW p = %.6f z=%.3f" % (math.erfc(abs(z2)/math.sqrt(2)), z2))

# sensitivity: drop non-integer / odd match_minutes? and check completion vs minutes
print("sessions", len(order), "recs", len(recs))
