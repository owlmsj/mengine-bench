# Pixel Arena tutorial: ship B, not A

**Recommendation:** ship variant B. B lifts tutorial completion from 38.0% to 46.7% (+8.7 percentage points, +22.8% relative). The release rule in `telemetry/README.md` requires significance at the 5% level, and the gain clears it by a wide margin: two-sided p = 0.0002 (z = 3.72, 95% CI on the difference 4.1 to 13.2 points).

## What the export needed

The CSV has 1,870 rows but only 1,800 unique `session_id` values. The README says the ETL resends sessions. The 70 duplicate groups are byte-identical on variant, completion, player and minutes, so keeping one row per session loses nothing. Variant arrives as `a`, `A`, ` A`, `b`, `B`, ` B`; all were trimmed and lowercased. No invalid rows.

| | Sessions | Completed | Rate |
|---|---|---|---|
| A | 900 | 342 | 38.0% |
| B | 900 | 420 | 46.7% |

Test: two-proportion z-test on deduped sessions, z = 3.721, p = 0.000198. Chi-square with Yates correction gives p = 0.000239. Not deduplicating would give p = 0.000112, so the shortcut would have overstated confidence, not changed the call.

## Checks a skeptical lead would ask for

- **Repeated players.** 366 players appear in both arms, so sessions are not fully independent. A player-clustered variance gives p = 0.0002 (design effect 1.01). A within-player paired comparison across those 366 players gives +9.0 points, p = 0.0052. Still significant.
- **Randomization check by resampling.** A 20,000-draw permutation test gives p = 0.0003.
- **Time confound.** B sessions are longer (median 15.5 vs 13.8 match_minutes). If extra time were the cause, the gap should vanish within time strata. It does not: B is ahead in 9 of 10 minute-decile strata, and the Mantel-Haenszel odds ratio is 1.42, matching the crude 1.42.
- **Near duplicates with new ids.** Seven extra rows look like the same event resent under a new session id. Dropping all seven gives 38.0% vs 46.8%, p = 0.00019.

## Assumptions and limits

- Completion is the primary metric because the stated release rule names tutorial completion.
- Sessions are the unit of randomization; two-sided alpha of 5% since the rule does not specify a direction.
- The export has no date, device or acquisition columns, so I cannot test novelty effects or segment stability. Treat the result as valid for this cohort, and re-check after release.
- `match_minutes` is plausibly a downstream effect of completing the tutorial, not a pre-treatment covariate; either way the stratified analysis rules it out as the explanation.

Files: `result.json` (required fields), `analyze.py`, `stats.py`, `cluster.py`, `robust.py`, `strat.py` (reproducible checks).
