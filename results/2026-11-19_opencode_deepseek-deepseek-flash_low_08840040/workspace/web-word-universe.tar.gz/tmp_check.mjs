
const DATA = {"words": [{"w": "acento", "t": "linguagem", "d": 7, "p": [0.05, 0.05, 0.01], "l": [{"w": "fala", "k": "analogas"}, {"w": "pergunta", "k": "sinonimos"}, {"w": "prazer", "k": "analogas"}, {"w": "sotaque", "k": "analogas"}, {"w": "sílaba", "k": "sinonimos"}]}, {"w": "açougueiro", "t": "ofícios", "d": 6, "p": [-0.16, -0.17, -0.04], "l": [{"w": "alfaiate", "k": "analogas"}, {"w": "boca", "k": "analogas"}, {"w": "padeiro", "k": "sinonimos"}, {"w": "pescador", "k": "sinonimos"}, {"w": "tarde", "k": "analogas"}]}, {"w": "açúcar", "t": "comida", "d": 5, "p": [1.52, 1.63, 0.34], "l": [{"w": "manteiga", "k": "sinonimos"}, {"w": "mel", "k": "sinonimos"}, {"w": "pimenta", "k": "analogas"}, {"w": "tempo", "k": "analogas"}, {"w": "unha", "k": "analogas"}]}, {"w": "advogado", "t": "ofícios", "d": 9, "p": [1.42, 1.24, 0.29], "l": [{"w": "cachoeira", "k": "analogas"}, {"w": "coração", "k": "analogas"}, {"w": "eternidade", "k": "analogas"}, {"w": "fala", "k": "analogas"}, {"w": "hora", "k": "analogas"}, {"w": "juiz", "k": "sinonimos"}, {"w": "juiz", "k": "analogas"}, {"w": "palavra", "k": "analogas"}, {"w": "professor", "k": "sinonimos"}]}, {"w": "afeto", "t": "sentimentos", "d": 4, "p": [0.05, 0.05, 0.01], "l": [{"w": "amor", "k": "sinonimos"}, {"w": "angústia", "k": "analogas"}, {"w": "carinho", "k": "sinonimos"}, {"w": "voz", "k": "analogas"}]}, {"w": "aflição", "t": "sentimentos", "d": 6, "p": [0.03, 0.04, 0.01], "l": [{"w": "angústia", "k": "sinonimos"}, {"w": "ansiedade", "k": "sinonimos"}, {"w": "ansiedade", "k": "analogas"}, {"w": "escultura", "k": "analogas"}, {"w": "felicidade", "k": "analogas"}, {"w": "pavor", "k": "analogas"}, {"w": "água", "k": "analogas"}]}, {"w": "água", "t": "comida", "d": 7, "p": [-0.13, -0.11, -0.03], "l": [{"w": "aflição", "k": "analogas"}, {"w": "café", "k": "analogas"}, {"w": "comida", "k": "sinonimos"}, {"w": "ombro", "k": "analogas"}, {"w": "professor", "k": "analogas"}, {"w": "refeição", "k": "analogas"}, {"w": "vinho", "k": "sinonimos"}]}, {"w": "aldeia", "t": "lugares", "d": 4, "p": [-0.15, -0.16, -0.03], "l": [{"w": "bairro", "k": "sinonimos"}, {"w": "capital", "k": "analogas"}, {"w": "trabalho", "k": "analogas"}, {"w": "vila", "k": "sinonimos"}]}, {"w": "alegria", "t": "sentimentos", "d": 4, "p": [0.01, 0.01, 0.0], "l": [{"w": "felicidade", "k": "sinonimos"}, {"w": "queijo", "k": "analogas"}, {"w": "surpresa", "k": "sinonimos"}, {"w": "ternura", "k": "analogas"}]}, {"w": "alfaiate", "t": "ofícios", "d": 8, "p": [-0.39, -0.42, -0.09], "l": [{"w": "açougueiro", "k": "analogas"}, {"w": "boca", "k": "analogas"}, {"w": "emprego", "k": "analogas"}, {"w": "padeiro", "k": "sinonimos"}, {"w": "profissão", "k": "analogas"}, {"w": "sapateiro", "k": "sinonimos"}, {"w": "susto", "k": "analogas"}]}, {"w": "alma", "t": "corpo", "d": 9, "p": [1.61, 1.42, 0.32], "l": [{"w": "amor", "k": "analogas"}, {"w": "corpo", "k": "sinonimos"}, {"w": "dente", "k": "analogas"}, {"w": "gíria", "k": "analogas"}, {"w": "pátria", "k": "analogas"}, {"w": "pé", "k": "sinonimos"}]}, {"w": "almoço", "t": "comida", "d": 9, "p": [-0.17, -0.15, -0.03], "l": [{"w": "carne", "k": "analogas"}, {"w": "frase", "k": "analogas"}, {"w": "jantar", "k": "sinonimos"}, {"w": "patrão", "k": "analogas"}, {"w": "pimenta", "k": "analogas"}, {"w": "refeição", "k": "sinonimos"}]}, {"w": "amanhã", "t": "tempo", "d": 6, "p": [-0.33, -0.36, -0.07], "l": [{"w": "eternidade", "k": "sinonimos"}, {"w": "hoje", "k": "sinonimos"}, {"w": "hoje", "k": "analogas"}, {"w": "hora", "k": "analogas"}, {"w": "perna", "k": "analogas"}, {"w": "porta", "k": "analogas"}]}, {"w": "amor", "t": "sentimentos", "d": 6, "p": [-0.32, -0.32, -0.07], "l": [{"w": "afeto", "k": "sinonimos"}, {"w": "alma", "k": "analogas"}, {"w": "paixão", "k": "sinonimos"}, {"w": "susto", "k": "analogas"}, {"w": "tristeza", "k": "analogas"}, {"w": "árvore", "k": "analogas"}]}, {"w": "angústia", "t": "sentimentos", "d": 6, "p": [0.05, 0.05, 0.01], "l": [{"w": "afeto", "k": "analogas"}, {"w": "aflição", "k": "sinonimos"}, {"w": "compaixão", "k": "analogas"}, {"w": "dor", "k": "sinonimos"}, {"w": "medo", "k": "analogas"}, {"w": "riacho", "k": "analogas"}]}, {"w": "ano", "t": "tempo", "d": 5, "p": [0.02, 0.02, 0.0], "l": [{"w": "crepúsculo", "k": "analogas"}, {"w": "mês", "k": "sinonimos"}, {"w": "música", "k": "analogas"}, {"w": "século", "k": "sinonimos"}]}, {"w": "ansiedade", "t": "sentimentos", "d": 6, "p": [-0.15, -0.16, -0.03], "l": [{"w": "aflição", "k": "sinonimos"}, {"w": "aflição", "k": "analogas"}, {"w": "manteiga", "k": "analogas"}, {"w": "medo", "k": "sinonimos"}, {"w": "paixão", "k": "analogas"}, {"w": "rua", "k": "analogas"}]}, {"w": "apelido", "t": "linguagem", "d": 6, "p": [-0.46, -0.48, -0.1], "l": [{"w": "acento", "k": "analogas"}, {"w": "idioma", "k": "analogas"}, {"w": "irmã", "k": "analogas"}, {"w": "letra", "k": "sinonimos"}, {"w": "nome", "k": "sinonimos"}]}, {"w": "areia", "t": "natureza", "d": 5, "p": [-0.07, -0.06, -0.01], "l": [{"w": "montanha", "k": "analogas"}, {"w": "natureza", "k": "sinonimos"}, {"w": "ofício", "k": "analogas"}, {"w": "praia", "k": "sinonimos"}, {"w": "rima", "k": "analogas"}]}, {"w": "arroz", "t": "comida", "d": 6, "p": [-0.12, -0.1, -0.02], "l": [{"w": "chá", "k": "analogas"}, {"w": "feijão", "k": "sinonimos"}, {"w": "feijão", "k": "analogas"}, {"w": "madrugada", "k": "analogas"}, {"w": "trigo", "k": "sinonimos"}]}, {"w": "arte", "t": "artes", "d": 6, "p": [0.06, 0.06, 0.01], "l": [{"w": "cachoeira", "k": "analogas"}, {"w": "fotografia", "k": "sinonimos"}, {"w": "música", "k": "sinonimos"}, {"w": "romance", "k": "analogas"}, {"w": "samba", "k": "analogas"}]}, {"w": "árvore", "t": "natureza", "d": 6, "p": [0.05, 0.05, 0.01], "l": [{"w": "amor", "k": "analogas"}, {"w": "mandioca", "k": "analogas"}, {"w": "mata", "k": "analogas"}, {"w": "raiz", "k": "sinonimos"}, {"w": "selva", "k": "sinonimos"}, {"w": "serra", "k": "analogas"}]}, {"w": "ator", "t": "artes", "d": 4, "p": [0.05, 0.05, 0.01], "l": [{"w": "canção", "k": "analogas"}, {"w": "cena", "k": "sinonimos"}, {"w": "poesia", "k": "sinonimos"}, {"w": "primo", "k": "analogas"}]}, {"w": "aurora", "t": "tempo", "d": 5, "p": [-0.13, -0.12, -0.03], "l": [{"w": "crepúsculo", "k": "sinonimos"}, {"w": "instante", "k": "analogas"}, {"w": "madrugada", "k": "sinonimos"}, {"w": "prazer", "k": "analogas"}, {"w": "professor", "k": "analogas"}]}, {"w": "avenida", "t": "lugares", "d": 5, "p": [-0.26, -0.26, -0.06], "l": [{"w": "casa", "k": "analogas"}, {"w": "feijão", "k": "analogas"}, {"w": "praça", "k": "sinonimos"}, {"w": "quarto", "k": "analogas"}, {"w": "rua", "k": "sinonimos"}]}, {"w": "avó", "t": "família", "d": 6, "p": [-0.32, -0.31, -0.07], "l": [{"w": "avô", "k": "sinonimos"}, {"w": "genro", "k": "analogas"}, {"w": "idioma", "k": "analogas"}, {"w": "mãe", "k": "analogas"}, {"w": "neto", "k": "sinonimos"}]}, {"w": "avô", "t": "família", "d": 7, "p": [0.08, 0.07, 0.02], "l": [{"w": "avó", "k": "sinonimos"}, {"w": "coração", "k": "analogas"}, {"w": "irmã", "k": "sinonimos"}, {"w": "pais", "k": "analogas"}, {"w": "semana", "k": "analogas"}]}, {"w": "bairro", "t": "lugares", "d": 5, "p": [-0.15, -0.16, -0.03], "l": [{"w": "aldeia", "k": "sinonimos"}, {"w": "igreja", "k": "analogas"}, {"w": "porta", "k": "analogas"}, {"w": "refeição", "k": "analogas"}, {"w": "rua", "k": "sinonimos"}, {"w": "rua", "k": "analogas"}]}, {"w": "boca", "t": "corpo", "d": 7, "p": [0.08, 0.08, 0.02], "l": [{"w": "alfaiate", "k": "analogas"}, {"w": "açougueiro", "k": "analogas"}, {"w": "livro", "k": "analogas"}, {"w": "língua", "k": "sinonimos"}, {"w": "olho", "k": "sinonimos"}, {"w": "ombro", "k": "analogas"}, {"w": "rosto", "k": "analogas"}]}, {"w": "braço", "t": "corpo", "d": 5, "p": [0.03, 0.03, 0.01], "l": [{"w": "janela", "k": "analogas"}, {"w": "língua", "k": "analogas"}, {"w": "mão", "k": "sinonimos"}, {"w": "ombro", "k": "sinonimos"}, {"w": "surpresa", "k": "analogas"}]}, {"w": "cabeça", "t": "corpo", "d": 5, "p": [1.19, 1.07, 0.24], "l": [{"w": "corpo", "k": "sinonimos"}, {"w": "enfermeira", "k": "analogas"}, {"w": "mão", "k": "analogas"}, {"w": "rosto", "k": "sinonimos"}]}, {"w": "cachoeira", "t": "natureza", "d": 7, "p": [-0.07, -0.05, -0.01], "l": [{"w": "advogado", "k": "analogas"}, {"w": "lago", "k": "sinonimos"}, {"w": "linguagem", "k": "analogas"}, {"w": "pétala", "k": "analogas"}, {"w": "riacho", "k": "sinonimos"}, {"w": "semente", "k": "analogas"}]}, {"w": "café", "t": "comida", "d": 5, "p": [0.01, 0.01, 0.0], "l": [{"w": "chá", "k": "sinonimos"}, {"w": "momento", "k": "analogas"}, {"w": "pimenta", "k": "sinonimos"}, {"w": "trabalho", "k": "analogas"}, {"w": "água", "k": "analogas"}]}, {"w": "campo", "t": "natureza", "d": 6, "p": [-0.28, -0.3, -0.06], "l": [{"w": "jardim", "k": "sinonimos"}, {"w": "milho", "k": "analogas"}, {"w": "onda", "k": "analogas"}, {"w": "ponte", "k": "analogas"}, {"w": "prado", "k": "sinonimos"}, {"w": "selva", "k": "analogas"}]}, {"w": "canção", "t": "artes", "d": 7, "p": [-0.32, -0.32, -0.07], "l": [{"w": "ator", "k": "analogas"}, {"w": "cena", "k": "analogas"}, {"w": "idioma", "k": "analogas"}, {"w": "melodia", "k": "sinonimos"}, {"w": "música", "k": "sinonimos"}, {"w": "pai", "k": "analogas"}, {"w": "tela", "k": "analogas"}]}, {"w": "capital", "t": "lugares", "d": 9, "p": [2.38, 2.55, 0.53], "l": [{"w": "aldeia", "k": "analogas"}, {"w": "cidade", "k": "sinonimos"}, {"w": "estação", "k": "analogas"}, {"w": "riacho", "k": "analogas"}, {"w": "tempo", "k": "analogas"}, {"w": "vila", "k": "sinonimos"}, {"w": "voz", "k": "analogas"}]}, {"w": "carinho", "t": "sentimentos", "d": 7, "p": [-0.13, -0.14, -0.03], "l": [{"w": "afeto", "k": "sinonimos"}, {"w": "compaixão", "k": "analogas"}, {"w": "esperança", "k": "analogas"}, {"w": "melancolia", "k": "analogas"}, {"w": "saudade", "k": "analogas"}, {"w": "ternura", "k": "sinonimos"}]}, {"w": "carne", "t": "comida", "d": 8, "p": [-0.02, -0.01, -0.0], "l": [{"w": "arroz", "k": "analogas"}, {"w": "filho", "k": "analogas"}, {"w": "mandioca", "k": "sinonimos"}, {"w": "nação", "k": "analogas"}, {"w": "ovo", "k": "analogas"}, {"w": "peixe", "k": "sinonimos"}, {"w": "salário", "k": "analogas"}]}, {"w": "carpinteiro", "t": "ofícios", "d": 5, "p": [-0.08, -0.06, -0.01], "l": [{"w": "ferreiro", "k": "sinonimos"}, {"w": "patrão", "k": "analogas"}, {"w": "pedreiro", "k": "sinonimos"}, {"w": "trabalho", "k": "analogas"}, {"w": "vila", "k": "analogas"}]}, {"w": "casa", "t": "lugares", "d": 6, "p": [0.04, 0.04, 0.01], "l": [{"w": "avenida", "k": "analogas"}, {"w": "escola", "k": "sinonimos"}, {"w": "igreja", "k": "analogas"}, {"w": "lar", "k": "sinonimos"}, {"w": "poesia", "k": "analogas"}]}, {"w": "cena", "t": "artes", "d": 7, "p": [-0.16, -0.18, -0.04], "l": [{"w": "ator", "k": "sinonimos"}, {"w": "canção", "k": "analogas"}, {"w": "livro", "k": "analogas"}, {"w": "melodia", "k": "analogas"}, {"w": "ponte", "k": "analogas"}, {"w": "teatro", "k": "sinonimos"}]}, {"w": "chá", "t": "comida", "d": 6, "p": [0.06, 0.05, 0.01], "l": [{"w": "café", "k": "sinonimos"}, {"w": "dente", "k": "analogas"}, {"w": "peixe", "k": "analogas"}, {"w": "queijo", "k": "analogas"}, {"w": "vinho", "k": "sinonimos"}]}, {"w": "cidade", "t": "lugares", "d": 6, "p": [-0.16, -0.17, -0.04], "l": [{"w": "capital", "k": "sinonimos"}, {"w": "estado", "k": "sinonimos"}, {"w": "estação", "k": "analogas"}, {"w": "jardim", "k": "analogas"}, {"w": "prima", "k": "analogas"}]}, {"w": "cinema", "t": "artes", "d": 4, "p": [0.02, 0.02, 0.0], "l": [{"w": "escultura", "k": "sinonimos"}, {"w": "fotografia", "k": "sinonimos"}, {"w": "fotografia", "k": "analogas"}, {"w": "pergunta", "k": "analogas"}, {"w": "tela", "k": "analogas"}]}, {"w": "comida", "t": "comida", "d": 5, "p": [-0.12, -0.13, -0.03], "l": [{"w": "farinha", "k": "analogas"}, {"w": "história", "k": "analogas"}, {"w": "peito", "k": "analogas"}, {"w": "refeição", "k": "sinonimos"}, {"w": "água", "k": "sinonimos"}]}, {"w": "compaixão", "t": "sentimentos", "d": 8, "p": [-0.11, -0.1, -0.02], "l": [{"w": "angústia", "k": "analogas"}, {"w": "carinho", "k": "analogas"}, {"w": "contentamento", "k": "analogas"}, {"w": "esperança", "k": "sinonimos"}, {"w": "ovo", "k": "analogas"}, {"w": "sílaba", "k": "analogas"}, {"w": "ternura", "k": "sinonimos"}]}, {"w": "contentamento", "t": "sentimentos", "d": 4, "p": [0.02, 0.01, 0.0], "l": [{"w": "felicidade", "k": "sinonimos"}, {"w": "pais", "k": "analogas"}, {"w": "prazer", "k": "sinonimos"}, {"w": "prazer", "k": "analogas"}]}, {"w": "conto", "t": "artes", "d": 8, "p": [1.72, 1.56, 0.35], "l": [{"w": "folha", "k": "analogas"}, {"w": "herança", "k": "analogas"}, {"w": "lar", "k": "analogas"}, {"w": "livro", "k": "sinonimos"}, {"w": "palavra", "k": "analogas"}, {"w": "romance", "k": "sinonimos"}, {"w": "verso", "k": "analogas"}]}, {"w": "conversa", "t": "linguagem", "d": 4, "p": [0.0, 0.0, 0.0], "l": [{"w": "fala", "k": "sinonimos"}, {"w": "felicidade", "k": "analogas"}, {"w": "grito", "k": "analogas"}, {"w": "silêncio", "k": "sinonimos"}]}, {"w": "coração", "t": "corpo", "d": 7, "p": [-0.15, -0.13, -0.03], "l": [{"w": "advogado", "k": "analogas"}, {"w": "avô", "k": "analogas"}, {"w": "jantar", "k": "analogas"}, {"w": "joelho", "k": "analogas"}, {"w": "peito", "k": "sinonimos"}, {"w": "pulmão", "k": "sinonimos"}, {"w": "rosto", "k": "analogas"}]}, {"w": "corpo", "t": "corpo", "d": 4, "p": [-0.2, -0.18, -0.04], "l": [{"w": "alma", "k": "sinonimos"}, {"w": "cabeça", "k": "sinonimos"}, {"w": "cabeça", "k": "analogas"}, {"w": "peixe", "k": "analogas"}, {"w": "pescoço", "k": "analogas"}]}, {"w": "cozinha", "t": "lugares", "d": 7, "p": [-0.15, -0.16, -0.03], "l": [{"w": "capital", "k": "analogas"}, {"w": "fígado", "k": "analogas"}, {"w": "janela", "k": "sinonimos"}, {"w": "pai", "k": "analogas"}, {"w": "quarto", "k": "sinonimos"}, {"w": "voz", "k": "analogas"}]}, {"w": "crepúsculo", "t": "tempo", "d": 8, "p": [0.09, 0.09, 0.02], "l": [{"w": "ano", "k": "analogas"}, {"w": "aurora", "k": "sinonimos"}, {"w": "cunhado", "k": "analogas"}, {"w": "gíria", "k": "analogas"}, {"w": "hoje", "k": "analogas"}, {"w": "ontem", "k": "sinonimos"}, {"w": "segundo", "k": "analogas"}, {"w": "época", "k": "analogas"}]}, {"w": "cunhado", "t": "família", "d": 4, "p": [-0.1, -0.11, -0.02], "l": [{"w": "crepúsculo", "k": "analogas"}, {"w": "pais", "k": "analogas"}, {"w": "sobrinho", "k": "sinonimos"}, {"w": "sogra", "k": "sinonimos"}]}, {"w": "dança", "t": "artes", "d": 6, "p": [-0.15, -0.17, -0.03], "l": [{"w": "desenho", "k": "analogas"}, {"w": "piano", "k": "analogas"}, {"w": "rima", "k": "analogas"}, {"w": "tambor", "k": "sinonimos"}, {"w": "teatro", "k": "sinonimos"}, {"w": "voz", "k": "analogas"}]}, {"w": "dedo", "t": "corpo", "d": 5, "p": [1.2, 1.08, 0.25], "l": [{"w": "mão", "k": "sinonimos"}, {"w": "pé", "k": "analogas"}, {"w": "sapateiro", "k": "analogas"}, {"w": "unha", "k": "sinonimos"}, {"w": "unha", "k": "analogas"}]}, {"w": "dente", "t": "corpo", "d": 7, "p": [-0.3, -0.3, -0.06], "l": [{"w": "hoje", "k": "analogas"}, {"w": "língua", "k": "sinonimos"}, {"w": "pescoço", "k": "sinonimos"}, {"w": "pulmão", "k": "analogas"}]}, {"w": "desenho", "t": "artes", "d": 5, "p": [0.01, 0.01, 0.0], "l": [{"w": "dança", "k": "analogas"}, {"w": "escultura", "k": "sinonimos"}, {"w": "noite", "k": "analogas"}, {"w": "prima", "k": "analogas"}, {"w": "tela", "k": "sinonimos"}]}, {"w": "dia", "t": "tempo", "d": 5, "p": [0.0, 0.0, 0.0], "l": [{"w": "casa", "k": "analogas"}, {"w": "letra", "k": "analogas"}, {"w": "manhã", "k": "sinonimos"}, {"w": "semana", "k": "sinonimos"}, {"w": "tarde", "k": "analogas"}]}, {"w": "dicionário", "t": "linguagem", "d": 4, "p": [0.01, 0.01, 0.0], "l": [{"w": "arte", "k": "analogas"}, {"w": "significado", "k": "sinonimos"}, {"w": "sinônimo", "k": "sinonimos"}, {"w": "voz", "k": "analogas"}]}, {"w": "dor", "t": "sentimentos", "d": 4, "p": [-0.08, -0.07, -0.02], "l": [{"w": "almoço", "k": "analogas"}, {"w": "angústia", "k": "sinonimos"}, {"w": "mágoa", "k": "sinonimos"}, {"w": "saudade", "k": "analogas"}]}, {"w": "emprego", "t": "ofícios", "d": 7, "p": [0.05, 0.05, 0.01], "l": [{"w": "alfaiate", "k": "analogas"}, {"w": "esperança", "k": "analogas"}, {"w": "eternidade", "k": "analogas"}, {"w": "jantar", "k": "analogas"}, {"w": "mercado", "k": "analogas"}, {"w": "profissão", "k": "sinonimos"}, {"w": "salário", "k": "sinonimos"}]}, {"w": "enfermeira", "t": "ofícios", "d": 6, "p": [-0.2, -0.18, -0.04], "l": [{"w": "açougueiro", "k": "analogas"}, {"w": "médico", "k": "sinonimos"}, {"w": "professor", "k": "sinonimos"}, {"w": "violão", "k": "analogas"}, {"w": "época", "k": "analogas"}]}, {"w": "engenheiro", "t": "ofícios", "d": 6, "p": [0.07, 0.06, 0.01], "l": [{"w": "irmão", "k": "analogas"}, {"w": "juiz", "k": "analogas"}, {"w": "lavrador", "k": "analogas"}, {"w": "marinheiro", "k": "sinonimos"}, {"w": "ternura", "k": "analogas"}, {"w": "trabalho", "k": "sinonimos"}]}, {"w": "época", "t": "tempo", "d": 6, "p": [-0.21, -0.21, -0.04], "l": [{"w": "enfermeira", "k": "analogas"}, {"w": "era", "k": "sinonimos"}, {"w": "era", "k": "analogas"}, {"w": "leite", "k": "analogas"}, {"w": "momento", "k": "sinonimos"}]}, {"w": "era", "t": "tempo", "d": 5, "p": [1.02, 0.89, 0.21], "l": [{"w": "mês", "k": "analogas"}, {"w": "palavra", "k": "analogas"}, {"w": "século", "k": "sinonimos"}, {"w": "século", "k": "analogas"}, {"w": "teatro", "k": "analogas"}, {"w": "época", "k": "sinonimos"}, {"w": "época", "k": "analogas"}]}, {"w": "escola", "t": "lugares", "d": 4, "p": [0.01, 0.01, 0.0], "l": [{"w": "casa", "k": "sinonimos"}, {"w": "esperança", "k": "analogas"}, {"w": "esquina", "k": "analogas"}, {"w": "igreja", "k": "sinonimos"}]}, {"w": "escultura", "t": "artes", "d": 7, "p": [-0.01, -0.01, -0.0], "l": [{"w": "cinema", "k": "sinonimos"}, {"w": "desenho", "k": "sinonimos"}, {"w": "jardim", "k": "analogas"}, {"w": "olho", "k": "analogas"}, {"w": "sobrinho", "k": "analogas"}, {"w": "violão", "k": "analogas"}]}, {"w": "espanto", "t": "sentimentos", "d": 4, "p": [-0.15, -0.16, -0.03], "l": [{"w": "esperança", "k": "analogas"}, {"w": "país", "k": "analogas"}, {"w": "surpresa", "k": "sinonimos"}, {"w": "surpresa", "k": "analogas"}, {"w": "susto", "k": "sinonimos"}]}, {"w": "esperança", "t": "sentimentos", "d": 7, "p": [0.04, 0.04, 0.01], "l": [{"w": "carinho", "k": "analogas"}, {"w": "compaixão", "k": "sinonimos"}, {"w": "emprego", "k": "analogas"}, {"w": "escola", "k": "analogas"}, {"w": "espanto", "k": "analogas"}, {"w": "nostalgia", "k": "analogas"}, {"w": "saudade", "k": "sinonimos"}]}, {"w": "esquina", "t": "lugares", "d": 5, "p": [-0.18, -0.2, -0.04], "l": [{"w": "cozinha", "k": "analogas"}, {"w": "escola", "k": "analogas"}, {"w": "pescador", "k": "analogas"}, {"w": "ponte", "k": "sinonimos"}, {"w": "praça", "k": "sinonimos"}]}, {"w": "estado", "t": "lugares", "d": 6, "p": [-0.1, -0.11, -0.02], "l": [{"w": "cidade", "k": "sinonimos"}, {"w": "mão", "k": "analogas"}, {"w": "médico", "k": "analogas"}, {"w": "poesia", "k": "analogas"}, {"w": "praça", "k": "analogas"}, {"w": "pátria", "k": "sinonimos"}]}, {"w": "estação", "t": "lugares", "d": 6, "p": [-0.5, -0.51, -0.11], "l": [{"w": "capital", "k": "analogas"}, {"w": "cidade", "k": "analogas"}, {"w": "mercado", "k": "sinonimos"}, {"w": "mercado", "k": "analogas"}, {"w": "porto", "k": "sinonimos"}, {"w": "susto", "k": "analogas"}, {"w": "tia", "k": "analogas"}]}, {"w": "estômago", "t": "corpo", "d": 4, "p": [0.02, 0.02, 0.0], "l": [{"w": "fígado", "k": "sinonimos"}, {"w": "irmão", "k": "analogas"}, {"w": "língua", "k": "analogas"}, {"w": "pulmão", "k": "sinonimos"}]}, {"w": "eternidade", "t": "tempo", "d": 7, "p": [-0.1, -0.08, -0.02], "l": [{"w": "advogado", "k": "analogas"}, {"w": "amanhã", "k": "sinonimos"}, {"w": "emprego", "k": "analogas"}, {"w": "instante", "k": "analogas"}, {"w": "madrugada", "k": "analogas"}, {"w": "passado", "k": "sinonimos"}, {"w": "peixe", "k": "analogas"}]}, {"w": "fala", "t": "linguagem", "d": 4, "p": [-0.09, -0.08, -0.02], "l": [{"w": "acento", "k": "analogas"}, {"w": "advogado", "k": "analogas"}, {"w": "conversa", "k": "sinonimos"}, {"w": "voz", "k": "sinonimos"}]}, {"w": "família", "t": "família", "d": 4, "p": [-0.13, -0.14, -0.03], "l": [{"w": "herança", "k": "sinonimos"}, {"w": "nora", "k": "analogas"}, {"w": "parentesco", "k": "sinonimos"}, {"w": "susto", "k": "analogas"}]}, {"w": "farinha", "t": "comida", "d": 6, "p": [-0.2, -0.22, -0.05], "l": [{"w": "pescador", "k": "analogas"}, {"w": "pão", "k": "sinonimos"}, {"w": "trigo", "k": "sinonimos"}, {"w": "vinho", "k": "analogas"}]}, {"w": "feijão", "t": "comida", "d": 6, "p": [1.3, 1.16, 0.26], "l": [{"w": "arroz", "k": "sinonimos"}, {"w": "arroz", "k": "analogas"}, {"w": "avenida", "k": "analogas"}, {"w": "mandioca", "k": "analogas"}, {"w": "milho", "k": "sinonimos"}, {"w": "palavra", "k": "analogas"}, {"w": "vinho", "k": "analogas"}]}, {"w": "felicidade", "t": "sentimentos", "d": 6, "p": [-0.0, -0.0, -0.0], "l": [{"w": "aflição", "k": "analogas"}, {"w": "alegria", "k": "sinonimos"}, {"w": "compaixão", "k": "analogas"}, {"w": "contentamento", "k": "sinonimos"}, {"w": "conversa", "k": "analogas"}, {"w": "trigo", "k": "analogas"}]}, {"w": "ferreiro", "t": "ofícios", "d": 6, "p": [-0.13, -0.15, -0.03], "l": [{"w": "carpinteiro", "k": "sinonimos"}, {"w": "onda", "k": "analogas"}, {"w": "pastor", "k": "analogas"}, {"w": "sapateiro", "k": "sinonimos"}, {"w": "sapateiro", "k": "analogas"}, {"w": "segundo", "k": "analogas"}]}, {"w": "fígado", "t": "corpo", "d": 5, "p": [-0.25, -0.25, -0.05], "l": [{"w": "alma", "k": "analogas"}, {"w": "cozinha", "k": "analogas"}, {"w": "estômago", "k": "sinonimos"}, {"w": "futuro", "k": "analogas"}, {"w": "pele", "k": "sinonimos"}]}, {"w": "filha", "t": "família", "d": 7, "p": [-0.09, -0.07, -0.02], "l": [{"w": "filho", "k": "sinonimos"}, {"w": "irmão", "k": "sinonimos"}, {"w": "manteiga", "k": "analogas"}, {"w": "nora", "k": "analogas"}, {"w": "parentesco", "k": "analogas"}, {"w": "primo", "k": "analogas"}, {"w": "tia", "k": "analogas"}]}, {"w": "filho", "t": "família", "d": 5, "p": [0.02, 0.02, 0.0], "l": [{"w": "carne", "k": "analogas"}, {"w": "filha", "k": "sinonimos"}, {"w": "genro", "k": "analogas"}, {"w": "pai", "k": "sinonimos"}]}, {"w": "flor", "t": "natureza", "d": 5, "p": [0.06, 0.06, 0.01], "l": [{"w": "folha", "k": "sinonimos"}, {"w": "mar", "k": "analogas"}, {"w": "pétala", "k": "sinonimos"}, {"w": "samba", "k": "analogas"}, {"w": "semente", "k": "analogas"}]}, {"w": "floresta", "t": "natureza", "d": 5, "p": [1.53, 1.64, 0.34], "l": [{"w": "mar", "k": "analogas"}, {"w": "mata", "k": "sinonimos"}, {"w": "medo", "k": "analogas"}, {"w": "natureza", "k": "sinonimos"}, {"w": "tempo", "k": "analogas"}]}, {"w": "folha", "t": "natureza", "d": 7, "p": [-0.32, -0.32, -0.07], "l": [{"w": "conto", "k": "analogas"}, {"w": "flor", "k": "sinonimos"}, {"w": "raiz", "k": "sinonimos"}, {"w": "semente", "k": "analogas"}, {"w": "silêncio", "k": "analogas"}, {"w": "tio", "k": "analogas"}]}, {"w": "fotografia", "t": "artes", "d": 6, "p": [-0.2, -0.21, -0.04], "l": [{"w": "arte", "k": "sinonimos"}, {"w": "cinema", "k": "sinonimos"}, {"w": "refeição", "k": "analogas"}, {"w": "rima", "k": "analogas"}, {"w": "soldado", "k": "analogas"}, {"w": "teatro", "k": "analogas"}]}, {"w": "frase", "t": "linguagem", "d": 8, "p": [0.13, 0.12, 0.03], "l": [{"w": "almoço", "k": "analogas"}, {"w": "gíria", "k": "analogas"}, {"w": "letra", "k": "analogas"}, {"w": "linguagem", "k": "sinonimos"}, {"w": "sentido", "k": "sinonimos"}, {"w": "sussurro", "k": "analogas"}, {"w": "tristeza", "k": "analogas"}]}, {"w": "fruto", "t": "natureza", "d": 5, "p": [0.03, 0.03, 0.01], "l": [{"w": "jardim", "k": "sinonimos"}, {"w": "natureza", "k": "analogas"}, {"w": "piano", "k": "analogas"}, {"w": "semente", "k": "sinonimos"}]}, {"w": "futuro", "t": "tempo", "d": 6, "p": [1.69, 1.81, 0.38], "l": [{"w": "fígado", "k": "analogas"}, {"w": "minuto", "k": "analogas"}, {"w": "passado", "k": "sinonimos"}, {"w": "século", "k": "analogas"}, {"w": "tempo", "k": "sinonimos"}]}, {"w": "genro", "t": "família", "d": 5, "p": [-0.06, -0.07, -0.01], "l": [{"w": "avó", "k": "analogas"}, {"w": "madrinha", "k": "analogas"}, {"w": "nora", "k": "sinonimos"}, {"w": "sogra", "k": "sinonimos"}]}, {"w": "gíria", "t": "linguagem", "d": 6, "p": [-0.49, -0.47, -0.1], "l": [{"w": "alma", "k": "analogas"}, {"w": "crepúsculo", "k": "analogas"}, {"w": "frase", "k": "analogas"}, {"w": "idioma", "k": "analogas"}, {"w": "sinônimo", "k": "sinonimos"}, {"w": "sotaque", "k": "sinonimos"}, {"w": "sotaque", "k": "analogas"}]}, {"w": "grito", "t": "linguagem", "d": 6, "p": [0.02, 0.02, 0.0], "l": [{"w": "conversa", "k": "analogas"}, {"w": "pergunta", "k": "analogas"}, {"w": "silêncio", "k": "sinonimos"}, {"w": "silêncio", "k": "analogas"}, {"w": "sobrinho", "k": "analogas"}, {"w": "sussurro", "k": "sinonimos"}]}, {"w": "herança", "t": "família", "d": 9, "p": [-0.32, -0.32, -0.07], "l": [{"w": "conto", "k": "analogas"}, {"w": "família", "k": "sinonimos"}, {"w": "madrinha", "k": "sinonimos"}, {"w": "marinheiro", "k": "analogas"}, {"w": "neta", "k": "analogas"}, {"w": "pimenta", "k": "analogas"}, {"w": "sinônimo", "k": "analogas"}, {"w": "tio", "k": "analogas"}]}, {"w": "história", "t": "linguagem", "d": 7, "p": [1.77, 1.92, 0.4], "l": [{"w": "apelido", "k": "analogas"}, {"w": "comida", "k": "analogas"}, {"w": "memória", "k": "sinonimos"}, {"w": "resposta", "k": "sinonimos"}, {"w": "surpresa", "k": "analogas"}, {"w": "tempo", "k": "analogas"}]}, {"w": "hoje", "t": "tempo", "d": 5, "p": [0.05, 0.05, 0.01], "l": [{"w": "amanhã", "k": "sinonimos"}, {"w": "amanhã", "k": "analogas"}, {"w": "crepúsculo", "k": "analogas"}, {"w": "dente", "k": "analogas"}, {"w": "ontem", "k": "sinonimos"}, {"w": "tristeza", "k": "analogas"}]}, {"w": "hora", "t": "tempo", "d": 5, "p": [1.43, 1.56, 0.32], "l": [{"w": "advogado", "k": "analogas"}, {"w": "minuto", "k": "sinonimos"}, {"w": "tempo", "k": "sinonimos"}, {"w": "época", "k": "analogas"}]}, {"w": "idioma", "t": "linguagem", "d": 8, "p": [3.66, 3.64, 0.79], "l": [{"w": "apelido", "k": "analogas"}, {"w": "canção", "k": "analogas"}, {"w": "gíria", "k": "analogas"}, {"w": "linguagem", "k": "sinonimos"}, {"w": "madrinha", "k": "analogas"}, {"w": "palavra", "k": "sinonimos"}]}, {"w": "igreja", "t": "lugares", "d": 7, "p": [0.02, 0.01, 0.0], "l": [{"w": "bairro", "k": "analogas"}, {"w": "escola", "k": "sinonimos"}, {"w": "mercado", "k": "sinonimos"}, {"w": "mercado", "k": "analogas"}, {"w": "operário", "k": "analogas"}]}, {"w": "instante", "t": "tempo", "d": 6, "p": [0.06, 0.06, 0.01], "l": [{"w": "almoço", "k": "analogas"}, {"w": "aurora", "k": "analogas"}, {"w": "eternidade", "k": "analogas"}, {"w": "momento", "k": "sinonimos"}, {"w": "segundo", "k": "sinonimos"}]}, {"w": "irmã", "t": "família", "d": 6, "p": [-0.2, -0.17, -0.04], "l": [{"w": "apelido", "k": "analogas"}, {"w": "avô", "k": "sinonimos"}, {"w": "irmão", "k": "sinonimos"}, {"w": "pintura", "k": "analogas"}, {"w": "sal", "k": "analogas"}, {"w": "tia", "k": "analogas"}]}, {"w": "irmão", "t": "família", "d": 7, "p": [-0.12, -0.1, -0.02], "l": [{"w": "engenheiro", "k": "analogas"}, {"w": "filha", "k": "sinonimos"}, {"w": "irmã", "k": "sinonimos"}, {"w": "pais", "k": "analogas"}, {"w": "ponte", "k": "analogas"}, {"w": "tia", "k": "analogas"}]}, {"w": "janela", "t": "lugares", "d": 7, "p": [-0.09, -0.07, -0.02], "l": [{"w": "braço", "k": "analogas"}, {"w": "cozinha", "k": "sinonimos"}, {"w": "igreja", "k": "analogas"}, {"w": "nação", "k": "analogas"}, {"w": "porta", "k": "sinonimos"}, {"w": "profissão", "k": "analogas"}]}, {"w": "jantar", "t": "comida", "d": 5, "p": [0.03, 0.03, 0.01], "l": [{"w": "almoço", "k": "sinonimos"}, {"w": "coração", "k": "analogas"}, {"w": "emprego", "k": "analogas"}, {"w": "mel", "k": "analogas"}, {"w": "pão", "k": "sinonimos"}]}, {"w": "jardim", "t": "natureza", "d": 7, "p": [-0.03, -0.0, -0.0], "l": [{"w": "campo", "k": "sinonimos"}, {"w": "escultura", "k": "analogas"}, {"w": "fruto", "k": "sinonimos"}, {"w": "montanha", "k": "analogas"}, {"w": "praia", "k": "analogas"}, {"w": "pétala", "k": "analogas"}]}, {"w": "joelho", "t": "corpo", "d": 5, "p": [0.04, 0.04, 0.01], "l": [{"w": "coração", "k": "analogas"}, {"w": "pedreiro", "k": "analogas"}, {"w": "perna", "k": "sinonimos"}, {"w": "perna", "k": "analogas"}, {"w": "pé", "k": "sinonimos"}, {"w": "tambor", "k": "analogas"}]}, {"w": "juiz", "t": "ofícios", "d": 6, "p": [-0.24, -0.21, -0.05], "l": [{"w": "advogado", "k": "sinonimos"}, {"w": "advogado", "k": "analogas"}, {"w": "engenheiro", "k": "analogas"}, {"w": "mão", "k": "analogas"}, {"w": "patrão", "k": "analogas"}, {"w": "porto", "k": "analogas"}, {"w": "soldado", "k": "sinonimos"}]}, {"w": "lago", "t": "natureza", "d": 4, "p": [0.03, 0.03, 0.01], "l": [{"w": "acento", "k": "analogas"}, {"w": "cachoeira", "k": "sinonimos"}, {"w": "mar", "k": "sinonimos"}, {"w": "mar", "k": "analogas"}, {"w": "natureza", "k": "analogas"}]}, {"w": "lar", "t": "lugares", "d": 6, "p": [-0.32, -0.32, -0.07], "l": [{"w": "casa", "k": "sinonimos"}, {"w": "conto", "k": "analogas"}, {"w": "ponte", "k": "analogas"}, {"w": "praça", "k": "analogas"}, {"w": "quarto", "k": "sinonimos"}, {"w": "rua", "k": "analogas"}]}, {"w": "lavrador", "t": "ofícios", "d": 8, "p": [-0.38, -0.38, -0.08], "l": [{"w": "engenheiro", "k": "analogas"}, {"w": "ofício", "k": "analogas"}, {"w": "padeiro", "k": "analogas"}, {"w": "pastor", "k": "sinonimos"}, {"w": "pescador", "k": "sinonimos"}, {"w": "selva", "k": "analogas"}]}, {"w": "leite", "t": "comida", "d": 6, "p": [0.04, 0.04, 0.01], "l": [{"w": "mandioca", "k": "analogas"}, {"w": "manteiga", "k": "sinonimos"}, {"w": "pele", "k": "analogas"}, {"w": "pão", "k": "analogas"}, {"w": "queijo", "k": "sinonimos"}, {"w": "época", "k": "analogas"}]}, {"w": "letra", "t": "linguagem", "d": 6, "p": [0.05, 0.05, 0.01], "l": [{"w": "apelido", "k": "sinonimos"}, {"w": "dia", "k": "analogas"}, {"w": "significado", "k": "analogas"}, {"w": "sílaba", "k": "sinonimos"}]}, {"w": "linguagem", "t": "linguagem", "d": 5, "p": [-0.27, -0.27, -0.06], "l": [{"w": "cachoeira", "k": "analogas"}, {"w": "frase", "k": "sinonimos"}, {"w": "grito", "k": "analogas"}, {"w": "idioma", "k": "sinonimos"}, {"w": "riacho", "k": "analogas"}]}, {"w": "livro", "t": "artes", "d": 5, "p": [-0.24, -0.21, -0.05], "l": [{"w": "boca", "k": "analogas"}, {"w": "cena", "k": "analogas"}, {"w": "conto", "k": "sinonimos"}, {"w": "pintura", "k": "sinonimos"}]}, {"w": "língua", "t": "corpo", "d": 6, "p": [0.01, 0.01, 0.0], "l": [{"w": "boca", "k": "sinonimos"}, {"w": "dente", "k": "sinonimos"}, {"w": "osso", "k": "analogas"}, {"w": "tarde", "k": "analogas"}]}, {"w": "madrinha", "t": "família", "d": 5, "p": [-0.25, -0.24, -0.05], "l": [{"w": "genro", "k": "analogas"}, {"w": "herança", "k": "sinonimos"}, {"w": "idioma", "k": "analogas"}, {"w": "neta", "k": "analogas"}, {"w": "padrinho", "k": "sinonimos"}]}, {"w": "madrugada", "t": "tempo", "d": 9, "p": [0.06, 0.06, 0.01], "l": [{"w": "arroz", "k": "analogas"}, {"w": "aurora", "k": "sinonimos"}, {"w": "eternidade", "k": "analogas"}, {"w": "manhã", "k": "analogas"}, {"w": "médico", "k": "analogas"}, {"w": "noite", "k": "sinonimos"}, {"w": "nome", "k": "analogas"}, {"w": "passado", "k": "analogas"}, {"w": "vila", "k": "analogas"}]}, {"w": "mãe", "t": "família", "d": 5, "p": [0.05, 0.05, 0.01], "l": [{"w": "avó", "k": "analogas"}, {"w": "cena", "k": "analogas"}, {"w": "neto", "k": "analogas"}, {"w": "pai", "k": "sinonimos"}, {"w": "pais", "k": "sinonimos"}]}, {"w": "mágoa", "t": "sentimentos", "d": 5, "p": [1.17, 1.04, 0.24], "l": [{"w": "dor", "k": "sinonimos"}, {"w": "melancolia", "k": "analogas"}, {"w": "nostalgia", "k": "analogas"}, {"w": "tristeza", "k": "sinonimos"}]}, {"w": "mandioca", "t": "comida", "d": 7, "p": [-0.1, -0.08, -0.02], "l": [{"w": "carne", "k": "sinonimos"}, {"w": "feijão", "k": "analogas"}, {"w": "leite", "k": "analogas"}, {"w": "milho", "k": "sinonimos"}, {"w": "pimenta", "k": "analogas"}, {"w": "sentido", "k": "analogas"}, {"w": "árvore", "k": "analogas"}]}, {"w": "manhã", "t": "tempo", "d": 5, "p": [-0.01, -0.01, -0.0], "l": [{"w": "ano", "k": "analogas"}, {"w": "dia", "k": "sinonimos"}, {"w": "profissão", "k": "analogas"}, {"w": "tarde", "k": "sinonimos"}]}, {"w": "manteiga", "t": "comida", "d": 7, "p": [-0.09, -0.11, -0.02], "l": [{"w": "almoço", "k": "analogas"}, {"w": "ansiedade", "k": "analogas"}, {"w": "açúcar", "k": "sinonimos"}, {"w": "leite", "k": "sinonimos"}, {"w": "milho", "k": "analogas"}, {"w": "queijo", "k": "analogas"}]}, {"w": "mar", "t": "natureza", "d": 7, "p": [-0.3, -0.32, -0.07], "l": [{"w": "flor", "k": "analogas"}, {"w": "lago", "k": "sinonimos"}, {"w": "lago", "k": "analogas"}, {"w": "medo", "k": "analogas"}, {"w": "onda", "k": "sinonimos"}, {"w": "vale", "k": "analogas"}]}, {"w": "marinheiro", "t": "ofícios", "d": 6, "p": [-0.09, -0.07, -0.02], "l": [{"w": "advogado", "k": "analogas"}, {"w": "engenheiro", "k": "sinonimos"}, {"w": "herança", "k": "analogas"}, {"w": "médico", "k": "analogas"}, {"w": "pedreiro", "k": "analogas"}, {"w": "soldado", "k": "sinonimos"}]}, {"w": "mata", "t": "natureza", "d": 5, "p": [-0.14, -0.14, -0.03], "l": [{"w": "floresta", "k": "sinonimos"}, {"w": "fruto", "k": "analogas"}, {"w": "mercado", "k": "analogas"}, {"w": "selva", "k": "sinonimos"}, {"w": "árvore", "k": "analogas"}]}, {"w": "médico", "t": "ofícios", "d": 7, "p": [0.03, 0.03, 0.01], "l": [{"w": "enfermeira", "k": "sinonimos"}, {"w": "estado", "k": "analogas"}, {"w": "madrugada", "k": "analogas"}, {"w": "marinheiro", "k": "analogas"}, {"w": "pastor", "k": "sinonimos"}]}, {"w": "medo", "t": "sentimentos", "d": 6, "p": [-0.09, -0.09, -0.02], "l": [{"w": "angústia", "k": "analogas"}, {"w": "ansiedade", "k": "sinonimos"}, {"w": "pavor", "k": "sinonimos"}, {"w": "pavor", "k": "analogas"}, {"w": "ternura", "k": "analogas"}]}, {"w": "mel", "t": "comida", "d": 6, "p": [-0.13, -0.14, -0.03], "l": [{"w": "açúcar", "k": "sinonimos"}, {"w": "jantar", "k": "analogas"}, {"w": "melancolia", "k": "analogas"}, {"w": "pimenta", "k": "analogas"}, {"w": "sal", "k": "sinonimos"}]}, {"w": "melancolia", "t": "sentimentos", "d": 7, "p": [-0.06, -0.04, -0.01], "l": [{"w": "carinho", "k": "analogas"}, {"w": "mágoa", "k": "analogas"}, {"w": "médico", "k": "analogas"}, {"w": "nostalgia", "k": "sinonimos"}, {"w": "tristeza", "k": "sinonimos"}]}, {"w": "melodia", "t": "artes", "d": 5, "p": [0.1, 0.1, 0.02], "l": [{"w": "canção", "k": "sinonimos"}, {"w": "cena", "k": "analogas"}, {"w": "piano", "k": "analogas"}, {"w": "ritmo", "k": "sinonimos"}, {"w": "verso", "k": "analogas"}]}, {"w": "memória", "t": "linguagem", "d": 4, "p": [0.82, 0.71, 0.16], "l": [{"w": "alma", "k": "analogas"}, {"w": "história", "k": "sinonimos"}, {"w": "palavra", "k": "sinonimos"}, {"w": "sílaba", "k": "analogas"}]}, {"w": "mercado", "t": "lugares", "d": 6, "p": [0.04, 0.04, 0.01], "l": [{"w": "emprego", "k": "analogas"}, {"w": "estação", "k": "sinonimos"}, {"w": "igreja", "k": "sinonimos"}, {"w": "igreja", "k": "analogas"}, {"w": "mata", "k": "analogas"}, {"w": "porta", "k": "analogas"}]}, {"w": "milho", "t": "comida", "d": 7, "p": [-0.08, -0.07, -0.02], "l": [{"w": "campo", "k": "analogas"}, {"w": "feijão", "k": "sinonimos"}, {"w": "mandioca", "k": "sinonimos"}, {"w": "manteiga", "k": "analogas"}, {"w": "refeição", "k": "analogas"}, {"w": "tela", "k": "analogas"}, {"w": "trigo", "k": "analogas"}]}, {"w": "minuto", "t": "tempo", "d": 6, "p": [-0.26, -0.28, -0.06], "l": [{"w": "futuro", "k": "analogas"}, {"w": "hora", "k": "sinonimos"}, {"w": "noite", "k": "analogas"}, {"w": "segundo", "k": "sinonimos"}, {"w": "tambor", "k": "analogas"}]}, {"w": "momento", "t": "tempo", "d": 5, "p": [0.02, 0.02, 0.0], "l": [{"w": "café", "k": "analogas"}, {"w": "instante", "k": "sinonimos"}, {"w": "noite", "k": "analogas"}, {"w": "época", "k": "sinonimos"}]}, {"w": "montanha", "t": "natureza", "d": 6, "p": [1.17, 1.03, 0.24], "l": [{"w": "areia", "k": "analogas"}, {"w": "jardim", "k": "analogas"}, {"w": "lavrador", "k": "analogas"}, {"w": "prado", "k": "sinonimos"}, {"w": "prado", "k": "analogas"}, {"w": "serra", "k": "sinonimos"}]}, {"w": "música", "t": "artes", "d": 7, "p": [-0.05, -0.04, -0.01], "l": [{"w": "ano", "k": "analogas"}, {"w": "arte", "k": "sinonimos"}, {"w": "canção", "k": "sinonimos"}, {"w": "nora", "k": "analogas"}, {"w": "pintura", "k": "analogas"}, {"w": "samba", "k": "analogas"}, {"w": "verso", "k": "analogas"}]}, {"w": "mão", "t": "corpo", "d": 6, "p": [-0.18, -0.16, -0.04], "l": [{"w": "braço", "k": "sinonimos"}, {"w": "dedo", "k": "sinonimos"}, {"w": "estado", "k": "analogas"}, {"w": "pele", "k": "analogas"}]}, {"w": "mês", "t": "tempo", "d": 6, "p": [-0.08, -0.06, -0.01], "l": [{"w": "ano", "k": "sinonimos"}, {"w": "era", "k": "analogas"}, {"w": "ferreiro", "k": "analogas"}, {"w": "momento", "k": "analogas"}, {"w": "semana", "k": "sinonimos"}, {"w": "sinônimo", "k": "analogas"}]}, {"w": "nação", "t": "lugares", "d": 7, "p": [-0.31, -0.33, -0.07], "l": [{"w": "instante", "k": "analogas"}, {"w": "país", "k": "sinonimos"}, {"w": "pátria", "k": "sinonimos"}, {"w": "rua", "k": "analogas"}, {"w": "vila", "k": "analogas"}]}, {"w": "natureza", "t": "natureza", "d": 6, "p": [-0.1, -0.11, -0.02], "l": [{"w": "areia", "k": "sinonimos"}, {"w": "floresta", "k": "sinonimos"}, {"w": "raiz", "k": "analogas"}, {"w": "romance", "k": "analogas"}]}, {"w": "neta", "t": "família", "d": 7, "p": [-0.08, -0.1, -0.02], "l": [{"w": "arroz", "k": "analogas"}, {"w": "madrinha", "k": "analogas"}, {"w": "neto", "k": "sinonimos"}, {"w": "pais", "k": "analogas"}, {"w": "quarto", "k": "analogas"}, {"w": "tio", "k": "sinonimos"}]}, {"w": "neto", "t": "família", "d": 6, "p": [0.07, 0.07, 0.02], "l": [{"w": "avó", "k": "sinonimos"}, {"w": "filho", "k": "analogas"}, {"w": "mãe", "k": "analogas"}, {"w": "neta", "k": "sinonimos"}, {"w": "romance", "k": "analogas"}, {"w": "sílaba", "k": "analogas"}]}, {"w": "noite", "t": "tempo", "d": 5, "p": [0.01, 0.01, 0.0], "l": [{"w": "desenho", "k": "analogas"}, {"w": "madrugada", "k": "sinonimos"}, {"w": "minuto", "k": "analogas"}, {"w": "momento", "k": "analogas"}, {"w": "tarde", "k": "sinonimos"}, {"w": "tarde", "k": "analogas"}]}, {"w": "nome", "t": "linguagem", "d": 5, "p": [0.06, 0.07, 0.01], "l": [{"w": "apelido", "k": "sinonimos"}, {"w": "madrugada", "k": "analogas"}, {"w": "ritmo", "k": "analogas"}, {"w": "sussurro", "k": "sinonimos"}, {"w": "voz", "k": "analogas"}]}, {"w": "nora", "t": "família", "d": 8, "p": [-0.09, -0.08, -0.02], "l": [{"w": "família", "k": "analogas"}, {"w": "filha", "k": "analogas"}, {"w": "genro", "k": "sinonimos"}, {"w": "música", "k": "analogas"}, {"w": "padrinho", "k": "sinonimos"}, {"w": "patrão", "k": "analogas"}, {"w": "peixe", "k": "analogas"}]}, {"w": "nostalgia", "t": "sentimentos", "d": 5, "p": [-0.09, -0.08, -0.02], "l": [{"w": "esperança", "k": "analogas"}, {"w": "melancolia", "k": "sinonimos"}, {"w": "mágoa", "k": "analogas"}, {"w": "saudade", "k": "sinonimos"}, {"w": "sílaba", "k": "analogas"}]}, {"w": "ofício", "t": "ofícios", "d": 6, "p": [0.06, 0.06, 0.01], "l": [{"w": "areia", "k": "analogas"}, {"w": "lavrador", "k": "analogas"}, {"w": "livro", "k": "analogas"}, {"w": "padeiro", "k": "analogas"}, {"w": "profissão", "k": "sinonimos"}, {"w": "trabalho", "k": "sinonimos"}]}, {"w": "olho", "t": "corpo", "d": 5, "p": [-0.01, -0.01, -0.0], "l": [{"w": "boca", "k": "sinonimos"}, {"w": "escultura", "k": "analogas"}, {"w": "pulmão", "k": "analogas"}, {"w": "rosto", "k": "sinonimos"}]}, {"w": "ombro", "t": "corpo", "d": 4, "p": [-0.0, -0.0, -0.0], "l": [{"w": "boca", "k": "analogas"}, {"w": "braço", "k": "sinonimos"}, {"w": "pescoço", "k": "sinonimos"}, {"w": "água", "k": "analogas"}]}, {"w": "onda", "t": "natureza", "d": 7, "p": [1.75, 1.88, 0.39], "l": [{"w": "campo", "k": "analogas"}, {"w": "ferreiro", "k": "analogas"}, {"w": "mar", "k": "sinonimos"}, {"w": "prado", "k": "analogas"}, {"w": "praia", "k": "sinonimos"}, {"w": "riacho", "k": "analogas"}, {"w": "tempo", "k": "analogas"}]}, {"w": "ontem", "t": "tempo", "d": 3, "p": [0.0, 0.0, 0.0], "l": [{"w": "crepúsculo", "k": "sinonimos"}, {"w": "crepúsculo", "k": "analogas"}, {"w": "hoje", "k": "sinonimos"}, {"w": "pavor", "k": "analogas"}]}, {"w": "operário", "t": "ofícios", "d": 7, "p": [-0.08, -0.06, -0.01], "l": [{"w": "igreja", "k": "analogas"}, {"w": "lavrador", "k": "analogas"}, {"w": "passado", "k": "analogas"}, {"w": "patrão", "k": "sinonimos"}, {"w": "pedreiro", "k": "sinonimos"}, {"w": "profissão", "k": "analogas"}, {"w": "soldado", "k": "analogas"}]}, {"w": "osso", "t": "corpo", "d": 6, "p": [0.03, 0.03, 0.01], "l": [{"w": "farinha", "k": "analogas"}, {"w": "língua", "k": "analogas"}, {"w": "pele", "k": "sinonimos"}, {"w": "pescoço", "k": "analogas"}, {"w": "sangue", "k": "sinonimos"}]}, {"w": "ovo", "t": "comida", "d": 5, "p": [1.17, 1.05, 0.24], "l": [{"w": "carne", "k": "analogas"}, {"w": "compaixão", "k": "analogas"}, {"w": "palavra", "k": "analogas"}, {"w": "peixe", "k": "sinonimos"}, {"w": "queijo", "k": "sinonimos"}]}, {"w": "padeiro", "t": "ofícios", "d": 5, "p": [-0.12, -0.13, -0.03], "l": [{"w": "alfaiate", "k": "sinonimos"}, {"w": "açougueiro", "k": "sinonimos"}, {"w": "capital", "k": "analogas"}, {"w": "lavrador", "k": "analogas"}, {"w": "ofício", "k": "analogas"}]}, {"w": "padrinho", "t": "família", "d": 4, "p": [-0.1, -0.11, -0.02], "l": [{"w": "madrinha", "k": "sinonimos"}, {"w": "nora", "k": "sinonimos"}, {"w": "sotaque", "k": "analogas"}, {"w": "tio", "k": "analogas"}]}, {"w": "pai", "t": "família", "d": 6, "p": [-0.11, -0.12, -0.02], "l": [{"w": "avó", "k": "analogas"}, {"w": "canção", "k": "analogas"}, {"w": "cozinha", "k": "analogas"}, {"w": "filho", "k": "sinonimos"}, {"w": "mãe", "k": "sinonimos"}]}, {"w": "pais", "t": "família", "d": 9, "p": [-0.14, -0.11, -0.03], "l": [{"w": "contentamento", "k": "analogas"}, {"w": "irmão", "k": "analogas"}, {"w": "mãe", "k": "sinonimos"}, {"w": "neta", "k": "analogas"}, {"w": "parentesco", "k": "sinonimos"}, {"w": "pavor", "k": "analogas"}, {"w": "tia", "k": "analogas"}]}, {"w": "paixão", "t": "sentimentos", "d": 5, "p": [-0.08, -0.07, -0.02], "l": [{"w": "amor", "k": "sinonimos"}, {"w": "ansiedade", "k": "analogas"}, {"w": "conto", "k": "analogas"}, {"w": "prazer", "k": "sinonimos"}, {"w": "unha", "k": "analogas"}]}, {"w": "palavra", "t": "linguagem", "d": 16, "p": [-14.39, -12.92, -2.93], "l": [{"w": "advogado", "k": "analogas"}, {"w": "alma", "k": "analogas"}, {"w": "cabeça", "k": "analogas"}, {"w": "conto", "k": "analogas"}, {"w": "dedo", "k": "analogas"}, {"w": "era", "k": "analogas"}, {"w": "feijão", "k": "analogas"}, {"w": "idioma", "k": "sinonimos"}, {"w": "memória", "k": "sinonimos"}, {"w": "montanha", "k": "analogas"}, {"w": "mágoa", "k": "analogas"}, {"w": "ovo", "k": "analogas"}, {"w": "patrão", "k": "analogas"}, {"w": "pintura", "k": "analogas"}, {"w": "professor", "k": "analogas"}, {"w": "tia", "k": "analogas"}]}, {"w": "pão", "t": "comida", "d": 4, "p": [0.04, 0.05, 0.01], "l": [{"w": "farinha", "k": "sinonimos"}, {"w": "jantar", "k": "sinonimos"}, {"w": "leite", "k": "analogas"}, {"w": "verso", "k": "analogas"}]}, {"w": "parentesco", "t": "família", "d": 4, "p": [0.02, 0.02, 0.0], "l": [{"w": "família", "k": "sinonimos"}, {"w": "filha", "k": "analogas"}, {"w": "médico", "k": "analogas"}, {"w": "pais", "k": "sinonimos"}]}, {"w": "passado", "t": "tempo", "d": 4, "p": [-0.12, -0.13, -0.03], "l": [{"w": "eternidade", "k": "sinonimos"}, {"w": "futuro", "k": "sinonimos"}, {"w": "madrugada", "k": "analogas"}, {"w": "operário", "k": "analogas"}]}, {"w": "pastor", "t": "ofícios", "d": 5, "p": [0.04, 0.05, 0.01], "l": [{"w": "ferreiro", "k": "analogas"}, {"w": "lavrador", "k": "sinonimos"}, {"w": "mel", "k": "analogas"}, {"w": "médico", "k": "sinonimos"}, {"w": "profissão", "k": "analogas"}]}, {"w": "pátria", "t": "lugares", "d": 6, "p": [1.51, 1.65, 0.34], "l": [{"w": "alma", "k": "analogas"}, {"w": "estado", "k": "sinonimos"}, {"w": "nação", "k": "sinonimos"}, {"w": "porto", "k": "analogas"}, {"w": "praça", "k": "analogas"}, {"w": "tempo", "k": "analogas"}]}, {"w": "patrão", "t": "ofícios", "d": 7, "p": [1.44, 1.29, 0.29], "l": [{"w": "almoço", "k": "analogas"}, {"w": "carpinteiro", "k": "analogas"}, {"w": "juiz", "k": "analogas"}, {"w": "nora", "k": "analogas"}, {"w": "operário", "k": "sinonimos"}, {"w": "palavra", "k": "analogas"}, {"w": "salário", "k": "sinonimos"}]}, {"w": "pavor", "t": "sentimentos", "d": 7, "p": [-0.16, -0.18, -0.04], "l": [{"w": "aflição", "k": "analogas"}, {"w": "medo", "k": "sinonimos"}, {"w": "medo", "k": "analogas"}, {"w": "melancolia", "k": "analogas"}, {"w": "ontem", "k": "analogas"}, {"w": "pais", "k": "analogas"}, {"w": "ritmo", "k": "analogas"}, {"w": "susto", "k": "sinonimos"}]}, {"w": "país", "t": "lugares", "d": 5, "p": [0.04, 0.05, 0.01], "l": [{"w": "cidade", "k": "analogas"}, {"w": "espanto", "k": "analogas"}, {"w": "nação", "k": "sinonimos"}, {"w": "porta", "k": "sinonimos"}, {"w": "violão", "k": "analogas"}]}, {"w": "pé", "t": "corpo", "d": 5, "p": [-0.22, -0.19, -0.04], "l": [{"w": "alma", "k": "sinonimos"}, {"w": "joelho", "k": "sinonimos"}, {"w": "rosto", "k": "analogas"}, {"w": "tela", "k": "analogas"}]}, {"w": "pedreiro", "t": "ofícios", "d": 7, "p": [-0.22, -0.24, -0.05], "l": [{"w": "carpinteiro", "k": "sinonimos"}, {"w": "joelho", "k": "analogas"}, {"w": "marinheiro", "k": "analogas"}, {"w": "operário", "k": "sinonimos"}, {"w": "osso", "k": "analogas"}]}, {"w": "peito", "t": "corpo", "d": 4, "p": [0.03, 0.03, 0.01], "l": [{"w": "comida", "k": "analogas"}, {"w": "coração", "k": "sinonimos"}, {"w": "pulmão", "k": "analogas"}, {"w": "unha", "k": "sinonimos"}]}, {"w": "peixe", "t": "comida", "d": 6, "p": [-0.07, -0.06, -0.01], "l": [{"w": "carne", "k": "sinonimos"}, {"w": "chá", "k": "analogas"}, {"w": "eternidade", "k": "analogas"}, {"w": "nora", "k": "analogas"}, {"w": "ovo", "k": "sinonimos"}]}, {"w": "pele", "t": "corpo", "d": 5, "p": [0.02, 0.02, 0.01], "l": [{"w": "fígado", "k": "sinonimos"}, {"w": "leite", "k": "analogas"}, {"w": "mão", "k": "analogas"}, {"w": "osso", "k": "sinonimos"}, {"w": "pulmão", "k": "analogas"}]}, {"w": "pergunta", "t": "linguagem", "d": 5, "p": [0.0, 0.0, 0.0], "l": [{"w": "acento", "k": "sinonimos"}, {"w": "grito", "k": "analogas"}, {"w": "olho", "k": "analogas"}, {"w": "resposta", "k": "sinonimos"}]}, {"w": "perna", "t": "corpo", "d": 3, "p": [0.02, 0.02, 0.0], "l": [{"w": "amanhã", "k": "analogas"}, {"w": "joelho", "k": "sinonimos"}, {"w": "joelho", "k": "analogas"}, {"w": "sangue", "k": "sinonimos"}]}, {"w": "pescador", "t": "ofícios", "d": 9, "p": [2.43, 2.6, 0.54], "l": [{"w": "amanhã", "k": "analogas"}, {"w": "açougueiro", "k": "sinonimos"}, {"w": "lavrador", "k": "sinonimos"}, {"w": "pedreiro", "k": "analogas"}, {"w": "verso", "k": "analogas"}]}, {"w": "pescoço", "t": "corpo", "d": 7, "p": [0.03, 0.03, 0.01], "l": [{"w": "avô", "k": "analogas"}, {"w": "corpo", "k": "analogas"}, {"w": "dente", "k": "sinonimos"}, {"w": "ombro", "k": "sinonimos"}, {"w": "sangue", "k": "analogas"}]}, {"w": "pétala", "t": "natureza", "d": 6, "p": [-0.16, -0.17, -0.04], "l": [{"w": "cachoeira", "k": "analogas"}, {"w": "flor", "k": "sinonimos"}, {"w": "mar", "k": "analogas"}, {"w": "semente", "k": "sinonimos"}, {"w": "susto", "k": "analogas"}]}, {"w": "piano", "t": "artes", "d": 7, "p": [-0.14, -0.15, -0.03], "l": [{"w": "dança", "k": "analogas"}, {"w": "fruto", "k": "analogas"}, {"w": "melodia", "k": "analogas"}, {"w": "prado", "k": "analogas"}, {"w": "sobrinho", "k": "analogas"}, {"w": "tambor", "k": "sinonimos"}, {"w": "violão", "k": "sinonimos"}]}, {"w": "pimenta", "t": "comida", "d": 7, "p": [-0.08, -0.09, -0.02], "l": [{"w": "almoço", "k": "analogas"}, {"w": "açúcar", "k": "analogas"}, {"w": "café", "k": "sinonimos"}, {"w": "herança", "k": "analogas"}, {"w": "mandioca", "k": "analogas"}, {"w": "mel", "k": "analogas"}, {"w": "sal", "k": "sinonimos"}, {"w": "sal", "k": "analogas"}]}, {"w": "pintura", "t": "artes", "d": 6, "p": [1.3, 1.16, 0.26], "l": [{"w": "irmã", "k": "analogas"}, {"w": "janela", "k": "analogas"}, {"w": "livro", "k": "sinonimos"}, {"w": "música", "k": "analogas"}, {"w": "palavra", "k": "analogas"}, {"w": "tela", "k": "sinonimos"}]}, {"w": "poesia", "t": "artes", "d": 6, "p": [0.05, 0.05, 0.01], "l": [{"w": "ator", "k": "sinonimos"}, {"w": "casa", "k": "analogas"}, {"w": "estado", "k": "analogas"}, {"w": "verso", "k": "sinonimos"}, {"w": "violão", "k": "analogas"}]}, {"w": "ponte", "t": "lugares", "d": 7, "p": [0.1, 0.11, 0.02], "l": [{"w": "campo", "k": "analogas"}, {"w": "esquina", "k": "sinonimos"}, {"w": "irmão", "k": "analogas"}, {"w": "lar", "k": "analogas"}, {"w": "porto", "k": "sinonimos"}, {"w": "vale", "k": "analogas"}]}, {"w": "porta", "t": "lugares", "d": 5, "p": [0.04, 0.04, 0.01], "l": [{"w": "amanhã", "k": "analogas"}, {"w": "bairro", "k": "analogas"}, {"w": "janela", "k": "sinonimos"}, {"w": "país", "k": "sinonimos"}]}, {"w": "porto", "t": "lugares", "d": 5, "p": [-0.06, -0.07, -0.01], "l": [{"w": "estação", "k": "sinonimos"}, {"w": "juiz", "k": "analogas"}, {"w": "ponte", "k": "sinonimos"}, {"w": "pátria", "k": "analogas"}, {"w": "vila", "k": "analogas"}]}, {"w": "praça", "t": "lugares", "d": 8, "p": [-0.07, -0.09, -0.02], "l": [{"w": "avenida", "k": "sinonimos"}, {"w": "esquina", "k": "sinonimos"}, {"w": "lar", "k": "analogas"}, {"w": "pátria", "k": "analogas"}, {"w": "ternura", "k": "analogas"}, {"w": "vale", "k": "analogas"}]}, {"w": "prado", "t": "natureza", "d": 6, "p": [1.4, 1.52, 0.32], "l": [{"w": "campo", "k": "sinonimos"}, {"w": "carinho", "k": "analogas"}, {"w": "montanha", "k": "sinonimos"}, {"w": "montanha", "k": "analogas"}, {"w": "onda", "k": "analogas"}, {"w": "piano", "k": "analogas"}]}, {"w": "praia", "t": "natureza", "d": 5, "p": [-0.33, -0.36, -0.07], "l": [{"w": "areia", "k": "sinonimos"}, {"w": "jardim", "k": "analogas"}, {"w": "onda", "k": "sinonimos"}, {"w": "pescador", "k": "analogas"}, {"w": "rio", "k": "analogas"}]}, {"w": "prazer", "t": "sentimentos", "d": 5, "p": [0.01, 0.01, 0.0], "l": [{"w": "acento", "k": "analogas"}, {"w": "aurora", "k": "analogas"}, {"w": "contentamento", "k": "sinonimos"}, {"w": "contentamento", "k": "analogas"}, {"w": "paixão", "k": "sinonimos"}, {"w": "ternura", "k": "analogas"}]}, {"w": "prima", "t": "família", "d": 5, "p": [0.06, 0.05, 0.01], "l": [{"w": "cidade", "k": "analogas"}, {"w": "herança", "k": "analogas"}, {"w": "primo", "k": "sinonimos"}, {"w": "sobrinho", "k": "sinonimos"}]}, {"w": "primo", "t": "família", "d": 6, "p": [-0.26, -0.23, -0.05], "l": [{"w": "ator", "k": "analogas"}, {"w": "filha", "k": "analogas"}, {"w": "prima", "k": "sinonimos"}, {"w": "professor", "k": "analogas"}, {"w": "sobrinho", "k": "analogas"}, {"w": "tia", "k": "sinonimos"}]}, {"w": "professor", "t": "ofícios", "d": 8, "p": [1.46, 1.32, 0.3], "l": [{"w": "advogado", "k": "sinonimos"}, {"w": "enfermeira", "k": "sinonimos"}, {"w": "palavra", "k": "analogas"}, {"w": "primo", "k": "analogas"}, {"w": "salário", "k": "analogas"}, {"w": "sapateiro", "k": "analogas"}, {"w": "água", "k": "analogas"}]}, {"w": "profissão", "t": "ofícios", "d": 8, "p": [0.05, 0.05, 0.01], "l": [{"w": "alfaiate", "k": "analogas"}, {"w": "emprego", "k": "sinonimos"}, {"w": "janela", "k": "analogas"}, {"w": "ofício", "k": "sinonimos"}, {"w": "operário", "k": "analogas"}, {"w": "serra", "k": "analogas"}]}, {"w": "pulmão", "t": "corpo", "d": 9, "p": [0.06, 0.06, 0.01], "l": [{"w": "avô", "k": "analogas"}, {"w": "coração", "k": "sinonimos"}, {"w": "estômago", "k": "sinonimos"}, {"w": "olho", "k": "analogas"}, {"w": "peito", "k": "analogas"}, {"w": "pele", "k": "analogas"}, {"w": "pescoço", "k": "analogas"}, {"w": "unha", "k": "analogas"}]}, {"w": "quarto", "t": "lugares", "d": 4, "p": [0.06, 0.06, 0.01], "l": [{"w": "avenida", "k": "analogas"}, {"w": "cozinha", "k": "sinonimos"}, {"w": "lar", "k": "sinonimos"}, {"w": "neta", "k": "analogas"}]}, {"w": "queijo", "t": "comida", "d": 6, "p": [-0.11, -0.09, -0.02], "l": [{"w": "alegria", "k": "analogas"}, {"w": "chá", "k": "analogas"}, {"w": "leite", "k": "sinonimos"}, {"w": "manteiga", "k": "analogas"}, {"w": "ovo", "k": "sinonimos"}, {"w": "poesia", "k": "analogas"}]}, {"w": "raiz", "t": "natureza", "d": 5, "p": [0.04, 0.04, 0.01], "l": [{"w": "folha", "k": "sinonimos"}, {"w": "natureza", "k": "analogas"}, {"w": "serra", "k": "analogas"}, {"w": "vale", "k": "analogas"}, {"w": "árvore", "k": "sinonimos"}]}, {"w": "refeição", "t": "comida", "d": 6, "p": [0.07, 0.07, 0.02], "l": [{"w": "almoço", "k": "sinonimos"}, {"w": "bairro", "k": "analogas"}, {"w": "comida", "k": "sinonimos"}, {"w": "fotografia", "k": "analogas"}, {"w": "milho", "k": "analogas"}, {"w": "água", "k": "analogas"}]}, {"w": "resposta", "t": "linguagem", "d": 4, "p": [-0.13, -0.14, -0.03], "l": [{"w": "história", "k": "sinonimos"}, {"w": "letra", "k": "analogas"}, {"w": "pergunta", "k": "sinonimos"}, {"w": "semana", "k": "analogas"}]}, {"w": "riacho", "t": "natureza", "d": 6, "p": [-0.34, -0.36, -0.08], "l": [{"w": "angústia", "k": "analogas"}, {"w": "cachoeira", "k": "sinonimos"}, {"w": "capital", "k": "analogas"}, {"w": "linguagem", "k": "analogas"}, {"w": "onda", "k": "analogas"}, {"w": "rio", "k": "sinonimos"}]}, {"w": "rima", "t": "artes", "d": 7, "p": [0.12, 0.12, 0.03], "l": [{"w": "areia", "k": "analogas"}, {"w": "fotografia", "k": "analogas"}, {"w": "romance", "k": "sinonimos"}, {"w": "significado", "k": "analogas"}, {"w": "verso", "k": "sinonimos"}, {"w": "violão", "k": "analogas"}]}, {"w": "rio", "t": "natureza", "d": 4, "p": [0.06, 0.07, 0.01], "l": [{"w": "pedreiro", "k": "analogas"}, {"w": "praia", "k": "analogas"}, {"w": "riacho", "k": "sinonimos"}, {"w": "vale", "k": "sinonimos"}]}, {"w": "ritmo", "t": "artes", "d": 5, "p": [-0.16, -0.17, -0.04], "l": [{"w": "melodia", "k": "sinonimos"}, {"w": "nome", "k": "analogas"}, {"w": "pavor", "k": "analogas"}, {"w": "samba", "k": "sinonimos"}, {"w": "teatro", "k": "analogas"}]}, {"w": "romance", "t": "artes", "d": 8, "p": [-0.42, -0.42, -0.09], "l": [{"w": "arte", "k": "analogas"}, {"w": "conto", "k": "sinonimos"}, {"w": "natureza", "k": "analogas"}, {"w": "rima", "k": "sinonimos"}, {"w": "sotaque", "k": "analogas"}, {"w": "teatro", "k": "analogas"}]}, {"w": "rosto", "t": "corpo", "d": 6, "p": [-0.07, -0.06, -0.01], "l": [{"w": "boca", "k": "analogas"}, {"w": "cabeça", "k": "sinonimos"}, {"w": "nora", "k": "analogas"}, {"w": "olho", "k": "sinonimos"}, {"w": "pé", "k": "analogas"}]}, {"w": "rua", "t": "lugares", "d": 7, "p": [1.91, 2.04, 0.43], "l": [{"w": "alfaiate", "k": "analogas"}, {"w": "avenida", "k": "sinonimos"}, {"w": "bairro", "k": "sinonimos"}, {"w": "bairro", "k": "analogas"}, {"w": "lar", "k": "analogas"}, {"w": "nação", "k": "analogas"}]}, {"w": "sal", "t": "comida", "d": 3, "p": [0.03, 0.03, 0.01], "l": [{"w": "irmã", "k": "analogas"}, {"w": "mel", "k": "sinonimos"}, {"w": "pimenta", "k": "sinonimos"}, {"w": "pimenta", "k": "analogas"}]}, {"w": "salário", "t": "ofícios", "d": 4, "p": [-0.22, -0.19, -0.04], "l": [{"w": "carne", "k": "analogas"}, {"w": "emprego", "k": "sinonimos"}, {"w": "patrão", "k": "sinonimos"}, {"w": "professor", "k": "analogas"}]}, {"w": "samba", "t": "artes", "d": 6, "p": [0.04, 0.04, 0.01], "l": [{"w": "arte", "k": "analogas"}, {"w": "flor", "k": "analogas"}, {"w": "música", "k": "analogas"}, {"w": "ritmo", "k": "sinonimos"}, {"w": "romance", "k": "analogas"}, {"w": "violão", "k": "sinonimos"}]}, {"w": "sangue", "t": "corpo", "d": 4, "p": [0.01, 0.01, 0.0], "l": [{"w": "osso", "k": "sinonimos"}, {"w": "perna", "k": "sinonimos"}, {"w": "pescoço", "k": "analogas"}, {"w": "sentido", "k": "analogas"}]}, {"w": "sapateiro", "t": "ofícios", "d": 4, "p": [-0.16, -0.13, -0.03], "l": [{"w": "alfaiate", "k": "sinonimos"}, {"w": "dedo", "k": "analogas"}, {"w": "ferreiro", "k": "sinonimos"}, {"w": "ferreiro", "k": "analogas"}, {"w": "professor", "k": "analogas"}]}, {"w": "saudade", "t": "sentimentos", "d": 5, "p": [0.03, 0.03, 0.01], "l": [{"w": "ansiedade", "k": "analogas"}, {"w": "carinho", "k": "analogas"}, {"w": "dor", "k": "analogas"}, {"w": "esperança", "k": "sinonimos"}, {"w": "nostalgia", "k": "sinonimos"}]}, {"w": "século", "t": "tempo", "d": 4, "p": [-0.18, -0.18, -0.04], "l": [{"w": "ano", "k": "sinonimos"}, {"w": "era", "k": "sinonimos"}, {"w": "era", "k": "analogas"}, {"w": "minuto", "k": "analogas"}]}, {"w": "segundo", "t": "tempo", "d": 4, "p": [0.02, 0.02, 0.0], "l": [{"w": "crepúsculo", "k": "analogas"}, {"w": "ferreiro", "k": "analogas"}, {"w": "instante", "k": "sinonimos"}, {"w": "minuto", "k": "sinonimos"}]}, {"w": "selva", "t": "natureza", "d": 5, "p": [0.06, 0.06, 0.01], "l": [{"w": "campo", "k": "analogas"}, {"w": "igreja", "k": "analogas"}, {"w": "mata", "k": "sinonimos"}, {"w": "árvore", "k": "sinonimos"}]}, {"w": "semana", "t": "tempo", "d": 5, "p": [-0.12, -0.13, -0.03], "l": [{"w": "avô", "k": "analogas"}, {"w": "dia", "k": "sinonimos"}, {"w": "futuro", "k": "analogas"}, {"w": "mês", "k": "sinonimos"}]}, {"w": "semente", "t": "natureza", "d": 6, "p": [0.04, 0.04, 0.01], "l": [{"w": "cachoeira", "k": "analogas"}, {"w": "flor", "k": "analogas"}, {"w": "folha", "k": "analogas"}, {"w": "fruto", "k": "sinonimos"}, {"w": "mercado", "k": "analogas"}, {"w": "pétala", "k": "sinonimos"}]}, {"w": "sentido", "t": "linguagem", "d": 6, "p": [-0.16, -0.17, -0.04], "l": [{"w": "frase", "k": "sinonimos"}, {"w": "história", "k": "analogas"}, {"w": "mandioca", "k": "analogas"}, {"w": "sangue", "k": "analogas"}, {"w": "significado", "k": "sinonimos"}, {"w": "significado", "k": "analogas"}, {"w": "trabalho", "k": "analogas"}]}, {"w": "serra", "t": "natureza", "d": 5, "p": [-0.11, -0.09, -0.02], "l": [{"w": "montanha", "k": "sinonimos"}, {"w": "profissão", "k": "analogas"}, {"w": "vale", "k": "sinonimos"}, {"w": "árvore", "k": "analogas"}]}, {"w": "significado", "t": "linguagem", "d": 4, "p": [-0.0, -0.0, -0.0], "l": [{"w": "dicionário", "k": "sinonimos"}, {"w": "letra", "k": "analogas"}, {"w": "rima", "k": "analogas"}, {"w": "sentido", "k": "sinonimos"}, {"w": "sentido", "k": "analogas"}]}, {"w": "sílaba", "t": "linguagem", "d": 8, "p": [-0.1, -0.09, -0.02], "l": [{"w": "acento", "k": "sinonimos"}, {"w": "compaixão", "k": "analogas"}, {"w": "frase", "k": "analogas"}, {"w": "letra", "k": "sinonimos"}, {"w": "memória", "k": "analogas"}, {"w": "neto", "k": "analogas"}, {"w": "nostalgia", "k": "analogas"}]}, {"w": "silêncio", "t": "linguagem", "d": 4, "p": [0.02, 0.02, 0.0], "l": [{"w": "conversa", "k": "sinonimos"}, {"w": "folha", "k": "analogas"}, {"w": "grito", "k": "sinonimos"}, {"w": "grito", "k": "analogas"}, {"w": "sussurro", "k": "analogas"}]}, {"w": "sinônimo", "t": "linguagem", "d": 5, "p": [0.08, 0.07, 0.02], "l": [{"w": "dicionário", "k": "sinonimos"}, {"w": "gíria", "k": "sinonimos"}, {"w": "herança", "k": "analogas"}, {"w": "mês", "k": "analogas"}, {"w": "sílaba", "k": "analogas"}]}, {"w": "sobrinho", "t": "família", "d": 7, "p": [0.03, 0.03, 0.01], "l": [{"w": "cunhado", "k": "sinonimos"}, {"w": "grito", "k": "analogas"}, {"w": "piano", "k": "analogas"}, {"w": "prima", "k": "sinonimos"}, {"w": "primo", "k": "analogas"}, {"w": "sotaque", "k": "analogas"}]}, {"w": "sogra", "t": "família", "d": 5, "p": [1.4, 1.53, 0.32], "l": [{"w": "cunhado", "k": "sinonimos"}, {"w": "dente", "k": "analogas"}, {"w": "genro", "k": "sinonimos"}, {"w": "tempo", "k": "analogas"}, {"w": "tia", "k": "analogas"}]}, {"w": "soldado", "t": "ofícios", "d": 4, "p": [0.04, 0.04, 0.01], "l": [{"w": "fotografia", "k": "analogas"}, {"w": "juiz", "k": "sinonimos"}, {"w": "marinheiro", "k": "sinonimos"}, {"w": "operário", "k": "analogas"}]}, {"w": "sotaque", "t": "linguagem", "d": 7, "p": [0.12, 0.12, 0.03], "l": [{"w": "acento", "k": "analogas"}, {"w": "gíria", "k": "sinonimos"}, {"w": "gíria", "k": "analogas"}, {"w": "sobrinho", "k": "analogas"}, {"w": "vinho", "k": "analogas"}, {"w": "voz", "k": "sinonimos"}]}, {"w": "surpresa", "t": "sentimentos", "d": 4, "p": [-0.12, -0.13, -0.03], "l": [{"w": "alegria", "k": "sinonimos"}, {"w": "braço", "k": "analogas"}, {"w": "espanto", "k": "sinonimos"}, {"w": "espanto", "k": "analogas"}, {"w": "história", "k": "analogas"}]}, {"w": "sussurro", "t": "linguagem", "d": 5, "p": [0.01, 0.01, 0.0], "l": [{"w": "folha", "k": "analogas"}, {"w": "frase", "k": "analogas"}, {"w": "grito", "k": "sinonimos"}, {"w": "nome", "k": "sinonimos"}, {"w": "silêncio", "k": "analogas"}]}, {"w": "susto", "t": "sentimentos", "d": 8, "p": [2.13, 2.28, 0.48], "l": [{"w": "alfaiate", "k": "analogas"}, {"w": "amor", "k": "analogas"}, {"w": "espanto", "k": "sinonimos"}, {"w": "estação", "k": "analogas"}, {"w": "pavor", "k": "sinonimos"}, {"w": "pétala", "k": "analogas"}, {"w": "tempo", "k": "analogas"}]}, {"w": "tambor", "t": "artes", "d": 5, "p": [0.08, 0.08, 0.02], "l": [{"w": "dança", "k": "sinonimos"}, {"w": "joelho", "k": "analogas"}, {"w": "minuto", "k": "analogas"}, {"w": "piano", "k": "sinonimos"}, {"w": "verso", "k": "analogas"}]}, {"w": "tarde", "t": "tempo", "d": 5, "p": [0.01, 0.01, 0.0], "l": [{"w": "açougueiro", "k": "analogas"}, {"w": "dia", "k": "analogas"}, {"w": "língua", "k": "analogas"}, {"w": "manhã", "k": "sinonimos"}, {"w": "noite", "k": "sinonimos"}, {"w": "noite", "k": "analogas"}]}, {"w": "teatro", "t": "artes", "d": 8, "p": [1.96, 2.12, 0.44], "l": [{"w": "cena", "k": "sinonimos"}, {"w": "dança", "k": "sinonimos"}, {"w": "era", "k": "analogas"}, {"w": "fotografia", "k": "analogas"}, {"w": "pai", "k": "analogas"}, {"w": "ritmo", "k": "analogas"}, {"w": "romance", "k": "analogas"}, {"w": "tempo", "k": "analogas"}]}, {"w": "tela", "t": "artes", "d": 6, "p": [-0.06, -0.05, -0.01], "l": [{"w": "cinema", "k": "analogas"}, {"w": "desenho", "k": "sinonimos"}, {"w": "milho", "k": "analogas"}, {"w": "pintura", "k": "sinonimos"}, {"w": "pé", "k": "analogas"}]}, {"w": "tempo", "t": "tempo", "d": 16, "p": [-18.65, -20.0, -4.17], "l": [{"w": "açúcar", "k": "analogas"}, {"w": "capital", "k": "analogas"}, {"w": "floresta", "k": "analogas"}, {"w": "futuro", "k": "sinonimos"}, {"w": "história", "k": "analogas"}, {"w": "hora", "k": "sinonimos"}, {"w": "idioma", "k": "analogas"}, {"w": "onda", "k": "analogas"}, {"w": "pescador", "k": "analogas"}, {"w": "prado", "k": "analogas"}, {"w": "pátria", "k": "analogas"}, {"w": "rua", "k": "analogas"}, {"w": "sogra", "k": "analogas"}, {"w": "susto", "k": "analogas"}, {"w": "teatro", "k": "analogas"}, {"w": "tio", "k": "analogas"}]}, {"w": "ternura", "t": "sentimentos", "d": 7, "p": [0.03, 0.03, 0.01], "l": [{"w": "alegria", "k": "analogas"}, {"w": "carinho", "k": "sinonimos"}, {"w": "compaixão", "k": "sinonimos"}, {"w": "engenheiro", "k": "analogas"}, {"w": "medo", "k": "analogas"}, {"w": "praça", "k": "analogas"}]}, {"w": "tia", "t": "família", "d": 9, "p": [1.48, 1.26, 0.29], "l": [{"w": "estação", "k": "analogas"}, {"w": "filha", "k": "analogas"}, {"w": "irmão", "k": "analogas"}, {"w": "pais", "k": "analogas"}, {"w": "primo", "k": "sinonimos"}, {"w": "sogra", "k": "analogas"}, {"w": "tio", "k": "sinonimos"}]}, {"w": "tio", "t": "família", "d": 6, "p": [1.55, 1.69, 0.35], "l": [{"w": "folha", "k": "analogas"}, {"w": "herança", "k": "analogas"}, {"w": "neta", "k": "sinonimos"}, {"w": "tempo", "k": "analogas"}, {"w": "tia", "k": "sinonimos"}]}, {"w": "trabalho", "t": "ofícios", "d": 6, "p": [0.02, 0.02, 0.0], "l": [{"w": "aldeia", "k": "analogas"}, {"w": "carpinteiro", "k": "analogas"}, {"w": "engenheiro", "k": "sinonimos"}, {"w": "ofício", "k": "sinonimos"}, {"w": "sentido", "k": "analogas"}]}, {"w": "trigo", "t": "comida", "d": 5, "p": [0.05, 0.05, 0.01], "l": [{"w": "arroz", "k": "sinonimos"}, {"w": "farinha", "k": "sinonimos"}, {"w": "milho", "k": "analogas"}, {"w": "unha", "k": "analogas"}]}, {"w": "tristeza", "t": "sentimentos", "d": 5, "p": [-0.08, -0.07, -0.02], "l": [{"w": "amor", "k": "analogas"}, {"w": "frase", "k": "analogas"}, {"w": "hoje", "k": "analogas"}, {"w": "melancolia", "k": "sinonimos"}, {"w": "mágoa", "k": "sinonimos"}]}, {"w": "unha", "t": "corpo", "d": 6, "p": [-0.24, -0.24, -0.05], "l": [{"w": "açúcar", "k": "analogas"}, {"w": "dedo", "k": "sinonimos"}, {"w": "paixão", "k": "analogas"}, {"w": "peito", "k": "sinonimos"}, {"w": "pulmão", "k": "analogas"}, {"w": "trigo", "k": "analogas"}]}, {"w": "vale", "t": "natureza", "d": 6, "p": [0.02, 0.02, 0.01], "l": [{"w": "mar", "k": "analogas"}, {"w": "ponte", "k": "analogas"}, {"w": "raiz", "k": "analogas"}, {"w": "rio", "k": "sinonimos"}, {"w": "serra", "k": "sinonimos"}]}, {"w": "verso", "t": "artes", "d": 8, "p": [-0.47, -0.47, -0.1], "l": [{"w": "melodia", "k": "analogas"}, {"w": "pescador", "k": "analogas"}, {"w": "poesia", "k": "sinonimos"}, {"w": "pão", "k": "analogas"}, {"w": "rima", "k": "sinonimos"}, {"w": "tambor", "k": "analogas"}]}, {"w": "vila", "t": "lugares", "d": 6, "p": [-0.16, -0.17, -0.04], "l": [{"w": "aldeia", "k": "sinonimos"}, {"w": "capital", "k": "sinonimos"}, {"w": "carpinteiro", "k": "analogas"}, {"w": "madrugada", "k": "analogas"}, {"w": "nação", "k": "analogas"}, {"w": "porto", "k": "analogas"}]}, {"w": "vinho", "t": "comida", "d": 5, "p": [-0.09, -0.08, -0.02], "l": [{"w": "chá", "k": "sinonimos"}, {"w": "farinha", "k": "analogas"}, {"w": "feijão", "k": "analogas"}, {"w": "sotaque", "k": "analogas"}, {"w": "água", "k": "sinonimos"}]}, {"w": "violão", "t": "artes", "d": 8, "p": [0.02, 0.02, 0.0], "l": [{"w": "enfermeira", "k": "analogas"}, {"w": "escultura", "k": "analogas"}, {"w": "país", "k": "analogas"}, {"w": "piano", "k": "sinonimos"}, {"w": "poesia", "k": "analogas"}, {"w": "praça", "k": "analogas"}, {"w": "rima", "k": "analogas"}, {"w": "samba", "k": "sinonimos"}]}, {"w": "voz", "t": "linguagem", "d": 8, "p": [-0.23, -0.25, -0.05], "l": [{"w": "afeto", "k": "analogas"}, {"w": "capital", "k": "analogas"}, {"w": "cozinha", "k": "analogas"}, {"w": "fala", "k": "sinonimos"}, {"w": "nome", "k": "analogas"}, {"w": "sotaque", "k": "sinonimos"}]}], "themes": {"artes": {"n": 25}, "comida": {"n": 25}, "corpo": {"n": 25}, "família": {"n": 25}, "linguagem": {"n": 25}, "lugares": {"n": 25}, "natureza": {"n": 25}, "ofícios": {"n": 25}, "sentimentos": {"n": 25}, "tempo": {"n": 25}}, "stats": {"words": 250, "relations": 743, "links": 1380, "top": ["palavra", "tempo"], "maxdeg": 16}, "dropped": ["em-construção", "link-antigo", "pagina-removida", "rascunho-3", "xpto-2"]};
const THEME_COLORS = {
  "sentimentos":"#f26d9b", "família":"#f2b04f", "corpo":"#e8735a", "comida":"#e7c85a",
  "natureza":"#6fcf97", "lugares":"#5bb8d9", "tempo":"#8f9bf2", "artes":"#c48cf0",
  "ofícios":"#b6a08a", "linguagem":"#7ce0d3"
};
const THEME_ORDER = Object.keys(THEME_COLORS);

const plain = s => s.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().trim();
const esc = s => s.replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const WORDS = DATA.words;
const byWord = new Map(WORDS.map(w => [w.w, w]));
const INDEX = WORDS.map(w => ({w:w.w, n:plain(w.w)})).sort((a,b)=>a.n.localeCompare(b.n,"pt"));

/* legend & stats */
const legendEl = document.getElementById("legend");
for (const t of THEME_ORDER) {
  const n = (DATA.themes[t] && DATA.themes[t].n) || 0;
  const li = document.createElement("li");
  li.innerHTML = `<span class="dot" style="background:${THEME_COLORS[t]};color:${THEME_COLORS[t]}"></span>
    <span>${esc(t)}</span><span class="ct">${n}</span>`;
  legendEl.appendChild(li);
}
document.getElementById("stats").innerHTML =
  `<b>${DATA.stats.words}</b> palavras &nbsp;·&nbsp; <b>${DATA.stats.relations}</b> relações &nbsp;·&nbsp; ` +
  `mais conectadas: <b>${DATA.stats.top.map(esc).join(", ")}</b> (${DATA.stats.maxdeg})`;

/* search */
const qEl = document.getElementById("q");
const resEl = document.getElementById("results");
let matches = [], active = -1;

function search(term) {
  const n = plain(term);
  if (!n) return [];
  const starts = [], has = [];
  for (const it of INDEX) {
    if (it.n === n) starts.unshift(it);
    else if (it.n.startsWith(n)) starts.push(it);
    else if (it.n.includes(n)) has.push(it);
  }
  return starts.concat(has).slice(0, 8);
}
function renderResults(term) {
  matches = search(term); active = -1;
  if (!term.trim()) { resEl.classList.remove("open"); resEl.innerHTML = ""; return; }
  if (!matches.length) {
    resEl.innerHTML = `<div class="empty">nenhuma palavra com “${esc(term.trim())}”.</div>`;
  } else {
    resEl.innerHTML = matches.map((m,i) => {
      const w = byWord.get(m.w);
      return `<button data-w="${esc(m.w)}" data-i="${i}" role="option">
        <span>${esc(m.w)}</span><span class="rt">${esc(w.t)} · ${w.d}</span></button>`;
    }).join("");
  }
  resEl.classList.add("open");
}
qEl.addEventListener("input", () => renderResults(qEl.value));
qEl.addEventListener("keydown", e => {
  if (e.key === "Escape") { qEl.blur(); resEl.classList.remove("open"); return; }
  if (!matches.length) return;
  if (e.key === "ArrowDown" || e.key === "ArrowUp") {
    e.preventDefault();
    active = (active + (e.key === "ArrowDown" ? 1 : matches.length - 1)) % matches.length;
    [...resEl.querySelectorAll("button")].forEach((b,i)=>b.classList.toggle("active", i===active));
  } else if (e.key === "Enter") {
    e.preventDefault();
    const pick = matches[active < 0 ? 0 : active];
    if (pick) { selectWord(pick.w, true); qEl.value = ""; resEl.classList.remove("open"); qEl.blur(); }
  }
});
resEl.addEventListener("click", e => {
  const b = e.target.closest("button[data-w]");
  if (!b) return;
  selectWord(b.dataset.w, true); qEl.value = ""; resEl.classList.remove("open"); qEl.blur();
});
document.addEventListener("click", e => {
  if (!e.target.closest(".searchwrap")) resEl.classList.remove("open");
});
document.addEventListener("keydown", e => {
  if (e.key === "/" && document.activeElement !== qEl) { e.preventDefault(); qEl.focus(); }
  if (e.key === "Escape") resEl.classList.remove("open");
});

/* panel */
const panel = document.getElementById("panel");
const panelBody = document.getElementById("panel-body");
document.getElementById("close").addEventListener("click", () => clearSelection());

function renderPanel(w) {
  const data = byWord.get(w);
  const col = THEME_COLORS[data.t] || "#aaa";
  const groups = {sinonimos:[], analogas:[], back:[]};
  const outSet = new Set();
  for (const l of data.l) {
    groups[l.k === "sinonimos" ? "sinonimos" : "analogas"].push(l.w);
    outSet.add(l.w);
  }
  for (const o of WORDS) {
    if (o.w === w) continue;
    if (o.l.some(l => l.w === w) && !outSet.has(o.w)) groups.back.push(o.w);
  }
  const part = (title, list) => {
    if (!list.length) return "";
    const uniq = [...new Set(list)].sort((a,b)=>a.localeCompare(b,"pt"));
    return `<div class="group"><h3>${title}</h3><div class="chips">${
      uniq.map(x => `<button class="chip" data-w="${esc(x)}">${esc(x)}</button>`).join("")
    }</div></div>`;
  };
  panelBody.innerHTML = `
    <div class="theme"><span class="dot" style="background:${col};color:${col}"></span>${esc(data.t)}</div>
    <h2>${esc(w)}</h2>
    <div class="degree"><b>${data.d}</b> ${data.d === 1 ? "conexão" : "conexões"} no universo</div>
    ${part("Sinônimos", groups.sinonimos)}
    ${part("Palavras análogas", groups.analogas)}
    ${part("Também apontam para cá", groups.back)}
    <div class="note">As seções seguem as ligações escritas na página desta palavra; as de volta vêm de outras páginas que a citam. Abra <b>?word=${encodeURIComponent(w)}</b> para voltar a esta vista.</div>
  `;
  panel.classList.add("open");
}
panelBody.addEventListener("click", e => {
  const b = e.target.closest("button[data-w]");
  if (b) selectWord(b.dataset.w, true);
});

/* selection state */
let selected = null, focusTarget = null, labelSet = new Set(), pulse = 0, applyView = null;

function setURL(w) {
  try {
    const u = new URL(location.href);
    if (w) u.searchParams.set("word", w); else u.searchParams.delete("word");
    history.replaceState(null, "", u.href);
  } catch (_) { /* file:// may forbid history updates */ }
}
function selectWord(w, fromUser) {
  if (!byWord.has(w)) return;
  selected = w;
  const data = byWord.get(w);
  renderPanel(w); setURL(w);
  focusTarget = data.p.slice();
  labelSet = new Set([w, ...data.l.map(l => l.w)]);
  for (const o of WORDS) if (o.l.some(l => l.w === w)) labelSet.add(o.w);
  pulse = 1;
  if (applyView) applyView();
  if (fromUser) panel.scrollTop = 0;
}
function clearSelection() {
  selected = null; focusTarget = null; labelSet = new Set();
  panel.classList.remove("open"); setURL(null);
  if (applyView) applyView();
}

/* three.js */
let THREE = null;
try {
  THREE = await import("https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js");
} catch (err) {
  document.getElementById("loading").classList.add("hide");
  document.getElementById("fail").classList.add("show");
}
if (THREE) boot();

function boot() {
  const stage = document.getElementById("stage");
  const renderer = new THREE.WebGLRenderer({antialias:true, powerPreference:"high-performance"});
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.setSize(innerWidth, innerHeight);
  stage.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x05070e);
  const camera = new THREE.PerspectiveCamera(52, innerWidth/innerHeight, .1, 600);
  const BASE_DIST = 62;
  const cam = {theta:0.5, phi:1.22, dist:BASE_DIST};
  let targetDist = BASE_DIST;
  const target = new THREE.Vector3();

  /* starfield */
  {
    const N = 2200, pos = new Float32Array(N*3), col = new Float32Array(N*3);
    const c = new THREE.Color();
    for (let i=0;i<N;i++) {
      const r = 90 + Math.random()*220;
      const t = Math.random()*Math.PI*2, u = Math.random()*2-1, s = Math.sqrt(1-u*u);
      pos[i*3] = Math.cos(t)*s*r; pos[i*3+1] = u*r; pos[i*3+2] = Math.sin(t)*s*r;
      c.setHSL(0.58 + Math.random()*0.12, .35, .55 + Math.random()*.3);
      col[i*3]=c.r; col[i*3+1]=c.g; col[i*3+2]=c.b;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos,3));
    g.setAttribute("color", new THREE.BufferAttribute(col,3));
    scene.add(new THREE.Points(g, new THREE.PointsMaterial({size:.55, vertexColors:true, transparent:true,
      opacity:.55, sizeAttenuation:true, depthWrite:false, blending:THREE.AdditiveBlending})));
  }

  /* edges */
  const edgeList = [], seen = new Set();
  for (const a of WORDS) for (const l of a.l) {
    const key = a.w < l.w ? a.w+"\u0000"+l.w : l.w+"\u0000"+a.w;
    if (seen.has(key)) continue;
    seen.add(key); edgeList.push([a.w, l.w]);
  }
  const edgePos = new Float32Array(edgeList.length*6);
  const edgeCol = new Float32Array(edgeList.length*6);
  const cA = new THREE.Color();
  edgeList.forEach(([a,b], i) => {
    const pa = byWord.get(a).p, pb = byWord.get(b).p;
    edgePos.set(pa, i*6); edgePos.set(pb, i*6+3);
    cA.set(THEME_COLORS[byWord.get(a).t]).lerp(new THREE.Color("#dfe6ff"), .35);
    edgeCol.set([cA.r,cA.g,cA.b], i*6);
    cA.set(THEME_COLORS[byWord.get(b).t]).lerp(new THREE.Color("#dfe6ff"), .35);
    edgeCol.set([cA.r,cA.g,cA.b], i*6+3);
  });
  const edgeGeo = new THREE.BufferGeometry();
  edgeGeo.setAttribute("position", new THREE.BufferAttribute(edgePos,3));
  edgeGeo.setAttribute("color", new THREE.BufferAttribute(edgeCol,3));
  scene.add(new THREE.LineSegments(edgeGeo, new THREE.LineBasicMaterial({
    vertexColors:true, transparent:true, opacity:.14, depthWrite:false, blending:THREE.AdditiveBlending})));

  /* nodes */
  const npos = new Float32Array(WORDS.length*3), ncol = new Float32Array(WORDS.length*3), nsize = new Float32Array(WORDS.length);
  const colOf = new THREE.Color();
  WORDS.forEach((w,i) => {
    npos.set(w.p, i*3);
    colOf.set(THEME_COLORS[w.t] || "#cccccc");
    ncol.set([colOf.r, colOf.g, colOf.b], i*3);
    nsize[i] = 1.55 + w.d * 0.16;
  });
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(npos,3));
  geo.setAttribute("aColor", new THREE.BufferAttribute(ncol,3));
  geo.setAttribute("size", new THREE.BufferAttribute(nsize,1));
  const pts = new THREE.Points(geo, new THREE.ShaderMaterial({
    vertexShader:`
      attribute vec3 aColor; attribute float size;
      varying vec3 vColor;
      void main(){
        vColor = aColor;
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        gl_PointSize = size * (300.0 / -mv.z);
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader:`
      varying vec3 vColor;
      void main(){
        vec2 uv = gl_PointCoord - 0.5;
        float d = length(uv);
        if (d > 0.5) discard;
        float halo = smoothstep(0.5, 0.02, d);
        float core = smoothstep(0.16, 0.0, d);
        gl_FragColor = vec4(vColor * (0.75 + core * 1.9), halo * 0.95);
      }`,
    transparent:true, depthWrite:false, blending:THREE.AdditiveBlending
  }));
  scene.add(pts);

  /* halo */
  const hc = document.createElement("canvas"); hc.width = hc.height = 128;
  const hctx = hc.getContext("2d");
  const hg = hctx.createRadialGradient(64,64,4,64,64,62);
  hg.addColorStop(0,"rgba(255,250,235,1)");
  hg.addColorStop(.3,"rgba(255,240,210,.42)");
  hg.addColorStop(1,"rgba(255,235,200,0)");
  hctx.fillStyle = hg; hctx.fillRect(0,0,128,128);
  const halo = new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(hc), transparent:true,
    depthWrite:false, blending:THREE.AdditiveBlending, opacity:.7}));
  halo.scale.set(7,7,1); halo.visible = false;
  scene.add(halo);

  /* highlighted edges */
  const hgeo = new THREE.BufferGeometry();
  const hlines = new THREE.LineSegments(hgeo, new THREE.LineBasicMaterial({color:0xfff4dc,
    transparent:true, opacity:.55, depthWrite:false, blending:THREE.AdditiveBlending}));
  scene.add(hlines);

  applyView = function() {
    if (!selected) { hlines.visible = false; halo.visible = false; targetDist = BASE_DIST; return; }
    const a = byWord.get(selected), arr = [];
    for (const l of a.l) arr.push(...a.p, ...byWord.get(l.w).p);
    for (const o of WORDS)
      if (o.w !== selected && o.l.some(l => l.w === selected)) arr.push(...a.p, ...o.p);
    hgeo.setAttribute("position", new THREE.Float32BufferAttribute(arr,3));
    hgeo.computeBoundingSphere();
    hlines.visible = true;
    halo.position.set(a.p[0], a.p[1], a.p[2]); halo.visible = true;
    targetDist = 33;
  };

  /* labels */
  const labelsEl = document.getElementById("labels");
  const labelEls = new Map();
  function labelFor(w) {
    let el = labelEls.get(w);
    if (!el) {
      el = document.createElement("div");
      el.className = "node-label dim";
      el.textContent = w;
      labelsEl.appendChild(el);
      labelEls.set(w, el);
    }
    return el;
  }

  /* interaction */
  const ray = new THREE.Raycaster();
  ray.params.Points.threshold = 1.35;
  const mouse = new THREE.Vector2(-10,-10);
  let hovered = null, dragging = false, lastX = 0, lastY = 0, moved = 0;
  const dom = renderer.domElement;
  let mouseXY = [0,0];

  function pick() {
    ray.setFromCamera(mouse, camera);
    const hits = ray.intersectObject(pts, false);
    for (const h of hits) if (h.index != null) return WORDS[h.index];
    return null;
  }

  dom.addEventListener("pointerdown", e => {
    dragging = true; moved = 0; lastX = e.clientX; lastY = e.clientY;
    dom.setPointerCapture(e.pointerId); dom.classList.add("dragging");
  });
  dom.addEventListener("pointermove", e => {
    const r = dom.getBoundingClientRect();
    mouse.x = ((e.clientX - r.left) / r.width) * 2 - 1;
    mouse.y = -((e.clientY - r.top) / r.height) * 2 + 1;
    mouseXY = [e.clientX, e.clientY];
    if (dragging) {
      const dx = e.clientX - lastX, dy = e.clientY - lastY;
      moved += Math.abs(dx) + Math.abs(dy);
      cam.theta -= dx * 0.005;
      cam.phi = Math.max(.18, Math.min(Math.PI - .18, cam.phi - dy * 0.005));
      lastX = e.clientX; lastY = e.clientY;
    }
  });
  dom.addEventListener("pointerup", () => {
    dragging = false; dom.classList.remove("dragging");
    if (moved < 5) { const hit = pick(); if (hit) selectWord(hit.w, true); }
  });
  dom.addEventListener("pointerleave", () => { dragging = false; mouse.set(-10,-10); });
  dom.addEventListener("wheel", e => {
    e.preventDefault();
    targetDist = Math.max(18, Math.min(130, targetDist * (1 + Math.sign(e.deltaY) * 0.09)));
  }, {passive:false});
  dom.addEventListener("dblclick", () => clearSelection());

  const tooltip = document.getElementById("tooltip");
  const tw = tooltip.querySelector(".tw"), td = tooltip.querySelector(".td");

  /* deep link */
  const p0 = new URLSearchParams(location.search);
  const rawWord = (p0.get("word") || "").trim();
  if (rawWord) {
    const n = plain(rawWord);
    const hit = WORDS.find(w => w.w === rawWord) || WORDS.find(w => plain(w.w) === n);
    if (hit) selectWord(hit.w, false);
    else { qEl.value = rawWord; renderResults(rawWord); }
  }

  /* loop */
  const clock = new THREE.Clock();
  const labelTmp = new THREE.Vector3();
  const desired = new THREE.Vector3();
  function frame() {
    requestAnimationFrame(frame);
    const dt = Math.min(clock.getDelta(), .05);
    if (!dragging) cam.theta += dt * 0.035;
    if (pulse > 0) pulse = Math.max(0, pulse - dt*1.6);

    if (focusTarget) desired.set(focusTarget[0], focusTarget[1], focusTarget[2]);
    else desired.set(0,0,0);
    target.lerp(desired, Math.min(1, dt*4));
    cam.dist += (targetDist - cam.dist) * Math.min(1, dt*4);
    camera.position.set(
      target.x + cam.dist * Math.sin(cam.phi) * Math.sin(cam.theta),
      target.y + cam.dist * Math.cos(cam.phi),
      target.z + cam.dist * Math.sin(cam.phi) * Math.cos(cam.theta));
    camera.lookAt(target);

    const hit = dragging ? null : pick();
    if (hit !== hovered) {
      hovered = hit;
      dom.style.cursor = hit ? "pointer" : "grab";
      if (hit) {
        tw.textContent = hit.w;
        td.textContent = hit.t + " · " + hit.d + (hit.d === 1 ? " ligação" : " ligações");
        tooltip.style.display = "block";
      } else tooltip.style.display = "none";
    }
    if (hovered) { tooltip.style.left = mouseXY[0]+"px"; tooltip.style.top = mouseXY[1]+"px"; }

    for (const el of labelEls.values()) el.style.opacity = "0";
    for (const w of labelSet) {
      const d = byWord.get(w);
      if (!d) continue;
      labelTmp.set(d.p[0], d.p[1], d.p[2]).project(camera);
      if (!(labelTmp.z < 1 && Math.abs(labelTmp.x) < 1.05 && Math.abs(labelTmp.y) < 1.05)) continue;
      const el = labelFor(w);
      el.className = "node-label" + (w === selected ? " main" : " dim");
      el.style.opacity = w === selected ? "1" : "0.7";
      el.style.left = ((labelTmp.x*.5+.5)*innerWidth) + "px";
      el.style.top = ((-labelTmp.y*.5+.5)*innerHeight) + "px";
      el.style.zIndex = w === selected ? "6" : "4";
    }
    halo.material.opacity = .5 + .22 * Math.sin(performance.now()/520) + pulse*.25;
    halo.scale.setScalar(6.2 + Math.sin(performance.now()/520)*.6 + pulse*1.6);
    renderer.render(scene, camera);
  }

  window.addEventListener("resize", () => {
    camera.aspect = innerWidth/innerHeight; camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
  });

  requestAnimationFrame(frame);
  setTimeout(() => document.getElementById("loading").classList.add("hide"), 220);
  if (selected) applyView();
}
