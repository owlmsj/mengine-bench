import os,re,unicodedata,collections
files=[f for f in os.listdir("site") if f.endswith(".html")]
print("distinct NFC:",len(set(unicodedata.normalize("NFC",f) for f in files)))
for f in files:
    if unicodedata.normalize("NFC",f)!=f: print("non-NFC filename:",repr(f),unicodedata.normalize("NFC",f))
for f in ["coracoes.html","paixoes.html","saudades.html"]:
    t=open("site/"+f,encoding="utf-8").read(); print("====",f); print(t)
# longest link pages
for f in files:
    t=open("site/"+f,encoding="utf-8").read()
    n=len(re.findall(r"<a href=",t))
    if n>10: print(f,n)
