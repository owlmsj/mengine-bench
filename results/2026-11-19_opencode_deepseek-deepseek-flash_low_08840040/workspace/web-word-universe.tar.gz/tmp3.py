import os,re,html,urllib.parse,unicodedata,collections,json
N=lambda s:unicodedata.normalize("NFC",s)
files=[f for f in os.listdir("site") if f.endswith(".html")]
bykey={N(f).casefold():f for f in files}
print("collisions:",len(bykey),len(files))
raw={}
for f in files:
    t=open("site/"+f,encoding="utf-8",errors="replace").read()
    raw[f]=t
redirect={}
for f,t in raw.items():
    m=re.search(r'http-equiv="refresh" content="0; url=([^"]+)"',t)
    if m: redirect[f]=html.unescape(urllib.parse.unquote(m.group(1)))
print("redirects:",{k:(v,bykey.get(N(v).casefold())) for k,v in redirect.items()})
def resolve(h):
    h=urllib.parse.unquote(html.unescape(h))
    key=N(h).casefold()
    f=bykey.get(key)
    if not f: return None
    seen=set()
    while f in redirect and f not in seen:
        seen.add(f); f=bykey.get(N(redirect[f]).casefold())
        if not f: return None
    return f
bad=collections.Counter(); selfl=[]; hrefnorm=collections.Counter()
for f,t in raw.items():
    if f in redirect: continue
    for href in re.findall(r'<section[^>]*>.*?</section>',t,re.S):
        pass
    secs=re.findall(r'<section id="(\w+)"><h2>.*?</h2><ul>(.*?)</ul></section>',t,re.S)
    for sid,ul in secs:
        for href,txt in re.findall(r'<a href="([^"]+)">(.*?)</a>',ul,re.S):
            r=resolve(href)
            if r is None: bad[(f,href,html.unescape(txt))]+=1
            elif r==f: selfl.append((f,href,html.unescape(txt)))
            if N(href)!=href: hrefnorm[href]+=1
print("bad:",bad)
print("self:",selfl)
print("non-NFC hrefs:",hrefnorm)
# words
words={}
for f,t in raw.items():
    if f in redirect or f in ("index.html","sobre.html","contato.html"): continue
    h1=re.search(r"<h1>(.*?)</h1>",t,re.S)
    tema=re.search(r'class="tema">Tema: (.*?)<',t)
    words[f]={"w":html.unescape(h1.group(1)),"tema":html.unescape(tema.group(1)) if tema else None}
print("words:",len(words),"unique h1:",len(set(N(w["w"]) for w in words.values())))
# dup display names
print("dups:",[(k,v) for k,v in collections.Counter(N(w["w"]).casefold() for w in words.values()).items() if v>1])
json.dump({"words":{k:{"w":v["w"],"tema":v["tema"]} for k,v in words.items()},"files":files},open("tmp_words.json","w",encoding="utf-8"),ensure_ascii=False,indent=1)
