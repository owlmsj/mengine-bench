p="universe/index.html"
s=open(p,encoding="utf-8").read()
s=s.replace("""  scene.add(new THREE.LineSegments(edgeGeo, new THREE.LineBasicMaterial({
    vertexColors:true, transparent:true, opacity:.14, depthWrite:false, blending:THREE.AdditiveBlending})));""",
"""  const emat = new THREE.LineBasicMaterial({vertexColors:true, transparent:true, opacity:.14,
    depthWrite:false, blending:THREE.AdditiveBlending});
  scene.add(new THREE.LineSegments(edgeGeo, emat));""")
s=s.replace("""  geo.setAttribute("size", new THREE.BufferAttribute(nsize,1));""",
"""  geo.setAttribute("size", new THREE.BufferAttribute(nsize,1));
  const nAlpha = new Float32Array(WORDS.length).fill(1);
  geo.setAttribute("aAlpha", new THREE.BufferAttribute(nAlpha,1));""")
s=s.replace("""      attribute vec3 aColor; attribute float size;
      varying vec3 vColor;
      void main(){
        vColor = aColor;""",
"""      attribute vec3 aColor; attribute float size; attribute float aAlpha;
      varying vec3 vColor; varying float vAlpha;
      void main(){
        vColor = aColor; vAlpha = aAlpha;""")
s=s.replace("""      varying vec3 vColor;
      void main(){
        vec2 uv = gl_PointCoord - 0.5;""",
"""      varying vec3 vColor; varying float vAlpha;
      void main(){
        vec2 uv = gl_PointCoord - 0.5;""")
s=s.replace("gl_FragColor = vec4(vColor * (0.75 + core * 1.9), halo * 0.95);",
            "gl_FragColor = vec4(vColor * (0.75 + core * 1.9), halo * 0.95 * vAlpha);")
s=s.replace("""    targetDist = 15; cam.dist = 15;
    target.set(a.p[0], a.p[1], a.p[2]);
  };""",
"""    targetDist = 15; cam.dist = 15;
    target.set(a.p[0], a.p[1], a.p[2]);
    WORDS.forEach((w,i) => { nAlpha[i] = labelSet.has(w.w) ? 1 : 0.14; });
    geo.attributes.aAlpha.needsUpdate = true;
    emat.opacity = .055;
  };""")
s=s.replace("""    if (!selected) { hlines.visible = false; halo.visible = false; targetDist = BASE_DIST; cam.dist = BASE_DIST; target.set(0,0,0); return; }""",
"""    if (!selected) { hlines.visible = false; halo.visible = false; targetDist = BASE_DIST; cam.dist = BASE_DIST; target.set(0,0,0);
      nAlpha.fill(1); geo.attributes.aAlpha.needsUpdate = true; emat.opacity = .14; return; }""")
open(p,"w",encoding="utf-8",newline="\n").write(s)
print("ok")
