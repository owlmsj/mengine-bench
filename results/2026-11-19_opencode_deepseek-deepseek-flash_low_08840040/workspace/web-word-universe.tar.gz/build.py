import os, re, html, urllib.parse, unicodedata, collections, json
import numpy as np

ROOT = os.path.dirname(os.path.abspath(__file__))
SITE = os.path.join(ROOT, "site")
N = lambda s: unicodedata.normalize("NFC", s)

files = [f for f in os.listdir(SITE) if f.endswith(".html")]
bykey = {N(f).casefold(): f for f in files}
raw = {f: open(os.path.join(SITE, f), encoding="utf-8", errors="replace").read() for f in files}
redirect = {f: html.unescape(urllib.parse.unquote(m.group(1)))
            for f, t in raw.items()
            if (m := re.search(r'http-equiv="refresh" content="0; url=([^"]+)"', t))}

def canon(f):
    seen = set()
    while f in redirect and f not in seen:
        seen.add(f)
        f = bykey.get(N(redirect[f]).casefold())
        if f is None:
            return None
    return f

def resolve(href):
    f = bykey.get(N(urllib.parse.unquote(html.unescape(href))).casefold())
    return canon(f) if f else None

NONWORDS = {"index.html", "sobre.html", "contato.html"}
words = {}
for f, t in raw.items():
    if f in redirect or f in NONWORDS:
        continue
    h1 = html.unescape(re.search(r"<h1>(.*?)</h1>", t, re.S).group(1)).strip()
    tm = re.search(r'class="tema">Tema: (.*?)<', t)
    words[f] = {"word": h1, "theme": html.unescape(tm.group(1)).strip() if tm else None,
                "links": [], "seen": set()}

dangling = collections.Counter()
for f, d in words.items():
    for sid, _h, ul in re.findall(r'<section id="(\w+)"><h2>(.*?)</h2><ul>(.*?)</ul></section>', raw[f], re.S):
        for href, txt in re.findall(r'<a href="([^"]+)">(.*?)</a>', ul, re.S):
            r = resolve(href)
            label = html.unescape(re.sub("<.*?>", "", txt)).strip()
            if r is None or r not in words:
                if label:
                    dangling[(d["word"], label)] += 1
                continue
            if r == f:
                continue
            key = (words[r]["word"], sid)
            if key in d["seen"]:
                continue
            d["seen"].add(key)
            d["links"].append({"to": words[r]["word"], "type": sid, "label": label})

all_words = [d["word"] for d in words.values()]
assert len(all_words) == len(set(all_words)) == 250
word_theme = {d["word"]: d["theme"] for d in words.values()}

adj = {w: set() for w in all_words}
for f, d in words.items():
    for l in d["links"]:
        adj[d["word"]].add(l["to"])
        adj[l["to"]].add(d["word"])
pairs = {tuple(sorted((a, b))) for a in adj for b in adj[a]}
degree = {w: len(adj[w]) for w in all_words}

words_json = {w: sorted(adj[w], key=N) for w in sorted(all_words, key=N)}
with open(os.path.join(ROOT, "words.json"), "w", encoding="utf-8", newline="\n") as fh:
    json.dump(words_json, fh, ensure_ascii=False, indent=1)
    fh.write("\n")

maxdeg = max(degree.values())
top = sorted([w for w in all_words if degree[w] == maxdeg], key=N)
result = {
    "words": len(all_words),
    "relations": len(pairs),
    "most_connected": top[0],
    "most_connected_degree": maxdeg,
    "most_connected_ties": top,
    "themes": dict(sorted(collections.Counter(word_theme.values()).items())),
    "directed_links": sum(len(d["links"]) for d in words.values()),
    "method": ("One node per non-redirect word page (index/sobre/contato excluded); "
               "redirects coracoes->coracao, paixoes->paixao, saudades->saudade resolved; "
               "7 links to nonexistent pages dropped; self links ignored; pairs undirected and deduplicated."),
}
with open(os.path.join(ROOT, "result.json"), "w", encoding="utf-8", newline="\n") as fh:
    json.dump(result, fh, ensure_ascii=False, indent=1)
    fh.write("\n")

# ---- deterministic 3D layout: local spring layout per theme, clusters on a sphere ----
import networkx as nx

themes = sorted(set(word_theme.values()))
rng = np.random.default_rng(20261119)
idx = {w: i for i, w in enumerate(all_words)}
centers = {}
for ti, th in enumerate(themes):
    y = 1 - (ti + 0.5) * 2 / len(themes)
    r = np.sqrt(max(0.0, 1 - y * y))
    ang = ti * 2.399963229728653
    centers[th] = np.array([np.cos(ang) * r, y, np.sin(ang) * r]) * 14.5

G = nx.Graph()
G.add_nodes_from(all_words)
G.add_edges_from(pairs)
P = np.zeros((len(all_words), 3))
for ti, th in enumerate(themes):
    members = [w for w in all_words if word_theme[w] == th]
    sub = G.subgraph(members)
    init = {w: rng.normal(0, 1, 3) for w in members}
    local = nx.spring_layout(sub, dim=3, k=1.6, iterations=300, seed=11 + ti, pos=init)
    L = np.array([local[w] for w in members])
    L -= L.mean(0)
    L /= np.abs(L).max() + 1e-9
    L *= 5.7
    # arbitrary but deterministic tilt per cluster
    a1, a2 = rng.uniform(0, 2 * np.pi, 2)
    Rz = np.array([[np.cos(a1), -np.sin(a1), 0], [np.sin(a1), np.cos(a1), 0], [0, 0, 1]])
    Rx = np.array([[1, 0, 0], [0, np.cos(a2), -np.sin(a2)], [0, np.sin(a2), np.cos(a2)]])
    L = L @ Rz.T @ Rx.T
    for j, w in enumerate(members):
        P[idx[w]] = centers[th] + L[j]

# gentle global refinement: edges pull, theme centres keep clusters legible
wtheme = np.array([word_theme[w] for w in all_words])
C = np.array([centers[t] for t in wtheme])
edges = np.array([(idx[a], idx[b]) for a, b in pairs])
for it in range(90):
    disp = (C - P) * 0.02
    dd = P[edges[:, 0]] - P[edges[:, 1]]
    dl = np.sqrt(np.sum(dd * dd, axis=1)) + 1e-6
    force = (dd / dl[:, None]) * np.minimum(dl, 6)[:, None] * 0.012
    np.add.at(disp, edges[:, 0], -force)
    np.add.at(disp, edges[:, 1], force)
    step = np.sum(disp * disp, axis=1) ** 0.5
    scale = np.minimum(1.0, 0.35 / (step + 1e-9))
    P += disp * scale[:, None]
mean = P.mean(0)
scaled = (P - mean) / (np.abs(P - mean).max() + 1e-9) * 20.0

by_word = {d["word"]: d for d in words.values()}
data = {
    "words": [{"w": w, "t": word_theme[w], "d": degree[w],
               "p": [round(float(x), 2) for x in scaled[idx[w]]],
               "l": sorted([{"w": l["to"], "k": l["type"]} for l in by_word[w]["links"]], key=lambda o: N(o["w"]))}
              for w in all_words],
    "themes": {th: {"n": sum(1 for v in word_theme.values() if v == th)} for th in themes},
    "stats": {"words": len(all_words), "relations": len(pairs),
              "links": sum(len(d["links"]) for d in words.values()),
              "top": top, "maxdeg": maxdeg},
    "dropped": sorted({lbl for (_, lbl) in dangling}),
}
with open(os.path.join(ROOT, "tmp_graph.json"), "w", encoding="utf-8") as fh:
    json.dump(data, fh, ensure_ascii=False)
print("ok", result["words"], result["relations"], result["most_connected"], maxdeg, "dropped:", data["dropped"])
