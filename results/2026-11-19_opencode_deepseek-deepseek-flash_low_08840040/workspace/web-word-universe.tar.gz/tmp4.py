import os,re,html,urllib.parse,unicodedata,collections,json
N=lambda s:unicodedata.normalize("NFC",s)
files=[f for f in os.listdir("site") if f.endswith(".html")]
bykey={N(f).casefold():f for f in files}
raw={f:open("site/"+f,encoding="utf-8").read() for f in files}
redirect={f:html.unescape(urllib.parse.unquote(m.group(1))) for f,t in raw.items() if (m:=re.search(r'http-equiv="refresh" content="0; url=([^"]+)"',t))}
def canon(f):
    seen=set()
    while f in redirect and f not in seen:
        seen.add(f); f=bykey.get(N(redirect[f]).casefold())
    return f
def resolve(h):
    f=bykey.get(N(urllib.parse.unquote(html.unescape(h))).casefold())
    return canon(f) if f else None
words={}
for f,t in raw.items():
    if f in redirect or f in ("index.html","sobre.html","contato.html"): continue
    h1=html.unescape(re.search(r"<h1>(.*?)</h1>",t,re.S).group(1))
    tema=re.search(r'class="tema">Tema: (.*?)<',t)
    words[f]={"word":h1,"theme":html.unescape(tema.group(1)) if tema else None,"section_links":[]}
for f,d in words.items():
    t=raw[f]
    for sid,_h,ul in re.findall(r'<section id="(\w+)"><h2>(.*?)</h2><ul>(.*?)</ul></section>',t,re.S):
        for href,txt in re.findall(r'<a href="([^"]+)">(.*?)</a>',ul,re.S):
            r=resolve(href)
            if r and r!=f and r in words:
                d["section_links"].append((r,sid,html.unescape(re.sub("<.*?>","",txt))))
print("words",len(words))
typed=[]; und=set()
for f,d in words.items():
    for r,sid,txt in d["section_links"]:
        und.add(tuple(sorted((words[f]["word"],words[r]["word"]))))
        typed.append((words[f]["word"],words[r]["word"],sid))
print("relations",len(und),"typed edges",len(typed),"dupe typed",len(typed)-len(set((a,b,s) for a,b,s in typed)))
deg=collections.Counter()
for a,b in und: deg[a]+=1; deg[b]+=1
print("degree min/max/avg",min(deg.values()),max(deg.values()),len(und)*2/len(words))
top=deg.most_common(10); print(top)
print("isolated:",[w for w in (d["word"] for d in words.values()) if deg[w]==0])
print("themes",collections.Counter(d["theme"] for d in words.values()))
print("class map counts",collections.Counter(f for d in words.values() for r,sid,t in d["section_links"] for f in [sid]))

