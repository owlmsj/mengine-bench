import re
s=open('universe/index.html',encoding='utf-8').read()
open('tmp_check.mjs','w',encoding='utf-8',newline='\n').write(re.search(r'<script type="module">(.*?)</script>',s,re.S).group(1))
print(s.count('__GRAPH_JSON__'))
