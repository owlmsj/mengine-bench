import re
p='universe/index.html'
s=open(p,encoding='utf-8').read()
s=s.replace('<div class="vignette"></div>','<div class="vignette"></div>\n<div class="scrim"></div>')
s=s.replace('  .hint span{color:#8b92a8}','  .hint span{color:#8b92a8}\n  body.panel-open .hint{opacity:0;transition:opacity .3s}')
s=s.replace('const BASE_DIST = 62;','const BASE_DIST = 72;')
s=s.replace('targetDist = 33;','targetDist = 25;')
s=s.replace('halo.scale.set(7,7,1);','halo.scale.set(5,5,1);')
s=s.replace('halo.scale.setScalar(6.2 + Math.sin(performance.now()/520)*.6 + pulse*1.6);','halo.scale.setScalar(4.4 + Math.sin(performance.now()/520)*.5 + pulse*1.4);')
s=s.replace('  panel.classList.add("open");\n}','  panel.classList.add("open");\n  document.body.classList.add("panel-open");\n}')
s=s.replace('  panel.classList.remove("open"); setURL(null);','  panel.classList.remove("open"); document.body.classList.remove("panel-open"); setURL(null);')
open(p,'w',encoding='utf-8',newline='\n').write(s)
print('patched')
