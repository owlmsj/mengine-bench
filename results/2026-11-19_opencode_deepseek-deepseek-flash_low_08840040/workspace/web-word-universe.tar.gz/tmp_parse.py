import os,re,html,urllib.parse,json,collections
files=[f for f in os.listdir("site") if f.endswith(".html")]
print(len(files))
data={}
for f in files:
    t=open("site/"+f,encoding="utf-8").read()
    h1=re.search(r"<h1>(.*?)</h1>",t,re.S)
    tema=re.search(r'class="tema">Tema: (.*?)<',t)
    secs=re.findall(r'<section id="(\w+)"><h2>(.*?)</h2><ul>(.*?)</ul></section>',t,re.S)
    links=[]
    for sid,title,ul in secs:
        for href,txt in re.findall(r'<a href="([^"]+)">(.*?)</a>',ul,re.S):
            links.append((sid,html.unescape(re.sub('<.*?>','',txt)),urllib.parse.unquote(href)))
    data[f]={"h1":html.unescape(h1.group(1)) if h1 else None,"tema":tema.group(1) if tema else None,"links":links}
print("no h1:",[f for f in data if not data[f]["h1"]])
print("dup h1:",[(k,v) for k,v in collections.Counter(d["h1"] for d in data.values()).items() if v>1])
print("themes:",collections.Counter(d["tema"] for d in data.values()))
names=set(files)
dang=collections.Counter()
for f,d in data.items():
    for s,txt,h in d["links"]:
        if h not in names: dang[(h,txt)]+=1
print("dangling:",dang)
print("selflinks:",[(f,l) for f,d in data.items() for l in d["links"] if l[2]==f])
print("linkcounts:",collections.Counter(len(d["links"]) for d in data.values()))
for f in ["pais.html","país.html","pa%C3%ADs.html","avô.html","avó.html","estação.html","família.html","mão.html","pulmão.html","mês.html","patrão.html","língua.html"]:
    if f in data: print(f,"->",data[f]["h1"],data[f]["tema"],data[f]["links"])
