import sqlite3, json, collections
c=sqlite3.connect('analytics.db')
steps=["install","tutorial_complete","first_match","purchase"]
users={r[0]:r[1] for r in c.execute("select user_id,platform from users where is_test=0")}
ev=collections.defaultdict(lambda: collections.defaultdict(list))
for uid,name,ts in c.execute("select user_id,name,ts from events"):
    if uid in users and name in steps: ev[uid][name].append(ts)
funnel={}; drops={}
for plat in sorted(set(users.values())):
    reach={s:0 for s in steps}
    conv={}
    for uid,p in users.items():
        if p!=plat: continue
        prev=None; ok=True
        for s in steps:
            if s=="install": t=min(ev[uid][s]) if ev[uid][s] else None
            else:
                cand=[x for x in ev[uid][s] if prev is not None and x>=prev]
                t=min(cand) if cand else None
            if t is None: ok=False
            if ok:
                reach[s]+=1; prev=t
    funnel[plat]={s:reach[s] for s in steps}
    for i in range(1,len(steps)):
        conv[steps[i]]=reach[steps[i]]/reach[steps[i-1]] if reach[steps[i-1]] else 0
    drops[plat]={"step":min(conv,key=conv.get),"conversion":round(min(conv.values()),4),"all_conversions":{k:round(v,4) for k,v in conv.items()}}
print(json.dumps({"funnel":funnel,"biggest_drop":{p:d["step"] for p,d in drops.items()}},indent=2))
print(json.dumps(drops,indent=2))
# sensitivity: allow first occurrence of later step regardless of install? and strict > instead of >=
