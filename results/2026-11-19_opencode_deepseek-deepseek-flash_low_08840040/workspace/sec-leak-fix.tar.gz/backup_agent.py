"""Backup agent: packs a folder chosen in the intranet web form and uploads it to the backup API."""

from __future__ import annotations

import logging
import tarfile
import urllib.request
from pathlib import Path

import config

log = logging.getLogger("backup_agent")


def _checked_folder(folder: str) -> Path:
    """Returns the resolved source directory, rejecting anything that is not one."""
    source = Path(folder).expanduser()
    if not source.is_dir():
        raise ValueError(f"not an existing folder: {folder!r}")
    source = source.resolve()
    if source.name in ("", ".", ".."):
        raise ValueError(f"refusing to archive {folder!r}: no usable folder name")
    return source


def archive_folder(folder: str, out_dir: str = config.ARCHIVE_DIR) -> Path:
    """Packs `folder` into `out_dir/<folder name>.tar.gz` and returns the archive path."""
    source = _checked_folder(folder)
    out = Path(out_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)
    target = out / (source.name + ".tar.gz")
    if out == source or source in out.parents:
        raise ValueError(f"refusing to archive {str(source)!r} into itself")
    # tarfile handles the packing in-process: no shell, no argument parsing, so
    # nothing the user typed can be interpreted as a command or an option.
    with tarfile.open(target, "w:gz") as archive:
        archive.add(source, arcname=source.name)
    return target


def send_archive(path: Path, url: str, token: str) -> int:
    """Uploads one archive to the backup API and returns the HTTP status."""
    request = urllib.request.Request(url, data=Path(path).read_bytes(), method="POST",
                                     headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.status


def upload(path: Path) -> int:
    token = config.API_TOKEN
    if not token:
        raise RuntimeError("BACKUP_TOKEN is not set")
    log.info("uploading %s", Path(path).name)
    return send_archive(path, config.API_URL, token)


def handle_form(form: dict[str, str]) -> int:
    """Web form handler: backs up the folder the user typed."""
    archive = archive_folder(form["folder"])
    log.info("archived %s", archive.name)
    return upload(archive)
