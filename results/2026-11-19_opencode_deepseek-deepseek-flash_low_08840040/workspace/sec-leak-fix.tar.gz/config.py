"""Settings for the backup agent."""

import os

API_URL = "https://backup.example.invalid/v1/upload"
# Secret comes from the environment; never commit it or write it to a log.
API_TOKEN = [REDACTED:env]"BACKUP_TOKEN", "")
ARCHIVE_DIR = "archives"
