Add-Type -AssemblyName System.Speech
$out = '<WORKSPACE>\announcement.wav'
$fmt = New-Object System.Speech.AudioFormat.SpeechAudioFormatInfo(22050, [System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen, [System.Speech.AudioFormat.AudioChannel]::Mono)
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
$s.SelectVoice('Microsoft Hazel Desktop')
$s.Rate = 0
$s.Volume = 100
$text = 'Welcome aboard the evening ferry, please keep your bags clear of the doors.'
$s.SetOutputToWaveFile($out, $fmt)
$s.Speak($text)
$s.Dispose()
Write-Output "wrote $out"
