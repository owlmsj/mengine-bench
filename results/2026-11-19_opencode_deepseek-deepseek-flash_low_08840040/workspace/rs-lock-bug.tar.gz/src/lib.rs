//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        // One guard per read-modify-write: reading into a temporary and
        // writing under a fresh guard drops concurrent awards (lost update).
        *slot.lock().unwrap() += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        // Both slots are the same mutex when from == to; locking it twice
        // deadlocks the match thread, so the documented no-op returns first.
        if from == to {
            return;
        }
        let (from_slot, to_slot) = (self.slot(from), self.slot(to));
        // Lock in a fixed PlayerId order: two matches transferring in
        // opposite directions would otherwise each hold the other's lock.
        let (first, second) = if from < to {
            (from_slot.clone(), to_slot.clone())
        } else {
            (to_slot.clone(), from_slot.clone())
        };
        let mut first_score = first.lock().unwrap();
        let mut second_score = second.lock().unwrap();
        if from < to {
            *first_score -= points;
            *second_score += points;
        } else {
            *second_score -= points;
            *first_score += points;
        }
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::thread;

    #[test]
    fn same_player_transfer_returns() {
        let board = Board::new();
        board.join(1, 10);
        board.transfer(1, 1, 5);
        assert_eq!((board.score(1), board.total()), (10, 10));
    }

    #[test]
    fn concurrent_awards_are_not_lost() {
        let board = Board::new();
        board.join(1, 0);
        let handles: Vec<_> = (0..8)
            .map(|_| {
                let board = board.clone();
                thread::spawn(move || {
                    for _ in 0..10_000 {
                        board.award(1, 1);
                    }
                })
            })
            .collect();
        for handle in handles {
            handle.join().unwrap();
        }
        assert_eq!((board.score(1), board.total()), (80_000, 80_000));
    }

    #[test]
    fn opposite_transfers_do_not_deadlock() {
        let board = Board::new();
        board.join(1, 1_000_000);
        board.join(2, 1_000_000);
        let a = {
            let board = board.clone();
            thread::spawn(move || {
                for _ in 0..10_000 {
                    board.transfer(1, 2, 1);
                }
            })
        };
        let b = {
            let board = board.clone();
            thread::spawn(move || {
                for _ in 0..10_000 {
                    board.transfer(2, 1, 1);
                }
            })
        };
        a.join().unwrap();
        b.join().unwrap();
        assert_eq!(board.score(1) + board.score(2), 2_000_000);
        assert_eq!(board.total(), 2_000_000);
    }
}
