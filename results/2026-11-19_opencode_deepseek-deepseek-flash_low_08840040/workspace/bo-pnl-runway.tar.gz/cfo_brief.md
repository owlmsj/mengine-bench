# H1 2026 close - CFO briefing for the investor meeting

Currency BRL. Source: `finance/ledger.csv`, `finance/chart_of_accounts.csv`, `finance/cash_balance.txt`, rule in `finance/README.md`. Machine-readable figures: `result.json`. Slides: `cfo_deck.html`.

## Headline

- H1 revenue **R$ 1,389,493**, up 36% from January to June, +19% Q1 to Q2.
- Gross margin **70.2%** for the half, stable in a 68-72% band, 72.4% in June.
- H1 EBITDA **-R$ 1,218,969** (-87.7% of revenue), but improving every quarter: monthly EBITDA went from -210,279 in January to -192,968 in June.
- Burn **R$ 197,288/month** (average negative EBITDA of Apr, May, Jun, per the board's rule).
- Cash on 30 June **R$ 1,847,350.40**, so **9.36 months of runway**, roughly into early April 2027 at the current run-rate.

## Month by month

| Month | Revenue | Gross profit | GM % | EBITDA | EBITDA % |
|---|---:|---:|---:|---:|---:|
| Jan 2026 | 200,510.87 | 140,418.95 | 70.0% | -210,278.96 | -104.9% |
| Feb 2026 | 216,328.06 | 152,049.35 | 70.3% | -212,300.08 | -98.1% |
| Mar 2026 | 219,066.17 | 149,970.12 | 68.5% | -204,525.45 | -93.4% |
| Apr 2026 | 238,163.26 | 167,295.53 | 70.2% | -196,950.65 | -82.7% |
| May 2026 | 243,032.89 | 169,059.76 | 69.6% | -201,945.82 | -83.1% |
| Jun 2026 | 272,391.57 | 197,228.88 | 72.4% | -192,968.22 | -70.8% |

Net result for the half: -R$ 1,179,354 including a +R$ 41,615 financial result (investment income less interest/IOF).

## Method and assumptions

- Dates are dd/mm/yyyy, as written in the ledger.
- Amounts are pt-BR (`-56.661,03` = -56661.03).
- Costs are stored as negatives; gross profit and EBITDA add them to revenue.
- Refunds (3.1.09) are contra-revenue. June has no refund entry, unlike March and May.
- EBITDA excludes financial lines 6.1.01/6.1.02; they are in the net result only.
- Burn uses Apr-Jun, the last three closed months, and runway uses the 30 June balance, the latest close.
- Runway is a static run-rate, not a forecast: no revenue growth, cost inflation, capex, debt or tax payments are modelled.

## Caveats to raise before presenting

1. **Cash does not reconcile to P&L.** H1 net loss is R$ 1,179,354 but cash fell only R$ 461,838 from 31 May to 30 June alone (and the ledger does not carry an opening balance). Working capital, capex and financing are outside this ledger. If the June cash outflow repeats, real runway is nearer 4 months than 9. Get the cash-flow statement before quoting 9.4 unchallenged.
2. Management accounts, unaudited; June refunds may be missing.
3. No customer, churn, headcount or pipeline data in the folder, so no forward-looking claims beyond the run-rate.

## One-line close

"Revenue up 36% in the half, gross margin steady above 70%, monthly loss down 8% since January, and nine months of cash at the current burn - with the open item that cash is leaving faster than the P&L implies."
