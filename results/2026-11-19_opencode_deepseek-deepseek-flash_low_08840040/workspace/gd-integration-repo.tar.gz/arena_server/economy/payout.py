"""Match payout. Rules live in docs/ECONOMY.md."""

from decimal import ROUND_HALF_UP, Decimal


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    # Decimal avoids binary-float error that can turn an exact half (1425) down.
    raw = (Decimal(str(base)) + Decimal(str(kills)) * Decimal(str(cfg["kill_bonus"]))) \
        * Decimal(str(cfg["event_multiplier"]))
    return int((raw / 10).quantize(Decimal("1"), rounding=ROUND_HALF_UP) * 10)
