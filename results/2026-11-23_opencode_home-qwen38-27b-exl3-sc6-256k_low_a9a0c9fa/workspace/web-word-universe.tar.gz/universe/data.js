const DATA = {
  "alfaiate": [
    "sapateiro",
    "padeiro",
    "boca",
    "emprego",
    "profissao",
    "susto",
    "acougueiro"
  ],
  "amanhã": [
    "hoje",
    "eternidade",
    "hoje",
    "hora",
    "perna",
    "porta"
  ],
  "angústia": [
    "dor",
    "aflicao",
    "compaixao",
    "riacho",
    "medo",
    "afeto"
  ],
  "cabeça": [
    "corpo",
    "rosto",
    "m%C3%A3o",
    "enfermeira"
  ],
  "café": [
    "pimenta",
    "cha",
    "momento",
    "agua",
    "trabalho"
  ],
  "carinho": [
    "afeto",
    "ternura",
    "melancolia",
    "compaixao",
    "saudades",
    "esperanca"
  ],
  "carne": [
    "mandioca",
    "peixe",
    "filho",
    "arroz",
    "Nacao",
    "ovo",
    "salario"
  ],
  "cena": [
    "teatro",
    "ator",
    "melodia",
    "cancao",
    "ponte",
    "livro"
  ],
  "contentamento": [
    "felicidade",
    "prazer",
    "prazer",
    "pais"
  ],
  "dedo": [
    "m%C3%A3o",
    "unha",
    "pe",
    "unha",
    "sapateiro"
  ],
  "dente": [
    "l%C3%ADngua",
    "pescoco",
    "pulm%C3%A3o",
    "hoje"
  ],
  "desenho": [
    "tela",
    "escultura",
    "noite",
    "danca",
    "prima"
  ],
  "dicionário": [
    "significado",
    "sinonimo",
    "voz",
    "arte"
  ],
  "época": [
    "momento",
    "era",
    "era",
    "enfermeira",
    "leite"
  ],
  "estômago": [
    "pulm%C3%A3o",
    "figado",
    "l%C3%ADngua",
    "irmao"
  ],
  "fala": [
    "voz",
    "conversa",
    "acento",
    "advogado"
  ],
  "filha": [
    "filho",
    "irmao",
    "parentesco",
    "tia",
    "manteiga",
    "primo",
    "nora"
  ],
  "floresta": [
    "natureza",
    "mata",
    "mar",
    "medo",
    "tempo"
  ],
  "folha": [
    "raiz",
    "flor",
    "tio",
    "semente",
    "conto",
    "silencio"
  ],
  "hora": [
    "tempo",
    "minuto",
    "Epoca",
    "advogado"
  ],
  "idioma": [
    "palavra",
    "linguagem",
    "madrinha",
    "apelido",
    "cancao",
    "giria"
  ],
  "jardim": [
    "fruto",
    "campo",
    "petala",
    "escultura",
    "montanha",
    "praia"
  ],
  "juiz": [
    "advogado",
    "soldado",
    "porto",
    "patr%C3%A3o",
    "advogado",
    "engenheiro",
    "m%C3%A3o"
  ],
  "madrugada": [
    "noite",
    "aurora",
    "manha",
    "nome",
    "eternidade",
    "passado",
    "vila",
    "arroz",
    "medico"
  ],
  "manteiga": [
    "leite",
    "acucar",
    "milho",
    "queijo",
    "almoco",
    "ansiedade"
  ],
  "mar": [
    "lago",
    "onda",
    "flor",
    "vale",
    "lago",
    "medo"
  ],
  "mercado": [
    "esta%C3%A7%C3%A3o",
    "igreja",
    "mata",
    "porta",
    "emprego",
    "igreja"
  ],
  "música": [
    "arte",
    "cancao",
    "ano",
    "verso",
    "nora",
    "samba",
    "pintura"
  ],
  "nação": [
    "pa%C3%ADs",
    "patria",
    "rua",
    "instante",
    "vila"
  ],
  "neto": [
    "av%C3%B3",
    "neta",
    "mae",
    "filho",
    "romance",
    "silaba"
  ],
  "nome": [
    "sussurro",
    "apelido",
    "madrugada",
    "voz",
    "ritmo"
  ],
  "nora": [
    "genro",
    "padrinho",
    "fam%C3%ADlia",
    "filha",
    "peixe",
    "patr%C3%A3o",
    "Musica"
  ],
  "nostalgia": [
    "saudades",
    "melancolia",
    "esperanca",
    "silaba",
    "magoa"
  ],
  "ofício": [
    "trabalho",
    "profissao",
    "areia",
    "padeiro",
    "livro",
    "lavrador"
  ],
  "operário": [
    "patr%C3%A3o",
    "pedreiro",
    "passado",
    "profissao",
    "lavrador",
    "igreja",
    "soldado"
  ],
  "parentesco": [
    "fam%C3%ADlia",
    "pais",
    "filha",
    "medico"
  ],
  "pastor": [
    "lavrador",
    "medico",
    "ferreiro",
    "profissao",
    "mel"
  ],
  "pergunta": [
    "acento",
    "resposta",
    "grito",
    "olho"
  ],
  "perna": [
    "sangue",
    "joelho",
    "joelho",
    "Amanha"
  ],
  "praça": [
    "avenida",
    "esquina",
    "ternura",
    "patria",
    "vale",
    "lar"
  ],
  "prima": [
    "primo",
    "sobrinho",
    "heranca",
    "cidade"
  ],
  "quarto": [
    "lar",
    "cozinha",
    "avenida",
    "neta"
  ],
  "refeição": [
    "comida",
    "almoco",
    "milho",
    "bairro",
    "agua",
    "fotografia"
  ],
  "romance": [
    "rima",
    "conto",
    "natureza",
    "teatro",
    "arte",
    "sotaque"
  ],
  "semana": [
    "m%C3%AAs",
    "dia",
    "futuro",
    "av%C3%B4"
  ],
  "susto": [
    "pavor",
    "espanto",
    "amor",
    "petala",
    "esta%C3%A7%C3%A3o",
    "alfaiate",
    "tempo"
  ],
  "trigo": [
    "farinha",
    "arroz",
    "milho",
    "unha"
  ],
  "vale": [
    "serra",
    "rio",
    "raiz",
    "mar",
    "ponte"
  ],
  "vila": [
    "capital",
    "aldeia",
    "Nacao",
    "madrugada",
    "porto",
    "carpinteiro"
  ],
  "violão": [
    "samba",
    "piano",
    "pa%C3%ADs",
    "enfermeira",
    "rima",
    "Praca",
    "poesia",
    "escultura"
  ],
  "acento": [
    "silaba",
    "pergunta",
    "fala",
    "sotaque",
    "prazer"
  ],
  "açougueiro": [
    "padeiro",
    "pescador",
    "tarde",
    "alfaiate",
    "boca"
  ],
  "açúcar": [
    "manteiga",
    "mel",
    "pimenta",
    "unha",
    "tempo"
  ],
  "advogado": [
    "professor",
    "juiz",
    "cachoeira",
    "hora",
    "coracoes",
    "juiz",
    "eternidade",
    "fala",
    "palavra"
  ],
  "afeto": [
    "amor",
    "carinho",
    "Angustia",
    "voz"
  ],
  "aflição": [
    "Angustia",
    "ansiedade",
    "felicidade",
    "escultura",
    "ansiedade",
    "pavor",
    "agua"
  ],
  "água": [
    "vinho",
    "comida",
    "ombro",
    "Cafe",
    "Refeicao",
    "aflicao",
    "professor"
  ],
  "aldeia": [
    "vila",
    "bairro",
    "capital",
    "trabalho"
  ],
  "alegria": [
    "surpresa",
    "felicidade",
    "ternura",
    "queijo"
  ],
  "alma": [
    "pe",
    "corpo",
    "amor",
    "dente",
    "giria",
    "patria"
  ],
  "almoço": [
    "Refeicao",
    "jantar",
    "carne",
    "patr%C3%A3o",
    "pimenta",
    "frase"
  ],
  "amor": [
    "paixoes",
    "afeto",
    "susto",
    "tristeza",
    "alma",
    "arvore"
  ],
  "ano": [
    "seculo",
    "m%C3%AAs",
    "crepusculo",
    "Musica"
  ],
  "ansiedade": [
    "aflicao",
    "medo",
    "aflicao",
    "rua",
    "paixoes",
    "manteiga"
  ],
  "apelido": [
    "nome",
    "letra",
    "idioma",
    "acento",
    "irma"
  ],
  "areia": [
    "praia",
    "natureza",
    "montanha",
    "Oficio",
    "rima"
  ],
  "arroz": [
    "trigo",
    "feijao",
    "cha",
    "madrugada",
    "feijao"
  ],
  "arte": [
    "fotografia",
    "Musica",
    "samba",
    "cachoeira",
    "romance",
    "rascunho-3"
  ],
  "árvore": [
    "selva",
    "raiz",
    "mata",
    "amor",
    "serra",
    "mandioca"
  ],
  "ator": [
    "cena",
    "poesia",
    "cancao",
    "primo"
  ],
  "aurora": [
    "madrugada",
    "crepusculo",
    "prazer",
    "instante",
    "professor"
  ],
  "avenida": [
    "rua",
    "Praca",
    "casa",
    "feijao",
    "quarto"
  ],
  "avó": [
    "av%C3%B4",
    "neto",
    "mae",
    "idioma",
    "genro"
  ],
  "avô": [
    "irma",
    "av%C3%B3",
    "pais",
    "coracoes",
    "semana"
  ],
  "bairro": [
    "aldeia",
    "rua",
    "rua",
    "igreja",
    "porta",
    "Refeicao"
  ],
  "boca": [
    "olho",
    "l%C3%ADngua",
    "rosto",
    "ombro",
    "alfaiate",
    "acougueiro",
    "livro"
  ],
  "braço": [
    "ombro",
    "m%C3%A3o",
    "surpresa",
    "l%C3%ADngua",
    "janela"
  ],
  "cachoeira": [
    "riacho",
    "lago",
    "petala",
    "semente",
    "advogado",
    "linguagem"
  ],
  "campo": [
    "jardim",
    "prado",
    "selva",
    "onda",
    "ponte",
    "milho"
  ],
  "canção": [
    "Musica",
    "melodia",
    "tela",
    "pai",
    "cena",
    "ator",
    "idioma"
  ],
  "capital": [
    "cidade",
    "vila",
    "esta%C3%A7%C3%A3o",
    "riacho",
    "aldeia",
    "voz",
    "tempo"
  ],
  "carpinteiro": [
    "pedreiro",
    "ferreiro",
    "trabalho",
    "patr%C3%A3o",
    "vila"
  ],
  "casa": [
    "escola",
    "lar",
    "avenida",
    "igreja",
    "poesia"
  ],
  "chá": [
    "Cafe",
    "vinho",
    "peixe",
    "queijo",
    "dente"
  ],
  "cidade": [
    "estado",
    "capital",
    "prima",
    "esta%C3%A7%C3%A3o",
    "jardim"
  ],
  "cinema": [
    "escultura",
    "fotografia",
    "tela",
    "fotografia",
    "pergunta"
  ],
  "comida": [
    "agua",
    "Refeicao",
    "peito",
    "farinha",
    "historia"
  ],
  "compaixão": [
    "ternura",
    "esperanca",
    "Angustia",
    "carinho",
    "contentamento",
    "silaba",
    "ovo"
  ],
  "conto": [
    "romance",
    "livro",
    "folha",
    "lar",
    "verso",
    "heranca",
    "palavra"
  ],
  "conversa": [
    "fala",
    "silencio",
    "grito",
    "felicidade"
  ],
  "coração": [
    "peito",
    "pulm%C3%A3o",
    "av%C3%B4",
    "rosto",
    "advogado",
    "joelho",
    "jantar"
  ],
  "corpo": [
    "alma",
    "Cabeca",
    "Cabeca",
    "peixe",
    "pescoco"
  ],
  "cozinha": [
    "quarto",
    "janela",
    "pai",
    "figado",
    "capital",
    "voz"
  ],
  "crepúsculo": [
    "aurora",
    "ontem",
    "cunhado",
    "segundo",
    "ano",
    "Epoca",
    "giria",
    "hoje"
  ],
  "cunhado": [
    "sobrinho",
    "sogra",
    "pais",
    "crepusculo"
  ],
  "dança": [
    "tambor",
    "teatro",
    "piano",
    "rima",
    "voz",
    "desenho"
  ],
  "dia": [
    "semana",
    "manha",
    "tarde",
    "casa",
    "letra"
  ],
  "dor": [
    "magoa",
    "Angustia",
    "saudades",
    "almoco"
  ],
  "emprego": [
    "profissao",
    "salario",
    "esperanca",
    "eternidade",
    "mercado",
    "alfaiate",
    "jantar"
  ],
  "enfermeira": [
    "medico",
    "professor",
    "Epoca",
    "acougueiro",
    "Violao"
  ],
  "engenheiro": [
    "marinheiro",
    "trabalho",
    "irmao",
    "juiz",
    "lavrador",
    "ternura"
  ],
  "era": [
    "Epoca",
    "seculo",
    "Epoca",
    "m%C3%AAs",
    "teatro",
    "seculo",
    "palavra"
  ],
  "escola": [
    "igreja",
    "casa",
    "esquina",
    "esperanca"
  ],
  "escultura": [
    "desenho",
    "cinema",
    "jardim",
    "olho",
    "Violao",
    "sobrinho"
  ],
  "espanto": [
    "susto",
    "surpresa",
    "esperanca",
    "pa%C3%ADs",
    "surpresa"
  ],
  "esperança": [
    "compaixao",
    "saudades",
    "nostalgia",
    "espanto",
    "carinho",
    "emprego",
    "escola"
  ],
  "esquina": [
    "Praca",
    "ponte",
    "cozinha",
    "pescador",
    "escola"
  ],
  "estado": [
    "patria",
    "cidade",
    "m%C3%A3o",
    "Praca",
    "medico",
    "poesia"
  ],
  "estação": [
    "porto",
    "mercado",
    "tia",
    "cidade",
    "capital",
    "mercado",
    "susto"
  ],
  "eternidade": [
    "Amanha",
    "passado",
    "instante",
    "madrugada",
    "emprego",
    "peixe",
    "advogado"
  ],
  "família": [
    "heranca",
    "parentesco",
    "nora",
    "susto"
  ],
  "farinha": [
    "pao",
    "trigo",
    "vinho",
    "pescador"
  ],
  "feijão": [
    "arroz",
    "milho",
    "avenida",
    "arroz",
    "mandioca",
    "vinho",
    "palavra"
  ],
  "felicidade": [
    "alegria",
    "contentamento",
    "aflicao",
    "compaixao",
    "trigo",
    "conversa"
  ],
  "ferreiro": [
    "carpinteiro",
    "sapateiro",
    "segundo",
    "pastor",
    "onda",
    "sapateiro"
  ],
  "fígado": [
    "Estomago",
    "pele",
    "futuro",
    "alma",
    "cozinha"
  ],
  "filho": [
    "pai",
    "filha",
    "genro",
    "carne"
  ],
  "flor": [
    "folha",
    "petala",
    "mar",
    "samba",
    "semente"
  ],
  "fotografia": [
    "cinema",
    "arte",
    "soldado",
    "rima",
    "teatro",
    "Refeicao"
  ],
  "frase": [
    "linguagem",
    "sentido",
    "tristeza",
    "letra",
    "almoco",
    "giria",
    "sussurro"
  ],
  "fruto": [
    "semente",
    "jardim",
    "natureza",
    "piano"
  ],
  "futuro": [
    "passado",
    "tempo",
    "minuto",
    "seculo",
    "figado"
  ],
  "genro": [
    "sogra",
    "nora",
    "madrinha",
    "av%C3%B3"
  ],
  "gíria": [
    "sinonimo",
    "sotaque",
    "crepusculo",
    "alma",
    "frase",
    "idioma",
    "sotaque"
  ],
  "grito": [
    "silencio",
    "sussurro",
    "conversa",
    "silencio",
    "sobrinho",
    "pergunta"
  ],
  "herança": [
    "madrinha",
    "fam%C3%ADlia",
    "tio",
    "neta",
    "sinonimo",
    "pimenta",
    "marinheiro",
    "conto"
  ],
  "história": [
    "resposta",
    "memoria",
    "comida",
    "apelido",
    "surpresa",
    "tempo"
  ],
  "hoje": [
    "ontem",
    "Amanha",
    "crepusculo",
    "tristeza",
    "Amanha",
    "dente"
  ],
  "igreja": [
    "mercado",
    "escola",
    "bairro",
    "mercado",
    "Operario"
  ],
  "instante": [
    "segundo",
    "momento",
    "eternidade",
    "almoco",
    "aurora"
  ],
  "irmã": [
    "irmao",
    "av%C3%B4",
    "tia",
    "pintura",
    "sal",
    "apelido"
  ],
  "irmão": [
    "filha",
    "irma",
    "pais",
    "tia",
    "engenheiro",
    "ponte"
  ],
  "janela": [
    "cozinha",
    "porta",
    "braco",
    "igreja",
    "Nacao",
    "profissao"
  ],
  "jantar": [
    "almoco",
    "pao",
    "mel",
    "coracoes",
    "emprego"
  ],
  "joelho": [
    "perna",
    "pe",
    "perna",
    "coracoes",
    "pedreiro",
    "tambor"
  ],
  "lago": [
    "cachoeira",
    "mar",
    "natureza",
    "acento",
    "mar"
  ],
  "lar": [
    "casa",
    "quarto",
    "rua",
    "ponte",
    "Praca",
    "conto"
  ],
  "lavrador": [
    "pescador",
    "pastor",
    "padeiro",
    "Oficio",
    "selva",
    "engenheiro"
  ],
  "leite": [
    "queijo",
    "manteiga",
    "pele",
    "pao",
    "mandioca",
    "Epoca"
  ],
  "letra": [
    "apelido",
    "silaba",
    "significado",
    "dia"
  ],
  "linguagem": [
    "idioma",
    "frase",
    "riacho",
    "grito",
    "cachoeira"
  ],
  "livro": [
    "conto",
    "pintura",
    "cena",
    "boca"
  ],
  "língua": [
    "boca",
    "dente",
    "osso",
    "tarde"
  ],
  "madrinha": [
    "padrinho",
    "heranca",
    "genro",
    "neta",
    "idioma"
  ],
  "mãe": [
    "pais",
    "pai",
    "neto",
    "cena",
    "av%C3%B3"
  ],
  "mágoa": [
    "tristeza",
    "dor",
    "melancolia",
    "nostalgia"
  ],
  "mandioca": [
    "milho",
    "carne",
    "feijao",
    "pimenta",
    "arvore",
    "leite",
    "sentido",
    "em-construcao"
  ],
  "manhã": [
    "dia",
    "tarde",
    "ano",
    "profissao"
  ],
  "marinheiro": [
    "soldado",
    "engenheiro",
    "pedreiro",
    "medico",
    "advogado",
    "heranca"
  ],
  "mata": [
    "floresta",
    "selva",
    "fruto",
    "mercado",
    "arvore"
  ],
  "médico": [
    "pastor",
    "enfermeira",
    "estado",
    "marinheiro",
    "madrugada"
  ],
  "medo": [
    "ansiedade",
    "pavor",
    "Angustia",
    "pavor",
    "ternura"
  ],
  "mel": [
    "acucar",
    "sal",
    "jantar",
    "pimenta",
    "melancolia"
  ],
  "melancolia": [
    "nostalgia",
    "tristeza",
    "carinho",
    "medico",
    "magoa"
  ],
  "melodia": [
    "cancao",
    "ritmo",
    "piano",
    "cena",
    "verso"
  ],
  "memória": [
    "historia",
    "palavra",
    "silaba",
    "alma"
  ],
  "milho": [
    "feijao",
    "mandioca",
    "Refeicao",
    "trigo",
    "manteiga",
    "campo",
    "tela"
  ],
  "minuto": [
    "hora",
    "segundo",
    "futuro",
    "tambor",
    "noite"
  ],
  "momento": [
    "instante",
    "Epoca",
    "noite",
    "Cafe",
    "link-antigo"
  ],
  "montanha": [
    "prado",
    "serra",
    "prado",
    "jardim",
    "lavrador",
    "areia"
  ],
  "mão": [
    "braco",
    "dedo",
    "pele",
    "estado"
  ],
  "mês": [
    "ano",
    "semana",
    "era",
    "momento",
    "ferreiro",
    "sinonimo"
  ],
  "natureza": [
    "areia",
    "floresta",
    "raiz",
    "romance"
  ],
  "neta": [
    "neto",
    "tio",
    "pais",
    "arroz",
    "madrinha",
    "quarto"
  ],
  "noite": [
    "tarde",
    "madrugada",
    "momento",
    "tarde",
    "minuto",
    "desenho"
  ],
  "olho": [
    "rosto",
    "boca",
    "pulm%C3%A3o",
    "escultura"
  ],
  "ombro": [
    "pescoco",
    "braco",
    "boca",
    "agua"
  ],
  "onda": [
    "mar",
    "praia",
    "campo",
    "riacho",
    "prado",
    "ferreiro",
    "tempo"
  ],
  "ontem": [
    "crepusculo",
    "hoje",
    "crepusculo",
    "pavor"
  ],
  "osso": [
    "pele",
    "sangue",
    "l%C3%ADngua",
    "pescoco",
    "farinha"
  ],
  "ovo": [
    "peixe",
    "queijo",
    "carne",
    "compaixao",
    "palavra"
  ],
  "padeiro": [
    "alfaiate",
    "acougueiro",
    "Oficio",
    "lavrador",
    "capital"
  ],
  "padrinho": [
    "nora",
    "madrinha",
    "tio",
    "sotaque"
  ],
  "pai": [
    "mae",
    "filho",
    "av%C3%B3",
    "cozinha",
    "cancao"
  ],
  "pais": [
    "parentesco",
    "mae",
    "contentamento",
    "irmao",
    "pavor",
    "neta",
    "tia"
  ],
  "paixão": [
    "prazer",
    "amor",
    "ansiedade",
    "conto",
    "unha"
  ],
  "palavra": [
    "memoria",
    "idioma",
    "magoa",
    "professor",
    "Cabeca",
    "tia",
    "patr%C3%A3o",
    "dedo",
    "era",
    "advogado",
    "conto",
    "ovo",
    "alma",
    "montanha",
    "pintura",
    "feijao"
  ],
  "pão": [
    "jantar",
    "farinha",
    "leite",
    "verso"
  ],
  "passado": [
    "eternidade",
    "futuro",
    "madrugada",
    "Operario"
  ],
  "pátria": [
    "Nacao",
    "estado",
    "porto",
    "alma",
    "Praca",
    "tempo"
  ],
  "patrão": [
    "salario",
    "Operario",
    "almoco",
    "juiz",
    "nora",
    "carpinteiro",
    "palavra"
  ],
  "pavor": [
    "medo",
    "susto",
    "medo",
    "melancolia",
    "aflicao",
    "pais",
    "ontem",
    "ritmo"
  ],
  "país": [
    "porta",
    "Nacao",
    "espanto",
    "cidade",
    "Violao"
  ],
  "pé": [
    "joelho",
    "alma",
    "rosto",
    "tela"
  ],
  "pedreiro": [
    "Operario",
    "carpinteiro",
    "joelho",
    "marinheiro",
    "osso"
  ],
  "peito": [
    "unha",
    "coracoes",
    "pulm%C3%A3o",
    "comida"
  ],
  "peixe": [
    "carne",
    "ovo",
    "nora",
    "cha",
    "eternidade"
  ],
  "pele": [
    "figado",
    "osso",
    "m%C3%A3o",
    "pulm%C3%A3o",
    "leite"
  ],
  "pescador": [
    "acougueiro",
    "lavrador",
    "pedreiro",
    "Amanha",
    "verso"
  ],
  "pescoço": [
    "dente",
    "ombro",
    "corpo",
    "av%C3%B4",
    "sangue"
  ],
  "pétala": [
    "flor",
    "semente",
    "susto",
    "cachoeira",
    "mar"
  ],
  "piano": [
    "Violao",
    "tambor",
    "sobrinho",
    "fruto",
    "melodia",
    "danca",
    "prado"
  ],
  "pimenta": [
    "sal",
    "Cafe",
    "mandioca",
    "acucar",
    "mel",
    "sal",
    "almoco",
    "heranca"
  ],
  "pintura": [
    "livro",
    "tela",
    "irma",
    "Musica",
    "janela",
    "palavra"
  ],
  "poesia": [
    "ator",
    "verso",
    "casa",
    "Violao",
    "estado"
  ],
  "ponte": [
    "esquina",
    "porto",
    "campo",
    "vale",
    "lar",
    "irmao"
  ],
  "porta": [
    "janela",
    "pa%C3%ADs",
    "bairro",
    "Amanha"
  ],
  "porto": [
    "ponte",
    "esta%C3%A7%C3%A3o",
    "patria",
    "vila",
    "juiz"
  ],
  "prado": [
    "campo",
    "montanha",
    "montanha",
    "carinho",
    "onda",
    "piano"
  ],
  "praia": [
    "onda",
    "areia",
    "rio",
    "jardim",
    "pescador"
  ],
  "prazer": [
    "contentamento",
    "paixoes",
    "contentamento",
    "ternura",
    "aurora",
    "acento"
  ],
  "primo": [
    "tia",
    "prima",
    "filha",
    "professor",
    "sobrinho",
    "ator",
    "pagina-removida"
  ],
  "professor": [
    "enfermeira",
    "advogado",
    "primo",
    "salario",
    "sapateiro",
    "agua",
    "palavra"
  ],
  "profissão": [
    "Oficio",
    "emprego",
    "serra",
    "Operario",
    "janela",
    "alfaiate"
  ],
  "pulmão": [
    "coracoes",
    "Estomago",
    "olho",
    "unha",
    "peito",
    "pescoco",
    "av%C3%B4",
    "pele"
  ],
  "queijo": [
    "ovo",
    "leite",
    "alegria",
    "manteiga",
    "poesia",
    "cha"
  ],
  "raiz": [
    "arvore",
    "folha",
    "natureza",
    "serra",
    "vale"
  ],
  "resposta": [
    "pergunta",
    "historia",
    "letra",
    "semana"
  ],
  "riacho": [
    "rio",
    "cachoeira",
    "Angustia",
    "onda",
    "linguagem",
    "capital"
  ],
  "rima": [
    "verso",
    "romance",
    "Violao",
    "fotografia",
    "areia",
    "significado"
  ],
  "rio": [
    "vale",
    "riacho",
    "praia",
    "pedreiro"
  ],
  "ritmo": [
    "melodia",
    "samba",
    "teatro",
    "pavor",
    "nome"
  ],
  "rosto": [
    "Cabeca",
    "olho",
    "boca",
    "nora",
    "pe"
  ],
  "rua": [
    "bairro",
    "avenida",
    "Nacao",
    "bairro",
    "lar",
    "alfaiate"
  ],
  "sal": [
    "mel",
    "pimenta",
    "pimenta",
    "irma"
  ],
  "salário": [
    "emprego",
    "patr%C3%A3o",
    "professor",
    "carne"
  ],
  "samba": [
    "ritmo",
    "Violao",
    "flor",
    "arte",
    "romance",
    "Musica"
  ],
  "sangue": [
    "osso",
    "perna",
    "pescoco",
    "sentido",
    "xpto-2"
  ],
  "sapateiro": [
    "ferreiro",
    "alfaiate",
    "ferreiro",
    "dedo",
    "professor"
  ],
  "saudade": [
    "esperanca",
    "nostalgia",
    "ansiedade",
    "dor",
    "carinho",
    "rascunho-3"
  ],
  "século": [
    "era",
    "ano",
    "era",
    "minuto"
  ],
  "segundo": [
    "minuto",
    "instante",
    "crepusculo",
    "ferreiro"
  ],
  "selva": [
    "mata",
    "arvore",
    "campo",
    "igreja"
  ],
  "semente": [
    "petala",
    "fruto",
    "folha",
    "flor",
    "mercado",
    "cachoeira"
  ],
  "sentido": [
    "frase",
    "significado",
    "sangue",
    "trabalho",
    "historia",
    "mandioca",
    "significado"
  ],
  "serra": [
    "montanha",
    "vale",
    "arvore",
    "profissao"
  ],
  "significado": [
    "sentido",
    "Dicionario",
    "sentido",
    "rima",
    "letra"
  ],
  "sílaba": [
    "letra",
    "acento",
    "nostalgia",
    "compaixao",
    "frase",
    "neto",
    "memoria"
  ],
  "silêncio": [
    "conversa",
    "grito",
    "sussurro",
    "folha",
    "grito"
  ],
  "sinônimo": [
    "Dicionario",
    "giria",
    "heranca",
    "silaba",
    "m%C3%AAs"
  ],
  "sobrinho": [
    "prima",
    "cunhado",
    "primo",
    "piano",
    "sotaque",
    "grito"
  ],
  "sogra": [
    "cunhado",
    "genro",
    "tia",
    "dente",
    "tempo"
  ],
  "soldado": [
    "juiz",
    "marinheiro",
    "Operario",
    "fotografia"
  ],
  "sotaque": [
    "giria",
    "voz",
    "vinho",
    "giria",
    "sobrinho",
    "acento"
  ],
  "surpresa": [
    "espanto",
    "alegria",
    "espanto",
    "braco",
    "historia"
  ],
  "sussurro": [
    "grito",
    "nome",
    "silencio",
    "frase",
    "folha",
    "pagina-removida"
  ],
  "tambor": [
    "piano",
    "danca",
    "minuto",
    "verso",
    "joelho"
  ],
  "tarde": [
    "manha",
    "noite",
    "dia",
    "noite",
    "acougueiro",
    "l%C3%ADngua"
  ],
  "teatro": [
    "danca",
    "cena",
    "era",
    "ritmo",
    "romance",
    "pai",
    "fotografia",
    "tempo"
  ],
  "tela": [
    "pintura",
    "desenho",
    "pe",
    "cinema",
    "milho"
  ],
  "tempo": [
    "futuro",
    "hora",
    "rua",
    "acucar",
    "tio",
    "historia",
    "patria",
    "susto",
    "idioma",
    "capital",
    "onda",
    "teatro",
    "floresta",
    "pescador",
    "prado",
    "sogra"
  ],
  "ternura": [
    "carinho",
    "compaixao",
    "alegria",
    "medo",
    "Praca",
    "engenheiro"
  ],
  "tia": [
    "tio",
    "primo",
    "filha",
    "irmao",
    "pais",
    "esta%C3%A7%C3%A3o",
    "sogra"
  ],
  "tio": [
    "neta",
    "tia",
    "heranca",
    "folha",
    "tempo"
  ],
  "trabalho": [
    "engenheiro",
    "Oficio",
    "aldeia",
    "carpinteiro",
    "sentido"
  ],
  "tristeza": [
    "melancolia",
    "magoa",
    "amor",
    "frase",
    "hoje"
  ],
  "unha": [
    "dedo",
    "peito",
    "pulm%C3%A3o",
    "paixoes",
    "trigo",
    "acucar"
  ],
  "verso": [
    "poesia",
    "rima",
    "pao",
    "tambor",
    "melodia",
    "pescador"
  ],
  "vinho": [
    "cha",
    "agua",
    "farinha",
    "feijao",
    "sotaque"
  ],
  "voz": [
    "sotaque",
    "fala",
    "afeto",
    "cozinha",
    "nome",
    "capital"
  ]
};