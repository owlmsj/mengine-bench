import re, json, os, unicodedata
from collections import Counter

site = os.path.join(os.path.dirname(__file__), "site")
words = {}   # word -> {"theme":..., "links":[...]}
non_word_pages = {"index.html", "sobre.html", "contato.html"}

def norm(s):
    s = unicodedata.normalize("NFC", s.strip())
    return s

for fn in sorted(os.listdir(site)):
    if not fn.endswith(".html") or fn in non_word_pages:
        continue
    html = open(os.path.join(site, fn), encoding="utf-8").read()
    m = re.search(r"<h1>(.*?)</h1>", html, re.S)
    if not m:
        continue
    word = norm(m.group(1))
    theme_m = re.search(r'class="tema"[^>]*>Tema:\s*(.*?)</p>', html, re.S)
    theme = norm(theme_m.group(1)) if theme_m else ""
    links = []
    for sec in re.findall(r'<section id="(\w+)">(.*?)</section>', html, re.S):
        for href, label in re.findall(r'<a href="([^"]+\.html)">([^<]*)</a>', sec[1]):
            if href in non_word_pages or href == fn:
                continue
            target = os.path.splitext(href)[0]
            # resolve to actual word label if page exists, else use label
            links.append(target)
    words[word] = {"theme": theme, "links": links}

# Build mapping word -> words it is linked to (use the target page's h1 word when available)
mapping = {}
for w, info in words.items():
    targets = []
    for t in info["links"]:
        # find word whose filename stem matches t (case-insensitive)
        found = None
        for w2 in words:
            if w2.lower().replace(" ", "") == t.lower().replace(" ", ""):
                found = w2
                break
        targets.append(found if found else t)
    mapping[w] = targets

json.dump(mapping, open("words.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)

# distinct pairs (undirected, dedup)
pairs = set()
for w, targets in mapping.items():
    for t in targets:
        a, b = sorted([w, t])
        pairs.add((a, b))

deg = Counter()
for a, b in pairs:
    deg[a] += 1
    deg[b] += 1

most = deg.most_common()
top = most[0] if most else (None, 0)
result = {
    "words": len(mapping),
    "relations": len(pairs),
    "most_connected": {"word": top[0], "degree": top[1]},
}
json.dump(result, open("result.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("words:", len(mapping), "pairs:", len(pairs))
print("top:", most[:8])