import csv, re, json

base = r"<WORKSPACE>\backoffice"

invoices = {}
with open(base + r"\invoices.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = float(row["amount"])

payments = {}  # id -> list of amounts
with open(base + r"\bank_statement_june.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        m = re.search(r"(?:INV|inv|invoice|INV-)\s*0*(\d{4})", memo)
        if not m:
            continue  # fees, interest, unidentified
        inv_id = "INV-" + m.group(1)
        if inv_id not in invoices:
            continue
        payments.setdefault(inv_id, []).append(float(row["amount"]))

unpaid, duplicated, mismatched = [], [], []
for inv_id, amt in invoices.items():
    pays = payments.get(inv_id, [])
    if not pays:
        unpaid.append(inv_id)
    elif len(pays) > 1:
        duplicated.append(inv_id)
    elif len(pays) == 1 and abs(pays[0] - amt) > 0.005:
        mismatched.append({"id": inv_id, "invoiced": amt, "paid": pays[0]})

unpaid.sort(); duplicated.sort()
mismatched.sort(key=lambda x: x["id"])
result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
out = r"<WORKSPACE>\result.json"
with open(out, "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))