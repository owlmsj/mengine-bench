# Handoff: local-9b Q5 @ 128k

Done:
- Baseline (measure_decode.ps1 -Ctx 131072 -NPredict 1024): 37.8 t/s, VRAM 7881 MiB.
- 7881 MiB = WDDM ceiling; Shared Usage showed 1494 MiB spilled (unreliable).
- Fix: --no-mmproj-offload + -ub 512 removes spill: 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k; discarded. Q4_K_M fits (7305 MiB, 40.4 t/s), fallback only.
- Recipe applied in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

Left:
- evals README still cites check_vision.ps1 (file gone). Update it.
- Review scratchpad temp file names (noted many times, never done).

Assumptions:
- Fix is accepted config; no re-measure. Q5 chosen; Q4_K_M fallback only.
- Rest of transcript is noise.

Found / why right:
- Numbers quoted verbatim from session/transcript.md (lines 30, 44, 124, 132, 185, 222).
- "What is left?" answered by README item (line 222); scratchpad note recurs (lines 55, 67, 79, 91, 158, 161, 190, 216) and was never closed.