import csv, json, math

path = r"<WORKSPACE>\telemetry\playtest_ab.csv"

sessions = {}  # session_id -> (variant, completed)
dup_rows = 0
bad_variant = 0
with open(path, newline="", encoding="utf-8") as f:
    r = csv.DictReader(f)
    for row in r:
        sid = row["session_id"].strip()
        v = row["variant"].strip().lower()
        comp = int(row["completed_tutorial"])
        if v not in ("a", "b"):
            bad_variant += 1
            continue
        if sid in sessions:
            dup_rows += 1
            # ETL resend: same session, keep first (data should be identical; verify)
            if sessions[sid] != (v, comp):
                print(f"CONFLICT {sid}: {sessions[sid]} vs {(v, comp)}")
            continue
        sessions[sid] = (v, comp)

a = [c for v, c in sessions.values() if v == "a"]
b = [c for v, c in sessions.values() if v == "b"]
na, nb = len(a), len(b)
ca, cb = sum(a), sum(b)
pa, pb = ca / na, cb / nb

print(f"total rows: {na + nb + dup_rows}, unique sessions: {len(sessions)}, dup rows skipped: {dup_rows}, bad variant: {bad_variant}")
print(f"A: n={na} completed={ca} rate={pa:.6f}")
print(f"B: n={nb} completed={cb} rate={pb:.6f}")

# two-proportion z-test, H1: B > A (one-sided) and two-sided p
p_pool = (ca + cb) / (na + nb)
se = math.sqrt(p_pool * (1 - p_pool) * (1 / na + 1 / nb))
z = (pb - pa) / se
# one-sided p (B better)
p_one = 1 - 0.5 * (1 + math.erf(z / math.sqrt(2)))
p_two = 2 * p_one
print(f"z={z:.6f} p_one(B>A)={p_one:.6f} p_two={p_two:.6f}")

# continuity-corrected (Hartigan) for robustness
p_pool_cc = (ca + cb) / (na + nb)
se_cc = math.sqrt(p_pool_cc * (1 - p_pool_cc) * (1 / na + 1 / nb))
z_cc = (abs(pb - pa) - 0.5 * (1 / na + 1 / nb)) / se_cc
p_two_cc = 2 * (1 - 0.5 * (1 + math.erf(abs(z_cc) / math.sqrt(2))))
print(f"z_cc={z_cc:.6f} p_two_cc={p_two_cc:.6f}")

result = {
    "ship_b": bool(p_one < 0.05),
    "sessions_a": na,
    "sessions_b": nb,
    "completion_rate_a": round(pa, 4),
    "completion_rate_b": round(pb, 4),
    "p_value": round(p_one, 6),
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))