from datetime import date

ipca = {1985: 242.23, 1986: 79.66, 1987: 363.41, 1988: 980.22, 1989: 1972.91,
        1990: 1620.97, 1991: 472.70, 1992: 1119.10, 1993: 2477.15, 1994: 916.46, 1995: 22.41}

plans = [
    ("Cruzado", date(1986, 2, 28), date(1987, 6, 12)),
    ("Bresser", date(1987, 6, 12), date(1989, 1, 15)),
    ("Verao", date(1989, 1, 15), date(1990, 3, 16)),
    ("Collor I", date(1990, 3, 16), date(1991, 1, 31)),
    ("Collor II", date(1991, 1, 31), date(1994, 2, 27)),
    ("Real", date(1994, 2, 27), None),
]

def months(d1, d2):
    return (d2.year - d1.year) * 12 + (d2.month - d1.month) - (1 if d2.day < d1.day else 0)

rows = []
for name, launch, nxt in plans:
    y = launch.year
    before = ipca[y - 1]
    after = ipca[y + 1]
    drop = max(0.0, min(1.0, 1 - after / before))
    if nxt is None:
        m = 60
    else:
        m = months(launch, nxt)
    dur = min(m, 60) / 60
    score = 0.7 * drop + 0.3 * dur
    rows.append((name, y, before, after, m, drop, dur, score))
    print(f"{name}: before={before} after={after} months={m} drop={drop:.4f} dur={dur:.4f} score={score:.4f}")

rows_sorted = sorted(rows, key=lambda r: -r[7])
print("TOP3:", [r[0] for r in rows_sorted[:3]])