import csv, json, statistics

# PresentMon
rows = []
with open(r"<WORKSPACE>\capture\presentmon.csv") as f:
    for r in csv.DictReader(f):
        rows.append(r)

mbp = [float(r["MsBetweenPresents"]) for r in rows]
t_end = float(rows[-1]["TimeInSeconds"]) + mbp[-1]
avg_fps = 1000.0 / (sum(mbp) / len(mbp))
mbp_sorted = sorted(mbp)
p99 = mbp_sorted[int(0.99 * (len(mbp_sorted) - 1))]
low1 = 1000.0 / p99
print(f"frames={len(mbp)} span_s={t_end:.3f} avg_fps={avg_fps:.2f} p99_ms={p99:.3f} low1={low1:.2f}")

# big frame times
spikes = [(i, mbp[i]) for i in range(len(mbp)) if mbp[i] > 30]
print(f"frames >30ms: {len(spikes)}")
for i, v in spikes[:40]:
    print(f"  idx={i} t={float(rows[i]['TimeInSeconds']):.3f} ms={v:.2f} present_api={rows[i]['MsInPresentAPI']} until_disp={rows[i]['MsUntilDisplayed']}")

# Sensors
sens = []
with open(r"<WORKSPACE>\capture\sensors.csv") as f:
    for r in csv.DictReader(f):
        sens.append(r)

l1 = [(int(r["time_s"]), r["gpu_pcie_link_state"], r["dpc_latency_us"]) for r in sens if r["gpu_pcie_link_state"] != "L0"]
print("non-L0 seconds:", l1)

# correlate: frame time at each second
import collections
per_sec = collections.defaultdict(list)
for i, r in enumerate(rows):
    per_sec[int(float(r["TimeInSeconds"]))].append(mbp[i])
print("per-second mean/max frame time:")
for s in sorted(per_sec):
    v = per_sec[s]
    print(f"  s={s} n={len(v)} mean={sum(v)/len(v):.2f} max={max(v):.2f}")