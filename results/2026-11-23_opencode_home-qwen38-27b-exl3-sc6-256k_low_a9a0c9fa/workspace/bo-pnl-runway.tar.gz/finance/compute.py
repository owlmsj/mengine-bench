import csv, json
from collections import defaultdict

base = r"<WORKSPACE>\finance"

coa = {}
with open(base + r"\chart_of_accounts.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        coa[row["account"]] = row["pnl_line"]

def parse_amount(s):
    s = s.strip()
    neg = s.startswith("-")
    s = s.lstrip("-")
    s = s.replace(".", "").replace(",", ".")
    v = float(s)
    return -v if neg else v

months = ["2026-01","2026-02","2026-03","2026-04","2026-05","2026-06"]
sums = {m: defaultdict(float) for m in months}

n = 0
with open(base + r"\ledger.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        d = row["date"]  # dd/mm/yyyy
        m = "2026-%02d" % int(d[3:5])
        amt = parse_amount(row["amount"])
        line = coa[row["account"]]
        sums[m][line] += amt
        n += 1

print("entries:", n)

revenue = {}
gross = {}
ebitda = {}
for m in months:
    rev = sums[m]["revenue"]
    cogs = sums[m]["cogs"]
    gm = (rev + cogs) / rev * 100 if rev else 0.0  # cogs negative
    # EBITDA: revenue + cogs + opex (all opex lines) + financial?
    # Standard: EBITDA excludes financial items. Include revenue, cogs, sm, rnd, ga.
    e = rev + cogs + sums[m]["sales_marketing"] + sums[m]["rnd"] + sums[m]["ga"]
    revenue[m] = round(rev, 2)
    gross[m] = round(gm, 2)
    ebitda[m] = round(e, 2)
    print(m, "rev=%.2f cogs=%.2f sm=%.2f rnd=%.2f ga=%.2f fin=%.2f gm=%.2f ebitda=%.2f" % (
        rev, cogs, sums[m]["sales_marketing"], sums[m]["rnd"], sums[m]["ga"],
        sums[m]["financial"], gm, e))

# burn: average monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = ["2026-04","2026-05","2026-06"]
neg = [-ebitda[m] for m in last3]
burn = sum(neg)/len(neg)
cash_jun = 1847350.40
runway = cash_jun / burn
print("burn=%.2f runway=%.4f" % (burn, runway))

out = {
    "revenue": revenue,
    "gross_margin_pct": gross,
    "ebitda": ebitda,
    "burn": round(burn, 2),
    "runway_months": round(runway, 2),
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))