import asyncio, json, uuid, ssl, socket, struct, os

TEXT = "Welcome aboard the evening ferry, please keep your bags clear of the doors."

async def edge_tts_mp3(path):
    import urllib.request
    req = urllib.request.Request(
        "https://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1/trustedclienttoken",
        headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
            "Accept": "application/json",
        }
    )
    try:
        token = urllib.request.urlopen(req).read().decode().strip()
        print("TOKEN OK:", token[:40])
    except Exception as e:
        print("TOKEN FAIL:", e)
        token = ""

    host = "speech.platform.bing.com"
    port = 443
    path_url = "/consumer/speech/synthesize/readaloud/edge/v1"
    if token:
        path_url += "?TrustedClientToken=" + token

    ctx = ssl.create_default_context()
    raw = socket.create_connection((host, port))
    ssock = ctx.wrap_socket(raw, server_hostname=host)

    # HTTP upgrade
    key = uuid.uuid4().hex[:16]
    req_head = (
        f"GET {path_url} HTTP/1.1\r\n"
        f"Host: {host}\r\n"
        f"Upgrade: websocket\r\n"
        f"Connection: Upgrade\r\n"
        f"Sec-WebSocket-Key: {key}\r\n"
        f"Sec-WebSocket-Version: 13\r\n"
        f"User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36\r\n"
        f"\r\n"
    )
    ssock.sendall(req_head.encode())
    # read headers
    resp = b""
    while b"\r\n\r\n" not in resp:
        resp += ssock.recv(4096)
    print("HANDSHAKE:", resp.decode(errors="ignore")[:200])

    def ws_send(payload: bytes):
        # client frames are masked
        mask = os.urandom(4)
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        header = bytearray([0x81])  # FIN + text
        ln = len(payload)
        if ln < 126:
            header.append(0x80 | ln)
        elif ln < 65536:
            header.append(0x80 | 126)
            header += struct.pack(">H", ln)
        else:
            header.append(0x80 | 127)
            header += struct.pack(">Q", ln)
        header += mask
        ssock.sendall(bytes(header) + masked)

    def ws_recv():
        # read one frame
        def rd(n):
            buf = b""
            while len(buf) < n:
                chunk = ssock.recv(n - len(buf))
                if not chunk:
                    raise ConnectionError("closed")
                buf += chunk
            return buf
        b1, b2 = rd(2)
        opcode = b1 & 0x0F
        ln = b2 & 0x7F
        if ln == 126:
            ln = struct.unpack(">H", rd(2))[0]
        elif ln == 127:
            ln = struct.unpack(">Q", rd(8))[0]
        payload = rd(ln) if ln else b""
        return opcode, payload

    config = {
        "context": {"synthesis": {"audio": {"metadataoptions": ["sentenceboundary"], "outputformat": "audio-24khz-48kbitrate-mono-mp3"}}},
        "name": "en-US-AriaNeural",
        "properties": {"locale": "en-US", "rate": "+0%", "pitch": "+0Hz", "volume": "+0%"}
    }
    msg1 = (
        "X-Timestamp: 2026-11-23T00:00:00Z\r\n"
        "Content-Type: application/json; charset=utf-16le\r\n"
        "Path: speech.config\r\n\r\n"
        + json.dumps(config)
    )
    ws_send(msg1.encode("utf-16le"))

    ssml = f'<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="en-US"><voice name="en-US-AriaNeural"><prosody rate="+0.000%">{TEXT}</prosody></voice></speak>'
    msg2 = (
        f"X-Id: {uuid.uuid4()}\r\n"
        "Content-Type: application/ssml+xml\r\n"
        "X-Timestamp: 2026-11-23T00:00:00Z\r\n"
        "Path: ssml\r\n\r\n"
        + ssml
    )
    ws_send(msg2.encode("utf-16le"))

    audio = b""
    while True:
        opcode, payload = ws_recv()
        if opcode == 0x8:  # close
            print("server closed")
            break
        if opcode == 0x1:  # text
            txt = payload.decode("utf-16le", errors="ignore")
            print("TEXT:", txt[:300])
            if "turn.end" in txt:
                break
        elif opcode == 0x2:  # binary
            audio += payload
    ssock.close()
    with open(path, "wb") as f:
        f.write(audio)
    print(f"MP3: {len(audio)} bytes")

asyncio.run(edge_tts_mp3("announcement_raw.mp3"))