Add-Type -AssemblyName System.Speech
$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
$synth.SetOutputToDefaultAudioDevice()
# Use a temp approach: set output to stream
$ms = New-Object System.IO.MemoryStream
$synth.SetOutputToStream($ms)
$synth.Speak("Welcome aboard the evening ferry, please keep your bags clear of the doors.")
$ms.Position = 0
$bytes = New-Object byte[] $ms.Length
$ms.Read($bytes, 0, $ms.Length) | Out-Null
[System.IO.File]::WriteAllBytes("<WORKSPACE>\sapi.wav", $bytes)
Write-Host "WAV written: $($bytes.Length) bytes"