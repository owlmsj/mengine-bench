"""Batch task runner.

Usage:
    from run import run_tasks

    await run_tasks([make_job_1, make_job_2, ...], max_concurrent=4)

Each task is a zero-argument callable returning an awaitable (e.g. a
coroutine). At most ``max_concurrent`` jobs run at once; ``run_tasks``
returns when every job has finished.

Ctrl+C handling: KeyboardInterrupt raised inside the event loop is
propagated to the caller, but all in-flight jobs are first cancelled and
their cleanup (``finally`` blocks / ``async with`` exits /
``asyncio.shield``-free teardown) is allowed to run to completion before
the exception is re-raised.
"""

from __future__ import annotations

import asyncio
from typing import Any, Awaitable, Callable, Iterable

__all__ = ["run_tasks"]


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[Any]]],
    max_concurrent: int,
) -> list[Any]:
    """Run zero-arg callables that return awaitables, bounded by max_concurrent.

    Returns the list of results in input order. If the caller is interrupted
    (e.g. Ctrl+C), in-flight jobs are cancelled and awaited so their cleanup
    code runs, then the original exception propagates.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent!r}")

    factories = list(tasks)
    if not factories:
        return []

    sem = asyncio.Semaphore(max_concurrent)
    results: list[Any] = [None] * len(factories)

    async def _run_one(index: int, factory: Callable[[], Awaitable[Any]]) -> None:
        async with sem:
            results[index] = await factory()

    jobs = [asyncio.ensure_future(_run_one(i, f)) for i, f in enumerate(factories)]
    try:
        await asyncio.gather(*jobs)
    except BaseException:
        # Cancel anything still running (e.g. after KeyboardInterrupt).
        for j in jobs:
            if not j.done():
                j.cancel()
        # Await the cancellations so cleanup code (finally / async with)
        # actually runs before we propagate the original exception.
        for j in jobs:
            try:
                await j
            except (asyncio.CancelledError, BaseException):
                pass
        raise
    return results


if __name__ == "__main__":
    # Minimal self-test: concurrency cap + result order + cleanup on cancel.
    import sys

    async def _selftest() -> None:
        running = 0
        peak = 0
        cleaned = []

        def make_job(i: int):
            async def job() -> int:
                nonlocal running, peak
                running += 1
                peak = max(peak, running)
                try:
                    await asyncio.sleep(0.05)
                finally:
                    running -= 1
                    cleaned.append(i)
                return i * 10

            return job

        res = await run_tasks([make_job(i) for i in range(6)], max_concurrent=2)
        assert res == [0, 10, 20, 30, 40, 50], res
        assert peak <= 2, peak
        assert len(cleaned) == 6, cleaned
        print("selftest ok: results ordered, cap respected, cleanup ran")

        # Cancel path: interrupt mid-run, ensure cleanup still runs.
        cleaned.clear()

        def make_slow(i: int):
            async def job() -> int:
                nonlocal running
                running += 1
                try:
                    await asyncio.sleep(30)
                finally:
                    running -= 1
                    cleaned.append(i)
                return i

            return job

        async def interrupter() -> None:
            await asyncio.sleep(0.1)
            raise KeyboardInterrupt

        runner = asyncio.ensure_future(run_tasks([make_slow(i) for i in range(3)], 2))
        await asyncio.sleep(0.1)  # let jobs start
        runner.cancel()
        try:
            await runner
        except (asyncio.CancelledError, KeyboardInterrupt):
            pass
        # Only the 2 in-flight jobs get to clean up; the 3rd never started.
        assert len(cleaned) == 2, cleaned
        print("selftest ok: cleanup ran after interrupt")

    asyncio.run(_selftest())