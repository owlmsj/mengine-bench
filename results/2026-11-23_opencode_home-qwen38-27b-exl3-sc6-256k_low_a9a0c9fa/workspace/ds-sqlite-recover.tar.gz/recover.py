import json, struct

data = open(r"<WORKSPACE>\prices.db", "rb").read()

def read_varint(buf, pos):
    result = 0
    for i in range(9):
        b = buf[pos+i]
        if i == 8:
            result = (result << 8) | b
            return result, pos+9
        result = (result << 7) | (b & 0x7F)
        if not (b & 0x80):
            return result, pos+i+1
    return result, pos+9

ncells = struct.unpack(">H", data[3:5])[0]
ptrs = [struct.unpack(">H", data[8+2*i:10+2*i])[0] for i in range(ncells)]

rows = []
for p in ptrs:
    pos = p
    payload_len, pos = read_varint(data, pos)
    rowid, pos = read_varint(data, pos)
    # record = [hdr_len varint][serial types][data]
    hdr_len, hdr_pos = read_varint(data, pos)
    hdr_end = hdr_pos + hdr_len
    serials = []
    hp = hdr_pos
    while hp < hdr_end:
        st, hp = read_varint(data, hp)
        serials.append(st)
    vals = []
    vp = hdr_end
    for st in serials:
        if st == 0:
            vals.append(None)
        elif st == 1:
            vals.append(struct.unpack(">b", data[vp:vp+1])[0]); vp += 1
        elif st == 2:
            vals.append(struct.unpack(">h", data[vp:vp+2])[0]); vp += 2
        elif st == 3:
            vals.append(int.from_bytes(data[vp:vp+3], "big", signed=True)); vp += 3
        elif st == 4:
            vals.append(struct.unpack(">i", data[vp:vp+4])[0]); vp += 4
        elif st == 5:
            vals.append(int.from_bytes(data[vp:vp+6], "big", signed=True)); vp += 6
        elif st == 6:
            vals.append(struct.unpack(">q", data[vp:vp+8])[0]); vp += 8
        elif st == 7:
            vals.append(struct.unpack(">d", data[vp:vp+8])[0]); vp += 8
        elif st == 8:
            vals.append(0)
        elif st == 9:
            vals.append(1)
        elif st >= 12 and st % 2 == 0:
            n = (st-12)//2
            vals.append(data[vp:vp+n].decode("utf-8", "replace")); vp += n
        elif st >= 13 and st % 2 == 1:
            n = (st-13)//2
            vals.append(data[vp:vp+n]); vp += n
        else:
            vals.append(None)
    rows.append((rowid, vals))
    print(f"rowid={rowid} serials={serials} vals={vals}")

out = []
for rowid, vals in sorted(rows):
    item, price = vals[0], vals[1]
    if isinstance(price, float) and price == int(price) and abs(price) < 1e15:
        price = int(price)
    out.append({"item": item, "price": price})

print(json.dumps(out, indent=2))
with open(r"<WORKSPACE>\recovered.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print("wrote", len(out), "rows")