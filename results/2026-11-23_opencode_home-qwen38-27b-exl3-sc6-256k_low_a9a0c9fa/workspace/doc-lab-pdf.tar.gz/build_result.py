import json

# First report (Alfa, 10/02/2026) units are the canonical units.
# Second report (Beta, 18/08/2026) values converted to Alfa units.

# Glucose: mmol/L -> mg/dL (* 18.016)
glu_beta = round(6.1 * 18.016, 1)
# LDL: mmol/L -> mg/dL (* 38.67)
ldl_beta = round(3.70 * 38.67, 1)
# Creatinine: umol/L -> mg/dL (/ 88.4)
cre_beta = round(76 / 88.4, 2)
# HbA1c: mmol/mol -> % ((x/10.929) + 2.15)
hba1c_beta = round((37 / 10.929) + 2.15, 2)

history = {
    "Glicose em jejum": {"10/02/2026": 92, "18/08/2026": glu_beta},
    "Colesterol LDL": {"10/02/2026": 118, "18/08/2026": ldl_beta},
    "Creatinina": {"10/02/2026": 0.95, "18/08/2026": cre_beta},
    "Hemoglobina glicada (HbA1c)": {"10/02/2026": 5.4, "18/08/2026": hba1c_beta},
}

# Worse = got worse (higher) AND now outside first report's reference range.
# Reference ranges from first report (Alfa):
#   Glicose: 70-99 mg/dL  -> 110.0 outside (above)
#   LDL: < 130 mg/dL      -> 143.1 outside (above)
#   Creatinina: 0.70-1.30 -> 0.86 inside
#   HbA1c: 4.0-5.6 %      -> 1.08 outside (below) but NOT worse (it decreased)

worse = ["Glicose em jejum", "Colesterol LDL"]

result = {"history": history, "worse": worse}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
print(json.dumps(result, ensure_ascii=False, indent=2))