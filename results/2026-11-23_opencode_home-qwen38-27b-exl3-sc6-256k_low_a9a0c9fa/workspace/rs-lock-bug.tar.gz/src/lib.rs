//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, i64>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, score);
        *self.total.lock().unwrap() += score;
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let score = *self.players.lock().unwrap().entry(id).or_insert(0) + points;
        self.players.lock().unwrap().insert(id, score);
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let mut players = self.players.lock().unwrap();
        let from_score = *players.entry(from).or_insert(0) - points;
        players.insert(from, from_score);
        let to_score = *players.entry(to).or_insert(0) + points;
        players.insert(to, to_score);
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.players.lock().unwrap().get(&id).unwrap_or(&0)
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}