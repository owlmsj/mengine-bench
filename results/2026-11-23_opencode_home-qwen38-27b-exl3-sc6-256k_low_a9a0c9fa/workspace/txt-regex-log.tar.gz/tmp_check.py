import re, datetime, sys

pat = open("regex.txt").read().strip()
print("pattern:", pat)

# --- sample log ---
text = open("server.log").read()
got = re.findall(pat, text, re.MULTILINE)
print("sample:", got)
# expected: lines with IPv4: line1 (10.12.0.7) -> last date 2026-04-01
# line3 (192.168.40.3) -> last date 2026-04-05
# line5 (172.20.1.14) -> no date on line -> nothing
# lines 2,4: no IP -> nothing
expected = ["2026-04-01", "2026-04-05"]
print("sample ok:", got == expected)

# --- edge cases ---
cases = [
    ("no ip, has date", "2026-04-02 INFO nothing", []),
    ("ip, date before ip", "2026-04-02 ip 10.0.0.1", []),
    ("ip, date after ip", "ip 10.0.0.1 at 2026-04-02", ["2026-04-02"]),
    ("two dates after ip", "ip 10.0.0.1 a 2026-04-02 b 2026-04-05", ["2026-04-05"]),
    ("feb29 leap", "ip 1.2.3.4 on 2024-02-29", ["2024-02-29"]),
    ("feb29 nonleap", "ip 1.2.3.4 on 2023-02-29", []),
    ("feb30", "ip 1.2.3.4 on 2024-02-30", []),
    ("month13", "ip 1.2.3.4 on 2024-13-01", []),
    ("day00", "ip 1.2.3.4 on 2024-01-00", []),
    ("day32", "ip 1.2.3.4 on 2024-01-32", []),
    ("date glued left", "ip 1.2.3.4 on x2024-01-01", []),
    ("date glued right", "ip 1.2.3.4 on 2024-01-01x", []),
    ("date glued right digit", "ip 1.2.3.4 on 2024-01-012", []),
    ("date at line end", "ip 1.2.3.4 on 2024-01-01", ["2024-01-01"]),
    ("bad ip part 256", "256.1.1.1 on 2024-01-01", []),
    ("bad ip leading zero", "01.1.1.1 on 2024-01-01", []),
    ("bad ip leading zero 2", "1.01.1.1 on 2024-01-01", []),
    ("ip glued", "ip 121.2.3.4 on 2024-01-01", []),
    ("ip glued left", "ip a1.2.3.4 on 2024-01-01", []),
    ("ip 255 ok", "255.255.255.255 on 2024-01-01", ["2024-01-01"]),
    ("ip 0 ok", "0.0.0.0 on 2024-01-01", ["2024-01-01"]),
    ("date before ip only", "2024-01-01 then 10.0.0.1", []),
    ("multi line order", "ip 1.1.1.1 d 2024-01-01\nno ip 2024-01-02\nip 2.2.2.2 d 2024-01-03", ["2024-01-01", "2024-01-03"]),
    ("crlf", "ip 1.1.1.1 d 2024-01-01\r\nno ip 2024-01-02\r\nip 2.2.2.2 d 2024-01-03", ["2024-01-01", "2024-01-03"]),
    ("two ips one date", "ip 1.1.1.1 and 2.2.2.2 on 2024-01-01", ["2024-01-01"]),
    ("ip then date then ip", "1.1.1.1 2024-01-01 2.2.2.2", ["2024-01-01"]),
    ("year 1999", "ip 1.1.1.1 1999-12-31", ["1999-12-31"]),
    ("year 1899", "ip 1.1.1.1 1899-12-31", []),
    ("year 2099", "ip 1.1.1.1 2099-12-31", ["2099-12-31"]),
    ("ip at end no date", "2024-01-01 ip 1.1.1.1", []),
    ("date only after ip on same line, ip at start", "1.1.1.1 2024-01-01", ["2024-01-01"]),
]

ok = True
for name, line, exp in cases:
    got = re.findall(pat, line, re.MULTILINE)
    status = "OK " if got == exp else "FAIL"
    if got != exp:
        ok = False
    print(f"{status} {name}: got={got} exp={exp}")

print("ALL OK" if ok else "SOME FAILED")