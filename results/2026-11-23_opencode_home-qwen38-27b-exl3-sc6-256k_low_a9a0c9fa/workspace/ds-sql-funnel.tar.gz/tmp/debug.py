import sqlite3, json
c = sqlite3.connect('analytics.db')
steps = ['install', 'tutorial_complete', 'first_match', 'purchase']
rows = c.execute("""
SELECT u.platform, e.user_id, e.name, MIN(e.ts)
FROM events e JOIN users u ON e.user_id = u.user_id
WHERE u.is_test = 0 AND e.name IN ('install','tutorial_complete','first_match','purchase')
GROUP BY u.platform, e.user_id, e.name
""").fetchall()
first = {}
for plat, uid, name, ts in rows:
    first[(plat, uid, name)] = ts
users = {}
for (plat, uid, name), ts in first.items():
    users.setdefault((plat, uid), {})[name] = ts

# Python version: count purchase where purchase >= first_match
pc_purch = 0
for (p, uid), ev in users.items():
    if p != 'pc' or 'purchase' not in ev:
        continue
    if 'first_match' in ev and ev['purchase'] >= ev['first_match']:
        pc_purch += 1
print('python purchase pc (>= first_match):', pc_purch)

# SQL version for purchase
sql = """
WITH firsts AS (
  SELECT u.platform AS plat, e.user_id, e.name, MIN(e.ts) AS ts
  FROM events e JOIN users u ON e.user_id = u.user_id
  WHERE u.is_test = 0
  GROUP BY u.platform, e.user_id, e.name
),
steps AS (
  SELECT f.plat, f.user_id,
    MAX(CASE WHEN f.name='install' THEN f.ts END) AS t0,
    MAX(CASE WHEN f.name='tutorial_complete' THEN f.ts END) AS t1,
    MAX(CASE WHEN f.name='first_match' THEN f.ts END) AS t2,
    MAX(CASE WHEN f.name='purchase' THEN f.ts END) AS t3
  FROM firsts f GROUP BY f.plat, f.user_id
)
SELECT plat, SUM(t3 IS NOT NULL AND t3 >= t2) FROM steps GROUP BY plat
"""
print('sql purchase:', c.execute(sql).fetchall())