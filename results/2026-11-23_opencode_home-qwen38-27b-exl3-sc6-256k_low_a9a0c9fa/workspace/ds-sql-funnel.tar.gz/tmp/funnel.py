import sqlite3, json
c = sqlite3.connect('analytics.db')
steps = ['install', 'tutorial_complete', 'first_match', 'purchase']
# first valid occurrence per user per step, valid = user known and not test
rows = c.execute("""
SELECT u.platform, e.user_id, e.name, MIN(e.ts)
FROM events e JOIN users u ON e.user_id = u.user_id
WHERE u.is_test = 0 AND e.name IN ('install','tutorial_complete','first_match','purchase')
GROUP BY u.platform, e.user_id, e.name
""").fetchall()
# first valid occurrence per user per step
first = {}
for plat, uid, name, ts in rows:
    first[(plat, uid, name)] = ts
# a step counts only at or after the same player's previous step
users = {}  # (plat, uid) -> {step: ts}
for (plat, uid, name), ts in first.items():
    users.setdefault((plat, uid), {})[name] = ts

funnel = {}
for plat in ['pc', 'steamdeck']:
    counts = {}
    prev_ts = None
    for step in steps:
        n = 0
        for (p, uid), ev in users.items():
            if p != plat or step not in ev:
                continue
            ts = ev[step]
            ok = True
            if prev_ts is not None:
                # need previous step present and ts >= prev step ts
                prev_step = steps[steps.index(step)-1]
                if prev_step not in ev or ts < ev[prev_step]:
                    ok = False
            if ok:
                n += 1
        counts[step] = n
    funnel[plat] = counts

# biggest drop: step with lowest conversion (players over previous step's players)
biggest = {}
for plat, counts in funnel.items():
    best_step, best_conv = None, None
    for i, step in enumerate(steps):
        if i == 0:
            continue
        prev = counts[steps[i-1]]
        if prev == 0:
            continue
        conv = counts[step] / prev
        if best_conv is None or conv < best_conv:
            best_conv, best_step = conv, step
    biggest[plat] = best_step

result = {'funnel': funnel, 'biggest_drop': biggest}
with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))