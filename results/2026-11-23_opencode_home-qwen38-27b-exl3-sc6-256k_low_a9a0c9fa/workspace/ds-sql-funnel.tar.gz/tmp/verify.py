import sqlite3
c = sqlite3.connect('analytics.db')
# Independent check: per platform, count users (non-test, known) whose first valid
# occurrence of each step satisfies ordering (step ts >= previous step ts).
sql = """
WITH firsts AS (
  SELECT u.platform AS plat, e.user_id, e.name, MIN(e.ts) AS ts
  FROM events e JOIN users u ON e.user_id = u.user_id
  WHERE u.is_test = 0
  GROUP BY u.platform, e.user_id, e.name
),
steps AS (
  SELECT f.plat, f.user_id,
    MAX(CASE WHEN f.name='install' THEN f.ts END) AS t0,
    MAX(CASE WHEN f.name='tutorial_complete' THEN f.ts END) AS t1,
    MAX(CASE WHEN f.name='first_match' THEN f.ts END) AS t2,
    MAX(CASE WHEN f.name='purchase' THEN f.ts END) AS t3
  FROM firsts f GROUP BY f.plat, f.user_id
)
SELECT plat,
  SUM(t0 IS NOT NULL) AS install,
  SUM(t1 IS NOT NULL AND t1 >= t0) AS tutorial,
  SUM(t2 IS NOT NULL AND t2 >= t1) AS first_match,
  SUM(t3 IS NOT NULL AND t3 >= t2) AS purchase
FROM steps GROUP BY plat
"""
for r in c.execute(sql):
    print(r)