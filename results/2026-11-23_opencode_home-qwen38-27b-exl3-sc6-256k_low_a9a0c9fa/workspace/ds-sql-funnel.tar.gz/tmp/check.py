import sqlite3
c = sqlite3.connect('analytics.db')
print('event names:', c.execute("SELECT name, COUNT(*) FROM events GROUP BY name").fetchall())
print('platforms:', c.execute("SELECT platform, COUNT(*) FROM users GROUP BY platform").fetchall())
print('is_test values:', c.execute("SELECT is_test, COUNT(*) FROM users GROUP BY is_test").fetchall())
print('events for unknown players:', c.execute("SELECT COUNT(*) FROM events e LEFT JOIN users u ON e.user_id=u.user_id WHERE u.user_id IS NULL").fetchone()[0])
print('distinct users with events:', c.execute("SELECT COUNT(DISTINCT user_id) FROM events").fetchone()[0])
# ts format check
ts = [r[0] for r in c.execute("SELECT DISTINCT ts FROM events LIMIT 10")]
print('sample ts:', ts)
bad = c.execute("SELECT COUNT(*) FROM events WHERE ts NOT GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9]'").fetchone()[0]
print('nonstandard ts:', bad)