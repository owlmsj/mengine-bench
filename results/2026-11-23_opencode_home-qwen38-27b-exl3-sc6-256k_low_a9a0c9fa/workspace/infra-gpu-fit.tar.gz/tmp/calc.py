import csv, json

# MODEL.md
params_b = 70e9
weight_bytes = params_b * 1  # FP8 = 1 byte/param
kv_per_token = 327_680
ctx = 32_768
seqs = 4
overhead_gb = 8.0
weights_gb = weight_bytes / 1e9
kv_gb = kv_per_token * ctx * seqs / 1e9
total_gb = weights_gb + kv_gb + overhead_gb
print(f"weights_gb={weights_gb} kv_gb={kv_gb} total_gb={total_gb}")

allowed_regions = {"us-east", "us-central", "eu-west"}
cap = 4.0
rows = list(csv.DictReader(open("offers.csv")))
cands = []
for r in rows:
    if r["in_stock"] != "yes":
        print(f"skip {r['offer_id']}: not in stock")
        continue
    if r["region"] not in allowed_regions:
        print(f"skip {r['offer_id']}: region {r['region']}")
        continue
    price = float(r["usd_per_hour"])
    if price > cap:
        print(f"skip {r['offer_id']}: ${price}/h over cap")
        continue
    mem = int(r["gpu_count"]) * float(r["vram_gb_per_gpu"])
    if mem < total_gb:
        print(f"skip {r['offer_id']}: {mem} GB < {total_gb} GB")
        continue
    cands.append((price, r["offer_id"], mem))
    print(f"OK   {r['offer_id']}: {mem} GB, ${price}/h, ${price*730}/mo")

cands.sort()
best = cands[0]
result = {
    "weights_gb": weights_gb,
    "kv_cache_gb": kv_gb,
    "total_gb": total_gb,
    "offer_id": best[1],
    "usd_per_hour": best[0],
    "usd_per_month": round(best[0] * 730, 2),
}
json.dump(result, open("result.json", "w"), indent=2)
print("BEST:", result)