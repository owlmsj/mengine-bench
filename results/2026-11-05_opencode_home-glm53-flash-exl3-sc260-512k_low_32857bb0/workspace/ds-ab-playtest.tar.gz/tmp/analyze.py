import csv, math
from collections import defaultdict

rows = defaultdict(list)
with open('./telemetry/playtest_ab.csv', newline='') as f:
    for r in csv.DictReader(f):
        v = r['variant'].strip().lower()
        rows[r['session_id']].append((v, int(r['completed_tutorial'])))

agg = {'a': [0,0], 'b': [0,0]}  # completed, total
dup = 0
conflict = 0
seen = {}
for sid, entries in rows.items():
    variants = {v for v,_ in entries}
    if len(entries) > 1: dup += 1
    if len(variants) > 1: conflict += 1
    v, c = entries[0]
    if len(variants) > 1:
        v, c = max(entries, key=lambda e: e[1])  # completed flag wins if conflicting
    agg[v][1] += 1
    agg[v][0] += c

na, nb = agg['a'][1], agg['b'][1]
xa, xb = agg['a'][0], agg['b'][0]
pa, pb = xa/na, xb/nb

# two-proportion z-test (pooled)
p_pool = (xa+xb)/(na+nb)
se = math.sqrt(p_pool*(1-p_pool)*(1/na+1/nb))
z = (pb-pa)/se
p_value = 2*(1-0.5*(1+math.erf(abs(z)/math.sqrt(2))))

# Fisher exact check via scipy if available
try:
    from scipy.stats import fisher_exact
    _, pf = fisher_exact([[xb, nb-xb],[xa, na-xa]])
except Exception:
    pf = None

print(f"duplicate session rows: {dup}, conflicting variant rows: {conflict}")
print(f"A: {xa}/{na} = {pa:.4f} ({pa*100:.1f}%)")
print(f"B: {xb}/{nb} = {pb:.4f} ({pb*100:.1f}%)")
print(f"z = {z:.3f}, p = {p_value:.5f}")
if pf is not None: print(f"fisher exact p = {pf:.5f}")