# Handoff: local-9b at 128k ctx (llama-server, Windows GPU)

Done:
- Q5 at 131072 ctx via `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`: 37.8 t/s, VRAM 7881 MiB, but WDDM Shared Usage showed 1494 MiB spilled -> invalid number.
- Fix `--no-mmproj-offload` + `-ub 512`: no spill, VRAM 7697 MiB, decode 38.0 t/s (median of 3). Applied in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.
- Q6_K (7.03 GiB) does not fit at 128k, discarded. Q4_K_M: 7305 MiB, 40.4 t/s, fallback only.

Next:
1. evals README still cites check_vision.ps1 (file gone); update it.
2. Never done: review scratchpad temp file names.
3. A download was awaited before measuring; re-run measure_decode.ps1 to confirm the numbers hold uncontaminated.

Assumptions: Shared Usage counts as spill and disqualifies a measurement; Q4_K_M is fallback only.

Verified by: measure_decode.ps1 output (t/s, VRAM, median of 3) and GPU counters; diff reviews confirmed recipe-only edits.