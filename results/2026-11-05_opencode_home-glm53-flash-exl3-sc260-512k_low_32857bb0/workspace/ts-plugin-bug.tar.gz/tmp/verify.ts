import { HookBus } from "../src/bus.ts";
import { registerAuditPlugin } from "../src/plugin.ts";
import assert from "node:assert/strict";

// 1. Order + sequential (plugin: notice, redaction, log)
const audit: string[] = [];
const bus = new HookBus();
registerAuditPlugin(bus, audit);
const result = { tool: "bash", output: "ok password=secret" };
await bus.emit("tool.after", result);
assert.deepEqual(audit, [
  "notice: tool output is audited",
  "bash: ok password=[redacted]",
]);
assert.equal(bus.count("tool.after"), 2, "notice unsubscribed itself once");

// 2. Second emit: notice does not run again
audit.length = 0;
await bus.emit("tool.after", { tool: "read", output: "x password=y" });
assert.deepEqual(audit, ["read: x password=[redacted]"]);

// 3. Error rejects emit and later handlers do not run
const b2 = new HookBus();
const runs: string[] = [];
b2.on("tool.after", async () => { await new Promise(r => setTimeout(r, 5)); runs.push("a"); });
b2.on("tool.after", () => { throw new Error("boom"); });
b2.on("tool.after", () => { runs.push("c"); });
await assert.rejects(b2.emit("tool.after", ""), /boom/);
assert.deepEqual(runs, ["a"]);

// 4. Async handlers finish before emit resolves and run one after another
const b3 = new HookBus();
const order: string[] = [];
b3.on("t", async () => { await new Promise(r => setTimeout(r, 10)); order.push("slow-first"); });
b3.on("t", () => { order.push("fast-second"); });
await b3.emit("t", "");
assert.deepEqual(order, ["slow-first", "fast-second"]);

// 5. Unsubscribing another handler mid-emit doesn't stop it in this emit
const b4 = new HookBus();
const got: string[] = [];
const offB = b4.on("t", (p: string) => { got.push(p); offB(); offA(); });
const offA = b4.on("t", (p: string) => { got.push("A:" + p); });
await b4.emit("t", "x");
assert.deepEqual(got, ["x", "A:x"]);
assert.equal(b4.count("t"), 0);
console.log("ALL OK");