"""Bounded-concurrency async job runner (stdlib only, Python 3.11+)."""
import asyncio
from collections.abc import Awaitable, Callable, Iterable


async def run_tasks(tasks: Iterable[Callable[[], Awaitable[object]]], max_concurrent: int) -> None:
    """Run each zero-arg job factory, at most max_concurrent at once.

    Factories are called only when a slot is free, so no job starts early.
    On Ctrl+C (cancellation) or a job error, TaskGroup cancels running jobs
    and waits for their cleanup (finally/except CancelledError) before raising.
    """
    if not isinstance(max_concurrent, int) or max_concurrent < 1:
        raise ValueError(f"max_concurrent must be int >= 1, got {max_concurrent!r}")
    slots = asyncio.Semaphore(max_concurrent)

    async def run_one_job(factory: Callable[[], Awaitable[object]]) -> None:
        try:
            await factory()
        finally:
            slots.release()

    async with asyncio.TaskGroup() as group:
        for factory in tasks:
            await slots.acquire()
            group.create_task(run_one_job(factory))
