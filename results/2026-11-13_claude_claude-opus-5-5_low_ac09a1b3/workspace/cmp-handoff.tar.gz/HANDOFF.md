# Handoff: local-9b Q5 at 128k context

Goal: measure local-9b Q5 decode at ctx 131072 (user needs 128k).

Final (valid): flags `--no-mmproj-offload -ub 512` -> VRAM 7697 MiB, decode 38.0 t/s (median of 3). No spill.
Discard: first run 37.8 t/s / 7881 MiB; 7881 is the WDDM ceiling, Shared Usage showed 1494 MiB spilled.
Alternatives: Q6_K (7.03 GiB) does not fit at 128k. Q4_K_M fits (7305 MiB, 40.4 t/s), fallback only.
Measure cmd: `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`; check Shared Usage = 0.

Done: recipe applied in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

Left: update evals README; it still cites check_vision.ps1, which no longer exists.

Source: session transcript only; I (writer) did not rerun anything, numbers are as logged there.
