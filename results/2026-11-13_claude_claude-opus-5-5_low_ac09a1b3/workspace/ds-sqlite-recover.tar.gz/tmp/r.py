import sys,json,struct
d=open(sys.argv[1],'rb').read()
ps=4096
def varint(b,i):
    v=0
    for k in range(9):
        c=b[i+k]
        if k==8: return (v<<8)|c,i+9
        v=(v<<7)|(c&0x7f)
        if c<0x80: return v,i+k+1
def rec(b,i):
    h,j=varint(b,i); end=i+h; ts=[]
    while j<end: t,j=varint(b,j); ts.append(t)
    p=end; out=[]
    for t in ts:
        if t==0: out.append(None)
        elif t in(1,2,3,4,6):
            n={1:1,2:2,3:3,4:4,6:8}[t]; out.append(int.from_bytes(b[p:p+n],'big',signed=True)); p+=n
        elif t==5: out.append(int.from_bytes(b[p:p+6],'big',signed=True)); p+=6
        elif t==7: out.append(struct.unpack('>d',b[p:p+8])[0]); p+=8
        elif t==8: out.append(0)
        elif t==9: out.append(1)
        elif t>=13 and t%2: n=(t-13)//2; out.append(b[p:p+n].decode()); p+=n
        else: n=(t-12)//2; out.append(b[p:p+n]); p+=n
    if p>len(b): raise ValueError
    return out
rows={}
for pg in range(0,len(d)//ps+1):
    base=pg*ps; o=base
    if o>=len(d) or d[o]!=13: continue
    n=struct.unpack('>H',d[o+3:o+5])[0]
    for c in range(n):
        try:
            cp=base+struct.unpack('>H',d[o+8+2*c:o+10+2*c])[0]
            ln,j=varint(d,cp); rid,j=varint(d,j)
            pass
            r=rec(d[j:j+ln],0); print(pg,rid,r,file=sys.stderr)
            if len(r)>=2 and isinstance(r[-2],str) and isinstance(r[-1],(int,float)): rows[(pg,rid)]={"item":r[-2],"price":r[-1]}
        except Exception as e: pass
json.dump(list(rows.values()),open(sys.argv[2],'w'),indent=1,ensure_ascii=False)
print(len(rows),len(d),ps)
