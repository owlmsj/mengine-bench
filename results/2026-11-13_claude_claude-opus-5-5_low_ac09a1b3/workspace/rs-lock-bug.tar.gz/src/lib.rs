//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    // Read and write under one guard; separate lock() calls lost concurrent updates.
    pub fn award(&self, id: PlayerId, points: i64) {
        *self.slot(id).lock().unwrap() += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    // Lock both slots in ascending id order: opposite transfers (a->b, b->a)
    // deadlocked, and a self transfer locked the same mutex twice.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return;
        }
        let (low, high) = if from < to { (from, to) } else { (to, from) };
        let low_slot = self.slot(low);
        let high_slot = self.slot(high);
        let mut low_score = low_slot.lock().unwrap();
        let mut high_score = high_slot.lock().unwrap();
        let (from_score, to_score) = if from == low {
            (&mut *low_score, &mut *high_score)
        } else {
            (&mut *high_score, &mut *low_score)
        };
        *from_score -= points;
        *to_score += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}

#[cfg(test)]
mod concurrency_regression {
    use super::*;
    use std::thread;

    #[test]
    fn concurrent_awards_and_opposite_transfers_keep_totals() {
        let board = Board::new();
        board.join(1, 0);
        board.join(2, 0);
        let workers: Vec<_> = (0..8u32)
            .map(|i| {
                let b = board.clone();
                thread::spawn(move || {
                    for _ in 0..2000 {
                        b.award(1, 1);
                        if i % 2 == 0 { b.transfer(1, 2, 1) } else { b.transfer(2, 1, 1) }
                        b.transfer(1, 1, 5);
                    }
                })
            })
            .collect();
        for w in workers {
            w.join().unwrap();
        }
        assert_eq!(board.total(), 16000);
        assert_eq!(board.score(1) + board.score(2), 16000);
    }
}
