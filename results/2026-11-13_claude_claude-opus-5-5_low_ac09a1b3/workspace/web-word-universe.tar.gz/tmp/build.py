import re,os,json,sys,unicodedata,urllib.parse
def fold(x): return ''.join(c for c in unicodedata.normalize('NFD',urllib.parse.unquote(x).lower()) if unicodedata.category(c)!='Mn')
D='site'; files={f for f in os.listdir(D) if f.endswith('.html')}
def rd(f): return open(os.path.join(D,f),encoding='utf-8').read()
lower={fold(f):f for f in files}
exact={urllib.parse.unquote(f).lower():f for f in files}
def resolve(href,seen=0):
    f=exact.get(urllib.parse.unquote(href).lower()) or lower.get(fold(href))
    if not f: return None
    t=rd(f); m=re.search(r'url=([^"]+)"',t)
    if m and seen<5: return resolve(m.group(1),seen+1)
    h=re.search(r'<h1>([^<]*)</h1>',t); return f if h and 'class="tema"' in t else None
def name(f): return re.search(r'<h1>([^<]*)</h1>',rd(f)).group(1).strip().lower()
G={};tema={};missing=set()
for f in files:
    t=rd(f)
    if 'class="tema"' not in t: continue
    w=name(f); G.setdefault(w,set()); tema[w]=re.search(r'Tema: ([^<]*)',t).group(1).strip()
    for sec in re.findall(r'<section id="\w+">(.*?)</section>',t,re.S):
        for href,txt in re.findall(r'href="([^"]+)">([^<]*)<',sec):
            r=resolve(href)
            if not r: missing.add(href); continue
            o=name(r)
            if o!=w: G[w].add(o); G.setdefault(o,set()).add(w)
pairs={tuple(sorted((a,b))) for a in G for b in G[a]}
mx=min(G,key=lambda k:(-len(G[k]),k))
top=sorted(G,key=lambda k:-len(G[k]))[:5]
json.dump({k:sorted(v) for k,v in sorted(G.items())},open('words.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
json.dump({'words':len(G),'relations':len(pairs),'most_connected':mx},open('result.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
print(len(G),len(pairs),mx,[(k,len(G[k])) for k in top],'missing',missing)
open('tmp/data.js','w',encoding='utf-8').write(json.dumps({'g':{k:sorted(v) for k,v in G.items()},'t':tema},ensure_ascii=False))
