"""Match payout. Rules live in docs/ECONOMY.md."""

from decimal import ROUND_HALF_UP, Decimal


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    # Decimal via str() avoids float drift (e.g. 1.1 multipliers) flipping a .5 tie.
    raw = (Decimal(str(base)) + kills * Decimal(str(cfg["kill_bonus"]))) * Decimal(str(cfg["event_multiplier"]))
    return int((raw / 10).quantize(Decimal("1"), rounding=ROUND_HALF_UP) * 10)
