"""Settings for the backup agent."""

import os

# Secret comes from the environment only (README: BACKUP_TOKEN); never hard-code it.
API_TOKEN = [REDACTED:env]"BACKUP_TOKEN", "")

API_URL = "https://backup.example.invalid/v1/upload"
ARCHIVE_DIR = "archives"
