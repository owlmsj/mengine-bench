"""Backup agent: packs a folder chosen in the intranet web form and uploads it to the backup API."""

from __future__ import annotations

import logging
import tarfile
import urllib.request
from pathlib import Path

import config

log = logging.getLogger("backup_agent")


def archive_folder(folder: str, out_dir: str = config.ARCHIVE_DIR) -> Path:
    """Packs `folder` into `out_dir/<folder name>.tar.gz` and returns the archive path."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    target = out / (Path(folder).name + ".tar.gz")
    # Pack in-process with tarfile: form input is never passed to a shell or command.
    source = Path(folder)
    if not source.is_dir():
        raise ValueError(f"folder must be an existing directory, got {folder!r}")
    with tarfile.open(target, "w:gz") as packed:
        packed.add(source, arcname=source.name)
    return target


def send_archive(path: Path, url: str, token: str) -> int:
    """Uploads one archive to the backup API and returns the HTTP status."""
    request = urllib.request.Request(url, data=path.read_bytes(), method="POST",
                                     headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.status


def upload(path: Path) -> int:
    if not config.API_TOKEN:
        raise RuntimeError("BACKUP_TOKEN environment variable is not set; expected a non-empty API token")
    log.info("uploading %s", path)
    return send_archive(path, config.API_URL, config.API_TOKEN)


def handle_form(form: dict[str, str]) -> int:
    """Web form handler: backs up the folder the user typed."""
    archive = archive_folder(form["folder"])
    log.info("archived %s", archive)
    return upload(archive)
