import csv
import json
from collections import defaultdict
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

ROOT = Path(__file__).resolve().parent
D = Decimal

def brl(value: str) -> Decimal:
    return D(value.replace('.', '').replace(',', '.'))

def rounded(value: Decimal) -> float:
    return float(value.quantize(D('0.01'), rounding=ROUND_HALF_UP))

with (ROOT / 'finance/chart_of_accounts.csv').open(encoding='utf-8-sig', newline='') as source:
    accounts = list(csv.DictReader(source, delimiter=';'))
mapping = {row['account']: row['pnl_line'] for row in accounts}
assert len(mapping) == len(accounts), 'Duplicate chart account'
with (ROOT / 'finance/ledger.csv').open(encoding='utf-8-sig', newline='') as source:
    ledger = list(csv.DictReader(source, delimiter=';'))
monthly = defaultdict(lambda: defaultdict(Decimal))
for row in ledger:
    month = datetime.strptime(row['date'], '%d/%m/%Y').strftime('%Y-%m')
    assert row['account'] in mapping, f"Unmapped account: {row['account']}"
    assert '2026-01' <= month <= '2026-06', f'Unexpected period: {month}'
    monthly[month][mapping[row['account']]] += brl(row['amount'])
months = [f'2026-{month:02}' for month in range(1, 7)]
assert sorted(monthly) == months
operating = ['revenue', 'cogs', 'sales_marketing', 'rnd', 'ga']
revenue = {month: monthly[month]['revenue'] for month in months}
gross = {month: revenue[month] + monthly[month]['cogs'] for month in months}
ebitda = {month: sum((monthly[month][line] for line in operating), D(0)) for month in months}
margin = {month: 100 * gross[month] / revenue[month] for month in months}
burn = -sum((ebitda[month] for month in months[-3:]), D(0)) / 3
cash_lines = (ROOT / 'finance/cash_balance.txt').read_text(encoding='utf-8-sig').splitlines()
cash = brl(cash_lines[-1].split('R$ ')[1])
prior_cash = brl(cash_lines[-2].split('R$ ')[1])
runway = cash / burn
result = {
    'revenue': {month: rounded(revenue[month]) for month in months},
    'gross_margin_pct': {month: rounded(margin[month]) for month in months},
    'ebitda': {month: rounded(ebitda[month]) for month in months},
    'burn': rounded(burn),
    'runway_months': rounded(runway),
}
(ROOT / 'result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')

# Independent account-prefix calculation checks the supplied chart classification.
for month in months:
    entries = [row for row in ledger if datetime.strptime(row['date'], '%d/%m/%Y').strftime('%Y-%m') == month]
    direct_revenue = sum((brl(row['amount']) for row in entries if row['account'].startswith('3.')), D(0))
    direct_cogs = sum((brl(row['amount']) for row in entries if row['account'].startswith('4.')), D(0))
    direct_ebitda = sum((brl(row['amount']) for row in entries if not row['account'].startswith('6.')), D(0))
    assert direct_revenue == revenue[month]
    assert direct_cogs + direct_revenue == gross[month]
    assert direct_ebitda == ebitda[month]
    total = sum((brl(row['amount']) for row in entries), D(0))
    assert total == ebitda[month] + monthly[month]['financial']
assert json.loads((ROOT / 'result.json').read_text()) == result

def money(value: Decimal) -> str:
    return f'{value:,.2f}'

h1_rev = sum(revenue.values())
h1_gross = sum(gross.values())
h1_ebitda = sum(ebitda.values())
cash_drop = prior_cash - cash
june_financial = monthly['2026-06']['financial']
june_pnl = ebitda['2026-06'] + june_financial
unexplained = cash_drop + june_pnl
report = ['# H1 2026 close: CFO board brief', '',
    'Reporting date: 30 June 2026. Currency: BRL (R$). Figures are calculated from the supplied ledger; this is a management close, not an audited statutory close.', '',
    f'H1 net revenue was R$ {money(h1_rev)}, gross margin {100*h1_gross/h1_rev:.2f}%, and EBITDA R$ {money(h1_ebitda)}. June closing cash was R$ {money(cash)}.', '',
    f'Board-defined monthly burn is R$ {money(burn)} and cash runway is {runway:.2f} months from 30 June 2026 at that constant burn.', '',
    '| Month | Net revenue (R$) | Gross profit (R$) | Gross margin | EBITDA (R$) |',
    '|---|---:|---:|---:|---:|']
for month in months:
    report.append(f'| {month} | {money(revenue[month])} | {money(gross[month])} | {margin[month]:.2f}% | {money(ebitda[month])} |')
report += ['', '## What changed', '',
    f'- January to June revenue grew {100*(revenue[months[-1]]/revenue[months[0]]-1):.2f}%. Gross margin changed by {margin[months[-1]]-margin[months[0]]:.2f} percentage points.',
    f'- Every month had negative EBITDA. June EBITDA changed by R$ {money(ebitda[months[-1]]-ebitda[months[0]])} versus January.',
    '- March and May include customer refunds of R$ 6,814.15 and R$ 8,634.37 respectively, deducted from revenue.', '',
    '## Liquidity and board decision', '',
    f'Burn = -[April EBITDA ({money(ebitda[months[3]])}) + May EBITDA ({money(ebitda[months[4]])}) + June EBITDA ({money(ebitda[months[5]])})] / 3 = R$ {money(burn)} per month. Runway = R$ {money(cash)} / unrounded burn = {runway:.2f} months.', '',
    f'Cash fell R$ {money(cash_drop)} from May to June. June EBITDA plus net financial income was R$ {money(june_pnl)} (net financial income R$ {money(june_financial)}). The cash decline exceeds that P&L loss by R$ {money(unexplained)}. The supplied files do not explain this difference: obtain bank movements, working capital, capex and financing schedules before certifying cash-flow reconciliation.', '',
    'Ask the board to agree a funding and spending plan against this runway and require a cash-flow bridge before relying on the EBITDA proxy for liquidity planning.', '',
    '## Assumptions and close limits', '',
    '- Ledger dates are DD/MM/YYYY; amounts use Brazilian decimal commas and thousands dots. Entries are treated as recognized accrual activity in their dated month, with no unsupported adjustments.',
    '- Revenue includes subscriptions and onboarding net of refunds. Gross profit equals revenue plus signed COGS; gross margin is gross profit divided by net revenue, expressed in percentage points (for example, 70 means 70%).',
    '- EBITDA includes revenue, COGS, sales/marketing, R&D and G&A. Financial income and interest/IOF are excluded. No depreciation, amortization or other unprovided entries are invented.',
    '- Burn follows the board note: average monthly negative EBITDA of the last three closed months, April-June. All three are loss-making. It is an EBITDA proxy, not measured cash consumption.',
    '- Latest supplied cash is 30 June, assumed unrestricted and available. Runway is measured from that date, not the investor meeting date. No July-November actuals are supplied, so present-day cash and runway cannot be established.',
    '- Runway assumes constant burn, no new funding, no minimum cash reserve and no cash conversion adjustments. Monetary results and JSON ratios round to two decimals; calculations use unrounded Decimal values.',
    '- A full statutory close cannot be certified without balance sheet, bank reconciliation, receivables/payables, accruals, tax and cutoff support.', '',
    '## Evidence', '',
    'Sources: finance/ledger.csv (dated postings), finance/chart_of_accounts.csv (classification), finance/README.md (board burn/runway policy), finance/cash_balance.txt (May and June cash).', '',
    f'Validation: all {len(ledger)} ledger rows mapped to unique chart accounts and the six requested months. Monthly revenue, gross profit and EBITDA independently recomputed using account prefixes; every monthly ledger total reconciled to EBITDA plus financial items. Saved JSON reloaded and compared with computed output. Source files unchanged.', '']
(ROOT / 'cfo_brief.md').write_text('\n'.join(report), encoding='utf-8')
proof = f'PASS: {len(ledger)} ledger rows; 0 unmapped accounts; 6 months independently reconciled.\nPASS: result.json reloaded and matches computed figures.\nBurn: BRL {money(burn)}; runway: {runway:.2f} months.\n'
(ROOT / 'validation.txt').write_text(proof, encoding='utf-8')
print(proof)
print(json.dumps(result, indent=2))
