# H1 2026 close: CFO board brief

Reporting date: 30 June 2026. Currency: BRL (R$). Figures are calculated from the supplied ledger; this is a management close, not an audited statutory close.

H1 net revenue was R$ 1,389,492.82, gross margin 70.24%, and EBITDA R$ -1,218,969.18. June closing cash was R$ 1,847,350.40.

Board-defined monthly burn is R$ 197,288.23 and cash runway is 9.36 months from 30 June 2026 at that constant burn.

| Month | Net revenue (R$) | Gross profit (R$) | Gross margin | EBITDA (R$) |
|---|---:|---:|---:|---:|
| 2026-01 | 200,510.87 | 140,418.95 | 70.03% | -210,278.96 |
| 2026-02 | 216,328.06 | 152,049.35 | 70.29% | -212,300.08 |
| 2026-03 | 219,066.17 | 149,970.12 | 68.46% | -204,525.45 |
| 2026-04 | 238,163.26 | 167,295.53 | 70.24% | -196,950.65 |
| 2026-05 | 243,032.89 | 169,059.76 | 69.56% | -201,945.82 |
| 2026-06 | 272,391.57 | 197,228.88 | 72.41% | -192,968.22 |

## What changed

- January to June revenue grew 35.85%. Gross margin changed by 2.38 percentage points.
- Every month had negative EBITDA. June EBITDA changed by R$ 17,310.74 versus January.
- March and May include customer refunds of R$ 6,814.15 and R$ 8,634.37 respectively, deducted from revenue.

## Liquidity and board decision

Burn = -[April EBITDA (-196,950.65) + May EBITDA (-201,945.82) + June EBITDA (-192,968.22)] / 3 = R$ 197,288.23 per month. Runway = R$ 1,847,350.40 / unrounded burn = 9.36 months.

Cash fell R$ 461,837.60 from May to June. June EBITDA plus net financial income was R$ -187,346.57 (net financial income R$ 5,621.65). The cash decline exceeds that P&L loss by R$ 274,491.03. The supplied files do not explain this difference: obtain bank movements, working capital, capex and financing schedules before certifying cash-flow reconciliation.

Ask the board to agree a funding and spending plan against this runway and require a cash-flow bridge before relying on the EBITDA proxy for liquidity planning.

## Assumptions and close limits

- Ledger dates are DD/MM/YYYY; amounts use Brazilian decimal commas and thousands dots. Entries are treated as recognized accrual activity in their dated month, with no unsupported adjustments.
- Revenue includes subscriptions and onboarding net of refunds. Gross profit equals revenue plus signed COGS; gross margin is gross profit divided by net revenue, expressed in percentage points (for example, 70 means 70%).
- EBITDA includes revenue, COGS, sales/marketing, R&D and G&A. Financial income and interest/IOF are excluded. No depreciation, amortization or other unprovided entries are invented.
- Burn follows the board note: average monthly negative EBITDA of the last three closed months, April-June. All three are loss-making. It is an EBITDA proxy, not measured cash consumption.
- Latest supplied cash is 30 June, assumed unrestricted and available. Runway is measured from that date, not the investor meeting date. No July-November actuals are supplied, so present-day cash and runway cannot be established.
- Runway assumes constant burn, no new funding, no minimum cash reserve and no cash conversion adjustments. Monetary results and JSON ratios round to two decimals; calculations use unrounded Decimal values.
- A full statutory close cannot be certified without balance sheet, bank reconciliation, receivables/payables, accruals, tax and cutoff support.

## Evidence

Sources: finance/ledger.csv (dated postings), finance/chart_of_accounts.csv (classification), finance/README.md (board burn/runway policy), finance/cash_balance.txt (May and June cash).

Validation: all 86 ledger rows mapped to unique chart accounts and the six requested months. Monthly revenue, gross profit and EBITDA independently recomputed using account prefixes; every monthly ledger total reconciled to EBITDA plus financial items. Saved JSON reloaded and compared with computed output. Source files unchanged.
