import logging
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock
import tarfile

import backup_agent

class SecurityRegressionTest(unittest.TestCase):
    def test_form_input_never_reaches_a_process(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent / 'tmp') as scratch:
            root = Path(scratch)
            folder = root / 'docs & echo injected'
            folder.mkdir()
            (folder / 'report.txt').write_text('backup content', encoding='utf-8')
            with mock.patch('subprocess.run', side_effect=AssertionError('process execution forbidden')):
                archive = backup_agent.archive_folder(str(folder), str(root / 'output'))
            with tarfile.open(archive) as packed:
                self.assertEqual(packed.extractfile(folder.name + '/report.txt').read(), b'backup content')

    def test_token_is_read_at_upload_and_never_logged(self):
        with mock.patch.dict(os.environ, {'BACKUP_TOKEN': '[REDACTED:env]'}):
            with mock.patch.object(backup_agent, 'send_archive', return_value=201) as sent:
                with mock.patch.object(backup_agent.log, 'info') as logged:
                    self.assertEqual(backup_agent.upload(Path('archive.tar.gz')), 201)
            self.assertTrue(sent.call_args.args[2] == 'regression-sentinel', 'upload must use the environment token')
            self.assertNotIn('regression-sentinel', str(logged.call_args_list))

if __name__ == '__main__':
    unittest.main()
