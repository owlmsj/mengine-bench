Goal: local-9b Q5 at 128k (131072 tokens).
Recorded result: 38.0 t/s decode (median of 3), 7697 MiB VRAM, no spill, using --no-mmproj-offload and -ub 512. Measurement command: pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024.
Reject the earlier 37.8 t/s / 7881 MiB result: it hit the WDDM ceiling and spilled 1494 MiB to shared memory. Q6_K (7.03 GiB) did not fit; Q4_K_M is fallback only (7305 MiB, 40.4 t/s).
Recipe reportedly applied in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.
Next: update evals README; it still cites deleted check_vision.ps1. Find the actual replacement before editing; none is named.
Assumption: continue documentation cleanup, preserving Q5 recipe. Only session/ and AGENTS.md are present here, so code/diffs and raw runs cannot be verified.
Finding: measurement/config work is reported complete; README remains. Evidence is the transcript's explicit results and final pending item, not an independent rerun.