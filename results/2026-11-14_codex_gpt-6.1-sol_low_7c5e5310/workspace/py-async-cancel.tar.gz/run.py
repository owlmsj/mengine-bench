"""Bounded asynchronous batch execution for Python 3.11+."""

import asyncio
from collections.abc import Awaitable, Callable, Iterable


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[object]]],
    max_concurrent: int,
) -> None:
    """Run jobs with bounded concurrency, discarding their results.

    The iterable is consumed lazily. A job failure cancels siblings and
    propagates as a TaskGroup exception group after cleanup. Cancellation
    cancels workers once and waits for their cleanup, even if the caller
    cancels again. Jobs must cooperate with cancellation and finish cleanup.
    A second physical Ctrl+C can force Python's runner to exit immediately.
    """
    if isinstance(max_concurrent, bool) or not isinstance(max_concurrent, int) or max_concurrent < 1:
        raise ValueError(f'max_concurrent must be a positive integer; received {max_concurrent!r}')

    remaining = iter(tasks)

    async def worker() -> None:
        while True:
            try:
                factory = next(remaining)
            except StopIteration:
                return
            await factory()

    async def batch() -> None:
        async with asyncio.TaskGroup() as group:
            for _ in range(max_concurrent):
                group.create_task(worker())

    running = asyncio.create_task(batch())
    try:
        await asyncio.shield(running)
    except asyncio.CancelledError:
        running.cancel()
        while not running.done():
            try:
                await asyncio.shield(running)
            except asyncio.CancelledError:
                continue
            except BaseException:
                break
        # Retrieve failures during shutdown; caller cancellation takes precedence.
        if not running.cancelled():
            running.exception()
        raise
