import asyncio
import unittest

from run import run_tasks


class RunTasksTests(unittest.IsolatedAsyncioTestCase):
    async def test_limit_and_completion(self):
        active = peak = completed = 0

        async def job():
            nonlocal active, peak, completed
            active += 1
            peak = max(peak, active)
            await asyncio.sleep(0.001)
            active -= 1
            completed += 1

        await run_tasks([job] * 12, 3)
        self.assertEqual((peak, completed), (3, 12))

    async def test_repeated_cancellation_waits_for_cleanup(self):
        started = asyncio.Event()
        cleaning = asyncio.Event()
        release = asyncio.Event()
        cleaned = asyncio.Event()

        async def job():
            try:
                started.set()
                await asyncio.Event().wait()
            finally:
                cleaning.set()
                await release.wait()
                cleaned.set()

        pending = asyncio.create_task(run_tasks([job], 1))
        await started.wait()
        pending.cancel()
        await cleaning.wait()
        pending.cancel()
        await asyncio.sleep(0)
        self.assertFalse(pending.done())
        release.set()
        with self.assertRaises(asyncio.CancelledError):
            await pending
        self.assertTrue(cleaned.is_set())

    async def test_failure_cleans_sibling(self):
        started = asyncio.Event()
        cleaned = asyncio.Event()

        async def sibling():
            try:
                started.set()
                await asyncio.Event().wait()
            finally:
                await asyncio.sleep(0)
                cleaned.set()

        async def failing():
            await started.wait()
            raise ValueError('job failed')

        with self.assertRaises(ExceptionGroup):
            await run_tasks([sibling, failing], 2)
        self.assertTrue(cleaned.is_set())

    async def test_empty_and_invalid(self):
        await run_tasks([], 2)
        for limit in (0, -1, True, 1.5):
            with self.assertRaises(ValueError):
                await run_tasks([], limit)


if __name__ == '__main__':
    unittest.main()
