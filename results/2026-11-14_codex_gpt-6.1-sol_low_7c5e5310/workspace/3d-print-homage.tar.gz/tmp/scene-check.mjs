
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js';
const scene=new THREE.Scene();scene.background=new THREE.Color('#e8dcb9');
const camera=new THREE.OrthographicCamera(0,1280,860,0,0.1,4000);camera.position.set(0,0,1600);
const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setSize(innerWidth,innerHeight);renderer.outputColorSpace=THREE.SRGBColorSpace;document.body.prepend(renderer.domElement);
scene.add(new THREE.AmbientLight(0xfff5dc,2));const sun=new THREE.DirectionalLight(0xffffff,2.3);sun.position.set(-500,700,1000);scene.add(sun);
const C={ink:'#163e56',blue:'#215b78',cyan:'#77a7ac',foam:'#f5efd8',wood:'#d2ad77',dark:'#193d50'};let seed=27;function rand(){seed=(seed*1664525+1013904223)>>>0;return seed/4294967296}
function mat(c){return new THREE.MeshStandardMaterial({color:c,roughness:1,flatShading:true,side:THREE.DoubleSide})}
const materials={};function material(c){return materials[c]??=mat(c)}
function polygon(points,color,z=0,depth=4,parent=scene){const s=new THREE.Shape();points.forEach(([x,y],i)=>i?s.lineTo(x,860-y):s.moveTo(x,860-y));s.closePath();const g=new THREE.ExtrudeGeometry(s,{depth,bevelEnabled:false});const m=new THREE.Mesh(g,material(color));m.position.z=z;parent.add(m);return m}
function line(points,color,z=0,r=2,parent=scene){const curve=new THREE.CatmullRomCurve3(points.map(([x,y])=>new THREE.Vector3(x,860-y,z)));const m=new THREE.Mesh(new THREE.TubeGeometry(curve,Math.max(8,points.length*5),r,5,false),material(color));parent.add(m);return m}
function ball(x,y,z,r,color,parent=scene){const m=new THREE.Mesh(new THREE.IcosahedronGeometry(r,0),material(color));m.position.set(x,860-y,z);parent.add(m);return m}
// A shallow sculptural relief: every ribbon has real depth and angular lit faces.
function ribbon(points,width,color,z,parent=scene){const curve=new THREE.CatmullRomCurve3(points.map(([x,y])=>new THREE.Vector3(x,860-y,0)));const verts=[],indices=[];const n=50;for(let i=0;i<=n;i++){const t=i/n,p=curve.getPoint(t),v=curve.getTangent(t);const w=width*(0.35+0.65*Math.sin(Math.PI*t));for(let j=0;j<4;j++){let a=(j/3-.5)*w;verts.push(p.x-v.y*a,p.y+v.x*a,z+Math.sin(j/3*Math.PI)*width*.22+Math.sin(i*1.4)*1.4)}}for(let i=0;i<n;i++)for(let j=0;j<3;j++){let a=i*4+j;indices.push(a,a+4,a+1,a+1,a+4,a+5)}const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(verts,3));g.setIndex(indices);g.computeVertexNormals();const m=new THREE.Mesh(g,material(color));parent.add(m);return m}
// Low horizon and the unmistakable distant Fuji.
polygon([[0,570],[300,543],[700,550],[1280,510],[1280,860],[0,860]],'#a8aaa0',-160,1);
polygon([[670,657],[741,617],[810,550],[827,563],[886,624],[954,658]],C.ink,-110,10);
polygon([[742,617],[810,550],[827,563],[864,608],[844,601],[838,618],[823,597],[817,623],[802,599],[788,619],[790,590],[770,612]],C.foam,-95,3);
polygon([[0,667],[170,595],[300,651],[470,624],[661,670],[864,645],[1080,580],[1280,470],[1280,860],[0,860]],C.ink,-70,15);
for(let i=0;i<12;i++)ribbon([[350+i*39,860],[600+i*24,740],[970+i*23,654],[1340,480+i*19]],17+i%3*7,i%3?C.blue:C.cyan,-40+i*2);
// Three oshiokuri-bune with pointed hulls, ribs, gunwales and crouched crews.
const boats=[];function boat(x,y,length,angle,z){const root=new THREE.Group();scene.add(root);root.position.set(x,860-y,z);root.rotation.z=angle;const p=new THREE.Group();root.add(p);p.position.y=-860;
const L=length;polygon([[0,0],[L*.17,39],[L*.68,48],[L,0],[L*.87,47],[L*.63,70],[L*.22,64]],C.wood,0,13,p);polygon([[L*.08,12],[L*.23,40],[L*.66,45],[L*.94,11],[L*.82,38],[L*.62,55],[L*.25,52]],'#58686a',17,4,p);line([[0,0],[L*.2,51],[L*.63,61],[L,0]],C.ink,23,2,p);line([[0,-2],[L*.2,35],[L*.65,43],[L,0]],'#f0d8a7',25,3,p);
for(let i=0;i<15;i++){let a=L*(.22+i*.037);line([[a,41],[a-10,56]],'#bba67f',25,1.6,p)}for(let i=0;i<8;i++){let a=L*(.43+i*.052);let yy=32-(i>3?(i-3)*5:0);const body=ball(a,yy,29,10,C.ink,p);body.scale.set(1.5,.7,1);ball(a-7,yy-7,35,5.3,'#e7c99f',p);line([[a-7,yy],[a-22,yy+13]],C.foam,35,1.8,p)}root.userData.restY=root.position.y;boats.push(root);return root}
boat(708,599,490,.30,-20);boat(40,420,345,-.55,148);
// The great left-hand breaker silhouette.
const wave=new THREE.Group();scene.add(wave);
polygon([[-90,349],[40,303],[142,226],[227,145],[329,94],[423,77],[490,78],[539,102],[580,126],[616,172],[646,212],[602,203],[560,215],[529,246],[510,297],[493,356],[500,420],[527,489],[579,553],[647,605],[687,641],[623,652],[542,618],[469,563],[395,548],[296,590],[197,629],[88,650],[-50,630]],C.ink,55,28,wave);
for(let i=0;i<16;i++){let a=i/15; ribbon([[-80+a*590,862],[20+a*500,662],[150+a*365,533],[205+a*265,373],[280+a*206,216],[352+a*145,150],[445+a*117,164],[510+a*90,220]],22+i%4*7,[C.blue,C.ink,C.cyan,C.blue][i%4],85+i*.3,wave)}
polygon([[-20,322],[80,292],[173,207],[267,134],[363,91],[445,80],[490,82],[525,95],[547,118],[507,107],[483,126],[460,113],[434,141],[410,130],[388,166],[366,160],[337,193],[310,186],[284,219],[263,218],[239,258],[211,253],[184,291],[150,292],[118,321],[64,337],[-20,359]],C.foam,117,12,wave);
// Branching, claw-like foam fingers follow the crest rather than a solid white cap.
function claw(x,y,s,angle,z,parent){const pts=[];for(let i=0;i<7;i++){let t=i/6;let xx=t*s*.78,yy=-Math.sin(t*Math.PI*.8)*s*.65;pts.push([x+xx*Math.cos(angle)-yy*Math.sin(angle),y+xx*Math.sin(angle)+yy*Math.cos(angle)])}line(pts,C.foam,z,s*.10,parent);const end=pts[6];line([pts[3],[end[0]+s*.18,end[1]-s*.30],[end[0]+s*.36,end[1]-s*.12]],C.foam,z+1,s*.065,parent)}
for(let i=0;i<43;i++){let t=i/42;let x=285+t*406,y=204-105*Math.sin(t*Math.PI)+t*t*218;claw(x,y,24+rand()*27,-.8+t*1.6,138,wave);if(i%2===0)claw(x-13,y+22,23+rand()*18,-.8,139,wave)}
// Foreground wave sweeps diagonally toward the tiny mountain.
polygon([[-60,875],[-25,767],[75,684],[170,689],[235,635],[318,649],[381,584],[424,495],[456,482],[502,528],[559,615],[633,702],[756,769],[1006,764],[1280,572],[1350,860]],C.ink,155,24);
for(let i=0;i<17;i++){let a=i/16;ribbon([[55+a*450,920],[143+a*391,772],[273+a*226,668],[392+a*82,558],[449+a*17,507],[528+a*17,637],[696+a*20,767],[970+a*40,815],[1310,601+a*235]],16+i%4*9,[C.blue,C.cyan,C.ink,C.foam][i%4],190+i*.5)}
polygon([[201,860],[264,749],[322,672],[370,593],[419,505],[447,485],[479,511],[491,546],[464,535],[446,560],[430,550],[409,600],[390,591],[363,651],[339,648],[315,712],[295,705],[271,774],[253,773],[234,860]],C.foam,215,8);
for(let i=0;i<50;i++){let x=30+rand()*460,y=610+rand()*270;claw(x,y,18+rand()*32,-1.1,225,scene)}
boat(526,659,550,-.16,260);
for(let i=0;i<7;i++)ribbon([[674+i*37,913],[901+i*25,833],[1111+i*22,718],[1320,618+i*31]],20+i*5,i%2?C.foam:C.blue,300+i*3);
const spray=new THREE.Group();scene.add(spray);for(let i=0;i<285;i++){let x=280+rand()*480,y=190+rand()*455;if(x>520&&y<330&&rand()>.2)continue;ball(x,y,150+rand()*60,1.4+rand()*2.1,C.foam,spray)}
// Subtle paper-like color variation is geometry, never the source image.
const grain=new THREE.BufferGeometry(),gv=[];for(let i=0;i<9000;i++)gv.push(rand()*1280,rand()*860,-190);grain.setAttribute('position',new THREE.Float32BufferAttribute(gv,3));scene.add(new THREE.Points(grain,new THREE.PointsMaterial({color:'#b9a67a',size:1.1,transparent:true,opacity:.18})));
let paused=matchMedia('(prefers-reduced-motion: reduce)').matches;const button=document.querySelector('#motion');function label(){button.textContent=paused?'PLAY':'PAUSE';button.setAttribute('aria-label',paused?'Play animation':'Pause animation')}label();button.onclick=()=>{paused=!paused;label()};let elapsed=0,last=0;function resize(){const aspect=innerWidth/innerHeight,target=1280/860;if(aspect>target){const w=860*aspect;camera.left=(1280-w)/2;camera.right=(1280+w)/2;camera.top=860;camera.bottom=0}else{const h=1280/aspect;camera.left=0;camera.right=1280;camera.top=430+h/2;camera.bottom=430-h/2}camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)}addEventListener('resize',resize);resize();
function animate(ms){requestAnimationFrame(animate);const dt=Math.min((ms-last)/1000,.05);last=ms;if(!paused)elapsed+=dt;wave.position.y=Math.sin(elapsed*.55)*2;wave.rotation.z=Math.sin(elapsed*.3)*.001;boats.forEach((b,i)=>{b.position.y=b.userData.restY+Math.sin(elapsed*.7+i)*2;b.rotation.x=Math.sin(elapsed*.6+i)*.025});spray.position.y=Math.sin(elapsed*.45)*4;renderer.render(scene,camera);document.body.dataset.ready='true'}requestAnimationFrame(animate);
window.addEventListener('error',e=>document.querySelector('#error').textContent=e.message);
