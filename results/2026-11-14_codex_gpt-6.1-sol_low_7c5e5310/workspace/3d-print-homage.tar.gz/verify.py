from pathlib import Path
import json, re, unittest

class WallpaperChecks(unittest.TestCase):
    def test_reference_subjects(self):
        result = json.loads(Path('result.json').read_text(encoding='utf-8-sig'))
        self.assertEqual(result['boats'], 3)
        self.assertEqual(result['mountain'], 'Mount Fuji')
        html = Path('scene/index.html').read_text(encoding='utf-8-sig')
        self.assertEqual(len(re.findall(r'(?<!function )boat\(\d', html)), 3)

    def test_single_file_dependency(self):
        html = Path('scene/index.html').read_text(encoding='utf-8-sig')
        self.assertEqual(re.findall(r'https?://[^\s\x27\x22]+', html), ['https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js'])
        self.assertNotIn('TextureLoader', html)
        self.assertNotIn('print.jpg', html)
        self.assertIn('prefers-reduced-motion', html)

    def test_anchored_boat_motion(self):
        html = Path('scene/index.html').read_text(encoding='utf-8-sig')
        self.assertTrue('b.position.y=b.userData.restY+' in html, 'boat motion must use a stable baseline')
        self.assertNotIn('b.position.y+=', html)

if __name__ == '__main__':
    unittest.main(verbosity=2)
