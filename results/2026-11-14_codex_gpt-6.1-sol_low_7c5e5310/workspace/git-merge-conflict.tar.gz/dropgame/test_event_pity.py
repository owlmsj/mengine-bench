import unittest

from loot import LootTable, PITY_LIMIT


class EventPityIntegrationTest(unittest.TestCase):
    def test_event_rare_resets_pity_and_pity_restarts(self) -> None:
        table = LootTable(event_multiplier=2.0)
        self.assertEqual([table.drop(0.99) for _ in range(PITY_LIMIT - 1)],
                         ["common"] * (PITY_LIMIT - 1))
        self.assertEqual(table.drop(0.08), "rare")
        self.assertEqual([table.drop(0.99) for _ in range(PITY_LIMIT)],
                         ["common"] * PITY_LIMIT)
        self.assertEqual(table.drop(0.99), "rare")
        self.assertEqual(table.drop(0.99), "common")

    def test_event_chance_is_capped(self) -> None:
        self.assertEqual(LootTable(event_multiplier=100.0).drop(0.999), "rare")
