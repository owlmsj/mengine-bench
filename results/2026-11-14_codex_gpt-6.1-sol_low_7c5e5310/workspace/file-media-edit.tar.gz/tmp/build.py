from PIL import Image
from pypdf import PdfReader,PdfWriter
from pypdf.generic import NameObject
import hashlib,json
from pathlib import Path
originals={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ['launch.jpg','permit-form.pdf','event-details.txt']}
im=Image.open('launch.jpg')
im.crop((1400,0,3000,2000)).resize((1080,1350),Image.Resampling.LANCZOS).save('out/feed-photo.jpg',quality=95,subsampling=0)
r=PdfReader('permit-form.pdf'); w=PdfWriter(); w.clone_document_from_reader(r)
values={'organizer':'Tidewater Studio','event_date':'2026-12-05','location':'North Cove Lawn','attendees':'about 40'}
w.update_page_form_field_values(None,values,auto_regenerate=False,flatten=True)
w.remove_annotations(subtypes='/Widget'); w.root_object.pop(NameObject('/AcroForm'),None)
with open('out/permit-filled.pdf','wb') as f:w.write(f)
r=PdfReader('out/permit-filled.pdf')
assert not r.get_fields()
assert not any(a.get_object().get('/Subtype')=='/Widget' for p in r.pages for a in p.get('/Annots',[]))
assert all(v in r.pages[0].extract_text() for v in values.values())
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in originals.items())
print('PASS: JPEG 1080x1350; all four answers present; zero widgets; no form tree; originals unchanged')
import pymupdf
pdf=pymupdf.open('out/permit-filled.pdf'); pdf[0].get_pixmap().save('tmp/permit-preview.png')
Image.open('out/feed-photo.jpg').resize((540,675)).save('tmp/feed-preview.png')
Path('out/verification.txt').write_text('PASS: JPEG 1080x1350; all four answers present; zero widgets; no form tree; originals unchanged\nCrop: (1400, 0, 3000, 2000), proportional resize.\nAnswers: Tidewater Studio | 2026-12-05 | North Cove Lawn | about 40\nOriginal SHA256: '+json.dumps(originals,indent=2))
