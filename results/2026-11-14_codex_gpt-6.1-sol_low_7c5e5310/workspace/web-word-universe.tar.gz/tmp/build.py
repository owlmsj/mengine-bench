import re,json,html,unicodedata,math,random
from pathlib import Path
from urllib.parse import unquote,urlsplit
root=Path(__file__).resolve().parents[1]
pages={p.name.casefold():p.read_text(encoding='utf-8') for p in (root/'site').glob('*.html')}
def plain(s): return html.unescape(re.sub('<[^>]+>','',s)).strip().lower()
entries={}
for filename,body in pages.items():
    if re.search(r'<section\b[^>]*id="(?:sinonimos|analogas)"',body):
        entries[filename]=plain(re.search(r'<h1[^>]*>(.*?)</h1>',body,re.S)[1])
def resolve(href,seen=()):
    name=unquote(urlsplit(html.unescape(href)).path).split('/')[-1].casefold()
    if name in seen:return None
    if name in entries:return entries[name]
    body=pages.get(name,'')
    redirect=re.search(r'url=([^"\s>]+)',body,re.I)
    return resolve(redirect[1],seen+(name,)) if redirect else None
graph={word:set() for word in entries.values()};themes={};pairs=set();missing=set();aliases={}
for filename,word in entries.items():
    body=pages[filename]
    theme=re.search(r'Tema:\s*([^<]+)',body)
    themes[word]=theme[1].strip() if theme else 'outros'
    for section in re.findall(r'<section\b[^>]*id="(?:sinonimos|analogas)"[^>]*>(.*?)</section>',body,re.S):
        for href in re.findall(r'<a\b[^>]*href="([^"]+)"',section):
            target=resolve(href)
            if target and target!=word:
                graph[word].add(target);graph[target].add(word);pairs.add(tuple(sorted((word,target))))
            elif not target:missing.add(href)
for name in pages:
    target=resolve(name)
    if target:aliases[name.removesuffix('.html')]=target
ordered={w:sorted(graph[w]) for w in sorted(graph)}
maximum=max(map(len,graph.values())); leaders=sorted(w for w in graph if len(graph[w])==maximum)
result={'words':len(graph),'relations':len(pairs),'most_connected':leaders[0] if len(leaders)==1 else leaders}
(root/'words.json').write_text(json.dumps(ordered,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(root/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
random.seed(17); words=list(ordered); groups=sorted(set(themes.values())); positions={}
for w in words:
    a=groups.index(themes[w])*2*math.pi/len(groups)
    positions[w]=[math.cos(a)*340+random.uniform(-120,120),math.sin(a)*290+random.uniform(-110,110)]
for iteration in range(260):
    forces={w:[0.,0.] for w in words}
    for i,w in enumerate(words):
        x,y=positions[w]
        for v in words[i+1:]:
            dx=x-positions[v][0];dy=y-positions[v][1];d=max(dx*dx+dy*dy,20);f=1500/d
            forces[w][0]+=dx*f;forces[w][1]+=dy*f;forces[v][0]-=dx*f;forces[v][1]-=dy*f
    for w,v in pairs:
        dx=positions[v][0]-positions[w][0];dy=positions[v][1]-positions[w][1]
        forces[w][0]+=dx*.018;forces[w][1]+=dy*.018;forces[v][0]-=dx*.018;forces[v][1]-=dy*.018
    for w in words:
        for axis in (0,1): positions[w][axis]+=max(-7,min(7,forces[w][axis]-positions[w][axis]*.012))*.65
payload={'graph':ordered,'themes':themes,'positions':positions,'aliases':aliases,'result':result}
template=(root/'tmp/template.html').read_text(encoding='utf-8')
(root/'universe/index.html').write_text(template.replace('__PAYLOAD__',json.dumps(payload,ensure_ascii=False)),encoding='utf-8')
assert sum(map(len,ordered.values()))==2*len(pairs)
assert 'rascunho-3' not in ordered and resolve('saudades.html')=='saudade'
assert all(w in ordered[v] for w in ordered for v in ordered[w])
print(json.dumps(result,ensure_ascii=False));print(f'PASS: symmetric adjacency; {len(pairs)} unique pairs; aliases resolved; {len(missing)} missing targets excluded.')
print('Most connected degree:',maximum); print('Saudade:',', '.join(ordered['saudade']))
