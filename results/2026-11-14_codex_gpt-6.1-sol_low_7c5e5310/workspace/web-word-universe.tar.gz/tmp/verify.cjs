const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync('universe/index.html','utf8');
function element(){return {textContent:'',value:'',style:{setProperty(){}},children:[],replaceChildren(...c){this.children=c},append(...c){this.children.push(...c)},getBoundingClientRect(){return {width:1100,height:850,left:0,top:0}},getContext(){return new Proxy({},{get:()=>()=>{}})},setPointerCapture(){}}}
const elements={};const sandbox={document:{getElementById:id=>elements[id]??=element(),createElement:element},location:{href:'file:///universe/index.html?word=saudade',search:'?word=saudade'},URL,URLSearchParams,devicePixelRatio:1,navigator:{},window:{history:{replaceState(){}},addEventListener(){}}};
vm.createContext(sandbox);vm.runInContext(html.match(/<script>([\s\S]*)<\/script>/)[1],sandbox);
assert.equal(elements.word.textContent,'saudade');
assert.equal(elements.relations.children.length,5);
assert.equal(vm.runInContext("find('ESPERANCA')",sandbox),'esperança');
assert.equal(vm.runInContext("find('saudades')",sandbox),'saudade');
elements.search.value='cafe';elements.search.oninput();assert(elements.suggestions.children.some(x=>x.textContent==='café'));
elements.searchForm.onsubmit({preventDefault(){}});assert.equal(elements.word.textContent,'café');
elements.search.value='xyz-no-match';elements.search.oninput();assert.match(elements.suggestions.textContent,/Nenhuma/);
const graph=JSON.parse(fs.readFileSync('words.json','utf8')),result=JSON.parse(fs.readFileSync('result.json','utf8'));
const pairs=new Set;for(const [w,links]of Object.entries(graph)){assert(!links.includes(w));assert.equal(new Set(links).size,links.length);for(const v of links){assert(graph[v].includes(w));pairs.add([w,v].sort().join('|'))}}
assert.equal(Object.keys(graph).length,result.words);assert.equal(pairs.size,result.relations);
assert(!html.includes('__PAYLOAD__'));assert(!/fetch\(/.test(html));
console.log('PASS: ?word=saudade selects saudade and its 5 relations.');
console.log('PASS: accent-insensitive search, redirect aliases, navigation and empty search state.');
console.log(`PASS: ${result.words} words; ${result.relations} distinct undirected pairs; symmetric, duplicate-free adjacency.`);
console.log('PASS: page script executes with embedded data and no fetch dependency.');
