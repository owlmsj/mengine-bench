Open universe/index.html directly in a browser. No server or build is needed.

Assumptions: only links inside sinonimos and analogas sections are semantic
relations. Relations are undirected; reciprocal references count once. Word
identity comes from the target page h1, lowercased with accents preserved.
Redirect pages resolve to their canonical word. Navigation, missing targets,
self-links and duplicate pairs are excluded. most_connected lists every tie.

Reproduce: python tmp/build.py
Check extraction and page logic: node tmp/verify.cjs
The page embeds the same adjacency as words.json. Colors represent the source
Tema field; spatial proximity is a force-layout aid, not an additional relation.

Browser visual verification was blocked by the browser tool's local-file URL
policy. Automated page logic checks use a mock DOM/canvas, not a browser render.
