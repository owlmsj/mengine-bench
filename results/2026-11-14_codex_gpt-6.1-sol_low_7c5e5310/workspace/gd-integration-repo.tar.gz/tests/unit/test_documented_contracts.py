import json
import tempfile
import unittest
from pathlib import Path

from arena_server.config.defaults import DEFAULTS
from arena_server.config.loader import load_config
from arena_server.economy.payout import match_payout
from arena_server.models.profile import Profile
from arena_server.persistence.codec import decode, encode


class DocumentedContracts(unittest.TestCase):
    def test_environment_overrides_file_for_every_setting(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as scratch:
            config_path = Path(scratch) / "config.json"
            config_path.write_text(json.dumps({key: 2 for key in DEFAULTS}), encoding="utf-8")
            environment = {f"ARENA_{key.upper()}": "3" for key in DEFAULTS}
            actual = load_config(config_path, env=environment)
            self.assertEqual(actual, {key: type(value)(3) for key, value in DEFAULTS.items()})
        self.assertEqual(load_config(env={}), DEFAULTS)

    def test_profile_round_trip_preserves_every_field(self):
        original = Profile("player", level=12, credits=1690, cosmetics=["skin"])
        self.assertEqual(decode(encode(original)), original)
        self.assertEqual(decode('{"name": "old"}'), Profile("old"))

    def test_payout_rounds_decimal_halves_up(self):
        for won in (True, False):
            for raw_base, multiplier, expected in ((1425, 1, 1430), (1585, 1, 1590), (1000, 1.005, 1010)):
                with self.subTest(won=won, base=raw_base, multiplier=multiplier):
                    config = dict(DEFAULTS, win_base=raw_base, loss_base=raw_base,
                                  event_multiplier=multiplier)
                    self.assertEqual(match_payout(won, 0, config), expected)


if __name__ == "__main__":
    unittest.main()
