$ErrorActionPreference = 'Stop'
$arenaRoot = Split-Path $PSScriptRoot -Parent
$arenaHeader = Get-Content (Join-Path $arenaRoot 'Source/PixelArena/ArenaGameMode.h') -Raw
$arenaConfig = Get-Content (Join-Path $arenaRoot 'Config/DefaultGame.ini') -Raw
$arenaFailures = @()
if ($arenaHeader -notmatch '(?s)UPROPERTY\s*\([^)]*\)\s*TObjectPtr<UArenaScoreTracker>\s+ScoreTracker\s*;') {
    $arenaFailures += 'FAIL: ScoreTracker must be a reflected strong UObject reference.'
}
if ($arenaConfig -notmatch '(?m)^\+DirectoriesToAlwaysCook=\(Path="/Game/Data/Palettes"\)\s*$') {
    $arenaFailures += 'FAIL: Packaging must always cook /Game/Data/Palettes.'
}
if ($arenaFailures.Count -gt 0) {
    $arenaFailures | Write-Output
    exit 1
}
Write-Output 'PASS: ScoreTracker is a reflected strong UObject reference.'
Write-Output 'PASS: Packaging always cooks /Game/Data/Palettes.'
