import json
import unittest

import gen


class HarnessModelTests(unittest.TestCase):
    def test_model_settings_and_generated_configs(self) -> None:
        expected = [
            {"name": "fast-coder", "context_window": 262144, "max_output": 16384, "tool_calling": True},
            {"name": "deep-thinker", "context_window": 200000, "max_output": 32768, "tool_calling": True},
            {"name": "tiny-chat", "context_window": 32768, "max_output": 4096, "tool_calling": False},
        ]
        actual = json.loads((gen.ROOT / "models.json").read_text(encoding="utf-8"))["models"]
        self.assertEqual(actual, expected)
        for filename, render in (
            ("opencode.json", gen.opencode),
            ("codex.toml", gen.codex),
            ("claude.json", gen.claude),
        ):
            with self.subTest(filename=filename):
                self.assertEqual(
                    (gen.ROOT / "out" / filename).read_text(encoding="utf-8"),
                    render(expected),
                )


if __name__ == "__main__":
    unittest.main()
