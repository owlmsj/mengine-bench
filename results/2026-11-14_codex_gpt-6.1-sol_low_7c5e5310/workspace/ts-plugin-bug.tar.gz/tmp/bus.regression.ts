import { test } from 'node:test';
import assert from 'node:assert/strict';
import { HookBus } from '../src/bus.ts';
import { registerAuditPlugin } from '../src/plugin.ts';

test('awaits handlers in order and completes after the last handler', async () => {
  const bus = new HookBus();
  const seen: number[] = [];
  bus.on('event', async () => { await new Promise(resolve => setTimeout(resolve, 5)); seen.push(1); });
  bus.on('event', () => { seen.push(2); });
  await bus.emit('event', null);
  assert.deepEqual(seen, [1, 2]);
});

test('snapshot survives removals and defers additions until the next emit', async () => {
  const bus = new HookBus();
  const seen: string[] = [];
  const off = bus.on('event', () => { seen.push('first'); off(); removeSecond(); bus.on('event', () => { seen.push('new'); }); });
  const removeSecond = bus.on('event', () => { seen.push('second'); });
  await bus.emit('event', null);
  assert.deepEqual(seen, ['first', 'second']);
  await bus.emit('event', null);
  assert.deepEqual(seen, ['first', 'second', 'new']);
});

for (const asynchronous of [false, true]) {
  test(`propagates the same error and stops subsequent handlers: async=${asynchronous}`, async () => {
    const bus = new HookBus();
    const failure = new Error('hook failed');
    let laterRan = false;
    bus.on('event', asynchronous ? async () => { throw failure; } : () => { throw failure; });
    bus.on('event', () => { laterRan = true; });
    await assert.rejects(bus.emit('event', null), error => error === failure);
    assert.equal(laterRan, false);
  });
}

test('audit plugin redacts before logging and notices only once', async () => {
  const bus = new HookBus();
  const audit: string[] = [];
  registerAuditPlugin(bus, audit);
  await bus.emit('tool.after', { tool: 'read', output: 'password=secret' });
  await bus.emit('tool.after', { tool: 'write', output: 'password=other' });
  assert.deepEqual(audit, ['notice: tool output is audited', 'read: password=[redacted]', 'write: password=[redacted]']);
});
