import json, struct
from pathlib import Path

source = Path('prices.db').read_bytes()
def varint(offset):
    value = 0
    for index in range(9):
        octet = source[offset + index]
        value = (value << (8 if index == 8 else 7)) | (octet if index == 8 else octet & 127)
        if index == 8 or octet < 128:
            return value, offset + index + 1
    raise ValueError('Invalid SQLite varint')

def decode_record(start):
    payload_size, cursor = varint(start)
    rowid, cursor = varint(cursor)
    payload_start = cursor
    payload_end = cursor + payload_size
    assert payload_end <= len(source), (start, payload_end)
    header_size, cursor = varint(cursor)
    header_end = payload_start + header_size
    serials = []
    while cursor < header_end:
        serial, cursor = varint(cursor)
        serials.append(serial)
    assert cursor == header_end
    cursor = header_end
    values = []
    for serial in serials:
        if serial == 0:
            values.append(None)
            continue
        if serial in (8, 9):
            values.append(serial - 8)
            continue
        if 1 <= serial <= 6:
            width = (1, 2, 3, 4, 6, 8)[serial - 1]
        elif serial == 7:
            width = 8
        elif serial >= 12:
            width = (serial - 12) // 2
        else:
            raise ValueError(f'Unexpected serial type {serial}')
        raw = source[cursor:cursor + width]
        assert len(raw) == width
        cursor += width
        if serial <= 6:
            value = int.from_bytes(raw, 'big', signed=True)
        elif serial == 7:
            value = struct.unpack('>d', raw)[0]
        elif serial % 2:
            value = raw.decode('utf-8')
        else:
            value = raw.hex()
        values.append(value)
    assert cursor == payload_end
    assert len(values) == 3 and values[0] is None
    assert isinstance(values[1], str) and type(values[2]) in (int, float)
    return rowid, {'item': values[1], 'price': values[2]}, (start, payload_end)

assert source[0] == 13
count = int.from_bytes(source[3:5], 'big')
rows = []
spans = []
for index in range(count):
    offset = int.from_bytes(source[8 + 2*index:10 + 2*index], 'big')
    rowid, row, span = decode_record(offset)
    rows.append(row)
    spans.append(span)
    print(f'rowid={rowid} bytes=[{span[0]},{span[1]}) {json.dumps(row, ensure_ascii=False)}')
ordered = sorted(spans)
assert all(left[1] == right[0] for left, right in zip(ordered, ordered[1:]))
assert ordered[0][0] == int.from_bytes(source[5:7], 'big') and ordered[-1][1] == len(source)
Path('recovered.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
assert json.loads(Path('recovered.json').read_text(encoding='utf-8')) == rows
print(f'PASS: {len(rows)} complete records; all payload bytes consumed; cells contiguous through EOF; JSON round-trip matches.')
