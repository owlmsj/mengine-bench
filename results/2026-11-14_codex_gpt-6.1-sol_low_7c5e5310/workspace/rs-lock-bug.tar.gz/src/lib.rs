//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

#[derive(Default)]
struct Scores {
    players: HashMap<PlayerId, i64>,
    total: i64,
}

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    scores: Arc<Mutex<Scores>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    /// Inserts a player, replacing any previous score for that player.
    pub fn join(&self, id: PlayerId, score: i64) {
        let mut scores = self.scores.lock().unwrap();
        let previous = scores.players.insert(id, score).unwrap_or(0);
        scores.total -= previous;
        scores.total += score;
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let mut scores = self.scores.lock().unwrap();
        *scores.players.get_mut(&id).unwrap() += points;
        scores.total += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let mut scores = self.scores.lock().unwrap();
        // Resolve both players before mutating either score.
        let from_score = scores.players[&from];
        let to_score = scores.players[&to];
        if from == to {
            return;
        }
        scores.players.insert(from, from_score - points);
        scores.players.insert(to, to_score + points);
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        self.scores.lock().unwrap().players[&id]
    }

    pub fn total(&self) -> i64 {
        self.scores.lock().unwrap().total
    }
}
#[cfg(test)]
mod regression_tests {
    use super::Board;
    use std::sync::{mpsc, Barrier};
    use std::thread;
    use std::time::Duration;

    #[test]
    fn self_transfer_finishes_without_changing_scores() {
        let board = Board::new();
        board.join(1, 10);
        let (finished, received) = mpsc::channel();
        thread::spawn(move || {
            board.transfer(1, 1, 7);
            finished.send((board.score(1), board.total())).unwrap();
        });
        assert_eq!(
            received.recv_timeout(Duration::from_secs(2)).unwrap(),
            (10, 10)
        );
    }

    #[test]
    fn concurrent_awards_keep_every_point() {
        let board = Board::new();
        board.join(1, 0);
        let barrier = std::sync::Arc::new(Barrier::new(8));
        let workers: Vec<_> = (0..8)
            .map(|_| {
                let board = board.clone();
                let barrier = barrier.clone();
                thread::spawn(move || {
                    barrier.wait();
                    for _ in 0..10_000 {
                        board.award(1, 1);
                    }
                })
            })
            .collect();
        for worker in workers {
            worker.join().unwrap();
        }
        assert_eq!((board.score(1), board.total()), (80_000, 80_000));
    }

    #[test]
    fn opposite_transfers_finish_and_preserve_scores() {
        let board = Board::new();
        board.join(1, 10);
        board.join(2, 20);
        let barrier = std::sync::Arc::new(Barrier::new(2));
        let (finished, received) = mpsc::channel();
        for (from, to) in [(1, 2), (2, 1)] {
            let board = board.clone();
            let barrier = barrier.clone();
            let finished = finished.clone();
            thread::spawn(move || {
                barrier.wait();
                for _ in 0..10_000 {
                    board.transfer(from, to, 1);
                }
                finished.send(()).unwrap();
            });
        }
        for _ in 0..2 {
            received.recv_timeout(Duration::from_secs(5)).unwrap();
        }
        assert_eq!(
            (board.score(1), board.score(2), board.total()),
            (10, 20, 30)
        );
    }

    #[test]
    fn repeated_join_replaces_score_and_adjusts_total() {
        let board = Board::new();
        board.join(1, 10);
        board.join(2, 20);
        board.join(1, 7);
        assert_eq!((board.score(1), board.total()), (7, 27));
    }
}
