import json
import sqlite3
from fractions import Fraction

STEPS = ('install', 'tutorial_complete', 'first_match', 'purchase')
connection = sqlite3.connect('analytics.db')
players = connection.execute('SELECT user_id, platform FROM users WHERE is_test = 0').fetchall()
funnel = {platform: dict.fromkeys(STEPS, 0) for _, platform in players}
for user_id, platform in players:
    previous = None
    for step in STEPS:
        timestamp = connection.execute(
            'SELECT MIN(ts) FROM events WHERE user_id = ? AND name = ? AND (? IS NULL OR ts >= ?)',
            (user_id, step, previous, previous),
        ).fetchone()[0]
        if timestamp is None:
            break
        funnel[platform][step] += 1
        previous = timestamp
biggest_drop = {}
for platform, counts in funnel.items():
    eligible = [i for i in range(1, len(STEPS)) if counts[STEPS[i-1]]]
    biggest_drop[platform] = min(eligible, key=lambda i: Fraction(counts[STEPS[i]], counts[STEPS[i-1]])) if eligible else None
    if biggest_drop[platform] is not None:
        biggest_drop[platform] = STEPS[biggest_drop[platform]]
result = {'funnel': funnel, 'biggest_drop': biggest_drop}
with open('result.json', 'w', encoding='utf-8') as output:
    json.dump(result, output, indent=2)
    output.write('\n')
# Independent relational computation verifies the per-player traversal.
query = '''
WITH installs AS (
 SELECT u.user_id, u.platform, MIN(e.ts) AS ts FROM users u
 JOIN events e ON e.user_id=u.user_id AND e.name='install'
 WHERE u.is_test=0 GROUP BY u.user_id,u.platform
), tutorials AS (
 SELECT i.user_id,i.platform,MIN(e.ts) AS ts FROM installs i
 JOIN events e ON e.user_id=i.user_id AND e.name='tutorial_complete' AND e.ts>=i.ts
 GROUP BY i.user_id,i.platform
), matches AS (
 SELECT t.user_id,t.platform,MIN(e.ts) AS ts FROM tutorials t
 JOIN events e ON e.user_id=t.user_id AND e.name='first_match' AND e.ts>=t.ts
 GROUP BY t.user_id,t.platform
), purchases AS (
 SELECT m.user_id,m.platform,MIN(e.ts) AS ts FROM matches m
 JOIN events e ON e.user_id=m.user_id AND e.name='purchase' AND e.ts>=m.ts
 GROUP BY m.user_id,m.platform
)
SELECT platform,'install',COUNT(*) FROM installs GROUP BY platform
UNION ALL SELECT platform,'tutorial_complete',COUNT(*) FROM tutorials GROUP BY platform
UNION ALL SELECT platform,'first_match',COUNT(*) FROM matches GROUP BY platform
UNION ALL SELECT platform,'purchase',COUNT(*) FROM purchases GROUP BY platform
'''
independent = {platform: dict.fromkeys(STEPS,0) for platform in funnel}
for platform, step, count in connection.execute(query):
    independent[platform][step] = count
assert independent == funnel, (independent, funnel)
assert json.load(open('result.json', encoding='utf-8')) == result
print('PASS: independent SQL funnel equals per-player computation; result.json round-trip verified.')
print(json.dumps(result, indent=2))
for platform, counts in funnel.items():
    for i in range(1,len(STEPS)):
        before, after = counts[STEPS[i-1]], counts[STEPS[i]]
        print(f'{platform}: {STEPS[i-1]} -> {STEPS[i]}: {before} -> {after}; lost {before-after}; conversion {after/before:.6%}')
