# How we report the funnel

Steps, in order: install, tutorial_complete, first_match, purchase.
A step counts only at or after the same player's previous step, with no time limit; its time is the first valid occurrence.
Test accounts and events from unknown players do not count.
A step's conversion is its players over the previous step's players. The biggest drop is the step with the lowest conversion.
