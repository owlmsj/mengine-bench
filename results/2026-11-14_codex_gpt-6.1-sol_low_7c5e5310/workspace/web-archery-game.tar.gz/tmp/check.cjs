const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync('game/index.html','utf8').match(/<script>([\s\S]*?)<\/script>/)[1];
const elements=new Map(),listeners={};
const context2d=new Proxy({createLinearGradient:()=>({addColorStop(){}})},{get:(obj,key)=>obj[key]||(()=>{})});
function element(id){if(!elements.has(id))elements.set(id,{textContent:'',classList:{add(){},remove(){}},getContext:()=>context2d,addEventListener:(name,fn)=>listeners[name]=fn,setPointerCapture(){},getBoundingClientRect:()=>({left:0,top:0,width:1200,height:566})});return elements.get(id)}
const sandbox={document:{getElementById:element,querySelector:element},window:{},requestAnimationFrame(){},setTimeout(){},console,Math};vm.createContext(sandbox);vm.runInContext(source,sandbox);
const run=s=>vm.runInContext(s,sandbox);
run('begin();tick(0);');assert.equal(run('mode'),'playing');assert.equal(run('remaining'),60);
listeners.pointerdown({clientX:173,clientY:365,pointerId:1});listeners.pointermove({clientX:38,clientY:365});listeners.pointerup();assert.equal(run('arrows.length'),1);assert(run('arrows[0].vx')>900);console.log('PASS pointer drag/release launches a powered arrow');
run('balloons=[{x:200,y:365,r:30,speed:0,phase:0,gold:false,color:"red"}];tick(32)');assert.equal(run('score'),10);assert.equal(run('balloons.length'),0);assert(run('particles.length')>0);console.log('PASS swept collision pops balloon, awards 10 points and emits confetti');
run('balloons=[{x:225,y:365,r:30,speed:0,phase:0,gold:true,color:"gold"}];tick(48)');assert.equal(run('score'),45);console.log('PASS gold balloon and consecutive-hit bonus award 35 points');
run('balloons=Array.from({length:5},()=>({x:600,y:-46,r:25,speed:0,phase:0}));tick(64)');assert.equal(run('mode'),'over');assert.equal(run('escaped'),5);console.log('PASS five escaped balloons end the round');
run('begin()');assert.equal(run('score'),0);assert.equal(run('escaped'),0);assert.equal(run('arrows.length'),0);console.log('PASS restart resets score, escapes and arrows');
run('elapsed=59.99;tick(96)');assert.equal(run('mode'),'over');console.log('PASS surviving 60 seconds completes the level');
run('begin();remaining=59.99;hud()');assert.equal(element('time').textContent,'1:00');console.log('PASS timer rounds correctly at minute boundary');

