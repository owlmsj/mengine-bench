import csv,json,math,collections
from pathlib import Path
rows=list(csv.DictReader(Path('telemetry/playtest_ab.csv').open(newline='',encoding='utf-8-sig')))
unique={}
for row in rows:
    row['variant']=row['variant'].strip().upper()
    assert row['variant'] in ('A','B'), 'Invalid variant'
    assert row['completed_tutorial'] in ('0','1'), 'Invalid completion'
    key=row['session_id']
    if key in unique:
        assert row==unique[key], 'Conflicting duplicate session'
    unique[key]=row
counts={v:[r for r in unique.values() if r['variant']==v] for v in ('A','B')}
n_a,n_b=[len(counts[v]) for v in ('A','B')]
x_a,x_b=[sum(int(r['completed_tutorial']) for r in counts[v]) for v in ('A','B')]
p_a,p_b=x_a/n_a,x_b/n_b
pooled=(x_a+x_b)/(n_a+n_b)
se=math.sqrt(pooled*(1-pooled)*(1/n_a+1/n_b))
z=(p_b-p_a)/se
p_value=math.erfc(abs(z)/math.sqrt(2))
result=dict(ship_b=p_b>p_a and p_value<0.05,sessions_a=n_a,sessions_b=n_b,completion_rate_a=p_a,completion_rate_b=p_b,p_value=p_value)
Path('result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
players=collections.defaultdict(list)
for r in unique.values(): players[r['player_id']].append(r)
repeat=sum(len(rs)>1 for rs in players.values())
crossover=sum(len({r['variant'] for r in rs})>1 for rs in players.values())
print(json.dumps(dict(raw_rows=len(rows),unique_sessions=len(unique),duplicate_rows=len(rows)-len(unique),completed_a=x_a,completed_b=x_b,players=len(players),repeat_players=repeat,crossover_players=crossover,z=z,result=result),indent=2))
# Player-clustered sensitivity: variance of the difference in session means.
scores=[]
for rs in players.values():
    scores.append(sum((int(r['completed_tutorial'])-(p_b if r['variant']=='B' else p_a))*(1/n_b if r['variant']=='B' else -1/n_a) for r in rs))
g=len(players)
cluster_se=math.sqrt(sum(s*s for s in scores)*g/(g-1)*(n_a+n_b-1)/(n_a+n_b-2))
cluster_z=(p_b-p_a)/cluster_se
cluster_p=math.erfc(abs(cluster_z)/math.sqrt(2))
ci=((p_b-p_a)-1.96*cluster_se,(p_b-p_a)+1.96*cluster_se)
# Independent arithmetic check of the uncorrected Pearson chi-square statistic.
observed=((x_a,n_a-x_a),(x_b,n_b-x_b))
expected=((n_a*pooled,n_a*(1-pooled)),(n_b*pooled,n_b*(1-pooled)))
chi=sum((observed[i][j]-expected[i][j])**2/expected[i][j] for i in range(2) for j in range(2))
assert abs(chi-z*z)<1e-10
assert json.loads(Path('result.json').read_text())==result
assert n_a+n_b==len(unique)
report=f'''Recommendation: ship B under the documented completion-only release rule.

A: {x_a}/{n_a} = {p_a:.8%}; B: {x_b}/{n_b} = {p_b:.8%}.
Absolute gain: {(p_b-p_a)*100:.6f} percentage points.
Relative gain: {(p_b/p_a-1)*100:.6f}%.
Two-sided pooled two-proportion z-test: z={z:.12f}, p={p_value:.15g}.
result.json p_value is this session-level test, with no continuity correction.

Cleaning: {len(rows)} exported rows, {len(unique)} unique session IDs, {len(rows)-len(unique)} duplicate rows removed.
Strip whitespace and uppercase variant; all outcomes binary; duplicate session records agree after normalization.

Dependence sensitivity: {g} players; {repeat} repeated players; {crossover} players appear in both arms.
Player-clustered sandwich standard error (finite-cluster and residual-df corrections): {cluster_se:.12f}.
Two-sided normal-reference clustered p={cluster_p:.15g}.
Clustered approximate 95% CI for B minus A: [{ci[0]*100:.6f}, {ci[1]*100:.6f}] percentage points.
This sensitivity preserves the conclusion at 5% while allowing arbitrary within-player session correlation.

Assumptions: session completion is the target metric; the two-sided test and alpha=0.05 are chosen without outcome-driven alternatives; no multiplicity or sequential-peeking adjustment because no other planned comparisons/stopping rules are supplied. The notes do not establish random assignment, exposure order, or absence of carryover. Causal interpretation assumes comparable assignment and no systematic carryover; player clustering addresses correlation, not confounding. Match minutes is not a stated release criterion. No claim is made about retention, harms, or other release guardrails.

Verification: all input validation assertions passed; Pearson chi-square independently matches z squared; saved JSON reread matches calculated values. Source: telemetry/README.md and telemetry/playtest_ab.csv. Reproduce with python analyze.py. No browser tabs, windows, or apps were opened.
'''
Path('analysis.txt').write_text(report,encoding='utf-8')
print(f'Player-clustered p_value={cluster_p:.15g}; 95% CI=[{ci[0]*100:.6f}, {ci[1]*100:.6f}] percentage points')
print('PASS: input validation, independent Pearson identity, saved JSON round-trip')
print(Path('result.json').read_text())
