//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

#[derive(Default)]
struct BoardState {
    players: HashMap<PlayerId, i64>,
    total: i64,
}

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    state: Arc<Mutex<BoardState>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        let mut state = self.state.lock().unwrap();
        let previous = state.players.insert(id, score).unwrap_or(0);
        state.total += score - previous;
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let mut state = self.state.lock().unwrap();
        *state.players.get_mut(&id).unwrap() += points;
        state.total += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let mut state = self.state.lock().unwrap();
        let _ = state.players[&from];
        let _ = state.players[&to];
        if from == to {
            return;
        }
        *state.players.get_mut(&from).unwrap() -= points;
        *state.players.get_mut(&to).unwrap() += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        self.state.lock().unwrap().players[&id]
    }

    pub fn total(&self) -> i64 {
        self.state.lock().unwrap().total
    }
}

#[cfg(test)]
mod regression_tests {
    use super::Board;
    use std::sync::mpsc;
    use std::time::Duration;

    #[test]
    fn concurrent_awards_are_not_lost() {
        let board = Board::new();
        board.join(1, 0);
        let threads: Vec<_> = (0..8).map(|_| {
            let board = board.clone();
            std::thread::spawn(move || for _ in 0..1000 { board.award(1, 1); })
        }).collect();
        for thread in threads { thread.join().unwrap(); }
        assert_eq!((board.score(1), board.total()), (8000, 8000));
    }

    #[test]
    fn transfers_complete_and_rejoin_updates_total() {
        let board = Board::new();
        board.join(1, 10);
        board.join(2, 20);
        board.join(1, 5);
        assert_eq!(board.total(), 25);
        let (send, receive) = mpsc::channel();
        std::thread::spawn(move || {
            board.transfer(1, 1, 3);
            let first = board.clone();
            let second = board.clone();
            let a = std::thread::spawn(move || for _ in 0..1000 { first.transfer(1, 2, 1); });
            let b = std::thread::spawn(move || for _ in 0..1000 { second.transfer(2, 1, 1); });
            a.join().unwrap();
            b.join().unwrap();
            send.send((board.score(1), board.score(2), board.total())).unwrap();
        });
        assert_eq!(receive.recv_timeout(Duration::from_secs(2)).unwrap(), (5, 20, 25));
    }
}
