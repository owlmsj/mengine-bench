
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js';
const scene=new THREE.Scene(); scene.background=new THREE.Color('#e5d5b2');
const camera=new THREE.OrthographicCamera(-8,8,5.375,-5.375,.1,100); camera.position.set(0,0,30); camera.lookAt(0,0,0);
const renderer=new THREE.WebGLRenderer({antialias:true}); renderer.setPixelRatio(Math.min(devicePixelRatio,2)); renderer.setSize(innerWidth,innerHeight); renderer.outputColorSpace=THREE.SRGBColorSpace; document.body.prepend(renderer.domElement);
const ink=0x123d59, deep=0x10486b, blue=0x17688b, mid=0x4290a4, pale=0xb8d9d2, foam=0xf5f0dd, sand=0xe7d6b3, wood=0xd9a779;
function poly(points,color,z,parent=scene){const shape=new THREE.Shape(); points.forEach(([x,y],i)=>i?shape.lineTo(x,y):shape.moveTo(x,y)); shape.closePath(); const mesh=new THREE.Mesh(new THREE.ShapeGeometry(shape),new THREE.MeshBasicMaterial({color,side:THREE.DoubleSide}));mesh.position.z=z;parent.add(mesh);return mesh}
function line(points,color,z,width=1,parent=scene){const geom=new THREE.BufferGeometry().setFromPoints(points.map(([x,y])=>new THREE.Vector3(x,y,z)));const obj=new THREE.Line(geom,new THREE.LineBasicMaterial({color,linewidth:width}));parent.add(obj);return obj}
function circle(x,y,r,color,z,parent=scene,n=7){const m=new THREE.Mesh(new THREE.CircleGeometry(r,n),new THREE.MeshBasicMaterial({color}));m.position.set(x,y,z);parent.add(m);return m}
// Distant atmosphere and the small sacred peak.
poly([[-8,-1.15],[-5,-1.35],[-2,-1.6],[1,-1.45],[4,-1.5],[8,-1.05],[8,-5.4],[-8,-5.4]],0xa7aa9e,-8);
poly([[1.05,-2.7],[2.35,-1.04],[3.72,-2.72]],ink,-5);
poly([[1.05,-2.7],[2.35,-1.04],[3.72,-2.72],[2.8,-2.4],[2.58,-2.15],[2.43,-2.32],[2.23,-1.99],[2.05,-2.28],[1.86,-2.16],[1.65,-2.49]],foam,-4.9);
line([[1.05,-2.7],[2.35,-1.04],[3.72,-2.72]],ink,-4.8);
// Great curling wave: angular surfaces build a hollow, overhanging crest.
const wave=new THREE.Group();scene.add(wave);
poly([[-8,-4.7],[-8,-.3],[-7.1,-.08],[-6.1,.52],[-5.15,1.35],[-4.2,2.18],[-3.18,2.95],[-2.1,3.53],[-1.2,3.82],[-.37,3.86],[.28,3.63],[.58,3.17],[.45,2.82],[-.05,2.55],[-.85,2.42],[-1.67,2.05],[-2.24,1.47],[-2.42,.77],[-2.35,.02],[-2.0,-.7],[-1.37,-1.44],[-.6,-2.02],[.45,-2.53],[1.1,-3.8]],foam,0,wave);
poly([[-8,-4.7],[-8,-1.04],[-7.24,-1.34],[-6.36,-1.32],[-5.49,-1.04],[-4.83,-.53],[-4.34,.15],[-4.17,.84],[-3.92,1.61],[-3.46,2.28],[-2.82,2.67],[-2.05,2.74],[-1.48,2.6],[-.98,2.36],[-1.55,2.03],[-1.94,1.57],[-2.21,.95],[-2.18,.24],[-1.97,-.55],[-1.48,-1.22],[-.85,-1.85],[.5,-2.6],[1.1,-3.8]],ink,.1,wave);
poly([[-7.8,-4],[-6.7,-2.5],[-5.8,-1.8],[-5.2,-.95],[-4.62,.1],[-4.34,1.03],[-3.99,1.91],[-3.44,2.48],[-2.91,2.6],[-3.38,2.04],[-3.6,1.3],[-3.78,.42],[-4.14,-.6],[-4.7,-1.55],[-5.75,-2.65]],blue,.2,wave);
poly([[-6.35,-3.7],[-5.33,-2.48],[-4.76,-1.46],[-4.37,-.35],[-4.09,.83],[-3.74,1.77],[-3.24,2.36],[-2.79,2.5],[-3.14,1.87],[-3.35,1.03],[-3.56,-.12],[-4.04,-1.36],[-4.75,-2.55]],deep,.22,wave);
poly([[-4.55,-3.3],[-3.79,-2.16],[-3.34,-1.09],[-3.13,.02],[-2.99,1.11],[-2.72,1.88],[-2.31,2.36],[-1.91,2.48],[-2.28,1.73],[-2.51,.78],[-2.47,-.18],[-2.13,-1.14],[-1.46,-2.02]],blue,.25,wave);
// White, claw-like foam fingers along the lip.
const claws=[[-3.85,2.0,.42],[-3.48,2.35,.42],[-3.1,2.56,.45],[-2.72,2.7,.46],[-2.3,2.75,.48],[-1.9,2.69,.48],[-1.51,2.53,.46],[-1.14,2.34,.47],[-.77,2.15,.48],[-.43,1.91,.43],[-.12,1.65,.38],[.17,1.37,.35]];
for(const [x,y,s] of claws){poly([[x-s*.6,y-s*.4],[x-s*.55,y+s*.25],[x-s*.2,y+s*.6],[x+s*.25,y+s*.62],[x+s*.65,y+s*.3],[x+s*.75,y-.06],[x+s*.46,y+s*.12],[x+s*.2,y+s*.3],[x-.02,y+s*.18],[x-s*.08,y-s*.25]],foam,.5,wave);line([[x-s*.6,y-s*.4],[x-s*.55,y+s*.25],[x-s*.2,y+s*.6],[x+s*.25,y+s*.62],[x+s*.65,y+s*.3]],ink,.51,1,wave)}
// Angular flecks and spray, deterministic for reproducibility.
let seed=24;function rand(){seed=(seed*16807)%2147483647;return (seed-1)/2147483646}
for(let i=0;i<140;i++){let x=-6.8+rand()*5.2,y=-2.5+rand()*4.9;if(x>-4.4 && y>-.4 && y<2.7 || x<-4.4 && y<.2)circle(x,y,.025+rand()*.045,foam,.55,wave,5)}
for(let i=0;i<50;i++){const x=-1.35+rand()*3.4,y=-1.55+rand()*3.2;circle(x,y,.018+rand()*.045,foam,.6,wave,5)}
// Three long fishing boats with tiny bent figures.
function boat(x,y,scale,angle){const g=new THREE.Group();g.position.set(x,y,2);g.rotation.z=angle;g.scale.setScalar(scale);scene.add(g);poly([[-2.2,.18],[-1.85,-.2],[-1.25,-.38],[1.3,-.38],[1.85,-.12],[2.25,.25],[1.65,.04],[-1.7,.04]],wood,0,g);line([[-2.2,.18],[-1.85,-.2],[-1.25,-.38],[1.3,-.38],[1.85,-.12],[2.25,.25]],ink,.02,1,g);line([[-1.65,-.12],[1.55,-.12]],ink,.03,1,g);for(let i=0;i<7;i++){let xx=-.8+i*.3;circle(xx,.12,.105,ink,.08,g,6);circle(xx,.19,.065,0xe8c8a0,.09,g,6)}for(let i=0;i<8;i++)line([[-1.5+i*.19,-.08],[-1.35+i*.19,-.3]],ink,.04,1,g);return g}
const boats=[boat(-5.65,-2.12,.68,-.37),boat(3.1,-2.45,.92,.21),boat(1.0,-4.0,1.17,-.15)];
// Layered foreground swells frame the boats and reinforce the print's diagonal rhythm.
const sea=new THREE.Group();scene.add(sea);
poly([[-8,-4.1],[-7,-3.63],[-6.1,-3.58],[-5.3,-3.15],[-4.5,-2.76],[-3.85,-2.18],[-3.35,-1.74],[-2.9,-1.77],[-2.33,-2.18],[-1.6,-2.75],[-.7,-3.25],[.35,-3.55],[1.7,-3.65],[3,-3.5],[4.5,-3.06],[6,-2.22],[8,-.9],[8,-5.4],[-8,-5.4]],foam,1,sea);
poly([[-8,-4.8],[-7,-4.5],[-5.9,-4.18],[-4.9,-3.86],[-4.05,-3.38],[-3.46,-2.87],[-2.95,-2.54],[-2.52,-2.72],[-1.9,-3.17],[-.8,-3.72],[.5,-4.03],[2,-4.05],[3.4,-3.8],[4.9,-3.3],[6.5,-2.5],[8,-1.45],[8,-5.4],[-8,-5.4]],pale,1.1,sea);
poly([[-8,-5.4],[-8,-4.55],[-7.2,-4.35],[-6.5,-4.42],[-5.6,-4.12],[-4.85,-4.18],[-4.08,-3.85],[-3.4,-3.4],[-2.95,-3.12],[-2.48,-3.42],[-1.8,-3.87],[-.75,-4.32],[.5,-4.55],[1.8,-4.51],[3.5,-4.18],[5.4,-3.5],[6.85,-2.72],[8,-1.95],[8,-5.4]],deep,1.2,sea);
poly([[-8,-5.4],[-8,-4.85],[-6.7,-4.72],[-5.4,-4.62],[-4.15,-4.24],[-3.3,-3.78],[-2.9,-3.67],[-2.25,-4.05],[-1.4,-4.47],[-.2,-4.75],[1.2,-4.83],[3,-4.6],[4.7,-4.11],[6.5,-3.35],[8,-2.45],[8,-5.4]],foam,1.3,sea);
for(let i=0;i<5;i++){let yy=-4.86+i*.32;poly([[4.1+i*.4,yy],[5.1+i*.25,yy+.13],[6.45+i*.15,yy+.48],[8,yy+1.05],[8,yy+.75],[6.6,yy+.27],[5.3,yy+.02]],i%2?blue:ink,1.4,sea)}
// Forward boat sits above foreground water.
boats[2].position.z=3;
// Foam on the left foreground.
for(let i=0;i<18;i++){let x=-7.9+i*.28,y=-4.75+Math.sin(i*1.4)*.22;poly([[x,y],[x+.04,y+.52],[x+.18,y+.72],[x+.34,y+.65],[x+.38,y+.42],[x+.22,y+.52],[x+.15,y+.35],[x+.17,y]],i%3?ink:blue,1.5,sea);circle(x+.2,y+.66,.075,foam,1.6,sea,5)}
function resize(){const aspect=innerWidth/innerHeight,base=10.75;if(aspect>16/10.75){camera.left=-base*aspect/2;camera.right=base*aspect/2;camera.top=base/2;camera.bottom=-base/2}else{camera.left=-8;camera.right=8;camera.top=8/aspect;camera.bottom=-8/aspect}camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)}
addEventListener('resize',resize);resize();
const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
function animate(t){const time=t*.001;if(!reduced){wave.position.y=Math.sin(time*.45)*.045;sea.position.y=Math.sin(time*.55+.7)*.035;boats.forEach((b,i)=>{b.position.y=[-2.12,-2.45,-4][i]+Math.sin(time*.8+i)*.035;b.rotation.z=[-.37,.21,-.15][i]+Math.sin(time*.7+i)*.012})}renderer.render(scene,camera);requestAnimationFrame(animate)}requestAnimationFrame(animate);

