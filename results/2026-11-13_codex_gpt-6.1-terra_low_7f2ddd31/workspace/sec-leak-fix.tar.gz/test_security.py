import logging
import os
import tarfile
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import backup_agent


class SecurityTest(unittest.TestCase):
    def test_form_path_is_archived_without_executing_it(self):
        with tempfile.TemporaryDirectory(dir=".") as temporary:
            folder = Path(temporary) / "folder & echo injected"
            folder.mkdir()
            (folder / "file.txt").write_text("contents", encoding="utf-8")
            with mock.patch.object(backup_agent, "send_archive", return_value=200) as sent:
                with mock.patch.dict(os.environ, {"BACKUP_TOKEN": "[REDACTED:env]"}):
                    self.assertEqual(backup_agent.handle_form({"folder": str(folder)}), 200)
            archive_path = sent.call_args.args[0]
            try:
                with tarfile.open(archive_path) as archive:
                    self.assertIn(folder.name + "/file.txt", archive.getnames())
            finally:
                archive_path.unlink()

    def test_upload_reads_environment_without_logging_token(self):
        with mock.patch.dict(os.environ, {"BACKUP_TOKEN": "[REDACTED:env]"}):
            with mock.patch.object(backup_agent, "send_archive", return_value=201) as sent:
                with mock.patch.object(logging.Logger, "_log") as logged:
                    self.assertEqual(backup_agent.upload(Path("archive")), 201)
        self.assertEqual(sent.call_args.args[2], "test-token")
        logged.assert_not_called()


if __name__ == "__main__":
    unittest.main()
