import json
import tempfile
import unittest
from pathlib import Path

from arena_server.config.loader import load_config
from arena_server.economy.payout import match_payout
from arena_server.models.profile import Profile
from arena_server.persistence.codec import decode, encode


class DocumentedBehavior(unittest.TestCase):
    def test_environment_overrides_file_and_defaults(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            path = Path(directory) / 'config.json'
            path.write_text(json.dumps({'kill_bonus': 50, 'event_multiplier': 1.25}), encoding='utf-8')
            cfg = load_config(path, env={'ARENA_KILL_BONUS': '75'})
        self.assertEqual((cfg['kill_bonus'], cfg['event_multiplier'], cfg['win_base']), (75, 1.25, 900))

    def test_profile_credits_round_trip_and_old_profiles_default_to_zero(self):
        profile = Profile('player', level=12, credits=1590, cosmetics=['skin'])
        self.assertEqual(decode(encode(profile)), profile)
        self.assertEqual(decode('{"name":"old"}').credits, 0)

    def test_decimal_half_rounds_up(self):
        cfg = {'win_base': 1000, 'loss_base': 600, 'kill_bonus': 0, 'event_multiplier': 1.005}
        self.assertEqual(match_payout(True, 0, cfg), 1010)
