"""Match payout. Rules live in docs/ECONOMY.md."""

from decimal import Decimal, ROUND_FLOOR


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    raw = (Decimal(str(base)) + Decimal(str(kills)) * Decimal(str(cfg["kill_bonus"])))
    raw *= Decimal(str(cfg["event_multiplier"]))
    return int((raw / 10 + Decimal("0.5")).to_integral_value(rounding=ROUND_FLOOR) * 10)
