Goal: Measure local-9b Q5 at 128k and finish the follow-up.

Assumption: No project checkout is present; transcript claims cannot be independently verified.

The transcript reports `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024` gave 37.8 t/s and 7881 MiB, but 1494 MiB spilled into shared memory, invalidating that result. With `--no-mmproj-offload` and `-ub 512`, it reports no spill, 7697 MiB and 38.0 t/s median of three. The recipe was reportedly applied to `scripts/start_server.ps1` (local9 block) and `profiles/local/local-9b.json`. Q6_K did not fit; Q4_K_M was a fallback at 7305 MiB and 40.4 t/s.

Next: locate the checkout and verify the settings and measurements. Update the evals README: its `check_vision.ps1` reference reportedly points to a deleted file. Find the replacement before editing.

Found: a reported spill-free Q5 result and an outstanding README fix. Evidence: the transcript; measurements were not reproduced here.
