from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote
import json, re
class Page(HTMLParser):
 def __init__(self):
  super().__init__(); self.inmain=False; self.inh=False; self.section=False; self.word=''; self.links=[]
 def handle_starttag(self,tag,attrs):
  a=dict(attrs)
  if tag=='main': self.inmain=True
  if self.inmain and tag=='h1': self.inh=True
  if self.inmain and tag=='section' and a.get('id') in ('sinonimos','analogas'): self.section=True
  if self.section and tag=='a' and 'href' in a: self.links.append(unquote(a['href']).split('#')[0])
 def handle_endtag(self,tag):
  if tag=='h1': self.inh=False
  if tag=='section': self.section=False
  if tag=='main': self.inmain=False
 def handle_data(self,s):
  if self.inh: self.word+=s
pages={}
for f in Path('site').glob('*.html'):
 p=Page(); p.feed(f.read_text(encoding='utf-8'))
 if p.links: pages[f.name]=p
print('pages',len(pages),'unique headings',len(set(p.word.strip().lower() for p in pages.values())))
names={f:p.word.strip().lower() for f,p in pages.items()}
graph={w:set() for w in names.values()}; missing=set(); directed=0
for f,p in pages.items():
 for link in p.links:
  if link not in names: missing.add(link); continue
  a,b=names[f],names[link]
  if a!=b: graph[a].add(b); graph[b].add(a); directed+=1
graph={k:sorted(v) for k,v in sorted(graph.items())}
edges=sum(map(len,graph.values()))//2
maximum=max(map(len,graph.values()))
tops=[k for k,v in graph.items() if len(v)==maximum]
Path('words.json').write_text(json.dumps(graph,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
Path('result.json').write_text(json.dumps({'words':len(graph),'relations':edges,'most_connected':tops[0] if len(tops)==1 else tops},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('directed valid links',directed,'distinct pairs',edges,'most_connected',tops,'degree',maximum,'missing',sorted(missing))
