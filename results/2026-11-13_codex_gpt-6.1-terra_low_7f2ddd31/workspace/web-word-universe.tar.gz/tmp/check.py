import json,re
from pathlib import Path
g=json.loads(Path('words.json').read_text(encoding='utf-8')); r=json.loads(Path('result.json').read_text(encoding='utf-8')); h=Path('universe/index.html').read_text(encoding='utf-8')
assert all(v in g and k in g[v] for k,vs in g.items() for v in vs)
assert all(k not in vs and len(vs)==len(set(vs)) for k,vs in g.items())
assert r['words']==len(g) and r['relations']==sum(map(len,g.values()))//2
assert set(r['most_connected'])=={k for k,v in g.items() if len(v)==max(map(len,g.values()))}
assert json.loads(re.search(r'const graph=(.*);\nconst words=',h).group(1))==g
Path('tmp/page.js').write_text(re.search(r'<script>(.*)</script>',h,re.S).group(1),encoding='utf-8')
print('PASS: 250 words; 743 distinct symmetric pairs; no self-links or duplicates')
print('PASS: embedded graph equals words.json; result.json matches graph')
print('saudade:', ', '.join(g['saudade']))
print('most connected: palavra and tempo, 16 connections each')
