import json
import tomllib
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent


class ModelConfigTest(unittest.TestCase):
    def test_fast_coder_context_is_consistent(self):
        source = json.loads((ROOT / 'models.json').read_text(encoding='utf-8'))
        opencode = json.loads((ROOT / 'out/opencode.json').read_text(encoding='utf-8'))
        codex = tomllib.loads((ROOT / 'out/codex.toml').read_text(encoding='utf-8'))
        claude = json.loads((ROOT / 'out/claude.json').read_text(encoding='utf-8'))
        values = [
            next(m['context_window'] for m in source['models'] if m['name'] == 'fast-coder'),
            opencode['provider']['workstation']['models']['fast-coder']['limit']['context'],
            codex['models']['fast-coder']['context_window'],
            next(m['contextWindow'] for m in claude['models'] if m['id'] == 'fast-coder'),
        ]
        self.assertEqual(values, [262144] * 4)


if __name__ == '__main__':
    unittest.main()
