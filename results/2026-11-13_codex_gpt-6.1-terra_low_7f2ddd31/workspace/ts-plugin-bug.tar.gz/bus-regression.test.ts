import { test } from "node:test";
import assert from "node:assert/strict";
import { HookBus } from "./src/bus.ts";
import { registerAuditPlugin } from "./src/plugin.ts";

test("audit hooks run in order even when the notice unsubscribes", async () => {
  const bus = new HookBus();
  const audit: string[] = [];
  registerAuditPlugin(bus, audit);
  await bus.emit("tool.after", { tool: "read", output: "password=secret" });
  assert.deepEqual(audit, ["notice: tool output is audited", "read: password=[redacted]"]);
});

test("emit snapshots subscriptions and propagates the first error", async () => {
  const bus = new HookBus();
  const seen: string[] = [];
  const failure = new Error("hook failed");
  let off = () => {};
  bus.on("event", async () => { seen.push("first"); off(); await Promise.resolve(); });
  off = bus.on("event", () => { seen.push("second"); throw failure; });
  bus.on("event", () => { seen.push("third"); });
  await assert.rejects(bus.emit("event", null), (error) => error === failure);
  assert.deepEqual(seen, ["first", "second"]);
});
