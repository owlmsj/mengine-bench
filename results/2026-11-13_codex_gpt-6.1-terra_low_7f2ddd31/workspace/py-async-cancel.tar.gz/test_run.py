import asyncio
import unittest

from run import run_tasks


class RunTasksTests(unittest.TestCase):
    def test_limit_and_completion(self):
        async def check():
            active = 0
            peak = 0
            finished = []
            async def job(i):
                nonlocal active, peak
                active += 1
                peak = max(peak, active)
                await asyncio.sleep(0.01)
                active -= 1
                finished.append(i)
            await run_tasks([lambda i=i: job(i) for i in range(8)], 2)
            self.assertEqual(peak, 2)
            self.assertEqual(sorted(finished), list(range(8)))
        asyncio.run(check())

    def test_cancellation_waits_for_cleanup(self):
        async def check():
            started = asyncio.Event()
            cleaned = []
            async def job():
                started.set()
                try:
                    await asyncio.Event().wait()
                finally:
                    await asyncio.sleep(0.01)
                    cleaned.append(True)
            runner = asyncio.create_task(run_tasks([job], 1))
            await started.wait()
            runner.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await runner
            self.assertEqual(cleaned, [True])
        asyncio.run(check())

    def test_invalid_limit(self):
        async def check():
            with self.assertRaises(ValueError):
                await run_tasks([], 0)
        asyncio.run(check())

    def test_failure_cleans_other_jobs(self):
        async def check():
            started = asyncio.Event()
            cleaned = []
            async def waiting():
                started.set()
                try:
                    await asyncio.Event().wait()
                finally:
                    cleaned.append(True)
            async def failing():
                await started.wait()
                raise RuntimeError('job failed')
            with self.assertRaises(ExceptionGroup):
                await run_tasks([waiting, failing], 2)
            self.assertEqual(cleaned, [True])
        asyncio.run(check())

