"""Run asynchronous jobs with bounded concurrency."""

import asyncio
from collections.abc import Awaitable, Callable, Iterable


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[object]]], max_concurrent: int
) -> None:
    """Run all jobs, cancelling and awaiting siblings on failure or cancellation.

    Job exceptions propagate as an ExceptionGroup from asyncio.TaskGroup.
    """
    if isinstance(max_concurrent, bool) or not isinstance(max_concurrent, int) or max_concurrent < 1:
        raise ValueError(f"max_concurrent must be a positive integer, got {max_concurrent!r}")

    remaining = iter(tasks)

    async def worker() -> None:
        for task in remaining:
            await task()

    async with asyncio.TaskGroup() as group:
        for _ in range(max_concurrent):
            group.create_task(worker())
