# CFO briefing: first half 2026

All amounts in Brazilian reais (R$). Figures are based on the supplied ledger and chart of accounts; negative EBITDA is a loss.

| Month | Net revenue | Gross margin | EBITDA |
|---|---:|---:|---:|
| January | 200,510.87 | 70.03% | (210,278.96) |
| February | 216,328.06 | 70.29% | (212,300.08) |
| March | 219,066.17 | 68.46% | (204,525.45) |
| April | 238,163.26 | 70.24% | (196,950.65) |
| May | 243,032.89 | 69.56% | (201,945.82) |
| June | 272,391.57 | 72.41% | (192,968.22) |

First-half net revenue was R$ 1,389,492.82 and EBITDA was a loss of R$ 1,218,969.18. Revenue rose each month, from R$ 200,510.87 in January to R$ 272,391.57 in June. June had the highest gross margin and the smallest EBITDA loss of the six months.

At 30 June cash was R$ 1,847,350.40. The board defines burn as average monthly negative EBITDA over the last three closed months: April, May and June losses average R$ 197,288.23 per month. Cash divided by that burn gives 9.36 months of runway, assuming that burn remains constant and no new financing or other cash flows. This is the board's EBITDA-based proxy, not a cash-flow forecast.

Cash declined R$ 461,837.60 from 31 May to 30 June, versus June's R$ 192,968.22 EBITDA loss. The R$ 268,869.38 difference is not explained by the supplied information. The CFO should reconcile working capital, financing, capital spending and other cash movements before treating the proxy as a cash forecast. If June's cash decline alone persisted, it would imply approximately 4.00 months of cash; one month is not a reliable trend.

Method and assumptions: revenue includes refunds and cancellations; gross margin is (net revenue less cost of goods sold) divided by net revenue. EBITDA sums revenue, COGS, sales and marketing, R&D and general and administrative ledger lines; financial income, interest and IOF are excluded. The chart has no separate depreciation or amortization lines, so the calculation assumes operating expense entries contain no such charges. Use the supplied ledger as complete and June as the latest closed month; no independent close or cash-flow reconciliation was supplied. Percentages and runway are rounded to two decimals after calculation. Sources: finance/ledger.csv, finance/chart_of_accounts.csv, finance/cash_balance.txt and finance/README.md.
