# HANDOFF

Goal: measure local-9b Q5 at 128k context.

Done:
- Baseline: `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024` -> decode 37.8 t/s, VRAM 7881 MiB. But 7881 is the WDDM ceiling: Shared Usage showed 1494 MiB spilled, so that number is contaminated. Do not report it.
- Fix: add `--no-mmproj-offload` and `-ub 512` -> spill gone: VRAM 7697 MiB, decode 38.0 t/s (median of 3 runs).
- Quant: Q6_K (7.03 GiB) does not fit at 128k - discarded. Q4_K_M fits (7305 MiB, 40.4 t/s) - fallback only.
- Recipe applied in `scripts/start_server.ps1:165` (local9 block) and `profiles/local/local-9b.json`.

Open:
1. Review scratchpad temp-file names (noted repeatedly, never done).
2. Update evals README: it still cites `check_vision.ps1`, which no longer exists.

Assumptions: "local-9b" = the 9B model at Q5_K; the WDDM Shared Usage counter is the trustworthy VRAM signal here; the applied flags are the final config.
