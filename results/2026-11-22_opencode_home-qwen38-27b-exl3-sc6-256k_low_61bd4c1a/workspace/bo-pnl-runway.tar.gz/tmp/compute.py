import csv, json, collections

def money(s):
    s = s.strip().replace('.', '').replace(',', '.')
    return float(s)

coa = {}
with open(r'finance/chart_of_accounts.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        coa[row['account']] = row['pnl_line']

months = {}
for m in ['01', '02', '03', '04', '05', '06']:
    months[m] = collections.defaultdict(float)
n = 0
with open(r'finance/ledger.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        d = row['date'].strip()
        day, mon, y = d.split('/')
        if y != '2026':
            continue
        n += 1
        months[mon][coa[row['account']]] += money(row['amount'])

rev_accounts = ['3.1.01', '3.1.02', '3.1.09']
lines = {}
for m in ['01', '02', '03', '04', '05', '06']:
    d = months[m]
    rev = sum(d.get(k, 0.0) for k in ['revenue'])
    cogs = d.get('cogs', 0.0)
    sm = d.get('sales_marketing', 0.0)
    rnd = d.get('rnd', 0.0)
    ga = d.get('ga', 0.0)
    fin = d.get('financial', 0.0)
    gross_profit = rev + cogs  # cogs stored negative
    gross_margin = gross_profit / rev * 100
    # EBITDA = operating profit (revenue - cogs - opex), excluding financials
    ebitda = gross_profit + sm + rnd + ga
    lines[m] = dict(revenue=rev, cogs=cogs, sm=sm, rnd=rnd, ga=ga, fin=fin,
                    gross_margin_pct=gross_margin, ebitda=ebitda)

for m in ['01', '02', '03', '04', '05', '06']:
    L = lines[m]
    print(f"2026-{m}: rev={L['revenue']:,.2f} cogs={L['cogs']:,.2f} sm={L['sm']:,.2f} "
          f"rnd={L['rnd']:,.2f} ga={L['ga']:,.2f} fin={L['fin']:,.2f} "
          f"GM={L['gross_margin_pct']:.2f}% EBITDA={L['ebitda']:,.2f}")

ebitdas = {m: lines[m]['ebitda'] for m in ['04', '05', '06']}
neg = [v for v in ebitdas.values() if v < 0]
burn_avg_all = -(sum(ebitdas.values()) / 3)
burn_avg_neg = -(sum(neg) / len(neg))
print('last-3 EBITDA:', {f"2026-{k}": round(v, 2) for k, v in ebitdas.items()})
print('burn (avg of 3) =', round(burn_avg_all, 2), ' burn (avg of negatives only) =', round(burn_avg_neg, 2))

cash_06 = 1847350.40
runway = cash_06 / burn_avg_all
print('runway =', round(runway, 4), 'months')

result = {
    'revenue': {f'2026-{m}': round(lines[m]['revenue'], 2) for m in ['01', '02', '03', '04', '05', '06']},
    'gross_margin_pct': {f'2026-{m}': round(lines[m]['gross_margin_pct'], 2) for m in ['01', '02', '03', '04', '05', '06']},
    'ebitda': {f'2026-{m}': round(lines[m]['ebitda'], 2) for m in ['01', '02', '03', '04', '05', '06']},
    'burn': round(burn_avg_all, 2),
    'runway_months': round(runway, 2),
}
with open(r'result.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2)
print('entries:', n)
print(json.dumps(result, indent=2))
