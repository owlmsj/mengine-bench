import fitz
doc = fitz.open('permit-form.pdf')
page = doc[0]
print('original annots:', [(a.type, a.xref) for a in page.annots() or []])
print('original widgets:', [(w.field_name, w.field_value) for w in page.widgets() or []])

vals = {'organizer':'Tidewater Studio','event_date':'2026-12-05','location':'North Cove Lawn','attendees':'about 40'}
for w in page.widgets():
    w.field_value = vals[w.field_name]
    try:
        w.update()
        print('updated', w.field_name, 'has update()')
    except Exception as e:
        print('update err', w.field_name, e)

doc.save('tmp/staged2.pdf', garbage=3, deflate=True)
doc.close()

doc = fitz.open('tmp/staged2.pdf')
page = doc[0]
print('staged annots:', [(a.type, a.xref) for a in page.annots() or []])
print('staged widgets:', [(w.field_name, w.field_value) for w in page.widgets() or []])
cat = doc.pdf_catalog()
print('staged AcroForm:', doc.xref_get_key(cat, 'AcroForm'))
# inspect one widget xref object
for a in page.annots() or []:
    print('annot obj:', doc.xref_object(a.xref)[:400])
    break
