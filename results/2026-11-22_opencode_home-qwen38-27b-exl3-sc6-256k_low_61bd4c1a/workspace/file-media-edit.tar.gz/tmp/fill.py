import fitz

VALS = {'organizer': 'Tidewater Studio',
        'event_date': '2026-12-05',
        'location': 'North Cove Lawn',
        'attendees': 'about 40'}

# pass 1: fill fields, save (PyMuPDF writes appearance streams on save)
doc = fitz.open('permit-form.pdf')
page = doc[0]
for w in page.widgets():
    if w.field_name in VALS:
        w.field_value = VALS[w.field_name]
        print('filled', w.field_name, '=', w.field_value)
doc.save('tmp/permit-staged.pdf', garbage=3, deflate=True)
doc.close()

# pass 2: flatten - move each widget appearance into page content, delete widgets, drop AcroForm
doc = fitz.open('tmp/permit-staged.pdf')
page = doc[0]
contents = page.get_contents()
base = doc.xref_stream(contents[0])
extra = b''
fallback = []
for annot in list(page.annots() or []):
    if annot.type[1].lower() != 'widget':
        continue
    xref = annot.xref
    data = None
    k = doc.xref_get_key(xref, 'AP N')
    if isinstance(k, tuple) and len(k) == 2 and isinstance(k[1], int):
        data = doc.xref_stream(k[1])
    if data is None:
        data = doc.xref_stream(xref)
    name = doc.xref_get_key(xref, 'T')[1]
    print('widget', repr(name), 'xref', xref, 'ap bytes', len(data) if data else None)
    if data:
        extra += b'\n' + data
    else:
        fallback.append((name, annot.rect))
    page.delete_annot(annot)

for name, rect in fallback:
    page.insert_text((rect.x0 + 2, rect.y1 - 6), VALS[name], fontsize=11, fontname='helv')
    print('insert_text fallback for', name)

doc.update_stream(contents[0], base + extra)
cat = doc.pdf_catalog()
doc.xref_set_key(cat, 'AcroForm', 'null')
doc.save('out/permit-filled.pdf', garbage=4, deflate=True)
doc.close()
print('done')
