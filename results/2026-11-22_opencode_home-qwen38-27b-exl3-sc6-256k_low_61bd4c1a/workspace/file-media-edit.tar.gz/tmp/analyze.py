import os, json
import numpy as np
from PIL import Image

os.makedirs('out', exist_ok=True)
os.makedirs('tmp', exist_ok=True)

# ---- Job 1: find magenta balloon ----
im = Image.open('launch.jpg').convert('RGB')
W, H = im.size
a = np.asarray(im, dtype=np.int16)
r, g, b = a[..., 0], a[..., 1], a[..., 2]
# magenta: high R, high B, low G
mask = (r > 130) & (b > 90) & (r - g > 50) & (b - g > 30) & (r > b * 0.75)
ys, xs = np.nonzero(mask)
print('size', W, H)
print('magenta px', len(xs))
if len(xs):
    print('bbox x', xs.min(), xs.max(), 'y', ys.min(), ys.max())
    # 4:5 crop from 3:2 source: full height 2000 -> width 1600... no:
    # crop must be 4:5 (w:h). h=2000 -> w=1600? that's narrow. w: h = 1080:1350 = 4:5.
    # crop w = 1600, h = 2000 keeps full height; horizontal slack = 1400.
    cw, ch = 1600, 2000
    ccx, ccy = (xs.min() + xs.max()) / 2, (ys.min() + ys.max()) / 2
    x0 = int(round(ccx - cw / 2)); y0 = int(round(ccy - ch / 2))
    x0 = max(0, min(x0, W - cw)); y0 = max(0, min(y0, H - ch))
    print('crop', x0, y0, x0 + cw, y0 + ch)
    inside = (x0 <= xs.min()) and (xs.max() <= x0 + cw) and (y0 <= ys.min()) and (ys.max() <= y0 + ch)
    print('balloon fully inside', inside)
    crop = im.crop((x0, y0, x0 + cw, y0 + ch)).resize((1080, 1350), Image.LANCZOS)
    crop.save('out/feed-photo.jpg', quality=92)
    print('feed photo saved', crop.size)

# ---- Job 2: dump permit widgets ----
import fitz
doc = fitz.open('permit-form.pdf')
for pno, page in enumerate(doc):
    print('page', pno, 'rect', page.rect)
    for w in page.widgets() or []:
        print('widget', repr(w.field_name), w.field_type_string, 'value', repr(w.field_value), 'rect', w.rect)
# verify date is a Saturday
import datetime
print('2026-12-05 weekday:', datetime.date(2026, 12, 5).strftime('%A'))
