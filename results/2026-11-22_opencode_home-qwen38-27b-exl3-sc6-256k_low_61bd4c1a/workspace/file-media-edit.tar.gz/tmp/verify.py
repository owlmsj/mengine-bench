import fitz
doc = fitz.open('out/permit-filled.pdf')
print('pages', doc.page_count)
for pno, page in enumerate(doc):
    print('--- page', pno, 'text ---')
    print(page.get_text())
    print('widgets:', [ (w.field_name, w.field_value) for w in page.widgets() or [] ])
    print('annots:', list(page.annots() or []))
cat = doc.pdf_catalog()
print('AcroForm key:', doc.xref_get_key(cat, 'AcroForm'))
# check image too
from PIL import Image
im = Image.open('out/feed-photo.jpg')
print('feed photo', im.size, im.format)
import hashlib, os
for f in ['launch.jpg','permit-form.pdf','event-details.txt']:
    print(f, os.path.getsize(f))
