"""Concurrency-limited async task runner.

run_tasks(tasks, max_concurrent) runs zero-argument callables that return
awaitable jobs, with at most max_concurrent jobs in flight at once, and
returns once every job is done.

Ctrl+C handling: asyncio.run() converts the pending KeyboardInterrupt into
cancellation of the running coroutine, which cancels every in-flight job;
each job's `finally`/`async with` cleanup therefore still runs. Results are
returned in task order.
"""

import asyncio


async def run_tasks(tasks, max_concurrent):
    """Run `tasks` with at most `max_concurrent` jobs running at once.

    Each entry of `tasks` is a zero-argument callable returning an
    awaitable (e.g. `lambda: my_job()`). Awaits until all jobs finish and
    returns their results, in input order. The first job exception is
    re-raised to the caller (asyncio.gather semantics with
    return_exceptions=False).
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent}")

    semaphore = asyncio.Semaphore(max_concurrent)

    async def bounded(task):
        async with semaphore:
            return await task()

    return list(await asyncio.gather(*(bounded(t) for t in tasks)))
