import asyncio, sys
from run import run_tasks

async def main():
    # 1) cap: track concurrent jobs
    state = {"active": 0, "peak": 0}
    def job(i):
        async def run():
            state["active"] += 1
            state["peak"] = max(state["peak"], state["active"])
            await asyncio.sleep(0.05)
            state["active"] -= 1
            return i * 10
        return run
    res = await run_tasks([job(i) for i in range(20)], 4)
    assert res == [i * 10 for i in range(20)], res
    assert state["peak"] <= 4, state["peak"]
    print("cap ok, peak =", state["peak"])

    # 2) cleanup on cancel (simulates Ctrl+C: run() cancels the task)
    cleaned = []
    def job2(i):
        async def run():
            try:
                await asyncio.sleep(10)
                return i
            finally:
                cleaned.append(i)
        return run
    async def outer():
        return await run_tasks([job2(i) for i in range(3)], 2)
    try:
        await asyncio.wait_for(outer(), timeout=0.1)
        print("FAIL: should have timed out")
    except asyncio.TimeoutError:
        print("cancelled; cleaned =", sorted(cleaned))

    # 3) exception propagates
    def bad():
        async def run():
            raise RuntimeError("boom")
        return run
    try:
        await run_tasks([bad()], 2)
        print("FAIL: no exception")
    except RuntimeError as e:
        print("exception ok:", e)

asyncio.run(main())
