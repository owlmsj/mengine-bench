import sqlite3, json
from collections import defaultdict

db = r"<WORKSPACE>\analytics.db"
out = r"<WORKSPACE>\result.json"

c = sqlite3.connect(db)
users = {uid: (plat, is_test) for uid, plat, is_test in
         c.execute("select user_id, platform, is_test from users")}

# first occurrence per (user, event)
events = defaultdict(list)
for uid, name, ts in c.execute("select user_id, name, ts from events"):
    events[(uid, name)].append(ts)
for k in events:
    events[k].sort()

STEPS = ["install", "tutorial_complete", "first_match", "purchase"]

funnel = defaultdict(lambda: [0, 0, 0, 0])  # platform -> counts per step
for uid, (plat, is_test) in users.items():
    if is_test:
        continue
    t_prev = None
    for i, step in enumerate(STEPS):
        cands = events.get((uid, step), [])
        # first occurrence at or after t_prev
        found = None
        for ts in cands:
            if t_prev is None or ts >= t_prev:
                found = ts
                break
        if found is None:
            break
        funnel[plat][i] += 1
        t_prev = found

result = {"funnel": {}, "biggest_drop": {}}
for plat in sorted(funnel):
    counts = funnel[plat]
    result["funnel"][plat] = {STEPS[i]: counts[i] for i in range(len(STEPS))}
    # conversions: step i over step i-1 (i>0)
    convs = []
    for i in range(1, len(STEPS)):
        if counts[i - 1] > 0:
            convs.append((STEPS[i], counts[i] / counts[i - 1]))
        else:
            convs.append((STEPS[i], 0.0))
    # lowest conversion; tie -> earliest step in funnel order
    worst = min(convs, key=lambda x: (x[1], STEPS.index(x[0])))
    result["biggest_drop"][plat] = worst[0]

with open(out, "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
