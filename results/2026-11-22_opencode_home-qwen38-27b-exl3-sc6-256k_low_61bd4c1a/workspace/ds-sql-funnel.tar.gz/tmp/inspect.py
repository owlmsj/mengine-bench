import sqlite3

db = r"<WORKSPACE>\analytics.db"
c = sqlite3.connect(db)
for (name,) in c.execute("select name from sqlite_master where type='table'"):
    print("TABLE", name)
    cols = c.execute(f"pragma table_info({name})").fetchall()
    for col in cols:
        print("  ", col)
    n = c.execute(f"select count(*) from {name}").fetchone()[0]
    print("  rows:", n)
    for row in c.execute(f"select * from {name} limit 5"):
        print("  ", row)
