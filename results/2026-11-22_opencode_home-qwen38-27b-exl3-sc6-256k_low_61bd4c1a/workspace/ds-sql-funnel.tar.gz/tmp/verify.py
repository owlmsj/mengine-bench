import sqlite3
db = r"<WORKSPACE>\analytics.db"
c = sqlite3.connect(db)
print("install counts:", c.execute(
    "select u.platform, count(distinct e.user_id) from events e join users u on e.user_id=u.user_id where e.name='install' and u.is_test=0 group by 1"
).fetchall())
print("out-of-order users (later step before earlier):", c.execute(
    "select count(*) from events e join users u on e.user_id=u.user_id where e.name='purchase' and e.ts < min((select ts2 from events e2 where e2.user_id=e.user_id and e2.name in ('install','tutorial_complete','first_match')))"
).fetchone())
