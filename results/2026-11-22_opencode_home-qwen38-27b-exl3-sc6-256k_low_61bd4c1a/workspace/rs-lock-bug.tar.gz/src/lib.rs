//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        // A player already on the board keeps their accumulated score; joining
        // adds the given points on top. This keeps `total` equal to the sum of
        // the player scores and never replaces a slot Arc that live handles
        // may still point at.
        let slot = self
            .players
            .lock()
            .unwrap()
            .entry(id)
            .or_insert_with(|| Arc::new(Mutex::new(0)))
            .clone();
        *slot.lock().unwrap() += score;
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        // Single locked read-modify-write: reading and writing under separate
        // lock acquisitions let a concurrent award overwrite this one, which
        // is what drained scores under load.
        *self.slot(id).lock().unwrap() += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return;
        }
        // Lock the two slots in a global order (by player id) so that
        // concurrent transfers in opposite directions cannot deadlock.
        let from_slot = self.slot(from);
        let to_slot = self.slot(to);
        if from < to {
            let mut from_score = from_slot.lock().unwrap();
            let mut to_score = to_slot.lock().unwrap();
            *from_score -= points;
            *to_score += points;
        } else {
            let mut to_score = to_slot.lock().unwrap();
            let mut from_score = from_slot.lock().unwrap();
            *from_score -= points;
            *to_score += points;
        }
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}
