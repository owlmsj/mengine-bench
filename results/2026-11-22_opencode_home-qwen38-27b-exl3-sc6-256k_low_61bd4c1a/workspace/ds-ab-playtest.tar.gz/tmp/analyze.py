import csv, math, json

rows = []
with open(r"telemetry\playtest_ab.csv", newline="") as f:
    for r in csv.DictReader(f):
        rows.append(r)

print("total rows:", len(rows))

# sanity: field values
variants = sorted({r["variant"] for r in rows})
print("raw variant values:", variants)
completed = sorted({r["completed_tutorial"] for r in rows})
print("completed values:", completed)

# normalize
for r in rows:
    r["v"] = r["variant"].strip().lower()
    r["c"] = int(r["completed_tutorial"])

bad = [r for r in rows if r["v"] not in ("a", "b")]
print("unparseable variant rows:", len(bad))

# group by session_id
by_sid = {}
for r in rows:
    by_sid.setdefault(r["session_id"], []).append(r)

inconsistent = []
for sid, rs in by_sid.items():
    vs = {x["v"] for x in rs}
    cs = {x["c"] for x in rs}
    if len(vs) > 1 or len(cs) > 1:
        inconsistent.append((sid, vs, cs))
print("sessions with conflicting variant/completed across duplicate rows:", len(inconsistent))
for x in inconsistent[:10]:
    print("  ", x)

dup_counts = {sid: len(rs) for sid, rs in by_sid.items() if len(rs) > 1}
print("duplicate session count:", len(dup_counts))

# one record per session: use first row (dedupe)
sess = {sid: rs[0] for sid, rs in by_sid.items()}
na = sum(1 for s in sess.values() if s["v"] == "a")
nb = sum(1 for s in sess.values() if s["v"] == "b")
ca = sum(1 for s in sess.values() if s["v"] == "a" and s["c"] == 1)
cb = sum(1 for s in sess.values() if s["v"] == "b" and s["c"] == 1)
print("unique sessions:", len(sess), "A:", na, "B:", nb)
print("completed A:", ca, "completed B:", cb)
pa, pb = ca / na, cb / nb
print("rate A:", pa, "rate B:", pb, "diff B-A:", pb - pa)

# two-proportion z-test, pooled
p_pool = (ca + cb) / (na + nb)
se = math.sqrt(p_pool * (1 - p_pool) * (1 / na + 1 / nb))
z = (pb - pa) / se
# one-sided p for H1: p_B > p_A
p_one = 0.5 * math.erfc(z / math.sqrt(2))
p_two = 2 * (0.5 * math.erfc(abs(z) / math.sqrt(2)))
print("z:", z, "p_one_sided(B>A):", p_one, "p_two_sided:", p_two)

# un-pooled SE for CI (Wald) on the difference
se_diff = math.sqrt(pa * (1 - pa) / na + pb * (1 - pb) / nb)
print("95% CI for diff B-A:", (pb - pa - 1.959964 * se_diff, pb - pa + 1.959964 * se_diff))

# chi-squared (no continuity correction) as cross-check
total = na + nb
exp = [[ca, cb], [na - ca, nb - cb]]
chi2 = 0.0
for i in range(2):
    for j in range(2):
        e = exp[i][j]
        o = (ca if j == 0 else cb) if i == 0 else ((na - ca) if j == 0 else (nb - cb))
        chi2 += (o - e) ** 2 / e
print("chi2:", chi2, "(df=1)")

# cross-check: dedupe by exact row identity (count unique rows)
uniq_rows = {tuple(sorted(r.items())) for r in rows}
print("unique full rows:", len(uniq_rows))

result = {
    "ship_b": (p_one < 0.05) and (pb > pa),
    "sessions_a": na,
    "sessions_b": nb,
    "completion_rate_a": round(pa, 6),
    "completion_rate_b": round(pb, 6),
    "p_value": round(p_one, 6),
}
with open(r"..\result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
