import csv, json, re, collections

base = r"<WORKSPACE>\backoffice"
inv = {}
with open(base + r"\invoices.csv", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        inv[r["id"]] = float(r["amount"])

payments = collections.defaultdict(list)
ignored = []
with open(base + r"\bank_statement_june.csv", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        memo = r["memo"].upper()
        m = re.search(r"(?:INV|INVOICE)[-\s]?(\d{4})", memo)
        if m:
            payments["INV-" + m.group(1)].append(float(r["amount"]))
        else:
            ignored.append((r["date"], r["memo"], r["amount"]))

unpaid, duplicated, mismatched = [], [], []
for i in range(1001, 1041):
    iid = "INV-" + str(i)
    pays = payments.get(iid)
    if not pays:
        unpaid.append(iid)
    elif len(pays) > 1:
        duplicated.append(iid)
    elif len(pays) == 1 and pays[0] != inv[iid]:
        mismatched.append({"id": iid, "invoiced": inv[iid], "paid": pays[0]})

out = {"unpaid": sorted(unpaid), "duplicated": sorted(duplicated), "mismatched": mismatched}
print(json.dumps(out, indent=2))
print("ignored rows:", ignored)
print("paid count (unique invoices):", len(payments))
