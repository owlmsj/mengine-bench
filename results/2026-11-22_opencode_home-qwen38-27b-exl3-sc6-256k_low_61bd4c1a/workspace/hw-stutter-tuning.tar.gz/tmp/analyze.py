import csv, statistics, json

rows = list(csv.DictReader(open(r'capture\presentmon.csv', newline='')))
mbp = [float(r['MsBetweenPresents']) for r in rows]
n = len(mbp)
avg_fps = 1000.0 / (sum(mbp) / n)
srt = sorted(mbp)
p99 = srt[int(round(0.99 * (n - 1)))]
low1 = 1000.0 / p99
print(f"frames={n} total_ms={sum(mbp):.3f}")
print(f"avg_fps={avg_fps:.2f} p99_ms={p99:.3f} low1pct_fps={low1:.2f}")

# bucket by second
from collections import defaultdict
buckets = defaultdict(list)
t = 0.0
i = 0
times = []
cur = 0.0
for r in rows:
    times.append(float(r['TimeInSeconds']))
for tsec, v in zip(times, mbp):
    buckets[int(tsec)].append(v)
bad = []
for s in sorted(buckets):
    vs = buckets[s]
    mx = max(vs)
    if mx > 30:
        bad.append((s, len(vs), round(mx,1)))
print("seconds with max frame time >30ms:")
for b in bad:
    print(b)

# present API vs render complete on worst frames
worst = sorted(rows, key=lambda r: float(r['MsBetweenPresents']), reverse=True)[:15]
for r in worst:
    print(r['TimeInSeconds'], round(float(r['MsBetweenPresents']),1), 'API', r['MsInPresentAPI'], 'render', r['MsUntilRenderComplete'], 'displayed', r['MsUntilDisplayed'])

# per-second mean frame time, find periodic bumps
means = []
for s in sorted(buckets):
    vs = buckets[s]
    means.append((s, round(sum(vs)/len(vs),2), len(vs), round(max(vs),1)))
print("second mean n max:")
for m in means:
    print(m)
