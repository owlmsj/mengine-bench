import csv, re, json

base = r"<WORKSPACE>\backoffice"
invoices = {}
with open(base + r"\invoices.csv", newline="") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = float(row["amount"])

payments = []
with open(base + r"\bank_statement_june.csv", newline="") as f:
    for row in csv.DictReader(f):
        m = re.search(r"(?:inv|invoice)[\s\-#]*(\d{4})", row["memo"], re.I)
        if not m:
            continue  # fees, interest, unidentified PIX
        payments.append((m.group(1), float(row["amount"])))

paid = {}
for num, amt in payments:
    paid.setdefault(num, []).append(amt)

unpaid = [k for k in sorted(invoices) if k.split("-")[1] not in paid]
duplicated = [k for k in sorted(paid) if len(paid[k]) > 1]
mismatched = []
for k in sorted(paid):
    if len(paid[k]) > 1:
        continue  # exclusive: duplicated is never mismatched
    inv_amt = invoices.get("INV-" + k)
    amt = paid[k][0]
    if inv_amt is None:
        print("UNKNOWN INVOICE in statement:", k, amt)
    elif abs(amt - inv_amt) > 0.005:
        mismatched.append({"id": "INV-" + k, "invoiced": inv_amt, "paid": amt})

result = {"unpaid": unpaid, "duplicated": ["INV-" + k for k in duplicated], "mismatched": mismatched}
print(json.dumps(result, indent=2))
# sanity: counts
print("invoices:", len(invoices), "distinct paid:", len(paid), "payments:", len(payments))
