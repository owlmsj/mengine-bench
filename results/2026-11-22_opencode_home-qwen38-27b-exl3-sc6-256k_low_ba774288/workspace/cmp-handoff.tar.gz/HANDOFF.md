# Handoff: local-9b Q5_K @ 128k context

Done (measured: 131072 ctx, 1024 predict, scripts/measure_decode.ps1):
- Baseline: 37.8 t/s, 7881 MiB VRAM. 7881 is the WDDM ceiling: Shared Usage showed 1494 MiB spilled, so that VRAM number is wrong.
- Fix: --no-mmproj-offload + -ub 512 -> spill gone: 7697 MiB, 38.0 t/s (median of 3). This is the number to report.
- Q6_K (7.03 GiB) does not fit at 128k: discarded. Q4_K_M (7305 MiB, 40.4 t/s) kept as fallback only.
- Recipe applied in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

Left:
1. Evals README still cites check_vision.ps1 (file no longer exists) - update it.
2. Scratchpad temp file names were flagged for review several times, never closed.

Assumptions/caveat: this workspace holds only session/ and AGENTS.md; the script/profile paths above come from the session transcript, so locate the real repo before applying anything. No browser tabs or apps left open.
