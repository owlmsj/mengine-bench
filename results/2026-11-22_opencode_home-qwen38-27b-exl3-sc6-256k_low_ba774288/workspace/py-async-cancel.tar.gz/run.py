"""Batch job runner with a bound on concurrent jobs.

    from run import run_tasks
    await run_tasks([make_job_a, make_job_b], max_concurrent=4)

Each entry of ``tasks`` is a zero-argument callable that returns an
awaitable job; the callable is invoked after a concurrency slot is
acquired, so at most ``max_concurrent`` jobs ever run at once.

Assumptions (the brief leaves these open):
- ``max_concurrent`` is a positive int; values below 1 are clamped to 1
  so the batch cannot deadlock.
- If any job raises, the run is fail-fast: remaining jobs are cancelled
  and the first failure is raised (as an ``ExceptionGroup``, per
  ``asyncio.TaskGroup`` semantics).
- On Ctrl+C (or any cancellation of the caller) every in-flight and
  queued job is cancelled and awaited before the error propagates, so
  job ``finally`` blocks and ``async with`` cleanup always run.
"""

import asyncio


async def run_tasks(tasks, max_concurrent):
    """Run the jobs from *tasks*, at most *max_concurrent* at once.

    Returns when every job has completed (or after all jobs have been
    cancelled and awaited, if the run is cancelled or a job fails).
    """
    sem = asyncio.Semaphore(max(1, int(max_concurrent)))

    async def run_one(task):
        async with sem:
            await task()

    async with asyncio.TaskGroup() as group:
        for task in tasks:
            group.create_task(run_one(task))
