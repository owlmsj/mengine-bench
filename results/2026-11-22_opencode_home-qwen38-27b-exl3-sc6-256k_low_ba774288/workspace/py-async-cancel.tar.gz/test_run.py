import asyncio

from run import run_tasks


async def main():
    # 1. At most max_concurrent jobs run at once, all 10 complete.
    active = 0
    peak = 0
    finished = 0

    def make_job():
        async def job():
            nonlocal active, peak, finished
            active += 1
            peak = max(peak, active)
            await asyncio.sleep(0.05)
            active -= 1
            finished += 1
        return job

    await run_tasks([make_job() for _ in range(10)], 3)
    assert peak <= 3, f"peak={peak} exceeded max_concurrent=3"
    assert peak == 3, f"peak={peak}, expected to reach the cap of 3"
    assert finished == 10, f"finished={finished}"
    print(f"cap OK: peak={peak}, finished={finished}")

    # 2. All jobs complete when nothing fails.
    done = []

    def make_i(i):
        async def job():
            await asyncio.sleep(0.01)
            done.append(i)
        return job

    await run_tasks([make_i(i) for i in range(5)], 2)
    assert sorted(done) == [0, 1, 2, 3, 4], done
    print("completion OK")

    # 3. Cancellation (Ctrl+C simulation): job cleanup (finally) must run.
    cleaned = []

    async def long_job():
        try:
            await asyncio.sleep(30)
        finally:
            cleaned.append(1)

    outer = asyncio.create_task(run_tasks([lambda: long_job()], 4))
    await asyncio.sleep(0.1)
    outer.cancel()
    try:
        await outer
    except asyncio.CancelledError:
        pass
    assert cleaned == [1], f"cleanup did not run: cleaned={cleaned}"
    print("cleanup-on-cancel OK")

    # 4. A failing job cancels siblings; cleanup of siblings still runs.
    sib_cleaned = []

    async def failing():
        raise ValueError("boom")

    async def sibling():
        try:
            await asyncio.sleep(30)
        finally:
            sib_cleaned.append(1)

    try:
        await run_tasks([lambda: failing(), lambda: sibling()], 2)
        raise AssertionError("expected ExceptionGroup")
    except* ValueError as eg:
        assert len(eg.exceptions) == 1
    assert sib_cleaned == [1], f"sibling cleanup did not run: {sib_cleaned}"
    print("fail-fast + sibling cleanup OK")

    # 5. Empty batch returns immediately.
    await run_tasks([], 3)
    print("empty batch OK")


asyncio.run(main())
print("ALL OK")
