import { HookBus } from "../src/bus.ts";

// 1) Sequential order: each handler finishes before the next starts.
{
  const bus = new HookBus();
  const order = [];
  bus.on("e", async () => { await new Promise(r => setTimeout(r, 10)); order.push("a"); });
  bus.on("e", async () => { order.push("b"); });
  bus.on("e", async () => { order.push("c"); });
  await bus.emit("e", null);
  console.log("order:", JSON.stringify(order), order.join() === "a,b,c" ? "OK" : "FAIL");
}

// 2) Rejection propagates and stops later handlers.
{
  const bus = new HookBus();
  const ran = [];
  bus.on("e", async () => { ran.push("a"); });
  bus.on("e", async () => { ran.push("b"); throw new Error("boom"); });
  bus.on("e", async () => { ran.push("c"); });
  const err = await bus.emit("e", null).then(() => null, (e) => e);
  console.log("reject:", err instanceof Error && err.message === "boom" ? "OK" : "FAIL", "ran:", ran.join(","));
}

// 3) Synchronous throw also rejects.
{
  const bus = new HookBus();
  bus.on("e", () => { throw new Error("sync"); });
  const err = await bus.emit("e", null).then(() => null, (e) => e);
  console.log("sync-throw:", err instanceof Error && err.message === "sync" ? "OK" : "FAIL");
}

// 4) Self-unsubscribe during emit does not stop the rest; counts from next emit.
{
  const bus = new HookBus();
  const ran = [];
  const off = bus.on("e", async () => { ran.push("a"); off(); });
  bus.on("e", async () => { ran.push("b"); });
  await bus.emit("e", null);
  const first = ran.join(",");
  await bus.emit("e", null);
  const second = ran.slice(2).join(",");
  console.log("unsub-in-emit:", first === "a,b" && second === "b" ? "OK" : "FAIL", `(${first} | ${second})`);
}

// 5) Late subscription during emit applies only to the next emit.
{
  const bus = new HookBus();
  const ran = [];
  bus.on("e", () => { bus.on("e", () => { ran.push("late"); }); ran.push("first"); });
  await bus.emit("e", null);
  const first = ran.join(",");
  await bus.emit("e", null);
  const second = ran.slice(1).join(",");
  console.log("late-subscribe:", first === "first" && second === "first,late" ? "OK" : "FAIL", `(${first} | ${second})`);
}

// 6) Audit plugin: notice once, redaction, audit log order.
{
  const { registerAuditPlugin } = await import("../src/plugin.ts");
  const bus = new HookBus();
  const audit = [];
  registerAuditPlugin(bus, audit);
  const result = { tool: "shell", output: "password=secret123 done" };
  await bus.emit("tool.after", result);
  await bus.emit("tool.after", { tool: "shell", output: "password=again more" });
  const ok =
    audit[0] === "notice: tool output is audited" &&
    audit[1] === "shell: password=[redacted] done" &&
    audit[2] === "shell: password=[redacted] more" &&
    audit.length === 3 &&
    result.output === "password=[redacted] done";
  console.log("plugin:", ok ? "OK" : "FAIL", JSON.stringify(audit));
}
