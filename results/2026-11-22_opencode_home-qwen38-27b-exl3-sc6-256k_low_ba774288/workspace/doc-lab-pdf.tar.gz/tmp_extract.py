import os
from pypdf import PdfReader

base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "exams")
for f in ["resultado_beta.pdf", "laudo_alfa.pdf"]:
    print("==== " + f + " ====")
    r = PdfReader(os.path.join(base, f))
    for i, p in enumerate(r.pages):
        print("--page", i + 1, "--")
        print(p.extract_text())
