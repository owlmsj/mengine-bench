import json, os

# First report chronologically: Alfa, collection 2026-02-10 (units mg/dL, mg/dL, mg/dL, %)
# Second report: Beta, collection 2026-08-18 (units mmol/L, mmol/L, umol/L, mmol/mol)

glucose_mgdl_later = 6.1 * 18.0156        # mmol/L -> mg/dL
ldl_mgdl_later = 3.70 * 38.67              # mmol/L -> mg/dL
creatinina_mgdl_later = 76 / 88.42        # umol/L -> mg/dL
hba1c_pct_later = 37 * 0.093897 + 2.0375  # mmol/mol -> NGSP % (IFCC)

print("glucose later mg/dL:", round(glucose_mgdl_later, 1))
print("ldl later mg/dL:", round(ldl_mgdl_later, 1))
print("creatinina later mg/dL:", round(creatinina_mgdl_later, 2))
print("hba1c later %:", round(hba1c_pct_later, 1))

history = {
    "Glicose em jejum": {"2026-02-10": 92, "2026-08-18": round(glucose_mgdl_later, 1)},
    "Colesterol LDL": {"2026-02-10": 118, "2026-08-18": round(ldl_mgdl_later, 1)},
    "Creatinina": {"2026-02-10": 0.95, "2026-08-18": round(creatinina_mgdl_later, 2)},
    "Hemoglobina glicada (HbA1c)": {"2026-02-10": 5.4, "2026-08-18": round(hba1c_pct_later, 1)},
}

# worse: got worse AND latest value outside first report (Alfa) reference range
# glucose: 70-99 mg/dL, higher is worse -> 109.9 outside -> worse
# LDL: <130 mg/dL, higher is worse -> 143.1 outside -> worse
# creatinine: 0.70-1.30, lower is better; 0.86 improved and in range -> not worse
# HbA1c: 4.0-5.6 %, higher is worse; 5.5 slightly up but still in range -> not worse
worse = ["Glicose em jejum", "Colesterol LDL"]

out = {"history": history, "worse": worse}
path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "result.json")
with open(path, "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print("wrote", path)
