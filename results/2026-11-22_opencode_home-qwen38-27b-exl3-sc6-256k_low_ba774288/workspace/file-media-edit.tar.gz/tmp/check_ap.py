from pypdf import PdfReader
from pypdf.generic import IndirectObject

r = PdfReader('out/permit-filled.pdf')
page = r.pages[0]
for a in page.get('/Annots'):
    o = a.get_object()
    print('T', o.get('/T'), 'V=', repr(o.get('/V')), 'AP=', 'AP' in o or '/AP' in o)
    ap = o.get('/AP')
    if ap:
        n = ap['/N'].get_object()
        try:
            data = n.get_data()
        except Exception as e:
            data = repr(e)
        print('  AP N data:', data[:200])
# check field tree objects
import re
raw = open('out/permit-filled.pdf', 'rb').read()
print('has "Tidewater" in file:', b'Tidewater' in raw)
print('has /V entry:', re.findall(rb'/V\s*/\([^)]*\)', raw))
print('has /AP entry:', len(re.findall(rb'/AP', raw)))
