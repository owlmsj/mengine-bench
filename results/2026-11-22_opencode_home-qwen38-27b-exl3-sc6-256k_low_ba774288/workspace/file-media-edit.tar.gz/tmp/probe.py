from pypdf import PdfReader
from PIL import Image
import numpy as np

r = PdfReader('permit-form.pdf')
fields = r.get_fields()
print("PAGES:", len(r.pages))
for k, v in (fields or {}).items():
    print("FIELD", repr(k), "|", v.get('/FT'), "|", repr(v.get('/V')))
for pi, page in enumerate(r.pages):
    for a in (page.get('/Annots') or []):
        obj = a.get_object()
        if obj.get('/Subtype') == '/Widget':
            print("ANNOT", pi, repr(obj.get('/T')), obj.get('/Rect'))

im = Image.open('launch.jpg').convert('RGB')
a = np.asarray(im)
r_, g, b = a[..., 0].astype(int), a[..., 1].astype(int), a[..., 2].astype(int)
mask = (r_ > 140) & (b > 110) & (g < 120) & (r_ - g > 60) & (b - g > 40)
ys, xs = np.where(mask)
print("MAGENTA_PX", int(mask.sum()), "IMG", im.size)
if mask.sum():
    print("BBOX x:", int(xs.min()), int(xs.max()), "y:", int(ys.min()), int(ys.max()))
    # density per 200px cell to find main cluster
    hist = {}
    for x, y in zip(xs[::50], ys[::50]):
        hist[(x // 200, y // 200)] = hist.get((x // 200, y // 200), 0) + 1
    top = sorted(hist.items(), key=lambda kv: -kv[1])[:8]
    print("TOP_CELLS", top)
