from PIL import Image
import fitz, os

im = Image.open('out/feed-photo.jpg')
print('FEED', im.size, im.format)

d = fitz.open('out/permit-filled.pdf')
print('PERMIT pages:', d.page_count)
root = d.pdf_catalog()
acro = d.xref_get_key(root, 'AcroForm')
print('PERMIT AcroForm key:', acro)
# annotations still present as static text
p = d[0]
print('PERMIT annots:', len(p.annots()) if p.annots() else 0)
print('PERMIT text sample:', ' '.join(p.get_text().split())[:150])

for f in ('launch.jpg', 'permit-form.pdf', 'event-details.txt'):
    print('ORIG', f, os.path.getsize(f))
for f in ('out/feed-photo.jpg', 'out/permit-filled.pdf'):
    print('OUT', f, os.path.getsize(f))
