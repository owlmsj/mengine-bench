import os
from PIL import Image
from pypdf import PdfReader, PdfWriter
from pypdf.generic import NameObject

os.makedirs('out', exist_ok=True)

# --- Job 1: feed photo 1080x1350, magenta balloon fully in frame ---
im = Image.open('launch.jpg').convert('RGB')
# balloon bbox: x 2350-2750, y 500-900 -> 4:5 crop 1500x1875 at (1500,0)
crop = im.crop((1500, 0, 3000, 1875))
assert crop.size == (1500, 1875)
out = crop.resize((1080, 1350), Image.LANCZOS)
out.save('out/feed-photo.jpg', quality=92)
print("SAVED out/feed-photo.jpg", out.size)

# --- Job 2: fill permit form and flatten ---
data = {
    'organizer': 'Tidewater Studio',
    'event_date': 'Saturday 5 December 2026',
    'location': 'North Cove Lawn',
    'attendees': 'about 40',
}
reader = PdfReader('permit-form.pdf')
writer = PdfWriter()
writer.append(reader)
for page in writer.pages:
    writer.update_page_form_field_values(page, data, auto_regenerate=True)
# flatten: drop the AcroForm so no editable fields remain (values stay via appearance streams)
if '/AcroForm' in writer._root_object:
    del writer._root_object[NameObject('/AcroForm')]
with open('out/permit-filled.pdf', 'wb') as f:
    writer.write(f)
print("SAVED out/permit-filled.pdf")

# --- verify ---
v = PdfReader('out/permit-filled.pdf')
print("VERIFY AcroForm present:", '/AcroForm' in v.trailer['/Root'])
text = v.pages[0].extract_text()
for k in data:
    ok = data[k] in text
    print("VERIFY", k, ok)
print("VERIFY text:", repr(text))
