from PIL import Image, ImageDraw, ImageFont

W, H = 1200, 675
img = Image.new("RGB", (W, H), (14, 61, 89))  # deep harbor blue
d = ImageDraw.Draw(img)

# Simple horizon + sun for a poster feel
d.rectangle([0, 470, W, H], fill=(22, 93, 122))  # water band
d.ellipse([820, 120, 1020, 320], fill=(246, 201, 95))  # sun
for x in range(0, W, 40):  # subtle sun reflection
    d.line([(x, 480), (x, 560)], fill=(246, 201, 95), width=2)

# Title, large and legible
font_big = None
for path in (
    r"C:\Windows\Fonts\arialbd.ttf",
    r"C:\Windows\Fonts\segoeuib.ttf",
    r"C:\Windows\Fonts\calibri.ttf",
):
    try:
        font_big = ImageFont.truetype(path, 150)
        break
    except OSError:
        pass
if font_big is None:
    font_big = ImageFont.load_default()

text = "Harbor Day 2026"
bbox = d.textbbox((0, 0), text, font=font_big)
tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
d.text(((W - tw) / 2 - bbox[0], (470 - th) / 2 - bbox[1]), text, font=font_big, fill=(255, 255, 255))

img.save(r"<WORKSPACE>\cover.png")
print("saved", img.size, img.format)
