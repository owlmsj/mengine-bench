import csv, json, math

rows = []
with open(r"telemetry\playtest_ab.csv", newline="") as f:
    for r in csv.DictReader(f):
        rows.append(r)

print("raw rows:", len(rows))

# validate duplicate consistency
seen = {}
dup_conflict = 0
for r in rows:
    sid = r["session_id"].strip()
    key = (r["variant"].strip().lower(), r["completed_tutorial"].strip())
    if sid in seen and seen[sid] != key:
        dup_conflict += 1
    seen.setdefault(sid, key)
print("unique sessions:", len(seen), "conflicting duplicates:", dup_conflict)

# normalize + dedupe (first occurrence)
sessions = {}
for r in rows:
    sid = r["session_id"].strip()
    if sid not in sessions:
        v = r["variant"].strip().lower()
        assert v in ("a", "b"), v
        c = int(r["completed_tutorial"].strip())
        assert c in (0, 1)
        sessions[sid] = (v, c)

na = sum(1 for v, c in sessions.values() if v == "a")
nb = sum(1 for v, c in sessions.values() if v == "b")
xa = sum(c for v, c in sessions.values() if v == "a")
xb = sum(c for v, c in sessions.values() if v == "b")
pa, pb = xa / na, xb / nb
print(f"A: n={na} completed={xa} rate={pa:.4f}")
print(f"B: n={nb} completed={xb} rate={pb:.4f}")
print(f"diff (B-A) = {pb-pa:+.4f}")

# two-proportion z-test, pooled
p_pool = (xa + xb) / (na + nb)
se = math.sqrt(p_pool * (1 - p_pool) * (1/na + 1/nb))
z = (pb - pa) / se
# two-sided p via erfc
p_two = math.erfc(abs(z) / math.sqrt(2))
p_one = 0.5 * math.erfc(z / math.sqrt(2)) if z > 0 else 1 - 0.5 * math.erfc(-z / math.sqrt(2))
print(f"z = {z:.4f}")
print(f"p two-sided = {p_two:.6f}")
print(f"p one-sided (B>A) = {p_one:.6f}")

# continuity-corrected chi-square sanity check (4x4 table, Yates)
import statistics
n_total = na + nb
x11, x12 = xb, nb - xb
x21, x22 = xa, na - xa
expected_risk = p_pool
chi_yates = 0
for oi, ei in [(x11, expected_risk * nb), (x12, (1-expected_risk) * nb),
               (x21, expected_risk * na), (x22, (1-expected_risk) * na)]:
    chi_yates += (abs(oi - ei) - 0.5) ** 2 / ei
print(f"chi2 Yates = {chi_yates:.4f} (df=1, crit 3.841, 5%)")

ship_b = p_two < 0.05
result = {
    "ship_b": ship_b,
    "sessions_a": na,
    "sessions_b": nb,
    "completion_rate_a": round(pa, 4),
    "completion_rate_b": round(pb, 4),
    "p_value": round(p_two, 6),
}
with open(r"result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
