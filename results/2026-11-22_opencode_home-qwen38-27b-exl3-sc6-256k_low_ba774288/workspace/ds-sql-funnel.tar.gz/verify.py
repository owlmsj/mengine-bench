import sqlite3
c = sqlite3.connect('analytics.db')
print('non-test by platform:', c.execute('select platform, count(*) from users where is_test=0 group by platform').fetchall())
print('users w/ install event (non-test):', c.execute("select u.platform, count(*) from users u join events e on e.user_id=u.user_id where e.name='install' and u.is_test=0 group by u.platform").fetchall())
print('unknown players in events:', c.execute("select count(*) from events where user_id not in (select user_id from users)").fetchone())
print('test-account events:', c.execute("select count(*) from events e join users u on u.user_id=e.user_id where u.is_test=1").fetchone())
print('event names:', c.execute('select distinct name from events').fetchall())
