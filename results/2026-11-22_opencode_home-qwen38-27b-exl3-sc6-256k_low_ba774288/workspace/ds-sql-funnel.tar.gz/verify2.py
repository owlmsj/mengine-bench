import sqlite3
c = sqlite3.connect('analytics.db')
print('distinct users w/ install event (non-test):', c.execute("select u.platform, count(distinct u.user_id) from users u join events e on e.user_id=u.user_id where e.name='install' and u.is_test=0 group by u.platform").fetchall())
print('dup user_ids in users:', c.execute('select count(*) from (select user_id from users group by user_id having count(*)>1)').fetchone())
print('dup install events:', c.execute("select user_id, count(*) from events where name='install' group by user_id having count(*)>1 limit 5").fetchall())
