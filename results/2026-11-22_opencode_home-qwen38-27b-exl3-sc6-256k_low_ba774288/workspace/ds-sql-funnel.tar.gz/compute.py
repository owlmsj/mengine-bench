import sqlite3, json
c = sqlite3.connect('analytics.db')
STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']
users = {uid: (plat, test) for uid, plat, test in c.execute('select user_id, platform, is_test from users')}
funnel = {p: {s: 0 for s in STEPS} for p in sorted({plat for plat, _ in users.values()})}
for uid, (plat, test) in users.items():
    if test:
        continue
    evs = {s: [ts for ts in c.execute('select ts from events where user_id=? and name=?', (uid, s))] for s in STEPS}
    t = None
    for s in STEPS:
        valid = sorted(ts for ts in evs[s] if t is None or ts >= t)
        if valid and (t is not None or s == 'install'):
            t = valid[0]
            funnel[plat][s] += 1
result = {}
for p in funnel:
    f = funnel[p]
    conv = {}
    for i, s in enumerate(STEPS):
        if i == 0:
            continue
        conv[s] = (f[s] / f[STEPS[i-1]]) if f[STEPS[i-1]] else None
    biggest = min(conv, key=lambda s: (conv[s] is None, conv[s]))
    result[p] = {'funnel': f, 'biggest_drop': biggest}
with open('result.json', 'w') as fh:
    json.dump(result, fh, indent=2)
print(json.dumps(result, indent=2))
