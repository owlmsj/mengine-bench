use arena_scores::Board;
use std::thread;

fn main() {
    let board = Board::new();
    let players: Vec<u32> = (1..=8).collect();
    for p in &players {
        board.join(*p, 100);
    }
    assert_eq!(board.total(), 800);

    let nthreads = 16usize;
    let iters = 20_000usize;
    let mut handles = Vec::new();
    for t in 0..nthreads {
        let b = board.clone();
        let players = players.clone();
        handles.push(thread::spawn(move || {
            for i in 0..iters {
                let a = players[(t + i) % players.len()];
                let c = players[(t + i + 1) % players.len()];
                let d = players[(t + i + 3) % players.len()];
                // Both transfer directions at once (deadlock probe) + self-transfer (no-op).
                b.transfer(a, c, 1);
                b.transfer(c, a, 1);
                b.transfer(a, a, 5);
                // Mixed award/load pattern (lost-update probe).
                b.award(d, 1);
                let _ = b.score(a);
            }
        }));
    }
    for h in handles {
        h.join().unwrap();
    }

    // Invariants: total == sum of per-player scores; total unchanged by transfers.
    let sum: i64 = players.iter().map(|p| board.score(*p)).sum();
    assert_eq!(board.total(), sum, "total ({}) != sum of scores ({})", board.total(), sum);
    // Each player starts at 100; awards give iters times: each (t,i) pair awards to d once.
    let expected_awards: i64 = (nthreads * iters) as i64;
    assert_eq!(board.total(), 800 + expected_awards);
    println!("OK: total={} sum={} (transfers net zero, awards all counted, no deadlock)", board.total(), sum);
}
