Add-Type -AssemblyName System.Speech
$out = Join-Path $PSScriptRoot "announcement.wav"
if (Test-Path $out) { Remove-Item $out }
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
$s.SetOutputToWaveFile($out)
$s.Speak("Welcome aboard the evening ferry, please keep your bags clear of the doors.")
$s.Dispose()
Write-Output "saved $out"
