# H1 2026 close — CFO presentation notes

Figures from finance/ledger.csv (86 entries), finance/chart_of_accounts.csv, finance/cash_balance.txt.
All values in R$. EBITDA excludes the financial line (6.1.01 investment income, 6.1.02 interest/IOF).

| Month | Revenue | Gross margin % | EBITDA |
|---|---|---|---|
| 2026-01 | 200,510.87 | 70.03 | -210,278.96 |
| 2026-02 | 216,328.06 | 70.29 | -212,300.08 |
| 2026-03 | 219,066.17 | 68.46 | -204,525.45 |
| 2026-04 | 238,163.26 | 70.24 | -196,950.65 |
| 2026-05 | 243,032.89 | 69.56 | -201,945.82 |
| 2026-06 | 272,391.57 | 72.41 | -192,968.22 |

- H1 revenue: 1,389,492.86; June is the best month (+22% vs January, +12% vs May).
- EBITDA loss narrowing: -210.3k (Jan) -> -193.0k (Jun), ~8% improvement.
- Burn (board definition: average of the negative EBITDA of the last 3 closed months, Apr+May+Jun): 197,288.23 per month.
- Cash at 30/06/2026: 1,847,350.40 (was 2,309,188.00 at 31/05/2026; -461,837.60 in June, worse than the 197.3k EBITDA burn, i.e. ~264.5k of non-P&L cash outflows in June such as working capital / timing).
- Runway: 1,847,350.40 / 197,288.23 = 9.36 months (to ~mid-October 2027).

Assumptions:
1. "Last three closed months" = Apr, May, Jun 2026 (H1 is now closed per the brief).
2. EBITDA = revenue + COGS + sales&marketing + R&D + G&A; financial items excluded.
3. Refund account 3.1.09 (net -15,448.52 in H1) is part of revenue, so revenue is net of refunds.
4. Burn reported as a positive number (cash out per month).
