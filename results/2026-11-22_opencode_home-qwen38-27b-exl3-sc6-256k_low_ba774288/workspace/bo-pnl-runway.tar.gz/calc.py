import csv, json

def pt(s):
    s = s.strip().replace(".", "")
    return float(s.replace(",", "."))

coa = {}
with open("finance/chart_of_accounts.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        coa[row["account"]] = row["pnl_line"]

months = ["2026-01","2026-02","2026-03","2026-04","2026-05","2026-06"]
pnl = {m: {l: 0.0 for l in ["revenue","cogs","sales_marketing","rnd","ga","financial"]} for m in months}
n = 0
with open("finance/ledger.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        n += 1
        d = row["date"].strip()
        dd, mm, yy = d.split("/")
        m = yy + "-" + mm
        line = coa[row["account"].strip()]
        pnl[m][line] += pt(row["amount"])

rev = {m: round(pnl[m]["revenue"], 2) for m in months}
gp  = {m: round(pnl[m]["revenue"] + pnl[m]["cogs"], 2) for m in months}
gm  = {m: round(gp[m] / rev[m] * 100, 2) for m in months}
eb  = {m: round(pnl[m]["revenue"] + pnl[m]["cogs"] + pnl[m]["sales_marketing"] + pnl[m]["rnd"] + pnl[m]["ga"], 2) for m in months}

last3 = ["2026-04","2026-05","2026-06"]
avg_eb = sum(eb[m] for m in last3) / 3
burn = round(-avg_eb, 2)
cash = 1847350.40
runway = round(cash / burn, 2)

print("entries:", n)
print("revenue:", rev)
print("gross_profit:", gp)
print("gross_margin_pct:", gm)
print("ebitda:", eb)
print("avg EBITDA last 3 (Apr-Jun):", round(avg_eb, 2))
print("burn:", burn)
print("cash 30/06:", cash)
print("runway_months:", runway)

out = {m: {"revenue": rev[m], "gross_margin_pct": gm[m], "ebitda": eb[m]} for m in months}
json.dump({"revenue": rev, "gross_margin_pct": gm, "ebitda": eb,
          "burn": burn, "runway_months": runway}, open("result.json", "w"), indent=2)
print("result.json written")
