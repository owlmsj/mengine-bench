$w  = 70e9 / 1e9
$kv = 327680 * 32768 * 4 / 1e9
$tot = $w + $kv + 8
"weights=$w"
"kv=$kv"
"total=$tot"
Import-Csv ".\offers.csv" |
  Where-Object { $_.in_stock -eq 'yes' -and @('us-east','us-central','eu-west') -contains $_.region -and [double]$_.usd_per_hour -le 4 -and [int]$_.gpu_count * [double]$_.vram_gb_per_gpu -ge $tot } |
  Sort-Object { [double]$_.usd_per_hour } |
  ForEach-Object { "candidate: $($_.offer_id) $($_.usd_per_hour)/h mem=$([int]$_.gpu_count * [double]$_.vram_gb_per_gpu)GB monthly=$([math]::Round([double]$_.usd_per_hour * 730,2))" }
