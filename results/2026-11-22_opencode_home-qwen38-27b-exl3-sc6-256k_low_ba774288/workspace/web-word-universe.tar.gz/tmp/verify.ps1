$ErrorActionPreference='Stop'
$ws = "<WORKSPACE>"
$d = Get-Content (Join-Path $ws "words.json") -Raw | ConvertFrom-Json
$words = @($d.PSObject.Properties.Name)
$pairs = @{}
foreach ($k in $words) {
  foreach ($t in @($d.$k)) {
    $a = $k; $b = $t
    if ($a -gt $b) { $x = $a; $a = $b; $b = $x }
    $pairs["$a|$b"] = $true
  }
}
$deg = @{}
foreach ($p in $pairs.Keys) {
  $P = $p -split "\|"
  $deg[$P[0]] = ($deg[$P[0]] + 1)
  $deg[$P[1]] = ($deg[$P[1]] + 1)
}
$max = ($deg.Values | Measure-Object -Maximum).Maximum
$ties = @($deg.Keys | Where-Object { $deg[$_] -eq $max } | Sort-Object)
Write-Output ("words=" + $words.Count + " pairs=" + $pairs.Count + " maxdeg=" + $max + " ties=" + ($ties -join ","))
