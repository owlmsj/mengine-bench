$ErrorActionPreference='Stop'
$ws = "<WORKSPACE>"
$site = Join-Path $ws "site"
$tmp = Join-Path $ws "tmp"

function Normalize([string]$s){ return $s.Trim().ToLowerInvariant() }
function Get-Links([string]$c,[string]$id){
  $m = [regex]::Match($c, ('<section id="'+$id+'">.*?</section>'))
  if (-not $m.Success) { return @() }
  [regex]::Matches($m.Value, '<a href="([^"]+)"[^>]*>(.*?)</a>') | ForEach-Object {
    [pscustomobject]@{ href=$_.Groups[1].Value; text=$_.Groups[2].Value }
  }
}

$files = Get-ChildItem $site -Filter *.html | Where-Object { $_.Name -ine "index.html" }
$pages = @()
foreach ($f in $files) {
  $c = [IO.File]::ReadAllText($f.FullName)
  $h1 = if ($c -match '<h1>(.*?)</h1>') { $Matches[1].Trim() } else { $null }
  $tema = if ($c -match '<p class="tema">[^<]*:\s*(.*?)</p>') { $Matches[1].Trim() } else { $null }
  $redir = if ($c -match 'http-equiv="refresh"[^>]*url=([A-Za-z0-9._~%-]+)') { $Matches[1] } else { $null }
  $sin = Get-Links $c "sinonimos"; $ana = Get-Links $c "analogas"
  $isWord = ($null -ne $h1) -and (($null -ne $tema) -or ($sin.Count -gt 0) -or ($ana.Count -gt 0))
  $pages += [pscustomobject]@{ file=$f.Name; h1=$h1; tema=$tema; redir=$redir; sin=$sin; ana=$ana; isWord=$isWord }
}

$wordFiles = @{}   # lower file name -> normalized word (h1)
$redirMap  = @{}   # lower file name -> lower target file name
foreach ($p in $pages) {
  $k = $p.file.ToLowerInvariant()
  if ($p.isWord) { $wordFiles[$k] = Normalize $p.h1 }
  if ($null -ne $p.redir) { $redirMap[$k] = ([uri]::UnescapeDataString($p.redir)).ToLowerInvariant() }
}

function Resolve-Target([string]$href){
  $cur = ([uri]::UnescapeDataString($href)).ToLowerInvariant()
  for ($i = 0; $i -lt 5; $i++) {
    if ($wordFiles.ContainsKey($cur)) { return $wordFiles[$cur] }
    if ($redirMap.ContainsKey($cur)) { $cur = $redirMap[$cur] } else { return $null }
  }
  return $null
}

$words = [ordered]@{}
function Ensure-Word([string]$w,[string]$display,[string]$tema){
  if (-not $script:words.Contains($w)) {
    $script:words[$w] = [ordered]@{ d=$display; t=$tema; sin=@(); ana=@() }
  }
  elseif ($null -eq $script:words[$w].t -and $null -ne $tema) { $script:words[$w].t = $tema }
}
$deadLinks = 0; $deadList = @()
foreach ($p in $pages) {
  if (-not $p.isWord) { continue }
  $w = Normalize $p.h1
  Ensure-Word $w $p.h1 $p.tema
  foreach ($l in $p.sin) { $t = Resolve-Target $l.href; if ($null -eq $t) { $script:deadLinks++; $script:deadList += ($p.file+' -> '+$l.href) } elseif ($t -ne $w) { $script:words[$w].sin += $t } }
  foreach ($l in $p.ana) { $t = Resolve-Target $l.href; if ($null -eq $t) { $script:deadLinks++; $script:deadList += ($p.file+' -> '+$l.href) } elseif ($t -ne $w) { $script:words[$w].ana += $t } }
}
foreach ($k in $words.Keys) {
  $words[$k].sin = @($words[$k].sin | Sort-Object -Unique)
  $words[$k].ana = @($words[$k].ana | Sort-Object -Unique)
}

# words.json : word -> linked words (union of sin+ana)
$map = [ordered]@{}
foreach ($k in $words.Keys | Sort-Object) {
  $u = [ordered]@{}
  foreach ($t in ($words[$k].sin + $words[$k].ana)) { if ($t -ne $k -and -not $u.Contains($t)) { $u[$t] = $true } }
  $map[$k] = @($u.Keys)
}
$map | ConvertTo-Json -Depth 4 | Set-Content (Join-Path $ws "words.json") -Encoding UTF8

# undirected pairs + degree
$pairs = @{}
foreach ($k in $words.Keys) { foreach ($t in ($words[$k].sin + $words[$k].ana)) { $a=$k; $b=$t; if ($a -gt $b) { $a=$t; $b=$k }; $pairs["$a`t$b"] = $true } }
$deg = @{}
foreach ($k in $words.Keys) { $deg[$k] = 0 }
foreach ($pair in $pairs.Keys) { $P = $pair -split "`t"; $deg[$P[0]]++; $deg[$P[1]]++ }
$max = ($deg.Values | Measure-Object -Maximum).Maximum
$most = ($deg.Keys | Where-Object { $deg[$_] -eq $max } | Sort-Object)[0]
$top = $deg.GetEnumerator() | Sort-Object { $_.Value } -Descending | Select-Object -First 12

$lines = @()
$lines += "pages parsed: $($pages.Count)"
$lines += "word entries: $($words.Count)"
$lines += "redirect stubs: $(($pages | Where-Object { $null -ne $_.redir }).Count)"
$lines += "dead links dropped: $deadLinks"
foreach ($d in ($deadList | Sort-Object -Unique)) { $lines += "  dead: $d" }
$lines += "relations (distinct pairs): $($pairs.Count)"
$lines += "most_connected: $most (deg $max)"
$lines += "--- top 12 degree ---"
foreach ($t in $top) { $lines += ("{0,3}  {1}" -f $t.Value, $t.Key) }
$lines += "--- words with 0 links ---"
$lines += (($words.Keys | Where-Object { @($map[$_]).Count -eq 0 }) -join ", ")
$lines += "--- temas ---"
$tm = @{}
foreach ($k in $words.Keys) { if ($words[$k].t) { $x=$words[$k].t; $tm[$x] = ($tm[$x]+1) } }
foreach ($t in ($tm.GetEnumerator() | Sort-Object Value -Descending)) { $lines += ("{0,3}  {1}" -f $t.Value, $t.Key) }
$lines += "words without tema: $(($words.Keys | Where-Object { -not $words[$_].t }).Count)"
$lines | Out-File (Join-Path $tmp "report.txt") -Encoding UTF8

$uni = [ordered]@{}
foreach ($k in $words.Keys | Sort-Object) {
  $uni[$k] = [ordered]@{ d=$words[$k].d; t=$words[$k].t; sin=$words[$k].sin; ana=$words[$k].ana }
}
$uni | ConvertTo-Json -Depth 5 | Out-File (Join-Path $tmp "universe_data.json") -Encoding UTF8
Get-Content (Join-Path $tmp "report.txt")
