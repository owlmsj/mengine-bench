$ErrorActionPreference='Stop'
$ws = "<WORKSPACE>"
$html = [IO.File]::ReadAllText("$ws\tmp\template.html")
$json = [IO.File]::ReadAllText("$ws\tmp\universe_data.json")
if ($json.Length -gt 0 -and $json[0] -eq [char]0xFEFF) { $json = $json.Substring(1) }
$out = $html.Replace("__DATA__", $json)
New-Item -ItemType Directory -Force "$ws\universe" | Out-Null
[IO.File]::WriteAllText("$ws\universe\index.html", $out)
Write-Output ("bytes: " + (Get-Item "$ws\universe\index.html").Length)
