import re, sys

pat = open("regex.txt", encoding="utf-8").read().strip()
print("pattern ok:", bool(pat))

# --- sample log ---
log = open("server.log", encoding="utf-8").read()
got = re.findall(pat, log, re.MULTILINE)
print("sample:", got)

# --- synthetic edge cases ---
cases = [
    # (line, expected)
    ("2026-04-02 07:15:09 INFO  gateway accepted 10.12.0.7 for build 2026-04-01", ["2026-04-01"]),
    ("2026-04-02 07:15:11 INFO  cache warm, 412 keys, next sweep 2026-04-03", []),
    ("2026-04-02 07:16:40 WARN  peer 192.168.40.3 slow, retry window 2026-04-02 to 2026-04-05", ["2026-04-05"]),
    ("2026-04-02 07:18:02 INFO  job 7781-20-4410 queued by scheduler", []),
    ("2026-04-02 07:19:30 ERROR upstream 172.20.1.14 refused handshake", []),
    # multiple dates, last one wins
    ("2026-01-01 00:00:00 INFO a 1.2.3.4 b 2026-01-02 c 2026-01-03", ["2026-01-03"]),
    # date before address only
    ("2026-01-01 00:00:00 INFO 9.9.9.9 start 2026-01-01", ["2026-01-01"]),
    # address with leading zero part -> not an address
    ("2026-01-01 00:00:00 INFO 192.168.040.3 down 2026-01-02", []),
    # address part 256 -> not an address
    ("2026-01-01 00:00:00 INFO 256.1.1.1 down 2026-01-02", []),
    # address part 255 ok
    ("2026-01-01 00:00:00 INFO 255.255.255.255 up 2026-01-02", ["2026-01-02"]),
    # address part 0 ok
    ("2026-01-01 00:00:00 INFO 0.0.0.0 up 2026-01-02", ["2026-01-02"]),
    # address glued to letters -> not an address
    ("2026-01-01 00:00:00 INFO abc10.1.1.1 up 2026-01-02", []),
    ("2026-01-01 00:00:00 INFO 10.1.1.1xyz up 2026-01-02", []),
    # address glued to digits -> not an address
    ("2026-01-01 00:00:00 INFO 110.1.1.1 up 2026-01-02", []),
    ("2026-01-01 00:00:00 INFO 10.1.1.12 up 2026-01-02", []),
    # date glued to letters/digits -> not a date
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up x2026-01-02", []),
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up 2026-01-02x", []),
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up 2026-01-023", []),
    # invalid calendar dates
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up 2026-02-30", []),
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up 2026-04-31", []),
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up 2026-06-31", []),
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up 2026-00-10", []),
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up 2026-13-01", []),
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up 2026-01-00", []),
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up 2026-01-32", []),
    # Feb 29 allowed in every year (per brief)
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up 2026-02-29", ["2026-02-29"]),
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up 1900-02-29", ["1900-02-29"]),
    # Feb 30 never
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up 2026-02-30", []),
    # 31-day months
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up 2026-12-31", ["2026-12-31"]),
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up 2026-07-31", ["2026-07-31"]),
    # 30-day months
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up 2026-09-30", ["2026-09-30"]),
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up 2026-04-30", ["2026-04-30"]),
    # no date at all but address present
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up", []),
    # date at line start, address later
    ("2026-01-01 00:00:00 INFO 1.1.1.1", ["2026-01-01"]),
    # address then date then address
    ("2026-01-01 00:00:00 INFO 1.1.1.1 2026-01-05 2.2.2.2 2026-01-06", ["2026-01-06"]),
    # timestamp date + address + later date: last date overall
    ("2026-04-02 07:15:09 INFO 10.12.0.7 build 2026-04-01", ["2026-04-01"]),
    # date with address in same "word" via hyphen? 2026-01-01-1.2.3.4 -> date glued to digit
    ("2026-01-01 00:00:00 INFO 1.1.1.1 up 2026-01-01-2", []),
    # address with 5 parts -> not a valid address (1.2.3.4.5)
    ("2026-01-01 00:00:00 INFO 1.2.3.4.5 up 2026-01-02", []),
    # single-part number not an address
    ("2026-01-01 00:00:00 INFO 12345 up 2026-01-02", []),
    # address at line end
    ("2026-01-01 00:00:00 INFO up 2026-01-03 8.8.8.8", ["2026-01-03"]),
    # date at line end
    ("2026-01-01 00:00:00 INFO 8.8.8.8 up 2026-01-04", ["2026-01-04"]),
    # empty line
    ("", []),
    # line with only address
    ("INFO 8.8.8.8", []),
    # line with only date
    ("INFO 2026-01-05", []),
]

fails = 0
for line, exp in cases:
    got = re.findall(pat, line + "\n", re.MULTILINE)
    if got != exp:
        fails += 1
        print(f"FAIL line={line!r} expected={exp} got={got}")
print(f"edge cases: {len(cases)-fails}/{len(cases)} passed")
sys.exit(1 if fails else 0)