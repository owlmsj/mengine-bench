import re, json, os, glob, unicodedata, sys, urllib.parse

sys.stdout.reconfigure(encoding='utf-8')
site = r'<WORKSPACE>\site'
ws = r'<WORKSPACE>'

def norm(s):
    return unicodedata.normalize('NFC', s)

def noacc(s):
    return ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn').lower()

pages = {}  # stem -> dict
for f in glob.glob(os.path.join(site, '*.html')):
    stem = os.path.splitext(os.path.basename(f))[0]
    if stem in ('index', 'sobre', 'contato'):
        continue
    html = open(f, encoding='utf-8').read()
    m = re.search(r'<main><h1>(.*?)</h1>', html)
    if not m:
        continue
    display = norm(m.group(1))
    tm = re.search(r'class="tema">Tema: (.*?)</p>', html)
    theme = norm(tm.group(1)) if tm else None
    links = {}  # target stem -> set(types)
    for sec_id, sec_type in (('sinonimos', 'sinonimo'), ('analogas', 'analogas')):
        sm = re.search(r'<section id="%s">.*?<ul>(.*?)</ul>' % sec_id, html, re.S)
        if sm:
            for am in re.finditer(r'<a href="([^"]+)">(.*?)</a>', sm.group(1)):
                href = urllib.parse.unquote(am.group(1))
                t = href[:-5] if href.endswith('.html') else href
                links.setdefault(t, set()).add(sec_type)
    pages[stem] = {'display': display, 'theme': theme, 'links': links}

# stem -> display map (case-insensitive)
stem_map = {noacc(s): s for s in pages}
# display word (accent-insensitive) -> display
disp_map = {noacc(v['display']): v['display'] for v in pages.values()}

def resolve(target):
    t = noacc(target)
    if t in stem_map:
        return pages[stem_map[t]]['display']
    if t in disp_map:
        return disp_map[t]
    return None

words = {}
broken = {}
for stem, v in pages.items():
    d = v['display']
    linked = {}
    for t, types in v['links'].items():
        r = resolve(t)
        if r is None:
            broken.setdefault(d, []).append(t)
        else:
            linked.setdefault(r, set()).update(types)
    words[d] = {'display': d, 'theme': v['theme'], 'links': {k: sorted(v2) for k, v2 in linked.items()}}

print('words:', len(words))
print('broken link sources:', {k: v for k, v in broken.items()})

# words.json: display -> sorted list of linked display words
out = {d: sorted(v['links'].keys()) for d, v in words.items()}
json.dump(out, open(os.path.join(ws, 'words.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# relations: distinct unordered pairs
pairs = set()
for d, v in words.items():
    for t in v['links']:
        if t in words:
            a, b = sorted([d, t])
            pairs.add((a, b))
print('distinct pairs:', len(pairs))

deg = {d: 0 for d in words}
for a, b in pairs:
    deg[a] += 1
    deg[b] += 1
top = sorted(deg.items(), key=lambda x: (-x[1], x[0]))[:8]
print('top:', top)

# full data for UI embedding
ui = {
    'words': {d: {'theme': v['theme'], 'links': v['links']} for d, v in words.items()},
}
json.dump(ui, open(os.path.join(ws, 'ui_data.json'), 'w', encoding='utf-8'), ensure_ascii=False)

mc = top[0]
result = {'words': len(words), 'relations': len(pairs), 'most_connected': mc[0]}
json.dump(result, open(os.path.join(ws, 'result.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('result:', result)

# theme distribution
from collections import Counter
c = Counter(v['theme'] for v in words.values())
print('themes:', dict(c))