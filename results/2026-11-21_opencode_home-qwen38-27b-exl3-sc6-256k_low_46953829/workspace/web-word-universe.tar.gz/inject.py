import json, io, sys
ws = r'<WORKSPACE>'
data = json.load(open(ws + r'\ui_data.json', encoding='utf-8'))
html = open(ws + r'\universe\index.html', encoding='utf-8').read()
payload = json.dumps(data, ensure_ascii=False)
# guard against </script> in payload (there is none, but be safe)
payload = payload.replace('</', '<\\/')
assert '__DATA__' in html
html = html.replace('__DATA__', payload)
open(ws + r'\universe\index.html', 'w', encoding='utf-8').write(html)
print('injected, size:', len(html))
print('has DATA const:', 'const DATA = {' in html)
print('saudade present:', '"saudade"' in html)