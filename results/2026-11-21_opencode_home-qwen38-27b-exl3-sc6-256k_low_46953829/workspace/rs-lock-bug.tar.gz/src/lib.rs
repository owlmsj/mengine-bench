//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    ///
    /// The read-modify-write happens under a single lock hold for the slot
    /// and a single lock hold for the total, so concurrent awards never
    /// lose an update.
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        *slot.lock().unwrap() += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    ///
    /// The two slots are locked in a fixed order (by `PlayerId`) so that
    /// concurrent transfers in opposite directions cannot deadlock.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return;
        }
        let (first, second) = if from < to {
            (self.slot(from), self.slot(to))
        } else {
            (self.slot(to), self.slot(from))
        };
        let mut first_score = first.lock().unwrap();
        let mut second_score = second.lock().unwrap();
        if from < to {
            *first_score -= points;
            *second_score += points;
        } else {
            *first_score += points;
            *second_score -= points;
        }
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}