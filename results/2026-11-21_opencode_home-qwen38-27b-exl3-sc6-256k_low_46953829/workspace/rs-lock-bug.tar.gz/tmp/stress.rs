// Concurrency stress check for arena_scores (scratch, not part of the crate).
use arena_scores::Board;
use std::sync::Arc;
use std::thread;

fn main() {
    // 1) Deadlock check: opposite-direction transfers must not hang.
    let b = Arc::new(Board::new());
    b.join(1, 100);
    b.join(2, 100);
    let mut hs = Vec::new();
    for _ in 0..8 {
        let b1 = Arc::clone(&b);
        hs.push(thread::spawn(move || {
            for _ in 0..2000 {
                b1.transfer(1, 2, 1);
            }
        }));
        let b2 = Arc::clone(&b);
        hs.push(thread::spawn(move || {
            for _ in 0..2000 {
                b2.transfer(2, 1, 1);
            }
        }));
    }
    for h in hs {
        h.join().unwrap();
    }
    assert_eq!(b.total(), 200, "total changed by transfer");
    assert_eq!(b.score(1) + b.score(2), b.total(), "scores do not sum to total");
    println!("deadlock check OK: total={} s1={} s2={}", b.total(), b.score(1), b.score(2));

    // 2) Lost-update check: concurrent awards must not lose points.
    let c = Arc::new(Board::new());
    c.join(1, 0);
    let mut hs = Vec::new();
    for _ in 0..16 {
        let c1 = Arc::clone(&c);
        hs.push(thread::spawn(move || {
            for _ in 0..5000 {
                c1.award(1, 1);
            }
        }));
    }
    for h in hs {
        h.join().unwrap();
    }
    assert_eq!(c.score(1), 16 * 5000, "award lost updates");
    assert_eq!(c.total(), 16 * 5000, "total lost updates");
    println!("lost-update check OK: score={} total={}", c.score(1), c.total());

    // 3) Mixed load: awards + transfers + reads concurrently; total invariant.
    let d = Arc::new(Board::new());
    d.join(1, 0);
    d.join(2, 0);
    let mut hs = Vec::new();
    for _ in 0..8 {
        let d1 = Arc::clone(&d);
        hs.push(thread::spawn(move || {
            for i in 0..2000 {
                if i % 2 == 0 { d1.award(1, 1); } else { d1.award(2, 1); }
            }
        }));
    }
    for _ in 0..8 {
        let d2 = Arc::clone(&d);
        hs.push(thread::spawn(move || {
            for _ in 0..2000 {
                d2.transfer(1, 2, 1);
            }
        }));
    }
    for h in hs {
        h.join().unwrap();
    }
    assert_eq!(d.total(), 16000, "mixed total wrong");
    assert_eq!(d.score(1) + d.score(2), d.total(), "mixed scores do not sum to total");
    println!("mixed check OK: total={} s1={} s2={}", d.total(), d.score(1), d.score(2));

    println!("ALL STRESS CHECKS PASSED");
}