import csv, json, re
from decimal import Decimal

BASE = r"<WORKSPACE>\finance"

def parse_amt(s):
    # pt-BR: '.' thousands, ',' decimal
    s = s.strip()
    neg = s.startswith('-')
    s = s.lstrip('-')
    s = s.replace('.', '').replace(',', '.')
    d = Decimal(s)
    return -d if neg else d

# chart of accounts
coa = {}
with open(BASE + r"\chart_of_accounts.csv", encoding="utf-8") as f:
    r = csv.reader(f, delimiter=";")
    header = next(r)
    for row in r:
        if not row or not row[0].strip():
            continue
        acct, name, pnl = [c.strip() for c in row]
        coa[acct] = pnl

# ledger
months = ["2026-01","2026-02","2026-03","2026-04","2026-05","2026-06"]
# per-month, per-line sums (signed, revenue positive, costs negative)
sums = {m: {l: Decimal(0) for l in ["revenue","cogs","sales_marketing","rnd","ga","financial"]} for m in months}
counts = {m: 0 for m in months}
with open(BASE + r"\ledger.csv", encoding="utf-8") as f:
    r = csv.reader(f, delimiter=";")
    header = next(r)
    for row in r:
        if not row or not row[0].strip():
            continue
        date, acct, desc, amt = [c.strip() for c in row]
        # date dd/mm/yyyy
        d, m, y = date.split("/")
        month = f"{y}-{m}"
        line = coa.get(acct)
        if line is None:
            raise SystemExit(f"unknown account {acct}")
        a = parse_amt(amt)
        sums[month][line] += a
        counts[month] += 1

out = {}
report = {}
for m in months:
    s = sums[m]
    revenue = s["revenue"]
    cogs = s["cogs"]
    gross = revenue + cogs  # cogs negative
    gm = (gross / revenue * 100) if revenue != 0 else Decimal(0)
    opex = s["sales_marketing"] + s["rnd"] + s["ga"]
    ebitda = gross + opex
    out[m] = {
        "revenue": float(revenue),
        "gross_margin_pct": float(gm),
        "ebitda": float(ebitda),
    }
    report[m] = dict(revenue=float(revenue), cogs=float(cogs), gross=float(gross),
                     opex=float(opex), ebitda=float(ebitda), n=counts[m])

# burn: avg monthly negative EBITDA of last three closed months (Apr, May, Jun)
def ebitda_of(m):
    s = sums[m]
    gross = s["revenue"] + s["cogs"]
    opex = s["sales_marketing"] + s["rnd"] + s["ga"]
    return gross + opex

last3 = ["2026-04","2026-05","2026-06"]
ebits = [ebitda_of(m) for m in last3]
neg = [Decimal(0) if e >= 0 else -e for e in ebits]
burn = sum(neg) / 3

# cash latest
cash = Decimal("1847350.40")
runway = cash / burn if burn > 0 else None

result = {
    "revenue": {m: round(out[m]["revenue"], 2) for m in months},
    "gross_margin_pct": {m: round(out[m]["gross_margin_pct"], 2) for m in months},
    "ebitda": {m: round(out[m]["ebitda"], 2) for m in months},
    "burn": round(float(burn), 2),
    "runway_months": round(float(runway), 2),
}

with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)

print("=== per month ===")
for m in months:
    r = report[m]
    print(f"{m} n={r['n']:2d} rev={r['revenue']:>12,.2f} cogs={r['cogs']:>12,.2f} "
          f"gross={r['gross']:>12,.2f} opex={r['opex']:>12,.2f} ebitda={r['ebitda']:>12,.2f}")
print("=== last3 ebitda ===")
for m in last3:
    print(m, f"{ebitda_of(m):,.2f}")
print("burn =", f"{burn:,.2f}")
print("cash =", f"{cash:,.2f}")
print("runway =", f"{runway:.4f}")
print("total ledger entries:", sum(counts.values()))