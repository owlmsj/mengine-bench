import csv, json

rows = []
with open(r"<WORKSPACE>\capture\presentmon.csv", newline="") as f:
    for row in csv.DictReader(f):
        rows.append(row)
mbp = [float(x["MsBetweenPresents"]) for x in rows]
n = len(mbp)
avg_fps = 1000.0/(sum(mbp)/n)
s = sorted(mbp)
k = 0.99*(n-1); lo = s[int(k)]; hi = s[min(int(k)+1, n-1)]
p99 = lo + (hi-lo)*(k-int(k))
low1 = 1000.0/p99

sens = {}
with open(r"<WORKSPACE>\capture\sensors.csv", newline="") as f:
    for row in csv.DictReader(f):
        sens[int(row["time_s"])] = row

l1_secs = [sec for sec, r in sens.items() if r["gpu_pcie_link_state"] == "L1"]
big = [(float(x["TimeInSeconds"]), float(x["MsBetweenPresents"])) for x in rows if float(x["MsBetweenPresents"]) > 15]
in_l1 = sum(1 for t, m in big if int(t) in l1_secs)
print("L1 seconds:", l1_secs)
print("big frames:", len(big), "in L1 seconds:", in_l1)
print("avg_fps=%.2f low1pct=%.2f p99=%.3f" % (avg_fps, low1, p99))

result = {
  "avg_fps": round(avg_fps, 2),
  "low_1pct_fps": round(low1, 2),
  "cause": "Hitches occur in ~12-frame bursts every ~4 s, each time the GPU PCIe link drops from L0 to L1 (ASPM L1 on the GPU root port, pcie_aspm_rp1_gpu=L1 in BIOS). Every one of the 180 slow frames (>15 ms, ~21-24 ms vs ~7 ms normal) lands in a second where the sensor log shows gpu_pcie_link_state=L1, and frame times return to ~7 ms as soon as the link is back in L0. A secondary, smaller contributor: at t=43-45 s a Windows Defender (MsMpEng.exe) scan burst drove DPC latency to ~400-455 us and disk to 80-94% (no exclusion for the game), adding DPC stalls on top.",
  "changes": [
    {"setting": "pcie_aspm_rp1_gpu", "from": "L1", "to": "disabled"},
    {"setting": "defender_exclusions", "from": "[]", "to": "exclude Arena.exe and its install directory from real-time scanning"}
  ]
}
with open(r"<WORKSPACE>\result.json", "w") as f:
    json.dump(result, f, indent=2)
print("written")