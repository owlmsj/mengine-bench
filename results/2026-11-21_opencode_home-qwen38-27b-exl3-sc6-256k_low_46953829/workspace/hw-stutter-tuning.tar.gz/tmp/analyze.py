import csv, statistics

rows = []
with open(r"<WORKSPACE>\capture\presentmon.csv", newline="") as f:
    r = csv.DictReader(f)
    for row in r:
        rows.append(row)

mbp = [float(x["MsBetweenPresents"]) for x in rows]
t0 = float(rows[0]["TimeInSeconds"]); t1 = float(rows[-1]["TimeInSeconds"])
n = len(mbp)
mean_mbp = sum(mbp)/n
avg_fps = 1000.0/mean_mbp
# p99 by nearest-rank
s = sorted(mbp)
k = int(0.99*(n-1))  # linear interp index
lo = s[k]; hi = s[min(k+1, n-1)]; frac = 0.99*(n-1)-k
p99 = lo + (hi-lo)*frac
low1 = 1000.0/p99
print("n frames:", n, "span s:", round(t1-t0,3))
print("avg_fps:", round(avg_fps,2), "p99_ms:", round(p99,3), "low1pct_fps:", round(low1,2))
print("max ms:", max(mbp), "min ms:", min(mbp))
# big gaps
big = [(float(x["TimeInSeconds"]), float(x["MsBetweenPresents"])) for x in rows if float(x["MsBetweenPresents"]) > 15]
print("frames >15ms:", len(big))
for t,m in big: print("  t=%.3f ms=%.2f" % (t,m))
# correlation with sensor: L1 seconds
sens = {}
with open(r"<WORKSPACE>\capture\sensors.csv", newline="") as f:
    for row in csv.DictReader(f):
        sens[int(row["time_s"])] = row
# per-second mean frame time
buckets = {}
for x in rows:
    sec = int(float(x["TimeInSeconds"]))
    buckets.setdefault(sec, []).append(float(x["MsBetweenPresents"]))
print("sec state dpc disk ms_mean ms_max")
for sec in sorted(buckets):
    b = buckets[sec]
    srow = sens.get(sec, {})
    print(sec, srow.get("gpu_pcie_link_state","?"), srow.get("dpc_latency_us","?"), srow.get("disk_active_pct","?"),
          round(sum(b)/len(b),2), max(b))