# HANDOFF — local-9b Q5 @ 128k

Goal: measure local-9b Q5 at 128k, run clean on local GPU.

Done (per transcript):
- Baseline 37.8 t/s, VRAM 7881 MiB — but 7881 is the WDDM ceiling; Shared Usage shows 1494 MiB spilled. The spill is the real bug.
- Fix: `--no-mmproj-offload` + `-ub 512` kills the spill → 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) doesn't fit at 128k — discarded. Q4_K_M fits (7305 MiB, 40.4 t/s) — fallback only.
- Recipe applied in `scripts/start_server.ps1:165` (local9 block) and `profiles/local/local-9b.json`.

Left:
1. evals README still cites `check_vision.ps1` (no longer exists) — fix it.
2. Review scratchpad temp-file names (noted repeatedly, never done).

Assumptions:
- The real repo (scripts/profiles/README) is NOT in this workspace — only `session/transcript.md` + `AGENTS.md` are here. Work in the real repo.
- "Done" = recipe applied + README fixed + scratchpad names reviewed.

How I know it's right:
- Numbers are the transcript's own measurement notes (median of 3, spill counter), not re-run here.
- I verified this workspace holds only transcript + AGENTS.md, so the applied-recipe claim is taken from the transcript, not re-checked against files.