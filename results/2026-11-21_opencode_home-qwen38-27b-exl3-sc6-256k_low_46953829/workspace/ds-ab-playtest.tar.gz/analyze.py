import csv, json, math
from collections import Counter

path = r"<WORKSPACE>\telemetry\playtest_ab.csv"

rows = []
with open(path, newline="", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        rows.append(r)

print("total rows:", len(rows))

# normalize variant
def norm_variant(v):
    return v.strip().lower()

# check for conflicts: same session_id with different completed_tutorial or variant
by_sid = {}
conflicts = 0
for r in rows:
    sid = r["session_id"].strip()
    v = norm_variant(r["variant"])
    comp = r["completed_tutorial"].strip()
    if sid not in by_sid:
        by_sid[sid] = {"variant": v, "completed": comp}
    else:
        e = by_sid[sid]
        if e["variant"] != v or e["completed"] != comp:
            conflicts += 1
            print("CONFLICT", sid, e, (v, comp))

print("unique sessions:", len(by_sid))
print("conflicting duplicates:", conflicts)

# variant distribution (raw and normalized)
raw_variants = Counter(r["variant"] for r in rows)
print("raw variant values:", dict(raw_variants))
norm_variants = Counter(norm_variant(r["variant"]) for r in rows)
print("normalized variant values:", dict(norm_variants))

# check completed values
comp_vals = Counter(r["completed_tutorial"].strip() for r in rows)
print("completed values:", dict(comp_vals))

# aggregate per variant over unique sessions
a_n = a_c = b_n = b_c = 0
for sid, e in by_sid.items():
    if e["variant"] == "a":
        a_n += 1
        a_c += int(e["completed"])
    elif e["variant"] == "b":
        b_n += 1
        b_c += int(e["completed"])
    else:
        print("UNEXPECTED VARIANT", sid, e)

print(f"A: n={a_n} completed={a_c}")
print(f"B: n={b_n} completed={b_c}")

p_a = a_c / a_n
p_b = b_c / b_n
print(f"p_a={p_a:.6f} p_b={p_b:.6f} diff={p_b-p_a:.6f}")

# two-proportion z-test, two-sided, pooled
p_pool = (a_c + b_c) / (a_n + b_n)
se = math.sqrt(p_pool * (1 - p_pool) * (1/a_n + 1/b_n))
z = (p_b - p_a) / se
# normal CDF via erf
def norm_cdf(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))
p_value = 2 * (1 - norm_cdf(abs(z)))
print(f"z={z:.4f} p_value={p_value:.6f}")

# also continuity-corrected (Haldane) for the skeptical lead
se_cc = math.sqrt(p_pool * (1 - p_pool) * (1/a_n + 1/b_n))
z_cc = (abs(p_b - p_a) - 0.5 * (1/a_n + 1/b_n)) / se_cc
p_cc = 2 * (1 - norm_cdf(abs(z_cc)))
print(f"continuity-corrected z={z_cc:.4f} p={p_cc:.6f}")

# Fisher exact (two-sided) via hypergeometric for robustness
from math import comb
# table: a_c, a_n-a_c, b_c, b_n-b_c
def fisher_two_sided(x11, x12, x21, x22):
    n = x11 + x12 + x21 + x22
    r1 = x11 + x12
    r2 = x21 + x22
    c1 = x11 + x21
    c2 = x12 + x22
    def pmf(k):
        lo = max(0, r1 - c2)
        hi = min(r1, c1)
        if k < lo or k > hi:
            return 0.0
        return comb(c1, k) * comb(c2, r1 - k) / comb(n, r1)
    p_obs = pmf(x11)
    tot = 0.0
    for k in range(max(0, r1 - c2), min(r1, c1) + 1):
        pk = pmf(k)
        if pk <= p_obs + 1e-15:
            tot += pk
    return tot

p_fisher = fisher_two_sided(a_c, a_n - a_c, b_c, b_n - b_c)
print(f"fisher two-sided p={p_fisher:.6f}")

result = {
    "ship_b": bool(p_value < 0.05 and p_b > p_a),
    "sessions_a": a_n,
    "sessions_b": b_n,
    "completion_rate_a": p_a,
    "completion_rate_b": p_b,
    "p_value": p_value,
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))