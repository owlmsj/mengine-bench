import sqlite3, json

c = sqlite3.connect('analytics.db')
steps = ['install', 'tutorial_complete', 'first_match', 'purchase']

# non-test players per platform
players = {}
for uid, platform, is_test in c.execute('select user_id, platform, is_test from users'):
    if not is_test:
        players.setdefault(platform, {})[uid] = None

# first valid occurrence of each event per player, honoring ordering:
# a step counts only at or after the same player's previous step.
# Interpretation: for each player, walk steps in order; step i counts if there is
# an event with ts >= ts of step i-1 (first such event). No time limit.
# Events from unknown players (not in users) do not count.
events = {}
for uid, name, ts in c.execute('select user_id, name, ts from events'):
    events.setdefault(uid, {}).setdefault(name, []).append(ts)

funnel = {}
biggest = {}
for platform in sorted(players):
    counts = {}
    for step in steps:
        n = 0
        for uid in players[platform]:
            # find first valid occurrence of this step at/after previous step ts
            prev_ts = None
            ok = True
            for s in steps:
                if s == step:
                    break
                ts_list = sorted(events.get(uid, {}).get(s, []))
                if not ts_list:
                    ok = False
                    break
                prev_ts = ts_list[0]
            if not ok:
                continue
            ts_list = sorted(events.get(uid, {}).get(step, []))
            if not ts_list:
                continue
            if prev_ts is None or ts_list[0] >= prev_ts:
                n += 1
        counts[step] = n
    funnel[platform] = counts
    # biggest drop: step with lowest conversion (players / previous step players)
    best_step, best_conv = None, None
    for i, s in enumerate(steps):
        if i == 0:
            continue
        prev = counts[steps[i-1]]
        if prev == 0:
            conv = 0.0
        else:
            conv = counts[s] / prev
        if best_conv is None or conv < best_conv:
            best_conv = conv
            best_step = s
    biggest[platform] = best_step

result = {'funnel': funnel, 'biggest_drop': biggest}
print(json.dumps(result, indent=2))
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)