import sqlite3
c = sqlite3.connect('analytics.db')
# Independent cross-check: for each platform, count non-test players who have a
# valid chain up to each step (each step's first event ts >= previous step's first event ts).
# Use SQL to get first event ts per (user, event) then join.
q = """
WITH first_ts AS (
  SELECT user_id, name, min(ts) AS ts
  FROM events
  GROUP BY user_id, name
)
SELECT u.platform,
  count(CASE WHEN e1.ts IS NOT NULL THEN 1 END) AS install,
  count(CASE WHEN e1.ts IS NOT NULL AND e2.ts IS NOT NULL AND e2.ts >= e1.ts THEN 1 END) AS tutorial,
  count(CASE WHEN e1.ts IS NOT NULL AND e2.ts IS NOT NULL AND e2.ts >= e1.ts
             AND e3.ts IS NOT NULL AND e3.ts >= e2.ts THEN 1 END) AS first_match,
  count(CASE WHEN e1.ts IS NOT NULL AND e2.ts IS NOT NULL AND e2.ts >= e1.ts
             AND e3.ts IS NOT NULL AND e3.ts >= e2.ts
             AND e4.ts IS NOT NULL AND e4.ts >= e3.ts THEN 1 END) AS purchase
FROM users u
LEFT JOIN first_ts e1 ON e1.user_id = u.user_id AND e1.name = 'install'
LEFT JOIN first_ts e2 ON e2.user_id = u.user_id AND e2.name = 'tutorial_complete'
LEFT JOIN first_ts e3 ON e3.user_id = u.user_id AND e3.name = 'first_match'
LEFT JOIN first_ts e4 ON e4.user_id = u.user_id AND e4.name = 'purchase'
WHERE u.is_test = 0
GROUP BY u.platform
"""
for row in c.execute(q):
    print(row)

# Also check: are there events for users not in users table?
print('events for unknown users:', c.execute("""
  select count(*) from events e where not exists (select 1 from users u where u.user_id = e.user_id)
""").fetchone()[0])
# check event names present
print('event names:', [r[0] for r in c.execute('select distinct name from events')])
# check platforms
print('platforms:', [r[0] for r in c.execute('select distinct platform from users')])
# check is_test values
print('is_test values:', [r[0] for r in c.execute('select distinct is_test from users')])