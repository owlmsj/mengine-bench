import sqlite3
c = sqlite3.connect('analytics.db')
for name, sql in c.execute("select name, sql from sqlite_master where type='table'"):
    print(name)
    print(sql)
    print('---')
for t in [r[0] for r in c.execute("select name from sqlite_master where type='table'")]:
    print(t, 'rows:', c.execute(f'select count(*) from "{t}"').fetchone()[0])
    for row in c.execute(f'select * from "{t}" limit 5'):
        print(row)
    print('===')