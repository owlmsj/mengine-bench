import csv, json

# Memory needs (GB = 1e9 bytes)
weights_gb = 70.0  # 70B params x 1 byte (FP8)
kv_per_token = 327_680  # bytes
ctx = 32_768
seqs = 4
kv_cache_gb = kv_per_token * ctx * seqs / 1e9
overhead_gb = 8.0
total_gb = weights_gb + kv_cache_gb + overhead_gb
print(f"weights={weights_gb} kv={kv_cache_gb} total={total_gb}")

rows = list(csv.DictReader(open("offers.csv")))
best = None
for r in rows:
    if r["in_stock"] != "yes":
        continue
    if r["region"] not in ("us-east", "us-central", "eu-west"):
        continue
    price = float(r["usd_per_hour"])
    if price > 4.0:
        continue
    usable = int(r["gpu_count"]) * float(r["vram_gb_per_gpu"])
    if usable < total_gb:
        continue
    if best is None or price < best["usd_per_hour"]:
        best = {"offer_id": r["offer_id"], "usd_per_hour": price}
print(best)
out = {
    "weights_gb": weights_gb,
    "kv_cache_gb": kv_cache_gb,
    "total_gb": total_gb,
    "offer_id": best["offer_id"],
    "usd_per_hour": best["usd_per_hour"],
    "usd_per_month": round(best["usd_per_hour"] * 730, 2),
}
json.dump(out, open("result.json", "w"), indent=2)
print(json.dumps(out, indent=2))