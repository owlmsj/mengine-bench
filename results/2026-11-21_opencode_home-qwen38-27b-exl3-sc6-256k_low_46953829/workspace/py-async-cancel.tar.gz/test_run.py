"""Tests for run.run_tasks: concurrency cap, completion, Ctrl+C cleanup."""

import asyncio
import os
import signal
import sys

from run import run_tasks


def test_concurrency_cap_and_completion():
    async def main():
        running = 0
        peak = 0
        done = 0

        def make_job():
            async def job():
                nonlocal running, peak, done
                running += 1
                peak = max(peak, running)
                await asyncio.sleep(0.02)
                running -= 1
                done += 1
            return job

        await run_tasks([make_job() for _ in range(10)], max_concurrent=3)
        assert peak <= 3, f"peak {peak} exceeded cap 3"
        assert peak == 3, f"peak {peak} never reached cap 3"
        assert done == 10, f"only {done}/10 jobs completed"

    asyncio.run(main())


def test_ctrl_c_runs_cleanup():
    async def main():
        cleaned = []

        def make_job():
            async def job():
                try:
                    await asyncio.sleep(60)
                finally:
                    cleaned.append(1)
            return job

        async def send_interrupt():
            await asyncio.sleep(0.1)
            os.kill(os.getpid(), signal.SIGINT)

        async def runner():
            await run_tasks([make_job() for _ in range(5)], max_concurrent=2)

        interrupt_task = asyncio.create_task(send_interrupt())
        runner_task = asyncio.create_task(runner())
        try:
            await runner_task
        except KeyboardInterrupt:
            pass
        interrupt_task.cancel()
        assert len(cleaned) == 5, f"only {len(cleaned)}/5 jobs ran cleanup"

    asyncio.run(main())


def test_invalid_max_concurrent():
    async def main():
        try:
            await run_tasks([], 0)
        except ValueError:
            return
        raise AssertionError("run_tasks([], 0) did not raise ValueError")

    asyncio.run(main())


if __name__ == "__main__":
    failures = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"PASS {name}")
            except Exception as exc:
                failures += 1
                print(f"FAIL {name}: {exc!r}")
    sys.exit(1 if failures else 0)