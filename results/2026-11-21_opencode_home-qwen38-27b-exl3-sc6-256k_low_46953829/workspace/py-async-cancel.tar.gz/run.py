"""Helper for batch scripts: run async jobs with a concurrency cap.

Usage:
    from run import run_tasks
    await run_tasks([make_job_1, make_job_2, ...], max_concurrent=4)

Each task is a zero-argument callable returning an awaitable job (a
coroutine). At most ``max_concurrent`` jobs run at once. ``run_tasks``
returns when every job has finished.

Ctrl+C behaviour: the first KeyboardInterrupt cancels all running jobs so
their ``finally``/``async with`` cleanup code runs (via asyncio's
cancellation machinery), and ``run_tasks`` re-raises KeyboardInterrupt.
"""

from __future__ import annotations

import asyncio
from typing import Awaitable, Callable, Iterable


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[object]]],
    max_concurrent: int,
) -> None:
    """Run ``tasks`` with at most ``max_concurrent`` jobs running at once.

    ``tasks`` is an iterable of zero-argument callables; each call returns
    an awaitable job. Returns when every job is done. On Ctrl+C the first
    KeyboardInterrupt cancels every running job, awaits their cleanup, then
    re-raises KeyboardInterrupt.

    Raises:
        ValueError: if ``max_concurrent`` < 1.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent!r}")

    semaphore = asyncio.Semaphore(max_concurrent)
    jobs: list[asyncio.Task] = []

    async def _run(task: Callable[[], Awaitable[object]]) -> None:
        async with semaphore:
            await task()

    try:
        for task in tasks:
            jobs.append(asyncio.create_task(_run(task)))
        await asyncio.gather(*jobs)
    except (KeyboardInterrupt, asyncio.CancelledError):
        # Ctrl+C (or parent cancellation): stop the run but let every job's
        # cleanup code run. Cancelling the tasks triggers their
        # finally/async-with blocks; gather waits for them to finish.
        for job in jobs:
            if not job.done():
                job.cancel()
        await asyncio.gather(*jobs, return_exceptions=True)
        raise