import json, struct

data = open('prices.db', 'rb').read()
n = len(data)
assert n == 4096, n

# Leaf table b-tree page: cell pointer array starts right after the 8-byte
# page header (offset 8); page 1 would use offset 108. The zeroed middle of
# the file is the cell pointer array region (all zeros = no cells there);
# the real pointers sit at the very start of the page.
PAGE = 4096
CP = 8

# --- record decoding (SQLite file format, section 1.6.1) ---
def varint(buf, off):
    v = 0
    for i in range(9):
        b = buf[off + i]
        if i == 8:
            v = (v << 8) | b
            return v, off + 9
        v = (v << 7) | (b & 0x7F)
        if not (b & 0x80):
            return v, off + i + 1
    raise ValueError('varint too long')

def decode_record(buf, off):
    hlen, off = varint(buf, off)
    hstart = off
    types = []
    while off < hstart + hlen:
        t, off = varint(buf, off)
        types.append(t)
    vals = []
    for t in types:
        if t == 0:
            vals.append(None)
        elif t == 1:
            vals.append(int.from_bytes(buf[off:off+1], 'big', signed=True)); off += 1
        elif t == 2:
            vals.append(int.from_bytes(buf[off:off+2], 'big', signed=True)); off += 2
        elif t == 3:
            vals.append(int.from_bytes(buf[off:off+3], 'big', signed=True)); off += 3
        elif t == 4:
            vals.append(int.from_bytes(buf[off:off+4], 'big', signed=True)); off += 4
        elif t == 5:
            vals.append(int.from_bytes(buf[off:off+6], 'big', signed=True)); off += 6
        elif t == 6:
            vals.append(int.from_bytes(buf[off:off+8], 'big', signed=True)); off += 8
        elif t == 7:
            vals.append(struct.unpack('>d', buf[off:off+8])[0]); off += 8
        elif t == 8:
            vals.append(0)
        elif t == 9:
            vals.append(1)
        elif t >= 12 and t % 2 == 0:
            ln = (t - 12) // 2
            vals.append(buf[off:off+ln].decode('utf-8')); off += ln
        elif t >= 13:
            ln = (t - 13) // 2
            vals.append(bytes(buf[off:off+ln])); off += ln
        else:
            raise ValueError(f'bad serial type {t}')
    return vals

# --- leaf cell parsing (section 1.6.2) ---
def parse_leaf(buf, off):
    payload_len, off = varint(buf, off)
    rowid, off = varint(buf, off)
    return rowid, decode_record(buf, off)

rows = []
errors = []
# walk cell pointer array; stop at first zero pointer (rest of array is zeroed)
off = CP
ptrs = []
while off < CP + 100 and off + 2 <= PAGE:
    p = struct.unpack('>H', data[off:off+2])[0]
    off += 2
    if p == 0:
        break
    ptrs.append(p)

for p in ptrs:
    try:
        rowid, vals = parse_leaf(data, p)
        rows.append((rowid, vals))
    except Exception as e:
        errors.append((p, repr(e)))

print('cell pointers:', [hex(p) for p in ptrs])
print('errors:', errors)
for rowid, vals in rows:
    print(rowid, vals)

# Build output: item = first text column, price = numeric column.
# Schema assumed: (item TEXT, price <numeric>) -> 2 columns; rowid implicit.
out = []
for rowid, vals in rows:
    if len(vals) < 2:
        continue
    item, price = vals[0], vals[1]
    if not isinstance(item, str):
        continue
    if isinstance(price, float) and price.is_integer():
        price = int(price)
    out.append({'item': item, 'price': price})

with open('recovered.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print('wrote', len(out), 'rows')