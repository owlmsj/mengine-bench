import csv, json, re
from decimal import Decimal

base = r"<WORKSPACE>\backoffice"

inv = {}
with open(base + r"\invoices.csv", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        inv[r["id"]] = Decimal(r["amount"])

payments = {}  # id -> list of amounts
with open(base + r"\bank_statement_june.csv", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        memo = r["memo"]
        m = re.search(r"INV-?10(\d{2})", memo)
        if not m:
            continue  # fees, interest, unidentified
        pid = "INV-10" + m.group(1)
        payments.setdefault(pid, []).append(Decimal(r["amount"]))

unpaid, duplicated, mismatched = [], [], []
for iid, amt in inv.items():
    pays = payments.get(iid, [])
    if not pays:
        unpaid.append(iid)
    elif len(pays) > 1:
        duplicated.append(iid)
    elif pays[0] != amt:
        mismatched.append({"id": iid, "invoiced": str(amt), "paid": str(pays[0])})

unpaid.sort(); duplicated.sort(); mismatched.sort(key=lambda x: x["id"])
result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))