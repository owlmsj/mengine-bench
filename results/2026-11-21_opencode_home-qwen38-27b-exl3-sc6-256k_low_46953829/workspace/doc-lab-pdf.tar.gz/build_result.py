import json

# Alfa (first report, 10/02/2026) units are the target units.
# Beta (18/08/2026) values converted to Alfa units:
#  Glicose: 6.1 mmol/L * 18.01559 = mg/dL
#  LDL:     3.70 mmol/L * 38.66903 = mg/dL
#  Creatinina: 76 umol/L * 0.011299 = mg/dL
#  HbA1c:   37 mmol/mol -> IFCC formula: (37+23.5)/1.594 = %
glu = 6.1 * 18.01559
ldl = 3.70 * 38.66903
cre = 76 * 0.011299
hba = 37 / 10.929 + 2.15  # IFCC mmol/mol -> NGSP %

history = {
    "Glicose em jejum": {"10/02/2026": 92, "18/08/2026": round(glu, 1)},
    "Colesterol LDL": {"10/02/2026": 118, "18/08/2026": round(ldl, 1)},
    "Creatinina": {"10/02/2026": 0.95, "18/08/2026": round(cre, 2)},
    "Hemoglobina glicada (HbA1c)": {"10/02/2026": 5.4, "18/08/2026": round(hba, 1)},  # hba = 5.2 %
}

# Worse = rose and is now outside the FIRST report's reference range.
# Ranges from Alfa: Glicose 70-99, LDL <130, Creatinina 0.70-1.30, HbA1c 4.0-5.6
worse = []
if history["Glicose em jejum"]["18/08/2026"] > 99:
    worse.append("Glicose em jejum")
if history["Colesterol LDL"]["18/08/2026"] > 130:
    worse.append("Colesterol LDL")
if history["Creatinina"]["18/08/2026"] > 1.30:
    worse.append("Creatinina")
if history["Hemoglobina glicada (HbA1c)"]["18/08/2026"] > 5.6:
    worse.append("Hemoglobina glicada (HbA1c)")

result = {"history": history, "worse": worse}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
print(json.dumps(result, ensure_ascii=False, indent=2))