Boarding screen announcements for the ferry line. Audio files go in this folder.
