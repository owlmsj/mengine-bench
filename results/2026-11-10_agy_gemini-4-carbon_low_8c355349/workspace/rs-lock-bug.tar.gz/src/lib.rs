//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, RwLock, RwLockReadGuard, RwLockWriteGuard};

pub type PlayerId = u32;

#[derive(Default)]
struct ScoreState {
    players: HashMap<PlayerId, i64>,
    total: i64,
}

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    state: Arc<RwLock<ScoreState>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    fn read_state(&self) -> RwLockReadGuard<'_, ScoreState> {
        self.state.read().unwrap_or_else(|poisoned| poisoned.into_inner())
    }

    fn write_state(&self) -> RwLockWriteGuard<'_, ScoreState> {
        self.state.write().unwrap_or_else(|poisoned| poisoned.into_inner())
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        let mut state = self.write_state();
        if let Some(previous) = state.players.insert(id, score) {
            state.total -= previous;
        }
        state.total += score;
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let mut state = self.write_state();
        let player_score = state
            .players
            .get_mut(&id)
            .unwrap_or_else(|| panic!("unknown PlayerId {id}; expected registered player"));
        *player_score += points;
        state.total += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let mut state = self.write_state();
        if !state.players.contains_key(&from) {
            panic!("unknown from PlayerId {from}; expected registered player");
        }
        if !state.players.contains_key(&to) {
            panic!("unknown to PlayerId {to}; expected registered player");
        }
        if from == to {
            return;
        }
        *state.players.get_mut(&from).unwrap() -= points;
        *state.players.get_mut(&to).unwrap() += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        let state = self.read_state();
        *state
            .players
            .get(&id)
            .unwrap_or_else(|| panic!("unknown PlayerId {id}; expected registered player"))
    }

    pub fn total(&self) -> i64 {
        self.read_state().total
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::{mpsc, Barrier};
    use std::thread;
    use std::time::Duration;

    fn run_with_timeout<F: FnOnce() + Send + 'static>(timeout: Duration, f: F) -> bool {
        let (tx, rx) = mpsc::channel();
        thread::spawn(move || {
            f();
            let _ = tx.send(());
        });
        rx.recv_timeout(timeout).is_ok()
    }

    #[test]
    fn self_transfer_does_not_deadlock_or_change_score() {
        let ok = run_with_timeout(Duration::from_millis(500), || {
            let board = Board::new();
            board.join(1, 100);
            board.transfer(1, 1, 25);
            assert_eq!(board.score(1), 100);
            assert_eq!(board.total(), 100);
        });
        assert!(ok, "transfer(id, id, points) deadlocked");
    }

    #[test]
    fn opposite_transfers_do_not_deadlock() {
        let ok = run_with_timeout(Duration::from_secs(2), || {
            let board = Board::new();
            board.join(1, 100_000);
            board.join(2, 100_000);
            let barrier = Arc::new(Barrier::new(8));
            let mut handles = Vec::new();
            for t in 0..8 {
                let b = board.clone();
                let bar = barrier.clone();
                handles.push(thread::spawn(move || {
                    bar.wait();
                    for _ in 0..20_000 {
                        if t % 2 == 0 {
                            b.transfer(1, 2, 1);
                        } else {
                            b.transfer(2, 1, 1);
                        }
                    }
                }));
            }
            for h in handles {
                h.join().unwrap();
            }
            assert_eq!(board.score(1), 100_000);
            assert_eq!(board.score(2), 100_000);
            assert_eq!(board.total(), 200_000);
        });
        assert!(ok, "opposite transfers deadlocked");
    }

    #[test]
    fn concurrent_awards_and_transfers_preserve_exact_scores_and_total() {
        let board = Board::new();
        for id in 0..8 {
            board.join(id, 1_000);
        }
        let barrier = Arc::new(Barrier::new(8));
        let mut handles = Vec::new();
        for t in 0..8u32 {
            let b = board.clone();
            let bar = barrier.clone();
            handles.push(thread::spawn(move || {
                bar.wait();
                for step in 0..5_000u32 {
                    b.award(t, 3);
                    let target = (t + step + 1) % 8;
                    b.transfer(t, target, 1);
                }
            }));
        }
        for h in handles {
            h.join().unwrap();
        }
        let sum: i64 = (0..8).map(|id| board.score(id)).sum();
        assert_eq!(sum, 8 * 1_000 + 8 * 5_000 * 3);
        assert_eq!(board.total(), sum);
    }

    #[test]
    fn rejoin_existing_player_keeps_total_consistent() {
        let board = Board::new();
        board.join(1, 50);
        board.award(1, 20);
        board.join(1, 10);
        assert_eq!(board.score(1), 10);
        assert_eq!(board.total(), 10);
    }

    #[test]
    #[should_panic(expected = "unknown to PlayerId 99")]
    fn self_or_invalid_transfer_panics_on_missing_player() {
        let board = Board::new();
        board.join(1, 10);
        board.transfer(1, 99, 5);
    }

    #[test]
    #[should_panic(expected = "unknown from PlayerId 99")]
    fn self_transfer_panics_on_missing_player() {
        let board = Board::new();
        board.transfer(99, 99, 5);
    }
}
