"""Match payout. Rules live in docs/ECONOMY.md."""

from decimal import Decimal, ROUND_HALF_UP


def match_payout(won, kills, cfg):
    base = Decimal(str(cfg["win_base"] if won else cfg["loss_base"]))
    kill_bonus = Decimal(str(cfg["kill_bonus"]))
    multiplier = Decimal(str(cfg["event_multiplier"]))
    raw = (base + Decimal(str(kills)) * kill_bonus) * multiplier
    return int((raw / Decimal(10)).quantize(Decimal("1"), rounding=ROUND_HALF_UP) * 10)
