/**
 * Hook bus for harness plugins (OpenCode-style hooks). The README states the contract:
 * handlers run one after another in subscription order, emit resolves after all of them,
 * a handler error rejects emit, and unsubscribing during an emit does not stop the others.
 */

export type Handler<T> = (payload: T) => void | Promise<void>;

type Subscription = {
  invoke: Handler<unknown>;
};

export class HookBus {
  private subscriptions: Map<string, Subscription[]> = new Map();

  /** Subscribes a handler to an event; returns the function that unsubscribes it. */
  on<T>(event: string, handler: Handler<T>): () => void {
    const list = this.subscriptions.get(event) ?? [];
    const entry: Subscription = { invoke: handler as Handler<unknown> };
    list.push(entry);
    this.subscriptions.set(event, list);
    return () => {
      const index = list.indexOf(entry);
      if (index >= 0) {
        list.splice(index, 1);
      }
    };
  }

  /** Runs the handlers of an event with the payload. */
  async emit<T>(event: string, payload: T): Promise<void> {
    const snapshot = [...(this.subscriptions.get(event) ?? [])];
    for (const entry of snapshot) {
      await entry.invoke(payload);
    }
  }

  /** How many handlers an event has. */
  count(event: string): number {
    return (this.subscriptions.get(event) ?? []).length;
  }
}
