# Handoff: local-9b @ 128k Context

## Status & Results
- **Goal**: Fit `local-9b` Q5 at 128k (`-Ctx 131072`) without VRAM spill.
- **Measurement**: `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`
- **Root Cause**: Baseline hit 7881 MiB WDDM ceiling + 1494 MiB Shared Usage spill (37.8 t/s, invalid). Always check Shared Usage counter.
- **Working Recipe (`local-9b` Q5)**: Add `--no-mmproj-offload` and `-ub 512` -> **0 spill**, **7697 MiB VRAM**, **38.0 t/s decode** (median of 3).
- **Other Quants**: `Q6_K` (7.03 GiB) does not fit at 128k (discarded). `Q4_K_M` fits (7305 MiB, 40.4 t/s; fallback only).

## Applied Changes
- `scripts/start_server.ps1:165` (`local9` block)
- `profiles/local/local-9b.json`

## Next Steps
1. Update evals `README` to remove stale `check_vision.ps1` reference (file deleted).
2. Verify `git status` / `git diff` and clean or rename scratchpad temp files if needed before committing.
