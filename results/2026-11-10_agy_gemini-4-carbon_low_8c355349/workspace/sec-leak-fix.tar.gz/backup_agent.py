"""Backup agent: packs a folder chosen in the intranet web form and uploads it to the backup API."""

from __future__ import annotations

import logging
import tarfile
import urllib.request
from pathlib import Path

import config

log = logging.getLogger("backup_agent")


def archive_folder(folder: str, out_dir: str = config.ARCHIVE_DIR) -> Path:
    """Packs `folder` into `out_dir/<folder name>.tar.gz` and returns the archive path."""
    if not isinstance(folder, str) or not folder or "\x00" in folder:
        raise ValueError(f"Invalid folder path {folder!r}; expected non-empty string without null bytes")
    source = Path(folder)
    if not source.is_dir():
        raise ValueError(f"Folder {folder!r} is not an existing directory; expected path to a directory")
    folder_name = source.name or source.resolve().name
    if not folder_name or folder_name in {".", ".."}:
        raise ValueError(f"Folder {folder!r} has no valid archive basename; expected named directory")
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    target = out / f"{folder_name}.tar.gz"
    with tarfile.open(target, "w:gz") as packed:
        packed.add(source, arcname=folder_name)
    return target


def send_archive(path: Path, url: str, token: str) -> int:
    """Uploads one archive to the backup API and returns the HTTP status."""
    request = urllib.request.Request(url, data=path.read_bytes(), method="POST",
                                     headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.status


def upload(path: Path) -> int:
    token = config.get_api_token()
    log.info("uploading %s", path)
    return send_archive(path, config.API_URL, token)


def handle_form(form: dict[str, str]) -> int:
    """Web form handler: backs up the folder the user typed."""
    archive = archive_folder(form["folder"])
    log.info("archived %s", archive)
    return upload(archive)
