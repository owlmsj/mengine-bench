"""Settings for the backup agent."""

import os

API_URL = "https://backup.example.invalid/v1/upload"
ARCHIVE_DIR = "archives"


def get_api_token() -> str:
    """Reads the backup API token from the BACKUP_TOKEN environment variable."""
    token = os.environ.get("BACKUP_TOKEN", "").strip()
    if not token:
        raise RuntimeError(
            "BACKUP_TOKEN environment variable is empty or unset; expected non-empty bearer token string"
        )
    return token

