import sqlite3, json
from collections import defaultdict

STEPS = ["install", "tutorial_complete", "first_match", "purchase"]

c = sqlite3.connect('analytics.db')
users = {uid: (plat, test) for uid, plat, test in c.execute("SELECT user_id, platform, is_test FROM users")}
print("platforms:", c.execute("SELECT platform, COUNT(*), SUM(is_test) FROM users GROUP BY platform").fetchall())
print("event names:", c.execute("SELECT name, COUNT(*) FROM events GROUP BY name").fetchall())
print("unknown-player events:", c.execute("SELECT COUNT(*) FROM events WHERE user_id NOT IN (SELECT user_id FROM users)").fetchone())
print("ts sample formats:", c.execute("SELECT ts FROM events LIMIT 3").fetchall())

# per player: all event timestamps per step name (ISO-like strings compare chronologically)
ev_ts = defaultdict(lambda: defaultdict(list))
for uid, name, ts in c.execute("SELECT user_id, name, ts FROM events"):
    u = users.get(uid)
    if u is None or u[1] == 1:  # unknown player or test account
        continue
    if name not in STEPS:
        continue
    ev_ts[uid][name].append(ts)

funnel = defaultdict(lambda: {s: 0 for s in STEPS})
for uid, d in ev_ts.items():
    plat = users[uid][0]
    prev_ts = None
    for s in STEPS:
        # first valid occurrence: earliest ts at/after previous step's time
        valid = sorted(t for t in d.get(s, []) if prev_ts is None or t >= prev_ts)
        if not valid:
            break
        funnel[plat][s] += 1
        prev_ts = valid[0]

result = {"funnel": {}, "biggest_drop": {}}
for plat in sorted(funnel):
    counts = funnel[plat]
    result["funnel"][plat] = counts
    conv = {}
    for prev, cur in zip(STEPS, STEPS[1:]):
        conv[cur] = counts[cur] / counts[prev] if counts[prev] else None
    valid = {s: v for s, v in conv.items() if v is not None}
    result["biggest_drop"][plat] = min(valid, key=valid.get) if valid else None
    print(plat, counts, {s: round(v, 4) for s, v in conv.items() if v is not None})

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
print(open('result.json').read())