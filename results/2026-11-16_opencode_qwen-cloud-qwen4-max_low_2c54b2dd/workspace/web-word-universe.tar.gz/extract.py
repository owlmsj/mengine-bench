import json, re, os, sys
from urllib.parse import unquote

SITE = "site"
files = {f.lower(): f for f in os.listdir(SITE) if f.lower().endswith(".html")}
NON_WORDS = {"index.html", "sobre.html", "contato.html"}

pages = {}   # lower filename -> parsed
for low, real in files.items():
    html = open(os.path.join(SITE, real), encoding="utf-8").read()
    m = re.search(r'url=([^"]+)', html)
    if m and "<h1>" not in html:
        pages[low] = {"redirect": unquote(m.group(1)).lower()}
        continue
    h1 = re.search(r"<h1>(.*?)</h1>", html)
    if not h1 or low in NON_WORDS:
        pages[low] = {"skip": True}
        continue
    word = h1.group(1).strip().lower()
    tema = re.search(r'class="tema">Tema:\s*(.*?)</p>', html)
    sections = {}
    for sec in re.finditer(r'<section id="([^"]+)">(.*?)</section>', html, re.S):
        links = [unquote(h).lower() for h in re.findall(r'href="([^"]+)"', sec.group(2))]
        sections[sec.group(1)] = links
    pages[low] = {"word": word, "tema": tema.group(1).strip() if tema else "", "sections": sections}

def resolve(low, seen=None):
    seen = seen or set()
    if low in seen: return None
    seen.add(low)
    p = pages.get(low)
    if not p: return None
    if "redirect" in p: return resolve(p["redirect"], seen)
    if "skip" in p: return None
    return p["word"]

words = {}
dangling = set()
alias = {}
for low, p in pages.items():
    if "word" not in p: continue
    w = p["word"]
    if w in words:
        print("DUPLICATE WORD:", w, low); sys.exit(1)
    words[w] = {"tema": p["tema"], "file": files[low], "sections": {}}
    alias[low[:-5]] = w
    for sec, links in p["sections"].items():
        out = []
        for href in links:
            t = resolve(href)
            if t is None:
                dangling.add(href)
            elif t != w and t not in out:
                out.append(t)
        words[w]["sections"][sec] = out

# undirected distinct pairs
pairs = set()
adj = {w: set() for w in words}
for w, d in words.items():
    for sec, targets in d["sections"].items():
        for t in targets:
            pairs.add(tuple(sorted((w, t))))
            adj[w].add(t); adj[t].add(w)

words_json = {w: sorted(adj[w]) for w in sorted(words)}
deg = {w: len(adj[w]) for w in words}
top = sorted(deg.items(), key=lambda kv: (-kv[1], kv[0]))
result = {"words": len(words), "relations": len(pairs), "most_connected": top[0][0]}

json.dump(words_json, open("words.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
json.dump(result, open("result.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

# rich payload for the single-file view
payload = {
    "words": {w: {"tema": d["tema"], "rel": d["sections"]} for w, d in words.items()},
    "alias": alias,
    "stats": result,
    "top": top[:12],
    "dangling": sorted(dangling),
}
json.dump(payload, open("payload.json", "w", encoding="utf-8"), ensure_ascii=False)

temas = sorted({d["tema"] for d in words.values()})
print("words:", len(words), "pairs:", len(pairs), "directed edges:", sum(len(v) for v in words_json.values()))
print("most_connected:", top[:6])
print("temas:", temas)
print("dangling:", sorted(dangling))
print("redirects:", [k for k,v in pages.items() if "redirect" in v])
print("section ids:", sorted({s for d in words.values() for s in d["sections"]}))
iso = [w for w in words if not adj[w]]
print("isolated:", iso)