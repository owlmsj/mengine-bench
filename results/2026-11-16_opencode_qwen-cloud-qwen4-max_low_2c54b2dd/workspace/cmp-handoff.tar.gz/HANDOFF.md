# HANDOFF: local-9b Q5 @ 128k ctx

Goal: measure decode at 128k (llama-server, WDDM GPU). Evidence: session/transcript.md, line N.

Done:
- L30: first run `scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024` = 37.8 t/s, 7881 MiB. INVALID: L44: 7881 MiB is WDDM ceiling; Shared Usage showed 1494 MiB spilled.
- L124: fix = `--no-mmproj-offload` + `-ub 512`; spill gone. Valid: 7697 MiB, 38.0 t/s (median of 3).
- L132: Q6_K (7.03 GiB) does not fit at 128k, discarded; Q4_K_M fallback 7305 MiB, 40.4 t/s.
- L185: recipe applied in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

Left:
- L222: evals README still cites check_vision.ps1 (deleted). Update it; this answered "What is left?" and is not done.
- Re-run measure_decode.ps1 with fixed flags; confirm Shared Usage = 0.

Assumptions: repo absent here; paths from transcript. Filler lines (git status, --help, GPU panel) hold no findings.

Verified: numbers quoted from cited lines; validity via spill check (L44).