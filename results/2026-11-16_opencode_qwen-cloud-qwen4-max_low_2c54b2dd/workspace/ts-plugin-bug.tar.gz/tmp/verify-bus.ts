import assert from "node:assert/strict";
import { HookBus } from "../src/bus.ts";
import { registerAuditPlugin } from "../src/plugin.ts";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// 1. Sequential order, slow first handler must finish before second starts.
{
  const bus = new HookBus();
  const log: string[] = [];
  bus.on("e", async () => { await sleep(20); log.push("a"); });
  bus.on("e", () => { log.push("b"); });
  await bus.emit("e", null);
  assert.deepEqual(log, ["a", "b"]);
}

// 2. Failing handler rejects emit with same error; later handlers do not run.
{
  const bus = new HookBus();
  const err = new Error("boom");
  const log: string[] = [];
  bus.on("e", () => { throw err; });
  bus.on("e", () => { log.push("should not run"); });
  await assert.rejects(bus.emit("e", null), (e) => e === err);
  assert.deepEqual(log, []);
}
{
  const bus = new HookBus();
  const err = new Error("async boom");
  bus.on("e", async () => { await sleep(5); throw err; });
  await assert.rejects(bus.emit("e", null), (e) => e === err);
}

// 3. Self-unsubscribe during emit does not stop others in that emit; next emit skips it.
{
  const bus = new HookBus();
  const log: string[] = [];
  const off = bus.on("e", () => { off(); log.push("one"); });
  bus.on("e", () => { log.push("two"); });
  await bus.emit("e", null);
  assert.deepEqual(log, ["one", "two"]);
  await bus.emit("e", null);
  assert.deepEqual(log, ["one", "two", "two"]);
}

// 4. Handler added during emit runs only from next emit.
{
  const bus = new HookBus();
  const log: string[] = [];
  bus.on("e", () => { bus.on("e", () => { log.push("late"); }); log.push("first"); });
  await bus.emit("e", null);
  assert.deepEqual(log, ["first"]);
  await bus.emit("e", null);
  assert.deepEqual(log, ["first", "first", "late"]);
}

// 5. Audit plugin end to end: one-time notice, redaction before audit entry.
{
  const bus = new HookBus();
  const audit: string[] = [];
  registerAuditPlugin(bus, audit);
  await bus.emit("tool.after", { tool: "shell", output: "password=hunter2 ok" });
  await bus.emit("tool.after", { tool: "shell", output: "password=abc ok" });
  assert.deepEqual(audit, [
    "notice: tool output is audited",
    "shell: password=[redacted] ok",
    "shell: password=[redacted] ok",
  ]);
}

console.log("all bus regression checks passed");