//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// One lock guards every score and the total, so no operation can observe or
/// leave a half-applied update, and no lock ordering can deadlock.
#[derive(Default)]
struct State {
    scores: HashMap<PlayerId, i64>,
    total: i64,
}

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    state: Arc<Mutex<State>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    /// Adds a player. Re-joining replaces the score and adjusts the total by
    /// the difference, so the total always equals the sum of the scores.
    pub fn join(&self, id: PlayerId, score: i64) {
        let mut state = self.state.lock().unwrap();
        let old = state.scores.insert(id, score).unwrap_or(0);
        state.total += score - old;
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let mut state = self.state.lock().unwrap();
        let score = state
            .scores
            .get_mut(&id)
            .unwrap_or_else(|| panic!("player {id} has not joined"));
        *score += points;
        state.total += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return;
        }
        let mut state = self.state.lock().unwrap();
        if !state.scores.contains_key(&from) {
            panic!("player {from} has not joined");
        }
        if !state.scores.contains_key(&to) {
            panic!("player {to} has not joined");
        }
        *state.scores.get_mut(&from).unwrap() -= points;
        *state.scores.get_mut(&to).unwrap() += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        let state = self.state.lock().unwrap();
        *state
            .scores
            .get(&id)
            .unwrap_or_else(|| panic!("player {id} has not joined"))
    }

    pub fn total(&self) -> i64 {
        self.state.lock().unwrap().total
    }
}

#[cfg(test)]
mod tests {
    use super::Board;
    use std::sync::Arc;
    use std::thread;

    #[test]
    fn concurrent_awards_keep_every_point() {
        let board = Board::new();
        board.join(1, 0);
        let workers: Vec<_> = (0..8)
            .map(|_| {
                let board = board.clone();
                thread::spawn(move || {
                    for _ in 0..10_000 {
                        board.award(1, 1);
                    }
                })
            })
            .collect();
        for worker in workers {
            worker.join().unwrap();
        }
        assert_eq!(board.score(1), 80_000);
        assert_eq!(board.total(), 80_000);
    }

    #[test]
    fn opposite_transfers_do_not_deadlock() {
        let board = Board::new();
        board.join(1, 1000);
        board.join(2, 1000);
        let a = {
            let board = board.clone();
            thread::spawn(move || {
                for _ in 0..10_000 {
                    board.transfer(1, 2, 1);
                }
            })
        };
        let b = {
            let board = board.clone();
            thread::spawn(move || {
                for _ in 0..10_000 {
                    board.transfer(2, 1, 1);
                }
            })
        };
        a.join().unwrap();
        b.join().unwrap();
        assert_eq!(board.score(1), 1000);
        assert_eq!(board.score(2), 1000);
        assert_eq!(board.total(), 2000);
    }

    #[test]
    fn self_transfer_is_a_noop() {
        let board = Board::new();
        board.join(1, 7);
        board.transfer(1, 1, 3);
        assert_eq!((board.score(1), board.total()), (7, 7));
    }

    #[test]
    fn rejoin_replaces_without_double_counting() {
        let board = Board::new();
        board.join(1, 10);
        board.join(1, 4);
        assert_eq!((board.score(1), board.total()), (4, 4));
    }

    #[test]
    fn mixed_load_keeps_total_equal_to_sum() {
        let board = Arc::new(Board::new());
        board.join(1, 100);
        board.join(2, 100);
        let workers: Vec<_> = (0..4)
            .map(|i| {
                let board = Arc::clone(&board);
                thread::spawn(move || {
                    for _ in 0..5_000 {
                        board.award(1, 2);
                        board.transfer(1, 2, 1);
                        board.transfer(2, 1, 1);
                        if i == 0 {
                            board.award(2, 1);
                        }
                    }
                })
            })
            .collect();
        for worker in workers {
            worker.join().unwrap();
        }
        assert_eq!(board.total(), board.score(1) + board.score(2));
        assert_eq!(board.total(), 200 + 4 * 5_000 * 2 + 5_000);
    }
}
