use repro::Board;
use std::thread;
#[test]
fn concurrent_awards_keep_every_point() {
    let board = Board::new();
    board.join(1, 0);
    let workers: Vec<_> = (0..8).map(|_| {
        let board = board.clone();
        thread::spawn(move || { for _ in 0..10_000 { board.award(1, 1); } })
    }).collect();
    for w in workers { w.join().unwrap(); }
    assert_eq!(board.score(1), 80_000);
    assert_eq!(board.total(), 80_000);
}
#[test]
fn self_transfer_is_a_noop() {
    let board = Board::new();
    board.join(1, 7);
    board.transfer(1, 1, 3);
    assert_eq!((board.score(1), board.total()), (7, 7));
}
