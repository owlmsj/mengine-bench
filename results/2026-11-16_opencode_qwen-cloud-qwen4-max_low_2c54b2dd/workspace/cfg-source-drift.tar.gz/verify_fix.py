"""One-shot check: all three configs agree with models.json on every setting."""
import json
import re
import tomllib
from pathlib import Path

root = Path(__file__).resolve().parent
src = {m["name"]: m for m in json.loads((root / "models.json").read_text(encoding="utf-8"))["models"]}
oc = json.loads((root / "out/opencode.json").read_text(encoding="utf-8"))["provider"]["workstation"]["models"]
cx = tomllib.loads((root / "out/codex.toml").read_text(encoding="utf-8"))["models"]
cl = {m["id"]: m for m in json.loads((root / "out/claude.json").read_text(encoding="utf-8"))["models"]}

for name, m in src.items():
    assert oc[name]["limit"] == {"context": m["context_window"], "output": m["max_output"]}, name
    assert oc[name]["tool_call"] == m["tool_calling"], name
    assert cx[name] == {"context_window": m["context_window"], "max_output_tokens": m["max_output"], "tool_calling": m["tool_calling"]}, name
    assert cl[name] == {"id": name, "contextWindow": m["context_window"], "maxOutputTokens": m["max_output"], "supportsTools": m["tool_calling"]}, name
    print(f"{name}: context={m['context_window']} output={m['max_output']} tools={m['tool_calling']} -- all three match")

assert src["fast-coder"]["context_window"] == 262144
print("fast-coder context is 262144 in source and all three configs; every other setting matches source")