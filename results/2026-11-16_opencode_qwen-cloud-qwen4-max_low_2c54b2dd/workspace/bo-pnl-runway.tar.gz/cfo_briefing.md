# CFO Briefing — H1 2026 Close (investor meeting)

Currency: BRL (R$). Source: finance/ledger.csv (86 entries, Jan–Jun 2026),
finance/chart_of_accounts.csv, finance/cash_balance.txt, finance/README.md.

## Monthly performance

| Month   | Revenue    | COGS      | Gross margin | EBITDA     |
|---------|-----------:|----------:|-------------:|-----------:|
| 2026-01 | 200,510.87 | 60,091.92 | 70.03%       | -210,278.96 |
| 2026-02 | 216,328.06 | 64,278.71 | 70.29%       | -212,300.08 |
| 2026-03 | 219,066.17 | 69,096.05 | 68.46%       | -204,525.45 |
| 2026-04 | 238,163.26 | 70,867.73 | 70.24%       | -196,950.65 |
| 2026-05 | 243,032.89 | 73,973.13 | 69.56%       | -201,945.82 |
| 2026-06 | 272,391.57 | 75,162.69 | 72.41%       | -192,968.22 |

H1 totals: revenue 1,389,492.82; EBITDA -1,218,969.18.

Narrative: revenue grew every month, +35.8% Jan→Jun (200.5k → 272.4k).
Gross margin held ~68–72%, best in June (72.41%). EBITDA loss narrowed from
-210.3k (Jan) to -193.0k (Jun): operating leverage improving, but still
burning ~200k/month. June was the strongest month on revenue, margin and EBITDA.

## Burn and runway (board definition, finance/README.md)

- Burn = average monthly negative EBITDA of last 3 closed months (Apr, May, Jun):
  (196,950.65 + 201,945.82 + 192,968.22) / 3 = **R$ 197,288.23 / month**
- Latest closing cash (30/06/2026): **R$ 1,847,350.40**
- Runway = 1,847,350.40 / 197,288.23 = **9.36 months** (into ~April 2027 at current burn)

## Definitions and assumptions

1. Revenue = accounts 3.1.01 + 3.1.02 + 3.1.09 (refunds netted against revenue;
   May includes refund -8,634.37, customer Kestrel).
2. COGS = 4.1.01 + 4.1.02. Gross margin % = (revenue - COGS) / revenue.
3. EBITDA = revenue - COGS - sales_marketing (5.1.x) - R&D (5.2.x) - G&A (5.3.x).
   Financial items (6.1.01 investment income, 6.1.02 interest/IOF) excluded:
   they sit below EBITDA. No D&A accounts exist in the chart, so operating
   result equals EBITDA.
4. Burn uses the board's README definition, not net cash change. All of
   Apr–Jun had negative EBITDA, so "average negative EBITDA" is unambiguous.
5. Cash taken from cash_balance.txt (30/06/2026), the latest closing balance.
6. Ledger parsed as dd/mm/yyyy, semicolon-delimited, Brazilian number format
   (1.234,56). All 86 entries fall in Jan–Jun 2026; all accounts map to the chart.

## Caveat for the CFO

The P&L ledger does not fully explain cash movement: June net result incl.
financial items is -187,346.57, but cash fell 461,837.60 (2,309,188.00 →
1,847,350.40). The gap (~274.5k) is non-P&L cash flow (e.g. capex, working
capital, financing) not present in the provided ledger. Runway per the board
definition uses the stated cash balance; if cash-only burn were used instead
(June cash delta), runway would be ~4.0 months. Recommend confirming the cash
bridge before the meeting.

## Verification

Computed twice with independent parsers (csv module vs regex integer-cents);
both agree on every figure. result.json holds the machine-readable key figures.
