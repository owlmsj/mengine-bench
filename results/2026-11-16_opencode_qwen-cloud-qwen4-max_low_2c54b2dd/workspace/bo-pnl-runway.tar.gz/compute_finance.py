import csv, json
from collections import defaultdict

def brl(s):
    return float(s.strip().replace(".", "").replace(",", "."))

coa = {}
with open("finance/chart_of_accounts.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        coa[row["account"]] = row["pnl_line"]

months = [f"2026-{m:02d}" for m in range(1, 7)]
agg = {m: defaultdict(float) for m in months}
n_entries = 0
with open("finance/ledger.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        d, mo, y = row["date"].split("/")
        key = f"{y}-{mo}"
        assert key in agg, f"unexpected month {key}"
        line = coa[row["account"]]
        agg[key][line] += brl(row["amount"])
        n_entries += 1

result = {"revenue": {}, "gross_margin_pct": {}, "ebitda": {}}
ebitda_by_month = {}
for m in months:
    a = agg[m]
    rev = a["revenue"]
    cogs = a["cogs"]
    opex = a["sales_marketing"] + a["rnd"] + a["ga"]
    ebitda = rev + cogs + opex  # expenses already negative; financial excluded
    gm = (rev + cogs) / rev * 100 if rev else 0.0
    result["revenue"][m] = round(rev, 2)
    result["gross_margin_pct"][m] = round(gm, 2)
    result["ebitda"][m] = round(ebitda, 2)
    ebitda_by_month[m] = ebitda
    print(f"{m}: rev={rev:,.2f} cogs={cogs:,.2f} gm%={gm:.2f} "
          f"sm={a['sales_marketing']:,.2f} rnd={a['rnd']:,.2f} ga={a['ga']:,.2f} "
          f"fin={a['financial']:,.2f} EBITDA={ebitda:,.2f}")

# Board definition (finance/README.md): burn = avg monthly negative EBITDA of last 3 closed months
last3 = months[-3:]
neg = [max(0.0, -ebitda_by_month[m]) for m in last3]
burn = sum(neg) / 3
cash_jun = brl("1.847.350,40")  # finance/cash_balance.txt, 30/06/2026
runway = cash_jun / burn
result["burn"] = round(burn, 2)
result["runway_months"] = round(runway, 2)
print(f"last3 EBITDA: {[round(ebitda_by_month[m],2) for m in last3]}")
print(f"burn={burn:,.2f} cash_jun={cash_jun:,.2f} runway={runway:.2f} months, entries={n_entries}")

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(open("result.json").read())
