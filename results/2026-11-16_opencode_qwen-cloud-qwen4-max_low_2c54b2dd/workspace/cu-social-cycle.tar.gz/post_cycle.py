import json, re, urllib.request, urllib.error, http.cookiejar, datetime, sys

BASE = "http://127.0.0.1:61531"
TEXT = "Testing the new Bluehaze uploader: Harbor Day is on."
ALT = "Poster with the title Harbor Day 2026."
COLL = "app.bluehaze.feed.post"

cj = http.cookiejar.CookieJar()
op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))

def get(path):
    with op.open(BASE + path) as r:
        return r.read().decode()

def rpc(method, params=None, body=None, ctype=None, token=None):
    url = BASE + "/rpc/" + method
    if params:
        url += "?" + urllib.parse.urlencode(params)
    headers = {}
    data = None
    if body is not None:
        headers["Content-Type"] = ctype or "application/json"
        headers["X-Bh-Token"] = token
        data = body if ctype else json.dumps(body).encode()
    req = urllib.request.Request(url, data=data, headers=headers,
                                 method="POST" if body is not None else "GET")
    with op.open(req) as r:
        return json.loads(r.read().decode())

import urllib.parse

html = get("/")
nonce = re.search(r'name="bh-boot" content="([0-9a-f]+)"', html).group(1)
def token(n):
    f = 0x811C9DC5; g = ""
    for h in range(4):
        s = n + "." + str(h)
        for ch in s:
            f ^= ord(ch); f = (f * 0x01000193) & 0xFFFFFFFF
        g += format(f, "08x")
    return g
k = token(nonce)

who = rpc("com.bluehaze.server.getSession")
print("SESSION:", json.dumps(who))
assert who.get("handle") == "tester.bluehaze.test", who
did = who["did"]

before_tl = rpc("app.bluehaze.feed.getTimeline", {"limit": "100"})
before_af = rpc("app.bluehaze.feed.getAuthorFeed", {"actor": who["handle"], "limit": "100"})
def sig(feed):
    return [(p["uri"], p["cid"], p["record"]["text"]) for p in feed["feed"]]
before_all = sig(before_tl) + sig(before_af)
print("BEFORE timeline posts:", len(before_tl["feed"]), "author posts:", len(before_af["feed"]))

blob = open("cover.png", "rb").read()
up = rpc("com.bluehaze.repo.uploadBlob", body=blob, ctype="image/png", token=k)
print("UPLOAD:", json.dumps(up)[:300])

record = {"$type": COLL, "text": TEXT,
          "createdAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "embed": {"$type": "app.bluehaze.embed.images",
                    "images": [{"image": up["blob"], "alt": ALT}]}}
created = rpc("com.bluehaze.repo.createRecord",
              body={"repo": did, "collection": COLL, "record": record}, token=k)
print("CREATED:", json.dumps(created))
uri = created["uri"]; rkey = uri.split("/")[-1]

thread = rpc("app.bluehaze.feed.getPostThread", {"uri": uri})
p = thread["thread"]["post"]
imgs = p.get("embed", {}).get("images", [])
assert p["record"]["text"] == TEXT, p["record"]["text"]
assert imgs and imgs[0]["alt"] == ALT, imgs
print("VERIFIED LIVE: text exact, alt exact, image src:", imgs[0]["thumb"][:80])

deleted = rpc("com.bluehaze.repo.deleteRecord",
              body={"repo": did, "collection": COLL, "rkey": rkey}, token=k)
print("DELETED:", json.dumps(deleted))

try:
    rpc("app.bluehaze.feed.getPostThread", {"uri": uri})
    print("ERROR: post still readable"); sys.exit(1)
except urllib.error.HTTPError as e:
    print("GONE check: HTTP", e.code, e.read().decode()[:200])

after_tl = rpc("app.bluehaze.feed.getTimeline", {"limit": "100"})
after_af = rpc("app.bluehaze.feed.getAuthorFeed", {"actor": who["handle"], "limit": "100"})
after_all = sig(after_tl) + sig(after_af)
assert uri not in [u for u, _, _ in after_all], "post still in feeds"
assert sorted(before_all) == sorted(after_all), "other posts changed!"
print("FINAL: feeds identical to before (timeline", len(after_tl["feed"]),
      ", author", len(after_af["feed"]), "); only the test post was created and removed.")