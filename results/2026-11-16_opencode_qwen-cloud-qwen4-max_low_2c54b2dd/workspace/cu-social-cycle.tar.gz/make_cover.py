from PIL import Image, ImageDraw, ImageFont

W, H = 1200, 675
img = Image.new("RGB", (W, H))
d = ImageDraw.Draw(img)
# dusk sky gradient over harbor water
for y in range(H):
    t = y / H
    if t < 0.62:
        s = t / 0.62
        r = int(24 + 60 * s); g = int(34 + 50 * s); b = int(74 + 90 * s)
    else:
        s = (t - 0.62) / 0.38
        r = int(16 + 10 * s); g = int(30 + 20 * s); b = int(60 + 30 * s)
    d.line([(0, y), (W, y)], fill=(r, g, b))
# sun glow
d.ellipse([880, 120, 1080, 320], fill=(255, 190, 120))
d.ellipse([905, 145, 1055, 295], fill=(255, 214, 150))
# water shimmer lines
for i, y in enumerate(range(430, 660, 18)):
    w = 220 - i * 8
    d.line([(980 - w // 2, y), (980 + w // 2, y)], fill=(255, 200, 140), width=3)
# simple boat silhouette
d.polygon([(180, 470), (360, 470), (330, 510), (210, 510)], fill=(10, 14, 26))
d.line([(270, 470), (270, 360)], fill=(10, 14, 26), width=6)
d.polygon([(276, 365), (276, 460), (345, 460)], fill=(18, 24, 40))
# title, legible, centered
font = ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf", 112)
sub = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 40)
title = "Harbor Day 2026"
bb = d.textbbox((0, 0), title, font=font)
tw = bb[2] - bb[0]
x = (W - tw) // 2
y = 210
d.text((x + 4, y + 4), title, font=font, fill=(8, 10, 20))
d.text((x, y), title, font=font, fill=(255, 255, 255))
st = "A day on the water"
sb = d.textbbox((0, 0), st, font=sub)
d.text(((W - (sb[2] - sb[0])) // 2, y + 150), st, font=sub, fill=(220, 230, 255))
img.save("cover.png", "PNG")
print("saved", img.size, img.mode)