"""Match payout. Rules live in docs/ECONOMY.md."""

from decimal import Decimal, ROUND_HALF_UP


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    # Decimal from str keeps exact halves (e.g. 1425) intact; float math can
    # drift below the half and floor-based rounding would round it down.
    raw = (Decimal(str(base)) + Decimal(kills) * Decimal(str(cfg["kill_bonus"]))) * Decimal(str(cfg["event_multiplier"]))
    return int(raw.quantize(Decimal("1E1"), rounding=ROUND_HALF_UP))