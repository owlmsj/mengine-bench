
"use strict";
/* POP SHOT! — single-file canvas archery. All art procedural, all sound synthesized. */

const canvas = document.getElementById('stage');
const ctx = canvas.getContext('2d');
let W = 0, H = 0, S = 1, DPR = 1;

function resize(){
  DPR = Math.min(window.devicePixelRatio || 1, 2);
  W = window.innerWidth; H = window.innerHeight;
  canvas.width = W * DPR; canvas.height = H * DPR;
  canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
  S = Math.max(0.6, Math.min(H / 800, W / 1100));
}
window.addEventListener('resize', resize);
resize();

/* ---------- state ---------- */
const TARGET = 1500, MAX_ARROWS = 20;
const state = {
  mode: 'menu',            // menu | play | win | lose
  score: 0, arrowsLeft: MAX_ARROWS, streak: 0,
  charging: false, power: 0, aim: -0.6,
  mouse: { x: 0, y: 0 },
  shake: 0, hitstop: 0, time: 0, spawnTimer: 0,
  best: Number(localStorage.getItem('popshot_best') || 0),
};
const balloons = [], arrows = [], particles = [], popups = [], clouds = [];
for (let i = 0; i < 5; i++) clouds.push({ x: Math.random(), y: 0.08 + Math.random() * 0.22, s: 0.6 + Math.random(), v: 0.004 + Math.random() * 0.008 });

const BALLOON_COLORS = ['#ff5d5d','#2ec4b6','#ffbf3f','#9b5de5','#ff7ab6','#4ea8de'];
const rnd = (a, b) => a + Math.random() * (b - a);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

function archerPos(){ return { x: W * 0.115, y: H - 74 * S }; }
function bowAnchor(){ const a = archerPos(); return { x: a.x + 14 * S, y: a.y - 52 * S }; }

/* ---------- audio (all synthesized) ---------- */
let AC = null, master = null, musicGain = null, muted = false, musicTimer = null, nextNote = 0, noteIdx = 0;
function ensureAudio(){
  if (AC) { if (AC.state === 'suspended') AC.resume(); return; }
  AC = new (window.AudioContext || window.webkitAudioContext)();
  master = AC.createGain(); master.gain.value = muted ? 0 : 0.9; master.connect(AC.destination);
  musicGain = AC.createGain(); musicGain.gain.value = 0.16; musicGain.connect(master);
  nextNote = AC.currentTime + 0.1;
  musicTimer = setInterval(scheduleMusic, 90);
}
function env(g, t, a, peak, d){
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(peak, t + a);
  g.gain.exponentialRampToValueAtTime(0.0001, t + a + d);
}
function tone(freq, dur, type, vol, when, slideTo){
  if (!AC) return;
  const t = when || AC.currentTime;
  const o = AC.createOscillator(), g = AC.createGain();
  o.type = type; o.frequency.setValueAtTime(freq, t);
  if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
  env(g, t, 0.006, vol, dur);
  o.connect(g); g.connect(master);
  o.start(t); o.stop(t + dur + 0.1);
}
function noise(dur, vol, filterFreq, type, when){
  if (!AC) return;
  const t = when || AC.currentTime;
  const len = Math.max(1, Math.floor(AC.sampleRate * dur));
  const buf = AC.createBuffer(1, len, AC.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
  const src = AC.createBufferSource(); src.buffer = buf;
  const f = AC.createBiquadFilter(); f.type = type || 'bandpass'; f.frequency.value = filterFreq; f.Q.value = 0.9;
  const g = AC.createGain(); env(g, t, 0.004, vol, dur);
  src.connect(f); f.connect(g); g.connect(master);
  src.start(t);
}
const snd = {
  draw(){ tone(90, 0.22, 'sawtooth', 0.05, null, 160); noise(0.18, 0.05, 900, 'lowpass'); },
  twang(power){
    const f = 150 + power * 90;
    tone(f, 0.16, 'triangle', 0.32, null, f * 0.72);
    tone(f * 2.01, 0.09, 'square', 0.07);
    noise(0.22, 0.12, 2400, 'highpass');
  },
  pop(size, mult){
    const base = 620 - size * 9;
    noise(0.09, 0.5, 1800 + Math.random() * 900, 'bandpass');
    tone(base, 0.1, 'sine', 0.3, null, base * 0.45);
    const penta = [523, 587, 659, 784, 880];
    tone(penta[Math.min(mult - 1, 4)] * 2, 0.14, 'sine', 0.14, AC ? AC.currentTime + 0.05 : 0);
  },
  gold(){ [880, 1108, 1318, 1760].forEach((f, i) => tone(f, 0.18, 'triangle', 0.18, AC.currentTime + i * 0.06)); },
  bomb(){ tone(160, 0.5, 'sine', 0.5, null, 40); noise(0.4, 0.5, 300, 'lowpass'); },
  miss(){ noise(0.16, 0.07, 700, 'lowpass'); },
  win(){ [523, 659, 784, 1046, 784, 1046, 1318].forEach((f, i) => tone(f, 0.22, 'triangle', 0.22, AC.currentTime + i * 0.12)); },
  lose(){ [392, 349, 311, 262].forEach((f, i) => tone(f, 0.3, 'triangle', 0.18, AC.currentTime + i * 0.22)); },
  click(){ tone(660, 0.07, 'square', 0.1); },
};
/* gentle fairground pluck loop */
const MELODY = [523, 0, 659, 784, 0, 659, 523, 0, 587, 0, 698, 880, 0, 698, 587, 0];
const BASS = [131, 131, 175, 175, 147, 147, 196, 196];
function scheduleMusic(){
  if (!AC || muted || state.mode !== 'play') return;
  while (nextNote < AC.currentTime + 0.25) {
    const step = noteIdx % 16;
    const m = MELODY[step];
    if (m) pluck(m, nextNote, 0.5);
    if (step % 2 === 0) pluck(BASS[(noteIdx >> 1) % 8], nextNote, 0.9, true);
    nextNote += 0.24; noteIdx++;
  }
}
function pluck(freq, t, dur, bass){
  const o = AC.createOscillator(), g = AC.createGain();
  o.type = bass ? 'sine' : 'triangle'; o.frequency.value = freq;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(bass ? 0.5 : 0.3, t + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g); g.connect(musicGain);
  o.start(t); o.stop(t + dur + 0.05);
}
document.getElementById('mute').addEventListener('click', () => {
  ensureAudio();
  muted = !muted;
  if (master) master.gain.value = muted ? 0 : 0.9;
  document.getElementById('mute').textContent = muted ? '🔇' : '🔊';
});

/* ---------- HUD ---------- */
const el = id => document.getElementById(id);
function buildQuiver(){
  const q = el('quiver'); q.innerHTML = '';
  for (let i = 0; i < MAX_ARROWS; i++) {
    const d = document.createElement('div');
    d.className = 'arrow-icon' + (i >= state.arrowsLeft ? ' spent' : '');
    q.appendChild(d);
  }
}
function updateHUD(){
  el('score').textContent = state.score;
  el('goalfill').style.width = clamp(state.score / TARGET * 100, 0, 100) + '%';
  el('goaltxt').textContent = state.score >= TARGET ? 'TARGET REACHED!' : 'TARGET ' + TARGET;
  buildQuiver();
  const c = el('combo');
  const mult = Math.min(5, 1 + state.streak);
  if (state.streak >= 2 && state.mode === 'play') { c.textContent = '×' + mult + ' STREAK!'; c.classList.add('on'); }
  else c.classList.remove('on');
}
function showScreen(id){
  ['menu', 'win', 'lose'].forEach(s => el(s).classList.toggle('hidden', s !== id));
}
function bestText(){ return state.best > 0 ? 'BEST: ' + state.best : ''; }

/* ---------- game flow ---------- */
function startGame(){
  ensureAudio(); snd.click();
  state.mode = 'play'; state.score = 0; state.arrowsLeft = MAX_ARROWS;
  state.streak = 0; state.charging = false; state.power = 0;
  state.spawnTimer = 0.2; state.shake = 0; state.hitstop = 0;
  balloons.length = 0; arrows.length = 0; particles.length = 0; popups.length = 0;
  for (let i = 0; i < 5; i++) spawnBalloon(true);
  showScreen(null); updateHUD();
  el('hint').classList.add('show');
  setTimeout(() => el('hint').classList.remove('show'), 4200);
}
function endGame(won){
  state.mode = won ? 'win' : 'lose';
  state.charging = false;
  if (won) {
    const bonus = state.arrowsLeft * 50;
    state.score += bonus;
    const stars = state.arrowsLeft >= 8 ? 3 : state.arrowsLeft >= 4 ? 2 : 1;
    el('winStars').textContent = '★'.repeat(stars) + '☆'.repeat(3 - stars);
    el('winScore').textContent = state.score + (bonus ? '  (+' + bonus + ' arrow bonus)' : '');
    snd.win();
  } else {
    el('loseScore').textContent = state.score + ' / ' + TARGET;
    snd.lose();
  }
  if (state.score > state.best) { state.best = state.score; localStorage.setItem('popshot_best', String(state.best)); }
  el('menuBest').textContent = bestText();
  el('loseBest').textContent = bestText();
  el('winBest').textContent = bestText();
  updateHUD();
  setTimeout(() => showScreen(won ? 'win' : 'lose'), won ? 700 : 500);
}
el('startBtn').addEventListener('click', startGame);
el('retryBtn').addEventListener('click', startGame);
el('againBtn').addEventListener('click', startGame);
el('menuBest').textContent = bestText();

/* ---------- input ---------- */
function setAim(){
  const b = bowAnchor();
  state.aim = clamp(Math.atan2(state.mouse.y - b.y, state.mouse.x - b.x), -1.5, 0.25);
}
canvas.addEventListener('pointermove', e => { state.mouse.x = e.clientX; state.mouse.y = e.clientY; setAim(); });
canvas.addEventListener('pointerdown', e => {
  ensureAudio();
  state.mouse.x = e.clientX; state.mouse.y = e.clientY; setAim();
  if (state.mode !== 'play' || state.arrowsLeft <= 0) return;
  state.charging = true; state.power = 0;
  snd.draw();
  canvas.setPointerCapture(e.pointerId);
});
window.addEventListener('pointerup', () => {
  if (!state.charging) return;
  state.charging = false;
  if (state.mode === 'play' && state.power > 0.07 && state.arrowsLeft > 0) fireArrow();
  state.power = 0;
});
canvas.addEventListener('contextmenu', e => e.preventDefault());

function fireArrow(){
  const b = bowAnchor();
  const speed = (560 + 820 * state.power) * S;
  arrows.push({
    x: b.x + Math.cos(state.aim) * 30 * S, y: b.y + Math.sin(state.aim) * 30 * S,
    vx: Math.cos(state.aim) * speed, vy: Math.sin(state.aim) * speed,
    trail: [], dead: false,
  });
  state.arrowsLeft--;
  state.shake = Math.max(state.shake, 2 + state.power * 3);
  snd.twang(state.power);
  updateHUD();
}

/* ---------- balloons ---------- */
function spawnBalloon(onScreen){
  const roll = Math.random();
  let kind = 'normal', r, pts;
  if (roll < 0.08) { kind = 'gold'; r = 24; pts = 300; }
  else if (roll < 0.20 && state.time > 6) { kind = 'bomb'; r = 27; pts = 0; }
  else {
    const sizeRoll = Math.random();
    if (sizeRoll < 0.3) { r = 18; pts = 150; }
    else if (sizeRoll < 0.68) { r = 26; pts = 100; }
    else { r = 34; pts = 50; }
  }
  r *= S;
  balloons.push({
    kind, r, pts,
    x: rnd(W * 0.32, W * 0.94),
    y: onScreen ? rnd(H * 0.25, H * 0.85) : H + r + 20,
    vy: -rnd(55, 120) * S * (kind === 'gold' ? 1.35 : 1),
    swayAmp: rnd(8, 26) * S, swayFreq: rnd(0.8, 1.8), phase: rnd(0, 6.28),
    color: kind === 'gold' ? '#ffd700' : kind === 'bomb' ? '#2b2d33' : BALLOON_COLORS[(Math.random() * BALLOON_COLORS.length) | 0],
    baseX: 0, wob: 0,
  });
  const b = balloons[balloons.length - 1];
  b.baseX = b.x;
}
function popBalloon(b, arrow){
  const idx = balloons.indexOf(b);
  if (idx >= 0) balloons.splice(idx, 1);
  if (b.kind === 'bomb') {
    state.streak = 0;
    state.arrowsLeft = Math.max(0, state.arrowsLeft - 3);
    state.shake = 16; state.hitstop = 0.09;
    snd.bomb();
    burst(b.x, b.y, '#444', 22, true);
    burst(b.x, b.y, '#ff9d3f', 14, true);
    popups.push({ x: b.x, y: b.y, text: '-3 ARROWS!', color: '#ff5d5d', life: 1.3, vy: -55 });
    updateHUD();
    checkLose();
    return;
  }
  const mult = Math.min(5, 1 + state.streak);
  const gained = b.pts * mult;
  state.score += gained;
  state.streak++;
  state.shake = Math.max(state.shake, b.kind === 'gold' ? 9 : 5);
  state.hitstop = 0.045;
  if (b.kind === 'gold') snd.gold(); else snd.pop(b.r / S, mult);
  burst(b.x, b.y, b.color, b.kind === 'gold' ? 26 : 16, false);
  popups.push({
    x: b.x, y: b.y - b.r,
    text: '+' + gained + (mult > 1 ? '  ×' + mult : ''),
    color: b.kind === 'gold' ? '#ffd700' : '#fff6e6',
    life: 1.1, vy: -70,
  });
  updateHUD();
  if (state.score >= TARGET) { endGame(true); return; }
}
function burst(x, y, color, n, fiery){
  for (let i = 0; i < n; i++) {
    const a = rnd(0, Math.PI * 2), sp = rnd(90, fiery ? 420 : 300) * S;
    particles.push({
      x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 60 * S,
      life: rnd(0.4, 0.85), maxLife: 0.85,
      size: rnd(3, 7) * S, color,
      kind: fiery ? 'spark' : (Math.random() < 0.5 ? 'shard' : 'confetti'),
      rot: rnd(0, 6.28), vrot: rnd(-9, 9),
    });
  }
  particles.push({ x, y, vx: 0, vy: 0, life: 0.22, maxLife: 0.22, size: 10 * S, color: '#ffffff', kind: 'ring', rot: 0, vrot: 0 });
}
function checkLose(){
  if (state.mode !== 'play') return;
  if (state.arrowsLeft <= 0 && arrows.length === 0 && state.score < TARGET) endGame(false);
}

/* ---------- update ---------- */
function update(dt){
  state.time += dt;
  if (state.hitstop > 0) { state.hitstop -= dt; return; }
  state.shake = Math.max(0, state.shake - dt * 34);

  if (state.mode === 'play') {
    if (state.charging) state.power = clamp(state.power + dt / 0.85, 0, 1);
    state.spawnTimer -= dt;
    const interval = Math.max(0.42, 0.95 - state.time * 0.008);
    if (state.spawnTimer <= 0 && balloons.length < 14) { spawnBalloon(false); state.spawnTimer = interval; }
  }

  for (let i = balloons.length - 1; i >= 0; i--) {
    const b = balloons[i];
    b.y += b.vy * dt;
    b.phase += b.swayFreq * dt;
    b.x = b.baseX + Math.sin(b.phase) * b.swayAmp;
    b.wob = Math.sin(b.phase * 2) * 0.06;
    if (b.y < -b.r * 2.5) balloons.splice(i, 1);
  }

  const g = 1150 * S;
  for (let i = arrows.length - 1; i >= 0; i--) {
    const a = arrows[i];
    a.trail.push({ x: a.x, y: a.y });
    if (a.trail.length > 9) a.trail.shift();
    a.vy += g * dt;
    a.x += a.vx * dt; a.y += a.vy * dt;
    const ang = Math.atan2(a.vy, a.vx);
    const tipX = a.x + Math.cos(ang) * 20 * S, tipY = a.y + Math.sin(ang) * 20 * S;
    let hit = false;
    for (const b of balloons) {
      const dx = tipX - b.x, dy = tipY - b.y;
      if (dx * dx + dy * dy < (b.r + 5 * S) * (b.r + 5 * S)) { popBalloon(b, a); hit = true; break; }
    }
    if (hit || a.x > W + 60 || a.x < -60 || a.y > H + 60) {
      arrows.splice(i, 1);
      if (!hit) {
        if (state.streak >= 2) snd.miss();
        state.streak = 0;
        updateHUD();
      }
      checkLose();
    }
  }

  for (let i = particles.length - 1; i >= 0; i--) {
    const p = particles[i];
    p.life -= dt;
    if (p.life <= 0) { particles.splice(i, 1); continue; }
    if (p.kind !== 'ring') {
      p.vy += (p.kind === 'confetti' ? 320 : 700) * S * dt;
      p.vx *= 1 - dt * 1.4;
      p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.vrot * dt;
    }
  }
  for (let i = popups.length - 1; i >= 0; i--) {
    const p = popups[i];
    p.life -= dt; p.y += p.vy * dt; p.vy *= 1 - dt * 2;
    if (p.life <= 0) popups.splice(i, 1);
  }
  for (const c of clouds) { c.x += c.v * dt; if (c.x > 1.15) c.x = -0.15; }
}

/* ---------- drawing ---------- */
function drawBackground(){
  const sky = ctx.createLinearGradient(0, 0, 0, H);
  sky.addColorStop(0, '#241448');
  sky.addColorStop(0.45, '#5b2a6e');
  sky.addColorStop(0.72, '#c95d63');
  sky.addColorStop(0.9, '#ff9e5e');
  ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);

  /* sun */
  const sunX = W * 0.72, sunY = H * 0.78;
  const glow = ctx.createRadialGradient(sunX, sunY, 10, sunX, sunY, 220 * S);
  glow.addColorStop(0, 'rgba(255,220,150,.85)');
  glow.addColorStop(1, 'rgba(255,220,150,0)');
  ctx.fillStyle = glow; ctx.fillRect(sunX - 240 * S, sunY - 240 * S, 480 * S, 480 * S);
  ctx.fillStyle = '#ffe9b0';
  ctx.beginPath(); ctx.arc(sunX, sunY, 46 * S, 0, 6.29); ctx.fill();

  /* clouds */
  ctx.fillStyle = 'rgba(255,190,160,.28)';
  for (const c of clouds) {
    const cx = c.x * W, cy = c.y * H, cs = c.s * 34 * S;
    ctx.beginPath();
    ctx.arc(cx, cy, cs, 0, 6.29);
    ctx.arc(cx + cs * 0.9, cy + cs * 0.2, cs * 0.7, 0, 6.29);
    ctx.arc(cx - cs * 0.9, cy + cs * 0.25, cs * 0.6, 0, 6.29);
    ctx.fill();
  }

  /* far hills */
  ctx.fillStyle = '#3d2352';
  ctx.beginPath(); ctx.moveTo(0, H * 0.82);
  ctx.quadraticCurveTo(W * 0.25, H * 0.7, W * 0.5, H * 0.8);
  ctx.quadraticCurveTo(W * 0.75, H * 0.9, W, H * 0.76);
  ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.fill();

  drawFerrisWheel(W * 0.86, H * 0.72, 92 * S);
  drawTent(W * 0.58, H * 0.84, 130 * S);

  /* near ground */
  ctx.fillStyle = '#2c4a2e';
  ctx.beginPath(); ctx.moveTo(0, H - 46 * S);
  ctx.quadraticCurveTo(W * 0.5, H - 66 * S, W, H - 40 * S);
  ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.fill();
  ctx.fillStyle = '#243d26';
  ctx.fillRect(0, H - 18 * S, W, 18 * S);

  drawBunting();
}
function drawFerrisWheel(cx, cy, r){
  ctx.save();
  ctx.strokeStyle = 'rgba(30,15,50,.85)'; ctx.fillStyle = 'rgba(30,15,50,.85)';
  ctx.lineWidth = 4 * S;
  ctx.beginPath(); ctx.moveTo(cx - r * 0.6, cy + r * 1.15); ctx.lineTo(cx, cy); ctx.lineTo(cx + r * 0.6, cy + r * 1.15); ctx.stroke();
  const rot = state.time * 0.12;
  ctx.lineWidth = 3 * S;
  ctx.beginPath(); ctx.arc(cx, cy, r, 0, 6.29); ctx.stroke();
  for (let i = 0; i < 8; i++) {
    const a = rot + i * Math.PI / 4;
    const ex = cx + Math.cos(a) * r, ey = cy + Math.sin(a) * r;
    ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(ex, ey); ctx.stroke();
    ctx.fillStyle = i % 2 ? 'rgba(255,158,94,.6)' : 'rgba(46,196,182,.6)';
    ctx.fillRect(ex - 6 * S, ey, 12 * S, 10 * S);
    ctx.fillStyle = 'rgba(30,15,50,.85)';
  }
  ctx.restore();
}
function drawTent(cx, baseY, w){
  const h = w * 0.62;
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(cx - w / 2, baseY);
  ctx.quadraticCurveTo(cx - w * 0.2, baseY - h * 0.7, cx, baseY - h);
  ctx.quadraticCurveTo(cx + w * 0.2, baseY - h * 0.7, cx + w / 2, baseY);
  ctx.closePath();
  ctx.fillStyle = '#a83a5a'; ctx.fill();
  ctx.clip();
  ctx.fillStyle = '#f2e3c6';
  for (let i = -3; i <= 3; i += 2) ctx.fillRect(cx + i * w * 0.14 - w * 0.07, baseY - h, w * 0.14, h);
  ctx.restore();
  ctx.strokeStyle = '#2a1a3a'; ctx.lineWidth = 2 * S;
  ctx.beginPath(); ctx.moveTo(cx, baseY - h); ctx.lineTo(cx, baseY - h - 16 * S); ctx.stroke();
  ctx.fillStyle = '#ffcf3f';
  ctx.beginPath(); ctx.moveTo(cx, baseY - h - 16 * S); ctx.lineTo(cx + 14 * S, baseY - h - 11 * S); ctx.lineTo(cx, baseY - h - 6 * S); ctx.fill();
}
function drawBunting(){
  const y0 = 26 * S, sag = 34 * S, n = 14;
  ctx.strokeStyle = 'rgba(255,246,230,.5)'; ctx.lineWidth = 2 * S;
  ctx.beginPath(); ctx.moveTo(-10, y0);
  ctx.quadraticCurveTo(W / 2, y0 + sag * 2, W + 10, y0); ctx.stroke();
  const cols = ['#ff5d5d', '#ffcf3f', '#2ec4b6', '#9b5de5', '#ff7ab6'];
  for (let i = 1; i < n; i++) {
    const t = i / n;
    const x = -10 + (W + 20) * t;
    const y = y0 + 2 * sag * 2 * t * (1 - t) * 2;
    const sway = Math.sin(state.time * 1.6 + i) * 3 * S;
    ctx.fillStyle = cols[i % cols.length];
    ctx.beginPath();
    ctx.moveTo(x - 9 * S, y);
    ctx.lineTo(x + 9 * S, y);
    ctx.lineTo(x + sway, y + 20 * S);
    ctx.closePath(); ctx.fill();
  }
}
function drawArcher(){
  const a = archerPos();
  const b = bowAnchor();
  const aim = state.aim;
  const draw = state.charging ? state.power : 0;
  ctx.save();
  ctx.translate(a.x, a.y);
  ctx.scale(S, S);
  /* legs */
  ctx.strokeStyle = '#3a2a1a'; ctx.lineWidth = 7; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(0, -26); ctx.lineTo(-10, 0); ctx.moveTo(0, -26); ctx.lineTo(11, 0); ctx.stroke();
  /* body */
  ctx.fillStyle = '#3f7d44';
  ctx.beginPath(); ctx.moveTo(-11, -26); ctx.quadraticCurveTo(0, -20, 11, -26); ctx.lineTo(8, -56); ctx.lineTo(-8, -56); ctx.closePath(); ctx.fill();
  /* head + hood */
  ctx.fillStyle = '#f2c49b';
  ctx.beginPath(); ctx.arc(2, -66, 9, 0, 6.29); ctx.fill();
  ctx.fillStyle = '#2f5e34';
  ctx.beginPath(); ctx.arc(0, -68, 11, Math.PI * 0.85, Math.PI * 2.05); ctx.lineTo(14, -62); ctx.closePath(); ctx.fill();
  /* quiver on back */
  ctx.fillStyle = '#7a4a22';
  ctx.save(); ctx.rotate(-0.35); ctx.fillRect(-24, -58, 9, 26); ctx.restore();
  ctx.restore();

  /* bow + arms in world space, rotated to aim */
  ctx.save();
  ctx.translate(b.x, b.y);
  ctx.rotate(aim);
  ctx.scale(S, S);
  const pull = 8 + draw * 26;
  /* back arm */
  ctx.strokeStyle = '#f2c49b'; ctx.lineWidth = 6; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(-14, 6); ctx.lineTo(-pull - 4, 0); ctx.stroke();
  /* bow limb */
  ctx.strokeStyle = '#8a5a2b'; ctx.lineWidth = 5;
  ctx.beginPath(); ctx.arc(6, 0, 34, -1.25, 1.25); ctx.stroke();
  /* string */
  const tipX = 6 + Math.cos(1.25) * 34, tipY = Math.sin(1.25) * 34;
  ctx.strokeStyle = '#f5f0e0'; ctx.lineWidth = 1.6;
  ctx.beginPath(); ctx.moveTo(tipX, -tipY); ctx.lineTo(-pull, 0); ctx.lineTo(tipX, tipY); ctx.stroke();
  /* nocked arrow */
  if (state.charging || state.mode === 'menu') {
    ctx.strokeStyle = '#c98a4b'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(-pull, 0); ctx.lineTo(30, 0); ctx.stroke();
    ctx.fillStyle = '#d8d8e8';
    ctx.beginPath(); ctx.moveTo(36, 0); ctx.lineTo(28, -4); ctx.lineTo(28, 4); ctx.closePath(); ctx.fill();
    ctx.fillStyle = '#ff5d5d';
    ctx.beginPath(); ctx.moveTo(-pull, 0); ctx.lineTo(-pull + 8, -4); ctx.lineTo(-pull + 8, 4); ctx.closePath(); ctx.fill();
  }
  /* front arm */
  ctx.strokeStyle = '#f2c49b'; ctx.lineWidth = 6;
  ctx.beginPath(); ctx.moveTo(-12, 4); ctx.lineTo(8, 0); ctx.stroke();
  ctx.restore();

  /* power ring */
  if (state.charging) {
    ctx.save();
    ctx.translate(b.x, b.y);
    ctx.lineWidth = 5 * S;
    ctx.strokeStyle = 'rgba(255,246,230,.2)';
    ctx.beginPath(); ctx.arc(0, 0, 52 * S, 0, 6.29); ctx.stroke();
    const hue = 120 - state.power * 120;
    ctx.strokeStyle = 'hsl(' + hue + ',90%,60%)';
    ctx.beginPath(); ctx.arc(0, 0, 52 * S, -Math.PI / 2, -Math.PI / 2 + state.power * 6.283); ctx.stroke();
    ctx.restore();
    drawTrajectory();
  }
}
function drawTrajectory(){
  const b = bowAnchor();
  const speed = (560 + 820 * state.power) * S;
  let x = b.x + Math.cos(state.aim) * 30 * S, y = b.y + Math.sin(state.aim) * 30 * S;
  let vx = Math.cos(state.aim) * speed, vy = Math.sin(state.aim) * speed;
  const g = 1150 * S, step = 0.045;
  ctx.fillStyle = 'rgba(255,246,230,.7)';
  for (let i = 0; i < 22; i++) {
    vy += g * step; x += vx * step; y += vy * step;
    if (x > W || y > H) break;
    ctx.globalAlpha = 0.65 * (1 - i / 22);
    ctx.beginPath(); ctx.arc(x, y, 3 * S, 0, 6.29); ctx.fill();
  }
  ctx.globalAlpha = 1;
}
function drawBalloon(b){
  ctx.save();
  ctx.translate(b.x, b.y);
  ctx.rotate(b.wob);
  /* string */
  ctx.strokeStyle = 'rgba(255,246,230,.55)'; ctx.lineWidth = 1.4 * S;
  ctx.beginPath(); ctx.moveTo(0, b.r * 1.15);
  ctx.quadraticCurveTo(Math.sin(b.phase * 1.5) * 8 * S, b.r * 1.15 + 22 * S, Math.sin(b.phase) * 5 * S, b.r * 1.15 + 42 * S);
  ctx.stroke();
  /* body */
  const grad = ctx.createRadialGradient(-b.r * 0.35, -b.r * 0.4, b.r * 0.15, 0, 0, b.r * 1.25);
  grad.addColorStop(0, lighten(b.color, 0.45));
  grad.addColorStop(0.55, b.color);
  grad.addColorStop(1, darken(b.color, 0.3));
  ctx.fillStyle = grad;
  ctx.beginPath(); ctx.ellipse(0, 0, b.r, b.r * 1.12, 0, 0, 6.29); ctx.fill();
  /* knot */
  ctx.fillStyle = darken(b.color, 0.2);
  ctx.beginPath(); ctx.moveTo(-5 * S, b.r * 1.1); ctx.lineTo(5 * S, b.r * 1.1); ctx.lineTo(0, b.r * 1.24); ctx.closePath(); ctx.fill();
  /* shine */
  ctx.fillStyle = 'rgba(255,255,255,.5)';
  ctx.beginPath(); ctx.ellipse(-b.r * 0.35, -b.r * 0.45, b.r * 0.22, b.r * 0.32, -0.5, 0, 6.29); ctx.fill();
  if (b.kind === 'gold') {
    ctx.fillStyle = 'rgba(255,255,255,' + (0.5 + Math.sin(state.time * 6) * 0.3) + ')';
    star(0, 0, b.r * 0.42);
  }
  if (b.kind === 'bomb') {
    ctx.fillStyle = '#e8e8f0';
    ctx.font = '900 ' + Math.round(b.r * 1.1) + 'px Nunito, sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('☠', 0, b.r * 0.08);
    ctx.strokeStyle = '#ff9d3f'; ctx.lineWidth = 2 * S;
    ctx.beginPath(); ctx.moveTo(0, -b.r * 1.12); ctx.quadraticCurveTo(6 * S, -b.r * 1.35, 2 * S, -b.r * 1.5); ctx.stroke();
    ctx.fillStyle = '#ffcf3f';
    ctx.beginPath(); ctx.arc(2 * S, -b.r * 1.5, 2.5 * S + Math.sin(state.time * 12) * S, 0, 6.29); ctx.fill();
  }
  ctx.restore();
}
function star(x, y, r){
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const a = -Math.PI / 2 + i * Math.PI / 5;
    const rr = i % 2 ? r * 0.45 : r;
    const px = x + Math.cos(a) * rr, py = y + Math.sin(a) * rr;
    i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
  }
  ctx.closePath(); ctx.fill();
}
function lighten(hex, amt){ return shade(hex, amt); }
function darken(hex, amt){ return shade(hex, -amt); }
function shade(hex, amt){
  const n = parseInt(hex.slice(1), 16);
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  if (amt >= 0) { r += (255 - r) * amt; g += (255 - g) * amt; b += (255 - b) * amt; }
  else { r *= 1 + amt; g *= 1 + amt; b *= 1 + amt; }
  return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
}
function drawArrow(a){
  /* trail */
  ctx.strokeStyle = 'rgba(255,246,230,.28)'; ctx.lineWidth = 2 * S;
  ctx.beginPath();
  for (let i = 0; i < a.trail.length; i++) {
    const t = a.trail[i];
    i ? ctx.lineTo(t.x, t.y) : ctx.moveTo(t.x, t.y);
  }
  ctx.stroke();
  const ang = Math.atan2(a.vy, a.vx);
  ctx.save();
  ctx.translate(a.x, a.y); ctx.rotate(ang); ctx.scale(S, S);
  ctx.strokeStyle = '#c98a4b'; ctx.lineWidth = 3; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(-20, 0); ctx.lineTo(16, 0); ctx.stroke();
  ctx.fillStyle = '#d8d8e8';
  ctx.beginPath(); ctx.moveTo(22, 0); ctx.lineTo(13, -4.5); ctx.lineTo(13, 4.5); ctx.closePath(); ctx.fill();
  ctx.fillStyle = '#ff5d5d';
  ctx.beginPath(); ctx.moveTo(-20, 0); ctx.lineTo(-12, -5); ctx.lineTo(-8, 0); ctx.lineTo(-12, 5); ctx.closePath(); ctx.fill();
  ctx.restore();
}
function drawParticles(){
  for (const p of particles) {
    const t = p.life / p.maxLife;
    ctx.globalAlpha = clamp(t, 0, 1);
    if (p.kind === 'ring') {
      ctx.strokeStyle = p.color; ctx.lineWidth = 3 * S * t;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.size + (1 - t) * 46 * S, 0, 6.29); ctx.stroke();
    } else {
      ctx.save();
      ctx.translate(p.x, p.y); ctx.rotate(p.rot);
      ctx.fillStyle = p.color;
      if (p.kind === 'shard') {
        ctx.beginPath(); ctx.arc(0, 0, p.size, 0.3, 2.6); ctx.lineTo(0, 0); ctx.closePath(); ctx.fill();
      } else if (p.kind === 'confetti') {
        ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
      } else {
        ctx.beginPath(); ctx.arc(0, 0, p.size * t, 0, 6.29); ctx.fill();
      }
      ctx.restore();
    }
  }
  ctx.globalAlpha = 1;
}
function drawPopups(){
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  for (const p of popups) {
    const t = clamp(p.life, 0, 1);
    ctx.globalAlpha = t;
    ctx.font = '26px Bungee, cursive';
    ctx.fillStyle = 'rgba(0,0,0,.4)';
    ctx.fillText(p.text, p.x + 2, p.y + 3);
    ctx.fillStyle = p.color;
    ctx.fillText(p.text, p.x, p.y);
  }
  ctx.globalAlpha = 1;
}
function drawCrosshair(){
  if (state.mode !== 'play') return;
  const m = state.mouse;
  ctx.strokeStyle = 'rgba(255,246,230,.85)'; ctx.lineWidth = 1.6;
  ctx.beginPath(); ctx.arc(m.x, m.y, 9, 0, 6.29); ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(m.x - 14, m.y); ctx.lineTo(m.x - 5, m.y);
  ctx.moveTo(m.x + 5, m.y); ctx.lineTo(m.x + 14, m.y);
  ctx.moveTo(m.x, m.y - 14); ctx.lineTo(m.x, m.y - 5);
  ctx.moveTo(m.x, m.y + 5); ctx.lineTo(m.x, m.y + 14);
  ctx.stroke();
}
function render(){
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  if (state.shake > 0) ctx.translate(rnd(-state.shake, state.shake), rnd(-state.shake, state.shake));
  drawBackground();
  for (const b of balloons) drawBalloon(b);
  drawArcher();
  for (const a of arrows) drawArrow(a);
  drawParticles();
  drawPopups();
  drawCrosshair();
}

/* ---------- main loop ---------- */
let last = performance.now();
function frame(now){
  const dt = clamp((now - last) / 1000, 0, 0.033);
  last = now;
  update(dt);
  render();
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
updateHUD();

