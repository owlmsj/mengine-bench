"""Pixel Arena tutorial A/B decision.

Cleaning per telemetry/README.md: session_id is the unique key (ETL resends),
variant may be lowercase or have a leading space. Test: two-sided two-proportion
z-test (pooled), release rule = significant at alpha 0.05.
"""
import csv
import json
import math
from collections import defaultdict

rows = list(csv.DictReader(open("telemetry/playtest_ab.csv", newline="", encoding="utf-8")))
by_session = {}
conflicts = []
raw_count = len(rows)
for r in rows:
    sid = r["session_id"].strip()
    variant = r["variant"].strip().lower()
    completed = int(r["completed_tutorial"])
    rec = (variant, completed)
    if sid in by_session:
        if by_session[sid] != rec:
            conflicts.append((sid, by_session[sid], rec))
    else:
        by_session[sid] = rec

counts = {"a": [0, 0], "b": [0, 0]}  # variant -> [completed, sessions]
for variant, completed in by_session.values():
    counts[variant][1] += 1
    counts[variant][0] += completed

n_a, n_b = counts["a"][1], counts["b"][1]
c_a, c_b = counts["a"][0], counts["b"][0]
p_a, p_b = c_a / n_a, c_b / n_b
p_pool = (c_a + c_b) / (n_a + n_b)
se = math.sqrt(p_pool * (1 - p_pool) * (1 / n_a + 1 / n_b))
z = (p_b - p_a) / se
p_value = math.erfc(abs(z) / math.sqrt(2))  # two-sided normal

ship_b = p_value < 0.05 and p_b > p_a

result = {
    "ship_b": ship_b,
    "sessions_a": n_a,
    "sessions_b": n_b,
    "completion_rate_a": round(p_a, 4),
    "completion_rate_b": round(p_b, 4),
    "p_value": round(p_value, 4),
}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
    f.write("\n")

print(f"raw_rows={raw_count} unique_sessions={len(by_session)} duplicate_rows={raw_count - len(by_session)}")
print(f"conflicting_duplicates={len(conflicts)}")
for c in conflicts[:10]:
    print("  conflict:", c)
print(f"a: completed={c_a}/{n_a} rate={p_a:.4f}")
print(f"b: completed={c_b}/{n_b} rate={p_b:.4f}")
print(f"diff_b_minus_a={p_b - p_a:+.4f} z={z:.4f} p_value={p_value:.6f}")
print(json.dumps(result, indent=2))