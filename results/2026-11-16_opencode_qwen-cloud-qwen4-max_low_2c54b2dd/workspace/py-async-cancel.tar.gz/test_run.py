"""Smoke tests for run.run_tasks: concurrency cap and cleanup on interrupt."""

import asyncio
import signal
import sys

from run import run_tasks


async def test_concurrency_cap() -> None:
    active = 0
    peak = 0
    done = []

    def make(i: int):
        async def job():
            nonlocal active, peak
            active += 1
            peak = max(peak, active)
            await asyncio.sleep(0.02)
            active -= 1
            done.append(i)
        return job

    await run_tasks([make(i) for i in range(12)], max_concurrent=3)
    assert peak <= 3, f"peak {peak} exceeded cap"
    assert sorted(done) == list(range(12)), done
    print(f"cap ok: peak={peak}, done={len(done)}")


async def test_cleanup_on_cancel() -> None:
    started = []
    cleaned = []

    def make(i: int):
        async def job():
            started.append(i)
            try:
                await asyncio.sleep(5)
            finally:
                await asyncio.sleep(0)  # async cleanup must be awaited
                cleaned.append(i)
        return job

    runner = asyncio.create_task(run_tasks([make(i) for i in range(6)], 2))
    await asyncio.sleep(0.05)
    runner.cancel()  # same path asyncio.run takes on Ctrl+C
    try:
        await runner
    except asyncio.CancelledError:
        pass
    assert started, "no jobs started"
    assert sorted(cleaned) == sorted(started), (started, cleaned)
    print(f"cancel-cleanup ok: started={len(started)} cleaned={len(cleaned)}")


def test_cleanup_on_real_sigint() -> None:
    """Child process: real Ctrl+C signal while jobs sleep; cleanup must run."""
    code = r'''
import asyncio, signal, sys
sys.path.insert(0, %r)
from run import run_tasks

cleaned = []

def make(i):
    async def job():
        try:
            await asyncio.sleep(30)
        finally:
            cleaned.append(i)
    return job

async def main():
    loop = asyncio.get_running_loop()
    loop.call_later(0.2, lambda: signal.raise_signal(signal.SIGINT))
    await run_tasks([make(i) for i in range(4)], 2)

try:
    asyncio.run(main())
except KeyboardInterrupt:
    pass
print("SIGINT-CLEANED", sorted(cleaned))
''' % str(__import__("pathlib").Path(__file__).parent)
    import subprocess
    out = subprocess.run(
        [sys.executable, "-c", code], capture_output=True, text=True, timeout=15
    )
    assert "SIGINT-CLEANED [0, 1]" in out.stdout, (out.stdout, out.stderr)
    print("real SIGINT cleanup ok:", out.stdout.strip())


async def amain() -> None:
    await test_concurrency_cap()
    await test_cleanup_on_cancel()


if __name__ == "__main__":
    asyncio.run(amain())
    test_cleanup_on_real_sigint()
    print("ALL OK")
