"""Batch helper: run zero-argument awaitable factories with bounded concurrency.

Stdlib only, Python 3.11+. On Ctrl+C (KeyboardInterrupt) or cancellation,
already-started jobs are cancelled and their cleanup (finally / async context
managers) is awaited before the error propagates.
"""

import asyncio
from collections.abc import Awaitable, Callable, Iterable

TaskFactory = Callable[[], Awaitable[object]]


async def run_tasks(tasks: Iterable[TaskFactory], max_concurrent: int) -> None:
    """Run every task, at most ``max_concurrent`` jobs at once.

    Returns when all jobs are done. If a job raises, the remaining jobs are
    cancelled (their cleanup still runs) and the error is re-raised.
    """
    if not isinstance(max_concurrent, int) or max_concurrent < 1:
        raise ValueError(
            f"max_concurrent must be an int >= 1, got {max_concurrent!r}"
        )

    gate = asyncio.Semaphore(max_concurrent)

    async def guarded(factory: TaskFactory) -> None:
        async with gate:
            await factory()

    # TaskGroup guarantees every child task finishes (including finally
    # blocks) before __aexit__ returns, even on KeyboardInterrupt/cancel.
    async with asyncio.TaskGroup() as group:
        for factory in tasks:
            group.create_task(guarded(factory))
