# HANDOFF: local-9b Q5 @ 128k context debugging

Goal: local-9b Q5 at 128k context without VRAM spill. Measurement DONE; docs pending.

Measured via scripts/measure_decode.ps1:
- Q5, -Ctx 131072 -NPredict 1024: 37.8 t/s but 7881 MiB VRAM = WDDM ceiling with
  1494 MiB Shared Usage spill (doesn't count).
- Fix --no-mmproj-offload + -ub 512: spill gone, 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k: discarded. Q4_K_M: 7305 MiB, 40.4 t/s, fallback only.
- Recipe applied in scripts/start_server.ps1 (local9 block, ~line 165) and profiles/local/local-9b.json.

Assumption: the median-of-3 run is definitive; earlier 37.8 t/s was contaminated by spill.

Left:
1. Evals README still cites check_vision.ps1 (deleted): update it.
2. Scratchpad temp-file names flagged for review, never done.

Verify: rerun measure_decode.ps1 at 131072/1024; VRAM < 7700 MiB, no spill.