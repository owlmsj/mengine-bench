import sqlite3
c = sqlite3.connect(r'<WORKSPACE>\analytics.db')
for name, sql in c.execute("select name, sql from sqlite_master where type='table'"):
    print(name)
    print(sql)
    print('---')
    n = c.execute(f"select count(*) from {name}").fetchone()[0]
    print('rows:', n)
    for row in c.execute(f"select * from {name} limit 5"):
        print(row)
    print()