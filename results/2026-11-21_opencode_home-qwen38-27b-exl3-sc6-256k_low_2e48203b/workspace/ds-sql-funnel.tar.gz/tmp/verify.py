import sqlite3
WS = r'<WORKSPACE>'
c = sqlite3.connect(WS + r'\analytics.db')
# install: first install event
print("install per platform:")
for r in c.execute("""
select u.platform, count(*) from users u
join (select user_id, min(ts) t from events where name='install' group by user_id) e on e.user_id=u.user_id
where u.is_test=0 group by u.platform order by u.platform"""):
    print(r)
# tutorial: first tutorial_complete at/after first install
print("tutorial per platform:")
for r in c.execute("""
select u.platform, count(*) from users u
join (select user_id, min(ts) t from events where name='install' group by user_id) i on i.user_id=u.user_id
join (select user_id, min(ts) t from events where name='tutorial_complete' group by user_id) t on t.user_id=u.user_id
where u.is_test=0 and t.t >= i.t group by u.platform order by u.platform"""):
    print(r)
# first_match after tutorial
print("first_match per platform:")
for r in c.execute("""
select u.platform, count(*) from users u
join (select user_id, min(ts) t from events where name='install' group by user_id) i on i.user_id=u.user_id
join (select user_id, min(ts) t from events where name='tutorial_complete' group by user_id) t on t.user_id=u.user_id
join (select user_id, min(ts) t from events where name='first_match' group by user_id) m on m.user_id=u.user_id
where u.is_test=0 and t.t >= i.t and m.t >= t.t group by u.platform order by u.platform"""):
    print(r)
# purchase after first_match
print("purchase per platform:")
for r in c.execute("""
select u.platform, count(*) from users u
join (select user_id, min(ts) t from events where name='install' group by user_id) i on i.user_id=u.user_id
join (select user_id, min(ts) t from events where name='tutorial_complete' group by user_id) t on t.user_id=u.user_id
join (select user_id, min(ts) t from events where name='first_match' group by user_id) m on m.user_id=u.user_id
join (select user_id, min(ts) t from events where name='purchase' group by user_id) p on p.user_id=u.user_id
where u.is_test=0 and t.t >= i.t and m.t >= t.t and p.t >= m.t group by u.platform order by u.platform"""):
    print(r)
# sanity: events with unknown users
print("events from users not in users table:", c.execute("""
select count(*) from events e where not exists (select 1 from users u where u.user_id=e.user_id)""").fetchone()[0])
# event names present
print("event names:", [r[0] for r in c.execute("select distinct name from events order by name")])
# test users
print("test users:", c.execute("select count(*) from users where is_test=1").fetchone()[0])
# platforms
print("platforms:", [r[0] for r in c.execute("select distinct platform from users order by platform")])