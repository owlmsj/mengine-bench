import sqlite3, json

WS = r'<WORKSPACE>'
c = sqlite3.connect(WS + r'\analytics.db')
STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']

# distinct platforms
platforms = [r[0] for r in c.execute("select distinct platform from users order by platform")]

funnel = {}
biggest_drop = {}
for p in platforms:
    users = c.execute(
        "select user_id from users where platform=? and is_test=0", (p,)
    ).fetchall()
    counts = {s: 0 for s in STEPS}
    prev_ts = {}
    for (uid,) in users:
        # first valid occurrence per step, respecting order
        reached = None  # timestamp of previous step (None for first)
        for s in STEPS:
            if reached is None:
                row = c.execute(
                    "select min(ts) from events where user_id=? and name=?", (uid, s)
                ).fetchone()
            else:
                row = c.execute(
                    "select min(ts) from events where user_id=? and name=? and ts>=?",
                    (uid, s, reached),
                ).fetchone()
            if row and row[0] is not None:
                counts[s] += 1
                reached = row[0]
            else:
                break
    funnel[p] = counts
    # conversions: step players / previous step players
    conv = {}
    for i, s in enumerate(STEPS):
        if i == 0:
            conv[s] = None
        else:
            prev = counts[STEPS[i - 1]]
            conv[s] = (counts[s] / prev) if prev else None
    # biggest drop = step with lowest conversion (among steps with a previous step)
    cands = {s: conv[s] for s in STEPS[1:] if conv[s] is not None}
    bd = min(cands, key=lambda s: cands[s]) if cands else None
    biggest_drop[p] = bd

out = {'funnel': funnel, 'biggest_drop': biggest_drop}
with open(WS + r'\result.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))