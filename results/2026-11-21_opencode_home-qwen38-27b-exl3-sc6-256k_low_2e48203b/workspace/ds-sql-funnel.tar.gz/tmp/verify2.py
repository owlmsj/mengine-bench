import sqlite3
WS = r'<WORKSPACE>'
c = sqlite3.connect(WS + r'\analytics.db')
# Sequential: each step's time = first occurrence at/after the previous step's first valid occurrence.
# install: first install
# tutorial: first tutorial_complete with ts >= install_ts
# first_match: first first_match with ts >= tutorial_ts
# purchase: first purchase with ts >= first_match_ts
# We compute per-user step timestamps then count.
rows = c.execute("""
with inst as (select user_id, min(ts) t from events where name='install' group by user_id),
tut as (select e.user_id, min(e.ts) t from events e join inst i on i.user_id=e.user_id where e.name='tutorial_complete' and e.ts>=i.t group by e.user_id),
fm as (select e.user_id, min(e.ts) t from events e join tut t on t.user_id=e.user_id where e.name='first_match' and e.ts>=t.t group by e.user_id),
pur as (select e.user_id, min(e.ts) t from events e join fm f on f.user_id=e.user_id where e.name='purchase' and e.ts>=f.t group by e.user_id)
select u.platform,
  sum(case when i.t is not null then 1 else 0 end) installs,
  sum(case when t.t is not null then 1 else 0 end) tutorials,
  sum(case when f.t is not null then 1 else 0 end) first_matches,
  sum(case when p.t is not null then 1 else 0 end) purchases
from users u
left join inst i on i.user_id=u.user_id
left join tut t on t.user_id=u.user_id
left join fm f on f.user_id=u.user_id
left join pur p on p.user_id=u.user_id
where u.is_test=0
group by u.platform order by u.platform
""").fetchall()
for r in rows:
    print(r)