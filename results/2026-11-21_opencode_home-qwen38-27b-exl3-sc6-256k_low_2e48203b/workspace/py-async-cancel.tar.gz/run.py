"""Batch task runner helper.

Usage:
    from run import run_tasks
    await run_tasks(tasks, max_concurrent)

Each task is a zero-argument callable returning an awaitable job.
At most max_concurrent jobs run at once. Ctrl+C (KeyboardInterrupt)
still lets running jobs finish their cleanup (finally blocks).
"""

import asyncio


async def run_tasks(tasks, max_concurrent):
    """Run all jobs from tasks, at most max_concurrent concurrently.

    Returns when every job has completed (or failed). If the run is
    interrupted by Ctrl+C, jobs already started are allowed to run
    their cleanup code (finally blocks) before the exception propagates.
    """
    sem = asyncio.Semaphore(max_concurrent)

    async def guarded(task):
        async with sem:
            await task()

    await asyncio.gather(*(guarded(t) for t in tasks))


if __name__ == "__main__":
    # Self-test: verify concurrency cap and cleanup on cancellation.
    state = {"running": 0, "peak": 0, "cleaned": []}

    async def job(i):
        state["running"] += 1
        state["peak"] = max(state["peak"], state["running"])
        try:
            await asyncio.sleep(0.05)
        finally:
            state["cleaned"].append(i)
            state["running"] -= 1

    async def main():
        tasks = [lambda i=i: job(i) for i in range(10)]
        await run_tasks(tasks, 3)
        assert state["peak"] <= 3, f"peak {state['peak']} exceeded cap 3"
        assert len(state["cleaned"]) == 10
        print(f"OK: peak={state['peak']}, cleaned={len(state['cleaned'])}")

    asyncio.run(main())