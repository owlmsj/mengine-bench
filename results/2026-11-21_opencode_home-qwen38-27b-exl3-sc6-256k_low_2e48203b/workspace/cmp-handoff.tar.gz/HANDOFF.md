# HANDOFF — local-9b @ 128k

Goal: local-9b Q5 at 128k context, no VRAM spill.

## Done (measured)
- Baseline: 37.8 t/s, VRAM 7881 MiB (measure_decode.ps1 -Ctx 131072 -NPredict 1024).
- 7881 MiB = WDDM ceiling; Shared Usage showed 1494 MiB spilled — unreliable counter.
- Fix: `--no-mmproj-offload -ub 512` → spill gone, 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) doesn't fit at 128k — discarded. Q4_K_M fits (7305 MiB, 40.4 t/s) — fallback only.
- Recipe applied: scripts/start_server.ps1:165 (local9 block) + profiles/local/local-9b.json.

## Left
1. Review scratchpad temp file names (noted repeatedly, never done).
2. evals README cites check_vision.ps1 — file no longer exists; update it.

## Assumptions
- "local-9b Q5" = Q5_K_M in profiles/local/local-9b.json; 128k = 131072 tokens; measure_decode.ps1 is source of truth.

## How I know
Numbers from measure_decode.ps1 (median of 3) after the flag change; VRAM from the same run, not the WDDM ceiling or Shared Usage counter.