//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    state: Arc<Mutex<BoardState>>,
}

#[derive(Default)]
struct BoardState {
    players: HashMap<PlayerId, i64>,
    total: i64,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        let mut s = self.state.lock().unwrap();
        s.players.insert(id, score);
        s.total += score;
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let mut s = self.state.lock().unwrap();
        *s.players.get_mut(&id).expect("player not joined") += points;
        s.total += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let mut s = self.state.lock().unwrap();
        *s.players.get_mut(&from).expect("player not joined") -= points;
        *s.players.get_mut(&to).expect("player not joined") += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.state.lock().unwrap().players.get(&id).expect("player not joined")
    }

    pub fn total(&self) -> i64 {
        self.state.lock().unwrap().total
    }
}