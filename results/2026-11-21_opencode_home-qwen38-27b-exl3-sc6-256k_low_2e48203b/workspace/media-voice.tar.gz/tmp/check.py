import sys
print(sys.version)
mods = ["pyttsx3", "gtts", "edge_tts", "speech", "pydub", "numpy", "wave", "sapi"]
for m in mods:
    try:
        __import__(m)
        print("OK", m)
    except Exception as e:
        print("NO", m, type(e).__name__)