Add-Type -AssemblyName System.Speech
$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
$text = "Welcome aboard the evening ferry, please keep your bags clear of the doors."
$out = "<WORKSPACE>\announcement.wav"
$synth.SetOutputToWaveFile($out)
$synth.Speak($text)
$synth.Dispose()
Write-Host "done"