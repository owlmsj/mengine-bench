import wave
w = wave.open(r"<WORKSPACE>\announcement.wav")
n = w.getnframes()
fr = w.getframerate()
print("channels", w.getnchannels(), "rate", fr, "frames", n, "duration_s", round(n/fr, 2))