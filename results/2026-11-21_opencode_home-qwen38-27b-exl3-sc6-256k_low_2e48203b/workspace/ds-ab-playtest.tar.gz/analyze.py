import csv, json, math
from collections import Counter

rows = []
with open(r"telemetry/playtest_ab.csv", newline="", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        rows.append(r)

print("total data rows:", len(rows))

# Dedupe by session_id (ETL resends; keep first occurrence)
seen = {}
for r in rows:
    sid = r["session_id"].strip()
    if sid not in seen:
        seen[sid] = r
sessions = list(seen.values())
print("unique sessions:", len(sessions))

# Normalize variant: strip + lower
def norm(v):
    return v.strip().lower()

counts = Counter(norm(r["variant"]) for r in sessions)
print("variant counts:", dict(counts))

a = [r for r in sessions if norm(r["variant"]) == "a"]
b = [r for r in sessions if norm(r["variant"]) == "b"]
print("sessions_a:", len(a), "sessions_b:", len(b))

comp_a = sum(int(r["completed_tutorial"]) for r in a)
comp_b = sum(int(r["completed_tutorial"]) for r in b)
rate_a = comp_a / len(a)
rate_b = comp_b / len(b)
print("completed_a:", comp_a, "completed_b:", comp_b)
print("rate_a: %.6f" % rate_a, "rate_b: %.6f" % rate_b)

# Two-proportion z-test, two-sided, H0: p_a = p_b
n1, n2 = len(a), len(b)
p_pool = (comp_a + comp_b) / (n1 + n2)
se = math.sqrt(p_pool * (1 - p_pool) * (1/n1 + 1/n2))
z = (rate_b - rate_a) / se
# two-sided p-value
p_value = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))
print("pooled p: %.6f" % p_pool, "se: %.6f" % se, "z: %.4f" % z)
print("p_value: %.6f" % p_value)

# Also: does B beat A significantly?
ships = p_value < 0.05 and rate_b > rate_a
print("ship_b:", ships)

out = {
    "ship_b": bool(ships),
    "sessions_a": n1,
    "sessions_b": n2,
    "completion_rate_a": round(rate_a, 6),
    "completion_rate_b": round(rate_b, 6),
    "p_value": round(p_value, 6),
}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))