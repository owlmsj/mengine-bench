import json, os, re, html, urllib.parse

base = r"<WORKSPACE>"
site = os.path.join(base, "site")

def norm(s): return s.strip().lower()

words = {}
pages = {}
for fn in os.listdir(site):
    if not fn.endswith(".html"): continue
    raw = open(os.path.join(site, fn), encoding="utf-8").read()
    m = re.search(r"<title>(.*?)\s*\|\s*Dicion", raw)
    word = html.unescape(m.group(1)).strip() if m else None
    if word is None: continue
    pages[fn] = word
    if word == "Início": continue
    links = set()
    for sid in ("sinonimos", "analogas"):
        sm = re.search(r'<section id="%s">(.*?)</section>' % sid, raw, re.S)
        if sm:
            for am in re.finditer(r'<a href="([^"]+)">([^<]+)</a>', sm.group(1)):
                href = html.unescape(urllib.parse.unquote(am.group(1)))
                target = os.path.splitext(href)[0]
                links.add(target)
    words[word] = links

file_to_word = {fn: w for fn, w in pages.items()}
out = {}
for w, links in words.items():
    rels = set()
    for t in links:
        if t in file_to_word:
            rels.add(file_to_word[t])
        else:
            rels.add(t)  # keep even if target page missing
    out[w] = sorted(rels)

json.dump(out, open(os.path.join(base, "words.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
pairs = set()
for w, rels in out.items():
    for r in rels:
        pairs.add(tuple(sorted([w, r])))
deg = {w: len(r) for w, r in out.items()}
most = sorted(deg.items(), key=lambda kv: (-kv[1], kv[0]))[0]
print("words:", len(out), "pairs:", len(pairs), "most:", most)
print("saudade:", out["saudade"])