import re
t = open(r"universe/index.html", encoding="utf-8").read()
m = re.search(r'<script type="module">(.*?)</script>', t, re.S)
open(r"tmp_module.mjs", "w", encoding="utf-8").write(m.group(1))
print("len", len(m.group(1)))