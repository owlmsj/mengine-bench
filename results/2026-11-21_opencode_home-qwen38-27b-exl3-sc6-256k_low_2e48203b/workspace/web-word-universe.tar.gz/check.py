import json
w = json.load(open("words.json", encoding="utf-8"))
print("saudade:", w["saudade"])
t = open("universe/index.html", encoding="utf-8").read()
i = t.find('"saudade"')
print("in html:", t[i:i+110])
print("632 in html:", "632" in t)
print("1113 in html:", "1113" in t)