import json, re, os, html, urllib.parse

base = r"<WORKSPACE>"
site = os.path.join(base, "site")
words = json.load(open(os.path.join(base, "words.json"), encoding="utf-8"))

# collect themes
themes = {}
for fn in os.listdir(site):
    if not fn.endswith(".html"): continue
    raw = open(os.path.join(site, fn), encoding="utf-8").read()
    m = re.search(r"<title>(.*?)\s*\|\s*Dicion", raw)
    if not m: continue
    w = html.unescape(m.group(1)).strip()
    if w == "Início": continue
    tm = re.search(r'class="tema">Tema:\s*(.*?)</p>', raw)
    if tm: themes[w] = tm.group(1).strip()

tpl = open(os.path.join(base, "universe", "index.html"), encoding="utf-8").read()
tpl = tpl.replace("/*__DATA__*/null", json.dumps(words, ensure_ascii=False))
tpl = tpl.replace("const THEMES = ", "const THEMES = ", 0)  # noop
# inject THEMES const before the scene section
tpl = tpl.replace("// ---- scene", "const THEMES = " + json.dumps(themes, ensure_ascii=False) + ";\n// ---- scene")
open(os.path.join(base, "universe", "index.html"), "w", encoding="utf-8").write(tpl)
print("themes:", len(themes))
print("ok")