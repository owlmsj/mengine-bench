
import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js";

const WORDS = {"acento": ["prazer", "sotaque"], "açougueiro": ["boca", "padeiro", "pescador", "tarde"], "açúcar": ["mel", "pimenta", "tempo", "unha"], "advogado": ["cachoeira", "eternidade", "palavra", "professor"], "afeto": ["amor", "voz"], "aflição": ["ansiedade", "escultura", "felicidade", "pavor"], "água": ["comida", "ombro", "professor", "vinho"], "aldeia": ["bairro", "capital", "trabalho"], "alegria": ["felicidade", "queijo", "surpresa", "ternura"], "alfaiate": ["boca", "emprego", "padeiro", "sapateiro"], "alma": ["amor", "corpo"], "almoço": ["frase", "jantar", "patrão", "pimenta"], "amanhã": ["eternidade", "hoje", "porta"], "amor": ["afeto", "alma", "tristeza"], "angústia": ["afeto", "dor", "medo", "riacho"], "ano": ["mês"], "ansiedade": ["medo", "rua"], "apelido": ["acento", "letra"], "areia": ["montanha", "natureza", "praia", "rima"], "arroz": [], "arte": ["cachoeira", "fotografia", "samba"], "árvore": ["amor", "mandioca", "mata", "raiz", "selva", "serra"], "ator": ["poesia", "primo"], "aurora": ["instante", "prazer", "professor"], "avenida": ["casa", "rua"], "avó": ["avô", "genro"], "avô": ["avó", "pais"], "bairro": ["aldeia", "igreja", "porta", "rua"], "boca": ["livro", "língua", "olho", "ombro", "rosto"], "braço": ["janela", "língua", "mão", "ombro", "surpresa"], "cabeça": ["corpo", "enfermeira", "mão", "rosto"], "cachoeira": ["advogado", "lago", "linguagem", "riacho", "semente"], "café": ["momento", "pimenta", "trabalho"], "campo": ["milho", "onda", "ponte", "prado", "selva"], "canção": ["ator", "melodia", "pai", "tela"], "capital": ["aldeia", "cidade", "estação", "riacho", "tempo", "voz"], "carinho": ["afeto", "melancolia", "ternura"], "carne": ["arroz", "filho", "mandioca", "ovo", "peixe"], "carpinteiro": ["ferreiro", "patrão", "pedreiro", "trabalho"], "casa": ["avenida", "escola", "igreja", "lar", "poesia"], "cena": ["ator", "livro", "melodia", "ponte", "teatro"], "chá": ["peixe", "queijo", "vinho"], "cidade": ["capital", "estado", "estação"], "cinema": ["escultura", "fotografia", "tela"], "comida": ["farinha", "peito"], "compaixão": ["ovo", "ternura"], "Contato": [], "contentamento": ["felicidade", "pais", "prazer"], "conto": ["lar", "livro", "palavra", "verso"], "conversa": ["felicidade", "grito"], "coração": ["advogado", "avô", "jantar", "joelho", "peito", "pulmão", "rosto"], "corpo": ["alma", "peixe"], "cozinha": ["capital", "janela", "pai", "voz"], "crepúsculo": ["ano", "aurora", "cunhado", "hoje", "ontem", "segundo"], "cunhado": ["pais", "sobrinho", "sogra"], "dança": ["piano", "rima", "tambor", "teatro", "voz"], "dedo": ["mão", "sapateiro", "unha"], "dente": ["hoje", "língua", "pulmão"], "desenho": ["escultura", "noite", "tela"], "dia": ["casa", "letra", "tarde"], "dicionário": ["arte", "significado", "voz"], "dor": [], "emprego": ["eternidade", "jantar"], "enfermeira": ["professor"], "engenheiro": ["lavrador", "marinheiro", "ternura", "trabalho"], "época": ["enfermeira", "era", "leite", "momento"], "era": ["mês", "palavra", "teatro"], "escola": ["casa", "esquina", "igreja"], "escultura": ["cinema", "olho", "sobrinho"], "espanto": ["país", "surpresa"], "esperança": ["emprego", "escola", "espanto"], "esquina": ["cozinha", "escola", "pescador", "ponte"], "estado": ["cidade", "mão", "poesia"], "estação": ["capital", "cidade", "porto", "tia"], "estômago": ["língua", "pulmão"], "eternidade": ["advogado", "emprego", "instante", "passado", "peixe"], "fala": ["acento", "advogado", "conversa", "voz"], "família": [], "farinha": ["pescador", "vinho"], "feijão": ["arroz", "avenida", "mandioca", "milho", "palavra", "vinho"], "felicidade": ["alegria", "conversa"], "ferreiro": ["carpinteiro", "onda", "sapateiro", "segundo"], "fígado": ["alma", "cozinha", "futuro", "pele"], "filha": ["filho", "primo", "tia"], "filho": ["genro", "pai"], "flor": ["samba", "semente"], "floresta": ["mata", "medo", "natureza", "tempo"], "folha": ["conto", "flor", "raiz", "semente", "tio"], "fotografia": ["arte", "cinema", "rima", "soldado", "teatro"], "frase": ["letra", "linguagem", "sentido", "sussurro", "tristeza"], "fruto": ["natureza", "piano", "semente"], "futuro": ["minuto", "passado", "tempo"], "genro": ["avó", "madrinha", "sogra"], "gíria": ["alma", "frase", "sotaque"], "grito": ["conversa", "sobrinho", "sussurro"], "herança": ["conto", "família", "madrinha", "marinheiro", "neta", "pimenta", "tio"], "história": ["apelido", "comida", "resposta", "surpresa", "tempo"], "hoje": ["ontem", "tristeza"], "hora": ["advogado", "minuto", "tempo"], "idioma": ["apelido", "linguagem", "madrinha", "palavra"], "igreja": ["bairro", "escola"], "instante": ["aurora", "eternidade", "momento", "segundo"], "irmã": ["apelido", "avô", "pintura", "sal", "tia"], "irmão": ["engenheiro", "pais", "ponte", "tia"], "janela": ["cozinha", "igreja", "porta"], "jantar": ["emprego", "mel"], "jardim": ["campo", "escultura", "fruto", "montanha", "praia"], "joelho": ["pedreiro", "tambor"], "juiz": ["advogado", "engenheiro", "mão", "patrão", "porto", "soldado"], "lago": ["acento", "cachoeira", "natureza"], "lar": ["casa", "conto", "ponte", "rua"], "lavrador": ["engenheiro", "padeiro", "pescador", "selva"], "leite": ["mandioca", "pele", "queijo"], "letra": ["apelido", "dia", "significado"], "linguagem": ["cachoeira", "frase", "grito", "riacho"], "livro": ["boca", "conto", "pintura"], "língua": ["boca", "osso", "tarde"], "madrinha": ["genro", "neta", "padrinho"], "madrugada": ["arroz", "aurora", "eternidade", "noite", "passado"], "mãe": ["avó", "pai", "pais"], "mágoa": ["dor", "melancolia", "tristeza"], "mandioca": ["leite", "milho", "pimenta", "sentido"], "manhã": ["ano", "dia", "tarde"], "manteiga": ["ansiedade", "leite", "milho", "queijo"], "mar": ["flor", "lago", "medo", "onda"], "marinheiro": ["advogado", "engenheiro", "pedreiro", "soldado"], "mata": ["fruto", "selva"], "médico": ["enfermeira", "estado", "marinheiro"], "medo": ["ansiedade", "pavor", "ternura"], "mel": ["jantar", "melancolia", "pimenta", "sal"], "melancolia": ["tristeza"], "melodia": ["piano", "ritmo", "verso"], "memória": ["alma", "palavra"], "mercado": ["emprego", "estação", "igreja", "mata", "porta"], "milho": ["campo", "mandioca", "tela"], "minuto": ["futuro", "noite", "segundo", "tambor"], "momento": ["instante", "noite"], "montanha": ["areia", "lavrador", "prado", "serra"], "música": ["ano", "arte", "pintura", "samba", "verso"], "mão": ["estado", "pele"], "mês": ["ano", "era", "ferreiro", "momento"], "nação": ["instante", "país", "rua"], "natureza": ["areia", "raiz"], "neta": ["arroz", "madrinha", "pais", "tio"], "neto": ["avó", "filho", "neta"], "noite": ["minuto", "momento", "tarde"], "nome": ["apelido", "ritmo", "sussurro", "voz"], "nora": ["família", "genro", "padrinho", "patrão", "peixe"], "nostalgia": ["melancolia"], "ofício": ["areia", "lavrador", "livro", "padeiro", "trabalho"], "olho": ["boca", "escultura", "pulmão", "rosto"], "ombro": ["boca"], "onda": ["campo", "ferreiro", "prado", "praia", "riacho", "tempo"], "ontem": ["hoje", "pavor"], "operário": ["igreja", "lavrador", "passado", "patrão", "pedreiro", "soldado"], "osso": ["farinha", "língua", "pele", "sangue"], "ovo": ["palavra", "peixe", "queijo"], "padeiro": ["capital", "lavrador"], "padrinho": ["madrinha", "sotaque", "tio"], "pai": ["avó", "cozinha", "filho"], "pais": ["neta", "pavor", "tia"], "paixão": ["amor", "ansiedade", "conto", "prazer", "unha"], "palavra": ["advogado", "alma", "conto", "era", "montanha", "ovo", "patrão", "pintura", "professor", "tia"], "pão": ["farinha", "jantar", "leite", "verso"], "parentesco": ["família", "pais"], "passado": ["eternidade", "futuro"], "pastor": ["ferreiro", "lavrador", "mel"], "pátria": ["alma", "estado", "porto", "tempo"], "patrão": ["carpinteiro", "palavra"], "pavor": ["medo", "melancolia", "ontem", "pais", "ritmo"], "país": ["cidade", "espanto", "porta"], "pé": ["alma", "joelho", "rosto", "tela"], "pedreiro": ["carpinteiro", "joelho", "marinheiro", "osso"], "peito": ["comida", "pulmão", "unha"], "peixe": ["eternidade", "ovo"], "pele": ["leite", "mão", "osso", "pulmão"], "pergunta": ["acento", "grito", "olho", "resposta"], "perna": ["joelho", "sangue"], "pescador": ["lavrador", "pedreiro", "verso"], "pescoço": ["avô", "corpo", "ombro", "sangue"], "pétala": ["cachoeira", "flor", "semente"], "piano": ["fruto", "melodia", "prado", "sobrinho", "tambor"], "pimenta": ["mandioca", "mel", "sal"], "pintura": ["janela", "livro", "palavra", "tela"], "poesia": ["ator", "casa", "estado", "verso"], "ponte": ["campo", "esquina", "lar", "porto"], "porta": ["bairro", "janela", "país"], "porto": ["estação", "ponte"], "praça": ["avenida", "esquina", "lar", "ternura"], "prado": ["campo", "montanha", "onda", "piano"], "praia": ["areia", "onda", "pescador", "rio"], "prazer": ["acento", "aurora", "ternura"], "prima": ["cidade", "primo", "sobrinho"], "primo": ["ator", "professor", "sobrinho", "tia"], "professor": ["advogado", "enfermeira", "palavra", "primo", "sapateiro"], "profissão": ["emprego", "janela", "serra"], "pulmão": ["avô", "olho", "peito", "pele", "unha"], "quarto": ["avenida", "cozinha", "lar", "neta"], "queijo": ["alegria", "leite", "ovo", "poesia"], "raiz": ["natureza", "serra"], "refeição": ["bairro", "comida", "fotografia", "milho"], "resposta": ["letra"], "riacho": ["cachoeira", "capital", "linguagem", "onda", "rio"], "rima": ["areia", "fotografia", "significado", "verso"], "rio": ["pedreiro", "praia", "riacho"], "ritmo": ["melodia", "pavor", "samba", "teatro"], "romance": ["arte", "conto", "natureza", "rima", "sotaque", "teatro"], "rosto": ["boca", "olho"], "rua": ["avenida", "bairro", "lar"], "sal": ["mel", "pimenta"], "salário": ["emprego", "patrão", "professor"], "samba": ["arte", "flor", "ritmo"], "sangue": ["osso", "sentido"], "sapateiro": ["ferreiro", "professor"], "saudade": ["ansiedade", "dor"], "século": ["ano", "era", "minuto"], "segundo": ["ferreiro", "instante", "minuto"], "selva": ["campo", "igreja", "mata"], "semana": ["avô", "dia", "futuro", "mês"], "semente": ["cachoeira", "flor", "fruto"], "sentido": ["frase", "mandioca", "sangue", "significado", "trabalho"], "serra": ["montanha"], "significado": ["letra", "rima", "sentido"], "sílaba": ["acento", "frase", "letra"], "silêncio": ["conversa", "grito", "sussurro"], "sinônimo": ["mês"], "Sobre": [], "sobrinho": ["cunhado", "grito", "piano", "primo", "sotaque"], "sogra": ["cunhado", "genro", "tempo", "tia"], "soldado": ["fotografia", "marinheiro"], "sotaque": ["acento", "sobrinho", "vinho", "voz"], "surpresa": ["alegria", "espanto"], "sussurro": ["frase", "grito"], "susto": ["amor", "espanto", "estação", "pavor", "tempo"], "tambor": ["joelho", "minuto", "piano", "verso"], "tarde": ["dia", "língua", "noite"], "teatro": ["era", "fotografia", "pai", "ritmo", "tempo"], "tela": ["cinema", "milho", "pintura"], "tempo": ["capital", "futuro", "onda", "pescador", "prado", "rua", "sogra", "teatro", "tio"], "ternura": ["alegria", "engenheiro", "medo"], "tia": ["estação", "pais", "primo", "sogra", "tio"], "tio": ["neta", "tempo", "tia"], "trabalho": ["aldeia", "carpinteiro", "engenheiro", "sentido"], "trigo": ["arroz", "farinha", "milho", "unha"], "tristeza": ["amor", "frase", "hoje", "melancolia"], "unha": ["peito", "pulmão"], "vale": ["ponte", "raiz", "rio", "serra"], "verso": ["melodia", "pescador", "poesia", "rima", "tambor"], "vila": ["aldeia", "capital", "carpinteiro", "porto"], "vinho": ["farinha", "sotaque"], "violão": ["enfermeira", "escultura", "país", "piano", "poesia", "rima", "samba"], "voz": ["afeto", "capital", "cozinha", "sotaque"]};
const words = Object.keys(WORDS);
const adj = {}; // word -> {target: kind}
for (const w of words){
  adj[w] = {};
  for (const r of WORDS[w]) adj[w][r] = WORDS[r].includes(w) ? "mut" : "out";
}

const THEMES = {"acento": "linguagem", "açougueiro": "ofícios", "açúcar": "comida", "advogado": "ofícios", "afeto": "sentimentos", "aflição": "sentimentos", "água": "comida", "aldeia": "lugares", "alegria": "sentimentos", "alfaiate": "ofícios", "alma": "corpo", "almoço": "comida", "amanhã": "tempo", "amor": "sentimentos", "angústia": "sentimentos", "ano": "tempo", "ansiedade": "sentimentos", "apelido": "linguagem", "areia": "natureza", "arroz": "comida", "arte": "artes", "árvore": "natureza", "ator": "artes", "aurora": "tempo", "avenida": "lugares", "avó": "família", "avô": "família", "bairro": "lugares", "boca": "corpo", "braço": "corpo", "cabeça": "corpo", "cachoeira": "natureza", "café": "comida", "campo": "natureza", "canção": "artes", "capital": "lugares", "carinho": "sentimentos", "carne": "comida", "carpinteiro": "ofícios", "casa": "lugares", "cena": "artes", "chá": "comida", "cidade": "lugares", "cinema": "artes", "comida": "comida", "compaixão": "sentimentos", "contentamento": "sentimentos", "conto": "artes", "conversa": "linguagem", "coração": "corpo", "corpo": "corpo", "cozinha": "lugares", "crepúsculo": "tempo", "cunhado": "família", "dança": "artes", "dedo": "corpo", "dente": "corpo", "desenho": "artes", "dia": "tempo", "dicionário": "linguagem", "dor": "sentimentos", "emprego": "ofícios", "enfermeira": "ofícios", "engenheiro": "ofícios", "época": "tempo", "era": "tempo", "escola": "lugares", "escultura": "artes", "espanto": "sentimentos", "esperança": "sentimentos", "esquina": "lugares", "estado": "lugares", "estação": "lugares", "estômago": "corpo", "eternidade": "tempo", "fala": "linguagem", "família": "família", "farinha": "comida", "feijão": "comida", "felicidade": "sentimentos", "ferreiro": "ofícios", "fígado": "corpo", "filha": "família", "filho": "família", "flor": "natureza", "floresta": "natureza", "folha": "natureza", "fotografia": "artes", "frase": "linguagem", "fruto": "natureza", "futuro": "tempo", "genro": "família", "gíria": "linguagem", "grito": "linguagem", "herança": "família", "história": "linguagem", "hoje": "tempo", "hora": "tempo", "idioma": "linguagem", "igreja": "lugares", "instante": "tempo", "irmã": "família", "irmão": "família", "janela": "lugares", "jantar": "comida", "jardim": "natureza", "joelho": "corpo", "juiz": "ofícios", "lago": "natureza", "lar": "lugares", "lavrador": "ofícios", "leite": "comida", "letra": "linguagem", "linguagem": "linguagem", "livro": "artes", "língua": "corpo", "madrinha": "família", "madrugada": "tempo", "mãe": "família", "mágoa": "sentimentos", "mandioca": "comida", "manhã": "tempo", "manteiga": "comida", "mar": "natureza", "marinheiro": "ofícios", "mata": "natureza", "médico": "ofícios", "medo": "sentimentos", "mel": "comida", "melancolia": "sentimentos", "melodia": "artes", "memória": "linguagem", "mercado": "lugares", "milho": "comida", "minuto": "tempo", "momento": "tempo", "montanha": "natureza", "música": "artes", "mão": "corpo", "mês": "tempo", "nação": "lugares", "natureza": "natureza", "neta": "família", "neto": "família", "noite": "tempo", "nome": "linguagem", "nora": "família", "nostalgia": "sentimentos", "ofício": "ofícios", "olho": "corpo", "ombro": "corpo", "onda": "natureza", "ontem": "tempo", "operário": "ofícios", "osso": "corpo", "ovo": "comida", "padeiro": "ofícios", "padrinho": "família", "pai": "família", "pais": "família", "paixão": "sentimentos", "palavra": "linguagem", "pão": "comida", "parentesco": "família", "passado": "tempo", "pastor": "ofícios", "pátria": "lugares", "patrão": "ofícios", "pavor": "sentimentos", "país": "lugares", "pé": "corpo", "pedreiro": "ofícios", "peito": "corpo", "peixe": "comida", "pele": "corpo", "pergunta": "linguagem", "perna": "corpo", "pescador": "ofícios", "pescoço": "corpo", "pétala": "natureza", "piano": "artes", "pimenta": "comida", "pintura": "artes", "poesia": "artes", "ponte": "lugares", "porta": "lugares", "porto": "lugares", "praça": "lugares", "prado": "natureza", "praia": "natureza", "prazer": "sentimentos", "prima": "família", "primo": "família", "professor": "ofícios", "profissão": "ofícios", "pulmão": "corpo", "quarto": "lugares", "queijo": "comida", "raiz": "natureza", "refeição": "comida", "resposta": "linguagem", "riacho": "natureza", "rima": "artes", "rio": "natureza", "ritmo": "artes", "romance": "artes", "rosto": "corpo", "rua": "lugares", "sal": "comida", "salário": "ofícios", "samba": "artes", "sangue": "corpo", "sapateiro": "ofícios", "saudade": "sentimentos", "século": "tempo", "segundo": "tempo", "selva": "natureza", "semana": "tempo", "semente": "natureza", "sentido": "linguagem", "serra": "natureza", "significado": "linguagem", "sílaba": "linguagem", "silêncio": "linguagem", "sinônimo": "linguagem", "sobrinho": "família", "sogra": "família", "soldado": "ofícios", "sotaque": "linguagem", "surpresa": "sentimentos", "sussurro": "linguagem", "susto": "sentimentos", "tambor": "artes", "tarde": "tempo", "teatro": "artes", "tela": "artes", "tempo": "tempo", "ternura": "sentimentos", "tia": "família", "tio": "família", "trabalho": "ofícios", "trigo": "comida", "tristeza": "sentimentos", "unha": "corpo", "vale": "natureza", "verso": "artes", "vila": "lugares", "vinho": "comida", "violão": "artes", "voz": "linguagem"};
// ---- scene
const app = document.getElementById("app");
const scene = new THREE.Scene();
scene.fog = new THREE.FogExp2(0x0e0d12, 0.0016);
const camera = new THREE.PerspectiveCamera(55, innerWidth/innerHeight, 0.1, 5000);
camera.position.set(0, 40, 320);
const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
app.appendChild(renderer.domElement);

scene.add(new THREE.AmbientLight(0xffffff, .9));
const dl = new THREE.DirectionalLight(0xffffff, 1.2); dl.position.set(120, 200, 160); scene.add(dl);

// ---- layout: deterministic 3D positions via hash-based sphere + jitter
function hash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0)/4294967295;}
const pos = {};
words.forEach((w,i)=>{
  const u = hash(w), v = hash(w+"x"), th = u*Math.PI*2, ph = Math.acos(2*v-1);
  const R = 120 + hash(w+"r")*60;
  pos[w] = new THREE.Vector3(R*Math.sin(ph)*Math.cos(th), R*Math.cos(ph)*0.7, R*Math.sin(ph)*Math.sin(th));
});

// ---- nodes
const nodeGeo = new THREE.SphereGeometry(1, 12, 12);
const nodeMat = new THREE.MeshStandardMaterial({color:0xf2efe9, roughness:.6, metalness:.1});
const nodes = {};
const deg = {};
for (const w of words){ deg[w] = WORDS[w].length; }
const maxDeg = Math.max(...Object.values(deg));
for (const w of words){
  const m = nodeMat.clone();
  const mesh = new THREE.Mesh(nodeGeo, m);
  const s = 1.6 + (deg[w]/maxDeg)*4.2;
  mesh.scale.setScalar(s);
  mesh.position.copy(pos[w]);
  mesh.userData.word = w;
  scene.add(mesh);
  nodes[w] = mesh;
}

// ---- labels (sprites)
function makeLabel(text, size=48){
  const c = document.createElement("canvas");
  const ctx = c.getContext("2d");
  const fs = size;
  ctx.font = `600 ${fs}px Inter, sans-serif`;
  const tw = ctx.measureText(text).width;
  c.width = Math.ceil(tw)+24; c.height = fs+24;
  const g = c.getContext("2d");
  g.font = `600 ${fs}px Inter, sans-serif`;
  g.fillStyle = "#f2efe9"; g.textBaseline = "middle"; g.textAlign = "center";
  g.fillText(text, c.width/2, c.height/2);
  const tex = new THREE.CanvasTexture(c);
  tex.anisotropy = 4;
  const mat = new THREE.SpriteMaterial({map:tex, transparent:true, depthWrite:false});
  const sp = new THREE.Sprite(mat);
  const scale = c.width/c.height;
  sp.scale.set(scale*10, 10, 1);
  return sp;
}
const labels = {};
for (const w of words){
  const sp = makeLabel(w, 40);
  sp.position.copy(pos[w]).add(new THREE.Vector3(0, 6 + (deg[w]/maxDeg)*3, 0));
  sp.material.opacity = 0.85;
  scene.add(sp);
  labels[w] = sp;
}

// ---- edges
const edgeMat = new THREE.LineBasicMaterial({color:0x4a4558, transparent:true, opacity:0.28});
const edgeGroup = new THREE.Group(); scene.add(edgeGroup);
const edges = [];
const seen = new Set();
for (const w of words){
  for (const r of WORDS[w]){
    const key = [w,r].sort().join("|");
    if (seen.has(key)) continue; seen.add(key);
    const g = new THREE.BufferGeometry().setFromPoints([pos[w], pos[r]]);
    const line = new THREE.Line(g, edgeMat.clone());
    edgeGroup.add(line);
    edges.push({a:w, b:r, line});
  }
}

// ---- interaction
const ray = new THREE.Raycaster();
const mouse = new THREE.Vector2();
let selected = null;
function setWord(w, push=true){
  selected = w;
  const p = document.getElementById("panel");
  if (!w){ p.hidden = true; }
  else {
    const d = WORDS[w];
    const syn = d.filter(x => (adj[w][x]||"") === "mut" || true); // show all relations, mark kind
    const kinds = {};
    for (const r of d) kinds[r] = adj[w][r];
    let html = `<p class="word">${w}</p>`;
    const theme = (typeof THEMES!=="undefined") ? THEMES[w] : null;
    if (theme) html += `<div class="theme">tema: ${theme}</div>`;
    html += `<h3>${d.length} relações</h3><div class="chips">`;
    for (const r of d){
      const k = kinds[r] === "mut" ? "syn" : "an";
      html += `<span class="chip ${k}" data-w="${r}">${r}</span>`;
    }
    html += `</div>`;
    p.innerHTML = html;
    p.hidden = false;
    p.querySelectorAll(".chip").forEach(c => c.onclick = () => setWord(c.dataset.w));
  }
  // highlight
  const nb = new Set(w ? WORDS[w] : []);
  if (w) nb.add(w);
  for (const x of words){
    const on = !w || nb.has(x);
    nodes[x].material.color.set(on ? (x===w?0xe8b464:0xf2efe9) : 0x3a3644);
    nodes[x].material.emissive = nodes[x].material.emissive || new THREE.Color(0);
    nodes[x].material.emissive.set(x===w ? 0x553300 : 0x000000);
    labels[x].material.opacity = on ? 0.95 : 0.12;
  }
  for (const e of edges){
    const on = w && (e.a===w || e.b===w);
    e.line.material.opacity = on ? 0.9 : (w ? 0.06 : 0.28);
    e.line.material.color.set(on ? 0xe8b464 : 0x4a4558);
  }
  if (push && w) history.replaceState(null, "", "?word="+encodeURIComponent(w));
  if (!w) history.replaceState(null, "", location.pathname);
}

// ---- search
const q = document.getElementById("q");
const sugg = document.getElementById("sugg");
const norm = s => s.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase();
q.addEventListener("input", () => {
  const v = norm(q.value.trim());
  if (!v){ sugg.style.display="none"; return; }
  const hits = words.filter(w => norm(w).startsWith(v) || norm(w).includes(v)).slice(0, 12);
  if (!hits.length){ sugg.style.display="none"; return; }
  sugg.innerHTML = hits.map(w => `<li data-w="${w}"><b>${w}</b></li>`).join("");
  sugg.style.display = "block";
  sugg.querySelectorAll("li").forEach(li => li.onclick = () => { setWord(li.dataset.w); q.value=li.dataset.w; sugg.style.display="none"; });
});
q.addEventListener("keydown", e => {
  if (e.key === "Enter"){
    const v = norm(q.value.trim());
    const hit = words.find(w => norm(w) === v) || words.find(w => norm(w).startsWith(v));
    if (hit) setWord(hit);
  }
  if (e.key === "Escape"){ sugg.style.display="none"; }
});

// ---- click / drag
let down = null, moved = false;
renderer.domElement.addEventListener("pointerdown", e => { down = {x:e.clientX, y:e.clientY}; moved = false; });
renderer.domElement.addEventListener("pointermove", e => {
  if (down && (Math.abs(e.clientX-down.x)>4 || Math.abs(e.clientY-down.y)>4)) moved = true;
});
renderer.domElement.addEventListener("pointerup", e => {
  if (moved){ down = null; return; }
  mouse.x = (e.clientX/innerWidth)*2-1; mouse.y = -(e.clientY/innerHeight)*2+1;
  ray.setFromCamera(mouse, camera);
  const meshes = Object.values(nodes);
  const hits = ray.intersectObjects(meshes);
  if (hits.length) setWord(hits[0].object.userData.word);
  else setWord(null);
  down = null;
});

// ---- orbit
let rotY = 0, rotX = 0.15, zoom = 320, dragging = false, last = null;
renderer.domElement.addEventListener("pointerdown", e => { dragging = true; last = {x:e.clientX, y:e.clientY}; });
addEventListener("pointerup", () => dragging = false);
addEventListener("pointermove", e => {
  if (!dragging) return;
  rotY += (e.clientX-last.x)*0.005;
  rotX += (e.clientY-last.y)*0.005;
  rotX = Math.max(-1.4, Math.min(1.4, rotX));
  last = {x:e.clientX, y:e.clientY};
});
renderer.domElement.addEventListener("wheel", e => {
  e.preventDefault();
  zoom *= (1 + Math.sign(e.deltaY)*0.08);
  zoom = Math.max(80, Math.min(900, zoom));
}, {passive:false});

// ---- stats
const totalPairs = new Set(words.flatMap(w => WORDS[w].map(r => [w,r].sort().join("|")))).size;
document.getElementById("stats").innerHTML =
  `<b>${words.length}</b> palavras · <b>${totalPairs}</b> relações<br>mais conectada: <b>${[...words].sort((a,b)=>WORDS[b].length-WORDS[a].length)[0]}</b>`;

// ---- deep link
const params = new URLSearchParams(location.search);
const init = params.get("word");
if (init && WORDS[init]) setWord(init, false);

// ---- animate
function tick(){
  requestAnimationFrame(tick);
  if (!dragging) rotY += 0.0009;
  const group = new THREE.Group();
  // rotate camera around origin
  camera.position.set(Math.sin(rotY)*zoom, Math.sin(rotX)*zoom*0.5 + 30, Math.cos(rotY)*zoom);
  camera.lookAt(0,0,0);
  renderer.render(scene, camera);
}
tick();
addEventListener("resize", () => {
  camera.aspect = innerWidth/innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
});
