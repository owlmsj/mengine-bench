import csv, json
from collections import defaultdict

# account -> pnl_line
coa = {}
with open(r'<WORKSPACE>\finance\chart_of_accounts.csv', encoding='utf-8') as f:
    r = csv.reader(f, delimiter=';')
    next(r)
    for row in r:
        coa[row[0]] = row[2]

def parse_amt(s):
    # "56.661,03" -> 56661.03 ; "-56.661,03" -> -56661.03
    s = s.strip()
    neg = s.startswith('-')
    s = s.replace('-', '').replace('.', '').replace(',', '.')
    v = float(s)
    return -v if neg else v

months = ['2026-01','2026-02','2026-03','2026-04','2026-05','2026-06']
# line -> month -> amount
lines = defaultdict(lambda: defaultdict(float))
with open(r'<WORKSPACE>\finance\ledger.csv', encoding='utf-8') as f:
    r = csv.reader(f, delimiter=';')
    next(r)
    for row in r:
        d, acct, desc, amt = row
        dd, mm, yyyy = d.split('/')
        m = f'{yyyy}-{mm}'
        line = coa.get(acct, 'unknown')
        lines[line][m] += parse_amt(amt)

revenue = {}
cogs = {}
ebitda = {}
for m in months:
    rev = lines['revenue'][m]
    c = lines['cogs'][m]
    sm = lines['sales_marketing'][m]
    rnd = lines['rnd'][m]
    ga = lines['ga'][m]
    fin = lines['financial'][m]
    revenue[m] = rev
    cogs[m] = c
    ebitda[m] = rev + c + sm + rnd + ga  # exclude financial (interest/investment)
    print(m, f'rev={rev:.2f} cogs={c:.2f} sm={sm:.2f} rnd={rnd:.2f} ga={ga:.2f} fin={fin:.2f} ebitda={ebitda[m]:.2f}')

gross_margin_pct = {m: (revenue[m] - abs(cogs[m])) / revenue[m] * 100 for m in months}

# burn: average monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = ['2026-04','2026-05','2026-06']
burn = -sum(ebitda[m] for m in last3) / 3
# runway: latest closing cash balance / burn
cash = 1847350.40
runway = cash / burn

print('burn', burn)
print('runway', runway)

result = {
    'revenue': {m: round(revenue[m], 2) for m in months},
    'gross_margin_pct': {m: round(gross_margin_pct[m], 2) for m in months},
    'ebitda': {m: round(ebitda[m], 2) for m in months},
    'burn': round(burn, 2),
    'runway_months': round(runway, 2),
}
with open(r'<WORKSPACE>\result.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
print(json.dumps(result, indent=2))