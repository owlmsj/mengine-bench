import csv, statistics, json

rows = []
with open('presentmon.csv', newline='') as f:
    for r in csv.DictReader(f):
        rows.append(r)

t = [float(r['MsBetweenPresents']) for r in rows]
n = len(rows)
avg_fps = 1000.0 / (sum(t) / n)
ts = sorted(t)
def pct(p):
    # linear interpolation percentile
    k = (len(ts) - 1) * p / 100.0
    lo = int(k); hi = min(lo + 1, len(ts) - 1)
    return ts[lo] + (ts[hi] - ts[lo]) * (k - lo)
p99 = pct(99.0)
low1 = 1000.0 / p99
print('frames:', n)
print('total_ms:', sum(t))
print('avg_ms:', sum(t) / n)
print('avg_fps:', round(avg_fps, 2))
print('p99_ms:', round(p99, 3))
print('low1_fps:', round(low1, 2))
print('max_ms:', max(t))

# find the worst frames with their TimeInSeconds
worst = sorted(rows, key=lambda r: -float(r['MsBetweenPresents']))[:15]
print('\nworst frames (TimeInSeconds, ms):')
for r in worst:
    print(' ', r['TimeInSeconds'], r['MsBetweenPresents'])

# histogram of slow frames (>30 ms)
slow = [(r['TimeInSeconds'], r['MsBetweenPresents']) for r in rows if float(r['MsBetweenPresents']) > 30]
print('\nframes >30ms:', len(slow))
for s in slow[:40]:
    print('  ', s)

# sensors
with open('sensors.csv', newline='') as f:
    srows = list(csv.DictReader(f))
print('\nsensors rows:', len(srows))
for s in srows:
    print(' ', s['time_s'], 'cpu', s['cpu_clock_mhz'], s['cpu_util_pct'],
          'gpu', s['gpu_clock_mhz'], s['gpu_pcie_link_state'], s['gpu_pcie_link_speed'],
          'dpc', s['dpc_latency_us'], 'disk', s['disk_active_pct'], s['top_cpu_process'])