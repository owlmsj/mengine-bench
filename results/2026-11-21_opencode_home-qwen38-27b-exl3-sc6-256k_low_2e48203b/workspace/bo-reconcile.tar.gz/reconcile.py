import csv, re, json
from collections import defaultdict

base = r"<WORKSPACE>\backoffice"

invoices = {}
with open(f"{base}/invoices.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = float(row["amount"])

payments = defaultdict(list)  # invoice id -> list of amounts
with open(f"{base}/bank_statement_june.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        m = re.search(r"10(\d{2})", memo)
        if not m:
            continue
        inv = f"INV-{m.group(0)}"
        if inv not in invoices:
            continue
        payments[inv].append(float(row["amount"]))

unpaid, duplicated, mismatched = [], [], []
for inv in sorted(invoices):
    pays = payments.get(inv, [])
    if not pays:
        unpaid.append(inv)
    elif len(pays) > 1:
        duplicated.append(inv)
    elif pays[0] != invoices[inv]:
        mismatched.append({"id": inv, "invoiced": invoices[inv], "paid": pays[0]})

result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))