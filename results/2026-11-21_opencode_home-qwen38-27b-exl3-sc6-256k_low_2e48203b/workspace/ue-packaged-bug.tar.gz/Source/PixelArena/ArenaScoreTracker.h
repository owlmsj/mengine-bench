#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "ArenaScoreTracker.generated.h"

/**
 * Tracks per-team scores for an arena match.
 * Must be a UObject (UCLASS) so it can be created with NewObject and
 * garbage-collected with its outer; a plain C++ class here broke the
 * packaged build (NewObject returned null -> crash in AddPoints).
 */
UCLASS()
class PIXELARENA_API UArenaScoreTracker : public UObject
{
	GENERATED_BODY()

public:
	void AddPoints(int32 TeamIndex, int32 Points);
	int32 GetPoints(int32 TeamIndex) const;

private:
	UPROPERTY()
	TMap<int32, int32> PointsByTeam;
};