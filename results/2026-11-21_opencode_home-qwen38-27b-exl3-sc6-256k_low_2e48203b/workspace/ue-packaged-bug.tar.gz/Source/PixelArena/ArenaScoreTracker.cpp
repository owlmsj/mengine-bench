#include "ArenaScoreTracker.h"

void UArenaScoreTracker::AddPoints(int32 TeamIndex, int32 Points)
{
	PointsByTeam.FindOrAdd(TeamIndex) += Points;
}

int32 UArenaScoreTracker::GetPoints(int32 TeamIndex) const
{
	const int32* Found = PointsByTeam.Find(TeamIndex);
	return Found ? *Found : 0;
}