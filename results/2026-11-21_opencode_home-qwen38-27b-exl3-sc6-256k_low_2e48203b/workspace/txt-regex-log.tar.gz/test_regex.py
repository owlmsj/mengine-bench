import re

with open(r"<WORKSPACE>\regex.txt") as f:
    pattern = f.read().strip()

with open(r"<WORKSPACE>\server.log") as f:
    log_text = f.read()

result = re.findall(pattern, log_text, re.MULTILINE)
print("RESULT:", result)

# Expected: lines with valid IPv4 -> last date on that line
# Line 1: 10.12.0.7 valid -> last date 2026-04-01
# Line 2: no IP -> nothing
# Line 3: 192.168.40.3 valid -> last date 2026-04-05
# Line 4: 7781-20-4410 not an IP -> nothing
# Line 5: 172.20.1.14 valid -> last date 2026-04-02
expected = ["2026-04-01", "2026-04-05", "2026-04-02"]
print("EXPECTED:", expected)
print("MATCH:", result == expected)