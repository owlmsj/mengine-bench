import re

with open(r"<WORKSPACE>\regex.txt") as f:
    pattern = f.read().strip()

cases = [
    # (line, expected)
    ("2026-04-02 07:15:09 INFO  gateway accepted 10.12.0.7 for build 2026-04-01", ["2026-04-01"]),
    ("2026-04-02 07:15:11 INFO  cache warm, 412 keys, next sweep 2026-04-03", []),
    ("2026-04-02 07:16:40 WARN  peer 192.168.40.3 slow, retry window 2026-04-02 to 2026-04-05", ["2026-04-05"]),
    ("2026-04-02 07:18:02 INFO  job 7781-20-4410 queued by scheduler", []),
    ("2026-04-02 07:19:30 ERROR upstream 172.20.1.14 refused handshake", ["2026-04-02"]),
    # IP with leading zero in octet -> invalid
    ("2026-01-01 host 010.1.2.3 date 2026-01-02", []),
    # IP octet > 255 -> invalid
    ("2026-01-01 host 256.1.2.3 date 2026-01-02", []),
    # IP with letter before -> invalid
    ("2026-01-01 host a10.1.2.3 date 2026-01-02", []),
    # IP with digit after -> invalid
    ("2026-01-01 host 10.1.2.34 date 2026-01-02", []),
    # Date with letter before -> invalid
    ("2026-01-01 host 10.1.2.3 date a2026-01-02", []),
    # Date with digit after -> invalid
    ("2026-01-01 host 10.1.2.3 date 2026-01-023", []),
    # Feb 29 in non-leap year -> invalid date, but line has IP
    ("2026-02-29 host 10.1.2.3 date 2026-02-29", []),
    # Feb 29 in leap year -> valid
    ("2024-02-29 host 10.1.2.3 date 2024-02-29", ["2024-02-29"]),
    # Feb 30 -> invalid
    ("2024-02-30 host 10.1.2.3 date 2024-02-30", []),
    # Month 13 -> invalid
    ("2026-13-01 host 10.1.2.3 date 2026-13-01", []),
    # Day 32 -> invalid
    ("2026-01-32 host 10.1.2.3 date 2026-01-32", []),
    # No IP, has date -> nothing
    ("2026-01-01 no ip here date 2026-01-02", []),
    # IP at start of line
    ("10.1.2.3 date 2026-01-02", ["2026-01-02"]),
    # IP at end of line, date before
    ("date 2026-01-02 host 10.1.2.3", ["2026-01-02"]),
    # Multiple dates, IP present -> last date
    ("2026-01-01 10.1.2.3 2026-01-02 2026-01-03", ["2026-01-03"]),
    # IP with 4 parts but one is 0-padded
    ("2026-01-01 host 10.01.2.3 date 2026-01-02", []),
    # Valid IP 0.0.0.0
    ("2026-01-01 host 0.0.0.0 date 2026-01-02", ["2026-01-02"]),
    # Valid IP 255.255.255.255
    ("2026-01-01 host 255.255.255.255 date 2026-01-02", ["2026-01-02"]),
    # Date at start of line, IP later
    ("2026-01-01 10.1.2.3", ["2026-01-01"]),
    # 2026-02-29 is not a valid date (2026 not leap) but 2024-02-29 is
    ("2024-02-29 10.1.2.3 2026-02-29", ["2024-02-29"]),
]

all_pass = True
for line, expected in cases:
    result = re.findall(pattern, line, re.MULTILINE)
    status = "PASS" if result == expected else "FAIL"
    if result != expected:
        all_pass = False
    print(f"{status}: {line!r} -> {result} (expected {expected})")

print("\nALL PASS" if all_pass else "\nSOME FAILED")