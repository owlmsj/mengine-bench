import csv, statistics, json

rows = []
with open(r'capture\presentmon.csv', newline='') as f:
    r = csv.DictReader(f)
    for row in r:
        rows.append(row)

btw = [float(x['MsBetweenPresents']) for x in rows if x['MsBetweenPresents']]
times = [float(x['TimeInSeconds']) for x in rows]

avg_fps = 1000.0 / (sum(btw) / len(btw))
srt = sorted(btw)
p99 = srt[int(0.99 * (len(srt) - 1))]
low1 = 1000.0 / p99

print('frames:', len(btw))
print('avg_fps: %.3f' % avg_fps)
print('mean ms: %.3f' % (sum(btw)/len(btw)))
print('p99 ms: %.3f  low1: %.3f' % (p99, low1))

# frames with hitch (above 2x median)
med = statistics.median(btw)
hitch = [(times[i], btw[i]) for i in range(len(rows)) if btw[i] > max(2*med, 20.0)]
print('median ms: %.3f' % med)
print('hitch count:', len(hitch))
tail = [(t, ms) for t, ms in hitch if t > 40]
print('hitches after t=40:', len(tail))
for t, ms in tail[:60]:
    print('t=%.2f ms=%.2f' % (t, ms))
mx = max(btw)
print('max ms: %.2f' % mx)

