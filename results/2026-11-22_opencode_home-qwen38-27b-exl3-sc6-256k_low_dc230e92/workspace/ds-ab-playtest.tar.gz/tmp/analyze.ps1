$ErrorActionPreference = 'Stop'
$csv = Import-Csv '<WORKSPACE>\telemetry\playtest_ab.csv'

# Dedup by session_id (ETL resends sessions; keep first row per session)
$seen = @{}
$rows = foreach ($r in $csv) {
    $sid = $r.session_id.Trim()
    if (-not $seen.ContainsKey($sid)) { $seen[$sid] = $true; [pscustomobject]@{ id=$sid; variant=$r.variant; done=[int]$r.completed_tutorial } }
}

# Normalize variant: trim + lowercase
$stats = @{}
foreach ($r in $rows) {
    $v = $r.variant.Trim().ToLower()
    if (-not $stats.ContainsKey($v)) { $stats[$v] = @{ n=0; done=0 } }
    $stats[$v].n++
    $stats[$v].done += $r.done
}

Write-Host "total unique sessions: $($rows.Count)"
foreach ($k in ($stats.Keys | Sort-Object)) {
    Write-Host "variant '$k': n=$($stats[$k].n) done=$($stats[$k].done)"
}

$a = $stats['a']; $b = $stats['b']
$p_a = $a.done / $a.n
$p_b = $b.done / $b.n
Write-Host ("rate a = {0:N6} ({1}/{2})" -f $p_a, $a.done, $a.n)
Write-Host ("rate b = {0:N6} ({1}/{2})" -f $p_b, $b.done, $b.n)

# Two-proportion pooled z-test, two-sided
$p = ($a.done + $b.done) / ($a.n + $b.n)
$se = [Math]::Sqrt($p * (1 - $p) * (1/$a.n + 1/$b.n))
$z = ($p_b - $p_a) / $se

# Normal CDF via A&S 7.1.26
function Phi([double]$z) {
    if ($z -lt 0) { return 1 - (Phi(-$z)) }
    $t = 1 / (1 + 0.2316419 * $z)
    $d = [Math]::Exp(-$z * $z / 2) / [Math]::Sqrt(2 * [Math]::PI)
    $poly = $t * (0.319381530 + $t * (-0.356563782 + $t * (1.781477937 + $t * (-1.821255978 + $t * 1.330274429))))
    return 1 - $d * $poly
}
$pval = 2 * (1 - (Phi([Math]::Abs($z))))
Write-Host ("z = {0:N4}" -f $z)
Write-Host ("p_value = {0:N6}" -f $pval)
Write-Host ("significant at 0.05 (B > A): " + ($pval -lt 0.05 -and $p_b -gt $p_a))

# Cross-check: chi-square (equivalent to two-sided pooled z^2)
$chi2 = $z * $z
Write-Host ("chi2 = {0:N4}" -f $chi2)
