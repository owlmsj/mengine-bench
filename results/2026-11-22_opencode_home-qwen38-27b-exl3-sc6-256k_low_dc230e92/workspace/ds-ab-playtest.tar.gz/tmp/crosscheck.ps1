$c = Import-Csv '<WORKSPACE>\telemetry\playtest_ab.csv'
Write-Host ('rows=' + $c.Count)
$uniq = $c | Select-Object -ExpandProperty session_id | Sort-Object -Unique
Write-Host ('unique_ids=' + $uniq.Count)

# first-row-per-session dedup, counted differently: sort by session, keep first
$map = @{}
foreach ($r in $c) {
    $sid = $r.session_id
    if (-not $map.ContainsKey($sid)) { $map[$sid] = $r }
}
$a_n = 0; $a_d = 0; $b_n = 0; $b_d = 0
foreach ($sid in $map.Keys) {
    $r = $map[$sid]
    $v = $r.variant.Trim().ToLower()
    $done = [int]$r.completed_tutorial
    if ($v -eq 'a') { $a_n++; $a_d += $done }
    elseif ($v -eq 'b') { $b_n++; $b_d += $done }
    else { Write-Host ('UNEXPECTED variant: ' + $r.variant) }
}
Write-Host ("a: n=$a_n done=$a_d rate=" + [Math]::Round($a_d / $a_n, 6))
Write-Host ("b: n=$b_n done=$b_d rate=" + [Math]::Round($b_d / $b_n, 6))

# p-value via chi-square on the 2x2 table, using Wilson-Hilferty-free approach:
# chi2 = N*(ad-bc)^2 / ((a+b)(c+d)(a+c)(b+d)), then p = 2*(1-Phi(sqrt(chi2)))
$a = $a_d; $b2 = $a_n - $a_d; $c2 = $b_d; $d = $b_n - $b_d
$N = $a_n + $b_n
$chi2 = $N * (($a * $d - $b2 * $c2) * ($a * $d - $b2 * $c2)) / (($a + $b2) * ($c2 + $d) * ($a + $c2) * ($b2 + $d))
function Phi([double]$z) {
    if ($z -lt 0) { return 1 - (Phi(-$z)) }
    $t = 1 / (1 + 0.2316419 * $z)
    $dd = [Math]::Exp(-$z * $z / 2) / [Math]::Sqrt(2 * [Math]::PI)
    return 1 - $dd * $t * (0.319381530 + $t * (-0.356563782 + $t * (1.781477937 + $t * (-1.821255978 + $t * 1.330274429))))
}
Write-Host ('chi2=' + [Math]::Round($chi2, 4) + ' p=' + [Math]::Round(2 * (1 - (Phi([Math]::Sqrt($chi2)))), 6))
