# HANDOFF — local-9b @ 128k
Goal: run local 9B at 128k (131072) context; measure decode.

Done:
- Baseline via `scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024` (Q5): 37.8 t/s, VRAM 7881 MiB.
- 7881 MiB is the WDDM ceiling; Shared Usage showed 1494 MiB spilled — that number does not count.
- Fix: `--no-mmproj-offload` + `-ub 512`: spill gone, 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k — discarded. Q4_K_M: 7305 MiB, 40.4 t/s — fallback only.
- Applied in local9 block of scripts/start_server.ps1:165 and profiles/local/local-9b.json.

Pending:
1. Review scratchpad temp file names (noted several times, never done).
2. Evals README cites deleted check_vision.ps1 — update it.

Assumptions: "Q5" = Q5_K_M (variant actually measured); 128k = 131072.

How I know it is right: numbers are literal measure_decode.ps1 outputs in the transcript; spill confirmed by the WDDM Shared Usage counter; fix verified — spill gone, decode steady at 38.0 t/s over 3 runs.
