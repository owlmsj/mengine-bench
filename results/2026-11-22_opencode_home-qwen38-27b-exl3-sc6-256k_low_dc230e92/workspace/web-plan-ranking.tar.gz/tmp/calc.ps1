$ErrorActionPreference = 'Stop'
$url = 'https://api.bcb.gov.br/dados/serie/bcdata.sgs.433/dados?formato=json&dataInicial=01/01/1985&dataFinal=31/12/1995'
$j = Invoke-RestMethod $url
"rows=$($j.Count) first=$($j[0].data) last=$($j[-1].data)"
$annual = @{}
foreach ($row in $j) {
  $dt = [datetime]::ParseExact($row.data, 'dd/MM/yyyy', $null)
  $y = $dt.Year
  if (-not $annual.ContainsKey($y)) { $annual[$y] = 1.0 }
  $annual[$y] *= (1 + [double]$row.valor / 100)
}
foreach ($y in ($annual.Keys | Sort-Object)) { "A{0}={1:F2}" -f $y, ($annual[$y] - 1) * 100 }
function MB($a, $b) {
  $d1 = [datetime]::Parse($a); $d2 = [datetime]::Parse($b)
  $m = ($d2.Year - $d1.Year) * 12 + ($d2.Month - $d1.Month)
  if ($d2.Day -lt $d1.Day) { $m-- }
  return $m
}
$plans = @(
  @{ n = 'Cruzado';  l = '1986-02-28'; x = '1987-06-12' },
  @{ n = 'Bresser';  l = '1987-06-12'; x = '1989-01-15' },
  @{ n = 'Verao';    l = '1989-01-15'; x = '1990-03-16' },
  @{ n = 'Collor I'; l = '1990-03-16'; x = '1991-01-31' },
  @{ n = 'Collor II'; l = '1991-01-31'; x = '1994-07-01' },
  @{ n = 'Real';     l = '1994-07-01'; x = $null }
)
foreach ($p in $plans) {
  $Y = [int]($p.l.Substring(0, 4))
  $b = if ($annual.Contains($Y - 1)) { ($annual[$Y - 1] - 1) * 100 } else { 'NA' }
  $a = if ($annual.Contains($Y + 1)) { ($annual[$Y + 1] - 1) * 100 } else { 'NA' }
  $d = if ($b -ne 'NA' -and $a -ne 'NA') { [Math]::Max(0, [Math]::Min(1, 1 - $a / $b)) } else { -1 }
  if ($p.x) { $mo = MB $p.l $p.x } else { $mo = 60 }
  $du = [Math]::Min($mo, 60) / 60
  $s = 0.7 * $d + 0.3 * $du
  "{0}: before={1} after={2} months={3} drop={4:F4} dur={5:F4} score={6:F4}" -f $p.n, $b, $a, $mo, $d, $du, $s
}
