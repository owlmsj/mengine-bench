$ErrorActionPreference = 'Stop'
$site = '<WORKSPACE>\site'
$out  = '<WORKSPACE>'
$utf8 = [Text.UTF8Encoding]::new($false)

function Strip-Tag([string]$s) { return ($s -replace '<[^>]+>','').Trim() }

$files = Get-ChildItem $site -Filter *.html | Sort-Object Name
$pages = @{}
foreach ($f in $files) {
  $html = [IO.File]::ReadAllText($f.FullName, $utf8)
  $h1 = $null
  $m = [regex]::Match($html, '<h1>(.*?)</h1>')
  if ($m.Success) { $h1 = Strip-Tag $m.Groups[1].Value }
  $tema = $null
  $t = [regex]::Match($html, '<p class="tema">Tema:\s*(.*?)</p>')
  if ($t.Success) { $tema = $t.Groups[1].Value.Trim() }
  $links = [System.Collections.Generic.List[string]]::new()
  foreach ($id in 'sinonimos','analogas') {
    $s = [regex]::Match($html, '<section id="' + $id + '">(.*?)</section>', [System.Text.RegularExpressions.RegexOptions]::Singleline)
    if ($s.Success) {
      foreach ($a in [regex]::Matches($s.Groups[1].Value, '<a href="([^"]+)"')) {
        $links.Add($a.Groups[1].Value)
      }
    }
  }
  $pages[$f.Name] = @{ h1 = $h1; tema = $tema; links = $links }
}

Write-Host ("total files: " + $pages.Count)
# canonical name by filename key (percent-decoded, lowercased for lookup)
$canonByFile = @{}
$normMap = @{}  # normalized word -> canonical word
foreach ($k in $pages.Keys) {
  $p = $pages[$k]
  if ($null -ne $p.h1 -and $p.h1 -ne 'Dicionário Criativo' -and $k -notin 'index.html','sobre.html','contato.html') {
    $canonByFile[$k] = $p.h1
  }
}
function Norm([string]$w) {
  $s = $w.Trim().ToLower()
  $s = $s -replace '[àáâãäå]','a' -replace '[èéêë]','e' -replace '[ìíîï]','i' -replace '[òóôõö]','o' -replace '[ùúûü]','u' -replace 'ç','c' -replace '[º°]','' -replace '\s+',' '
  return $s
}
foreach ($k in $canonByFile.Keys) { $normMap[(Norm $canonByFile[$k])] = $canonByFile[$k] }

# missing link targets
$missing = @()
$bad = @{}
foreach ($k in $pages.Keys) {
  foreach ($l in $pages[$k].links) {
    $dec = [System.Web.HttpUtility]::UrlDecode($l, [Text.Encoding]::UTF8)
    if (-not (Test-Path (Join-Path $site $dec))) { $missing += ($k + ' -> ' + $l) }
  }
}
Write-Host ('--- missing targets (' + $missing.Count + '):')
$missing | Select-Object -First 40 | ForEach-Object { Write-Host $_ }

# files without h1 (word pages?)
Write-Host '--- files without h1:'
foreach ($k in $pages.Keys) { if ($null -eq $pages[$k].h1) { Write-Host $k } }

# build graph
$words = @{}   # canonical word -> ordered unique linked canonical words
foreach ($k in $canonByFile.Keys) {
  $src = $canonByFile[$k]
  $set = [System.Collections.Generic.List[string]]::new()
  $seen = @{}
  foreach ($l in $pages[$k].links) {
    $dec = [System.Web.HttpUtility]::UrlDecode($l, [Text.Encoding]::UTF8)
    $tgt = $null
    if ($canonByFile.ContainsKey($dec)) { $tgt = $canonByFile[$dec] }
    if ($null -eq $tgt) { continue }
    $n = Norm $tgt
    if ($n -eq (Norm $src)) { continue }
    if (-not $seen.ContainsKey($n)) { $seen[$n] = $true; $set.Add($tgt) }
  }
  $words[$src] = $set
}

Write-Host ('words: ' + $words.Count)
$pairs = @{}
foreach ($w in $words.Keys) {
  foreach ($v in $words[$w]) {
    $a = Norm $w; $b = Norm $v
    if ($a -gt $b) { $t=$a; $a=$b; $b=$t }
    $key = $a + '|' + $b
    $pairs[$key] = $true
  }
}
Write-Host ('distinct undirected pairs: ' + $pairs.Count)

$deg = @{}
foreach ($w in $words.Keys) {
  $n = Norm $w
  if (-not $deg.ContainsKey($n)) { $deg[$n] = 0 }
  $deg[$n] += $words[$w].Count
  foreach ($v in $words[$w]) {
    $m = Norm $v
    if (-not $deg.ContainsKey($m)) { $deg[$m] = 0 }
    $deg[$m] += 1
  }
}
$top = $deg.GetEnumerator() | Sort-Object -Property @{Expression='Value';Descending=$true}, @{Expression='Key'} | Select-Object -First 8
Write-Host '--- top by total degree:'
$top | ForEach-Object { Write-Host ($_.Key + ': ' + $_.Value) }

# themes
$themes = @{}
foreach ($k in $canonByFile.Keys) {
  $t = $pages[$k].tema
  if ($null -ne $t) { $themes[$t] = ($themes[$t] + 1) } else { $themes['(none)'] = ($themes['(none)'] + 1) }
}
Write-Host '--- themes:'
$themes.GetEnumerator() | Sort-Object Value -Descending | ForEach-Object { Write-Host ($_.Key + ': ' + $_.Value) }

# write words.json
$js = [ordered]@{}
foreach ($w in $words.Keys) { $js[$w] = $words[$w] }
$json = $js | ConvertTo-Json -Depth 5
[IO.File]::WriteAllText((Join-Path $out 'words.json'), $json, $utf8)

$result = [ordered]@{
  words = $words.Count
  relations = $pairs.Count
  most_connected = $top[0].Key
}
[IO.File]::WriteAllText((Join-Path $out 'result.json'), ($result | ConvertTo-Json -Depth 3), $utf8)

$themeMap = [ordered]@{}
foreach ($k in $canonByFile.Keys) {
  $themeMap[$canonByFile[$k]] = $pages[$k].tema
}
$graph = [ordered]@{ words = $js; theme = $themeMap; degree = $deg }
[IO.File]::WriteAllText((Join-Path $out 'tmp\graph.json'), ($graph | ConvertTo-Json -Depth 5), $utf8)
Write-Host 'DONE'
