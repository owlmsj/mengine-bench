$ErrorActionPreference = 'Stop'
$root = '<WORKSPACE>'
$utf8 = [Text.UTF8Encoding]::new($false)
$graph = [IO.File]::ReadAllText((Join-Path $root 'tmp\graph.json'), $utf8) | ConvertFrom-Json
$data = [ordered]@{ words = $graph.words; theme = $graph.theme }
$json = ($data | ConvertTo-Json -Depth 6) -replace '</', '<\/'
$tpl = [IO.File]::ReadAllText((Join-Path $root 'tmp\template.html'), $utf8)
$html = $tpl.Replace('__DATA__', $json)
$outDir = Join-Path $root 'universe'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
[IO.File]::WriteAllText((Join-Path $outDir 'index.html'), $html, $utf8)
Write-Host ('index.html bytes: ' + $html.Length)
