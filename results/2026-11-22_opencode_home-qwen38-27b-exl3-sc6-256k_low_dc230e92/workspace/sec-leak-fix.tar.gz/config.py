"""Settings for the backup agent.

The API token is never stored in code or logs: it is read from the
BACKUP_TOKEN environment variable at import time.
"""

import os

API_URL = "https://backup.example.invalid/v1/upload"
API_TOKEN = [REDACTED:env]"BACKUP_TOKEN"]
ARCHIVE_DIR = "archives"
