import csv, json
from collections import defaultdict

base = r"<WORKSPACE>"

coa = {}
with open(f"{base}/finance/chart_of_accounts.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        coa[row["account"]] = row["pnl_line"]

months = ["2026-01","2026-02","2026-03","2026-04","2026-05","2026-06"]
pnl = {m: defaultdict(float) for m in months}

with open(f"{base}/finance/ledger.csv", encoding="utf-8-sig") as f:
    for row in csv.DictReader(f, delimiter=";"):
        d = row["date"]  # dd/mm/yyyy
        dd, mm, yy = d.split("/")
        m = f"{yy}-{mm}"
        amt = float(row["amount"].replace(".", "").replace(",", "."))
        line = coa[row["account"]]
        pnl[m][line] += amt

out = {"revenue": {}, "gross_margin_pct": {}, "ebitda": {},
       "burn": None, "runway_months": None}
ebitdas = {}
for m in months:
    p = pnl[m]
    rev = p["revenue"]
    cogs = p["cogs"]  # negative
    gross = rev + cogs
    opex = p["sales_marketing"] + p["rnd"] + p["ga"]
    ebitda = gross + opex  # excludes financial line (6.x)
    ebitdas[m] = ebitda
    out["revenue"][m] = round(rev, 2)
    out["gross_margin_pct"][m] = round(gross / rev * 100, 2)
    out["ebitda"][m] = round(ebitda, 2)

# burn: avg monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = [ebitdas[m] for m in ["2026-04","2026-05","2026-06"]]
burn = -sum(last3) / 3  # positive magnitude
out["burn"] = round(burn, 2)
cash_jun = 1847350.40
out["runway_months"] = round(cash_jun / burn, 2)

print(json.dumps(out, indent=1))
# sanity: show financial line excluded
for m in months:
    print(m, "financial:", pnl[m]["financial"])
with open(f"{base}/result.json", "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2)
