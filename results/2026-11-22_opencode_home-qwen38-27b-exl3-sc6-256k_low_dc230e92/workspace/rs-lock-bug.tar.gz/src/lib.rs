//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    /// Registers a player. If the player already has a score, the score is
    /// replaced and the total is adjusted by the difference, so the total
    /// always stays equal to the sum of all player scores.
    pub fn join(&self, id: PlayerId, score: i64) {
        let mut players = self.players.lock().unwrap();
        let delta = match players.get(&id) {
            Some(slot) => {
                let mut guard = slot.lock().unwrap();
                let delta = score - *guard;
                *guard = score;
                delta
            }
            None => {
                players.insert(id, Arc::new(Mutex::new(score)));
                score
            }
        };
        drop(players);
        *self.total.lock().unwrap() += delta;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    /// The read-modify-write happens under the lock, so concurrent awards
    /// cannot lose updates.
    pub fn award(&self, id: PlayerId, points: i64) {
        *self.slot(id).lock().unwrap() += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    /// The two slots are always locked in player-id order, so concurrent
    /// transfers (including reversed pairs and self-transfers) cannot
    /// deadlock.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return;
        }
        let (low, high) = if from < to { (from, to) } else { (to, from) };
        let low_slot = self.slot(low);
        let high_slot = self.slot(high);
        let mut low_guard = low_slot.lock().unwrap();
        let mut high_guard = high_slot.lock().unwrap();
        if from < to {
            *low_guard -= points;
            *high_guard += points;
        } else {
            *high_guard -= points;
            *low_guard += points;
        }
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}
