import csv, json, re

ws = r"<WORKSPACE>"
inv = {}
with open(ws + r"\backoffice\invoices.csv", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        inv[r["id"]] = float(r["amount"])

# payments keyed by invoice id; ignore fees, interest, unidentified PIX
payments = {}
ignored = []
with open(ws + r"\backoffice\bank_statement_june.csv", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        memo = r["memo"]
        m = re.search(r"inv(?:oice)?[\s-]?(\d{4})", memo, re.I)
        if not m:
            ignored.append(memo)
            continue
        iid = "INV-" + m.group(1)
        payments.setdefault(iid, []).append(float(r["amount"]))

unpaid, duplicated, mismatched = [], [], []
for iid in sorted(inv):
    if iid not in payments:
        unpaid.append(iid)
    elif len(payments[iid]) > 1:
        duplicated.append(iid)  # exclusive: never also mismatched
    elif abs(payments[iid][0] - inv[iid]) > 1e-9:
        mismatched.append({"id": iid, "invoiced": inv[iid], "paid": payments[iid][0]})

print("ignored memos:", ignored)
print("unpaid:", unpaid)
print("duplicated:", duplicated)
print("mismatched:", mismatched)

result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
with open(ws + r"\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print("wrote result.json")
