import sqlite3
c = sqlite3.connect('analytics.db')
print('non-test users per platform:', list(c.execute('select platform,count(*) from users where is_test=0 group by 1')))
print('test users:', c.execute('select count(*) from users where is_test=1').fetchone()[0])
print('events from unknown players:', c.execute('select count(*) from events e where not exists(select 1 from users u where u.user_id=e.user_id)').fetchone()[0])
q = ("select user_id from events where user_id in (select user_id from users where is_test=0) group by user_id having min(case when name='purchase' then ts end) is not null and min(case when name='first_match' then ts end) is not null and min(case when name='purchase' then ts end) < min(case when name='first_match' then ts end) limit 3")
print('players with purchase before first_match (out-of-order sample):', list(c.execute(q)))
print('event names present:', list(c.execute('select distinct name from events')))
