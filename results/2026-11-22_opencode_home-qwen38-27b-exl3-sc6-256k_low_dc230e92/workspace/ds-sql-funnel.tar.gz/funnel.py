import sqlite3, json

conn = sqlite3.connect('analytics.db')
conn.row_factory = sqlite3.Row

STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']

# valid players: known and not test
rows = conn.execute("""
    select e.user_id, u.platform, e.name, e.ts
    from events e
    join users u on u.user_id = e.user_id
    where u.is_test = 0
""").fetchall()

# per player+platform: first occurrence ts per step name
from collections import defaultdict
first = defaultdict(lambda: defaultdict(dict))
for r in rows:
    plat = r['platform']
    pid = r['user_id']
    evs = first[plat][pid]
    cur = evs.get(r['name'])
    if cur is None or r['ts'] < cur:
        evs[r['name']] = r['ts']

funnel = {}
biggest_drop = {}
for plat in sorted(first):
    players = first[plat]
    funnel[plat] = {}
    # per player, walk the funnel: step valid if first occurrence >= previous step ts (or first step always valid if present)
    counts = {s: 0 for s in STEPS}
    for pid, evs in players.items():
        prev_ts = None
        for s in STEPS:
            ts = evs.get(s)
            if ts is not None and (prev_ts is None or ts >= prev_ts):
                counts[s] += 1
                prev_ts = ts
            # else: invalid step (occurred before previous), do not advance prev_ts
    funnel[plat] = counts
    # conversions
    convs = {}
    for i in range(1, len(STEPS)):
        prev, cur = STEPS[i-1], STEPS[i]
        convs[cur] = (counts[cur] / counts[prev]) if counts[prev] else 0
    biggest_drop[plat] = min(convs, key=lambda s: convs[s])

result = {'funnel': funnel, 'biggest_drop': biggest_drop}
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
