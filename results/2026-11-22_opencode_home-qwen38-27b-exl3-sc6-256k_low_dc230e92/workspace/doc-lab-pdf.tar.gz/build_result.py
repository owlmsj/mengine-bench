import json

# Conversions (standard lab factors):
# glucose  mg/dL = mmol/L * 18.01559
# cholesterol/LDL mg/dL = mmol/L * 38.6669
# creatinine mg/dL = umol/L / 88.42
# HbA1c % = mmol/mol / 10.929 + 2.15 (IFCC -> NGSP)
glu = 6.1 * 18.01559
ldl = 3.70 * 38.6669
cre = 76 / 88.42
hba1c = 37 / 10.929 + 2.15
print(glu, ldl, cre, hba1c)

history = {
    "GLICOSE EM JEJUM": {"2026-02-10": 92, "2026-08-18": round(glu, 1)},
    "COLESTEROL LDL": {"2026-02-10": 118, "2026-08-18": round(ldl, 1)},
    "CREATININA": {"2026-02-10": 0.95, "2026-08-18": round(cre, 2)},
    "HEMOGLOBINA GLICADA (HbA1c)": {"2026-02-10": 5.4, "2026-08-18": round(hba1c, 1)},
}

# First report (Alfa) reference ranges:
# glucose 70-99, LDL <130, creatinine 0.70-1.30, HbA1c 4.0-5.6
def outside(marker, v):
    if marker == "GLICOSE EM JEJUM": return v > 99 or v < 70
    if marker == "COLESTEROL LDL": return v > 130
    if marker == "CREATININA": return v > 1.30 or v < 0.70
    if marker == "HEMOGLOBINA GLICADA (HbA1c)": return v > 5.6 or v < 4.0

worse = []
for m, vals in history.items():
    first, last = vals["2026-02-10"], vals["2026-08-18"]
    if last > first and outside(m, last):
        worse.append(m)
print(worse)

result = {"history": history, "worse": worse}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
print("written")
