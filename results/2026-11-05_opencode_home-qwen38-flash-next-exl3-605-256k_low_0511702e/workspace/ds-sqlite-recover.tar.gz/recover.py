import json, struct

data = open('prices.db', 'rb').read()

def varint(buf, off):
    v = 0
    for i in range(9):
        b = buf[off + i]
        if i == 8:
            v = (v << 8) | b
            return v, off + 9
        v = (v << 7) | (b & 0x7f)
        if not (b & 0x80):
            return v, off + i + 1

def value(buf, off, st):
    if st == 0: return None, off
    if st == 1: return struct.unpack('>b', buf[off:off+1])[0], off+1
    if st == 2: return struct.unpack('>h', buf[off:off+2])[0], off+2
    if st == 3: return int.from_bytes(buf[off:off+3], 'big', signed=True), off+3
    if st == 4: return struct.unpack('>i', buf[off:off+4])[0], off+4
    if st == 5: return int.from_bytes(buf[off:off+6], 'big', signed=True), off+6
    if st == 6: return struct.unpack('>q', buf[off:off+8])[0], off+8
    if st == 7: return struct.unpack('>d', buf[off:off+8])[0], off+8
    if st == 8: return 0, off
    if st == 9: return 1, off
    if st >= 12 and st % 2 == 0:
        n = (st - 12) // 2
        return buf[off:off+n], off+n
    if st >= 13 and st % 2 == 1:
        n = (st - 13) // 2
        return buf[off:off+n].decode('utf-8'), off+n
    raise ValueError('bad serial type %d' % st)

rows = []
n = struct.unpack('>H', data[3:5])[0]
for i in range(n):
    ptr = struct.unpack('>H', data[8 + 2*i:10 + 2*i])[0]
    sz, o = varint(data, ptr)          # payload size
    rowid, o = varint(data, o)         # rowid
    hsz, o2 = varint(data, o)          # record header size
    end = o + hsz
    types = []
    p = o2
    while p < end:
        st, p = varint(data, p)
        types.append(st)
    vals = []
    p = end
    for st in types:
        v, p = value(data, p, st)
        vals.append(v)
    rows.append((rowid, vals))

out = []
for rowid, vals in rows:
    assert vals[0] is None and vals[1:] and rowid > 0, (rowid, vals)  # col0 = INTEGER PRIMARY KEY (rowid alias)
    item, price = vals[1], vals[2]
    assert isinstance(item, str), (rowid, vals)
    assert isinstance(price, (int, float)), (rowid, vals)
    out.append({'item': item, 'price': price})

json.dump(out, open('recovered.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print(len(out), 'rows')
for r in out: print(r)