import csv, json, re
from decimal import Decimal
from collections import defaultdict

inv = {}
with open('backoffice/invoices.csv', newline='', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        inv[r['id']] = Decimal(r['amount'])

pays = defaultdict(list)
skipped = []
with open('backoffice/bank_statement_june.csv', newline='', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        amt = Decimal(r['amount'])
        m = re.search(r'(?:INV[-\s]?|invoice\s+)(\d{4})', r['memo'], re.I)
        num = m.group(1) if m else None
        if amt <= 0 or num is None or ('INV-' + num) not in inv:
            skipped.append((r['date'], r['memo'], r['amount']))
            continue
        pays['INV-' + num].append((r['date'], r['memo'], amt))

unpaid = sorted(i for i in inv if i not in pays)
dup = sorted(i for i, p in pays.items() if len(p) > 1)
mism = [{'id': i, 'invoiced': float(inv[i]), 'paid': float(p[0][2])}
        for i, p in sorted(pays.items())
        if len(p) == 1 and p[0][2] != inv[i]]

out = {'unpaid': unpaid, 'duplicated': dup, 'mismatched': mism}
with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, indent=2, ensure_ascii=False)
    f.write('\n')
print(json.dumps(out, indent=2, ensure_ascii=False))
print('payments', sum(len(p) for p in pays.values()), 'matched invoices', len(pays))
print('skipped:', skipped)
print('multi:', {i: p for i, p in pays.items() if len(p) > 1})