import json, datetime

SIDRA = "https://sidra.ibge.gov.br/tabela/1330"
# Annual IPCA (calendar year, %), IBGE SIDRA table 1330 (variação anual)
ipca = {1985: 226.03, 1986: 270.81, 1987: 365.88, 1988: 933.32, 1989: 1764.95,
        1990: 1584.46, 1991: 472.26, 1992: 1119.14, 1993: 2476.95, 1994: 916.08,
        1995: 22.41}

plans = [
    ("Cruzado",  datetime.date(1986, 2, 28), datetime.date(1987, 6, 12),
     ["https://pt.wikipedia.org/wiki/Plano_Cruzado", "https://pt.wikipedia.org/wiki/Plano_Bresser"]),
    ("Bresser",  datetime.date(1987, 6, 12), datetime.date(1989, 1, 15),
     ["https://pt.wikipedia.org/wiki/Plano_Bresser", "https://pt.wikipedia.org/wiki/Plano_Ver%C3%A3o"]),
    ("Verao",    datetime.date(1989, 1, 15), datetime.date(1990, 3, 16),
     ["https://pt.wikipedia.org/wiki/Plano_Ver%C3%A3o", "https://pt.wikipedia.org/wiki/Plano_Collor"]),
    ("Collor I", datetime.date(1990, 3, 16), datetime.date(1991, 1, 31),
     ["https://pt.wikipedia.org/wiki/Plano_Collor"]),
    ("Collor II",datetime.date(1991, 1, 31), datetime.date(1994, 7, 1),
     ["https://pt.wikipedia.org/wiki/Plano_Collor", "https://pt.wikipedia.org/wiki/Plano_Real"]),
    ("Real",     datetime.date(1994, 7, 1),  None,
     ["https://pt.wikipedia.org/wiki/Plano_Real"]),
]

def whole_months(a, b):
    m = (b.year - a.year) * 12 + (b.month - a.month)
    if b.day < a.day:
        m -= 1
    return m

rows = []
for name, start, nxt, srcs in plans:
    y = start.year
    before, after = ipca[y - 1], ipca[y + 1]
    drop = max(0.0, min(1.0, 1 - after / before))
    months = 60 if nxt is None else whole_months(start, nxt)
    dur = min(months, 60) / 60
    score = round(0.7 * drop + 0.3 * dur, 4)
    rows.append({"plan": name, "launch_date": start.isoformat(),
                 "ipca_before": before, "ipca_after": after,
                 "months_lasted": months, "score": score,
                 "sources": [SIDRA] + srcs})

rows.sort(key=lambda r: -r["score"])
out = {"plans": sorted(rows, key=lambda r: r["launch_date"]),
       "top3": [r["plan"] for r in rows[:3]]}
print(json.dumps(out, indent=2))
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2, ensure_ascii=False)