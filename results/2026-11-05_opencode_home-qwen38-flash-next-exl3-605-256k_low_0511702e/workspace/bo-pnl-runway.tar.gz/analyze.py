import csv, json
from collections import defaultdict

def br(s):
    return float(s.strip().replace(".", "").replace(",", "."))

line_of = {}
with open("finance/chart_of_accounts.csv", encoding="utf-8") as f:
    for r in csv.DictReader(f, delimiter=";"):
        line_of[r["account"]] = r["pnl_line"]

# month -> line -> sum
m = defaultdict(lambda: defaultdict(float))
with open("finance/ledger.csv", encoding="utf-8") as f:
    for r in csv.DictReader(f, delimiter=";"):
        d, r_ = r["date"].split("/"), r["account"]
        month = f"{d[2]}-{d[1]}"
        m[month][line_of[r_]] += br(r["amount"])

months = [f"2026-{i:02d}" for i in range(1, 7)]
out = {"revenue": {}, "gross_margin_pct": {}, "ebitda": {}}
rows = []
for mo in months:
    L = m[mo]
    rev = L["revenue"]
    cogs = L["cogs"]
    gm = (rev + cogs) / rev * 100
    ebitda = rev + cogs + L["sales_marketing"] + L["rnd"] + L["ga"]  # excl. financial
    out["revenue"][mo] = round(rev, 2)
    out["gross_margin_pct"][mo] = round(gm, 1)
    out["ebitda"][mo] = round(ebitda, 2)
    rows.append((mo, rev, cogs, L["sales_marketing"], L["rnd"], L["ga"], L["financial"], gm, ebitda))

for r in rows:
    print(f"{r[0]} rev={r[1]:>12,.2f} cogs={r[2]:>11,.2f} s&m={r[3]:>11,.2f} r&D={r[4]:>11,.2f} ga={r[5]:>10,.2f} fin={r[6]:>9,.2f} gm%={r[7]:5.1f} ebitda={r[8]:>11,.2f}")

# burn: avg monthly negative EBITDA of last three closed months (Apr-Jun)
last3 = [out["ebitda"][mo] for mo in months[-3:]]
burn = -sum(last3) / 3
cash = 1847350.40  # 30/06/2026 closing
out["burn"] = round(burn, 2)
out["runway_months"] = round(cash / burn, 1)
print(f"last3 ebitda={['%.2f' % x for x in last3]} burn={burn:,.2f} runway={cash/burn:.2f}")

with open("result.json", "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))