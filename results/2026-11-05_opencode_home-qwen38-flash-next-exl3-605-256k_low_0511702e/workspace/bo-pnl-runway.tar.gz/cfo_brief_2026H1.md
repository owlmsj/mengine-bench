# CFO Brief — H1 2026 Close (investor meeting)

Currency: BRL (R$). Source: `finance/ledger.csv` (86 entries, Jan–Jun 2026),
`finance/chart_of_accounts.csv`, `finance/cash_balance.txt`.
Method per board note (`finance/README.md`): burn = average monthly negative
EBITDA of the last three closed months (Apr–Jun); runway = latest closing cash
(30/06/2026, R$ 1,847,350.40) ÷ burn.

## Monthly P&L

| Month | Revenue | Gross margin % | EBITDA |
|-------|-------------|------|--------------|
| 2026-01 | 200,510.87 | 70.0 | -210,278.96 |
| 2026-02 | 216,328.06 | 70.3 | -212,300.08 |
| 2026-03 | 219,066.17 | 68.5 | -204,525.45 |
| 2026-04 | 238,163.26 | 70.2 | -196,950.65 |
| 2026-05 | 243,032.89 | 69.6 | -201,945.82 |
| 2026-06 | 272,391.57 | 72.4 | -192,968.22 |

## How each month went
- Revenue grew every month: R$ 200.5k → R$ 272.4k, +35.8% Jan→Jun
  (+7.0% CAGR/mo). June is the strongest month of the half.
- Gross margin held ~68.5–72.4%, ending at the half's best (72.4%).
  Dip in March (68.5%) from COGS growth outpacing revenue that month.
- EBITDA improved from -R$ 210.3k (Jan) to -R$ 193.0k (Jun): losses are
  narrowing as revenue scales, but opex (S&M + R&D + G&A ~R$ 390k/mo) is
  still growing with revenue, so operating leverage is only starting.
- Refunds (acct 3.1.09, "Refund customer Kestrel") hit March (-6,814.15)
  and May (-8,634.37); already netted in revenue.

## Burn and runway
- Burn (avg negative EBITDA, Apr–Jun): **R$ 197,288.23 / month**
- Cash at 30/06/2026: R$ 1,847,350.40
- Runway: **9.4 months** → cash-out around mid-April 2027 at current burn.

## Assumptions
- EBITDA = revenue + COGS + S&M + R&D + G&A; financial results (acct 6.1.x,
  investment income and interest/IOF, net ~+R$ 7k/mo) excluded, no
  depreciation/amortization entries exist in the ledger.
- Revenue is net of refunds (3.1.09 is a revenue contra account).
- Runway uses the board's definition (cash ÷ avg negative EBITDA), not cash
  flow; June's cash movement (-R$ 461.8k vs -R$ 187.3k net result) suggests
  non-P&L cash items (e.g. payables or capex) not in this ledger — worth a
  footnote if investors ask.