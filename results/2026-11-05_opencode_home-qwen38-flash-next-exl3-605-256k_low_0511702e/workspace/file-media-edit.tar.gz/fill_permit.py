"""Fill permit-form.pdf from event-details.txt and flatten the answers.

Flatten = bake each text field's appearance stream into the page content as a
form XObject, then drop the widget annotations and the AcroForm so nothing is
editable. Values come from event-details.txt (Ines Varga, balloon launch).
"""
import re

import pypdf
from pypdf.generic import (
    ArrayObject,
    DecodedStreamObject,
    DictionaryObject,
    NameObject,
    NumberObject,
    TextStringObject,
)

SRC = "permit-form.pdf"
DST = "out/permit-filled.pdf"

details = open("event-details.txt", encoding="utf-8").read()


def grab(label):
    m = re.search(rf"^{label}:\s*(.+)$", details, re.M)
    if not m:
        raise ValueError(f"missing {label!r} in event-details.txt")
    return m.group(1).strip()


date_raw = grab("Date")  # "Saturday 5 December 2026" -> field wants YYYY-MM-DD
MONTHS = {m: i for i, m in enumerate(
    "january february march april may june july august september october "
    "november december".split(), 1)}
dm = re.search(r"(\d{1,2})\s+(\w+)\s+(\d{4})", date_raw)
if not dm:
    raise ValueError(f"unparsable date {date_raw!r}, expected 'D Month YYYY'")
iso = f"{dm.group(3)}-{MONTHS[dm.group(2).lower()]:02d}-{int(dm.group(1)):02d}"

values = {
    "organizer": grab("Organizer"),
    "event_date": iso,
    "location": grab("Where"),
    "attendees": grab("People"),
}

writer = pypdf.PdfWriter(clone_from=SRC)
writer.update_page_form_field_values(writer.pages[0], values, auto_regenerate=False)

page = writer.pages[0]
res = page.get("/Resources")
if res is None:
    res = DictionaryObject()
    page[NameObject("/Resources")] = res
xobjs = res.setdefault(NameObject("/XObject"), DictionaryObject())
if not isinstance(xobjs, DictionaryObject):
    xobjs = DictionaryObject()
    res[NameObject("/XObject")] = xobjs

content = DecodedStreamObject()
fragments = []
for i, annot in enumerate(page.get("/Annots", [])):
    obj = annot.get_object()
    if obj.get("/FT", page.get("/FT")) != "/Tx":
        continue
    ap = obj.get("/AP")
    if ap is None or "/N" not in ap:
        raise ValueError(f"field {obj.get('/T')} has no appearance to flatten")
    xobj = ap["/N"].get_object()
    name = f"/Flattened{i}"
    xobjs[NameObject(name)] = ap["/N"]
    mat = xobj.get("/Matrix", ArrayObject([NumberObject(1), NumberObject(0),
                                           NumberObject(0), NumberObject(1),
                                           NumberObject(0), NumberObject(0)]))
    rect = obj["/Rect"]
    x, y = min(rect[0], rect[2]), min(rect[1], rect[3])
    # place the appearance at the widget origin, honouring its own matrix
    a, b, c, d, e, f = [float(v) for v in mat]
    fragments.append(
        f"q {a:g} {b:g} {c:g} {d:g} {e + float(x):g} {f + float(y):g} cm {name} Do Q"
    )

if not fragments:
    raise ValueError("no text widgets found to flatten")

content[NameObject("/Type")] = NameObject("/XObject")
content[NameObject("/Subtype")] = NameObject("/Form")
content[NameObject("/BBox")] = page["/MediaBox"]
content[NameObject("/Resources")] = res
content.set_data((" ".join(fragments)).encode("ascii"))
ref = writer._add_object(content)

existing = page.get("/Contents")
if existing is None:
    page[NameObject("/Contents")] = ref
else:
    base = existing.get_object()
    if isinstance(base, ArrayObject):
        arr = ArrayObject(list(base) + [ref])
    else:
        arr = ArrayObject([existing, ref])
    page[NameObject("/Contents")] = arr

del page[NameObject("/Annots")]
for key in ("/AcroForm", "/XFA"):
    writer._root_object.pop(NameObject(key), None)

with open(DST, "wb") as fh:
    writer.write(fh)
print("values:", values)
print("wrote", DST)