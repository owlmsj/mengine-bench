import csv, math
from collections import defaultdict

seen = {}
with open('telemetry/playtest_ab.csv', newline='') as f:
    for row in csv.DictReader(f):
        sid = row['session_id'].strip()
        v = row['variant'].strip().lower()
        c = int(row['completed_tutorial'].strip())
        if sid in seen and seen[sid] != (v, c):
            print('CONFLICT', sid, seen[sid], (v, c))
        seen[sid] = (v, c)

n = defaultdict(int); k = defaultdict(int)
for v, c in seen.values():
    n[v] += 1; k[v] += c

pa, pb = k['a']/n['a'], k['b']/n['b']
p = (k['a']+k['b'])/(n['a']+n['b'])
se = math.sqrt(p*(1-p)*(1/n['a']+1/n['b']))
z = (pb-pa)/se
pval = math.erfc(abs(z)/math.sqrt(2))  # two-sided
print(f"A: {k['a']}/{n['a']} = {pa:.4f}")
print(f"B: {k['b']}/{n['b']} = {pb:.4f}")
print(f"diff = {pb-pa:+.4f}, z = {z:.3f}, two-sided p = {pval:.4g}")

import json
out = {
    "ship_b": pval < 0.05 and pb > pa,
    "sessions_a": n['a'],
    "sessions_b": n['b'],
    "completion_rate_a": round(pa, 4),
    "completion_rate_b": round(pb, 4),
    "p_value": round(pval, 4),
}
with open('result.json', 'w') as f:
    json.dump(out, f, indent=2)
print(json.dumps(out))