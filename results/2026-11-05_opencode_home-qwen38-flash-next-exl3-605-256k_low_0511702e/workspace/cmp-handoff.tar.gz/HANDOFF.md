# HANDOFF: local-9b Q5 at 128k

## Task
Measure local-9b Q5 at 128k context and make it the default recipe.

## Findings (measured)
- First run: 37.8 t/s at 7881 MiB, but invalid: 7881 MiB is the WDDM
  ceiling; Shared Usage counter showed 1494 MiB spilled to RAM.
- Fix: `--no-mmproj-offload` + `-ub 512` removes the spill.
  Final: 7697 MiB, 38.0 t/s (median of 3).
  Command: scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024
- Q6_K (7.03 GiB) does not fit at 128k: discarded.
- Q4_K_M fits: 7305 MiB, 40.4 t/s; kept only as fallback.

## Done
Recipe applied in scripts/start_server.ps1:165 (local9 block) and
profiles/local/local-9b.json.

## Open
- evals README still cites check_vision.ps1 (file no longer exists).
- Verify the two edited files are committed; the code repo is NOT in
  this folder (only session/transcript.md lives here).

## Evidence
All numbers are quoted from session/transcript.md (steps 10, 15, 42, 45);
spill read from the WDDM Shared Usage counter in the GPU panel.