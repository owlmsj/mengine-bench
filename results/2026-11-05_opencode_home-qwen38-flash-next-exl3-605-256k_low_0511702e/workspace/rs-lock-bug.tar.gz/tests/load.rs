use arena_scores::Board;
use std::sync::Arc;
use std::thread;

#[test]
fn self_transfer_changes_nothing_and_does_not_hang() {
    let board = Board::new();
    board.join(1, 10);
    board.transfer(1, 1, 5);
    assert_eq!((board.score(1), board.total()), (10, 10));
}

#[test]
fn opposite_transfers_do_not_deadlock_or_lose_points() {
    let board = Arc::new(Board::new());
    board.join(1, 1000);
    board.join(2, 1000);
    let handles: Vec<_> = (0..8)
        .map(|i| {
            let board = board.clone();
            thread::spawn(move || {
                for _ in 0..2000 {
                    if i % 2 == 0 {
                        board.transfer(1, 2, 1);
                    } else {
                        board.transfer(2, 1, 1);
                    }
                }
            })
        })
        .collect();
    for h in handles {
        h.join().unwrap();
    }
    assert_eq!(board.score(1) + board.score(2), 2000);
    assert_eq!(board.total(), 2000);
}

#[test]
fn concurrent_awards_lose_no_updates() {
    let board = Arc::new(Board::new());
    board.join(1, 0);
    let handles: Vec<_> = (0..8)
        .map(|_| {
            let board = board.clone();
            thread::spawn(move || {
                for _ in 0..5000 {
                    board.award(1, 1);
                }
            })
        })
        .collect();
    for h in handles {
        h.join().unwrap();
    }
    assert_eq!(board.score(1), 40000);
    assert_eq!(board.total(), 40000);
}