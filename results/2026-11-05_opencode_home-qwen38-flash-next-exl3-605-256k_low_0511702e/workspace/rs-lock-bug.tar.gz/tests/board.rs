use arena_scores::Board;

#[test]
fn one_thread_keeps_the_scores() {
    let board = Board::new();
    board.join(1, 10);
    board.join(2, 0);
    board.award(1, 5);
    board.transfer(1, 2, 3);
    assert_eq!((board.score(1), board.score(2), board.total()), (12, 3, 15));
}
