//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    /// Each lock is held across the whole read-modify-write so concurrent
    /// awards cannot lose updates.
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        let score = *slot.lock().unwrap();
        *slot.lock().unwrap() = score + points;
        let total = *self.total.lock().unwrap();
        *self.total.lock().unwrap() = total + points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let from_slot = self.slot(from);
        let to_slot = self.slot(to);
        // Always take the lower id's lock first so two threads moving points
        // in opposite directions cannot deadlock on lock-order inversion.
        let (low, high) = if from < to {
            (from_slot.lock().unwrap(), to_slot.lock().unwrap())
        } else {
            (to_slot.lock().unwrap(), from_slot.lock().unwrap())
        };
        let (mut from_score, mut to_score) = if from < to { (low, high) } else { (high, low) };
        *from_score -= points;
        *to_score += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}
