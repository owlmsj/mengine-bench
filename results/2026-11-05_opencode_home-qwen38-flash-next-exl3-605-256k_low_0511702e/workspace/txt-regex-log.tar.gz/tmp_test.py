import re
pat = open('regex.txt', encoding='utf-8').read().strip()
rx = re.compile(pat, re.MULTILINE)

cases = [
    # (line, expected findall result)
    ("2026-04-02 07:15:09 INFO  gateway accepted 10.12.0.7 for build 2026-04-01", ["2026-04-01"]),
    ("2026-04-02 07:15:11 INFO  cache warm, 412 keys, next sweep 2026-04-03", []),
    ("2026-04-02 07:16:40 WARN  peer 192.168.40.3 slow, retry window 2026-04-02 to 2026-04-05", ["2026-04-05"]),
    ("2026-04-02 07:18:02 INFO  job 7781-20-4410 queued by scheduler", []),
    ("2026-04-02 07:19:30 ERROR upstream 172.20.1.14 refused handshake", ["2026-04-02"]),
    # IP invalid: leading zeros / >255
    ("2026-04-02 x 010.12.0.7 2026-04-03", []),
    ("2026-04-02 x 10.12.0.256 2026-04-03", []),
    ("2026-04-02 x 255.255.255.255 2026-04-03", ["2026-04-03"]),
    ("2026-04-02 x 0.0.0.0 ok", ["2026-04-02"]),
    # adjacency on IP: letter/digit disqualifies, punctuation ok
    ("2026-04-02 x v10.12.0.7 2026-04-03", []),
    ("2026-04-02 x 10.12.0.7x 2026-04-03", []),
    ("2026-04-02 x [10.12.0.7] 2026-04-03", ["2026-04-03"]),
    # invalid dates
    ("2026-04-02 x 10.12.0.7 bad 2026-02-30", ["2026-04-02"]),
    ("2026-04-02 x 10.12.0.7 bad 2026-04-31", ["2026-04-02"]),
    ("2026-04-02 x 10.12.0.7 ok 2026-02-29", ["2026-02-29"]),
    ("2025-02-28 x 10.12.0.7 2025-02-29", ["2025-02-29"]),
    ("2026-04-02 x 10.12.0.7 bad 2026-13-01", ["2026-04-02"]),
    ("2026-04-02 x 10.12.0.7 bad 2026-00-10", ["2026-04-02"]),
    # adjacency on date
    ("2026-04-02 x 10.12.0.7 a2026-04-03", ["2026-04-02"]),
    ("2026-04-02 x 10.12.0.7 2026-04-031", ["2026-04-02"]),
    ("2026-04-02 x 10.12.0.7 2026-04-03z", ["2026-04-02"]),
    ("2026-04-02 x 10.12.0.7 (2026-04-03)", ["2026-04-03"]),
    # last valid date wins even if later invalid pseudo-dates exist
    ("10.12.0.7 2026-05-10 then 2026-06-31 and 2026-07-04", ["2026-07-04"]),
    # date before ip still counts as only date
    ("2026-01-31 done 10.12.0.7", ["2026-01-31"]),
    # 31-day vs 30-day months
    ("10.12.0.7 2026-11-30 2026-11-31", ["2026-11-30"]),
    ("10.12.0.7 2026-12-31", ["2026-12-31"]),
]
fails = 0
for line, exp in cases:
    got = rx.findall(line)
    if got != exp:
        fails += 1
        print("FAIL", repr(line), "exp", exp, "got", got)

text = open('server.log', encoding='utf-8').read()
whole = rx.findall(text)
print("whole log:", whole)
assert whole == ["2026-04-01", "2026-04-05", "2026-04-02"], whole
# multi-line ordering across a combined text
combo = "\n".join(c[0] for c in cases)
allres = rx.findall(combo)
exp_all = [d for c in cases for d in c[1]]
if allres != exp_all:
    fails += 1
    print("FAIL combo", exp_all, allres)
print("group count:", rx.groups, "fails:", fails)