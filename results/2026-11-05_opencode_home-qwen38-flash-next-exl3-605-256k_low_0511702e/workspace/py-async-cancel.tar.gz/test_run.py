import asyncio
import time

from run import run_tasks


async def test_concurrency_cap_and_results():
    running = 0
    peak = 0

    def make(i):
        async def job():
            nonlocal running, peak
            running += 1
            peak = max(peak, running)
            await asyncio.sleep(0.02)
            running -= 1
            return i
        return job

    results = await run_tasks([make(i) for i in range(20)], 4)
    assert results == list(range(20)), results
    assert peak <= 4, peak
    assert peak == 4, peak  # cap is actually used


async def test_cleanup_on_cancel():
    cleaned = []

    def make(i):
        async def job():
            try:
                await asyncio.sleep(10)
            finally:
                await asyncio.sleep(0.01)  # async cleanup
                cleaned.append(i)
        return job

    async def outer():
        await run_tasks([make(i) for i in range(6)], 2)

    t = asyncio.create_task(outer())
    await asyncio.sleep(0.05)
    t.cancel()  # what asyncio.run does on first SIGINT
    try:
        await t
    except asyncio.CancelledError:
        pass
    else:
        raise AssertionError("expected CancelledError")
    assert sorted(cleaned) == [0, 1], cleaned  # started jobs cleaned up


async def test_error_propagates_after_cleanup():
    cleaned = []

    def boom():
        async def job():
            raise RuntimeError("boom")
        return job

    def slow():
        async def job():
            try:
                await asyncio.sleep(10)
            finally:
                cleaned.append(1)
        return job

    try:
        await run_tasks([boom(), slow()], 2)
    except* RuntimeError:
        pass
    else:
        raise AssertionError("expected ExceptionGroup")
    await asyncio.sleep(0)  # slow cleanup already awaited by TaskGroup
    assert cleaned == [1], cleaned


async def test_bad_cap():
    try:
        await run_tasks([], 0)
    except ValueError:
        return
    raise AssertionError("expected ValueError")


async def main():
    await test_concurrency_cap_and_results()
    await test_cleanup_on_cancel()
    await test_error_propagates_after_cleanup()
    await test_bad_cap()
    print("all tests passed")


if __name__ == "__main__":
    asyncio.run(main())