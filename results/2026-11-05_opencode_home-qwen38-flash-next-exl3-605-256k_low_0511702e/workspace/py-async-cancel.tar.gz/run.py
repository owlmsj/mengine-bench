"""Concurrency helper for batch scripts.

Usage:
    from run import run_tasks

    results = await run_tasks(tasks, max_concurrent)

Each task is a zero-argument callable that returns an awaitable job.
At most ``max_concurrent`` jobs run at once. On normal completion every
job has finished and results are returned in task order.

On Ctrl+C (KeyboardInterrupt under asyncio.run, which cancels the main
task) or on a job failure, all unfinished jobs are cancelled and *awaited*
before the error propagates, so each job's cleanup (finally blocks, async
context managers) runs to completion.

Assumptions:
- Python 3.11+ (uses asyncio.TaskGroup), standard library only.
- Fail-fast on job errors: remaining jobs are cancelled (after their
  cleanup) and an ExceptionGroup is raised, matching TaskGroup semantics.
- Ctrl+C surfaces as CancelledError (first SIGINT) or KeyboardInterrupt
  (repeated SIGINTs); cleanup runs in both cases, the error re-raises.
- A job that ignores cancellation (no await in cleanup, or bare
  except-then-await) can still block shutdown; that is the job's bug.
"""

import asyncio
from collections.abc import Awaitable, Callable, Iterable
from typing import TypeVar

T = TypeVar("T")


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[T]]],
    max_concurrent: int,
) -> list[T]:
    """Run all jobs with bounded concurrency; return results in task order.

    Raises ValueError if max_concurrent < 1. Propagates job exceptions as
    an ExceptionGroup after cancelling and awaiting the remaining jobs.
    Propagates CancelledError/KeyboardInterrupt after cleanup completes.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent}")

    semaphore = asyncio.Semaphore(max_concurrent)

    async def guarded(task: Callable[[], Awaitable[T]]) -> T:
        async with semaphore:
            return await task()

    async with asyncio.TaskGroup() as tg:
        handles = [tg.create_task(guarded(task)) for task in tasks]
    return [handle.result() for handle in handles]


import asyncio  # noqa: E402  (import kept after docstring for readability)