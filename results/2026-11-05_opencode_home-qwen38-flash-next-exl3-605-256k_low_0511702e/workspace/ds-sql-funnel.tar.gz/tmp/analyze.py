import sqlite3, json

c = sqlite3.connect('analytics.db')
STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']

valid_users = {}
for uid, plat, test in c.execute('select user_id, platform, is_test from users'):
    if not test:
        valid_users[uid] = plat

unknown = c.execute(
    "select count(*) from events e left join users u on u.user_id=e.user_id where u.user_id is null"
).fetchone()[0]
tests = c.execute(
    "select count(*) from events e join users u on u.user_id=e.user_id where u.is_test=1"
).fetchone()[0]
names = [r[0] for r in c.execute('select distinct name from events')]
print('unknown-player events:', unknown, 'test events:', tests, 'names:', names)

# per user: earliest valid ts per step, sequential
times = {}
for uid, name, ts in c.execute('select user_id, name, ts from events order by ts'):
    if uid not in valid_users or name not in STEPS:
        continue
    t = times.setdefault(uid, {})
    i = STEPS.index(name)
    if i == 0:
        if 'install' not in t or ts < t['install']:
            t['install'] = ts
    else:
        prev = STEPS[i-1]
        if prev in t and ts >= t[prev]:
            if name not in t or ts < t[name]:
                t[name] = ts

funnel = {}
for plat in sorted(set(valid_users.values())):
    counts = []
    for i, s in enumerate(STEPS):
        n = sum(1 for uid, t in times.items()
                if valid_users[uid] == plat and all(st in t for st in STEPS[:i+1]))
        counts.append(n)
    convs = [(counts[i]/counts[i-1] if counts[i-1] else 0, STEPS[i]) for i in range(1, 4)]
    worst = min(convs)
    funnel[plat] = {'funnel': dict(zip(STEPS, counts)),
                    'biggest_drop': worst[1],
                    'conversions': {s: round(c, 4) for c, s in convs}}
    print(plat, counts, 'worst:', worst)

json.dump({p: {'funnel': v['funnel'], 'biggest_drop': v['biggest_drop']}
           for p, v in funnel.items()}, open('result.json', 'w', encoding='utf-8'), indent=2)
print(json.dumps(funnel, indent=2))