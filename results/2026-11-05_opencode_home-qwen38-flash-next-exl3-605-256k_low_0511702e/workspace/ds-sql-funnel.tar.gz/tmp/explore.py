import sqlite3
c = sqlite3.connect('analytics.db')
for name, sql in c.execute("select name, sql from sqlite_master where type='table'"):
    print(name, '|', sql)
    print('rows:', c.execute(f'select count(*) from "{name}"').fetchone()[0])
    for row in c.execute(f'select * from "{name}" limit 5'):
        print(row)