"""Backup agent: packs a folder chosen in the intranet web form and uploads it to the backup API."""

from __future__ import annotations

import logging
import subprocess
import urllib.request
from pathlib import Path

import config

log = logging.getLogger("backup_agent")


def archive_folder(folder: str, out_dir: str = config.ARCHIVE_DIR) -> Path:
    """Packs `folder` into `out_dir/<folder name>.tar.gz` and returns the archive path."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    target = out / (Path(folder).name + ".tar.gz")
    # Argument list, no shell: the folder is user input and must never be parsed as a command.
    subprocess.run(["tar", "-czf", str(target), str(folder)], check=True)
    return target


def send_archive(path: Path, url: str, token: str) -> int:
    """Uploads one archive to the backup API and returns the HTTP status."""
    request = urllib.request.Request(url, data=path.read_bytes(), method="POST",
                                     headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.status


def upload(path: Path) -> int:
    if not config.API_TOKEN:
        raise RuntimeError("BACKUP_TOKEN environment variable is not set")
    log.info("uploading %s", path)
    return send_archive(path, config.API_URL, config.API_TOKEN)


def handle_form(form: dict[str, str]) -> int:
    """Web form handler: backs up the folder the user typed."""
    archive = archive_folder(form["folder"])
    log.info("archived %s", archive)
    return upload(archive)
