Add-Type -AssemblyName System.Speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
$s.SetOutputToWaveFile("$PSScriptRoot\announcement.wav")
$s.Rate = 0
$s.Speak("Welcome aboard the evening ferry. Please keep your bags clear of the doors.")
$s.Dispose()
(Get-Item "$PSScriptRoot\announcement.wav").Length