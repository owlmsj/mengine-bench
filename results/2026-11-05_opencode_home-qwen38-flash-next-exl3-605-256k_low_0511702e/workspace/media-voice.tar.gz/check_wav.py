import wave
w = wave.open('announcement.wav','rb')
print('channels', w.getnchannels(), 'rate', w.getframerate(), 'sampwidth', w.getsampwidth())
print('duration_s', round(w.getnframes()/w.getframerate(), 2))