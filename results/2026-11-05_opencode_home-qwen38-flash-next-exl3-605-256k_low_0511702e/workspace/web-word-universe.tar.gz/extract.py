import json, os, re, urllib.parse
from html.parser import HTMLParser

SITE = "site"

class Page(HTMLParser):
    def __init__(self):
        super().__init__()
        self.h1 = None
        self.in_h1 = False
        self.section = None
        self.in_a = False
        self.href = None
        self.links = []  # (section, href)
        self.has_sections = False
    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "h1": self.in_h1 = True
        elif tag == "section" and a.get("id") in ("sinonimos", "analogas"):
            self.section = a["id"]; self.has_sections = True
        elif tag == "a" and self.section:
            self.in_a = True; self.href = a.get("href", "")
    def handle_endtag(self, tag):
        if tag == "h1": self.in_h1 = False
        elif tag == "section": self.section = None
        elif tag == "a" and self.in_a:
            self.in_a = False; self.links.append((self.section, self.href))
    def handle_data(self, data):
        if self.in_h1: self.h1 = (self.h1 or "") + data

def decode_href(href):
    href = href.split("#")[0]
    return urllib.parse.unquote(href)

# pass 1: parse all pages
pages = {}
for fn in os.listdir(SITE):
    if not fn.endswith(".html"): continue
    p = Page()
    with open(os.path.join(SITE, fn), encoding="utf-8") as f:
        p.feed(f.read())
    stem = urllib.parse.unquote(fn[:-5]).lower()
    pages[stem] = {"file": fn, "h1": (p.h1 or stem).strip(), "links": p.links,
                   "word": p.has_sections}

# resolve meta-refresh redirect stubs (saudades.html -> saudade.html)
for stem, p in pages.items():
    with open(os.path.join(SITE, p["file"]), encoding="utf-8") as f:
        m = re.search(r'url=([^"]+)\.html', f.read())
    if m:
        p["redirect"] = urllib.parse.unquote(m.group(1)).lower()

# canonical: word pages keyed by lowercase h1 (unique?)
by_h1 = {}
for stem, p in pages.items():
    if p["word"]:
        key = p["h1"].lower()
        if key in by_h1 and by_h1[key]["file"] != p["file"]:
            print("DUP h1:", key, by_h1[key]["file"], p["file"])
        by_h1[key] = p
# map any stem (filename) -> canonical key
stem_to_key = {}
for stem, p in pages.items():
    if p["word"]:
        stem_to_key[stem] = p["h1"].lower()

edges = set()
for key, p in by_h1.items():
    for sec, href in p["links"]:
        target = decode_href(href)
        if not target.endswith(".html"): continue
        tstem = target[:-5].lower()
        tstem = pages.get(tstem, {}).get("redirect", tstem)
        tkey = stem_to_key.get(tstem)
        if tkey is None or tkey == key: continue
        edges.add(tuple(sorted((key, tkey))))

words = {}
for key, p in sorted(by_h1.items()):
    words[p["h1"]] = []
for a, b in edges:
    words[by_h1[a]["h1"]].append(by_h1[b]["h1"])
    words[by_h1[b]["h1"]].append(by_h1[a]["h1"])
for w in words: words[w] = sorted(set(words[w]), key=str.lower)

deg = {w: len(v) for w, v in words.items()}
best = max(deg.values())
top = sorted(w for w, d in deg.items() if d == best)
print("word pages:", len(words), "edges:", len(edges))
print("most_connected:", top, "degree:", best)
dead = sum(1 for key, p in by_h1.items() for sec, href in p["links"]
           if decode_href(href).endswith(".html")
           and pages.get(decode_href(href)[:-5].lower(), {}).get("redirect",
               decode_href(href)[:-5].lower()) not in stem_to_key)
print("dead links dropped:", dead)
isolated = [w for w, d in deg.items() if d == 0]
print("isolated:", isolated)

with open("words.json", "w", encoding="utf-8") as f:
    json.dump(words, f, ensure_ascii=False, indent=1, sort_keys=False)
with open("result.json", "w", encoding="utf-8") as f:
    json.dump({"words": len(words), "relations": len(edges),
               "most_connected": top[0] if len(top) == 1 else top}, f, ensure_ascii=False, indent=1)
print("themes check sample:", {w: deg[w] for w in list(words)[:5]})