import json

words = json.load(open("words.json", encoding="utf-8"))
data = json.dumps(words, ensure_ascii=False, separators=(",", ":"))
deg = {w: len(v) for w, v in words.items()}
best = max(deg.values())
top = sorted(w for w, d in deg.items() if d == best)

html = """<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Universo das Palavras</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,300;9..144,600&family=Inter:wght@400;500&display=swap" rel="stylesheet">
<style>
:root{--bg:#0b0d14;--ink:#e8e6df;--dim:#8b8fa3;--acc:#ffd166;--line:#2a2f45}
*{box-sizing:border-box;margin:0}
body{background:var(--bg);color:var(--ink);font-family:Inter,system-ui,sans-serif;overflow:hidden}
#gl{position:fixed;inset:0}
#fallback{position:fixed;inset:0;display:none;overflow:auto;padding:84px 20px 20px}
#fallback .fc{display:inline-block;border:1px solid var(--line);border-radius:999px;padding:6px 14px;margin:4px;cursor:pointer}
header{position:fixed;top:0;left:0;right:0;display:flex;gap:14px;align-items:center;padding:14px 20px;z-index:5;background:linear-gradient(var(--bg),transparent)}
h1{font-family:Fraunces,serif;font-weight:300;font-size:20px;letter-spacing:.02em;white-space:nowrap}
h1 b{color:var(--acc);font-weight:600}
#stats{color:var(--dim);font-size:12px;white-space:nowrap}
#search{flex:1;max-width:340px;position:relative}
input{width:100%;background:#141828;color:var(--ink);border:1px solid var(--line);border-radius:10px;padding:9px 12px;font:inherit;outline:none}
input:focus{border-color:var(--acc)}
#sug{position:absolute;top:110%;left:0;right:0;background:#141828;border:1px solid var(--line);border-radius:10px;overflow:hidden;display:none;max-height:260px;overflow-y:auto}
#sug div{padding:8px 12px;cursor:pointer;font-size:14px}
#sug div:hover,#sug .sel{background:#1e2440}
#panel{position:fixed;right:0;top:0;bottom:0;width:min(360px,92vw);background:rgba(13,16,26,.92);backdrop-filter:blur(8px);border-left:1px solid var(--line);padding:84px 22px 22px;transform:translateX(102%);transition:transform .35s cubic-bezier(.2,.8,.2,1);z-index:4;overflow-y:auto}
#panel.open{transform:none}
#pw{font-family:Fraunces,serif;font-size:42px;font-weight:600;line-height:1.05}
#deg{color:var(--dim);font-size:13px;margin:6px 0 18px}
#rel h2{font-size:11px;text-transform:uppercase;letter-spacing:.14em;color:var(--dim);margin:16px 0 8px;font-weight:500}
.chip{display:inline-block;border:1px solid var(--line);border-radius:999px;padding:5px 12px;margin:3px;font-size:13px;cursor:pointer;transition:.15s}
.chip:hover{border-color:var(--acc);color:var(--acc)}
#hint{position:fixed;bottom:14px;left:20px;color:var(--dim);font-size:12px;z-index:5}
#err{color:#ff6b6b;font-size:13px;margin-top:8px;display:none}
a{color:var(--acc)}
</style>
</head>
<body>
<canvas id="gl"></canvas>
<div id="fallback"></div>
<header>
<h1>Universo das <b>Palavras</b></h1>
<span id="stats"></span>
<div id="search"><input id="q" placeholder="buscar palavra… ex.: saudade" autocomplete="off"><div id="sug"></div><div id="err"></div></div>
</header>
<aside id="panel">
<div id="pw"></div><div id="deg"></div>
<div id="rel"><h2>Palavras ligadas</h2><div id="chips"></div></div>
</aside>
<div id="hint">arraste para girar · roda para aproximar · clique nas palavras</div>
<script type="importmap">
{"imports":{"three":"https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js"}}
</script>
<script type="module">
const WORDS = __DATA__;
const NAMES = Object.keys(WORDS);
const deg = Object.fromEntries(NAMES.map(w => [w, WORDS[w].length]));
const TOP = NAMES.filter(w => deg[w] === Math.max(...Object.values(deg))).sort();
document.getElementById('stats').textContent =
  NAMES.length + ' palavras · ' + __REL__ + ' ligações · mais conectada: ' + TOP.join(', ');

let sel = null;
const panel = document.getElementById('panel');
const q = document.getElementById('q'), sug = document.getElementById('sug');

function norm(s){return s.normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toLowerCase();}
const N = Object.fromEntries(NAMES.map(w => [norm(w), w]));
const ALIAS = {saudades:'saudade', coracoes:'coração', paixoes:'paixão'};
function resolve(s){s=s.trim();return WORDS[s]?s:(ALIAS[norm(s)]||N[norm(s)]||null);}

function show(w, push){
  sel = w;
  document.getElementById('pw').textContent = w;
  document.getElementById('deg').textContent = deg[w] + (deg[w]===1?' ligação':' ligações');
  const c = document.getElementById('chips'); c.innerHTML = '';
  for(const r of WORDS[w]){
    const el = document.createElement('span'); el.className='chip'; el.textContent=r;
    el.onclick = () => show(r, true); c.appendChild(el);
  }
  panel.classList.add('open');
  document.getElementById('err').style.display='none';
  if(push){history.replaceState(null,'', location.pathname + (w?'?word='+encodeURIComponent(w):''));}
  if(window.focusNode) focusNode(w);
}
function suggest(){
  const t = norm(q.value);
  if(!t){sug.style.display='none';return;}
  const hits = NAMES.filter(w=>norm(w).includes(t)).sort((a,b)=>deg[b]-deg[a]||a.localeCompare(b)).slice(0,8);
  sug.innerHTML='';
  for(const h of hits){const d=document.createElement('div');d.textContent=h+' · '+deg[h];
    d.onclick=()=>{q.value='';sug.style.display='none';show(h,true);};sug.appendChild(d);}
  sug.style.display = hits.length?'block':'none';
}
q.addEventListener('input', suggest);
q.addEventListener('keydown', e=>{
  if(e.key==='Enter'){const w=resolve(q.value)||N[norm(q.value)]||
     (sug.firstChild? norm2word(sug.firstChild.textContent.split(' · ')[0]) : null);
   if(w){q.value='';sug.style.display='none';show(w,true);}
   else{const er=document.getElementById('err');er.textContent='não encontrei “'+q.value+'”';er.style.display='block';}}
  if(e.key==='Escape'){sug.style.display='none';q.blur();}
});
function norm2word(s){return resolve(s);}

const params = new URLSearchParams(location.search);
const start = resolve(params.get('word')||'');
if(params.get('word') && !start){
  const er=document.getElementById('err');er.textContent='“'+params.get('word')+'” não está no universo';er.style.display='block';
}

// ---- 3D universe ----
let focusNode = null;
async function boot(){
  let THREE;
  try{ THREE = await import('three'); }
  catch(e){ return fallback(); }
  const renderer = new THREE.WebGLRenderer({canvas:document.getElementById('gl'),antialias:true,alpha:true});
  renderer.setPixelRatio(Math.min(devicePixelRatio,2));
  const scene = new THREE.Scene();
  const cam = new THREE.PerspectiveCamera(55,1,0.1,4000);
  const R = 260;
  // positions: golden-spiral sphere, hubs pulled toward center
  const pos = NAMES.map((w,i)=>{
    const t=(i+0.5)/NAMES.length, phi=Math.acos(1-2*t), th=Math.PI*(1+Math.sqrt(5))*i;
    const r = R*(1.15-Math.min(deg[w],16)/16*0.75);
    return new THREE.Vector3(r*Math.sin(phi)*Math.cos(th), r*Math.cos(phi)*0.85, r*Math.sin(phi)*Math.sin(th));
  });
  // light force relaxation
  const idx = Object.fromEntries(NAMES.map((w,i)=>[w,i]));
  const edges = [];
  for(const w of NAMES) for(const r of WORDS[w]) if(w<r) edges.push([idx[w],idx[r]]);
  for(let it=0; it<220; it++){
    const f = pos.map(()=>new THREE.Vector3());
    for(let i=0;i<pos.length;i++) for(let j=i+1;j<pos.length;j++){
      const d=pos[i].clone().sub(pos[j]); const L=d.length()||1;
      if(L<160){d.multiplyScalar((160-L)/L*0.02);f[i].add(d);f[j].sub(d);}
    }
    for(const [a,b] of edges){
      const d=pos[b].clone().sub(pos[a]); const L=d.length()||1;
      d.multiplyScalar((L-70)/L*0.01); f[a].add(d); f[b].sub(d);
    }
    for(let i=0;i<pos.length;i++){f[i].sub(pos[i].clone().multiplyScalar(0.001));pos[i].add(f[i]);}
  }
  // node sprites (canvas labels)
  function label(text, size, color, bold){
    const c=document.createElement('canvas'),x=c.getContext('2d');
    const fs=size*8; x.font=(bold?'600 ':'300 ')+fs+'px Inter,sans-serif';
    c.width=Math.ceil(x.measureText(text).width)+fs; c.height=fs*2;
    x.font=(bold?'600 ':'300 ')+fs+'px Inter,sans-serif';
    x.fillStyle=color;x.textBaseline='middle';x.fillText(text,fs/2,fs);
    const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;
    const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:t,transparent:true,depthWrite:false}));
    sp.scale.set(c.width/8,c.height/8,1);return sp;
  }
  const nodes = NAMES.map((w,i)=>{
    const hub = deg[w]>=10;
    const sp = label(w, hub?2.6:(deg[w]>=6?2:1.6), hub?'#ffd166':'#cfd3e4', hub);
    sp.position.copy(pos[i]); sp.userData={w,i}; return sp;
  });
  scene.add(...nodes);
  const gp = new Float32Array(edges.length*6);
  edges.forEach(([a,b],k)=>{gp.set([pos[a].x,pos[a].y,pos[a].z,pos[b].x,pos[b].y,pos[b].z],k*6);});
  const gGeo=new THREE.BufferGeometry();gGeo.setAttribute('position',new THREE.BufferAttribute(gp,3));
  const gMat=new THREE.LineBasicMaterial({color:0x39406b,transparent:true,opacity:0.35});
  const graph=new THREE.LineSegments(gGeo,gMat);scene.add(graph);
  const hMat=new THREE.LineBasicMaterial({color:0xffd166,transparent:true,opacity:0.9});
  const hGeo=new THREE.BufferGeometry();hGeo.setAttribute('position',new THREE.BufferAttribute(new Float32Array(3*60*2),3));
  const hilite=new THREE.LineSegments(hGeo,hMat);hilite.visible=false;scene.add(hilite);

  // camera orbit
  let az=0.4, el=0.25, dist=560, dragging=false, px=0, py=0, spin=0.0009;
  addEventListener('pointerdown',e=>{if(e.target===renderer.domElement){dragging=true;px=e.clientX;py=e.clientY;}});
  addEventListener('pointerup',()=>dragging=false);
  addEventListener('pointermove',e=>{if(!dragging)return;az-=(e.clientX-px)*0.005;el=Math.max(-1.3,Math.min(1.3,el+(e.clientY-py)*0.004));px=e.clientX;py=e.clientY;});
  addEventListener('wheel',e=>{dist=Math.max(120,Math.min(1400,dist*(1+e.deltaY*0.001)));},{passive:true});
  const ray=new THREE.Raycaster();
  renderer.domElement.addEventListener('click',e=>{
    ray.setFromCamera({x:e.clientX/innerWidth*2-1,y:-(e.clientY/innerHeight)*2+1},cam);
    const hit=ray.intersectObjects(nodes)[0];
    if(hit) show(hit.object.userData.w,true);
  });
  focusNode = w => {
    const i=idx[w]; if(i===undefined)return;
    const p=pos[i]; hilite.visible=true;
    const arr=hGeo.attributes.position.array; let k=0;
    for(const r of WORDS[w]){const j=idx[r];arr[k++]=p.x;arr[k++]=p.y;arr[k++]=p.z;arr[k++]=pos[j].x;arr[k++]=pos[j].y;arr[k++]=pos[j].z;}
    hGeo.setDrawRange(0,(WORDS[w].length)*2);hGeo.attributes.position.needsUpdate=true;
    for(const n of nodes){const on=n.userData.w===w||WORDS[w].includes(n.userData.w);
      n.material.opacity=sel? (on?1:0.12):1;n.material.transparent=true;}
    const target=new THREE.Vector3(p.x,p.y,p.z);
    camTarget.lerp(target,1);
  };
  const camTarget=new THREE.Vector3();
  function resize(){renderer.setSize(innerWidth,innerHeight);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix();}
  addEventListener('resize',resize);resize();
  (function tick(){
    requestAnimationFrame(tick);
    if(!dragging) az+=spin;
    cam.position.set(camTarget.x+dist*Math.cos(el)*Math.sin(az),
                     camTarget.y+dist*Math.sin(el),
                     camTarget.z+dist*Math.cos(el)*Math.cos(az));
    cam.lookAt(camTarget);
    renderer.render(scene,cam);
  })();
}
function fallback(){
  document.getElementById('gl').style.display='none';
  const fb=document.getElementById('fallback');fb.style.display='block';
  for(const w of NAMES.slice().sort((a,b)=>deg[b]-deg[a])){
    const el=document.createElement('span');el.className='fc';el.textContent=w+' · '+deg[w];
    el.onclick=()=>show(w,true);fb.appendChild(el);
  }
}
boot();
if(start) show(start,false);
</script>
</body>
</html>
"""
html = html.replace("__DATA__", data).replace("__REL__", str(len({tuple(sorted((a,b))) for a in words for b in words[a]})))
open("universe/index.html", "w", encoding="utf-8").write(html)
print("written", len(html), "bytes")