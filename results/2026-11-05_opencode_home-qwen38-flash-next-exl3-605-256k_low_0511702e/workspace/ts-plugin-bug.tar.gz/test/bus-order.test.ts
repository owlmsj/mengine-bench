import { test } from "node:test";
import assert from "node:assert/strict";
import { HookBus } from "../src/bus.ts";
import { registerAuditPlugin } from "../src/plugin.ts";

test("emit runs handlers sequentially in subscription order", async () => {
  const bus = new HookBus();
  const seen: string[] = [];
  bus.on("e", async () => {
    await new Promise((r) => setTimeout(r, 10));
    seen.push("slow");
  });
  bus.on("e", () => {
    seen.push("fast");
  });
  await bus.emit("e", undefined);
  assert.deepEqual(seen, ["slow", "fast"]);
});

test("emit rejects with the handler error and later handlers do not run", async () => {
  const bus = new HookBus();
  const boom = new Error("boom");
  let after = false;
  bus.on("e", async () => {
    await new Promise((r) => setTimeout(r, 5));
    throw boom;
  });
  bus.on("e", () => {
    after = true;
  });
  await assert.rejects(() => bus.emit("e", undefined), (err) => err === boom);
  assert.equal(after, false);
});

test("unsubscribing during an emit does not stop the others in that emit", async () => {
  const bus = new HookBus();
  const seen: string[] = [];
  const off = bus.on("e", () => {
    off();
    seen.push("first");
  });
  bus.on("e", () => {
    seen.push("second");
  });
  await bus.emit("e", undefined);
  assert.deepEqual(seen, ["first", "second"]);
  await bus.emit("e", undefined);
  assert.deepEqual(seen, ["first", "second", "second"]);
});

test("audit plugin: notice once, output redacted before the log line", async () => {
  const bus = new HookBus();
  const audit: string[] = [];
  registerAuditPlugin(bus, audit);
  audit.push("start");
  const result = { tool: "login", output: "ok password=hunter2" };
  await bus.emit("tool.after", result);
  assert.deepEqual(audit, [
    "start",
    "notice: tool output is audited",
    "login: ok password=[redacted]",
  ]);
  await bus.emit("tool.after", { tool: "read", output: "safe" });
  assert.deepEqual(audit.slice(3), ["read: safe"]);
});