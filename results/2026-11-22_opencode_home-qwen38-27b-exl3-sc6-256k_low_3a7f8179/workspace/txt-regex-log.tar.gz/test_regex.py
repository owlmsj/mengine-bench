import re

ip = r"(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)"
ip_full = r"(?<![0-9a-zA-Z])" + ip + r"(?:\." + ip + r"){3}(?![0-9a-zA-Z])"
date = (r"(?<![0-9a-zA-Z])(\d{4}-(?:0[13578]|1[02])-(?:0[1-9]|[12]\d|3[01])"
        r"|\d{4}-(?:0[469]|11)-(?:0[1-9]|[12]\d|30)"
        r"|\d{4}-02-(?:0[1-9]|[12]\d|2[0-9]))(?![0-9a-zA-Z])")
pattern = r"^(?=.*" + ip_full + r").*" + date

with open(r"<WORKSPACE>\regex.txt", "w") as f:
    f.write(pattern)

log = open(r"<WORKSPACE>\server.log").read()
print("PATTERN:", pattern)
print("FINDALL:", re.findall(pattern, log, re.MULTILINE))

# extra edge cases
cases = [
    ("2026-04-02 INFO 10.12.0.7 build 2026-04-01", ["2026-04-01"]),   # last date
    ("2026-04-02 cache warm 2026-04-03", []),                          # no IP
    ("x2026-04-02 10.0.0.1 2026-04-03", ["2026-04-03"]),               # first date glued, last clean
    ("2026-02-29 1.2.3.4", ["2026-02-29"]),                            # Feb 29 always ok
    ("2026-02-30 1.2.3.4", []),                                        # Feb 30 invalid
    ("2026-04-31 1.2.3.4", []),                                        # Apr 31 invalid
    ("2026-04-30 1.2.3.4", ["2026-04-30"]),                            # Apr 30 ok
    ("256.1.1.1 2026-04-02", []),                                      # bad IP part
    ("10.0.0.01 2026-04-02", []),                                      # leading zero in IP
    ("010.0.0.1 2026-04-02", []),                                      # leading zero
    ("1.2.3.4.5 2026-04-02", ["2026-04-02"]),                          # 5-part: inner IP has dot neighbors, allowed
    ("a10.0.0.1 2026-04-02", []),                                      # letter before IP
    ("10.0.0.1a 2026-04-02", []),                                      # letter after IP
    ("2026-04-02 10.0.0.1 2026-04-05 2026-04-06", ["2026-04-06"]),     # last of three
    ("92026-04-02 10.0.0.1", []),                                      # digit before date
    ("2026-04-029 10.0.0.1", []),                                      # digit after date
    ("2026-13-01 10.0.0.1", []),                                       # bad month
    ("2026-00-10 10.0.0.1", []),                                       # bad month
    ("2026-04-00 10.0.0.1", []),                                       # day 00
    ("2026-04-02 10.0.0.1", ["2026-04-02"]),                           # simple
]
ok = True
for text, expected in cases:
    got = re.findall(pattern, text, re.MULTILINE)
    status = "OK " if got == expected else "FAIL"
    if got != expected:
        ok = False
    print(f"{status} {text!r} -> {got} (expected {expected})")
print("ALL OK" if ok else "SOME FAILED")