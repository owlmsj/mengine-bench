import csv, statistics

rows = []
with open(r"capture/presentmon.csv") as f:
    for r in csv.DictReader(f):
        rows.append((float(r["TimeInSeconds"]), float(r["MsBetweenPresents"])))

fts = [t for _, t in rows]
n = len(fts)
mean = sum(fts) / n
avg_fps = 1000.0 / mean
s = sorted(fts)
p99 = s[int(0.99 * (n - 1))]
low1 = 1000.0 / p99
print(f"frames={n} mean_ms={mean:.4f} avg_fps={avg_fps:.2f} p99_ms={p99:.3f} low1={low1:.2f}")

# find hitches: frame times > 2x median
med = statistics.median(fts)
hitches = [(t, ft) for t, ft in rows if ft > 2 * med]
print(f"median_ms={med:.3f} hitches(>2x median)={len(hitches)}")
for t, ft in hitches:
    print(f"  t={t:.3f}s ft={ft:.2f}ms")

# distribution buckets
buckets = {}
for ft in fts:
    b = round(ft / 5) * 5
    buckets[b] = buckets.get(b, 0) + 1
for b in sorted(buckets):
    print(f"  {b}-{b+5}ms: {buckets[b]}")