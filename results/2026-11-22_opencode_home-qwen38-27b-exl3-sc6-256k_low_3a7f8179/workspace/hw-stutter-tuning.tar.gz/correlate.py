import csv

rows = []
with open(r"capture/presentmon.csv") as f:
    for r in csv.DictReader(f):
        rows.append((float(r["TimeInSeconds"]), float(r["MsBetweenPresents"])))

# L1 seconds from sensors
l1 = set()
with open(r"capture/sensors.csv") as f:
    for r in csv.DictReader(f):
        if r["gpu_pcie_link_state"] == "L1":
            l1.add(int(r["time_s"]))
print("L1 seconds:", sorted(l1))

# hitches per second
from collections import Counter
c = Counter()
for t, ft in rows:
    if ft > 15:
        c[int(t)] += 1
print("hitch-frames per second:", dict(sorted(c.items())))

# check: do all hitch-frames fall in L1 seconds?
in_l1 = sum(1 for t, ft in rows if ft > 15 and int(t) in l1)
total_h = sum(1 for t, ft in rows if ft > 15)
print(f"hitch frames in L1 seconds: {in_l1}/{total_h}")

# Defender window
dpc = []
with open(r"capture/sensors.csv") as f:
    for r in csv.DictReader(f):
        if int(r["dpc_latency_us"]) > 200:
            dpc.append((int(r["time_s"]), r["dpc_latency_us"], r["top_cpu_process"]))
print("high DPC:", dpc)