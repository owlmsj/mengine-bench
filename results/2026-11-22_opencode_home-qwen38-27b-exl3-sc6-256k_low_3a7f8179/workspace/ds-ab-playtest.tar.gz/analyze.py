import csv, json, math
from collections import Counter

path = r"<WORKSPACE>\telemetry\playtest_ab.csv"

sessions = {}  # session_id -> (variant, completed)
conflicts = 0
with open(path, newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        sid = row["session_id"].strip()
        variant = row["variant"].strip().lower()
        comp = int(row["completed_tutorial"])
        if sid in sessions:
            if sessions[sid] != (variant, comp):
                conflicts += 1
        sessions[sid] = (variant, comp)

a = [c for v, c in sessions.values() if v == "a"]
b = [c for v, c in sessions.values() if v == "b"]
other = [v for v, c in sessions.values() if v not in ("a", "b")]

n_a, n_b = len(a), len(b)
x_a, x_b = sum(a), sum(b)
p_a, p_b = x_a / n_a, x_b / n_b
p_pool = (x_a + x_b) / (n_a + n_b)
se = math.sqrt(p_pool * (1 - p_pool) * (1 / n_a + 1 / n_b))
z = (p_b - p_a) / se
# two-sided p-value via normal CDF (erf)
p_value = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))

print(f"rows deduped: {len(sessions)} sessions, conflicts: {conflicts}, other variants: {other}")
print(f"A: n={n_a} completed={x_a} rate={p_a:.6f}")
print(f"B: n={n_b} completed={x_b} rate={p_b:.6f}")
print(f"z={z:.6f} p={p_value:.6f}")

result = {
    "ship_b": bool(p_value < 0.05 and p_b > p_a),
    "sessions_a": n_a,
    "sessions_b": n_b,
    "completion_rate_a": round(p_a, 6),
    "completion_rate_b": round(p_b, 6),
    "p_value": round(p_value, 6),
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))