import sqlite3
c = sqlite3.connect('analytics.db')
for name, sql in c.execute("SELECT name, sql FROM sqlite_master WHERE type='table'"):
    print('==', name)
    print(sql)
    n = c.execute(f"SELECT COUNT(*) FROM {name}").fetchone()[0]
    print('rows:', n)
    for row in c.execute(f"SELECT * FROM {name} LIMIT 5"):
        print(row)