import sqlite3
c = sqlite3.connect('analytics.db')
print('events with unknown user_id:')
print(c.execute("SELECT COUNT(*) FROM events e WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.user_id=e.user_id)").fetchone())
print('test users:', c.execute("SELECT COUNT(*) FROM users WHERE is_test=1").fetchone())
print('distinct platforms:', c.execute("SELECT platform, COUNT(*) FROM users GROUP BY platform").fetchall())
print('event names:', c.execute("SELECT name, COUNT(*) FROM events GROUP BY name").fetchall())
# check out-of-order: player has later step before earlier step
import itertools
rows = c.execute("SELECT user_id, name, ts FROM events").fetchall()
from collections import defaultdict
ev = defaultdict(list)
for uid, name, ts in rows:
    ev[uid].append((ts, name))
STEPS = ['install','tutorial_complete','first_match','purchase']
ooo = 0
for uid, lst in ev.items():
    first = {}
    for ts, name in lst:
        if name in STEPS and name not in first:
            first[name] = ts
    for i in range(1, len(STEPS)):
        a, b = STEPS[i-1], STEPS[i]
        if a in first and b in first and first[b] < first[a]:
            ooo += 1
            break
print('users with out-of-order first occurrences:', ooo)