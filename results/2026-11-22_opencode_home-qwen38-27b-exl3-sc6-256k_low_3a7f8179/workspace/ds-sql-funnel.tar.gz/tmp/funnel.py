import sqlite3, json
from collections import defaultdict

STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']

c = sqlite3.connect('analytics.db')
users = {}
for uid, platform, is_test in c.execute("SELECT user_id, platform, is_test FROM users"):
    users[uid] = (platform, is_test)

# group events per user
ev = defaultdict(list)
for uid, name, ts in c.execute("SELECT user_id, name, ts FROM events"):
    ev[uid].append((ts, name))

# per platform: count players reaching each step
funnel = defaultdict(lambda: {s: 0 for s in STEPS})
for uid, (platform, is_test) in users.items():
    if is_test:
        continue
    times = {}
    for ts, name in ev.get(uid, []):
        if name in STEPS and name not in times:
            times[name] = ts  # first occurrence
    # walk steps in order: each step valid only if at/after previous step time
    prev = None
    for s in STEPS:
        if s in times:
            t = times[s]
            if prev is None or t >= prev:
                funnel[platform][s] += 1
                prev = t
            # else: out-of-order event, not counted (and does not advance prev)

result = {'funnel': {}, 'biggest_drop': {}}
for platform in sorted(funnel):
    f = funnel[platform]
    result['funnel'][platform] = f
    # conversions: step over previous step
    drops = []
    for i, s in enumerate(STEPS):
        if i == 0:
            continue
        prev_s = STEPS[i-1]
        prev_n = f[prev_s]
        conv = (f[s] / prev_n) if prev_n > 0 else None
        drops.append((s, conv))
    # biggest drop = step with lowest conversion (among defined)
    defined = [(s, cv) for s, cv in drops if cv is not None]
    if defined:
        worst = min(defined, key=lambda x: x[1])
        result['biggest_drop'][platform] = worst[0]
    else:
        result['biggest_drop'][platform] = None

print(json.dumps(result, indent=2))
with open('result.json', 'w') as fh:
    json.dump(result, fh, indent=2)