data = open('prices.db','rb').read()
# From hex dump, tail region around offset ~3940:
# "0A-04-00-27-07-66-69-72-73-74-20-61-69-64-20-62-69-74-3F-..."
# Let me find "first aid" in the file
idx = data.find(b'first aid')
print('first aid at', idx)
# print 40 bytes before and 40 after
start = max(0, idx-40)
print(data[start:idx+40].hex(' '))
# The cell should start a bit before: varint payload_len, varint rowid, record
# record: header_size varint, serial types..., then values
# "first aid bit" is the item string. Let's look for the cell start.
# Try: at some offset, varint plen, varint rowid, then record header
for i in range(idx-30, idx):
    b0 = data[i]
    # single-byte varint
    if b0 < 0x80:
        plen = b0
        j = i+1
        if j < len(data) and data[j] < 0x80:
            rowid = data[j]
            j2 = j+1
            # record header
            if j2 < len(data) and data[j2] < 0x80:
                hsize = data[j2]
                # check: hsize bytes of serial types starting at j2
                # then values
                print(f'candidate cell at {i}: plen={plen} rowid={rowid} hsize={hsize}')
                # dump the record
                rec = data[j2:j2+30]
                print('  record bytes:', rec.hex(' '))