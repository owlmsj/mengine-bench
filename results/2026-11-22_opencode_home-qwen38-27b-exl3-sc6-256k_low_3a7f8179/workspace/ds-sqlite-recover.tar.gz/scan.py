import struct, json

data = open('prices.db','rb').read()

def varint(b, i):
    v = 0
    for n in range(9):
        if i+n >= len(b):
            return None, None
        byte = b[i+n]
        if n == 8:
            v = (v << 8) | byte
            return v, i+9
        v = (v << 7) | (byte & 0x7F)
        if not (byte & 0x80):
            return v, i+n+1
    return v, i+9

def decode_record(b, i):
    hsize, j = varint(b, i)
    if hsize is None or hsize < 1 or hsize > 100:
        return None
    if j + hsize > len(b):
        return None
    types = []
    while j < i + hsize:
        t, j = varint(b, j)
        if t is None:
            return None
        types.append(t)
    vals = []
    k = i + hsize
    for t in types:
        if t == 0:
            vals.append(None)
        elif t == 1:
            if k+1 > len(b): return None
            vals.append(struct.unpack('>b', b[k:k+1])[0]); k += 1
        elif t == 2:
            if k+2 > len(b): return None
            vals.append(struct.unpack('>h', b[k:k+2])[0]); k += 2
        elif t == 3:
            if k+3 > len(b): return None
            vals.append(int.from_bytes(b[k:k+3],'big',signed=True)); k += 3
        elif t == 4:
            if k+4 > len(b): return None
            vals.append(struct.unpack('>i', b[k:k+4])[0]); k += 4
        elif t == 5:
            if k+6 > len(b): return None
            vals.append(int.from_bytes(b[k:k+6],'big',signed=True)); k += 6
        elif t == 6:
            if k+8 > len(b): return None
            vals.append(struct.unpack('>q', b[k:k+8])[0]); k += 8
        elif t == 7:
            if k+8 > len(b): return None
            vals.append(struct.unpack('>d', b[k:k+8])[0]); k += 8
        elif t == 8:
            vals.append(0)
        elif t == 9:
            vals.append(1)
        elif t >= 12 and t % 2 == 0:
            n = (t-12)//2
            if k+n > len(b): return None
            vals.append(b[k:k+n].decode('utf-8', errors='replace')); k += n
        elif t >= 13 and t % 2 == 1:
            n = (t-13)//2
            if k+n > len(b): return None
            vals.append(b[k:k+n]); k += n
        else:
            return None
    return vals

# Scan: cell = varint(plen) varint(rowid) record
# plen = (rowid varint bytes) + (record bytes)
rows = []
for i in range(len(data)-3):
    plen, j = varint(data, i)
    if plen is None or plen < 5 or plen > 2000:
        continue
    rowid, j2 = varint(data, j)
    if rowid is None or rowid < 1 or rowid > 1000000:
        continue
    # record occupies from j2 to i+plen
    if i + plen > len(data):
        continue
    vals = decode_record(data, j2)
    if vals is None:
        continue
    if len(vals) != 2:
        continue
    item, price = vals
    if not isinstance(item, str) or not item.isprintable() or not item:
        continue
    if not isinstance(price, (int, float)) or isinstance(price, bool):
        continue
    if not (0 < price < 1000000):
        continue
    rows.append((i, rowid, item, price))

# dedupe by rowid
seen = set()
out = []
for i, rowid, item, price in rows:
    if rowid in seen:
        continue
    seen.add(rowid)
    out.append((rowid, item, price))
    print(f'offset={i} rowid={rowid} item={item!r} price={price}')

print('total rows:', len(out))
result = [{"item": item, "price": price} for rowid, item, price in sorted(out)]
with open('recovered.json','w',encoding='utf-8') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
print('wrote recovered.json')