import struct, json

data = open('prices.db','rb').read()
print('file size:', len(data))

# Page 1 header
magic = data[:16].decode('latin1')
print('magic:', magic)
page_size = struct.unpack('>H', data[16:18])[0]
print('page size:', page_size)

# Page 1 is page 1 (sqlite_master). Leaf table b-tree header at offset 100.
off = 100
ptype = data[off]
ncells = struct.unpack('>H', data[off+1:off+3])[0]
print('page1 type:', ptype, 'ncells:', ncells)
cellptrs = struct.unpack('>%dH' % ncells, data[off+8:off+8+2*ncells])
print('cellptrs:', cellptrs)

def varint(b, i):
    v = 0
    for n in range(9):
        byte = b[i+n]
        if n == 8:
            v = (v << 8) | byte
            return v, i+9
        v = (v << 7) | (byte & 0x7F)
        if not (byte & 0x80):
            return v, i+n+1
    return v, i+9

def record_payload(b, i):
    # header size varint
    hsize, j = varint(b, i)
    types = []
    while j < i + hsize:
        t, j = varint(b, j)
        types.append(t)
    vals = []
    k = i + hsize
    for t in types:
        if t == 0:
            vals.append(None)
        elif t == 1:
            vals.append(struct.unpack('>b', b[k:k+1])[0]); k += 1
        elif t == 2:
            vals.append(struct.unpack('>h', b[k:k+2])[0]); k += 2
        elif t == 3:
            vals.append(int.from_bytes(b[k:k+3],'big',signed=True)); k += 3
        elif t == 4:
            vals.append(struct.unpack('>i', b[k:k+4])[0]); k += 4
        elif t == 5:
            vals.append(int.from_bytes(b[k:k+6],'big',signed=True)); k += 6
        elif t == 6:
            vals.append(struct.unpack('>q', b[k:k+8])[0]); k += 8
        elif t == 7:
            vals.append(struct.unpack('>d', b[k:k+8])[0]); k += 8
        elif t == 8:
            vals.append(0)
        elif t == 9:
            vals.append(1)
        elif t >= 12 and t % 2 == 0:
            n = (t-12)//2
            vals.append(b[k:k+n].decode('utf-8', errors='replace')); k += n
        elif t >= 13 and t % 2 == 1:
            n = (t-13)//2
            vals.append(b[k:k+n]); k += n
        else:
            raise ValueError('bad type %d' % t)
    return vals

rows = []
for cp in cellptrs:
    plen, j = varint(data, cp)
    rowid, j2 = varint(data, j)
    vals = record_payload(data, j2)
    rows.append((rowid, vals))
    print('rowid', rowid, vals)

# Now scan the rest of the file for the price table leaf page.
# The tail we saw: after page 1 (4096 bytes) there is nothing else (file is 4096).
# Wait: file is 4096 bytes = exactly one page. But we saw cell content at the tail of page 1?
# No - page 1 is the whole file. The tail content is part of page 1's cell area.
# But page 1 is sqlite_master with 10 cells... the tail bytes look like price rows though.
# Let's check: cellptrs point where?
for cp in cellptrs:
    print('cell at', cp, 'first bytes:', data[cp:cp+16].hex())