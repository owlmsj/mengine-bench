"""Batch task runner.

Provides ``run_tasks``: run zero-argument callables that return awaitable
jobs, with a bound on how many jobs run at once.

Assumptions (the brief leaves these open):
- A "job" is the awaitable returned by the task callable; the callable is
  invoked immediately (it is cheap), and the returned awaitable is what is
  awaited under the concurrency limit.
- ``max_concurrent`` is the maximum number of jobs awaiting simultaneously;
  it must be >= 1.
- Ctrl+C: ``KeyboardInterrupt`` is a BaseException, so a naive
  ``asyncio.gather`` would leave in-flight jobs' ``finally`` blocks (cleanup
  code) unrun. We catch the interrupt, cancel the in-flight jobs, and await
  them so their cleanup runs, then re-raise the interrupt.
- Exceptions from jobs are not swallowed: if any job raises, the first
  exception propagates after all jobs have finished (gather semantics).
- Standard library only, Python 3.11+.
"""

import asyncio
from typing import Awaitable, Callable, Sequence


async def run_tasks(tasks: Sequence[Callable[[], Awaitable[object]]],
                    max_concurrent: int) -> list:
    """Run ``tasks`` with at most ``max_concurrent`` jobs in flight.

    Each task is a zero-argument callable returning an awaitable job.
    Returns when every job is done. If any job raises, the first exception
    propagates once all jobs have finished. On Ctrl+C (KeyboardInterrupt),
    in-flight jobs are cancelled and awaited so their cleanup code runs,
    and the interrupt is then re-raised.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent!r}")

    semaphore = asyncio.Semaphore(max_concurrent)

    async def _run(task: Callable[[], Awaitable[object]]) -> object:
        async with semaphore:
            return await task()

    children = [asyncio.ensure_future(_run(t)) for t in tasks]
    try:
        results = await asyncio.gather(*children, return_exceptions=True)
    except BaseException:
        # Ctrl+C (KeyboardInterrupt) or cancellation of run_tasks itself:
        # cancel every in-flight job and await it so its finally/cleanup
        # blocks run, then propagate the original exception.
        for child in children:
            if not child.done():
                child.cancel()
        await asyncio.gather(*children, return_exceptions=True)
        raise
    # Propagate the first job exception (if any) after all jobs finished.
    for r in results:
        if isinstance(r, BaseException):
            raise r
    return results