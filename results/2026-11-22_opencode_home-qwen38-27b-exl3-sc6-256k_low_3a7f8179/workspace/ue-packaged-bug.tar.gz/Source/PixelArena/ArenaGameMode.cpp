#include "ArenaGameMode.h"

#include "ArenaHud.h"
#include "ArenaPalette.h"
#include "ArenaScoreTracker.h"
#include "ArenaStats.h"

DEFINE_LOG_CATEGORY_STATIC(LogArena, Log, All);

void AArenaGameMode::BeginPlay()
{
	Super::BeginPlay();

	Hud = NewObject<UArenaHud>(this);
	ScoreTracker = NewObject<UArenaScoreTracker>(this);
	Stats = new FArenaStats();

	Palette = LoadObject<UArenaPalette>(nullptr, TEXT("/Game/Data/Palettes/DA_Primary.DA_Primary"));
	if (!Palette)
	{
		UE_LOG(LogArena, Warning, TEXT("Palette is null, using fallback gray"));
	}
	Hud->ApplyPalette(Palette);
}

void AArenaGameMode::EndPlay(const EEndPlayReason::Type Reason)
{
	delete Stats;
	Stats = nullptr;
	Super::EndPlay(Reason);
}

void AArenaGameMode::OnGoalScored(int32 TeamIndex)
{
	// Guard against nulls: BeginPlay may not have run (e.g. streaming or
	// replication edge cases), and a missing palette asset leaves Hud null-safe
	// but ScoreTracker/Stats must never be dereferenced blindly.
	if (!Stats || !ScoreTracker || !Hud)
	{
		UE_LOG(LogArena, Warning, TEXT("OnGoalScored called before subsystems are ready (Stats=%p ScoreTracker=%p Hud=%p)"),
			(void*)Stats, (void*)ScoreTracker, (void*)Hud);
		return;
	}

	Stats->Goals++;
	ScoreTracker->AddPoints(TeamIndex, 1);
	Hud->ShowScore(TeamIndex, ScoreTracker->GetPoints(TeamIndex));
}
