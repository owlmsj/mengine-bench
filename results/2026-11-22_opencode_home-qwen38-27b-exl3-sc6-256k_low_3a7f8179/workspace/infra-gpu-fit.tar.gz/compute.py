import csv

# MODEL.md
weights_gb = 70  # 70e9 params * 1 byte (FP8) = 70 GB
kv_per_token = 327_680  # bytes
ctx = 32_768
seqs = 4
kv_gb = kv_per_token * ctx * seqs / 1e9  # 42.94967296 GB
overhead_gb = 8
total_gb = weights_gb + kv_gb + overhead_gb  # 120.94967296

print(f"weights_gb={weights_gb}")
print(f"kv_cache_gb={kv_gb}")
print(f"total_gb={total_gb}")

# POLICY.md
HOUR_CAP = 4.0
REGIONS = {"us-east", "us-central", "eu-west"}
HOURS = 730

rows = list(csv.DictReader(open("offers.csv")))
cands = []
for r in rows:
    if r["in_stock"] != "yes":
        print(f"skip {r['offer_id']}: out of stock")
        continue
    if r["region"] not in REGIONS:
        print(f"skip {r['offer_id']}: region {r['region']}")
        continue
    price = float(r["usd_per_hour"])
    if price > HOUR_CAP:
        print(f"skip {r['offer_id']}: ${price}/h over cap")
        continue
    mem = int(r["gpu_count"]) * float(r["vram_gb_per_gpu"])
    if mem < total_gb:
        print(f"skip {r['offer_id']}: {mem} GB < {total_gb:.4f} GB")
        continue
    cands.append((price, r["offer_id"], mem))
    print(f"OK   {r['offer_id']}: {mem} GB, ${price}/h, ${price*HOURS:.2f}/mo")

cands.sort()
best = cands[0]
print(f"\nBEST: {best[1]} ${best[0]}/h ${best[0]*HOURS:.2f}/mo")

import json
out = {
    "weights_gb": weights_gb,
    "kv_cache_gb": round(kv_gb, 4),
    "total_gb": round(total_gb, 4),
    "offer_id": best[1],
    "usd_per_hour": best[0],
    "usd_per_month": round(best[0] * HOURS, 2),
}
json.dump(out, open("result.json", "w"), indent=2)
print(json.dumps(out, indent=2))