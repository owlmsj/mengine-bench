# HANDOFF — local-9b at 128k

Goal: measure local-9b Q5_K at 128k context; make it fit.

Done (verbatim from session/transcript.md):
- Baseline (measure_decode.ps1 -Ctx 131072 -NPredict 1024): 37.8 t/s, VRAM 7881 MiB.
- 7881 MiB is the WDDM ceiling, not real usage: Shared Usage showed 1494 MiB spilled. That number does not count.
- Fix: --no-mmproj-offload + -ub 512 kills the spill. Final: 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k, discarded. Q4_K_M fits (7305 MiB, 40.4 t/s), fallback only.
- Recipe applied: scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

Left open (user asked "What is left?"):
1. Review names of the scratchpad temp files (noted repeatedly, never done).
2. Evals README still cites check_vision.ps1, which no longer exists — update it.

Assumptions: repo with scripts/ and profiles/ is where this session ran; paths relative to it. "Does not count" = 7881 MiB must not be reported as model VRAM.

How I know it is right: all numbers quoted verbatim from transcript lines 30, 44, 124, 132, 185, 222; fix measured after spill confirmed gone; recipe already applied in both files.