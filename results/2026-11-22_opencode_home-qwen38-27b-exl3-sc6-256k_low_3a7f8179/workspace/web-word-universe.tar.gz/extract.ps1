$site = "<WORKSPACE>\site"
$words = @{}
$files = Get-ChildItem -Path $site -Filter "*.html"
foreach ($f in $files) {
    $html = [IO.File]::ReadAllText($f.FullName, [Text.Encoding]::UTF8)
    # skip index, sobre, contato
    if ($f.Name -eq "index.html" -or $f.Name -eq "sobre.html" -or $f.Name -eq "contato.html") { continue }
    # word = h1 text
    $h1 = [regex]::Match($html, '<h1>(.*?)</h1>')
    $word = $h1.Groups[1].Value
    if ($word -eq "") { continue }
    # theme
    $tema = [regex]::Match($html, 'class="tema">Tema:\s*(.*?)</p>')
    $temaVal = $tema.Groups[1].Value
    # synonyms
    $sin = [regex]::Match($html, '<section id="sinonimos">.*?<ul>(.*?)</ul>')
    $sinLinks = @()
    if ($sin.Success) {
        $ms = [regex]::Matches($sin.Groups[1].Value, '<a href="([^"]+)">([^<]+)</a>')
        foreach ($m in $ms) { $sinLinks += $m.Groups[2].Value }
    }
    # analogas
    $ana = [regex]::Match($html, '<section id="analogas">.*?<ul>(.*?)</ul>')
    $anaLinks = @()
    if ($ana.Success) {
        $ms = [regex]::Matches($ana.Groups[1].Value, '<a href="([^"]+)">([^<]+)</a>')
        foreach ($m in $ms) { $anaLinks += $m.Groups[2].Value }
    }
    $words[$word] = @{ tema = $temaVal; sinonimos = $sinLinks; analogas = $anaLinks }
}
# build words.json: word -> linked words (union of sinonimos + analogas)
$linked = @{}
foreach ($w in $words.Keys) {
    $v = $words[$w]
    $all = @($v.sinonimos) + @($v.analogas)
    $unique = $all | Select-Object -Unique
    $linked[$w] = $unique
}
$json = $linked | ConvertTo-Json -Depth 5
$json | Out-File -FilePath "<WORKSPACE>\words.json" -Encoding UTF8
Write-Host "words count: $($words.Count)"
# count distinct pairs
$pairs = @{}
foreach ($w in $words.Keys) {
    foreach ($l in $linked[$w]) {
        $key = ($w, $l) | Sort-Object | Join-String " "
        $pairs[$key] = $true
    }
}
Write-Host "distinct pairs: $($pairs.Count)"
# most connected
$counts = @{}
foreach ($w in $words.Keys) {
    $counts[$w] = $linked[$w].Count
}
$top = $counts.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 5
foreach ($t in $top) { Write-Host "  $($t.Key): $($t.Value)" }