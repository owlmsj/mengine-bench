$site = "<WORKSPACE>\site"
$words = @{}
$files = Get-ChildItem -Path $site -Filter "*.html"
foreach ($f in $files) {
    $html = [IO.File]::ReadAllText($f.FullName, [Text.Encoding]::UTF8)
    if ($f.Name -eq "index.html" -or $f.Name -eq "sobre.html" -or $f.Name -eq "contato.html") { continue }
    $h1 = [regex]::Match($html, '<h1>(.*?)</h1>')
    $word = $h1.Groups[1].Value
    if ($word -eq "") { continue }
    $sin = [regex]::Match($html, '<section id="sinonimos">.*?<ul>(.*?)</ul>')
    $sinLinks = @()
    if ($sin.Success) {
        $ms = [regex]::Matches($sin.Groups[1].Value, '<a href="([^"]+)">([^<]+)</a>')
        foreach ($m in $ms) { $sinLinks += $m.Groups[2].Value }
    }
    $ana = [regex]::Match($html, '<section id="analogas">.*?<ul>(.*?)</ul>')
    $anaLinks = @()
    if ($ana.Success) {
        $ms = [regex]::Matches($ana.Groups[1].Value, '<a href="([^"]+)">([^<]+)</a>')
        foreach ($m in $ms) { $anaLinks += $m.Groups[2].Value }
    }
    $words[$word] = @($sinLinks) + @($anaLinks) | Select-Object -Unique
}
$pairs = @{}
foreach ($w in $words.Keys) {
    foreach ($l in $words[$w]) {
        $a = $w.ToLower(); $b = $l.ToLower()
        if ($a -lt $b) { $key = "$a|$b" } else { $key = "$b|$a" }
        $pairs[$key] = $true
    }
}
$counts = @{}
foreach ($w in $words.Keys) { $counts[$w] = $words[$w].Count }
$top = $counts.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 1
$result = @{
    words = $words.Count
    relations = $pairs.Count
    most_connected = $top.Key
}
$json = $result | ConvertTo-Json
$json | Out-File -FilePath "<WORKSPACE>\result.json" -Encoding UTF8
Write-Host "words: $($words.Count)"
Write-Host "relations: $($pairs.Count)"
Write-Host "most_connected: $($top.Key) ($($top.Value))"