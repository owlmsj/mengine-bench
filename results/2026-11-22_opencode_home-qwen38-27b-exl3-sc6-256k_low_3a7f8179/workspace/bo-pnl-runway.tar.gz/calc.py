import csv, json

# account -> pnl line
coa = {}
with open('finance/chart_of_accounts.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        coa[row['account']] = row['pnl_line']

months = ['2026-01','2026-02','2026-03','2026-04','2026-05','2026-06']
# per month: revenue, cogs, opex (sm+rnd+ga), financial
rev = {m: 0.0 for m in months}
cogs = {m: 0.0 for m in months}
opex = {m: 0.0 for m in months}
fin = {m: 0.0 for m in months}

with open('finance/ledger.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        d = row['date']  # dd/mm/yyyy
        day, m, y = d.split('/')
        key = f'{y}-{m}'
        amt = float(row['amount'].replace('.', '').replace(',', '.'))
        line = coa[row['account']]
        if line == 'revenue':
            rev[key] += amt
        elif line == 'cogs':
            cogs[key] += amt
        elif line == 'financial':
            fin[key] += amt
        else:
            opex[key] += amt

result = {'revenue': {}, 'gross_margin_pct': {}, 'ebitda': {}, }
for m in months:
    r = rev[m]
    g = cogs[m]
    gm = (r + g) / r * 100 if r else 0.0  # cogs negative
    ebitda = r + g + opex[m]  # exclude financial
    result['revenue'][m] = round(r, 2)
    result['gross_margin_pct'][m] = round(gm, 2)
    result['ebitda'][m] = round(ebitda, 2)

# burn: avg monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = [result['ebitda'][m] for m in ['2026-04','2026-05','2026-06']]
neg = [abs(x) for x in last3 if x < 0]
burn = sum(neg) / len(neg)
cash = 1847350.40
runway = cash / burn
result['burn'] = round(burn, 2)
result['runway_months'] = round(runway, 2)

print(json.dumps(result, indent=2))
with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2)