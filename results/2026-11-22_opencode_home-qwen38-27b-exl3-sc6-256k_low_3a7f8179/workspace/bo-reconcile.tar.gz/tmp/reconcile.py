import csv, json, re, os

base = r"<WORKSPACE>"
invoices = {}
with open(os.path.join(base, "backoffice", "invoices.csv"), encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = float(row["amount"])

payments = {}  # id -> list of amounts
with open(os.path.join(base, "backoffice", "bank_statement_june.csv"), encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        m = re.search(r"10(\d{2})", memo)
        if not m:
            continue  # no identifiable invoice (fees, interest, unidentified PIX)
        inv_id = "INV-" + m.group(0)
        if inv_id not in invoices:
            continue
        payments.setdefault(inv_id, []).append(float(row["amount"]))

unpaid, duplicated, mismatched = [], [], []
for inv_id in sorted(invoices):
    amts = payments.get(inv_id, [])
    if not amts:
        unpaid.append(inv_id)
    elif len(amts) > 1:
        duplicated.append(inv_id)
    elif abs(amts[0] - invoices[inv_id]) > 0.005:
        mismatched.append({"id": inv_id, "invoiced": invoices[inv_id], "paid": amts[0]})

result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
out = os.path.join(base, "result.json")
with open(out, "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))