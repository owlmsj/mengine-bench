from PIL import Image, ImageDraw, ImageFont
W,H = 1200,675
img = Image.new('RGB',(W,H),(18,60,110))
d = ImageDraw.Draw(img)
d.rectangle([0, 420, W, H], fill=(235, 180, 90))
d.ellipse([430,180,770,440], fill=(250,220,140))
d.rectangle([0,480,W,H], fill=(10,40,80))
for x,y in [(250,220),(330,190),(900,240)]:
    d.line([x-30,y+10,x,y], fill=(20,30,50), width=5)
    d.line([x,y,x+30,y+10], fill=(20,30,50), width=5)
try:
    font = ImageFont.truetype('arial.ttf', 110)
except Exception:
    font = ImageFont.load_default()
try:
    sub = ImageFont.truetype('arial.ttf', 40)
except Exception:
    sub = font
text = "Harbor Day 2026"
bbox = d.textbbox((0,0), text, font=font)
tw = bbox[2]-bbox[0]
d.text(((W-tw)/2, 100), text, fill=(255,255,255), font=font)
t2 = "North Cove  |  Saturday 07:00"
b2 = d.textbbox((0,0), t2, font=sub)
tw2 = b2[2]-b2[0]
d.text(((W-tw2)/2, 560), t2, fill=(255,255,255), font=sub)
img.save('cover.png')
print('saved', img.size)
