import sqlite3, json
con = sqlite3.connect('analytics.db')
steps = ['install','tutorial_complete','first_match','purchase']
users = {}
for uid, platform, is_test in con.execute('select user_id, platform, is_test from users'):
    if is_test:
        continue
    users[uid] = platform
events = {}
for uid, name, ts in con.execute('select user_id, name, ts from events'):
    if uid not in users:
        continue
    events.setdefault(uid, []).append((ts, name))
funnel = {}
big = {}
for platform in ['pc','steamdeck']:
    cnt = {s: 0 for s in steps}
    for uid, evs in events.items():
        if users[uid] != platform:
            continue
        prev_ts = None
        for step in steps:
            cand = [ts for ts, n in evs if n == step and (prev_ts is None or ts >= prev_ts)]
            if not cand:
                break
            t = min(cand)
            cnt[step] += 1
            prev_ts = t
    funnel[platform] = cnt
    convs = {}
    for i, step in enumerate(steps[1:], 1):
        p = steps[i-1]
        convs[step] = cnt[step] / cnt[p] if cnt[p] else None
    big[platform] = min(convs, key=lambda s: convs[s])
result = {'funnel': funnel, 'biggest_drop': big}
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
