const fs = require('fs');
const a = fs.readdirSync('./site').filter(f => f.toLowerCase().includes('av'));
console.log(a);
for (const f of a) {
  console.log('=====', JSON.stringify(f));
  const h = fs.readFileSync('./site/' + f, 'utf8');
  const m = h.match(/<h1>(.*?)<\/h1>/);
  console.log('h1:', m && m[1]);
  const s = h.match(/<section id="analogas">([\s\S]*?)<\/section>/);
  console.log('analogas:', s && s[1].slice(0, 700));
}
