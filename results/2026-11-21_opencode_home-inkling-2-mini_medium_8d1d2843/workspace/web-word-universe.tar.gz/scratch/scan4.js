const fs = require('fs');
const files = fs.readdirSync('./site').filter(f => f.endsWith('.html'));
let noh1 = 0, notema = 0, nosect = 0, noh1target = [];
for (const f of files) {
  const h = fs.readFileSync('./site/' + f, 'utf8');
  if (h.includes('http-equiv')) continue;
  if (f === 'index.html' || f === 'sobre.html' || f === 'contato.html') continue;
  if (!h.match(/<h1>(.*?)<\/h1>/)) { noh1++; noh1target.push(f); }
  if (!h.includes('tema')) { notema++; noh1target.push('no-tema ' + f); }
  const m = h.match(/<section id="analogas">([\s\S]*?)<\/section>/);
  if (!m) nosect++;
}
console.log({ noh1, notema, nosect });
console.log(noh1target.join('\n'));
