const fs = require('fs');
const files = fs.readdirSync('./site').filter(f => f.endsWith('.html'));
for (const f of files) {
  if (/[^\x20-\x7E]/.test(f)) console.log(JSON.stringify(f));
}
