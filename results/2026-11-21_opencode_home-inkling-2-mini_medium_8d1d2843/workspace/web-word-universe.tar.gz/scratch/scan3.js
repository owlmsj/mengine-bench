const fs = require('fs');
const files = fs.readdirSync('./site').filter(f => f.endsWith('.html'));
for (const f of files) {
  const html = fs.readFileSync('./site/' + f, 'utf8');
  if (html.includes('http-equiv')) continue;
  const hasMain = html.includes('<main>');
  const hasTema = html.includes('<p class="tema">');
  const hasSect = html.includes('<section id=');
  if (!hasTema && !hasSect) console.log('NO-SECTIONS:', JSON.stringify(f));
  else if (!hasTema) console.log('NO-TEMA:', JSON.stringify(f));
  else if (!hasSect) console.log('NO-SECTIONS-2:', JSON.stringify(f));
}
