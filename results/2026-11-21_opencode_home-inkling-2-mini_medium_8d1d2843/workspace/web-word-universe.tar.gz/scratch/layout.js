const fs = require('fs');
const words = JSON.parse(fs.readFileSync('./words.json', 'utf8'));
const keys = Object.keys(words);
const n = keys.length;
const idx = new Map(keys.map((k, i) => [k, i]));

// build edges (undirected, dedup)
const pairs = new Set();
for (const [k, v] of Object.entries(words)) {
  for (const t of v.links) {
    pairs.add([k, t].sort().join('|'));
  }
}
const edges = [...pairs].map(p => p.split('|').map(x => idx.get(x)));

// random seed (deterministic)
let seed = 42;
const rand = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };

// initial positions on sphere
const pos = new Float64Array(n * 3);
for (let i = 0; i < n; i++) {
  const u = rand() * 2 - 1;
  const th = rand() * Math.PI * 2;
  const r = Math.sqrt(1 - u * u);
  pos[i * 3] = r * Math.cos(th);
  pos[i * 3 + 1] = r * Math.sin(th);
  pos[i * 3 + 2] = u;
}

const k2 = 2.5; // repulsion coefficient
const springK = 0.012;
const ideal = 1.6;
const gravity = 0.06;
const damp = 0.72;
const vel = new Float64Array(n * 3);

for (let iter = 0; iter < 400; iter++) {
  // repulsion
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      const dx = pos[i*3] - pos[j*3], dy = pos[i*3+1] - pos[j*3+1], dz = pos[i*3+2] - pos[j*3+2];
      let d = Math.sqrt(dx*dx + dy*dy + dz*dz) || 0.01;
      const f = k2 / (d * d);
      const fx = (dx / d) * f, fy = (dy / d) * f, fz = (dz / d) * f;
      vel[i*3] += fx; vel[i*3+1] += fy; vel[i*3+2] += fz;
      vel[j*3] -= fx; vel[j*3+1] -= fy; vel[j*3+2] -= fz;
    }
  }
  // springs
  for (const [a, b] of edges) {
    const dx = pos[a*3] - pos[b*3], dy = pos[a*3+1] - pos[b*3+1], dz = pos[a*3+2] - pos[b*3+2];
    const d = Math.sqrt(dx*dx + dy*dy + dz*dz) || 0.01;
    const f = (d - ideal) * springK;
    const fx = (dx / d) * f, fy = (dy / d) * f, fz = (dz / d) * f;
    vel[a*3] -= fx; vel[a*3+1] -= fy; vel[a*3+2] -= fz;
    vel[b*3] += fx; vel[b*3+1] += fy; vel[b*3+2] += fz;
  }
  // gravity to center
  for (let i = 0; i < n; i++) {
    vel[i*3] -= pos[i*3] * gravity; vel[i*3+1] -= pos[i*3+1] * gravity; vel[i*3+2] -= pos[i*3+2] * gravity;
    vel[i*3] *= damp; vel[i*3+1] *= damp; vel[i*3+2] *= damp;
    pos[i*3] += vel[i*3]; pos[i*3+1] += vel[i*3+1]; pos[i*3+2] += vel[i*3+2];
  }
}

// normalize to radius ~1.9
let maxR = 0;
for (let i = 0; i < n; i++) {
  const r = Math.sqrt(pos[i*3]**2 + pos[i*3+1]**2 + pos[i*3+2]**2);
  if (r > maxR) maxR = r;
}
const scale = 1.9 / maxR;
const coords = keys.map((k, i) => [
  pos[i*3] * scale,
  pos[i*3+1] * scale,
  pos[i*3+2] * scale
]);

const themes = new Map();
for (const [k, v] of Object.entries(words)) {
  if (!themes.has(v.theme)) themes.set(v.theme, []);
  themes.get(v.theme).push(k);
}
console.log('themes:', [...themes.keys()]);

const out = {
  words: keys.map((k, i) => ({
    id: k,
    display: words[k].display,
    theme: words[k].theme,
    links: words[k].links,
    pos: coords[i]
  })),
  edges: edges.map(([a, b]) => [keys[a], keys[b]])
};
fs.writeFileSync('./scratch/layout.json', JSON.stringify(out));
console.log('saved layout.json, nodes:', out.words.length, 'edges:', out.edges.length);
