const fs = require('fs');
const files = fs.readdirSync('./site').filter(f => f.endsWith('.html'));

// redirect map
const redir = {};
for (const f of files) {
  const h = fs.readFileSync('./site/' + f, 'utf8');
  const m = h.match(/url=([^'"\s>]+)/);
  if (h.includes('http-equiv') && m) redir[decodeURIComponent(f)] = decodeURIComponent(m[1]);
}
console.log('redirects:', JSON.stringify(redir));

function resolve(href) {
  let target = decodeURIComponent(href.split('#')[0].split('?')[0]);
  target = target.replace(/^\.\//, '');
  const seen = new Set();
  while (redir[target] && !seen.has(target)) { seen.add(target); target = redir[target]; }
  return target;
}

const words = new Map(); // key -> { display, theme, file }
const broken = [];
for (const f of files) {
  if (f === 'index.html' || f === 'sobre.html' || f === 'contato.html') continue;
  const html = fs.readFileSync('./site/' + f, 'utf8');
  if (html.includes('http-equiv')) continue;
  const key = f.replace(/\.html$/i, '').toLowerCase();
  const h1 = (html.match(/<h1>(.*?)<\/h1>/) || [])[1] || '';
  const tema = (html.match(/<p class="tema">(.*?)<\/p>/) || [])[1] || '';
  const theme = tema.replace(/^Tema:\s*/i, '').trim();
  words.set(key, { display: h1.trim(), theme, file: f });
}
const edges = new Map();
for (const key of words.keys()) edges.set(key, new Set());
for (const [key, w] of words) {
  const html = fs.readFileSync('./site/' + w.file, 'utf8');
  const main = html.match(/<main>([\s\S]*?)<\/main>/);
  if (!main) continue;
  const links = main[1].match(/<a href="([^"]+)"[^>]*>([^<]*)<\/a>/g) || [];
  for (const l of links) {
    const hm = l.match(/href="([^"]+)"/);
    if (!hm) continue;
    const href = hm[1];
    if (!/\.html$/i.test(decodeURIComponent(href.split('#')[0]))) continue;
    const target = resolve(href).replace(/\.html$/i, '').toLowerCase();
    if (!target) continue;
    if (target === key) continue;
    if (words.has(target)) edges.get(key).add(target);
    else broken.push(key + ' -> ' + target);
  }
}

const brokenSet = new Set(broken);
console.log('broken links:', brokenSet.size);
for (const b of brokenSet) console.log('  ', b);

// undirected degree: count each distinct pair once
const pairSet = new Set();
for (const [k, targets] of edges) {
  for (const t of targets) pairSet.add([k, t].sort().join('|'));
}
console.log('words:', words.size);
console.log('distinct pairs (undirected):', pairSet.size);

const degree = new Map();
for (const [k, targets] of edges) degree.set(k, new Set(targets));
for (const [k, targets] of edges) {
  for (const t of targets) {
    if (!degree.has(t)) degree.set(t, new Set());
    degree.get(t).add(k);
  }
}
let most = null, maxDeg = -1;
for (const [k, set] of degree) {
  if (set.size > maxDeg) { maxDeg = set.size; most = k; }
}
console.log('most_connected:', most, maxDeg);
const ranked = [...degree.entries()].sort((a, b) => b[1].size - a[1].size).slice(0, 10);
for (const [k, s] of ranked) console.log('  top:', k, s.size);

const out = {};
for (const [k, w] of words) {
  const set = degree.get(k) || new Set();
  out[k] = { display: w.display, theme: w.theme, links: [...set].sort() };
}
fs.writeFileSync('./words.json', JSON.stringify(out, null, 2));

const counts = { words: words.size, relations: pairSet.size, most_connected: most };
fs.writeFileSync('./result.json', JSON.stringify(counts, null, 2));
console.log('saved words.json and result.json');
