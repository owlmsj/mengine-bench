const fs = require('fs');
const files = fs.readdirSync('./site').filter(f => f.endsWith('.html'));
const redirects = [], mains = [];
for (const f of files) {
  const html = fs.readFileSync('./site/' + f, 'utf8');
  if (html.includes('http-equiv')) redirects.push(f); else mains.push(f);
}
console.log('redirects:', JSON.stringify(redirects));
console.log('main pages:', mains.length);
