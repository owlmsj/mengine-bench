"""Batch task runner with bounded concurrency."""

import asyncio
from typing import Any, Awaitable, Callable, Iterable, List, TypeVar

T = TypeVar("T")


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[Any]]],
    max_concurrent: int,
) -> List[Any]:
    """Run tasks with at most ``max_concurrent`` jobs in flight.

    Each task is a zero-argument callable returning an awaitable job.
    Returns a list of job results (one per task, in input order) when every
    job completed without error. If any job raised, the first such exception
    is re-raised after every job has finished (cleanup still runs).

    If the caller is interrupted (e.g. Ctrl+C), pending jobs are cancelled
    and awaited, so ``finally`` blocks inside the jobs run before the
    cancellation propagates.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent!r}")

    semaphore = asyncio.Semaphore(max_concurrent)

    async def run_one(task: Callable[[], Awaitable[Any]]) -> Any:
        async with semaphore:
            return await task()

    results = await asyncio.gather(
        *(run_one(task) for task in tasks), return_exceptions=True
    )

    for result in results:
        if isinstance(result, BaseException):
            raise result

    return results
