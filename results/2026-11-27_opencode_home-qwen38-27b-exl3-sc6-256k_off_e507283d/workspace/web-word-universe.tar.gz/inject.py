import json

with open("words.json", encoding="utf-8") as f:
    words = json.load(f)

# theme per word: re-derive from site
import os, re, html as H
themes = {}
for fn in os.listdir("site"):
    if not fn.endswith(".html") or fn in ("index.html","sobre.html","contato.html"):
        continue
    txt = open(os.path.join("site",fn), encoding="utf-8").read()
    m = re.search(r"<h1>(.*?)</h1>", txt)
    t = re.search(r'class="tema">Tema:\s*(.*?)</p>', txt)
    if m and t:
        themes[H.unescape(m.group(1)).strip()] = H.unescape(t.group(1)).strip()

words_json = json.dumps(words, ensure_ascii=False)
themes_json = json.dumps(themes, ensure_ascii=False)

path = "universe/index.html"
s = open(path, encoding="utf-8").read()
s = s.replace("__WORDS__", words_json)
s = s.replace("__THEMES__", themes_json)
open(path, "w", encoding="utf-8").write(s)
print("injected", len(words), "words,", len(themes), "themes")
print("saudade links:", words.get("saudade"))