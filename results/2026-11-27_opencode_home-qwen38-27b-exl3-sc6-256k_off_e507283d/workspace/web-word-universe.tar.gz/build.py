import json, os, re, unicodedata, html

site = "site"
files = os.listdir(site)

def norm(s):
    s = unicodedata.normalize("NFD", s)
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.lower()

def slug_to_word(slug):
    w = slug[:-5]  # strip .html
    w = html.unescape(w)
    return w

words = {}  # word -> {"theme":..., "links": set}
for f in files:
    if not f.endswith(".html"):
        continue
    if f in ("index.html", "sobre.html", "contato.html"):
        continue
    path = os.path.join(site, f)
    with open(path, encoding="utf-8") as fh:
        txt = fh.read()
    m = re.search(r"<h1>(.*?)</h1>", txt)
    if not m:
        continue
    word = html.unescape(m.group(1)).strip()
    theme_m = re.search(r'class="tema">Tema:\s*(.*?)</p>', txt)
    theme = html.unescape(theme_m.group(1)).strip() if theme_m else None
    links = set()
    for sec in re.finditer(r'<section id="(sinonimos|analogas)">.*?</section>', txt, re.S):
        for a in re.finditer(r'<a href="([^"]+)">([^<]+)</a>', sec.group(0)):
            href = a.group(1)
            if href.endswith(".html") and href not in ("index.html", "sobre.html", "contato.html"):
                links.add(slug_to_word(href))
    words[word] = {"theme": theme, "links": links}

# Build final map: word -> list of linked words (only links that exist as words)
out = {}
for w, d in words.items():
    out[w] = sorted(l for l in d["links"] if l in words)

# Distinct pairs
pairs = set()
for w, ls in out.items():
    for l in ls:
        pairs.add(tuple(sorted((w, l))))

deg = {w: len(ls) for w, ls in out.items()}
most = sorted(deg.items(), key=lambda kv: (-kv[1], kv[0]))

result = {
    "words": len(out),
    "relations": len(pairs),
    "most_connected": {"word": most[0][0], "degree": most[0][1]} if most else None,
}

with open("words.json", "w", encoding="utf-8") as fh:
    json.dump(out, fh, ensure_ascii=False, indent=1)
with open("result.json", "w", encoding="utf-8") as fh:
    json.dump(result, fh, ensure_ascii=False, indent=1)

print("words:", len(out))
print("relations:", len(pairs))
print("top10:", most[:10])
print("saudade:", out.get("saudade"))
print("themes:", sorted({d["theme"] for d in words.values() if d["theme"]}))
print("no-theme:", [w for w, d in words.items() if not d["theme"]])