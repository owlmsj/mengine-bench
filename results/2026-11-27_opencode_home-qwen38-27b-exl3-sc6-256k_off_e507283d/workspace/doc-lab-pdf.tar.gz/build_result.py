import json

# Alfa (first report, 10/02/2026) - native units
alfa = {
    "Glicose em jejum": {"date": "2026-02-10", "value": 92, "unit": "mg/dL", "ref": (70, 99)},
    "Colesterol LDL": {"date": "2026-02-10", "value": 118, "unit": "mg/dL", "ref": (None, 130)},  # desejavel < 130
    "Creatinina": {"date": "2026-02-10", "value": 0.95, "unit": "mg/dL", "ref": (0.70, 1.30)},
    "Hemoglobina glicada (HbA1c)": {"date": "2026-02-10", "value": 5.4, "unit": "%", "ref": (4.0, 5.6)},
}

# Beta (18/08/2026) - convert to Alfa units
# glucose: mmol/L * 18.016 = mg/dL
# LDL: mmol/L * 38.67 = mg/dL
# creatinine: umol/L / 88.42 = mg/dL
# HbA1c: mmol/mol -> % via IFCC: % = (mmol/mol + 23.5) / 1.5948
beta = {
    "Glicose em jejum": {"date": "2026-08-18", "value": 6.1 * 18.016, "unit": "mg/dL", "ref": (70, 99)},
    "Colesterol LDL": {"date": "2026-08-18", "value": 3.70 * 38.67, "unit": "mg/dL", "ref": (None, 130)},
    "Creatinina": {"date": "2026-08-18", "value": 76 / 88.42, "unit": "mg/dL", "ref": (0.70, 1.30)},
    "Hemoglobina glicada (HbA1c)": {"date": "2026-08-18", "value": (37 + 23.5) / 10.929, "unit": "%", "ref": (4.0, 5.6)},
}

markers = list(alfa.keys())
history = {}
worse = []

for m in markers:
    a, b = alfa[m], beta[m]
    history[m] = {a["date"]: round(a["value"], 2), b["date"]: round(b["value"], 2)}
    lo, hi = a["ref"]
    outside = (lo is not None and b["value"] < lo) or (hi is not None and b["value"] > hi)
    got_worse = b["value"] > a["value"]
    if got_worse and outside:
        worse.append(m)

result = {"history": history, "worse": worse}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)

print(json.dumps(result, ensure_ascii=False, indent=2))
for m in markers:
    print(m, "alfa:", alfa[m]["value"], "beta:", round(beta[m]["value"], 2), "ref:", alfa[m]["ref"])