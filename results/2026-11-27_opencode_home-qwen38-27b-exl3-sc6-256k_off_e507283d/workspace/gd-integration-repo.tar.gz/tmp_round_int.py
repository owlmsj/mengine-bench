# Round to nearest 10, halves up, using pure integer arithmetic.
# value in units of 1 (e.g. 1587.5 -> 15875 in tenths)
def round10(tenths):
    # tenths is an int representing value*10
    # round to nearest 10 = round(tenths/10) * 10, halves up
    # tenths/10 = tenths // 10 with remainder tenths % 10
    q, r = divmod(tenths, 10)
    if r >= 5:
        q += 1
    return q * 10

# doc examples: 1425 -> 1430, 1585 -> 1590
print("1425 ->", round10(14250))
print("1585 ->", round10(15850))
# integration test: (900 + 5*75) * 1.25 = 1593.75 -> 15940 tenths
print("1593.75 ->", round10(15937))
# 1587.5 -> 15875 tenths
print("1587.5 ->", round10(15875))