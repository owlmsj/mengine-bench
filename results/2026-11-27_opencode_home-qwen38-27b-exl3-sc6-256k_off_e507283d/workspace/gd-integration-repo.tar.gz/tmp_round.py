from decimal import Decimal, ROUND_HALF_UP

for v in ("1425", "1585", "1587.5", "1593.75"):
    print(v, "->", Decimal(v).quantize(Decimal("10"), rounding=ROUND_HALF_UP))