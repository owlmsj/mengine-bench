import json, tempfile
from pathlib import Path
from arena_server.config.loader import load_config
from arena_server.economy.payout import match_payout

tmp = Path(tempfile.mkdtemp())
f = tmp / "live.json"
f.write_text(json.dumps({"kill_bonus": 50, "event_multiplier": 1.25}))
cfg = load_config(f, env={"ARENA_KILL_BONUS": "75"})
print("cfg:", cfg)
print("payout:", match_payout(True, 5, cfg))
# manual
base = cfg["win_base"]
inner = base + 5 * cfg["kill_bonus"]
raw = inner * cfg["event_multiplier"]
print("inner:", inner, "raw:", raw)