# Derive the exact tenths math for the integration case.
# (900 + 5*75) * 1.25 = 1593.75
inner = 900 + 5 * 75
print("inner:", inner)  # 1275
# multiplier 1.25 = 125/100
mult_num, mult_den = 125, 100
# raw = inner * mult_num / mult_den = 1275*125/100 = 1593.75
raw_num = inner * mult_num
raw_den = mult_den
print("raw_num/raw_den:", raw_num, "/", raw_den, "=", raw_num / raw_den)
# raw in tenths = raw * 10 = raw_num*10/raw_den
tenths_num = raw_num * 10
tenths_den = raw_den
print("tenths_num/tenths_den:", tenths_num, "/", tenths_den, "=", tenths_num / tenths_den)
# round tenths to int (halves up)
q, r = divmod(tenths_num, tenths_den)
if 2 * r >= tenths_den:
    q += 1
print("raw_tenths (int):", q)  # expect 15937 or 15938? 1593.75*10 = 15937.5 -> 15938
# round to nearest 10, halves up
q2, r2 = divmod(q, 10)
if r2 >= 5:
    q2 += 1
print("payout:", q2 * 10)  # expect 1590