"""Match payout. Rules live in docs/ECONOMY.md."""


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    # Compute raw = (base + kills*kill_bonus) * multiplier exactly, using integer
    # arithmetic to avoid float error. multiplier is parsed from its string form.
    mult_str = str(cfg["event_multiplier"])
    if "." in mult_str:
        whole, frac = mult_str.split(".")
        mult_num = int(whole + frac)
        mult_den = 10 ** len(frac)
    else:
        mult_num = int(mult_str)
        mult_den = 1
    inner = base + kills * cfg["kill_bonus"]
    # raw = inner * mult_num / mult_den (exact rational)
    # Round raw to nearest 10, halves up:
    #   raw/10 = inner * mult_num / (mult_den * 10)
    #   q, r = divmod(inner * mult_num, mult_den * 10); if 2*r >= mult_den*10: q += 1
    #   payout = q * 10
    den = mult_den * 10
    num = inner * mult_num
    q, r = divmod(num, den)
    if 2 * r >= den:
        q += 1
    return q * 10