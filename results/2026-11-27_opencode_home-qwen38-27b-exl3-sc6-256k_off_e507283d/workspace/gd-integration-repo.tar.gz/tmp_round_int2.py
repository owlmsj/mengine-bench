# Round to nearest 10, halves up, using pure integer arithmetic.
# Input: value in tenths (int). 1425 -> 14250, 1585 -> 15850, 1593.75 -> 15937 (approx), 1587.5 -> 15875
def round10(tenths):
    q, r = divmod(tenths, 10)
    if r >= 5:
        q += 1
    return q * 10

print("1425 ->", round10(14250))   # expect 1430
print("1585 ->", round10(15850))   # expect 1590
print("1587.5 ->", round10(15875)) # expect 1590
print("1593.75 ->", round10(15937)) # expect 1590 (1593.75 rounds to 1590)