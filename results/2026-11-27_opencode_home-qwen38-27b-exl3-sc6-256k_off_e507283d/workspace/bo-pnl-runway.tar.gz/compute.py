import csv, json
from collections import defaultdict

base = r"<WORKSPACE>\finance"

coa = {}
with open(base + r"\chart_of_accounts.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        coa[row["account"]] = row["pnl_line"]

months = ["2026-01","2026-02","2026-03","2026-04","2026-05","2026-06"]
tot = {m: defaultdict(float) for m in months}

with open(base + r"\ledger.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        d, a, amt = row["date"], row["account"], row["amount"]
        day, mon, yr = d.split("/")
        m = f"{yr}-{mon}"
        val = float(amt.replace(".", "").replace(",", "."))
        tot[m][coa[a]] += val

rev = {m: tot[m]["revenue"] for m in months}
cogs = {m: tot[m]["cogs"] for m in months}
ebitda = {m: tot[m]["revenue"] + tot[m]["cogs"] + tot[m]["sales_marketing"] + tot[m]["rnd"] + tot[m]["ga"] for m in months}
gm = {m: (rev[m] + cogs[m]) / rev[m] * 100 for m in months}

# burn: average monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = [ebitda[m] for m in ["2026-04","2026-05","2026-06"]]
negs = [x for x in last3 if x < 0]
burn = -sum(negs) / len(negs) if negs else 0.0
cash = 1847350.40
runway = cash / burn

out = {
    "revenue": {m: round(rev[m], 2) for m in months},
    "gross_margin_pct": {m: round(gm[m], 2) for m in months},
    "ebitda": {m: round(ebitda[m], 2) for m in months},
    "burn": round(burn, 2),
    "runway_months": round(runway, 2),
}
print(json.dumps(out, indent=2))
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2)
# detail for the report
for m in months:
    print(m, dict(tot[m]))