import re
pat = open('regex.txt').read().strip()
log = open('server.log').read()
print(re.findall(pat, log, re.MULTILINE))

# extra edge cases
cases = [
    ("2026-02-29 10.0.0.1 ok", ["2026-02-29"]),          # leap ok
    ("2023-02-29 10.0.0.1 ok", []),                       # non-leap 29 no
    ("2026-02-28 10.0.0.1 ok", ["2026-02-28"]),
    ("2026-04-31 10.0.0.1 ok", []),                       # apr 31 no
    ("2026-04-30 10.0.0.1 ok", ["2026-04-30"]),
    ("2026-01-01 256.0.0.1 ok", []),                      # bad ip
    ("2026-01-01 01.0.0.1 ok", []),                       # leading zero ip
    ("2026-01-01 1.0.0.1 ok", ["2026-01-01"]),
    ("2026-01-01 1.2.3.45 ok", ["2026-01-01"]),
    ("2026-01-01 x1.2.3.4 ok", []),                       # letter before ip
    ("2026-01-01 1.2.3.4x ok", []),                       # letter after ip
    ("2026-01-01 1.2.3.456 ok", []),                      # digit after ip
    ("2026-01-01 1.2.3.4 2026-01-02", ["2026-01-02"]),    # last date
    ("2026-01-01 1.2.3.4", ["2026-01-01"]),
    ("no ip here 2026-01-01", []),                        # no ip
    ("2026-13-01 1.2.3.4 ok", []),                        # bad month
    ("2026-00-10 1.2.3.4 ok", []),                        # bad month
    ("2026-01-00 1.2.3.4 ok", []),                        # bad day
    ("a2026-01-01 1.2.3.4 ok", []),                       # letter before date
    ("2026-01-01a 1.2.3.4 ok", []),                       # letter after date
    ("2026-01-011 1.2.3.4 ok", []),                       # digit after date
    ("2026-01-01 1.2.3.4 2026-01-02 2026-01-03", ["2026-01-03"]),
]
bad = 0
for line, want in cases:
    got = re.findall(pat, line, re.MULTILINE)
    if got != want:
        bad += 1
        print("FAIL", repr(line), "got", got, "want", want)
print("edge failures:", bad)