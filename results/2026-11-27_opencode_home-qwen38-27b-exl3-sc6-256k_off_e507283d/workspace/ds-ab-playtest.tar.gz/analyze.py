import csv, json, math

rows = []
with open(r"telemetry/playtest_ab.csv", newline="", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        rows.append(r)

print("total rows:", len(rows))

# clean variant: strip, lower
for r in rows:
    r["variant"] = r["variant"].strip().lower()
    r["completed_tutorial"] = int(r["completed_tutorial"])

# dedupe by session_id (first occurrence wins); verify consistency
seen = {}
conflicts = 0
for r in rows:
    sid = r["session_id"]
    if sid in seen:
        if seen[sid]["completed_tutorial"] != r["completed_tutorial"] or seen[sid]["variant"] != r["variant"]:
            conflicts += 1
    else:
        seen[sid] = r

print("unique sessions:", len(seen), "conflicting dupes:", conflicts)

a = [r for r in seen.values() if r["variant"] == "a"]
b = [r for r in seen.values() if r["variant"] == "b"]
other = [r for r in seen.values() if r["variant"] not in ("a", "b")]
print("variant counts:", len(a), len(b), "other:", len(other))

ca = sum(r["completed_tutorial"] for r in a)
cb = sum(r["completed_tutorial"] for r in b)
pa, pb = ca / len(a), cb / len(b)
print("A: %d/%d = %.6f" % (ca, len(a), pa))
print("B: %d/%d = %.6f" % (cb, len(b), pb))

# two-proportion z-test, two-sided, H0: pA = pB
p_pool = (ca + cb) / (len(a) + len(b))
se = math.sqrt(p_pool * (1 - p_pool) * (1 / len(a) + 1 / len(b)))
z = (pb - pa) / se
# two-sided p-value via normal CDF
p_value = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))
print("pooled p = %.6f, se = %.6f, z = %.6f, p_value = %.6f" % (p_pool, se, z, p_value))

result = {
    "ship_b": bool(p_value < 0.05 and pb > pa),
    "sessions_a": len(a),
    "sessions_b": len(b),
    "completion_rate_a": round(pa, 6),
    "completion_rate_b": round(pb, 6),
    "p_value": round(p_value, 6),
}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))