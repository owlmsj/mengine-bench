import sqlite3, json
from collections import defaultdict

STEPS = ["install", "tutorial_complete", "first_match", "purchase"]

c = sqlite3.connect('analytics.db')
users = {}
for uid, platform, is_test in c.execute("SELECT user_id, platform, is_test FROM users"):
    users[uid] = (platform, is_test)

# all occurrences per user/step, sorted
events = defaultdict(lambda: defaultdict(list))
for uid, name, ts in c.execute("SELECT user_id, name, ts FROM events"):
    if name in STEPS:
        events[uid][name].append(ts)
for uid in events:
    for name in events[uid]:
        events[uid][name].sort()

funnel = defaultdict(lambda: {s: 0 for s in STEPS})
for uid, (platform, is_test) in users.items():
    if is_test:
        continue
    prev_ts = None
    for s in STEPS:
        ts_list = events[uid].get(s, [])
        valid_ts = None
        for ts in ts_list:
            if prev_ts is None or ts >= prev_ts:
                valid_ts = ts
                break
        if valid_ts is None:
            continue
        funnel[platform][s] += 1
        prev_ts = valid_ts

result = {
    "funnel": {p: funnel[p] for p in sorted(funnel)},
    "biggest_drop": {},
}
for p in sorted(funnel):
    f = funnel[p]
    best_step, best_conv = None, None
    for i, s in enumerate(STEPS):
        if i == 0:
            continue
        prev = STEPS[i-1]
        if f[prev] == 0:
            continue
        conv = f[s] / f[prev]
        if best_conv is None or conv < best_conv:
            best_conv, best_step = conv, s
    result["biggest_drop"][p] = best_step

with open('result.json', 'w', encoding='utf-8') as fh:
    json.dump(result, fh, indent=2)
print(json.dumps(result, indent=2))