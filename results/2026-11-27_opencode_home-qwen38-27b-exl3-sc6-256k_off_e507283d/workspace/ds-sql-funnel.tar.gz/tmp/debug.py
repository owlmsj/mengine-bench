import sqlite3
from collections import defaultdict
STEPS = ["install", "tutorial_complete", "first_match", "purchase"]
c = sqlite3.connect('analytics.db')
users = {}
for uid, platform, is_test in c.execute("SELECT user_id, platform, is_test FROM users"):
    users[uid] = (platform, is_test)
first = defaultdict(dict)
for uid, name, ts in c.execute("SELECT user_id, name, ts FROM events"):
    if name in STEPS and (uid not in first or name not in first[uid] or ts < first[uid][name]):
        first[uid][name] = ts
# count purchase users whose purchase ts < first_match ts (the discrepancy)
bad = 0
for uid, (platform, is_test) in users.items():
    if is_test: continue
    ev = first.get(uid, {})
    if 'purchase' in ev and 'first_match' in ev and ev['purchase'] < ev['first_match']:
        bad += 1
print("purchase-before-first_match users:", bad)
# also: users with purchase but no install
no_install = sum(1 for uid,(p,t) in users.items() if not t and 'purchase' in first.get(uid,{}) and 'install' not in first.get(uid,{}))
print("purchase without install:", no_install)