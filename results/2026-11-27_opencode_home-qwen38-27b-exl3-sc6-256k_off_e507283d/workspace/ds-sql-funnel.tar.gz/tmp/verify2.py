import sqlite3
from collections import defaultdict
STEPS = ["install", "tutorial_complete", "first_match", "purchase"]
c = sqlite3.connect('analytics.db')
users = {}
for uid, platform, is_test in c.execute("SELECT user_id, platform, is_test FROM users"):
    users[uid] = (platform, is_test)
events = defaultdict(lambda: defaultdict(list))
for uid, name, ts in c.execute("SELECT user_id, name, ts FROM events"):
    if name in STEPS:
        events[uid][name].append(ts)
for uid in events:
    for name in events[uid]:
        events[uid][name].sort()
funnel = defaultdict(lambda: {s: 0 for s in STEPS})
for uid, (platform, is_test) in users.items():
    if is_test: continue
    prev_ts = None
    for s in STEPS:
        valid_ts = None
        for ts in events[uid].get(s, []):
            if prev_ts is None or ts >= prev_ts:
                valid_ts = ts
                break
        if valid_ts is None: continue
        funnel[platform][s] += 1
        prev_ts = valid_ts
for p in sorted(funnel):
    print(p, funnel[p])