import sqlite3
c = sqlite3.connect('analytics.db')
q = """
WITH ev AS (
  SELECT e.user_id, e.name, MIN(e.ts) ts
  FROM events e JOIN users u ON u.user_id = e.user_id
  WHERE u.is_test = 0 AND e.name IN ('install','tutorial_complete','first_match','purchase')
  GROUP BY e.user_id, e.name
)
SELECT u.platform,
  SUM(CASE WHEN i.ts IS NOT NULL THEN 1 ELSE 0 END),
  SUM(CASE WHEN i.ts IS NOT NULL AND t.ts IS NOT NULL AND t.ts >= i.ts THEN 1 ELSE 0 END),
  SUM(CASE WHEN i.ts IS NOT NULL AND t.ts IS NOT NULL AND t.ts >= i.ts
            AND m.ts IS NOT NULL AND m.ts >= t.ts THEN 1 ELSE 0 END),
  SUM(CASE WHEN i.ts IS NOT NULL AND t.ts IS NOT NULL AND t.ts >= i.ts
            AND m.ts IS NOT NULL AND m.ts >= t.ts
            AND p.ts IS NOT NULL AND p.ts >= m.ts THEN 1 ELSE 0 END)
FROM users u
LEFT JOIN ev i ON i.user_id = u.user_id AND i.name = 'install'
LEFT JOIN ev t ON t.user_id = u.user_id AND t.name = 'tutorial_complete'
LEFT JOIN ev m ON m.user_id = u.user_id AND m.name = 'first_match'
LEFT JOIN ev p ON p.user_id = u.user_id AND p.name = 'purchase'
WHERE u.is_test = 0
GROUP BY u.platform
"""
for r in c.execute(q):
    print(r)