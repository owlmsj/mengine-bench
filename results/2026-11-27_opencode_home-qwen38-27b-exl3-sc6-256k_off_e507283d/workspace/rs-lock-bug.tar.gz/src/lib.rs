//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        // One lock per field, held across the read-modify-write so
        // concurrent awards cannot lose updates.
        let slot = self.slot(id);
        let mut score = slot.lock().unwrap();
        *score += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        // Lock both slots in id order so two concurrent transfers
        // between the same pair cannot deadlock.
        let (first, second) = if from <= to { (from, to) } else { (to, from) };
        let first_arc = self.slot(first);
        let second_arc = self.slot(second);
        let mut first_slot = first_arc.lock().unwrap();
        let mut second_slot = second_arc.lock().unwrap();
        if from <= to {
            *first_slot -= points;
            *second_slot += points;
        } else {
            *second_slot -= points;
            *first_slot += points;
        }
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}
