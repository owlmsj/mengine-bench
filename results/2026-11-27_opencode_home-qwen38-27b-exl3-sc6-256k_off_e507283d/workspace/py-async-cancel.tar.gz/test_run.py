import asyncio
import signal
import time

from run import run_tasks


async def test_basic_and_bound():
    running = 0
    peak = 0
    done = 0

    async def job():
        nonlocal running, peak, done
        running += 1
        peak = max(peak, running)
        await asyncio.sleep(0.05)
        running -= 1
        done += 1

    await run_tasks([job for _ in range(10)], max_concurrent=3)
    assert done == 10, done
    assert peak <= 3, peak
    assert peak == 3, peak  # bound is actually used
    print("basic+bound OK, peak =", peak)


async def test_cleanup_on_cancel():
    cleaned = []

    async def job(i):
        try:
            await asyncio.sleep(10)
        finally:
            cleaned.append(i)

    async def main():
        t = asyncio.create_task(run_tasks([lambda i=i: job(i) for i in range(4)], max_concurrent=2))
        await asyncio.sleep(0.1)
        t.cancel()
        try:
            await t
        except asyncio.CancelledError:
            pass
        return cleaned

    cleaned = await main()
    assert sorted(cleaned) == [0, 1], cleaned  # only 2 jobs started (max_concurrent=2)
    print("cleanup-on-cancel OK:", cleaned)


async def test_sigint_like():
    """Simulate Ctrl+C: cancel the run_tasks task, expect cleanup + normal return."""
    cleaned = []

    async def job(i):
        try:
            await asyncio.sleep(10)
        finally:
            cleaned.append(i)

    t = asyncio.create_task(run_tasks([lambda i=i: job(i) for i in range(3)], max_concurrent=1))
    await asyncio.sleep(0.1)
    t.cancel()
    await t  # must NOT raise: run_tasks swallows CancelledError
    assert cleaned == [0], cleaned  # only 1 job started (max_concurrent=1)
    print("sigint-sim OK:", cleaned)


async def test_empty():
    await run_tasks([], max_concurrent=2)
    print("empty OK")


async def test_bad_max():
    try:
        await run_tasks([], max_concurrent=0)
    except ValueError:
        print("bad-max OK")
    else:
        raise AssertionError("expected ValueError")


async def main():
    await test_basic_and_bound()
    await test_cleanup_on_cancel()
    await test_sigint_like()
    await test_empty()
    await test_bad_max()
    print("ALL OK")


asyncio.run(main())