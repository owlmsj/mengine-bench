"""Batch task runner: run zero-arg async callables with bounded concurrency.

Usage:
    from run import run_tasks
    await run_tasks([job1, job2, ...], max_concurrent=4)

Each task is a zero-argument callable that returns an awaitable (e.g. a
coroutine function). At most `max_concurrent` jobs run at once. On Ctrl+C
(SIGINT) the in-flight jobs are cancelled and their cleanup code (finally
blocks / `async with` / `async for` teardown) runs before run_tasks returns.
"""

from __future__ import annotations

import asyncio
from typing import Awaitable, Callable, Sequence


async def run_tasks(
    tasks: Sequence[Callable[[], Awaitable[object]]],
    max_concurrent: int,
) -> None:
    """Run all tasks with at most `max_concurrent` running at once.

    Returns when every job has finished. If the task group is cancelled
    (e.g. by Ctrl+C), in-flight jobs are cancelled and awaited, so their
    cleanup code runs, and run_tasks returns normally.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent}")

    sem = asyncio.Semaphore(max_concurrent)

    async def _run(task: Callable[[], Awaitable[object]]) -> None:
        async with sem:
            await task()

    try:
        async with asyncio.TaskGroup() as tg:
            for task in tasks:
                tg.create_task(_run(task))
    except* asyncio.CancelledError:
        # Ctrl+C: TaskGroup already cancelled and awaited all child tasks,
        # so every job's cleanup has run. Swallow so run_tasks returns.
        pass