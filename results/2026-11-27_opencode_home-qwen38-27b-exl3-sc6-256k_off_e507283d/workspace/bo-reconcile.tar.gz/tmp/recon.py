import csv, re, json

base = r"<WORKSPACE>\backoffice"
invoices = {}
with open(f"{base}/invoices.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = float(row["amount"])

payments = {}  # id -> list of amounts
skipped = []
with open(f"{base}/bank_statement_june.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        m = re.search(r"(?:inv|invoice)[-\s#]*(\d{4})", memo, re.I)
        if not m:
            skipped.append((row["date"], memo, row["amount"]))
            continue
        inv = "INV-" + m.group(1)
        payments.setdefault(inv, []).append(float(row["amount"]))

unpaid = sorted(i for i in invoices if i not in payments)
duplicated = sorted(i for i, amts in payments.items() if len(amts) > 1)
mismatched = []
for i, amts in payments.items():
    if len(amts) == 1 and abs(amts[0] - invoices[i]) > 0.005:
        mismatched.append({"id": i, "invoiced": invoices[i], "paid": amts[0]})
mismatched.sort(key=lambda x: x["id"])

result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
print(json.dumps(result, indent=2))
print("skipped:", skipped)
print("paid count:", len(payments), "invoice count:", len(invoices))