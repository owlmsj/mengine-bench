from datetime import date

ipca = {1985:242.23,1986:79.66,1987:363.41,1988:980.21,1989:1972.91,
        1990:1620.97,1991:472.70,1992:1119.10,1993:2477.15,1994:916.46,
        1995:22.41,1996:9.56}

plans = [
    ("Cruzado", date(1986,2,28), date(1987,6,12)),
    ("Bresser", date(1987,6,12), date(1989,1,15)),
    ("Verao",   date(1989,1,15), date(1990,3,16)),
    ("Collor I",date(1990,3,16), date(1991,1,31)),
    ("Collor II",date(1991,1,31), date(1994,2,27)),
    ("Real",    date(1994,2,27), None),
]

def months_between(a, b):
    return (b.year - a.year) * 12 + (b.month - a.month) - (1 if b.day < a.day else 0)

results = []
for name, launch, nxt in plans:
    y = launch.year
    before = ipca[y-1]
    after = ipca[y+1]
    drop = max(0.0, min(1.0, 1 - after/before))
    if nxt is None:
        m = 60
    else:
        m = months_between(launch, nxt)
    dur = min(m, 60)/60
    score = 0.7*drop + 0.3*dur
    results.append((name, y, before, after, m, drop, dur, score))
    print(f"{name:10s} Y={y} before={before:8.2f} after={after:8.2f} months={m:3d} drop={drop:.4f} dur={dur:.4f} score={score:.4f}")

ranked = sorted(results, key=lambda r: -r[7])
print("\nTop 3:")
for r in ranked[:3]:
    print(r[0], round(r[7],4))