# HANDOFF — local-9b @ 128k

## Done (measured)
- Baseline Q5, Ctx 131072, 1024 predict: 37.8 t/s, VRAM 7881 MiB.
- 7881 MiB = WDDM ceiling; Shared Usage showed 1494 MiB spilled — does not count.
- Fix `--no-mmproj-offload` + `-ub 512` kills the spill: 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k — discarded. Q4_K_M fits (7305 MiB, 40.4 t/s) — fallback only.
- Recipe applied: scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

## Left
1. evals README still cites check_vision.ps1 — file no longer exists; update it.
2. Review scratchpad temp-file names (noted repeatedly, never done).

## Assumptions
- "Q5" = the measured Q5_K baseline; the recipe is the Q5 fix.
- No repo here; the numbers above are the source of truth.

## How I know it is right
Each number is a measured run in session/transcript.md (steps 10, 42, 45, 63). The fix is confirmed by the spill disappearing and VRAM dropping 7881→7697 MiB with decode holding 38.0 t/s.