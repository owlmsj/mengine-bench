import sqlite3, json
from collections import defaultdict

STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']

c = sqlite3.connect('analytics.db')
users = {uid: (plat, test) for uid, plat, test in c.execute("SELECT user_id, platform, is_test FROM users")}

events = defaultdict(list)
for uid, name, ts in c.execute("SELECT user_id, name, ts FROM events"):
    events[uid].append((ts, name))
for uid in events:
    events[uid].sort()

funnel = defaultdict(lambda: {s: 0 for s in STEPS})
platforms = set()
for uid, (plat, test) in users.items():
    if test:
        continue
    platforms.add(plat)
    evs = events.get(uid, [])
    prev_ts = None
    reached = 0
    for s in STEPS:
        t = None
        for ts, name in evs:
            if name == s and (prev_ts is None or ts >= prev_ts):
                t = ts
                break
        if t is None:
            break
        prev_ts = t
        reached += 1
        funnel[plat][s] += 1

for p in sorted(platforms):
    for s in STEPS:
        funnel[p][s] = funnel[p][s]  # ensure keys

result = {'funnel': {}, 'biggest_drop': {}}
for p in sorted(platforms):
    f = funnel[p]
    result['funnel'][p] = {s: f[s] for s in STEPS}
    convs = {}
    for i in range(1, len(STEPS)):
        prev = f[STEPS[i-1]]
        cur = f[STEPS[i]]
        convs[STEPS[i]] = (cur / prev) if prev else 0.0
    # biggest drop = lowest conversion
    worst = min(convs, key=lambda s: convs[s])
    result['biggest_drop'][p] = worst
    print(p, f, {k: round(v,4) for k,v in convs.items()}, '->', worst)

with open('result.json', 'w') as fh:
    json.dump(result, fh, indent=2)
print('written')