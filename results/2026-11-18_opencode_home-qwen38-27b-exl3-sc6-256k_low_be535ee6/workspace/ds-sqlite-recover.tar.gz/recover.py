import struct, json

data = open('prices.db','rb').read()
print("file len", len(data))

def varint(buf, off):
    # SQLite big-endian varint, up to 9 bytes
    result = 0
    for i in range(9):
        b = buf[off+i]
        if i == 8:
            result = (result << 8) | b
            return result, off+9
        result = (result << 7) | (b & 0x7F)
        if not (b & 0x80):
            return result, off+i+1
    return result, off+9

def serial_len(st):
    if st == 0: return 0
    if st == 1: return 1
    if st == 2: return 2
    if st == 3: return 3
    if st == 4: return 4
    if st == 5: return 6
    if st == 6: return 8
    if st == 7: return 8
    if st == 8: return 0
    if st == 9: return 0
    if st >= 12 and st % 2 == 0: return (st-12)//2
    if st >= 13 and st % 2 == 1: return (st-13)//2
    raise ValueError("bad serial type %d"%st)

def read_value(buf, off, st):
    n = serial_len(st)
    raw = buf[off:off+n]
    if st == 0: return None
    if st == 1: return struct.unpack('>b', raw)[0]
    if st == 2: return struct.unpack('>h', raw)[0]
    if st == 3: return int.from_bytes(raw, 'big', signed=True)
    if st == 4: return struct.unpack('>i', raw)[0]
    if st == 5: return int.from_bytes(raw, 'big', signed=True)
    if st == 6: return struct.unpack('>q', raw)[0]
    if st == 7: return struct.unpack('>d', raw)[0]
    if st == 8: return 0
    if st == 9: return 1
    if st >= 12 and st % 2 == 0: return raw.decode('utf-8', 'replace')
    if st >= 13 and st % 2 == 1: return raw
    raise ValueError("bad st %d"%st)

# Page header (b-tree leaf table page)
page_type = data[0]
ncells = struct.unpack('>H', data[3:5])[0]
cell_start = struct.unpack('>H', data[5:7])[0]
print("page_type", hex(page_type), "ncells", ncells, "cell_start", cell_start)

cell_ptrs = []
for i in range(ncells):
    p = struct.unpack('>H', data[8+2*i:10+2*i])[0]
    cell_ptrs.append(p)
print("cell_ptrs", [hex(p) for p in cell_ptrs])

rows = []
for cp in cell_ptrs:
    off = cp
    payload_len, off = varint(data, off)
    rowid, off = varint(data, off)
    # record
    hdr_size, off2 = varint(data, off)
    hdr_end = off + hdr_size
    stypes = []
    o = off2
    while o < hdr_end:
        st, o = varint(data, o)
        stypes.append(st)
    vals = []
    vo = hdr_end
    for st in stypes:
        v = read_value(data, vo, st)
        vo += serial_len(st)
        vals.append(v)
    rows.append((rowid, vals))

for rowid, vals in rows:
    print(rowid, vals)

# Build JSON: assume columns item, price
out = []
for rowid, vals in rows:
    item = vals[1] if len(vals) >= 2 else (vals[0] if vals else None)
    price = vals[2] if len(vals) >= 3 else (vals[1] if len(vals) >= 2 else None)
    if isinstance(item, bytes):
        item = item.decode('utf-8', 'replace')
    out.append({"item": item, "price": price})

with open('recovered.json','w',encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print("wrote", len(out), "rows")