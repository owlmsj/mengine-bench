import csv, json, math

rows = {}
with open("telemetry/playtest_ab.csv", newline="") as f:
    for r in csv.DictReader(f):
        sid = r["session_id"].strip()
        rows[sid] = r  # last row wins; ETL resend = same session

a = b = 0
a_ok = b_ok = 0
for sid, r in rows.items():
    v = r["variant"].strip().lower()
    ok = int(r["completed_tutorial"])
    if v == "a":
        a += 1; a_ok += ok
    elif v == "b":
        b += 1; b_ok += ok
    else:
        raise SystemExit(f"bad variant {r['variant']!r} for {sid}")

# chi-square, no continuity correction
n = a + b
E = [[a_ok, a - a_ok], [b_ok, b - b_ok]]
row_sums = [a, b]
col_sums = [a_ok + b_ok, (a - a_ok) + (b - b_ok)]
chi2 = 0.0
for i in range(2):
    for j in range(2):
        exp = row_sums[i] * col_sums[j] / n
        chi2 += (E[i][j] - exp) ** 2 / exp

# p-value from chi2 with df=1: p = 2*(1 - Phi(sqrt(chi2)))
p = 2 * (1 - 0.5 * (1 + math.erf(math.sqrt(chi2) / math.sqrt(2))))

result = {
    "ship_b": p < 0.05 and b_ok / b > a_ok / a,
    "sessions_a": a,
    "sessions_b": b,
    "completion_rate_a": a_ok / a,
    "completion_rate_b": b_ok / b,
    "p_value": p,
}
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
print(f"completed: a={a_ok}/{a} b={b_ok}/{b} chi2={chi2:.4f}")