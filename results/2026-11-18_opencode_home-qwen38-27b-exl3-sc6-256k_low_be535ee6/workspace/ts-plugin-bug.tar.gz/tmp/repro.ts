import { HookBus } from "../src/bus.ts";
import { registerAuditPlugin } from "../src/plugin.ts";

let pass = 0, fail = 0;
function check(name: string, ok: boolean) {
  if (ok) { pass++; console.log("ok  " + name); }
  else { fail++; console.log("FAIL " + name); }
}

// 1. Order: handlers run in subscription order, one after another.
{
  const bus = new HookBus();
  const order: string[] = [];
  bus.on("e", async () => { await new Promise(r => setTimeout(r, 10)); order.push("a"); });
  bus.on("e", async () => { order.push("b"); });
  bus.on("e", async () => { await new Promise(r => setTimeout(r, 1)); order.push("c"); });
  await bus.emit("e", null);
  check("runs in subscription order, sequentially", JSON.stringify(order) === JSON.stringify(["a","b","c"]));
}

// 2. A handler that awaits still runs (was fire-and-forget, could "never run").
{
  const bus = new HookBus();
  let ran = false;
  bus.on("e", async () => { await new Promise(r => setTimeout(r, 5)); ran = true; });
  await bus.emit("e", null);
  check("async handler completes before emit resolves", ran);
}

// 3. A failing hook rejects emit with the same error; later handlers do not run.
{
  const bus = new HookBus();
  let after = false;
  bus.on("e", async () => { throw new Error("boom"); });
  bus.on("e", () => { after = true; });
  let caught: unknown;
  try { await bus.emit("e", null); } catch (e) { caught = e; }
  check("emit rejects with the handler's error", caught instanceof Error && caught.message === "boom");
  check("handlers after a failure do not run", after === false);
}

// 4. Unsubscribe during emit does not stop the others in that emit.
{
  const bus = new HookBus();
  const ran: string[] = [];
  const off = bus.on("e", () => { ran.push("a"); off(); });
  bus.on("e", () => { ran.push("b"); });
  await bus.emit("e", null);
  check("self-unsubscribe mid-emit still lets others run", JSON.stringify(ran) === JSON.stringify(["a","b"]));
  await bus.emit("e", null);
  check("unsubscribe counts from the next emit", JSON.stringify(ran) === JSON.stringify(["a","b","b"]));
}

// 5. The audit plugin: one-time notice, redaction, then log, in order.
{
  const bus = new HookBus();
  const audit: string[] = [];
  registerAuditPlugin(bus, audit);
  await bus.emit("tool.after", { tool: "shell", output: "password=secret123 done" });
  await bus.emit("tool.after", { tool: "shell", output: "password=again ok" });
  check("one-time notice appears exactly once", audit.filter(a => a.startsWith("notice:")).length === 1);
  check("notice is first", audit[0].startsWith("notice:"));
  check("password redacted", audit.every(a => !a.includes("secret123") && !a.includes("again")));
  check("audit log appended after redaction", audit[1] === "shell: password=[redacted] done" && audit[2] === "shell: password=[redacted] ok");
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);