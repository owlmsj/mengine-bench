import csv, json, re, os

base = os.path.join(os.path.dirname(__file__), "backoffice")

# Load invoices
invoices = {}
with open(os.path.join(base, "invoices.csv"), encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = float(row["amount"])

# Load bank statement, map each payment to an invoice id
payments = {}   # id -> list of amounts
ignored = []
with open(os.path.join(base, "bank_statement_june.csv"), encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        amount = float(row["amount"])
        # extract candidate invoice numbers: "INV-1015", "inv1007", "invoice 1023"
        ids = set(re.findall(r"(?:INV-|inv|invoice\s*)(10\d{2})", memo, re.IGNORECASE))
        ids = [i for i in ids if ("INV-" + i) in invoices]
        if not ids:
            ignored.append((row["date"], memo, amount))
            continue
        for i in ids:
            payments.setdefault("INV-" + i, []).append(amount)

unpaid = sorted(set(invoices) - set(payments))
duplicated = sorted(i for i, amts in payments.items() if len(amts) > 1)
mismatched = []
for i, amts in payments.items():
    if i in duplicated:
        continue  # exclusive: duplicated never also mismatched
    if any(abs(a - invoices[i]) > 0.005 for a in amts):
        # single payment whose amount differs from its invoice
        paid = amts[0] if len(amts) == 1 else amts[0]
        mismatched.append({"id": i, "invoiced": invoices[i], "paid": paid})
mismatched.sort(key=lambda m: m["id"])

result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
with open(os.path.join(os.path.dirname(__file__), "result.json"), "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)

print("ignored rows:")
for d, m, a in ignored:
    print("  ", d, m, a)
print(json.dumps(result, indent=2, ensure_ascii=False))
print("counts: invoices=%d paid_ids=%d" % (len(invoices), len(payments)))