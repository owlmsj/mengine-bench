# HANDOFF — local-9b Q5 @ 128k

Goal: measure local-9b Q5 at 128k. Done.

Findings (session/transcript.md):
- Baseline 37.8 t/s, VRAM 7881 MiB. 7881 is the WDDM ceiling; Shared Usage showed 1494 MiB spilled — invalid.
- Fix: --no-mmproj-offload + -ub 512 removes the spill. Final 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k; discarded. Q4_K_M fits (7305 MiB, 40.4 t/s) — fallback only.
- Recipe applied at scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

Left to do:
1. evals README still cites check_vision.ps1, which no longer exists — update it.
2. Review the names of the scratchpad temp files (noted repeatedly, never done).

Caveats: Workspace holds only session/transcript.md and AGENTS.md; the scripts, profiles and evals README above are NOT present here, so I could not verify the applied recipe or README text. Numbers are as recorded; I did not re-run them. Treat as reported, not confirmed.

How I know it is right: I read the full transcript; findings are the agent's own recorded measurements and decisions, quoted verbatim. The two pending items are the only explicit Pending/Noted-for-later entries.