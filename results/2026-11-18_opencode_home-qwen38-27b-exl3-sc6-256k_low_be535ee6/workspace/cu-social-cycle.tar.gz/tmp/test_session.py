import json, urllib.request, base64, os

BASE = "http://127.0.0.1:57923"
NONCE = "dff974bb43daa96cca3407e3548b920e"

def e(nonce):
    f = 0x811c9dc5
    g = ""
    for h in range(4):
        i = nonce + "." + str(h)
        for ch in i:
            f ^= ord(ch)
            f = (f * 0x01000193) & 0xFFFFFFFF
        g += format(f, '08x')
    return g

TOKEN = e(NONCE)
print("token:", TOKEN)

def call(method, params=None, body=None, content_type=None, raw=False):
    url = BASE + "/xrpc/" + method + (("?" + urllib.parse.urlencode(params)) if params else "")
    headers = {}
    data = None
    if body is not None:
        headers["Content-Type"] = content_type or "application/json"
        headers["X-Bh-Token"] = TOKEN
        data = body if raw else json.dumps(body).encode()
    req = urllib.request.Request(url, data=data, headers=headers, method=("POST" if body is not None else "GET"))
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read().decode())

import urllib.parse
who = call("com.bluehaze.server.getSession")
print("session:", json.dumps(who))