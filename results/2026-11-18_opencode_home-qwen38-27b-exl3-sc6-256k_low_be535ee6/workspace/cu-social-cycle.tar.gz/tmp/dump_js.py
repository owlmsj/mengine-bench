s = open(r'site/static/js/main.ebd80609.js', encoding='utf-8').read()
idx = s.find('use strict')
body = s[idx:]
print(body)