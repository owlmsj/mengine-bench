from PIL import Image, ImageDraw, ImageFont
import os

W, H = 1200, 675
img = Image.new("RGB", (W, H))
d = ImageDraw.Draw(img)

# Harbor/water themed vertical gradient (deep blue -> teal)
top = (18, 48, 92)
bot = (24, 120, 140)
for y in range(H):
    t = y / (H - 1)
    r = int(top[0] + (bot[0]-top[0])*t)
    g = int(top[1] + (bot[1]-top[1])*t)
    b = int(top[2] + (bot[2]-top[2])*t)
    d.line([(0, y), (W, y)], fill=(r, g, b))

# Subtle "water" horizontal bands near bottom
for i, yy in enumerate(range(H-120, H, 14)):
    d.line([(0, yy), (W, yy)], fill=(255, 255, 255, 255), width=2)

def load_font(size):
    candidates = [
        r"C:\Windows\Fonts\seguiui.ttf",
        r"C:\Windows\Fonts\arialbd.ttf",
        r"C:\Windows\Fonts\arial.ttf",
        r"C:\Windows\Fonts\calibrib.ttf",
        r"C:\Windows\Fonts\tahoma.ttf",
    ]
    for c in candidates:
        if os.path.exists(c):
            try:
                return ImageFont.truetype(c, size)
            except Exception:
                pass
    return ImageFont.load_default()

title = "Harbor Day 2026"
font = load_font(120)
# measure and center
bb = d.textbbox((0, 0), title, font=font)
tw = bb[2]-bb[0]; th = bb[3]-bb[1]
tx = (W - tw)//2 - bb[0]
ty = (H - th)//2 - bb[1] - 20
# shadow then text
d.text((tx+4, ty+4), title, font=font, fill=(8, 20, 40))
d.text((tx, ty), title, font=font, fill=(255, 255, 255))

# small kicker line above
kfont = load_font(40)
kicker = "A CELEBRATION BY THE WATER"
kb = d.textbbox((0,0), kicker, font=kfont)
kw = kb[2]-kb[0]
d.text(((W-kw)//2 - kb[0], ty-70), kicker, font=kfont, fill=(190, 225, 240))

# underline accent
d.rectangle([W//2-160, ty+th+30, W//2+160, ty+th+38], fill=(255, 210, 90))

out = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "cover.png")
img.save(out, "PNG")
print("saved", out, img.size, os.path.getsize(out))