import base64
arr=["dG9vYi1oZw==","bmVrb1QtaEItWA==","L2Nwcngv","ZHJvY2VSZXRlbGVkLm9wZXIuZXphaGV1bGIubW9j","dHNvcC5kZWVmLmV6YWhldWxiLnBwYQ==","dHNvcC5kZWVmLmV6YWhldWxiLnBwYQ==","Ym9sQmRhb2xwdS5vcGVyLmV6YWhldWxiLm1vYw==","c2VnYW1pLmRlYm1lLmV6YWhldWxiLnBwYQ==","ZHJvY2VSZXRhZXJjLm9wZXIuZXphaGV1bGIubW9j","dHNvcC5kZWVmLmV6YWhldWxiLnBwYQ==","OmJldzpkaWQvLzp0YQ==","dHNvcC5kZWVmLmV6YWhldWxiLnBwYQ==","ZGFlcmhUdHNvUHRlZy5kZWVmLmV6YWhldWxiLnBwYQ==","ZWxpZm9yUHRlZy5yb3RjYS5lemFoZXVsYi5wcGE=","ZGVlRnJvaHR1QXRlZy5kZWVmLmV6YWhldWxiLnBwYQ==","ZW5pbGVtaVR0ZWcuZGVlZi5lemFoZXVsYi5wcGE=","bm9pc3NlU3RlZy5yZXZyZXMuZXphaGV1bGIubW9j"]
for i,x in enumerate(arr):
    print(i, base64.b64decode(x).decode()[::-1])
print('---PIL---')
try:
    import PIL
    from PIL import Image, ImageDraw, ImageFont
    print('PIL ok', PIL.__version__)
except Exception as e:
    print('PIL missing', e)