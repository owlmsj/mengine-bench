import json, urllib.request, urllib.parse, datetime, hashlib, os

BASE = "http://127.0.0.1:57923"
NONCE = "dff974bb43daa96cca3407e3548b920e"
TEXT = "Testing the new Bluehaze uploader: Harbor Day is on."
ALT = "Poster with the title Harbor Day 2026."
COVER = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "cover.png")

def e(nonce):
    f = 0x811c9dc5; g = ""
    for h in range(4):
        i = nonce + "." + str(h)
        for ch in i:
            f ^= ord(ch); f = (f * 0x01000193) & 0xFFFFFFFF
        g += format(f, '08x')
    return g
TOKEN = e(NONCE)

def call(method, params=None, body=None, content_type=None, raw=False):
    url = BASE + "/xrpc/" + method + (("?" + urllib.parse.urlencode(params)) if params else "")
    headers = {}; data = None
    if body is not None:
        headers["Content-Type"] = content_type or "application/json"
        headers["X-Bh-Token"] = TOKEN
        data = body if raw else json.dumps(body).encode()
    req = urllib.request.Request(url, data=data, headers=headers, method=("POST" if body is not None else "GET"))
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read().decode())

def state_hash():
    h = hashlib.sha256()
    h.update(open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "site-data/state.json"), "rb").read())
    return h.hexdigest()

print("STEP 0 session")
who = call("com.bluehaze.server.getSession")
print("  ", json.dumps(who))
did = who["did"]

print("STEP 1 uploadBlob")
img_bytes = open(COVER, "rb").read()
print("   cover bytes:", len(img_bytes), "sha256:", hashlib.sha256(img_bytes).hexdigest())
up = call("com.bluehaze.repo.uploadBlob", body=img_bytes, content_type="image/png", raw=True)
print("  ", json.dumps(up))
blob = up["blob"]

print("STEP 2 createRecord")
record = {
    "$type": "app.bluehaze.feed.post",
    "text": TEXT,
    "createdAt": datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z"),
    "embed": {"$type": "app.bluehaze.embed.images", "images": [{"image": blob, "alt": ALT}]},
}
cr = call("com.bluehaze.repo.createRecord", body={"repo": did, "collection": "app.bluehaze.feed.post", "record": record})
print("  ", json.dumps(cr))
uri = cr["uri"]; rkey = uri.split("/")[-1]
print("   uri:", uri, "rkey:", rkey)

print("STEP 3 verify post exists (getAuthorFeed)")
feed = call("app.bluehaze.feed.getAuthorFeed", params={"actor": who["handle"]})
found = None
for item in feed.get("feed", []):
    p = item["post"]
    if p["record"]["text"] == TEXT:
        found = p
        break
print("   matched post:", json.dumps(found) if found else "NOT FOUND")
assert found, "post not found in author feed"
imgs = found.get("embed", {}).get("images", [])
print("   image alt:", imgs[0]["alt"] if imgs else "NONE", "blob:", imgs[0]["image"] if imgs else "NONE")
assert imgs and imgs[0]["alt"] == ALT and imgs[0]["image"] == blob

print("STEP 4 verify post thread")
thread = call("app.bluehaze.feed.getPostThread", params={"uri": uri})
tp = thread["thread"]["post"]
print("   thread post text:", tp["record"]["text"])
assert tp["record"]["text"] == TEXT

print("STEP 5 deleteRecord (only this post)")
dr = call("com.bluehaze.repo.deleteRecord", body={"repo": did, "collection": "app.bluehaze.feed.post", "rkey": rkey})
print("  ", json.dumps(dr))

print("STEP 6 verify post gone")
feed2 = call("app.bluehaze.feed.getAuthorFeed", params={"actor": who["handle"]})
still = [i["post"] for i in feed2.get("feed", []) if i["post"]["record"]["text"] == TEXT]
print("   remaining matching posts:", len(still))
assert not still, "post still present after delete"
try:
    t2 = call("app.bluehaze.feed.getPostThread", params={"uri": uri})
    print("   thread after delete:", json.dumps(t2)[:200])
except Exception as ex:
    print("   thread after delete raised (expected):", ex)

print("DONE. rkey deleted:", rkey)