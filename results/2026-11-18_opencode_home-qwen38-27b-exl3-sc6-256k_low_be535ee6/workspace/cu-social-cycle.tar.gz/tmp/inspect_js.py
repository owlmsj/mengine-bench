import re
s = open(r'site/static/js/main.ebd80609.js', encoding='utf-8').read()
print(len(s))
# print the part after the obfuscation prefix
idx = s.find('use strict')
body = s[idx:]
# find method-like strings
for m in sorted(set(re.findall(r'"([a-zA-Z0-9_.]+)"', body))):
    if '.' in m and ' ' not in m:
        print(m)
print('---calls---')
for m in re.findall(r'n\(\s*"([^"]+)"\s*,\s*([^)]*)\)', body):
    print(m)