//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        // Hold each lock across the read-modify-write. The old code read the
        // value, released the lock, then wrote `old + points`; two threads
        // reading the same value both wrote the same result and one update was
        // silently lost, so final scores came out low under load.
        *slot.lock().unwrap() += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            // Locking the same non-reentrant Mutex twice would deadlock.
            return;
        }
        // Lock the two slots in a consistent (id-ascending) order. The old
        // code locked `from` then `to`, so concurrent `transfer(1,2)` and
        // `transfer(2,1)` locked in opposite order and deadlocked (ABBA),
        // hanging the match server under load.
        let (low, high) = if from < to { (from, to) } else { (to, from) };
        let low_slot = self.slot(low);
        let high_slot = self.slot(high);
        let mut low_score = low_slot.lock().unwrap();
        let mut high_score = high_slot.lock().unwrap();
        if from < to {
            *low_score -= points;
            *high_score += points;
        } else {
            *low_score += points;
            *high_score -= points;
        }
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::mpsc;
    use std::thread;
    use std::time::Duration;

    /// Regression test for the two reported bugs. Before the fix this either
    /// deadlocked (opposite-direction transfers) or produced a low total
    /// (lost updates in `award`). The workload runs in a child thread and the
    /// test waits with a timeout, so a deadlock fails the test instead of
    /// hanging the whole suite.
    #[test]
    fn concurrent_load_keeps_total_and_does_not_hang() {
        let board = Arc::new(Board::new());
        board.join(1, 100);
        board.join(2, 100);
        let start_total = 200;

        let workers = 8;
        let rounds = 500;
        let awarded = (workers * rounds * 2) as i64; // two awards per round
        let expected_total = start_total + awarded;

        let (tx, rx) = mpsc::channel();
        let worker_board = board.clone();
        thread::spawn(move || {
            let mut handles = Vec::new();
            for _ in 0..workers {
                let b = worker_board.clone();
                handles.push(thread::spawn(move || {
                    for _ in 0..rounds {
                        b.transfer(1, 2, 1);
                        b.transfer(2, 1, 1); // opposite direction: ABBA trigger
                    }
                }));
            }
            for _ in 0..workers {
                let b = worker_board.clone();
                handles.push(thread::spawn(move || {
                    for _ in 0..rounds {
                        b.award(1, 1);
                        b.award(2, 1);
                    }
                }));
            }
            for h in handles {
                h.join().unwrap();
            }
            let result = (
                worker_board.score(1),
                worker_board.score(2),
                worker_board.total(),
            );
            let _ = tx.send(result);
        });

        match rx.recv_timeout(Duration::from_secs(20)) {
            Ok((s1, s2, total)) => {
                assert_eq!(
                    total, expected_total,
                    "lost updates: total {total} != expected {expected_total}"
                );
                assert_eq!(s1 + s2, total, "scores no longer sum to the total");
            }
            Err(_) => panic!("deadlock: concurrent transfers/awards did not finish in time"),
        }
    }

    #[test]
    fn self_transfer_is_a_no_op() {
        let board = Board::new();
        board.join(7, 42);
        board.transfer(7, 7, 10); // must not deadlock and must change nothing
        assert_eq!(board.score(7), 42);
        assert_eq!(board.total(), 42);
    }
}