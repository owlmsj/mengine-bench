"""Concurrency-limited batch runner with clean Ctrl+C shutdown.

Usage:
    from run import run_tasks
    results = await run_tasks([task_a, task_b, ...], max_concurrent=4)

Each task is a zero-argument callable returning an awaitable job.
"""
import asyncio


async def run_tasks(tasks, max_concurrent):
    """Run jobs with at most ``max_concurrent`` running at once.

    Returns a list of results in input order once every job is done.

    If the run is interrupted before completion (Ctrl+C / KeyboardInterrupt,
    or cancellation of the surrounding task), every job is cancelled and
    awaited so that in-flight jobs finish their cleanup (finally blocks,
    ``async with`` exits) before the exception propagates. Jobs that had not
    started yet simply never run. On any job failure the same shutdown path
    runs: siblings are cancelled, cleanup is awaited, then the first
    exception is re-raised.
    """
    if max_concurrent < 1:
        raise ValueError(
            f"max_concurrent must be >= 1, got {max_concurrent!r}"
        )
    sem = asyncio.Semaphore(max_concurrent)

    async def _run(task):
        async with sem:
            return await task()

    jobs = [asyncio.ensure_future(_run(t)) for t in tasks]
    try:
        return await asyncio.gather(*jobs)
    except BaseException:
        # Interruption or failure: stop everything, but give every in-flight
        # job a chance to run its cleanup before we propagate.
        for job in jobs:
            job.cancel()
        await asyncio.gather(*jobs, return_exceptions=True)
        raise


if __name__ == "__main__":
    async def _demo(i):
        await asyncio.sleep(0.1)
        return i

    print(asyncio.run(run_tasks([lambda i=i: _demo(i) for i in range(5)], 2)))