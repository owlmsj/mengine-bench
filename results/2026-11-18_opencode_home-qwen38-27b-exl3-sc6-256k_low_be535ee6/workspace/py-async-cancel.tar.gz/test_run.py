"""Checks for run.run_tasks: concurrency cap, ordering, cleanup on stop."""
import asyncio
import os
import signal
import subprocess
import sys
import time

from run import run_tasks

CHILD = r"""
import asyncio
from run import run_tasks

async def main():
    print("started", flush=True)
    async def job(i):
        try:
            await asyncio.sleep(30)
        finally:
            print(f"cleanup {i}", flush=True)
    await run_tasks([lambda i=i: job(i) for i in range(4)], 2)
    print("finished", flush=True)

asyncio.run(main())
"""


async def test_concurrency_and_order():
    running = 0
    peak = 0

    async def job(i):
        nonlocal running, peak
        running += 1
        peak = max(peak, running)
        await asyncio.sleep(0.05)
        running -= 1
        return i

    results = await run_tasks([lambda i=i: job(i) for i in range(10)], 3)
    assert results == list(range(10)), results
    assert peak == 3, peak
    print(f"concurrency OK (peak={peak}, results in order)")


async def test_cancel_runs_cleanup():
    cleaned = []

    async def job(i):
        try:
            await asyncio.sleep(10)
        finally:
            cleaned.append(i)

    t = asyncio.create_task(run_tasks([lambda i=i: job(i) for i in range(4)], 2))
    await asyncio.sleep(0.1)
    t.cancel()
    try:
        await t
    except asyncio.CancelledError:
        pass
    # 2 jobs in flight clean up; 2 still waiting on the semaphore never start.
    assert sorted(cleaned) == [0, 1], cleaned
    print(f"cancel cleanup OK (cleaned={sorted(cleaned)})")


async def test_empty_and_validation():
    assert await run_tasks([], 3) == []
    try:
        await run_tasks([], 0)
    except ValueError:
        print("validation OK (max_concurrent=0 rejected)")
    else:
        raise AssertionError("expected ValueError")


def test_sigint_runs_cleanup():
    # Real Ctrl+C: child in its own console, parent sends CTRL_C_EVENT to it.
    kwargs = {}
    if os.name == "nt":
        kwargs["creationflags"] = subprocess.CREATE_NEW_CONSOLE
    with subprocess.Popen(
        [sys.executable, "-c", CHILD],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, **kwargs,
    ) as p:
        line = p.stdout.readline()
        assert "started" in line, line
        time.sleep(1.0)
        os.kill(p.pid, signal.CTRL_C_EVENT if os.name == "nt" else signal.SIGINT)
        out, _ = p.communicate(timeout=10)
    print("child output:", out.strip().replace("\n", " | "))
    assert "cleanup 0" in out and "cleanup 1" in out, out
    assert "finished" not in out, out
    print("sigint cleanup OK (in-flight jobs cleaned, run did not finish)")


async def main():
    await test_concurrency_and_order()
    await test_cancel_runs_cleanup()
    await test_empty_and_validation()
    test_sigint_runs_cleanup()
    print("ALL TESTS PASSED")

asyncio.run(main())