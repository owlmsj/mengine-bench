import csv, json
from collections import defaultdict

base = r"<WORKSPACE>\finance"

coa = {}
with open(base + r"\chart_of_accounts.csv", encoding="utf-8") as f:
    r = csv.reader(f, delimiter=";")
    next(r)
    for row in r:
        coa[row[0]] = row[2]

def parse_amt(s):
    s = s.strip().replace("R$", "").strip()
    neg = s.startswith("-")
    s = s.lstrip("-")
    s = s.replace(".", "").replace(",", ".")
    v = float(s)
    return -v if neg else v

months = ["2026-01","2026-02","2026-03","2026-04","2026-05","2026-06"]
line = {m: defaultdict(float) for m in months}

with open(base + r"\ledger.csv", encoding="utf-8") as f:
    r = csv.reader(f, delimiter=";")
    next(r)
    for row in r:
        d, acct, desc, amt = row
        dd, mm, yyyy = d.split("/")
        key = f"{yyyy}-{mm}"
        if key not in line:
            continue
        line[key][coa[acct]] += parse_amt(amt)

def rev(m): return line[m]["revenue"]
def cogs(m): return line[m]["cogs"]
def gross(m): return (rev(m)+cogs(m))/rev(m)*100 if rev(m) else 0.0  # cogs stored negative
def op(m): return rev(m)+line[m]["cogs"]+line[m]["sales_marketing"]+line[m]["rnd"]+line[m]["ga"]
def full(m): return sum(line[m].values())

out = {}
for m in months:
    out[m] = {
        "revenue": round(rev(m),2),
        "cogs": round(cogs(m),2),
        "gross_margin_pct": round(gross(m),2),
        "ebitda_op": round(op(m),2),
        "ebitda_full": round(full(m),2),
        "financial": round(line[m]["financial"],2),
    }

# burn: avg monthly negative EBITDA of last three closed months (Apr,May,Jun)
last3 = ["2026-04","2026-05","2026-06"]
for label, fn in [("op", op), ("full", full)]:
    vals = [fn(m) for m in last3]
    negs = [-v for v in vals if v < 0]
    burn = sum(negs)/len(negs) if negs else 0
    cash = 1847350.40
    print(label, "last3 ebitda:", [round(v,2) for v in vals], "burn:", round(burn,2), "runway:", round(cash/burn,2))

print(json.dumps(out, indent=2))

# Final result.json: EBITDA = full monthly P&L (no D&A/tax accounts in ledger)
result = {
    "revenue": {m: out[m]["revenue"] for m in months},
    "gross_margin_pct": {m: out[m]["gross_margin_pct"] for m in months},
    "ebitda": {m: out[m]["ebitda_full"] for m in months},
    "burn": round(sum(-full(m) for m in last3)/3, 2),
    "runway_months": round(1847350.40 / (sum(-full(m) for m in last3)/3), 2),
}
with open(base + r"\..\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print("WROTE result.json")
print(json.dumps(result, indent=2))