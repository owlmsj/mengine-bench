# H1 2026 Close - CFO Brief

All figures from `finance/ledger.csv` (86 entries, Jan-Jun 2026), mapped via
`chart_of_accounts.csv`. Currency: BRL (R$).

## Monthly P&L (R$)

| Month | Revenue | COGS | Gross margin | EBITDA |
|-------|---------:|------:|-------------:|-------:|
| 2026-01 | 200,510.87 | (60,091.92) | 70.03% | (203,812.19) |
| 2026-02 | 216,328.06 | (64,278.71) | 70.29% | (205,001.69) |
| 2026-03 | 219,066.17 | (69,096.05) | 68.46% | (198,078.94) |
| 2026-04 | 238,163.26 | (70,867.73) | 70.24% | (189,670.28) |
| 2026-05 | 243,032.89 | (73,973.13) | 69.56% | (195,444.78) |
| 2026-06 | 272,391.57 | (75,162.69) | 72.41% | (187,346.57) |

## Headline
- Revenue grew every month: R$200.5k (Jan) -> R$272.4k (Jun), +35.8% over H1.
- Gross margin stable ~70%, best in June (72.41%).
- Losses narrowed each month; June EBITDA (R$187.3k) is the smallest of the half.

## Burn & Runway (per board definition in README)
- Burn = average monthly negative EBITDA of last 3 closed months (Apr, May, Jun):
  (189,670.28 + 195,444.78 + 187,346.57) / 3 = **R$190,820.54 / month**
- Latest closing cash (30/06/2026) = R$1,847,350.40
- Runway = 1,847,350.40 / 190,820.54 = **9.68 months** (cash out ~mid-April 2027)

## Assumptions
1. EBITDA = full monthly P&L (all ledger lines incl. financial income/interest),
   because the ledger has no depreciation, amortization or tax accounts. The
   financial line is small (~+R$6-7k/mo net).
   - If the board prefers operating-only EBITDA (excl. financial): burn
     R$197,288.23, runway 9.36 months.
2. Revenue is net of refunds/cancellations (account 3.1.09, "Refunds and
   cancellations" mapped to revenue).
3. "Last three closed months" = Apr, May, Jun 2026; latest cash = 30/06/2026.

## Key figures (recorded in ./result.json)
- burn: 190820.54
- runway_months: 9.68