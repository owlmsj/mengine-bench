HANDOFF - local-9b Q5 @128k
Only source is session/transcript.md (no repo here).

Task: measure local-9b Q5 at 128k context.
Valid result: first run `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024` gave 37.8 t/s, 7881 MiB, but Shared Usage 1494 MiB spilled (WDDM ceiling) - invalid. With `--no-mmproj-offload` and `-ub 512`: VRAM 7697 MiB, decode 38.0 t/s (median of 3), spill gone - this is the confirmed number.
Also: Q6_K (7.03 GiB) does not fit at 128k; discarded. Q4_K_M fits (7305 MiB, 40.4 t/s), kept only as fallback.
Recipe applied in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.
Open items: (1) evals README still cites check_vision.ps1 - update it; (2) verify script/profile parse and re-run one clean measurement; (3) confirm server actually reports 131072 context.
Assumption: transcript is sole source of truth; nothing else in workspace to check.
Evidence: transcript: 37.8/7881 + 1494 spill (invalid); 38.0/7697 (valid).


