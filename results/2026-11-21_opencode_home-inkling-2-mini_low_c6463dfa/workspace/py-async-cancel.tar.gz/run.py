import asyncio


async def run_tasks(tasks, max_concurrent):
    if max_concurrent < 1:
        raise ValueError("max_concurrent must be >= 1")

    sem = asyncio.Semaphore(max_concurrent)

    async def worker(task):
        async with sem:
            job = task()
            await job

    children = [asyncio.ensure_future(worker(t)) for t in tasks]
    try:
        await asyncio.gather(*children)
    except BaseException:
        for c in children:
            c.cancel()
        await asyncio.gather(*children, return_exceptions=True)
        raise
