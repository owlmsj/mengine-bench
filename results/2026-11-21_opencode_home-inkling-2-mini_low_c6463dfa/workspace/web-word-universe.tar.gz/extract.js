const fs = require('fs');
const files = fs.readdirSync('site').filter(f => f.endsWith('.html'));
const skip = new Set(['index.html', 'contato.html', 'sobre.html']);
const redirectTarget = {};
const htmlOf = {};
for (const f of files) {
  const html = fs.readFileSync('site/' + f, 'utf8');
  htmlOf[f] = html;
  const r = html.match(/url=([^"']+)/);
  if (r) redirectTarget[f.toLowerCase()] = r[1].toLowerCase();
}
// h1 word for each file
const fileWord = {};
for (const f of files) {
  const html = htmlOf[f];
  if (redirectTarget[f.toLowerCase()]) continue;
  if (skip.has(f)) continue;
  const h1 = html.match(/<h1>(.*?)<\/h1>/i);
  if (h1) fileWord[f.toLowerCase()] = h1[1].trim();
}
function resolveFile(ref) {
  ref = decodeURIComponent(ref).toLowerCase();
  return redirectTarget[ref] || ref;
}
const words = {};
for (const f of files) {
  const key = f.toLowerCase();
  if (redirectTarget[key] || skip.has(f)) continue;
  const word = fileWord[key];
  if (!word) continue;
  const html = htmlOf[f];
  const sections = [...html.matchAll(/<section[^>]*>([\s\S]*?)<\/section>/g)];
  const linked = new Set();
  for (const s of sections) {
    for (const m of s[1].matchAll(/<a href="([^"]+)"/g)) {
      const target = resolveFile(m[1]);
      if (fileWord[target]) linked.add(fileWord[target]);
    }
  }
  words[word] = [...linked].sort((a, b) => a.localeCompare(b, 'pt'));
}
// build stats
const pairs = new Set();
for (const w in words) for (const l of words[w]) {
  const p = [w, l].sort((a, b) => a.localeCompare(b, 'pt'));
  pairs.add(p.join('|'));
}
const deg={}; for(const w in words){deg[w]=(deg[w]||0)+words[w].length; for(const l of words[w]) deg[l]=(deg[l]||0)+1;}
let maxW=null,maxC=-1; for(const w in deg){if(deg[w]>maxC){maxC=deg[w];maxW=w;}}
fs.writeFileSync('words.json', JSON.stringify(words, null, 2));
const result = {
  words: Object.keys(words).length,
  relations: pairs.size,
  most_connected: maxW,
  most_connected_count: maxC
};
fs.writeFileSync('result.json', JSON.stringify(result, null, 2));
console.log('words:', result.words, 'relations:', result.relations, 'most_connected:', maxW, '(', maxC, ')');
