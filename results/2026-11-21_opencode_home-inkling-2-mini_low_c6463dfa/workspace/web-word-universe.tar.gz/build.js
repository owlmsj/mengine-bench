const fs = require('fs');
const words = JSON.parse(fs.readFileSync('words.json', 'utf8'));
const names = Object.keys(words);
const idx = {}; names.forEach((n, i) => idx[n] = i);
const edges = [];
const seen = new Set();
for (const w in words) for (const l of words[w]) {
  const a = idx[w], b = idx[l];
  if (a === undefined || b === undefined) continue;
  const k = a < b ? a + '-' + b : b + '-' + a;
  if (!seen.has(k)) { seen.add(k); edges.push([a, b]); }
}
const data = { words: names, links: words };
const html = fs.readFileSync('template.html', 'utf8').replace('/*__DATA__*/', JSON.stringify(data));
fs.writeFileSync('universe/index.html', html);
console.log('written', html.length, 'bytes;', names.length, 'words;', edges.length, 'edges');
