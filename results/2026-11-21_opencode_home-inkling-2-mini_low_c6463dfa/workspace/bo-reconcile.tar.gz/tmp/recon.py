import csv, re, json
inv={}
with open('backoffice/invoices.csv',encoding='utf-8') as f:
    for r in csv.DictReader(f):
        inv[r['id'].strip()]=float(r['amount'])
pay={}
with open('backoffice/bank_statement_june.csv',encoding='utf-8') as f:
    for r in csv.DictReader(f):
        memo=r['memo']; amt=float(r['amount'])
        m=re.search(r'(?:INV|invoice|inv)[-\s]*0*(\d{4})',memo,re.I)
        if not m: continue
        iid='INV-'+m.group(1)
        pay.setdefault(iid,[]).append(amt)
unpaid=[];dup=[];mismatch=[]
for iid,amt in inv.items():
    if iid not in pay: unpaid.append(iid); continue
    ps=pay[iid]
    if len(ps)>1: dup.append(iid)
    elif abs(ps[0]-amt)>0.005: mismatch.append({'id':iid,'invoiced':amt,'paid':ps[0]})
print('unpaid',unpaid)
print('dup',dup)
print('mismatch',mismatch)
print('unmatched payments', {k:v for k,v in pay.items() if k not in inv})
with open('result.json','w',encoding='utf-8') as f:
    json.dump({'unpaid':unpaid,'duplicated':dup,'mismatched':mismatch},f,indent=2)
