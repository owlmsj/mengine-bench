import asyncio, sys
from run import run_tasks

async def main():
    active = 0
    peak = 0
    started = []
    cleaned = []

    def make(i):
        async def job():
            nonlocal active, peak
            started.append(i)
            active += 1
            peak = max(peak, active)
            try:
                await asyncio.sleep(0.02)
            finally:
                active -= 1
                cleaned.append(i)
        return job

    await run_tasks([make(i) for i in range(9)], 3)
    assert peak == 3, peak
    assert sorted(cleaned) == list(range(9))
    assert len(started) == 9
    print("concurrency ok peak=", peak)

    # laziness: only first max_concurrent callables invoked at start
    calls = []
    gate = asyncio.Event()
    def factory(i):
        calls.append(i)
        async def job():
            await gate.wait()
        return job
    t = asyncio.ensure_future(run_tasks([lambda i=i: factory(i)() for i in range(6)], 2))
    await asyncio.sleep(0.01)
    assert calls == [0, 1], calls
    gate.set()
    await t
    print("laziness ok")

    # cancellation runs cleanup
    cleaned2 = []
    async def long_job(i):
        try:
            await asyncio.sleep(10)
        finally:
            cleaned2.append(i)
    t = asyncio.ensure_future(run_tasks([lambda i=i: long_job(i) for i in range(3)], 2))
    await asyncio.sleep(0.01)
    t.cancel()
    try:
        await t
    except asyncio.CancelledError:
        pass
    assert sorted(cleaned2) == [0, 1], cleaned2
    print("cleanup ok", sorted(cleaned2))

asyncio.run(main())
