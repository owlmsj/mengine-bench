"""Concurrency helper for batch scripts.

``run_tasks`` starts at most ``max_concurrent`` jobs at once. A task is a
zero-argument callable that returns an awaitable; it is only called once a
slot is free, so queued work is never started eagerly.

Cancellation (e.g. Ctrl+C handled by ``asyncio.run``) cancels the running
jobs and still awaits them, so their ``finally`` / cleanup code runs before
the interruption propagates.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Iterable
from typing import Any

TaskFactory = Callable[[], Awaitable[Any]]


async def run_tasks(tasks: Iterable[TaskFactory], max_concurrent: int) -> None:
    """Run every job produced by ``tasks`` with bounded concurrency.

    Returns once every job has finished. If the surrounding task is
    cancelled, running and queued jobs are cancelled, their cleanup is
    awaited, and ``CancelledError`` is re-raised.
    """
    if max_concurrent < 1:
        raise ValueError(
            f"max_concurrent must be >= 1, got {max_concurrent!r}"
        )

    semaphore = asyncio.Semaphore(max_concurrent)

    async def run_one(task: TaskFactory) -> None:
        # The callable is invoked only after a slot is acquired, which keeps
        # queued tasks lazy and never exceeds the concurrency limit.
        async with semaphore:
            await task()

    jobs = [asyncio.ensure_future(run_one(task)) for task in tasks]
    if not jobs:
        return

    try:
        await asyncio.gather(*jobs)
    except BaseException:
        # Covers KeyboardInterrupt-driven cancellation as well as a job
        # failing. Cancel the rest, then wait so cleanup code can run.
        for job in jobs:
            job.cancel()
        await asyncio.gather(*jobs, return_exceptions=True)
        raise
