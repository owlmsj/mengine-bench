"""Settings for the backup agent."""

import os

API_URL = "https://backup.example.invalid/v1/upload"
# The token is a secret: it comes from the environment only, never from code
# and never from a file that is shipped with the service.
API_TOKEN = [REDACTED:env]"BACKUP_TOKEN", "")
ARCHIVE_DIR = "archives"
