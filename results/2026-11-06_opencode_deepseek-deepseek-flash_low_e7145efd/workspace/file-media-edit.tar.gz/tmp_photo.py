from PIL import Image
import numpy as np

src = Image.open('launch.jpg').convert('RGB')
W, H = src.size

# 4:5 portrait crop that keeps the whole balloon + basket.
# Balloon envelope x 2350..2750; basket bottom ~1045. Right-anchored crop
# leaves 250px (15.6%) of sky to the right of the envelope.
target_w, target_h = 1080, 1350
crop_h = H
crop_w = int(round(crop_h * target_w / target_h))  # 1600
left = W - crop_w                                    # 1400
top = 0
box = (left, top, left + crop_w, top + crop_h)

crop = src.crop(box).resize((target_w, target_h), Image.LANCZOS)
crop.save('out/feed-photo.jpg', 'JPEG', quality=92, optimize=True, progressive=True, subsampling=0)

# checks
out = Image.open('out/feed-photo.jpg')
print('src', src.size, 'box', box, 'out', out.size, out.mode)

a = np.asarray(out).astype(int)
R, G, B = a[:,:,0], a[:,:,1], a[:,:,2]
m = (R > 150) & (B > 120) & (G < 110) & (R - G > 90)
ys, xs = np.nonzero(m)
print('magenta px', m.sum(), 'bbox x', xs.min(), xs.max(), 'y', ys.min(), ys.max())
# roundness of envelope: width vs height of magenta blob
print('envelope w/h', xs.max()-xs.min()+1, ys.max()-ys.min()+1)
