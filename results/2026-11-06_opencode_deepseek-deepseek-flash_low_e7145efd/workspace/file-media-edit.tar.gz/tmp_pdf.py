from pypdf import PdfReader, PdfWriter
from pypdf.generic import NameObject, DecodedStreamObject

answers = {
    'organizer':  'Tidewater Studio',
    'event_date': '2026-12-05',
    'location':   'North Cove Lawn',
    'attendees':  'about 40',
}

reader = PdfReader('permit-form.pdf')
writer = PdfWriter(clone_from=reader)
page = writer.pages[0]
root = writer._root_object

def esc(s: str) -> str:
    return s.replace('\\', r'\\').replace('(', r'\(').replace(')', r'\)')

ops = []
fields = {}
for ref in page.get('/Annots', []):
    a = ref.get_object()
    name = str(a['/T'])
    x0, y0, x1, y1 = (float(v) for v in a['/Rect'])
    w, h = x1 - x0, y1 - y0
    fields[name] = (x0, y0, w, h)

# Draw the field backgrounds (the removed widgets' appearance) then the answers.
for name in ('organizer', 'event_date', 'location', 'attendees'):
    x0, y0, w, h = fields[name]
    ops.append(f"0.95 0.95 1 rg {x0:.2f} {y0:.2f} {w:.2f} {h:.2f} re f")
for name, value in answers.items():
    x0, y0, w, h = fields[name]
    size = 11
    baseline = y0 + (h - size) / 2 + size * 0.28
    ops.append(f"BT /Helv {size} Tf 0 0 0 rg {x0 + 7:.2f} {baseline:.2f} Td ({esc(value)}) Tj ET")

extra = DecodedStreamObject()
extra.set_data(("\n".join(ops) + "\n").encode('latin-1'))

old = page.get_contents()
page[NameObject('/Contents')] = writer._add_object(extra)
if old is not None:
    extra_data = old.get_data() + b"\n"
    merged = DecodedStreamObject()
    merged.set_data(extra_data + extra.get_data())
    page[NameObject('/Contents')] = writer._add_object(merged)

if '/Annots' in page:
    del page[NameObject('/Annots')]
root.pop(NameObject('/AcroForm'), None)

writer.add_metadata({'/Title': 'Event Permit Application EP-3 - Tidewater Studio'})
with open('out/permit-filled.pdf', 'wb') as fh:
    writer.write(fh)

print('wrote out/permit-filled.pdf')

chk = PdfReader('out/permit-filled.pdf')
p = chk.pages[0]
print('fields:', chk.get_fields())
print('annots:', p.get('/Annots'))
print('acroform:', chk.trailer['/Root'].get('/AcroForm'))
print('text:', repr(p.extract_text()))
raw = open('out/permit-filled.pdf','rb').read()
print('bytes', len(raw), 'Widget' in raw.decode('latin-1'), '/Tx' in raw.decode('latin-1'))
