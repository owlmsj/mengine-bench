from pypdf import PdfReader, PdfWriter
from pypdf.generic import (NameObject, DecodedStreamObject, DictionaryObject)

answers = [
    ('Tidewater Studio', 640.0),
    ('2026-12-05', 600.0),
    ('North Cove Lawn', 560.0),
    ('about 40', 520.0),
]
FIELDS_X, FIELDS_W, FIELDS_H = 200.0, 320.0, 24.0
SIZE = 11

def esc(s: str) -> str:
    return s.replace('\\', r'\\').replace('(', r'\(').replace(')', r'\)')

src = PdfReader('permit-form.pdf')
original = src.pages[0].get_contents().get_data().decode('latin-1').rstrip('\n')

ops = [original]
for _, y0 in answers:
    ops.append(f"0.95 0.95 1 rg {FIELDS_X:.2f} {y0:.2f} {FIELDS_W:.2f} {FIELDS_H:.2f} re f")
for value, y0 in answers:
    baseline = y0 + (FIELDS_H - SIZE) / 2 + SIZE * 0.28
    ops.append(f"BT /Helv {SIZE} Tf 0 0 0 rg {FIELDS_X + 7:.2f} {baseline:.2f} Td ({esc(value)}) Tj ET")

writer = PdfWriter()
page = writer.add_blank_page(width=595, height=842)
font = DictionaryObject({
    NameObject('/Type'): NameObject('/Font'),
    NameObject('/Subtype'): NameObject('/Type1'),
    NameObject('/BaseFont'): NameObject('/Helvetica'),
    NameObject('/Encoding'): NameObject('/WinAnsiEncoding'),
})
page[NameObject('/Resources')] = DictionaryObject({
    NameObject('/Font'): DictionaryObject({NameObject('/Helv'): writer._add_object(font)})
})
stream = DecodedStreamObject()
stream.set_data(("\n".join(ops) + "\n").encode('latin-1'))
page[NameObject('/Contents')] = writer._add_object(stream)
writer.add_metadata({'/Title': 'Event Permit Application EP-3 - Tidewater Studio'})
with open('out/permit-filled.pdf', 'wb') as fh:
    writer.write(fh)

raw = open('out/permit-filled.pdf', 'rb').read().decode('latin-1')
print('has /Widget:', '/Widget' in raw, '| /AcroForm:', '/AcroForm' in raw,
      '| /Annots:', '/Annots' in raw, '| /FT:', '/FT' in raw)
chk = PdfReader('out/permit-filled.pdf')
p = chk.pages[0]
print('pages', len(chk.pages), 'box', p.mediabox, 'fields', chk.get_fields(), 'annots', p.get('/Annots'))
print(p.extract_text())
