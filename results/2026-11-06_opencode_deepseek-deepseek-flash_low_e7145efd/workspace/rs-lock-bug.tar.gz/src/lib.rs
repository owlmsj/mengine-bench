//! Player scores shared between the match threads of the Pixel Arena server.
//!
//! All mutable state lives behind one mutex so every operation is atomic and no
//! two locks can ever be taken in a conflicting order. Per-player slots holding
//! their own `Arc<Mutex<i64>>` used to cause two failures under load:
//!
//! * `award` read a score, released the lock, then wrote `score + points` back,
//!   so concurrent awards overwrote each other and the board came out low.
//! * `transfer` locked `from` and then `to`, so opposite transfers in two
//!   threads deadlocked (ABBA) and `transfer(id, id, ..)` deadlocked on itself.
//!   The match server hung and threads never finished.
//!
//! The public API and its semantics are unchanged.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Scores plus the board total, updated together under the board lock.
#[derive(Default)]
struct Scores {
    players: HashMap<PlayerId, i64>,
    total: i64,
}

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    scores: Arc<Mutex<Scores>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    /// Registers a player with `score`. Re-joining an existing player resets
    /// that player's score and moves the total by the difference, so the
    /// invariant `total == sum of all player scores` always holds.
    pub fn join(&self, id: PlayerId, score: i64) {
        let mut scores = self.scores.lock().unwrap();
        let previous = scores.players.insert(id, score).unwrap_or(0);
        scores.total += score - previous;
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let mut scores = self.scores.lock().unwrap();
        let score = scores
            .players
            .get_mut(&id)
            .unwrap_or_else(|| panic!("award for unknown player {id}"));
        *score += points;
        scores.total += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return;
        }
        let mut scores = self.scores.lock().unwrap();
        if !scores.players.contains_key(&from) {
            panic!("transfer from unknown player {from}");
        }
        if !scores.players.contains_key(&to) {
            panic!("transfer to unknown player {to}");
        }
        *scores.players.get_mut(&from).unwrap() -= points;
        *scores.players.get_mut(&to).unwrap() += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self
            .scores
            .lock()
            .unwrap()
            .players
            .get(&id)
            .unwrap_or_else(|| panic!("score for unknown player {id}"))
    }

    pub fn total(&self) -> i64 {
        self.scores.lock().unwrap().total
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::mpsc;
    use std::thread;
    use std::time::Duration;

    const WAIT: Duration = Duration::from_secs(5);

    #[test]
    fn concurrent_awards_do_not_lose_points() {
        let board = Board::new();
        board.join(1, 0);
        let handles: Vec<_> = (0..8)
            .map(|_| {
                let b = board.clone();
                thread::spawn(move || {
                    for _ in 0..1000 {
                        b.award(1, 1);
                    }
                })
            })
            .collect();
        for h in handles {
            h.join().unwrap();
        }
        assert_eq!(board.score(1), 8000);
        assert_eq!(board.total(), 8000);
    }

    #[test]
    fn opposite_transfers_finish_without_deadlock() {
        let board = Board::new();
        board.join(1, 100);
        board.join(2, 100);
        let (tx, rx) = mpsc::channel();
        for _ in 0..4 {
            for (from, to) in [(1, 2), (2, 1)] {
                let (b, tx) = (board.clone(), tx.clone());
                thread::spawn(move || {
                    for _ in 0..1000 {
                        b.transfer(from, to, 1);
                    }
                    let _ = tx.send(());
                });
            }
        }
        drop(tx);
        for _ in 0..8 {
            assert!(rx.recv_timeout(WAIT).is_ok(), "transfer hung");
        }
        assert_eq!(board.score(1) + board.score(2), 200);
        assert_eq!(board.total(), 200);
    }

    #[test]
    fn self_transfer_returns_instead_of_hanging() {
        let board = Board::new();
        board.join(1, 50);
        let (tx, rx) = mpsc::channel();
        let b = board.clone();
        thread::spawn(move || {
            b.transfer(1, 1, 10);
            let _ = tx.send(());
        });
        assert!(rx.recv_timeout(WAIT).is_ok(), "self transfer hung");
        assert_eq!((board.score(1), board.total()), (50, 50));
    }

    #[test]
    fn rejoin_keeps_total_equal_to_the_sum_of_scores() {
        let board = Board::new();
        board.join(1, 10);
        board.join(1, 40);
        assert_eq!((board.score(1), board.total()), (40, 40));
    }
}
