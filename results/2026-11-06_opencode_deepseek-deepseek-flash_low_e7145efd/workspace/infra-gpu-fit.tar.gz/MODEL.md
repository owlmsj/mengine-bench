# Model to serve: arena-coder-70b

| property | value |
| --- | --- |
| parameters | 70 billion |
| weight precision | 8-bit (FP8) |
| KV cache | 327,680 bytes per token (FP16, all layers, K and V) |
| context we want per sequence | 32,768 tokens |
| concurrent sequences | 4 |
| runtime overhead | 8 GB for the whole deployment (CUDA context, activations), whatever the GPU count |

Every sequence must be able to hold its full context at the same time.
The runtime shards weights and KV cache across all GPUs of one offer (tensor parallel),
so an offer's usable memory is gpu_count x vram_gb_per_gpu.

Units: GB = 10^9 bytes everywhere in these docs and in offers.csv.
