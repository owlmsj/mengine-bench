# Rental policy

- Hourly cap: US$ 4 per hour for the whole deployment. Nothing above it is rented.
- Rent only offers that are in stock now (`in_stock` = yes).
- Allowed regions: us-east, us-central, eu-west.
- `usd_per_hour` in offers.csv is the price of the whole offer (all its GPUs), not per GPU.
- One offer per deployment; we do not combine offers.
- Monthly cost = hourly price x 730 hours.
