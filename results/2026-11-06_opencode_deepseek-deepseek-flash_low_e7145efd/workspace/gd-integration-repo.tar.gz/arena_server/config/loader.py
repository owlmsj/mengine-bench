"""Runtime config. Precedence, lowest to highest: DEFAULTS < JSON file < env (docs/CONFIG.md)."""

import json
import os

from arena_server.config.defaults import DEFAULTS


def _coerce(raw, like):
    return type(like)(raw)


def load_config(file_path=None, env=None):
    cfg = dict(DEFAULTS)
    if file_path:
        with open(file_path, encoding="utf-8") as fh:
            cfg.update(json.load(fh))
    env = os.environ if env is None else env
    for key, raw in env.items():
        if not key.startswith("ARENA_"):
            continue
        name = key[len("ARENA_"):].lower()
        # Coerce against the value already in cfg (file or default) so the
        # merged environment keeps the type callers expect.
        if name in cfg:
            cfg[name] = _coerce(raw, cfg[name])
        else:
            cfg[name] = raw
    return cfg
