"""Match payout. Rules live in docs/ECONOMY.md."""

from decimal import Decimal, ROUND_HALF_UP


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    # str() keeps binary float artifacts out of the rounding step, so exact
    # halves (1425, 1585) always go up as docs/ECONOMY.md requires.
    raw = (Decimal(str(base)) + Decimal(str(kills)) * Decimal(str(cfg["kill_bonus"]))) \
        * Decimal(str(cfg["event_multiplier"]))
    tens = (raw / 10).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    return int(tens) * 10
