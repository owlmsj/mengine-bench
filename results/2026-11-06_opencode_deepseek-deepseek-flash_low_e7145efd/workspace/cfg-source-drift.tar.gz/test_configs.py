"""Regression test: every harness config must agree with models.json.

Run: python -m unittest test_configs -v
"""

import json
import tomllib
import unittest
from pathlib import Path

import gen

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "out"


def load_models():
    data = json.loads((ROOT / "models.json").read_text(encoding="utf-8"))
    return {model["name"]: model for model in data["models"]}


class HarnessConfigAgreement(unittest.TestCase):
    def setUp(self):
        self.models = load_models()

    def test_generated_files_are_up_to_date(self):
        # out/ is generated; hand edits or a stale models.json must not survive.
        for filename, render in (
            ("opencode.json", gen.opencode),
            ("codex.toml", gen.codex),
            ("claude.json", gen.claude),
        ):
            with self.subTest(filename=filename):
                expected = render(list(self.models.values()))
                actual = (OUT / filename).read_text(encoding="utf-8")
                self.assertEqual(actual, expected, f"out/{filename} is stale; run python gen.py")

    def test_context_windows_agree_across_harnesses(self):
        opencode = json.loads((OUT / "opencode.json").read_text(encoding="utf-8"))
        claude = json.loads((OUT / "claude.json").read_text(encoding="utf-8"))
        codex = tomllib.loads((OUT / "codex.toml").read_text(encoding="utf-8"))

        opencode_models = opencode["provider"]["workstation"]["models"]
        claude_models = {entry["id"]: entry for entry in claude["models"]}
        codex_models = codex["models"]

        for name, model in self.models.items():
            with self.subTest(model=name):
                contexts = {
                    "models.json": model["context_window"],
                    "opencode.json": opencode_models[name]["limit"]["context"],
                    "codex.toml": codex_models[name]["context_window"],
                    "claude.json": claude_models[name]["contextWindow"],
                }
                self.assertEqual(
                    set(contexts.values()), {model["context_window"]},
                    f"context window disagrees for {name}: {contexts}",
                )

    def test_fast_coder_context_window_is_262144(self):
        self.assertEqual(
            self.models["fast-coder"]["context_window"], 262144,
            "fast-coder's real context window is 262144 tokens",
        )


if __name__ == "__main__":
    unittest.main()
