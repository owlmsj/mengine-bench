# Harness model configs

The model settings that OpenCode, Codex and Claude Code read on the workstation.

- `models.json`: the models we serve and their limits.
- `gen.py`: writes `out/` from `models.json` (`python gen.py`).
- `out/`: generated; the install step copies these files into each harness.
- `test_configs.py`: checks `out/` is in sync with `models.json` and that all
  three harnesses agree (`python -m unittest test_configs -v`).
