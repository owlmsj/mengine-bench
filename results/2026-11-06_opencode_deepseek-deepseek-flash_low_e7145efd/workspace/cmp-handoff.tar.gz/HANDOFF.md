# Handoff: local-9b Q5 @ 128k (ctx 131072)

## Where it stands
- Valid: `--no-mmproj-offload -ub 512` kills the spill -> VRAM 7697 MiB, decode 38.0 t/s (median of 3). Report this.
- Invalid: the 37.8 t/s / 7881 MiB run hit the 7881 MiB WDDM ceiling; Shared Usage showed 1494 MiB spilled, so it does not count.
- Q6_K (7.03 GiB) does not fit at 128k, discarded. Q4_K_M fits (7305 MiB, 40.4 t/s) but is fallback only.
- Recipe applied in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

## Assumptions
- The 38.0 t/s run is Q5 (only quant requested; never restated).
- 131072 = 128k.

## Left to do
1. Restart from the edited config, re-run `scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`, confirm no spill (config change unverified).
2. evals README still cites check_vision.ps1, which no longer exists. Fix.
3. Low: scratchpad temp file names.

## How I know
Only lines 30, 44, 124, 132, 185, 222 carry results; the rest is filler that changed nothing.
