/**
 * Hook bus for harness plugins (OpenCode-style hooks). The README states the contract:
 * handlers run one after another in subscription order, emit resolves after all of them,
 * a handler error rejects emit, and unsubscribing during an emit does not stop the others.
 */

export type Handler<T> = (payload: T) => void | Promise<void>;

export class HookBus {
  private handlers: Map<string, Handler<unknown>[]> = new Map();

  /** Subscribes a handler to an event; returns the function that unsubscribes it. */
  on<T>(event: string, handler: Handler<T>): () => void {
    const list = this.handlers.get(event) ?? [];
    list.push(handler as Handler<unknown>);
    this.handlers.set(event, list);
    return () => {
      // Remove from the current list, not the one captured above: the event may
      // have been cleared or replaced while this subscription was alive.
      const current = this.handlers.get(event);
      if (!current) return;
      const index = current.indexOf(handler as Handler<unknown>);
      if (index >= 0) {
        current.splice(index, 1);
      }
    };
  }

  /** Runs the handlers of an event with the payload. */
  async emit<T>(event: string, payload: T): Promise<void> {
    // Snapshot: handlers subscribed or unsubscribed during this emit must not
    // change the set that runs. The copy also keeps the live list intact for
    // unsubscribe to mutate safely.
    const snapshot = [...(this.handlers.get(event) ?? [])];
    for (const handler of snapshot) {
      await handler(payload);
    }
  }

  /** How many handlers an event has. */
  count(event: string): number {
    return (this.handlers.get(event) ?? []).length;
  }
}
