from PIL import Image, ImageDraw, ImageFont
W,H=1200,675
img=Image.new("RGB",(W,H),(16,42,67))
d=ImageDraw.Draw(img)
# gradient sky bands
for y in range(H):
    t=y/H
    r=int(16+ (232-16)*t**1.7)
    g=int(42+ (190-42)*t**1.7)
    b=int(67+ (150-67)*t**1.7)
    d.line([(0,y),(W,y)],fill=(r,g,b))
# sea
d.rectangle([0,470,W,H],fill=(20,70,110))
d.rectangle([0,470,W,478],fill=(235,225,200))
# sun
d.ellipse([820,120,980,280],fill=(255,238,190))
# lighthouse
d.polygon([(180,470),(230,200),(280,470)],fill=(245,240,230))
d.rectangle([214,160,246,210],fill=(200,60,50))
d.rectangle([205,470,255,500],fill=(120,90,70))
for y in range(240,460,60):
    d.rectangle([200+ (470-y)*0.05, y, 260-(470-y)*0.05, y+22],fill=(200,60,50))
# title
font=None
for p in [r"C:\Windows\Fonts\seguisb.ttf", r"C:\Windows\Fonts\arialbd.ttf", r"C:\Windows\Fonts\segoeuib.ttf"]:
    try:
        font=ImageFont.truetype(p,96); break
    except Exception: pass
if font is None: font=ImageFont.load_default()
text="Harbor Day 2026"
bb=d.textbbox((0,0),text,font=font)
tw,th=bb[2]-bb[0],bb[3]-bb[1]
x=(W-tw)//2; y=545
d.rectangle([x-30,y-22,x+tw+30,y+th+26],fill=(10,28,45))
d.text((x-bb[0],y-bb[1]),text,font=font,fill=(255,245,220))
font2=ImageFont.truetype(r"C:\Windows\Fonts\segoeui.ttf",34)
sub="North Cove  -  Save the date"
d.text(((W-d.textlength(sub,font=font2))//2,628),sub,font=font2,fill=(220,230,240))
img.save("cover.png","PNG")
print(img.size, img.mode)
