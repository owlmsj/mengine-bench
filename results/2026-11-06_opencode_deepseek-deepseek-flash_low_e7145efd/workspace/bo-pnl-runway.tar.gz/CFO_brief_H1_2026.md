# CFO Brief - First Half 2026 (Jan-Jun)

All figures in BRL, from `finance/ledger.csv`, mapped through `finance/chart_of_accounts.csv`. The six months are complete and closed.

## Headline

- H1 revenue: **R$ 1,389,492.82**
- H1 EBITDA: **R$ -1,218,969.18**
- Average gross margin: **70.17%**
- Monthly revenue grew **35.8%** from January to June (R$ 200,510.87 to R$ 272,391.57).
- EBITDA loss narrowed **8.2%** from January to June, but May slipped back and the trend is not yet a straight line.
- Board burn definition (average monthly negative EBITDA, last three closed months): **R$ 197,288.23**
- Latest cash (30/06/2026): **R$ 1,847,350.40**
- Runway: **9.36 months**, to about early April 2027, assuming flat burn and no new funding.

## Monthly P&L

| Month | Revenue (R$) | Gross margin | EBITDA (R$) |
|---|---:|---:|---:|
| 2026-01 | 200,510.87 | 70.03% | -210,278.96 |
| 2026-02 | 216,328.06 | 70.29% | -212,300.08 |
| 2026-03 | 219,066.17 | 68.46% | -204,525.45 |
| 2026-04 | 238,163.26 | 70.24% | -196,950.65 |
| 2026-05 | 243,032.89 | 69.56% | -201,945.82 |
| 2026-06 | 272,391.57 | 72.41% | -192,968.22 |

Quarter view: Q1 revenue R$ 635,905.10, Q2 revenue R$ 753,587.72 (+18.5% QoQ). Q1 EBITDA -R$ 627,104.49, Q2 EBITDA -R$ 591,864.69. Gross profit grew 20.6% while operating costs grew 5.2%, which is the operating leverage to protect.

## How each month went

- **January:** Opening month, R$ 200.5k revenue, 70.0% gross margin, EBITDA -R$ 210.3k. Highest monthly loss of the half.
- **February:** Revenue +7.9% to R$ 216.3k, margin flat at 70.3%, but EBITDA dipped to -R$ 212.3k as operating costs rose.
- **March:** Revenue +1.3% to R$ 219.1k, margin fell to the half-year low of 68.5%, EBITDA improved to -R$ 204.5k.
- **April:** Revenue +8.7% to R$ 238.2k, margin recovered to 70.2%, EBITDA -R$ 197.0k, the best month of the half until June.
- **May:** Revenue +2.0% to R$ 243.0k, margin 69.6%, EBITDA slipped to -R$ 201.9k on higher sales and G&A costs.
- **June:** Strongest month: revenue +12.1% to R$ 272.4k, margin 72.4% (half-year high), EBITDA -R$ 193.0k (smallest loss of the half).

## Cash and runway

The board's definition is used: burn = average of the last three closed months' negative EBITDA (April, May, June) = (196,950.65 + 201,945.82 + 192,968.22) / 3 = **R$ 197,288.23**. Runway = 1,847,350.40 / 197,288.23 = **9.36 months** from 30 June 2026.

At the current burn the company reaches roughly **early April 2027**. A six-month buffer means new funding should be secured by around **October 2026**.

**Cash reconciliation flag:** cash fell R$ 461,837.60 from 31 May to 30 June, while June EBITDA plus financial result was only -R$ 187,346.57. About **R$ 274,491.03 of June outflow is not explained by the P&L ledger** (possible working capital, capex, taxes or financing items). Confirm before presenting the cash bridge.

## Assumptions and definitions

1. Revenue = accounts 3.1.01 SaaS subscriptions + 3.1.02 onboarding services + 3.1.09 refunds and cancellations (refunds reduce revenue).
2. Gross profit = revenue - COGS (4.1.01 production cloud and GPUs + 4.1.02 customer support). Gross margin = gross profit / revenue.
3. EBITDA = gross profit - sales and marketing - R&D - G&A. Financial income and interest/IOF (accounts 6.x) are excluded, as are D&A, capex, taxes and working-capital movements. The ledger contains no D&A entries.
4. Monthly figures are as booked in the ledger; no accrual adjustments or reclasses were made.
5. Burn and runway follow `finance/README.md`. Runway assumes constant burn and no new funding, and uses the 30/06/2026 consolidated balance of R$ 1,847,350.40.
6. Cash balances are taken as given in `finance/README.md`; the ledger is treated as the P&L source, not a complete cash-flow statement.

## What the CFO should ask for

- A explained June cash bridge for the R$ 274.5k gap.
- Commitment to keep operating-cost growth below gross-profit growth; Q2 shows this works.
- Fundraising decision by October 2026 to preserve a six-month buffer.
- A named owner for the May cost slip (sales and G&A) so the June improvement holds.
