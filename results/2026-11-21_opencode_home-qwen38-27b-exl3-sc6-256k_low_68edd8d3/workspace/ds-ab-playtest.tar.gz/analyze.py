import csv, json, math

path = r"telemetry\playtest_ab.csv"
sessions = {}   # session_id -> (variant, completed)
inconsistent = []
dup_rows = 0

with open(path, newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        sid = row["session_id"].strip()
        v = row["variant"].strip().upper()
        c = int(row["completed_tutorial"].strip())
        if sid in sessions:
            dup_rows += 1
            pv, pc = sessions[sid]
            if (pv, pc) != (v, c):
                inconsistent.append((sid, pv, pc, v, c))
        else:
            sessions[sid] = (v, c)

n = {"A": 0, "B": 0}
x = {"A": 0, "B": 0}
for sid, (v, c) in sessions.items():
    n[v] += 1
    x[v] += c

pa, pb = x["A"] / n["A"], x["B"] / n["B"]
p_pool = (x["A"] + x["B"]) / (n["A"] + n["B"])
se = math.sqrt(p_pool * (1 - p_pool) * (1 / n["A"] + 1 / n["B"]))
z = (pb - pa) / se

def phi(t):  # standard normal CDF via erf
    return 0.5 * (1 + math.erf(t / math.sqrt(2)))

p_two = 2 * (1 - phi(abs(z)))
p_one = 1 - phi(z)  # H1: B > A

print(f"raw data rows (excl header): {sum(n.values()) + dup_rows}")
print(f"duplicate rows dropped: {dup_rows}")
print(f"inconsistent duplicates: {len(inconsistent)}")
for t in inconsistent[:20]:
    print("  ", t)
print(f"unique sessions: {sum(n.values())}")
print(f"A: n={n['A']} completed={x['A']} rate={pa:.4f}")
print(f"B: n={n['B']} completed={x['B']} rate={pb:.4f}")
print(f"diff (B-A): {pb-pa:+.4f}")
print(f"pooled p: {p_pool:.4f}  z: {z:.4f}")
print(f"p two-sided: {p_two:.6f}")
print(f"p one-sided (B>A): {p_one:.6f}")

ship_b = p_two < 0.05  # conservative: two-sided at 5%
result = {
    "ship_b": ship_b,
    "sessions_a": n["A"],
    "sessions_b": n["B"],
    "completion_rate_a": round(pa, 4),
    "completion_rate_b": round(pb, 4),
    "p_value": round(p_two, 4),
}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))