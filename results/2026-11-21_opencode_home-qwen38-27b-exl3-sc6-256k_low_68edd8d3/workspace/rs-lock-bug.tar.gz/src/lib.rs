//! Player scores shared between the match threads of the Pixel Arena server.
//!
//! All state lives behind a single mutex. The previous design used one mutex
//! per player plus a separate one for the total, which deadlocked in
//! `transfer` (two slots locked in argument order, so opposite transfers
//! blocked each other; a self-transfer locked the same slot twice) and lost
//! updates in `award` (read-modify-write split across two lock acquisitions).

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    state: Arc<Mutex<State>>,
}

#[derive(Default)]
struct State {
    players: HashMap<PlayerId, i64>,
    total: i64,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        let mut state = self.state.lock().unwrap();
        // Keep `total` equal to the sum of the scores: if the player already
        // has a score, only the difference is added.
        let delta = score - state.players.get(&id).copied().unwrap_or(0);
        state.players.insert(id, score);
        state.total += delta;
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let mut state = self.state.lock().unwrap();
        *state
            .players
            .get_mut(&id)
            .unwrap_or_else(|| panic!("award for unknown player {id}")) += points;
        state.total += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return;
        }
        let mut state = self.state.lock().unwrap();
        *state
            .players
            .get_mut(&from)
            .unwrap_or_else(|| panic!("transfer from unknown player {from}")) -= points;
        *state
            .players
            .get_mut(&to)
            .unwrap_or_else(|| panic!("transfer to unknown player {to}")) += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self
            .state
            .lock()
            .unwrap()
            .players
            .get(&id)
            .unwrap_or_else(|| panic!("score for unknown player {id}"))
    }

    pub fn total(&self) -> i64 {
        self.state.lock().unwrap().total
    }
}