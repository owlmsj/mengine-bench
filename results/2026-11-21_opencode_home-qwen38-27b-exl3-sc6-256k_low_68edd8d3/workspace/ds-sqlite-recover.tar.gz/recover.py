import json, struct

data = open('prices.db', 'rb').read()

def varint(buf, off):
    result = 0
    for i in range(9):
        b = buf[off + i]
        if i == 8:
            result = (result << 8) | b
            return result, off + 9
        result = (result << 7) | (b & 0x7F)
        if not (b & 0x80):
            return result, off + i + 1
    return result, off + 9

def read_serial(buf, off, st):
    if st == 0:
        return None, off
    if st == 1:
        return buf[off], off + 1
    if st == 2:
        return int.from_bytes(buf[off:off+2], 'big', signed=True), off + 2
    if st == 3:
        return int.from_bytes(buf[off:off+3], 'big', signed=True), off + 3
    if st == 4:
        return int.from_bytes(buf[off:off+4], 'big', signed=True), off + 4
    if st == 5:
        return int.from_bytes(buf[off:off+6], 'big', signed=True), off + 6
    if st == 6:
        return int.from_bytes(buf[off:off+8], 'big', signed=True), off + 8
    if st in (7, 8):
        return struct.unpack('>d', buf[off:off+8])[0], off + 8
    if st >= 12 and st % 2 == 0:
        n = (st - 12) // 2
        return buf[off:off+n].decode('utf-8', errors='replace'), off + n
    if st >= 13 and st % 2 == 1:
        n = (st - 13) // 2
        return buf[off:off+n], off + n
    raise ValueError('bad serial type %r at %d' % (st, off))

# page header at offset 0 (no db header present)
ptype = data[0]
ncells = struct.unpack('>H', data[3:5])[0]
print('page type', ptype, 'ncells', ncells)

rows = []
for i in range(ncells):
    off = struct.unpack('>H', data[8 + 2*i: 10 + 2*i])[0]
    payload_len, o = varint(data, off)
    rowid, o = varint(data, o)
    hdr_len, o2 = varint(data, o)
    serials = []
    o3 = o2
    while o3 < o2 + hdr_len:
        st, o3 = varint(data, o3)
        serials.append(st)
    vals = []
    ov = o2 + hdr_len
    for st in serials:
        v, ov = read_serial(data, ov, st)
        vals.append(v)
    rows.append({'rowid': rowid, 'payload_len': payload_len, 'values': vals})
    print(rowid, vals)

# assume schema (item TEXT, price REAL/INT): first col item, second price
out = []
for r in rows:
    v = r['values']
    if len(v) >= 2 and isinstance(v[0], str):
        price = v[1]
        if isinstance(price, float) and price.is_integer():
            price = int(price)
        out.append({'item': v[0], 'price': price})

json.dump(out, open('recovered.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
print('wrote', len(out), 'rows')