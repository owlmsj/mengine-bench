from PIL import Image
import os

os.makedirs("out", exist_ok=True)

im = Image.open("launch.jpg").convert("RGB")
# 4:5 portrait crop from 3000x2000 -> width 1600, full height 2000
# x0=1400 keeps balloon (x 2350-2750) fully inside with best margins
crop = im.crop((1400, 0, 3000, 2000))  # 1600x2000
out = crop.resize((1080, 1350), Image.LANCZOS)
out.save("out/feed-photo.jpg", "JPEG", quality=92)
print("saved out/feed-photo.jpg", out.size, out.mode)