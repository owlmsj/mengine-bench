from PIL import Image
import numpy as np

im = Image.open("launch.jpg").convert("RGB")
a = np.asarray(im, dtype=np.int32)
r, g, b = a[..., 0], a[..., 1], a[..., 2]
# magenta: high R, low G, high B
mask = (r > 120) & (b > 120) & (g < 100) & (r - g > 60) & (b - g > 60)
ys, xs = np.nonzero(mask)
print("magenta px:", len(xs))
print("bbox x:", xs.min(), xs.max(), "y:", ys.min(), ys.max())
H, W = a.shape[:2]
print("image:", W, H)