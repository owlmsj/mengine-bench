$w = 70e9 / 1e9
$kv = 327680 * 32768 * 4 / 1e9
$tot = $w + $kv + 8
"weights=$w kv=$kv total=$tot"
$rows = Import-Csv offers.csv
$ok = $rows | Where-Object {
  $_.in_stock -eq 'yes' -and
  ($_.region -in 'us-east','us-central','eu-west') -and
  [double]$_.usd_per_hour -le 4 -and
  ([double]$_.gpu_count * [double]$_.vram_gb_per_gpu) -ge $tot
}
$ok | ForEach-Object {
  "ELIGIBLE $($_.offer_id) mem=$([double]$_.gpu_count*[double]$_.vram_gb_per_gpu) h=$($_.usd_per_hour)"
}
$best = ($ok | Sort-Object { [double]$_.usd_per_hour })[0]
"BEST $($best.offer_id) h=$($best.usd_per_hour) m=$([double]$best.usd_per_hour*730)"