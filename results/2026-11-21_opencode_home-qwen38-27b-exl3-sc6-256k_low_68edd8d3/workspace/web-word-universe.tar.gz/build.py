# Parse ./site (saved Portuguese creative dictionary) into a word graph.
import os, re, json, math, random
from urllib.parse import unquote

SITE = 'site'
files = [f for f in os.listdir(SITE) if f.endswith('.html')]

word_pages = {}   # filename -> dict(word, tema, links {sec: [target filenames]})
redirects = {}    # filename -> target filename
for f in files:
    html = open(os.path.join(SITE, f), encoding='utf-8').read()
    m = re.search(r'<meta http-equiv="refresh" content="0; url=([^"]+)"', html)
    if m:
        redirects[f] = m.group(1)
        continue
    h1 = re.search(r'<main><h1>(.*?)</h1>', html)
    if not h1:
        continue  # index / sobre / contato
    tema = re.search(r'class="tema">Tema:\s*(.*?)</p>', html)
    links = {}
    for sec in ('sinonimos', 'analogas'):
        sm = re.search(r'<section id="%s">.*?<ul>(.*?)</ul>' % sec, html, re.S)
        if sm:
            links[sec] = re.findall(r'<a href="([^"]+)">', sm.group(1))
    word_pages[f] = {'word': h1.group(1), 'tema': tema.group(1).strip() if tema else '',
                     'links': links}

def resolve(f):
    seen = set()
    while f in redirects and f not in seen:
        seen.add(f)
        f = redirects[f]
    return f

name_of = {f: v['word'] for f, v in word_pages.items()}
graph, tema_of, secmap = {}, {}, {}
dangling = set()
for f, v in word_pages.items():
    per = {'sinonimos': set(), 'analogas': set()}
    for sec, ts in v['links'].items():
        for t in ts:
            tr = resolve(unquote(t))
            if tr in name_of:
                per[sec].add(name_of[tr])
            else:
                dangling.add(t)
    graph[v['word']] = sorted(per['sinonimos'] | per['analogas'])
    secmap[v['word']] = {'sinonimos': sorted(per['sinonimos']), 'analogas': sorted(per['analogas'])}
    tema_of[v['word']] = v['tema']

words = sorted(graph)
pairs = set()
for a, ts in graph.items():
    for b in ts:
        pairs.add(tuple(sorted((a, b))))
pairs = sorted(pairs)
deg = {w: len(set(graph[w]) | {a for a, ts in graph.items() if w in ts}) for w in words}
most = sorted(words, key=lambda w: (-deg[w], w))[0]

json.dump(graph, open('words.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
json.dump({'words': len(words), 'relations': len(pairs), 'most_connected': most},
          open('result.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

# ---- 3D layout: tema clusters on a sphere + force relaxation ----
random.seed(42)
temas = sorted({t for t in tema_of.values() if t})
def fib(i, n, R):
    phi = math.acos(1 - 2 * (i + 0.5) / n)
    th = math.pi * (1 + 5 ** 0.5) * i
    return [R * math.sin(phi) * math.cos(th), R * math.cos(phi), R * math.sin(phi) * math.sin(th)]
centers = {t: fib(i, max(len(temas), 1), 55) for i, t in enumerate(temas)}
pos = {}
for w in words:
    c = centers.get(tema_of[w], [0, 0, 0])
    u, v = random.uniform(-1, 1), random.uniform(-1, 1)
    n = math.hypot(u, v) or 1
    r = random.uniform(4, 12)
    pos[w] = [c[0] + u / n * r, c[1] + random.uniform(-8, 8), c[2] + v / n * r]
idx = {w: i for i, w in enumerate(words)}
P = [[p[0], p[1], p[2]] for p in (pos[w] for w in words)]
E = [(idx[a], idx[b]) for a, b in pairs]
for it in range(120):
    for i in range(len(words)):
        for j in range(i + 1, len(words)):
            dx, dy, dz = P[i][0]-P[j][0], P[i][1]-P[j][1], P[i][2]-P[j][2]
            d2 = dx*dx + dy*dy + dz*dz + 0.01
            f = min(220.0 / d2, 1.2)
            d = math.sqrt(d2)
            P[i][0] += dx/d*f; P[i][1] += dy/d*f; P[i][2] += dz/d*f
            P[j][0] -= dx/d*f; P[j][1] -= dy/d*f; P[j][2] -= dz/d*f
    for i, j in E:
        dx, dy, dz = P[i][0]-P[j][0], P[i][1]-P[j][1], P[i][2]-P[j][2]
        d = math.hypot(dx, dy, dz) or 0.01
        f = (d - 13) * 0.03
        P[i][0] -= dx/d*f; P[i][1] -= dy/d*f; P[i][2] -= dz/d*f
        P[j][0] += dx/d*f; P[j][1] += dy/d*f; P[j][2] += dz/d*f

palette = ['#7dd3fc','#f9a8d4','#fcd34d','#86efac','#c4b5fd','#fdba74',
           '#67e8f9','#f0abfc','#bef264','#fca5a5','#93c5fd','#fde68a',
           '#a5f3fc','#d8b4fe','#86efac']
tema_color = {t: palette[i % len(palette)] for i, t in enumerate(temas)}
node_color = {w: tema_color.get(tema_of[w], '#e2e8f0') for w in words}

data = {
    'words': words,
    'links': graph,
    'sec': secmap,
    'tema': tema_of,
    'color': node_color,
    'pos': [round(c, 2) for p in P for c in p],
    'pairs': pairs,
    'deg': deg,
    'most': most,
    'stats': {'words': len(words), 'relations': len(pairs), 'most_connected': most},
}
tpl = open('template.html', encoding='utf-8').read()
out = tpl.replace('__DATA__', json.dumps(data, ensure_ascii=False))
os.makedirs('universe', exist_ok=True)
open('universe/index.html', 'w', encoding='utf-8').write(out)
print('words:', len(words), 'relations:', len(pairs), 'most:', most, deg[most])
print('dangling:', sorted(dangling))
print('temas:', {t: sum(1 for w in words if tema_of[w] == t) for t in temas})
print('redirects:', redirects)