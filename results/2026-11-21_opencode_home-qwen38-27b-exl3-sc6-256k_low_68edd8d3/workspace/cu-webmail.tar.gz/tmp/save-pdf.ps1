$b64 = 'JVBERi0xLjQKJeLjz9MKMSAwIG9iago8PCAvVHlwZSAvQ2F0YWxvZyAvUGFnZXMgMiAwIFIgPj4KZW5kb2JqCjIgMCBvYmoKPDwgL1R5cGUgL1BhZ2VzIC9LaWRzIFszIDAgUl0gL0NvdW50IDEgPj4KZW5kb2JqCjMgMCBvYmoKPDwgL1R5cGUgL1BhZ2UgL1BhcmVudCAyIDAgUiAvTWVkaWFCb3ggWzAgMCA1OTUgODQyXSAvUmVzb3VyY2VzIDw8IC9Gb250IDw8IC9GMSA0IDAgUiAvRjIgNSAwIFIgPj4gPj4gL0NvbnRlbnRzIDYgMCBSID4+CmVuZG9iago0IDAgb2JqCjw8IC9UeXBlIC9Gb250IC9TdWJ0eXBlIC9UeXBlMSAvQmFzZUZvbnQgL0hlbHZldGljYSAvRW5jb2RpbmcgL1dpbkFuc2lFbmNvZGluZyA+PgplbmRvYmoKNSAwIG9iago8PCAvVHlwZSAvRm9udCAvU3VidHlwZSAvVHlwZTEgL0Jhc2VGb250IC9IZWx2ZXRpY2EtQm9sZCAvRW5jb2RpbmcgL1dpbkFuc2lFbmNvZGluZyA+PgplbmRvYmoKNiAwIG9iago8PCAvTGVuZ3RoIDMxNSAvRmlsdGVyIC9GbGF0ZURlY29kZSA+PgpzdHJlYW0KeNp9kctOwzAQRff5itkggdSE8TQPp7sWWgmpiwoM+7Q2YEjiyk2K+vfkiYpUd2nNPWfGugvh3a8IGAfx7kUxJBxBSO92ndnvw762sLG6rODBBODDU3k0eqdgvfEJKfYxZPwOxJe3FN6iFTFgbBSFvWhkZFapGXQYQ5/cHFHHLXSeQ2VmILRUPw1s4aWqpTZOEMMO3GSnQjUnN0RxmMEUm9Wng4uKedxRznnSz+cRbK3ZfdZWTYAmiAg7s9fqsjgk/COXr8/AGQWIzh0R75Irk0tdfkBWSqisLorm4dYPUKtnYRxEbv3QxKPK9VHZk1s5BFvllF87eOjIOWf9/KXeVqbKcvfGIdhuTNNrn4jSvt23uQBiN07jmGuNhGlAyb8onRmHfkR7IchaXQx2zrMm2YQwCpLR+gtfzsP/CmVuZHN0cmVhbQplbmRvYmoKeHJlZgowIDcKMDAwMDAwMDAwMCA2NTUzNSBmIAowMDAwMDAwMDE1IDAwMDAwIG4gCjAwMDAwMDAwNjQgMDAwMDAgbiAKMDAwMDAwMDEyMSAwMDAwMCBuIAowMDAwMDAwMjU3IDAwMDAwIG4gCjAwMDAwMDAzNTQgMDAwMDAgbiAKMDAwMDAwMDQ1NiAwMDAwMCBuIAp0cmFpbGVyCjw8IC9TaXplIDcgL1Jvb3QgMSAwIFIgPj4Kc3RhcnR4cmVmCjg0MwolJUVPRgo='
$bytes = [Convert]::FromBase64String($b64)
$out = Join-Path $PSScriptRoot '..' 'LP-2026-0418.pdf'
[System.IO.File]::WriteAllBytes($out, $bytes)
Write-Host "saved: $out ($($bytes.Length) bytes)"
# Inflate the FlateDecode content stream to read the text
$text = [System.Text.Encoding]::ASCII.GetString($bytes)
$start = $text.IndexOf('stream') + 6
if ($text[$start] -eq "`r") { $start++ }
if ($text[$start] -eq "`n") { $start++ }
$end = $text.IndexOf('endstream', $start)
$raw = [System.Text.Encoding]::ASCII.GetString($bytes, $start, $end - $start)
$zlib = [Convert]::FromBase64String([Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($raw)))
# raw bytes of the stream
$streamBytes = $bytes[$start..($end-1)]
# skip 2-byte zlib header
$deflate = New-Object System.IO.MemoryStream(, $streamBytes[2..($streamBytes.Length-1)])
$ds = New-Object System.IO.Compression.DeflateStream($deflate, [System.IO.Compression.CompressionMode]::Decompress)
$ms = New-Object System.IO.MemoryStream
$ds.CopyTo($ms)
$ds.Close()
Write-Host '--- PDF content stream text ---'
Write-Host ([System.Text.Encoding]::ASCII.GetString($ms.ToArray()))