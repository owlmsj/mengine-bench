$ErrorActionPreference = 'Stop'
$base = '<WORKSPACE>\finance'

# chart of accounts: account -> pnl_line
$coa = @{}
Get-Content (Join-Path $base 'chart_of_accounts.csv') | Select-Object -Skip 1 | ForEach-Object {
  $p = $_ -split ';'
  $coa[$p[0]] = $p[2]
}

# parse amount: Brazilian format 1.234.567,89 -> 1234567.89
function Parse-Amount([string]$s) {
  $s = $s.Trim()
  $neg = $s.StartsWith('-')
  $s = $s.TrimStart('-')
  $s = $s.Replace('.', '').Replace(',', '.')
  $v = [double]$s
  if ($neg) { $v = -$v }
  return $v
}

$months = @('2026-01','2026-02','2026-03','2026-04','2026-05','2026-06')
$lines = @('revenue','cogs','sales_marketing','rnd','ga','financial')
$data = @{}
foreach ($m in $months) {
  $data[$m] = @{}
  foreach ($l in $lines) { $data[$m][$l] = 0.0 }
}

Get-Content (Join-Path $base 'ledger.csv') | Select-Object -Skip 1 | ForEach-Object {
  $p = $_ -split ';'
  $d = $p[0]
  $acc = $p[1]
  $amt = Parse-Amount $p[3]
  $dt = [datetime]::ParseExact($d, 'dd/MM/yyyy', $null)
  $m = $dt.ToString('yyyy-MM')
  $line = $coa[$acc]
  if ($data.ContainsKey($m) -and $data[$m].ContainsKey($line)) {
    $data[$m][$line] += $amt
  }
}

$rev = @{}; $gm = @{}; $ebitda = @{}
foreach ($m in $months) {
  $r = $data[$m]['revenue']
  $c = $data[$m]['cogs']
  $sm = $data[$m]['sales_marketing']
  $rnd = $data[$m]['rnd']
  $ga = $data[$m]['ga']
  $rev[$m] = [math]::Round($r, 2)
  $gm[$m] = [math]::Round(($r + $c) / $r * 100, 2)  # c is signed (negative)
  $ebitda[$m] = [math]::Round($r + $c + $sm + $rnd + $ga, 2)  # financials excluded
}

# burn: average monthly negative EBITDA of last three closed months (Apr, May, Jun)
$last3 = @('2026-04','2026-05','2026-06')
$avg = ($last3 | ForEach-Object { $ebitda[$_] }) | Measure-Object -Average
$burn = [math]::Round([math]::Abs($avg.Average), 2)
$cash = 1847350.40
$runway = [math]::Round($cash / $burn, 2)

$result = [ordered]@{
  revenue = [ordered]@{}
  gross_margin_pct = [ordered]@{}
  ebitda = [ordered]@{}
  burn = $burn
  runway_months = $runway
}
foreach ($m in $months) {
  $result.revenue[$m] = $rev[$m]
  $result.gross_margin_pct[$m] = $gm[$m]
  $result.ebitda[$m] = $ebitda[$m]
}
$result | ConvertTo-Json | Set-Content '<WORKSPACE>\result.json'

# print detail for verification
foreach ($m in $months) {
  Write-Output ("{0}: rev={1} cogs={2} sm={3} rnd={4} ga={5} fin={6} ebitda={7} gm={8}" -f $m, $rev[$m], [math]::Round($data[$m]['cogs'],2), [math]::Round($data[$m]['sales_marketing'],2), [math]::Round($data[$m]['rnd'],2), [math]::Round($data[$m]['ga'],2), [math]::Round($data[$m]['financial'],2), $ebitda[$m], $gm[$m])
}
Write-Output ("burn={0} cash={1} runway={2}" -f $burn, $cash, $runway)