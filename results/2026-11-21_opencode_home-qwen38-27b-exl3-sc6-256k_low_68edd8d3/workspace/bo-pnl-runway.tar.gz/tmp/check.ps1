$l = Import-Csv -Path '<WORKSPACE>\finance\ledger.csv' -Delimiter ';'
Write-Output ('entries=' + $l.Count)
$l | Group-Object { ([datetime]::ParseExact($_.date,'dd/MM/yyyy',$null)).ToString('yyyy-MM') } | ForEach-Object {
  $rev = ($_.Group | Where-Object { $_.account -like '3.*' } | ForEach-Object { [double]($_.amount.Replace('.','').Replace(',','.')) } | Measure-Object -Sum).Sum
  $cogs = ($_.Group | Where-Object { $_.account -like '4.*' } | ForEach-Object { [double]($_.amount.Replace('.','').Replace(',','.')) } | Measure-Object -Sum).Sum
  $opex = ($_.Group | Where-Object { $_.account -like '5.*' } | ForEach-Object { [double]($_.amount.Replace('.','').Replace(',','.')) } | Measure-Object -Sum).Sum
  Write-Output ($_.Name + ' rev=' + [math]::Round($rev,2) + ' cogs=' + [math]::Round($cogs,2) + ' opex=' + [math]::Round($opex,2) + ' ebitda=' + [math]::Round($rev+$cogs+$opex,2) + ' gm=' + [math]::Round(($rev+$cogs)/$rev*100,2))
}