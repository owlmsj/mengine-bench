import sqlite3, json
from collections import defaultdict

c = sqlite3.connect('analytics.db')
users = {uid: (plat, test) for uid, plat, test in c.execute('select user_id, platform, is_test from users')}

ev = defaultdict(list)
for uid, name, ts in c.execute('select user_id, name, ts from events'):
    if uid in users and not users[uid][1]:  # exclude unknown players and test accounts
        ev[uid].append((ts, name))

STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']
funnel = defaultdict(lambda: {s: 0 for s in STEPS})

for uid, events in ev.items():
    plat = users[uid][0]
    prev = None
    for s in STEPS:
        # first valid occurrence at or after previous step's time
        valid = [ts for ts, n in events if n == s and (prev is None or ts >= prev)]
        if valid:
            prev = min(valid)
            funnel[plat][s] += 1

result = {
    'funnel': {plat: funnel[plat] for plat in sorted(funnel)},
    'biggest_drop': {},
}
for plat in sorted(funnel):
    f = funnel[plat]
    conv = {}
    for i, s in enumerate(STEPS[1:], 1):
        if f[STEPS[i-1]] > 0:
            conv[s] = f[s] / f[STEPS[i-1]]
    # biggest drop = step with lowest conversion
    worst = min(conv, key=conv.get)
    result['biggest_drop'][plat] = worst
    print(plat, f, {k: round(v, 3) for k, v in conv.items()}, '->', worst)

with open('result.json', 'w', encoding='utf-8') as fh:
    json.dump(result, fh, indent=2, ensure_ascii=False)
print('written')