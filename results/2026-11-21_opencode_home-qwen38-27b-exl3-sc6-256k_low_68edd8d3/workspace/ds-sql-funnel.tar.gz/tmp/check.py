import sqlite3
c = sqlite3.connect('analytics.db')
print('event names:', c.execute('select distinct name from events').fetchall())
print('install per platform (non-test):',
      c.execute("select u.platform, count(distinct u.user_id) from users u "
                "join events e on e.user_id=u.user_id "
                "where u.is_test=0 and e.name='install' group by u.platform").fetchall())
print('events from unknown players:',
      c.execute("select count(*) from events e where not exists "
                "(select 1 from users u where u.user_id=e.user_id)").fetchone())