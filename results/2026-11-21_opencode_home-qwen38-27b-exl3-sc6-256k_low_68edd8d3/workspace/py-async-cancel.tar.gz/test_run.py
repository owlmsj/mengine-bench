import asyncio

from run import run_tasks


async def main():
    # 1) concurrency cap + results in order
    active = 0
    peak = 0

    def make(i):
        async def job():
            nonlocal active, peak
            active += 1
            peak = max(peak, active)
            await asyncio.sleep(0.05)
            active -= 1
            return i

        return job

    results = await run_tasks([make(i) for i in range(10)], 3)
    assert results == list(range(10)), results
    assert peak <= 3, peak
    print("cap ok, peak =", peak)

    # 2) cancellation: in-flight jobs' cleanup still runs
    cleaned = []

    async def slow():
        try:
            await asyncio.sleep(10)
        finally:
            cleaned.append(1)

    t = asyncio.create_task(run_tasks([lambda: slow() for _ in range(4)], 2))
    await asyncio.sleep(0.1)
    t.cancel()
    try:
        await t
    except asyncio.CancelledError:
        pass
    assert cleaned == [1, 1], cleaned
    print("cleanup ok:", cleaned)

    # 3) empty task list
    assert await run_tasks([], 5) == []
    print("empty ok")


asyncio.run(main())
print("ALL OK")