"""Bounded-concurrency runner for awaitable jobs."""

import asyncio


async def run_tasks(tasks, max_concurrent):
    """Run each task's job with at most ``max_concurrent`` running at once.

    Each element of ``tasks`` is a zero-argument callable that returns an
    awaitable job. Returns the list of job results in input order.

    If this coroutine is cancelled (e.g. Ctrl+C under ``asyncio.run``),
    every in-flight job is cancelled and awaited, so each job's cleanup
    code (``finally`` blocks) runs before the cancellation propagates.

    Assumptions: ``max_concurrent >= 1``; if a job raises, the first
    exception propagates (standard ``asyncio.gather`` behavior).
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent!r}")
    sem = asyncio.Semaphore(max_concurrent)

    async def run_one(task):
        async with sem:
            return await task()

    return await asyncio.gather(*(run_one(t) for t in tasks))