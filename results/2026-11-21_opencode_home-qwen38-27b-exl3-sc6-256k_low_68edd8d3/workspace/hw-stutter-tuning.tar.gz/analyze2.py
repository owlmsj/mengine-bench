import csv
rows=[]
with open('capture/presentmon.csv') as f:
    for r in csv.DictReader(f):
        rows.append(r)
# frame times in 43-45.5s window (Defender)
print("Defender window t=43.0-45.5s frame times >10ms:")
for r in rows:
    t=float(r['TimeInSeconds']); ms=float(r['MsBetweenPresents'])
    if 43.0<=t<=45.5 and ms>10:
        print(f"  t={t:.3f} ms={ms:.2f}")
# count hitches by whether their second is an L1 second
l1_seconds={2,6,10,14,18,22,26,30,34,38,42,46,50,54,58}
med=6.962
in_l1=0; not_l1=0
for r in rows:
    ms=float(r['MsBetweenPresents'])
    if ms>3*med:
        sec=int(float(r['TimeInSeconds']))
        if sec in l1_seconds or (sec+1) in l1_seconds: in_l1+=1
        else: not_l1+=1
print(f"hitch frames in/near L1 second: {in_l1}, other: {not_l1}")
# list the 'other' hitch frames
print("hitch frames NOT near an L1 second:")
for r in rows:
    ms=float(r['MsBetweenPresents'])
    if ms>3*med:
        sec=int(float(r['TimeInSeconds']))
        if not (sec in l1_seconds or (sec+1) in l1_seconds):
            print(f"  t={float(r['TimeInSeconds']):.3f} ms={ms:.2f}")