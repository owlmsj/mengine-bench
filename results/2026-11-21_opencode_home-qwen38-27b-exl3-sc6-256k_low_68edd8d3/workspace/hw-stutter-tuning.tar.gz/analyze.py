import csv, statistics, json

rows = []
with open('capture/presentmon.csv') as f:
    for r in csv.DictReader(f):
        rows.append(r)

mbp = [float(r['MsBetweenPresents']) for r in rows]
# first row MsBetweenPresents is time since start; use all for mean per owner's formula (1000/mean)
avg_fps = 1000.0 / (sum(mbp) / len(mbp))
mbp_sorted = sorted(mbp)
def pct(p):
    idx = int(round((len(mbp_sorted)-1) * p/100.0))
    return mbp_sorted[idx]
p99 = pct(99)
low1 = 1000.0 / p99
print(f"frames={len(mbp)} avg_fps={avg_fps:.3f} p99_ms={p99:.3f} low1={low1:.3f}")
print(f"mean_ms={sum(mbp)/len(mbp):.3f} max_ms={max(mbp):.3f}")

# find hitch frames: frame time > 3x median
med = statistics.median(mbp)
hitches = [(i, rows[i]['TimeInSeconds'], mbp[i]) for i in range(len(mbp)) if mbp[i] > 3*med]
print(f"median_ms={med:.3f} hitches(>3x med)={len(hitches)}")
for i, t, ms in hitches[:40]:
    print(f"  frame {i} t={float(t):.3f}s ms={ms:.2f}")

# sensor log
sens = []
with open('capture/sensors.csv') as f:
    for r in csv.DictReader(f):
        sens.append(r)
print("\nsensors:")
for s in sens:
    flag = ''
    if s['gpu_pcie_link_state'] != 'L0': flag += ' LINK='+s['gpu_pcie_link_state']
    if int(s['dpc_latency_us']) > 200: flag += ' DPC='+s['dpc_latency_us']
    if int(s['disk_active_pct']) > 50: flag += ' DISK='+s['disk_active_pct']
    if int(s['cpu_clock_mhz']) < 5000: flag += ' CPUCLOCK='+s['cpu_clock_mhz']
    if s['top_cpu_process'] != 'Arena.exe': flag += ' TOP='+s['top_cpu_process']
    print(f"  t={s['time_s']}s cpu={s['cpu_clock_mhz']} util={s['cpu_util_pct']} gpu={s['gpu_clock_mhz']} link={s['gpu_pcie_link_state']} {s['gpu_pcie_link_speed']} dpc={s['dpc_latency_us']} disk={s['disk_active_pct']} top={s['top_cpu_process']}{flag}")