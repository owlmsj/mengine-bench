# HANDOFF — local-9b Q5 @ 128k

Goal: measure local-9b Q5 at 128k context.

Done:
- Baseline: `scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024` → 37.8 t/s, VRAM 7881 MiB.
- 7881 MiB is the WDDM ceiling: Shared Usage counter showed 1494 MiB spilled to system RAM — that VRAM number does not count.
- Fix: `--no-mmproj-offload` + `-ub 512` → spill gone, final VRAM 7697 MiB, decode 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k — discarded. Q4_K_M (7305 MiB, 40.4 t/s) kept only as fallback.
- Recipe applied in `scripts/start_server.ps1:165` (local9 block) and `profiles/local/local-9b.json`.

Left to do:
1. Review the names of the scratchpad temp files (never done).
2. Evals README still cites `check_vision.ps1`, which no longer exists — update it.

Assumptions: "local model" = local-9b Q5; measure script + profile are the source of truth.

Evidence: numbers are measured runs from the transcript; recipe at the cited file:line.