import csv, json, re

base = r"<WORKSPACE>\backoffice"

invoices = {}
with open(f"{base}/invoices.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = float(row["amount"])

payments = {}  # id -> list of amounts
ignored = []
with open(f"{base}/bank_statement_june.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        m = re.search(r"(10\d{2})", memo)
        if m:
            inv_id = f"INV-{m.group(1)}"
            if inv_id in invoices:
                payments.setdefault(inv_id, []).append(float(row["amount"]))
                continue
        ignored.append(memo)

unpaid = sorted(set(invoices) - set(payments))
duplicated = sorted(i for i, a in payments.items() if len(a) > 1)
mismatched = []
for i, a in sorted(payments.items()):
    if len(a) == 1 and abs(a[0] - invoices[i]) > 0.005:
        mismatched.append({"id": i, "invoiced": invoices[i], "paid": a[0]})

result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
print(json.dumps(result, indent=2))
print("ignored entries:", ignored)
print("paid invoice count:", len(payments), "total invoices:", len(invoices))