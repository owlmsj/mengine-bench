import pypdf, sys
for name in ["laudo_alfa", "resultado_beta"]:
    r = pypdf.PdfReader(f"exams/{name}.pdf")
    print(f"===== {name} ({len(r.pages)} pages) =====")
    for i, p in enumerate(r.pages):
        print(f"--- page {i+1} ---")
        print(p.extract_text())