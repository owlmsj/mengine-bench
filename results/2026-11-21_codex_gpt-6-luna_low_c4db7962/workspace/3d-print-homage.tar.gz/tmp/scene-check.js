

const scene=new THREE.Scene();scene.background=new THREE.Color('#eadbb8');
const camera=new THREE.OrthographicCamera(-8,8,5,-5,.1,100);camera.position.set(0,0,25);camera.lookAt(0,0,0);
const renderer=new THREE.WebGLRenderer({antialias:true,alpha:false});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setSize(innerWidth,innerHeight);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.setClearColor('#eadbb8');document.body.appendChild(renderer.domElement);
scene.add(new THREE.AmbientLight(0xffffff,1.8));const sun=new THREE.DirectionalLight(0xfff4db,1.3);sun.position.set(-5,8,12);scene.add(sun);
const mat=(c)=>new THREE.MeshStandardMaterial({color:c,roughness:1,flatShading:true,side:THREE.DoubleSide});
const paper=mat('#eadbb8'), blue=mat('#17486d'), blue2=mat('#286c91'), aqua=mat('#80b8b5'), foam=mat('#f7f0d7'), ink=mat('#173b59'), shadow=mat('#193955'), wood=mat('#c68b59'), pale=mat('#e1b78a'), mountain=mat('#f5ecd2');
function poly(points,z,m,group=scene){const g=new THREE.BufferGeometry();let v=[];for(const p of points)v.push(p[0],p[1],z);g.setAttribute('position',new THREE.Float32BufferAttribute(v,3));let ix=[];for(let i=1;i<points.length-1;i++)ix.push(0,i,i+1);g.setIndex(ix);g.computeVertexNormals();let o=new THREE.Mesh(g,m);group.add(o);return o}
function line(points,z,color='#173b59',w=.025){let c=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(p[0],p[1],z)));let o=new THREE.Mesh(new THREE.TubeGeometry(c,Math.max(12,points.length*4),w,4,false),mat(color));scene.add(o);return o}
function ellipse(x,y,rx,ry,z,m,rot=0){let o=new THREE.Mesh(new THREE.CircleGeometry(1,7),m);o.position.set(x,y,z);o.scale.set(rx,ry,1);o.rotation.z=rot;scene.add(o);return o}
// Handmade parchment speckling, built from small geometry rather than a reference image.
for(let i=0;i<190;i++){let x=(Math.random()-.5)*15.5,y=(Math.random()-.5)*9.5;ellipse(x,y,-.006,.012,.02,i%4?mat('#d8c89e'):mat('#f5e9c9'))}
// Quiet horizon and distant haze.
poly([[-8,-1.38],[8,-1.38],[8,-5],[-8,-5]],-.5,mat('#ded4b8'));
poly([[-8,-1.1],[-5,-1.18],[-2,-1.24],[1,-1.20],[4,-1.3],[8,-1.22],[8,-1.55],[-8,-1.55]],-.4,mat('#c9c7b5'));
// Fuji, just right of center, behind the boats.
poly([[1.0,-2.48],[2.10,-.95],[3.18,-2.45]],1,mountain);
poly([[1.75,-1.45],[2.1,-.95],[2.48,-1.48],[2.32,-1.37],[2.18,-1.52],[2.04,-1.39]],1.1,foam);
poly([[1.0,-2.48],[2.1,-.95],[1.91,-1.65],[1.67,-1.95],[1.55,-2.26]],1.05,mat('#294d6b'));
line([[1.0,-2.48],[2.1,-.95],[3.18,-2.45]],1.2,'#173b59',.018);
// Great wave: broad curled body and shaded inner face.
const wave=[[-8,.32],[-6.4,.64],[-5.1,1.05],[-4.0,2.18],[-2.8,3.30],[-1.45,3.82],[-.45,3.50],[.08,2.86],[.72,2.45],[1.55,2.12],[2.40,1.56],[2.90,.66],[2.72,-.08],[2.05,-.53],[1.12,-.61],[.18,-.15],[-.68,.60],[-1.54,.94],[-2.4,.56],[-3.25,-.12],[-4.05,-.9],[-5,-1.0],[-6,-.6],[-7,-.18],[-8,-.05]];
const wg=new THREE.Group();scene.add(wg);poly(wave,2.2,blue,wg);
poly([[-8,.16],[-6.2,.45],[-5.1,.84],[-4.0,1.83],[-2.85,2.80],[-1.55,3.24],[-.58,3.0],[-.10,2.42],[.35,1.82],[.62,.9],[.75,.15],[.38,-.2],[-.3,.35],[-1.2,.81],[-2.0,.42],[-3.1,-.34],[-4.25,-1.06],[-5.2,-.92],[-6.1,-.45],[-7,-.05],[-8,.02]],2.4,blue2,wg);
poly([[-8,.1],[-6.4,.36],[-5.5,.7],[-4.4,1.55],[-3.7,1.7],[-3.15,1.25],[-3.6,.86],[-4.35,.44],[-5.1,.12],[-6,-.12],[-7,-.18],[-8,-.13]],2.6,blue,wg);
poly([[-3.95,1.91],[-3.3,2.62],[-2.4,3.25],[-1.4,3.5],[-.7,3.22],[-.14,2.67],[.32,2.12],[-.12,2.34],[-.55,2.82],[-1.18,3.02],[-1.85,2.75],[-2.55,2.1],[-3.2,1.63]],2.7,foam,wg);
// Curling crest curls and claw-like foam fingers.
const curls=[[-3.8,2.06],[-3.7,2.48],[-3.35,2.56],[-3.21,2.33],[-3.34,2.23],[-3.49,2.37],[-3.44,2.52],[-3.15,2.66],[-2.92,2.54],[-2.9,2.35],[-3.03,2.3],[-3.1,2.43],[-2.83,2.75],[-2.48,2.88],[-2.29,2.71],[-2.35,2.53],[-2.5,2.54],[-2.55,2.67],[-2.33,2.98],[-1.99,3.1],[-1.8,2.95],[-1.83,2.78],[-1.98,2.78],[-2.03,2.91],[-1.77,3.22],[-1.4,3.3],[-1.24,3.14],[-1.3,2.98],[-1.45,3.0],[-1.5,3.11],[-1.24,3.4],[-.88,3.35],[-.75,3.17],[-.83,3.06],[-.96,3.13],[-.92,3.26],[-.59,3.08],[-.35,2.83],[-.4,2.65],[-.55,2.64],[-.6,2.77],[-.31,2.88],[-.01,2.67],[.14,2.47],[.07,2.31],[-.08,2.34],[-.12,2.46],[.18,2.52],[.47,2.28],[.59,2.05],[.5,1.9],[.35,1.95],[.34,2.07],[.62,2.11],[.88,1.88],[.93,1.69],[.79,1.59],[.68,1.68],[.73,1.8],[.96,1.79],[1.21,1.53],[1.21,1.34],[1.08,1.27],[.97,1.37],[1.04,1.49],[1.27,1.45],[1.51,1.16],[1.48,.98],[1.33,.94],[1.25,1.05],[1.31,1.16],[1.54,1.08],[1.77,.79],[1.72,.62],[1.57,.59],[1.51,.7],[1.58,.82],[1.81,.7],[2.03,.4],[1.96,.23],[1.81,.23],[1.77,.35],[1.85,.45],[2.05,.33],[2.24,.05],[2.18,-.1],[2.03,-.08],[2,-.01],[2.1,.07]];
for(let i=0;i<curls.length;i+=6){let s=curls.slice(i,i+6);if(s.length>=3)poly(s,2.85,foam,wg)}
line(curls.slice(0,20),2.95,'#173b59',.018);line(curls.slice(20,40),2.95,'#173b59',.018);line(curls.slice(40),2.95,'#173b59',.018);
// Foam scallops and spray, deliberately sparse enough to keep the silhouette legible.
for(let i=0;i<68;i++){let t=i/67,x=-3.45+t*5.35,y=2.45-t*2.48+Math.sin(t*13)*.11;let r=.07+(i%5)*.014;ellipse(x,y, r*1.2,r,3, i%3===0?blue:foam,(i%2)*.4)}
for(let i=0;i<95;i++){let x=-.25+Math.random()*4.5,y=-.1+Math.random()*1.7;let s=.018+Math.random()*.035;ellipse(x,y,s,s*1.35,2.9,i%3?foam:aqua)}
// Blue striations in the main barrel.
for(let i=0;i<9;i++){let x=-3.1+i*.36;line([[x,2.15],[x+.13,1.55],[x+.12,.75],[x+.36,-.02],[x+.8,-.48]],2.72,i%3?'#367a9a':'#0d3b63',.025)}
// Foreground wave folds, sweeping from the right toward the bottom.
poly([[-3.2,-5],[-2.9,-2.48],[-2.4,-1.25],[-1.7,-.73],[-1.12,-1.08],[-.45,-2.02],[.35,-2.8],[1.55,-3.35],[3.05,-3.43],[4.55,-2.85],[6.15,-1.85],[8,-.72],[8,-5]],3.2,blue2);
poly([[-2.95,-5],[-2.7,-2.52],[-2.15,-1.42],[-1.65,-1.1],[-1.22,-1.37],[-.58,-2.28],[.2,-3.07],[1.48,-3.65],[3,-3.72],[4.5,-3.15],[6,-2.15],[8,-1.02],[8,-2.0],[6,-3.06],[4.3,-3.7],[2.8,-4.05],[1.2,-3.95],[0,-3.43],[-.9,-2.7],[-1.65,-2.03],[-2.05,-2.03],[-2.4,-2.76],[-2.55,-5]],3.4,foam);
poly([[3,-4.0],[4.4,-3.76],[5.9,-3.1],[8,-2.06],[8,-2.75],[6.1,-3.7],[4.6,-4.1]],3.5,blue);
for(let i=0;i<11;i++){let x=-1.1+i*.78;line([[x,-2.4],[x+.48,-2.9],[x+1.1,-3.23],[x+1.85,-3.3]],3.55,i%3?'#1d557c':'#568ca0',.025)}
// Breaking lower-left spray.
for(let i=0;i<34;i++){let x=-6.8+Math.random()*2.1,y=-2.5-Math.random()*2.2,r=.08+Math.random()*.16;ellipse(x,y,r*1.2,r,3.7,i%4?foam:aqua)}
// Three long, narrow fishing boats; each hull is a shallow faceted skiff.
function boat(cx,cy,scale,angle){let g=new THREE.Group();g.position.set(cx,cy,4.5);g.rotation.z=angle;g.scale.setScalar(scale);scene.add(g);
function local(points,z,m){return poly(points,z,m,g)}
local([[-1.35,.10],[-.95,-.14],[.82,-.14],[1.27,.06],[.84,-.30],[-.8,-.28]],0,wood);
local([[-1.35,.10],[-.95,-.14],[.82,-.14],[1.27,.06],[.83,.18],[-.75,.18]],.03,ink);
local([[-.82,.02],[-.52,.11],[.63,.11],[.83,.03],[.55,-.12],[-.65,-.12]],.06,pale);
for(let i=0;i<6;i++)local([[-.65+i*.22,-.11],[-.61+i*.22,.1],[-.57+i*.22,.1],[-.61+i*.22,-.11]],.08,blue);
for(let i=0;i<7;i++){let px=-.62+i*.19;let o=ellipse(px,.19,.085,.13,.1,blue);o.position.z=.1;g.add(o)}
line([[-1.2,.12],[1.15,.12]],.12,'#173b59',.018);return g}
const boats=[boat(-4.25,-1.65,.87,.48),boat(.15,-3.0,1.08,.17),boat(5.9,-.88,.84,.7)];
// Fine white cut lines and foam chips on the wave face.
for(let i=0;i<60;i++){let x=-5.7+Math.random()*4.2,y=-.45+Math.random()*1.2,s=.018+Math.random()*.03;ellipse(x,y, s*1.5,s,3.0,i%4?foam:aqua)}
// Slow, small bob and breathing motion; no camera movement for wallpaper calm.
const time0=performance.now();function animate(now){requestAnimationFrame(animate);let t=(now-time0)*.001;boats.forEach((b,i)=>{b.position.y=b.userData.baseY+Math.sin(t*1.15+i*1.8)*.035;b.rotation.z=b.userData.baseR+Math.sin(t*.7+i)*.008});wg.position.y=Math.sin(t*.35)*.025;renderer.render(scene,camera)}boats.forEach(b=>{b.userData.baseY=b.position.y;b.userData.baseR=b.rotation.z});requestAnimationFrame(animate);
function resize(){let w=innerWidth,h=innerHeight,aspect=w/h;camera.left=-5*aspect;camera.right=5*aspect;camera.top=5;camera.bottom=-5;camera.updateProjectionMatrix();renderer.setSize(w,h)}addEventListener('resize',resize);resize();

