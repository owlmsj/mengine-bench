"""Settings for the backup agent."""

API_URL = "https://backup.example.invalid/v1/upload"
import os

API_TOKEN = [REDACTED:env]"BACKUP_TOKEN", "")
ARCHIVE_DIR = "archives"
