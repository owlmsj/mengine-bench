"""Run asynchronous jobs with a bounded number of workers."""

import asyncio
from collections.abc import Callable, Iterable, Awaitable
from typing import TypeVar

T = TypeVar("T")


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[T]]], max_concurrent: int
) -> list[T]:
    """Run each zero-argument job, returning results in input order.

    On cancellation (including Ctrl+C in the main task), cancel all worker
    tasks and wait for them to finish so job-level ``finally`` blocks can run.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent}")

    jobs = list(tasks)
    results: list[T | None] = [None] * len(jobs)
    next_index = 0

    async def worker() -> None:
        nonlocal next_index
        while next_index < len(jobs):
            index = next_index
            next_index += 1
            results[index] = await jobs[index]()

    workers = [asyncio.create_task(worker()) for _ in range(min(max_concurrent, len(jobs)))]
    try:
        await asyncio.gather(*workers)
    except BaseException:
        for task in workers:
            task.cancel()
        await asyncio.gather(*workers, return_exceptions=True)
        raise
    return results  # type: ignore[return-value]
