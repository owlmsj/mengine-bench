# Handoff

Goal: configure local-9b Q5 for 128k context and report a valid decode benchmark. Transcript says baseline 37.8 t/s / 7881 MiB was misleading: 7881 MiB is the WDDM ceiling and 1494 MiB spilled to shared memory. With `--no-mmproj-offload` and `-ub 512`, median of 3: 38.0 t/s, final VRAM 7697 MiB, spill gone. Q6_K (7.03 GiB) did not fit; Q4_K_M is fallback (7305 MiB, 40.4 t/s).

Transcript says recipe was applied at `scripts/start_server.ps1:165` (local9) and `profiles/local/local-9b.json`; verify those changes in the actual checkout. Remaining known task: update evals README, which references removed `check_vision.ps1`. User asked “What is left?”; transcript gives no further completion evidence. Assumption: trust recorded measurements, but verify setup and README before calling work done.

This handoff is based on `session/transcript.md`; this workspace has no project files or Git metadata, so edits and benchmark could not be independently checked here.
