//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    // One lock keeps player scores and their aggregate consistent, and avoids
    // lock-order deadlocks when a transfer touches two players.
    state: Arc<Mutex<State>>,
}

#[derive(Default)]
struct State {
    players: HashMap<PlayerId, i64>,
    total: i64,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        let mut state = self.state.lock().unwrap();
        if let Some(previous) = state.players.insert(id, score) {
            state.total -= previous;
        }
        state.total += score;
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let mut state = self.state.lock().unwrap();
        *state.players.get_mut(&id).expect("player must join before scoring") += points;
        state.total += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let mut state = self.state.lock().unwrap();
        if from == to {
            return;
        }
        *state.players.get_mut(&from).expect("source player must join before transfer") -= points;
        *state.players.get_mut(&to).expect("target player must join before transfer") += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.state.lock().unwrap().players.get(&id).expect("player must join before reading score")
    }

    pub fn total(&self) -> i64 {
        self.state.lock().unwrap().total
    }
}
