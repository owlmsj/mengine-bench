import sqlite3, json
from collections import defaultdict

c = sqlite3.connect('analytics.db')
users = {uid: (plat, is_test) for uid, plat, is_test in c.execute("SELECT user_id, platform, is_test FROM users")}
STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']

# first valid occurrence per player per step, respecting ordering:
# a step counts only at or after the player's previous step time (no time limit).
# So we process events in time order; a step's time = first occurrence with ts >= previous step's ts.
# Collect all events per user, sorted by ts.
ev = defaultdict(list)
for uid, name, ts in c.execute("SELECT user_id, name, ts FROM events"):
    if uid not in users or users[uid][1]:  # unknown player or test account
        continue
    ev[uid].append((ts, name))

funnel = defaultdict(lambda: defaultdict(int))  # platform -> step -> count
for uid, lst in ev.items():
    plat = users[uid][0]
    lst.sort()
    prev_ts = None
    reached = {}
    for ts, name in lst:
        if name not in STEPS:
            continue
        if name in reached:
            continue
        if prev_ts is not None and ts < prev_ts:
            continue  # occurs before previous step: not valid
        reached[name] = ts
        prev_ts = ts
    for s in reached:
        funnel[plat][s] += 1

result = {'funnel': {}, 'biggest_drop': {}}
for plat in sorted(funnel):
    counts = {s: funnel[plat][s] for s in STEPS}
    result['funnel'][plat] = counts
    # conversion per step = players at step / players at previous step
    conv = {}
    for i, s in enumerate(STEPS):
        if i == 0:
            conv[s] = 1.0  # install is the entry step
        else:
            prev = STEPS[i-1]
            conv[s] = counts[s] / counts[prev] if counts[prev] else 0.0
    # biggest drop = step with lowest conversion (exclude install entry)
    drop = min(STEPS[1:], key=lambda s: conv[s])
    result['biggest_drop'][plat] = drop

print(json.dumps(result, indent=2))
with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2)