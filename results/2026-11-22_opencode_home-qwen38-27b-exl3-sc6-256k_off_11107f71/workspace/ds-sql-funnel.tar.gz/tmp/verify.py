import sqlite3
c = sqlite3.connect('analytics.db')
users = {uid: (plat, is_test) for uid, plat, is_test in c.execute("SELECT user_id, platform, is_test FROM users")}
# check: any non-test user with events out of step order (e.g. first_match before install)?
from collections import defaultdict
ev = defaultdict(list)
for uid, name, ts in c.execute("SELECT user_id, name, ts FROM events"):
    if uid in users and not users[uid][1]:
        ev[uid].append((ts, name))
STEPS = ['install','tutorial_complete','first_match','purchase']
out_of_order = 0
for uid, lst in ev.items():
    lst.sort()
    prev_ts = None
    seen = {}
    for ts, name in lst:
        if name in STEPS and name not in seen:
            if prev_ts is not None and ts < prev_ts:
                out_of_order += 1
            else:
                seen[name] = ts
                prev_ts = ts
print('users with out-of-order step events:', out_of_order)
# sanity: total installs vs total users per platform
for plat in ['pc','steamdeck']:
    tot = sum(1 for u,(p,t) in users.items() if p==plat and not t)
    print(plat, 'non-test users:', tot)
# unknown-player events count
unk = c.execute("SELECT COUNT(*) FROM events WHERE user_id NOT IN (SELECT user_id FROM users)").fetchone()[0]
print('events from unknown players:', unk)
# test-account events
te = c.execute("SELECT COUNT(*) FROM events e JOIN users u ON e.user_id=u.user_id WHERE u.is_test=1").fetchone()[0]
print('events from test accounts:', te)
print('total events:', c.execute("SELECT COUNT(*) FROM events").fetchone()[0])