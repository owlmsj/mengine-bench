$ErrorActionPreference = 'Stop'
$text = 'Welcome aboard the evening ferry, please keep your bags clear of the doors.'
$mp3 = '<WORKSPACE>\tmp\announcement.mp3'
$wav = '<WORKSPACE>\announcement.wav'
edge-tts --text $text --voice en-US-AriaNeural --write-media $mp3
if (-not (Test-Path $mp3)) { throw 'edge-tts produced no mp3' }
ffmpeg -y -i $mp3 -ar 24000 -ac 1 $wav 2>&1 | Out-Null
if (-not (Test-Path $wav)) { throw 'ffmpeg produced no wav' }
$len = (ffprobe -v error -show_entries format=duration -of csv=p=0 $wav)
Write-Output "wav duration: $len"
Write-Output "wav size: $((Get-Item $wav).Length) bytes"