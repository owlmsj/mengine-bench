$cmds = @('edge-tts','ffmpeg','python','py','espeak-ng','say','flite','pico2wave')
foreach ($c in $cmds) {
  $cmd = Get-Command $c -ErrorAction SilentlyContinue
  if ($cmd) { Write-Output "$c => $($cmd.Source)" }
}
$edge = @(
  'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
  'C:\Program Files\Microsoft\Edge\Application\msedge.exe'
)
foreach ($e in $edge) {
  if (Test-Path $e) { Write-Output "edge => $e" }
}
$py = Get-Command python -ErrorAction SilentlyContinue
if ($py) {
  & python -c "import sys; print('python', sys.version.split()[0])"
  & python -c "import pyttsx3" 2>$null; if ($?) { Write-Output 'pyttsx3 yes' } else { Write-Output 'pyttsx3 no' }
  & python -c "import edge_tts" 2>$null; if ($?) { Write-Output 'edge_tts yes' } else { Write-Output 'edge_tts no' }
}