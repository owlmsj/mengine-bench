Add-Type -AssemblyName System.Speech
$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
# pick a decent voice if available
$voices = $synth.GetInstalledVoices() | ForEach-Object { $_.VoiceInfo }
Write-Output ("voices: " + (($voices | ForEach-Object { $_.Name }) -join '; '))
$wav = '<WORKSPACE>\announcement.wav'
$text = 'Welcome aboard the evening ferry, please keep your bags clear of the doors.'
$synth.SetOutputToWaveFile($wav)
# natural rate ~0, slight pause after comma handled by punctuation
$synth.Speak($text)
$synth.Dispose()
if (-not (Test-Path $wav)) { throw 'no wav' }
$len = (ffprobe -v error -show_entries format=duration -of csv=p=0 $wav)
Write-Output "wav duration: $len"
Write-Output "wav size: $((Get-Item $wav).Length) bytes"