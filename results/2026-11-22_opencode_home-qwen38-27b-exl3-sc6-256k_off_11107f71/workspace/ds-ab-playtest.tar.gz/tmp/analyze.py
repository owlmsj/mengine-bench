import csv, math, json
from collections import defaultdict

path = r"<WORKSPACE>\telemetry\playtest_ab.csv"

sessions = {}  # session_id -> (variant, completed)
dupes = 0
bad_variant = 0
with open(path, newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        sid = row["session_id"].strip()
        v = row["variant"].strip().lower()
        comp = int(row["completed_tutorial"])
        if v not in ("a", "b"):
            bad_variant += 1
            continue
        if sid in sessions:
            dupes += 1
            # sanity: re-sent rows should be identical
            if sessions[sid] != (v, comp):
                print("CONFLICT on", sid, sessions[sid], (v, comp))
            continue
        sessions[sid] = (v, comp)

n = {k: 0 for k in "ab"}
c = {k: 0 for k in "ab"}
for sid, (v, comp) in sessions.items():
    n[v] += 1
    c[v] += comp

print("rows total:", sum(n.values()), "dupes removed:", dupes, "bad variants:", bad_variant)
print("A: n=%d completed=%d rate=%.6f" % (n["a"], c["a"], c["a"]/n["a"]))
print("B: n=%d completed=%d rate=%.6f" % (n["b"], c["b"], c["b"]/n["b"]))

# two-proportion z-test, pooled, one-sided (B > A) and two-sided
p = (c["a"] + c["b"]) / (n["a"] + n["b"])
se = math.sqrt(p * (1 - p) * (1/n["a"] + 1/n["b"]))
z = ((c["b"]/n["b"]) - (c["a"]/n["a"])) / se
# normal CDF via erf
def norm_cdf(x): return 0.5 * (1 + math.erf(x / math.sqrt(2)))
p_two = 2 * (1 - norm_cdf(abs(z)))
p_one = 1 - norm_cdf(z)
print("pooled p=%.6f se=%.6f z=%.6f" % (p, se, z))
print("p two-sided=%.6f  p one-sided (B>A)=%.6f" % (p_two, p_one))

# chi-square with Yates continuity correction, for comparison
N = n["a"] + n["b"]
exp_a = N * c["a"] / (c["a"]+c["b"])  # not needed; do 2x2 properly
# 2x2: A comp c[a], A fail n[a]-c[a]; B comp c[b], B fail n[b]-c[b]
a_, b_ = c["a"], n["a"] - c["a"]
d_, e_ = c["b"], n["b"] - c["b"]
R1, R2 = a_ + b_, d_ + e_
C1, C2 = a_ + d_, b_ + e_
exp = [[R1*C1/N, R1*C2/N], [R2*C1/N, R2*C2/N]]
obs = [[a_, b_], [d_, e_]]
chi2 = sum((obs[i][j]-exp[i][j])**2/exp[i][j] for i in range(2) for j in range(2))
# Yates
chi2y = sum((abs(obs[i][j]-exp[i][j])-0.5)**2/exp[i][j] for i in range(2) for j in range(2))
# chi2 df=1: p = 2*(1 - CDF); for df=1, CDF(x) = 2*norm_cdf(sqrt(x)) - 1
p_chi2 = 2 * (1 - norm_cdf(math.sqrt(chi2)))
p_chi2y = 2 * (1 - norm_cdf(math.sqrt(chi2y)))
print("chi2=%.6f p=%.6f | chi2 yates=%.6f p=%.6f" % (chi2, p_chi2, chi2y, p_chi2y))

# Fisher exact (two-sided) via hypergeometric
from math import comb
def fisher_two_sided(a_, b_, d_, e_):
    r1, r2 = a_+b_, d_+e_
    c1, c2 = a_+d_, b_+e_
    N = r1+r2
    def pmf(x):
        if x < max(0, r1-c2) or x > min(r1, c1): return 0.0
        return math.lgamma(x+1)+math.lgamma(r1-x+1)+math.lgamma(c1-x+1)+math.lgamma(c2-c1+x+1) - math.lgamma(N+1)
    lo, hi = max(0, r1-c2), min(r1, c1)
    total = sum(math.exp(pmf(x)) for x in range(lo, hi+1))
    p_obs = math.exp(pmf(a_))
    p2 = sum(math.exp(pmf(x)) for x in range(lo, hi+1) if math.exp(pmf(x)) <= p_obs + 1e-300)
    return p2 / total

p_fisher = fisher_two_sided(a_, b_, d_, e_)
print("fisher exact two-sided p=%.6f" % p_fisher)

result = {
    "ship_b": bool(p_two < 0.05),
    "sessions_a": n["a"],
    "sessions_b": n["b"],
    "completion_rate_a": round(c["a"]/n["a"], 6),
    "completion_rate_b": round(c["b"]/n["b"], 6),
    "p_value": round(p_two, 6),
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))