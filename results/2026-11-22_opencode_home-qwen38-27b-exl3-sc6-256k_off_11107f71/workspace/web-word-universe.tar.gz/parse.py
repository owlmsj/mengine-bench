import re, json, os, html, urllib.parse

SITE = "site"

# cache file -> canonical h1 word
h1_cache = {}
def file_word(f):
    if f in h1_cache:
        return h1_cache[f]
    p = os.path.join(SITE, f)
    if not os.path.exists(p):
        h1_cache[f] = None
        return None
    with open(p, encoding="utf-8") as fh:
        txt = fh.read()
    m = re.search(r"<h1>(.*?)</h1>", txt)
    w = html.unescape(m.group(1)).strip() if m else None
    h1_cache[f] = w
    return w

words = {}  # canonical -> {theme, syn:[], ana:[]}
files = [f for f in os.listdir(SITE) if f.endswith(".html")]
for f in files:
    with open(os.path.join(SITE, f), encoding="utf-8") as fh:
        txt = fh.read()
    m = re.search(r"<h1>(.*?)</h1>", txt)
    if not m:
        continue
    title = html.unescape(m.group(1)).strip()
    tm = re.search(r'class="tema">Tema:\s*(.*?)</p>', txt)
    theme = html.unescape(tm.group(1)).strip() if tm else None
    syn, ana = [], []
    for sec in re.finditer(r'<section id="([^"]+)">(.*?)</section>', txt, re.S):
        sid = sec.group(1)
        for a in re.finditer(r'<a href="([^"]+)">(.*?)</a>', sec.group(2)):
            href = urllib.parse.unquote(os.path.basename(a.group(1)))
            target = file_word(href)
            if target is None:
                target = html.unescape(a.group(2)).strip()
            (syn if "sinonim" in sid else ana).append(target)
    words[title.lower()] = {"display": title, "theme": theme, "syn": syn, "ana": ana}

# dedupe preserving order
def dedupe(lst):
    seen=set(); out=[]
    for x in lst:
        k=x.lower()
        if k not in seen:
            seen.add(k); out.append(x)
    return out

existing = set(words.keys())
out = {}
for k,d in words.items():
    syn = [x for x in dedupe(d["syn"]) if x.lower() in existing]
    ana = [x for x in dedupe(d["ana"]) if x.lower() in existing]
    out[k] = {"display": d["display"], "theme": d["theme"], "syn": syn, "ana": ana}

# distinct undirected pairs over all links
pairs = set()
for k,d in out.items():
    for l in d["syn"]+d["ana"]:
        a,b = sorted((k, l.lower()))
        pairs.add((a,b))
pairs = sorted(pairs)

deg = {k: len(d["syn"])+len(d["ana"]) for k,d in out.items()}
# most connected: max degree, tie-break alphabetical ascending
most = sorted(deg.items(), key=lambda x:(-x[1], x[0]))[0][0]

result = {"words": len(out), "relations": len(pairs), "most_connected": most}

with open("words.json","w",encoding="utf-8") as fh:
    json.dump(out, fh, ensure_ascii=False, indent=1)
with open("result.json","w",encoding="utf-8") as fh:
    json.dump(result, fh, ensure_ascii=False, indent=1)

print("words:", len(out), "relations:", len(pairs), "most:", most, deg[most])
print("top:", sorted(deg.items(), key=lambda x:(-x[1],x[0]))[:8])