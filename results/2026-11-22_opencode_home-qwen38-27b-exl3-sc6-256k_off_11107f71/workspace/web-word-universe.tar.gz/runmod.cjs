// Run the extracted module with minimal DOM stubs to surface runtime errors.
const fs = require('fs');
const src = fs.readFileSync('tmp_module.mjs', 'utf-8');

function makeCanvas() {
  return {
    width: 300, height: 150,
    getContext: () => ({
      measureText: (t) => ({ width: t.length * 10 }),
      font: '', fillStyle: '', textBaseline: '',
      fillText: () => {},
    }),
    addEventListener: () => {},
  };
}
const elements = {
  scene: makeCanvas(),
  stats: { innerHTML: '', textContent: '' },
  panel: { classList: { add(){}, remove(){} } },
  'p-word': { textContent: '' },
  'p-theme': { textContent: '' },
  'p-syn': { innerHTML: '' },
  'p-ana': { innerHTML: '' },
  'p-count': { textContent: '' },
  q: { value: '', addEventListener(){}, },
  sug: { style: {}, innerHTML: '' },
  fallback: { style: {} },
  fb: { textContent: '' },
};
global.document = {
  getElementById: (id) => elements[id] || { style:{}, classList:{add(){},remove(){}}, addEventListener(){}, innerHTML:'', textContent:'' },
  createElement: (t) => makeCanvas(),
};
global.window = global;
global.addEventListener = () => {};
global.innerWidth = 1280; global.innerHeight = 800;
global.devicePixelRatio = 1;
global.location = { search: '?word=saudade', pathname: '/index.html' };
global.history = { replaceState(){} };
global.URLSearchParams = URLSearchParams;
global.requestAnimationFrame = () => {};

// Stub THREE import by intercepting dynamic import
const origImport = globalThis.import;
globalThis.import = async (spec) => {
  if (spec.includes('three')) {
    // minimal three stub
    class Color { setHSL(){return this} }
    class BufferAttribute { constructor(a,s){this.array=a;this.needsUpdate=false} }
    class BufferGeometry { setAttribute(){} }
    class ShaderMaterial { constructor(){} }
    class Points { constructor(){} }
    class LineBasicMaterial { constructor(){} }
    class LineSegments { constructor(){} }
    class CanvasTexture { constructor(){} }
    class SpriteMaterial { constructor(){} }
    class Sprite { constructor(){this.position={set(){}};this.scale={set(){}}} }
    class Scene { add(){} }
    class Group { add(){} }
    class PerspectiveCamera { constructor(){this.position={set(){z:0}};this.aspect=1;this.updateProjectionMatrix(){}} }
    class WebGLRenderer { constructor(){this.domElement={width:300,height:150};} setPixelRatio(){} setSize(){} render(){} }
    class Raycaster { constructor(){this.params={Points:{}};this.setFromCamera(){}this.intersectObject(){return []}} }
    class Vector2 { constructor(){} }
    return {
      Color, BufferAttribute, BufferGeometry, ShaderMaterial, Points,
      LineBasicMaterial, LineSegments, CanvasTexture, SpriteMaterial, Sprite,
      Scene, Group, PerspectiveCamera, WebGLRenderer, Raycaster, Vector2,
      LinearFilter: 0, FogExp2: class { constructor(){} },
    };
  }
  return origImport(spec);
};

try {
  // eval as module
  const mod = new Function('import', src.replace(/^import .*$/m, ''));
  // simpler: just eval the body after stripping the import line, but we need THREE
  // Instead, transform: replace import with a const from our stub
  const transformed = src.replace(
    /import \* as THREE from ".*?";/,
    'const THREE = await (async()=>{ const m = await import("https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js"); return m; })();'
  );
  const fn = new AsyncFunction(transformed);
  fn().then(() => console.log('MODULE RAN OK')).catch(e => console.log('MODULE ERROR:', e.message, '\n', (e.stack||'').split('\n').slice(0,4).join('\n')));
} catch(e) {
  console.log('WRAP ERROR:', e.message);
}