import re, json
html = open('universe/index.html', encoding='utf-8').read()
# extract DATA and PAIRS lines
mD = re.search(r'const DATA = (\{.*?\});\n', html)
mP = re.search(r'const PAIRS = (\[.*?\]);\n', html)
data = json.loads(mD.group(1))
pairs = json.loads(mP.group(1))
keys = set(data.keys())
bad = set()
for a,b in pairs:
    if a not in keys: bad.add(a)
    if b not in keys: bad.add(b)
print("DATA keys:", len(keys))
print("PAIRS:", len(pairs))
print("words in PAIRS not in DATA:", sorted(bad))
# also check reverse: data links referencing missing
missing_links = set()
for w,d in data.items():
    for l in d.get('syn',[])+d.get('ana',[]):
        if l.lower() not in keys: missing_links.add(l)
print("links in DATA not in DATA keys:", sorted(missing_links))