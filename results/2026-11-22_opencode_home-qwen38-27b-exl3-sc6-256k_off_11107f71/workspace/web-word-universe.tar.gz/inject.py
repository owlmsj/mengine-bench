import json, re

with open("words.json", encoding="utf-8") as f:
    data = json.load(f)
with open("result.json", encoding="utf-8") as f:
    result = json.load(f)

pairs = set()
for w, d in data.items():
    for l in (d.get("syn", []) + d.get("ana", [])):
        a, b = sorted((w, l.lower()))
        if a in data and b in data:
            pairs.add((a, b))
pairs = sorted(pairs)

with open("universe/index.html", encoding="utf-8") as f:
    lines = f.readlines()

data_json = json.dumps(data, ensure_ascii=False)
pairs_json = json.dumps(pairs, ensure_ascii=False)
most_json = json.dumps(result["most_connected"], ensure_ascii=False)

out = []
for ln in lines:
    if ln.startswith("const DATA = "):
        out.append("const DATA = " + data_json + ";\n")
    elif ln.startswith("const PAIRS = "):
        out.append("const PAIRS = " + pairs_json + ";\n")
    elif ln.startswith("const MOST = "):
        out.append("const MOST = " + most_json + ";\n")
    else:
        out.append(ln)

with open("universe/index.html", "w", encoding="utf-8") as f:
    f.writelines(out)

print("rewrote. pairs:", len(pairs), "words:", len(data), "most:", result["most_connected"])