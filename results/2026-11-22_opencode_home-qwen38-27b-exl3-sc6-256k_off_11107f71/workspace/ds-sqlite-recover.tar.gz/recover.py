import struct, json

data = open('prices.db','rb').read()
print('file len', len(data))

# Page header (page 1) starts at offset 0. First 16 bytes are the SQLite
# magic, which is corrupted/missing here. The rest of the page-1 header is:
#   offset 16: file change counter (4)
#   offset 20: db size in pages (4)
#   offset 24: first freelist trunk (4)
#   offset 28: freelist count (4)
#   offset 32: schema cookie (4)
#   offset 36: schema format (4)
#   offset 40: default page cache (4)
#   offset 44: largest root b-tree page (auto-vacuum) (4)
#   offset 48: text encoding (4)
#   offset 52: user version (4)
#   offset 56: incremental vacuum (4)
#   offset 60: application id (4)
#   offset 64: reserved for expansion (4)
#   offset 68: page type (1)  -- but for page 1 the b-tree header is at offset 100
# Actually for page 1, the b-tree page header starts at offset 100.
#   offset 100: page type (1): 0x0D = leaf table
#   offset 101: first freeblock (2)
#   offset 103: number of cells (2)
#   offset 105: cell content start (2)
#   offset 107: fragmented free bytes (1)
#   offset 108: right-most pointer (4) -- only for interior pages
#   offset 112: cell pointer array (2 bytes each)

# From the hex dump:
# 0000: 0D 00 00 00 0A 0F 3D 00 0F F1 0F E3 0F CB 0F BD
# Wait, that's only 16 bytes shown at offset 0. Let me re-read.
# Actually the hex dump shows:
# 0000  0D 00 00 00 0A 0F 3D 00 0F F1 0F E3 0F CB 0F BD
# 0010  0F AD 0F 93 0F 7F 0F 6D 0F 58 0F 3D 00 00 00 00
# So offset 0 = 0x0D (page type: leaf table b-tree)
# offset 1 = 0x00 (first freeblock high)
# offset 2 = 0x00 (first freeblock low)
# offset 3 = 0x00 (num cells high)
# offset 4 = 0x0A (num cells low) = 10 cells
# offset 5 = 0x0F (cell content start high)
# offset 6 = 0x3D (cell content start low) = 0x0F3D
# offset 7 = 0x00 (fragmented free bytes)
# offset 8..11: cell pointer 0 = 0x00000FF1? No wait.
# For a leaf page, there's no right-most pointer. So:
# offset 8: cell pointer 0 high
# offset 9: cell pointer 0 low
# ...

# Let me re-interpret:
# offset 0: 0x0D = page type (leaf table)
# offset 1-2: first freeblock = 0x0000
# offset 3-4: num cells = 0x000A = 10
# offset 5-6: cell content start = 0x0F3D
# offset 7: fragmented free bytes = 0x00
# offset 8-9: cell pointer 0
# offset 10-11: cell pointer 1
# ...

# From hex:
# offset 8: 0x0F, offset 9: 0xF1 -> cell 0 at 0x0FF1
# offset 10: 0x0F, offset 11: 0xE3 -> cell 1 at 0x0FE3
# offset 12: 0x0F, offset 13: 0xCB -> cell 2 at 0x0FCB
# offset 14: 0x0F, offset 15: 0xBD -> cell 3 at 0x0FBD
# offset 16: 0x0F, offset 17: 0xAD -> cell 4 at 0x0FAD
# offset 18: 0x0F, offset 19: 0x93 -> cell 5 at 0x0F93
# offset 20: 0x0F, offset 21: 0x7F -> cell 6 at 0x0F7F
# offset 22: 0x0F, offset 23: 0x6D -> cell 7 at 0x0F6D
# offset 24: 0x0F, offset 25: 0x58 -> cell 8 at 0x0F58
# offset 26: 0x0F, offset 27: 0x3D -> cell 9 at 0x0F3D

# So the cell pointers are at offsets 8..27 (10 pointers, 2 bytes each).
# This means the b-tree header starts at offset 0, not offset 100.
# That's unusual for page 1... unless the file was truncated and the
# first 100 bytes (the SQLite header) were cut off, leaving only the
# b-tree page header at what was originally offset 100.

# Actually wait. If the file was truncated from the FRONT (first 100 bytes
# removed), then what was originally at offset 100 is now at offset 0.
# The b-tree page header for a leaf table page is:
#   offset 0: page type (1)
#   offset 1-2: first freeblock (2)
#   offset 3-4: num cells (2)
#   offset 5-6: cell content start (2)
#   offset 7: fragmented free bytes (1)
#   offset 8: cell pointer array starts

# This matches perfectly! The file is the last 4096 bytes of a larger file,
# or the first 100 bytes were cut. Either way, we have a valid b-tree
# leaf page starting at offset 0.

num_cells = struct.unpack('>H', data[3:5])[0]
print('num cells', num_cells)

cell_pointers = []
for i in range(num_cells):
    off = 8 + i*2
    ptr = struct.unpack('>H', data[off:off+2])[0]
    cell_pointers.append(ptr)
print('cell pointers', [hex(p) for p in cell_pointers])

def varint(buf, pos):
    """Read a SQLite varint."""
    result = 0
    for i in range(9):
        byte = buf[pos+i]
        if i == 8:
            result = (result << 8) | byte
            return result, pos+9
        result = (result << 7) | (byte & 0x7F)
        if not (byte & 0x80):
            return result, pos+i+1
    return result, pos+9

def serial_type_size(st):
    if st == 0: return 0
    if st == 1: return 1
    if st == 2: return 2
    if st == 3: return 3
    if st == 4: return 4
    if st == 5: return 6
    if st == 6: return 8
    if st == 7: return 8
    if st >= 12 and st % 2 == 0: return (st-12)//2
    if st >= 13: return (st-13)//2
    return 0

def read_value(st, data, pos):
    size = serial_type_size(st)
    raw = data[pos:pos+size]
    if st == 0: return None
    if st == 1: return struct.unpack('>b', raw)[0]
    if st == 2: return struct.unpack('>h', raw)[0]
    if st == 3: return int.from_bytes(raw, 'big', signed=True)
    if st == 4: return struct.unpack('>i', raw)[0]
    if st == 5: return struct.unpack('>q', raw)[0]
    if st == 6: return struct.unpack('>Q', raw)[0]
    if st == 7: return struct.unpack('>d', raw)[0]
    if st >= 12 and st % 2 == 0:
        return raw.decode('utf-8', errors='replace')
    if st >= 13:
        return raw
    return None

rows = []
for cp in cell_pointers:
    # Each cell: payload size (varint), rowid (varint), then payload
    payload_size, pos = varint(data, cp)
    rowid, pos = varint(data, pos)
    # header size (varint) at start of payload
    header_size, hpos = varint(data, pos)
    # serial types
    stypes = []
    sp = hpos
    while sp < pos + header_size:
        st, sp = varint(data, sp)
        stypes.append(st)
    # data starts at pos + header_size
    dp = pos + header_size
    values = []
    for st in stypes:
        val = read_value(st, data, dp)
        values.append(val)
        dp += serial_type_size(st)
    rows.append({'rowid': rowid, 'values': values})
    print(f'cell at {hex(cp)}: rowid={rowid}, values={values}')

# The table has columns (item TEXT, price REAL) based on the data
# Let's figure out which is which from the values
print()
print('Parsed rows:')
for r in rows:
    print(r)