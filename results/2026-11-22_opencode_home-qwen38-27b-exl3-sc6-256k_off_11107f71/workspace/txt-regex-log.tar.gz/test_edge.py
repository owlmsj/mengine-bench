import re

pattern = open("regex.txt", encoding="utf-8").read().strip()

cases = [
    # (line, expected_date_or_None)
    ("2026-04-02 INFO 10.12.0.7 build 2026-04-01", "2026-04-01"),
    ("2026-04-02 INFO no address here 2026-04-03", None),
    ("x2026-04-02 INFO 10.12.0.7 build 2026-04-01", "2026-04-01"),  # date with letter before -> that date invalid, but 2026-04-01 still last valid
    ("2026-04-02 INFO 10.12.0.7 build 2026-04-01x", None),  # last date has letter after -> invalid; no other valid date
    ("2026-04-02 INFO 10.12.0.7 build 2026-02-29", "2026-2026-02-29".replace("2026-","")),  # 2026 not leap -> Feb 29 invalid
    ("2024-04-02 INFO 10.12.0.7 build 2024-02-29", "2024-02-29"),  # 2024 leap -> Feb 29 valid
    ("2026-04-02 INFO 256.12.0.7 build 2026-04-01", None),  # 256 invalid octet
    ("2026-04-02 INFO 10.12.0.07 build 2026-04-01", None),  # leading zero
    ("2026-04-02 INFO 10.12.0.7 2026-04-01 2026-04-05", "2026-04-05"),  # two dates, last wins
    ("2026-04-02 INFO 10.12.0.7 2026-13-01", None),  # month 13 invalid
    ("2026-04-02 INFO 10.12.0.7 2026-04-32", None),  # day 32 invalid
    ("2026-04-02 INFO 10.12.0.7 2026-06-31", None),  # June 31 invalid
    ("2026-04-02 INFO 10.12.0.7 2026-04-30", "2026-04-30"),  # April 30 valid
    ("2026-04-02 INFO 10.12.0.7 2026-02-30", None),  # Feb 30 invalid
    ("2026-04-02 INFO 1.2.3.4 2026-04-01", "2026-04-01"),  # short IP
    ("2026-04-02 INFO 1.2.3 2026-04-01", None),  # not an IP
    ("2026-04-02 INFO 10.12.0.7.1 2026-04-01", None),  # 5 parts, not valid IP
    ("2026-04-02 INFO 10.12.0.7 2026-04-01 2026-04-02", "2026-04-02"),  # last date
    ("2026-04-02 INFO 999.12.0.7 2026-04-01", None),  # 999 invalid
    ("2026-04-02 INFO 10.12.0.7 2026-04-011", None),  # digit after date
    ("2026-04-02 INFO 10.12.0.7 2026-04-01 2026-04-02", "2026-04-02"),
    ("2026-04-02 INFO 10.12.0.7 2026-02-28", "2026-02-28"),
    ("2026-04-02 INFO 10.12.0.7 2026-02-29", None),  # 2026 not leap
    ("2026-04-02 INFO 10.12.0.7 2026-04-01", "2026-04-01"),
]

ok = True
for line, expected in cases:
    actual = re.findall(pattern, line, re.MULTILINE)
    actual = actual[0] if actual else None
    status = "OK" if actual == expected else "FAIL"
    if actual != expected:
        ok = False
    print(f"{status}  line={line!r:60}  expected={expected!r:12}  actual={actual!r}")

print("\nALL PASS" if ok else "\nSOME FAILED")