import re

pattern = open("regex.txt", encoding="utf-8").read().strip()
log = open("server.log", encoding="utf-8").read()

# Expected: for each line containing a valid IPv4, the last valid date on that line
lines = log.splitlines()
ip_re = re.compile(r'(?<![0-9A-Za-z])(?:(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])(?![0-9A-Za-z])')
date_re = re.compile(r'(?<![0-9A-Za-z])(?:(?:19|20)\d{2})-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\d|30)|(?:02)-(?:0[1-9]|1\d|2[0-9]))(?![0-9A-Za-z])')

expected = []
for line in lines:
    if ip_re.search(line):
        dates = date_re.findall(line)
        if dates:
            expected.append(dates[-1])

actual = re.findall(pattern, log, re.MULTILINE)
print("expected:", expected)
print("actual:  ", actual)
print("MATCH" if expected == actual else "MISMATCH")