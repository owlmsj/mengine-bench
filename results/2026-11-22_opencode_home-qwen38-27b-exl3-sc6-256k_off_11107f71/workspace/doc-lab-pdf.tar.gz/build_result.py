import json

# First report: Alfa, 10/02/2026 (mg/dL, %)
# Second report: Beta, 18/08/2026 (mmol/L, mmol/mol) -> convert to Alfa units

# Conversions
# Glucose: mmol/L * 18.016 mg/dL
# LDL: mmol/L * 38.67 mg/dL
# Creatinine: umol/L / 88.42 mg/dL
# HbA1c: mmol/mol -> % via IFCC: % = 1.5928 * mmol/mol - 2.593

glucose_2 = 6.1 * 18.016
ldl_2 = 3.70 * 38.67
creatinine_2 = 76 / 88.42
hba1c_2 = 0.09 * 37 + 2.15

history = {
    "Glicose em jejum": {"10/02/2026": 92, "18/08/2026": round(glucose_2, 1)},
    "Colesterol LDL": {"10/02/2026": 118, "18/08/2026": round(ldl_2, 1)},
    "Creatinina": {"10/02/2026": 0.95, "18/08/2026": round(creatinine_2, 2)},
    "Hemoglobina glicada (HbA1c)": {"10/02/2026": 5.4, "18/08/2026": round(hba1c_2, 1)},
}

# First report reference ranges (Alfa units)
ranges = {
    "Glicose em jejum": (70, 99),
    "Colesterol LDL": (None, 130),   # desirable < 130
    "Creatinina": (0.70, 1.30),
    "Hemoglobina glicada (HbA1c)": (4.0, 5.6),
}

worse = []
for marker, vals in history.items():
    first, second = vals["10/02/2026"], vals["18/08/2026"]
    lo, hi = ranges[marker]
    outside = (lo is not None and second < lo) or (hi is not None and second > hi)
    got_worse = second > first
    if got_worse and outside:
        worse.append(marker)

result = {"history": history, "worse": worse}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
print(json.dumps(result, ensure_ascii=False, indent=2))