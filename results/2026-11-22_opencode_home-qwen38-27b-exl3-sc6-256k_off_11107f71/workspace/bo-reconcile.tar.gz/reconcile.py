import csv, json, re
from collections import defaultdict

ws = r"<WORKSPACE>"

invoices = {}
with open(ws + r"\backoffice\invoices.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = float(row["amount"])

payments = defaultdict(list)  # invoice id -> list of paid amounts
ignored = []
with open(ws + r"\backoffice\bank_statement_june.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        amt = float(row["amount"])
        m = re.search(r"(?:INV[-\s]?|invoice\s+|inv)(\d{4})", memo, re.I)
        if not m:
            ignored.append((row["date"], memo, amt))
            continue
        inv_id = "INV-" + m.group(1)
        if inv_id not in invoices:
            ignored.append((row["date"], memo, amt))
            continue
        payments[inv_id].append(amt)

unpaid, duplicated, mismatched = [], [], []
for inv_id, amount in sorted(invoices.items()):
    pays = payments.get(inv_id, [])
    if not pays:
        unpaid.append(inv_id)
    elif len(pays) > 1:
        duplicated.append(inv_id)
    elif len(pays) == 1 and abs(pays[0] - amount) > 0.005:
        mismatched.append({"id": inv_id, "invoiced": amount, "paid": pays[0]})

print("ignored rows:")
for i in ignored:
    print(" ", i)
print("paid invoice count:", len(payments))
print("unpaid:", unpaid)
print("duplicated:", duplicated)
print("mismatched:", mismatched)

result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
with open(ws + r"\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
print("wrote result.json")