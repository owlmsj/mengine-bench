import csv, json
from collections import defaultdict

base = r"<WORKSPACE>\finance"

pnl = {}
with open(base + r"\chart_of_accounts.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        pnl[row["account"]] = row["pnl_line"]

months = ["2026-01","2026-02","2026-03","2026-04","2026-05","2026-06"]
rev = defaultdict(float); cogs = defaultdict(float); ebitda = defaultdict(float)

with open(base + r"\ledger.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        d = row["date"]  # dd/mm/yyyy
        m = f"2026-{d[3:5]}"
        amt = float(row["amount"].replace(".", "").replace(",", "."))
        line = pnl[row["account"]]
        if line == "revenue":
            rev[m] += amt
        elif line == "cogs":
            cogs[m] += amt
        ebitda[m] += amt  # operating lines only; financial (6.x) excluded from EBITDA

result = {
    "revenue": {m: round(rev[m], 2) for m in months},
    "gross_margin_pct": {m: round((rev[m] + cogs[m]) / rev[m] * 100, 2) for m in months},
    "ebitda": {m: round(ebitda[m], 2) for m in months},
}

# burn: average monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = ["2026-04","2026-05","2026-06"]
neg = [abs(ebitda[m]) for m in last3 if ebitda[m] < 0]
burn = sum(neg) / len(neg)
cash = 1847350.40  # 30/06/2026 consolidated balance
runway = cash / burn
result["burn"] = round(burn, 2)
result["runway_months"] = round(runway, 2)

print(json.dumps(result, indent=2))
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)