# Handoff: local-9b Q5 @ 128k

Goal: measure local-9b Q5 decode at 128k. Done: recipe applied in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

Verified: with `--no-mmproj-offload -ub 512`, spill gone, VRAM 7697 MiB, decode 38.0 t/s (median of 3). Baseline: 37.8 t/s, 7881 MiB — but 7881 is the WDDM ceiling; Shared Usage shows 1494 MiB spilled, so that VRAM figure does not count. Q6_K (7.03 GiB) does not fit at 128k; discarded. Q4_K_M fits (7305 MiB, 40.4 t/s) — fallback only.

Assumption: the repo (scripts/, profiles/, evals/) lives where the work was done, not here — only the transcript is in this folder, so file contents are not re-verifiable.

Left open:
1. Update the evals README — still cites check_vision.ps1, which no longer exists.
2. Review scratchpad temp file names (noted repeatedly, never done).

How I know it's right: numbers are quoted from the transcript's measurement lines; pending items are its own "Pending"/"Noted for later" lines.