"""Helper for batch scripts: run zero-arg async task factories with a
bounded concurrency, surviving Ctrl+C so job cleanup code still runs.

Usage:
    from run import run_tasks

    async def main():
        await run_tasks([make_job, make_job, ...], max_concurrent=4)

Each task is a zero-argument callable that returns an awaitable job.
At most `max_concurrent` jobs run at once. `run_tasks` returns when
every job is done.

Ctrl+C behavior: the first SIGINT does not kill the run. It stops
starting new jobs and lets the jobs already running finish (their
finally/cleanup code runs). A second SIGINT cancels the running jobs
(their finally blocks still run, as cancellation does not skip them).
"""

from __future__ import annotations

import asyncio
import signal
import sys
from typing import Any, Awaitable, Callable, Iterable


class _RunState:
    __slots__ = ("stopping",)

    def __init__(self) -> None:
        self.stopping = False


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[Any]]],
    max_concurrent: int,
) -> None:
    """Run all jobs from `tasks` with at most `max_concurrent` in flight.

    `tasks` is an iterable of zero-argument callables; each call returns
    an awaitable job. The iterable is consumed eagerly so that a lazy
    generator cannot be affected by Ctrl+C mid-iteration.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent}")

    factories = list(tasks)
    semaphore = asyncio.Semaphore(max_concurrent)
    state = _RunState()

    loop = asyncio.get_running_loop()
    original_handler = None
    installed = False

    def _on_first_sigint() -> None:
        # First Ctrl+C: stop starting new jobs, let running ones finish.
        state.stopping = True
        # Second Ctrl+C: restore default behavior (raises KeyboardInterrupt
        # in the main task, which cancels the whole task group).
        loop.add_signal_handler(signal.SIGINT, loop.default_int_handler)

    if sys.platform == "win32":
        # On Windows add_signal_handler is unavailable; fall back to a
        # plain handler that records the first Ctrl+C.
        def _win_sigint(signum, frame):  # noqa: ARG001
            if not state.stopping:
                state.stopping = True
            else:
                # Second Ctrl+C: restore the default handler and re-raise.
                signal.signal(signal.SIGINT, signal.default_int_handler)
                raise KeyboardInterrupt

        try:
            original_handler = signal.getsignal(signal.SIGINT)
            signal.signal(signal.SIGINT, _win_sigint)
            installed = True
        except ValueError:
            # Not in the main thread: no signal handling, run as-is.
            pass
    else:
        try:
            loop.add_signal_handler(signal.SIGINT, _on_first_sigint)
            installed = True
        except (NotImplementedError, RuntimeError):
            installed = False

    async def _worker(factory: Callable[[], Awaitable[Any]]) -> None:
        if state.stopping:
            return
        async with semaphore:
            if state.stopping:
                return
            await factory()

    try:
        async with asyncio.TaskGroup() as group:
            for factory in factories:
                if state.stopping:
                    break
                group.create_task(_worker(factory))
    finally:
        if installed:
            if sys.platform == "win32":
                signal.signal(signal.SIGINT, original_handler)
            else:
                loop.remove_signal_handler(signal.SIGINT)