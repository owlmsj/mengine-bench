import csv, json, statistics

ws = r"<WORKSPACE>"

rows = []
with open(ws + r"\capture\presentmon.csv") as f:
    r = csv.DictReader(f)
    for row in r:
        rows.append(row)

mbp = [float(x["MsBetweenPresents"]) for x in rows]
t = [float(x["TimeInSeconds"]) for x in rows]
mean = sum(mbp) / len(mbp)
avg_fps = 1000.0 / mean
srt = sorted(mbp)
n = len(srt)
# 99th percentile (nearest-rank)
p99 = srt[int(round(0.99 * (n - 1)))]
low1 = 1000.0 / p99
print("frames:", n, "mean_ms:", round(mean, 3), "avg_fps:", round(avg_fps, 2))
print("p99_ms:", p99, "low1pct_fps:", round(low1, 2))
print("p95_ms:", srt[int(round(0.95 * (n - 1)))])
print("max_ms:", max(mbp))

# slow frames: > 3x mean
slow = [(t[i], mbp[i]) for i in range(n) if mbp[i] > 3 * mean]
print("slow frames (>3x mean):", len(slow))
for s in slow[:40]:
    print("  t=%.3f ms=%.2f" % s)

# sensors
sens = []
with open(ws + r"\capture\sensors.csv") as f:
    for row in csv.DictReader(f):
        sens.append(row)
l1 = [int(s["time_s"]) for s in sens if s["gpu_pcie_link_state"] == "L1"]
print("L1 seconds:", l1)
dpc = [(int(s["time_s"]), int(s["dpc_latency_us"])) for s in sens if int(s["dpc_latency_us"]) > 200]
print("DPC>200us:", dpc)

# check slow frames vs L1 seconds and DPC seconds
l1set = set(l1)
dpcset = {d[0] for d in dpc}
near_l1 = sum(1 for s in slow if any(abs(s[0] - (ls + 1)) < 1.2 or abs(s[0] - ls) < 1.2 for ls in l1set))
print("slow frames within ~1.2s of an L1 second:", near_l1, "of", len(slow))
# distribution of slow frames by second
from collections import Counter
c = Counter(int(s[0]) for s in slow)
print("slow frames by second:", dict(sorted(c.items())))