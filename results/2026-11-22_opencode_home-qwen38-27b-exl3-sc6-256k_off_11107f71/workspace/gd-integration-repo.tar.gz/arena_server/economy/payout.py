"""Match payout. Rules live in docs/ECONOMY.md."""

from decimal import ROUND_HALF_UP, Decimal


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    raw = (base + kills * cfg["kill_bonus"]) * cfg["event_multiplier"]
    # Docs: round to nearest ten, halves always up (1425 -> 1430, 1585 -> 1590).
    return int(Decimal(str(raw)).quantize(Decimal("1E1"), rounding=ROUND_HALF_UP))
