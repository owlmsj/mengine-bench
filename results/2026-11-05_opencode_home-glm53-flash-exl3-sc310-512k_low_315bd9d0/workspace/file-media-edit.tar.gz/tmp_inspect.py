import pypdf
r = pypdf.PdfReader('permit-form.pdf')
print('pages', len(r.pages))
f = r.get_fields()
if f:
    for k, v in f.items():
        print(repr(k), v.get('/V'), v.get('/FT'))
else:
    print('no acroform fields')
for i, p in enumerate(r.pages):
    print('--- page', i)
    print(p.extract_text())