from PIL import Image
import numpy as np
im = np.array(Image.open('launch.jpg').convert('RGB')).astype(int)
r, g, b = im[:,:,0], im[:,:,1], im[:,:,2]
m = (r > 180) & (b > 150) & (g < 120)
ys, xs = np.where(m)
print('bbox x0,y0,x1,y1:', xs.min(), ys.min(), xs.max(), ys.max())