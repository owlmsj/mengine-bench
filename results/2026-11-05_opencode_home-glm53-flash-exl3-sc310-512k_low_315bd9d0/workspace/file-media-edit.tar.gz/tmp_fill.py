import pypdf
reader = pypdf.PdfReader('permit-form.pdf')
writer = pypdf.PdfWriter()
writer.append(reader)
writer.update_page_form_field_values(writer.pages[0], {
    'organizer': 'Tidewater Studio',
    'event_date': '2026-12-05',
    'location': 'North Cove Lawn',
    'attendees': '40',
}, auto_regenerate=False)
# flatten: remove AcroForm so fields are no longer editable
writer.set_need_appearances_writer(True)
# burn appearances into page content by regenerating then clearing form
# pypdf cannot truly flatten; emulate: keep appearances, remove field widgets' editability
# Simplest reliable flatten: draw field appearance text directly and drop form.
import zlib
writer.update_page_form_field_values(writer.pages[0], {
    'organizer': 'Tidewater Studio',
    'event_date': '2026-12-05',
    'location': 'North Cove Lawn',
    'attendees': '40',
})
# Clear AcroForm from catalog
root = writer._root_object
if '/AcroForm' in root:
    del root['/AcroForm']
with open('out/permit-filled.pdf', 'wb') as fh:
    writer.write(fh)
print('written')
r2 = pypdf.PdfReader('out/permit-filled.pdf')
print('fields:', r2.get_fields())
print(r2.pages[0].extract_text())