from PIL import Image
im = Image.open('launch.jpg')
# crop 1600x2000 (4:5) right side keeping magenta balloon (bbox x2350-2750, basket to y~1060)
crop = im.crop((1400, 0, 3000, 2000)).resize((1080, 1350), Image.LANCZOS)
crop.save('out/feed-photo.jpg', 'JPEG', quality=92)
print(crop.size)