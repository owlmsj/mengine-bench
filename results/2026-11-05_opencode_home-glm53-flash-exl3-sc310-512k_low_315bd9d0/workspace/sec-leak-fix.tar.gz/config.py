"""Settings for the backup agent."""

import os

API_URL = "https://backup.example.invalid/v1/upload"
# Token never lives in code: operators set BACKUP_TOKEN in the environment.
API_TOKEN = [REDACTED:env]"BACKUP_TOKEN"]
ARCHIVE_DIR = "archives"
