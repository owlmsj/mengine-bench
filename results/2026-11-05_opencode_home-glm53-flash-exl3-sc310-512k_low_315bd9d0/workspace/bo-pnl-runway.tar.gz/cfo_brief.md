# H1 2026 Close - CFO Board Brief

Source: finance/ledger.csv (86 entries), chart_of_accounts.csv, cash_balance.txt, README.md.

## Monthly P&L (R$)

| Month | Revenue | Gross margin | EBITDA |
|---|---|---|---|
| 2026-01 | 200,510.87 | 70.0% | -210,278.96 |
| 2026-02 | 216,328.06 | 70.3% | -212,300.08 |
| 2026-03 | 219,066.17 | 68.5% | -204,525.45 |
| 2026-04 | 238,163.26 | 70.2% | -196,950.65 |
| 2026-05 | 243,032.89 | 69.6% | -201,945.82 |
| 2026-06 | 272,391.57 | 72.4% | -192,968.22 |

## Story
- Revenue grew +35.8% over the half (200.5k -> 272.4k); June was the best month (+12.1% vs May).
- Gross margin stable at ~70%, best in June (72.4%).
- EBITDA improved steadily: losses narrowed 8% (Jan -210.3k -> Jun -193.0k). Tighter G&A/R&D vs growing revenue.

## Burn & runway (per README definition)
- Burn = average negative EBITDA of the last 3 closed months (Apr, May, Jun): R$ 197,288.23/month.
- Runway = 30/06/2026 closing cash R$ 1,847,350.40 / burn = 9.4 months (into ~mid-April 2027).

## Assumptions
- Revenue = accounts 3.1.x (SaaS, onboarding, net of the two Kestrel refunds -8,634.37 and -6,814.15).
- COGS = 4.1.x; GM = (revenue + COGS)/revenue since expense lines are stored negative.
- EBITDA excludes financial income/expenses (6.1.x), per standard convention.
- Ledger and cash balances do not fully reconcile (Jun cash fell 461.8k vs EBITDA -193.0k plus +5.6k financial = -187.4k), implying ~274k of non-P&L cash outflows (e.g., capex/debt service) not in the ledger. Runway uses the board's official formula regardless.

Key figures recorded in ./result.json.