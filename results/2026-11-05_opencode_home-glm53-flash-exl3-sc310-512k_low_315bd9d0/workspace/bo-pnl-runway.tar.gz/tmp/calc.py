import csv, collections, json
rows=list(csv.DictReader(open('finance/ledger.csv',encoding='utf-8'),delimiter=';'))
acc={r['account']:r['pnl_line'] for r in csv.DictReader(open('finance/chart_of_accounts.csv',encoding='utf-8'),delimiter=';')}
def num(s): return float(s.replace('.','').replace(',','.'))
m={k:collections.defaultdict(float) for k in ['revenue','cogs','sales_marketing','rnd','ga','financial']}
for r in rows:
    mo=r['date'][3:5]
    m[acc[r['account']]][mo]+=num(r['amount'])
res={}
for mo in ['01','02','03','04','05','06']:
    rev=m['revenue'][mo]; cogs=m['cogs'][mo]
    ebitda=rev+cogs+m['sales_marketing'][mo]+m['rnd'][mo]+m['ga'][mo]
    res[mo]=(rev,round(100*(rev+cogs)/rev,1),ebitda)
    print(mo,f"rev={rev:,.2f} gm={100*(rev+cogs)/rev:.2f}% ebitda={ebitda:,.2f}")
burn=sum(min(res[mo][2],0) for mo in ['04','05','06'])/3
runway=1847350.40/-burn
print("burn",-burn)
print("runway",runway)
out={'revenue':{f'2026-{mo}':round(res[mo][0],2) for mo in res},
 'gross_margin_pct':{f'2026-{mo}':res[mo][1] for mo in res},
 'ebitda':{f'2026-{mo}':round(res[mo][2],2) for mo in res},
 'burn':round(-burn,2),'runway_months':round(runway,1)}
json.dump(out,open('result.json','w'),indent=1)