import json, re

raw = open(r"<HOME>\.local\share\opencode\tool-output\tool_1acfec4a9001TBes1Wuk2jNho3", encoding="utf-8").read()
data = json.loads(raw[raw.find("{"):])
vals = {}
for v in data["value"]:
    y = int(v["VALDATA"][:4]); mo = int(v["VALDATA"][5:7])
    if mo == 12:
        vals[y] = v["VALVALOR"]
rates = {y: (vals[y] / vals[y - 1] - 1) * 100 for y in range(1985, 1997)}
ipca = {y: round(rates[y], 1) for y in rates}
for y in sorted(rates):
    print(y, round(rates[y], 1))

plans = [("Plano Cruzado", "1986-02-28", 1986), ("Plano Bresser", "1987-06-12", 1987),
         ("Plano Verão", "1989-01-15", 1989), ("Plano Collor I", "1990-03-16", 1990),
         ("Plano Collor II", "1991-01-31", 1991), ("Plano Real", "1994-07-01", 1994)]
months = {"Plano Cruzado": 16, "Plano Bresser": 19, "Plano Verão": 14,
          "Plano Collor I": 10, "Plano Collor II": 41, "Plano Real": 60}
out = []
for name, ld, y in plans:
    b = ipca[y - 1]; a = ipca[y + 1]
    drop = max(0.0, min(1.0, 1 - a / b))
    dur = min(months[name], 60) / 60
    score = round(0.7 * drop + 0.3 * dur, 4)
    out.append({"plan": name, "launch_date": ld, "ipca_before": b, "ipca_after": a,
                "months_lasted": months[name], "score": score})
    print(name, b, a, months[name], score)
json.dump(out, open("tmp_scores.json", "w"), indent=1, ensure_ascii=False)
print("top3:", [o["plan"] for o in sorted(out, key=lambda x: -x["score"])[:3]])