import json, os, re, glob, html, unicodedata, urllib.parse
from collections import defaultdict

root = os.path.join('site')
words = {}   # word -> {"tema":..., "links": {"sinonimo":set,"analoga":set}}
pages = {}   # filename -> word

sect_re = re.compile(r'<section id="(\w+)"><h2>[^<]*</h2><ul>(.*?)</ul></section>', re.S)
a_re = re.compile(r'<a href="([^"]+)">(.*?)</a>')
h1_re = re.compile(r'<h1>(.*?)</h1>')
tema_re = re.compile(r'<p class="tema">Tema: ([^<]*)</p>')

all_links = set()  # (word, targetword, kind)
missing = []

for path in glob.glob(os.path.join(root, '*.html')):
    fn = os.path.basename(path)
    raw = open(path, encoding='utf-8').read()
    m = h1_re.search(raw)
    title = html.unescape(m.group(1)).strip() if m else None
    # index/sobre/contato pages: skip if no main h1 word? index has h1 too
    if fn in ('index.html',):
        pages[fn] = None
        continue
    if title in ('Sobre', 'Contato'):
        pages[fn] = None
        continue
    if title is None:
        pages[fn] = None
        continue
    w = title
    pages[fn] = w
    t = tema_re.search(raw)
    tema = html.unescape(t.group(1)).strip() if t else ''
    entry = words.setdefault(w, {'tema': tema, 'links': {}})
    if tema and not entry['tema']:
        entry['tema'] = tema
    for sm in sect_re.finditer(raw):
        kind, body = sm.group(1), sm.group(2)
        for am in a_re.finditer(body):
            href, label = am.group(1), html.unescape(am.group(2)).strip().lower()
            href_dec = urllib.parse.unquote(am.group(1))
            target = pages.get(os.path.basename(href_dec))
            # resolve by href filename too (link may point to page we haven't read yet)
            all_links.add((w, label, kind, href_dec))
            if target is None and os.path.basename(href) not in pages:
                missing.append(os.path.basename(href))

# resolve href->word for missing pages
for (w, label, kind, href) in all_links:
    tgt = pages.get(os.path.basename(href))
    if tgt is None:
        tgt = html.unescape(os.path.basename(href).replace('.html','')).lower()
        if tgt in ('sobre','contato','index','rascunho-3'):  # nav/dead pages
            continue
    words.setdefault(tgt, {'tema': '', 'links': {}})
    key = 'sinonimo' if kind=='sinonimos' else 'analoga'
    words[w]['links'].setdefault(key, set()).add(tgt)

out = {}
for w, e in words.items():
    out[w] = {'tema': e['tema'],
              'sinonimos': sorted(e['links'].get('sinonimo', set())),
              'analogas': sorted(e['links'].get('analoga', set()))}

json.dump(out, open('words.json','w',encoding='utf-8'), ensure_ascii=False, indent=1, sort_keys=True)
print('words:', len(out))
print('missing pages:', sorted(set(missing))[:20])
rels = set()
for w, e in out.items():
    for s in e['sinonimos']: rels.add(tuple(sorted((w,s))))
    for s in e['analogas']: rels.add(tuple(sorted((w,s))))
print('relations (distinct unordered pairs):', len(rels))
deg = defaultdict(int)
for a,b in rels: deg[a]+=1; deg[b]+=1
print('most connected:', sorted(deg.items(), key=lambda x:-x[1])[:5])