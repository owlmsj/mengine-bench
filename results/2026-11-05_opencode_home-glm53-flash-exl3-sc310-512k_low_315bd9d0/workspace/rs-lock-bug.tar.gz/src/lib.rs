//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        *slot.lock().unwrap() += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let from_slot = self.slot(from);
        let to_slot = self.slot(to);
        // Self-transfer must not deadlock on a single non-reentrant lock,
        // and must change nothing.
        if Arc::ptr_eq(&from_slot, &to_slot) {
            return;
        }
        // Always lock in a consistent order (by allocation address) so
        // concurrent transfers in opposite directions cannot deadlock.
        let (first, second) = if (from_slot.as_ref() as *const Mutex<i64>)
            < (to_slot.as_ref() as *const Mutex<i64>)
        {
            (&from_slot, &to_slot)
        } else {
            (&to_slot, &from_slot)
        };
        let mut first_guard = first.lock().unwrap();
        let mut second_guard = second.lock().unwrap();
        let (from_score, to_score) = if Arc::ptr_eq(first, &from_slot) {
            (&mut *first_guard, &mut *second_guard)
        } else {
            (&mut *second_guard, &mut *first_guard)
        };
        *from_score -= points;
        *to_score += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}
