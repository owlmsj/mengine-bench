use arena_scores::Board;
use std::sync::Arc;

#[test]
fn stress_no_deadlock_no_lost_updates() {
    let board = Arc::new(Board::new());
    for id in 1..=8 {
        board.join(id, 100);
    }
    assert_eq!(board.total(), 800);
    let mut handles = Vec::new();
    for t in 0..8 {
        let b = Arc::clone(&board);
        handles.push(std::thread::spawn(move || {
            for i in 0..2000 {
                let a = 1 + ((t + i) % 8) as u32;
                let c = 1 + ((t + i + 1) % 8) as u32;
                b.award(a, 1);
                b.transfer(a, c, 2);
                b.transfer(c, c, 5); // self-transfer must not hang
            }
        }));
    }
    for h in handles {
        h.join().unwrap();
    }
    // Per-player: join 100, +2000 awards of 1, +2000 self-transfers of 5 (net 0),
    // transfers conserve scores. Expected per player: 2100, total: 16800.
    for id in 1..=8 {
        assert_eq!(board.score(id), 2100, "player {}", id);
    }
    assert_eq!(board.total(), 16800);
}