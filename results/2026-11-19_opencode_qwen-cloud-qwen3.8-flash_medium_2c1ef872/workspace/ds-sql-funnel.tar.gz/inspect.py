import sqlite3
c = sqlite3.connect('analytics.db')
for r in c.execute("select name, sql from sqlite_master where type='table'"):
    print(r[0], '::', r[1])
    n = c.execute(f'select count(*) from "{r[0]}"').fetchone()[0]
    print('rows:', n)
    for row in c.execute(f'select * from "{r[0]}" limit 5'):
        print(' ', row)
