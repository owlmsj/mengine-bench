import json
import sqlite3
from datetime import datetime

STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']

c = sqlite3.connect('analytics.db')
users = {u: (p, t) for u, p, t in c.execute('select user_id, platform, is_test from users')}

# group events per known non-test user, sorted by time
evs = {}
for uid, name, ts in c.execute('select user_id, name, ts from events'):
    if uid not in users or users[uid][1]:
        continue  # unknown players and test accounts do not count
    if name not in STEPS:
        continue
    evs.setdefault(uid, []).append((datetime.strptime(ts, '%Y-%m-%d %H:%M:%S'), name))
for v in evs.values():
    v.sort()

counts = {}
for uid, (platform, is_test) in users.items():
    if is_test:
        continue
    per = counts.setdefault(platform, {s: 0 for s in STEPS})
    prev = datetime.min
    for s in STEPS:
        hit = next((t for t, n in evs.get(uid, []) if n == s and t >= prev), None)
        if hit is None:
            break
        per[s] += 1
        prev = hit

result = {'funnel': {}, 'biggest_drop': {}}
for platform, per in sorted(counts.items()):
    result['funnel'][platform] = per
    best_step, best_conv = None, None
    for i in range(1, len(STEPS)):
        prev_n = per[STEPS[i - 1]]
        conv = per[STEPS[i]] / prev_n if prev_n else 0.0
        if best_conv is None or conv < best_conv:
            best_conv, best_step = conv, STEPS[i]
    result['biggest_drop'][platform] = {'step': best_step, 'conversion': round(best_conv, 4)}

with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
