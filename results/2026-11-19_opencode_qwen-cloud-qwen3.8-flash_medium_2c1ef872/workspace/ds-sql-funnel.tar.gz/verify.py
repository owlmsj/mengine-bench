import json
import sqlite3
from datetime import datetime

c = sqlite3.connect('analytics.db')
users = {u: (p, t) for u, p, t in c.execute('select user_id, platform, is_test from users')}
STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']

evs = {}
for uid, name, ts in c.execute('select user_id, name, ts from events'):
    if uid not in users or users[uid][1] or name not in STEPS:
        continue
    evs.setdefault(uid, []).append((name, datetime.strptime(ts, '%Y-%m-%d %H:%M:%S')))

# example users where first-step-occurrence differs from first-valid-occurrence
ex = 0
for uid, lst in evs.items():
    d = {}
    for n, t in sorted(lst, key=lambda x: x[1]):
        d.setdefault(n, t)
    prev = None
    ok = True
    for s in STEPS:
        cands = sorted(t for n, t in lst if n == s and (prev is None or t >= prev))
        if not cands:
            ok = False
            break
        if s in d and prev is not None and d[s] < prev:
            print('rescued user', uid, users[uid][0], s, 'first@', d[s], 'valid@', cands[0])
            ex += 1
            break
        prev = cands[0]
print('rescued examples:', ex)

# check: per-step first valid occurrence, min-based scan (independent formulation)
chk = {}
for uid, lst in evs.items():
    plat = users[uid][0]
    per = chk.setdefault(plat, {s: 0 for s in STEPS})
    prev = datetime.min
    for s in STEPS:
        cands = [t for n, t in lst if n == s and t >= prev]
        if not cands:
            break
        per[s] += 1
        prev = min(cands)

res = json.load(open('result.json'))
assert chk == {p: res['funnel'][p] for p in chk}, (chk, res['funnel'])
for p, per in res['funnel'].items():
    vals = [per[s] for s in STEPS]
    assert all(a >= b for a, b in zip(vals, vals[1:]))
    conv = {STEPS[i]: per[STEPS[i]] / per[STEPS[i-1]] for i in range(1, 4)}
    assert res['biggest_drop'][p]['step'] == min(conv, key=conv.get)
print('all checks passed')
