use arena_scores::Board;
use std::sync::Barrier;
use std::thread;

#[test]
fn concurrent_awards_lose_no_points() {
    let board = Board::new();
    board.join(1, 0);
    let threads: Vec<_> = (0..8)
        .map(|_| {
            let b = board.clone();
            thread::spawn(move || {
                for _ in 0..1000 {
                    b.award(1, 1);
                }
            })
        })
        .collect();
    for t in threads {
        t.join().unwrap();
    }
    assert_eq!((board.score(1), board.total()), (8000, 8000));
}

#[test]
fn opposite_transfers_do_not_deadlock() {
    let board = Board::new();
    board.join(1, 1000);
    board.join(2, 1000);
    let start = std::sync::Arc::new(Barrier::new(4));
    let threads: Vec<_> = (0..4)
        .map(|i| {
            let b = board.clone();
            let start = start.clone();
            thread::spawn(move || {
                start.wait();
                for _ in 0..2000 {
                    if i % 2 == 0 {
                        b.transfer(1, 2, 1);
                    } else {
                        b.transfer(2, 1, 1);
                    }
                }
            })
        })
        .collect();
    for t in threads {
        t.join().unwrap();
    }
    assert_eq!(board.score(1) + board.score(2), 2000);
    assert_eq!(board.total(), 2000);
}

#[test]
fn self_transfer_changes_nothing() {
    let board = Board::new();
    board.join(7, 42);
    board.transfer(7, 7, 10);
    assert_eq!((board.score(7), board.total()), (42, 42));
}
