# H1 2026 Close — CFO Briefing (investor meeting 2026-11-20 context: first half now closed)

Source: `finance/ledger.csv` (86 postings, Jan–Jun 2026), mapped to P&L lines via `finance/chart_of_accounts.csv`. Cash from `finance/cash_balance.txt`. All values R$.

## Monthly results

| Month | Revenue | Gross margin % | EBITDA |
|---|---:|---:|---:|
| 2026-01 | 200,510.87 | 70.03 | -210,278.96 |
| 2026-02 | 216,328.06 | 70.29 | -212,300.08 |
| 2026-03 | 219,066.17 | 68.46 | -204,525.45 |
| 2026-04 | 238,163.26 | 70.24 | -196,950.65 |
| 2026-05 | 243,032.89 | 69.56 | -201,945.82 |
| 2026-06 | 272,391.57 | 72.41 | -192,968.22 |

- Revenue grew every month: +35.8% Jan → Jun (avg ~5.2% m/m).
- Gross margin steady ~68–70%, best month in June (72.4%).
- EBITDA loss flat at roughly -200k/mo; loss narrowed from -212k (Feb) to -193k (Jun) as revenue outgrew costs.

## Burn and runway (board's definition, README.md)

- Burn = average monthly negative EBITDA of the last three closed months (Apr, May, Jun) = **R$ 197,288.23/mo**.
- Runway = latest closing cash (30/06/2026: R$ 1,847,350.40) ÷ burn = **9.36 months** → cash-out around **mid-April 2027** at current burn.

## Assumptions and notes

- EBITDA = revenue − COGS − S&M − R&D − G&A; financial results (ac. 6.1.x, investment income and interest/IOF) are excluded from EBITDA but sit in the ledger, net small positive (~+6.5k/mo).
- Refunds (3.1.09, "Refund customer Kestrel", Mar and May) are treated as revenue contra, per chart of accounts.
- Ledger net movement (EBITDA + financial) for June (-187.3k) differs from actual cash decline May→June (-461.8k); cash file is authoritative for runway per the board definition. Non-P&L outflows (capex, taxes, working capital) are not in the ledger — flag for CFO before investors ask.
- Figures in `result.json` match this table exactly.
