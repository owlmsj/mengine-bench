"""Helper for running batches of async jobs with a concurrency limit.

Usage from batch scripts:

    from run import run_tasks

    async def main():
        await run_tasks([job_a, job_b], max_concurrent=4)

Each task is a zero-argument callable returning an awaitable (a coroutine).
At most ``max_concurrent`` jobs run at a time. On cancellation (Ctrl+C under
``asyncio.run`` on Python 3.11+, which cancels the main task) already-started
jobs receive a CancelledError so their ``finally``/async-cleanup code runs,
jobs that never started are skipped, and the cancellation is propagated.
"""

import asyncio


async def run_tasks(tasks, max_concurrent):
    if max_concurrent < 1:
        raise ValueError("max_concurrent must be >= 1")

    sem = asyncio.Semaphore(max_concurrent)

    async def guarded(task):
        # Skip jobs that never acquired a slot when we are already cancelling.
        try:
            await sem.acquire()
        except asyncio.CancelledError:
            return
        try:
            await task()
        finally:
            sem.release()

    children = [asyncio.ensure_future(guarded(t)) for t in tasks]
    try:
        # return_exceptions=False: the first real error propagates once the
        # other jobs have finished (their cleanup included) below.
        await asyncio.gather(*children)
    except (asyncio.CancelledError, Exception) as outer:
        # Give every child a chance to unwind (cleanup runs inside the child's
        # own finally blocks) before we re-raise.
        results = await asyncio.gather(*children, return_exceptions=True)
        if isinstance(outer, asyncio.CancelledError):
            raise
        # Prefer the original error; if the children swallowed it, raise the
        # first child exception we find.
        if isinstance(outer, asyncio.CancelledError):
            raise outer
        for r in results:
            if isinstance(r, Exception) and not isinstance(r, asyncio.CancelledError):
                raise r
        raise outer
