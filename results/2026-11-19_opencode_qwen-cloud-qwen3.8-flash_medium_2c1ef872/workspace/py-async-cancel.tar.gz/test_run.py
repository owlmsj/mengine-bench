import asyncio
import time
from run import run_tasks

running = 0
peak = 0
cleanups = []
done = []


async def make_job(i, dur):
    global running, peak
    running += 1
    peak = max(peak, running)
    try:
        await asyncio.sleep(dur)
        done.append(i)
    finally:
        running -= 1
        cleanups.append(i)


async def phase1():
    await run_tasks([lambda i=i: make_job(i, 0.05) for i in range(12)], 3)
    assert peak <= 3, peak
    assert len(done) == 12 and len(cleanups) == 12
    print("PASS cap+complete peak=%d done=%d" % (peak, len(done)))


async def phase2():
    # Simulate Ctrl+C: cancel the run_tasks task mid-flight.
    running = peak2 = 0
    local_clean, local_started = [], []

    async def job(i):
        nonlocal running, peak2
        running += 1
        peak2 = max(peak2, running)
        local_started.append(i)
        try:
            await asyncio.sleep(5)
        finally:
            running -= 1
            local_clean.append(i)

    t = asyncio.create_task(
        run_tasks([lambda i=i: job(i) for i in range(10)], 4)
    )
    await asyncio.sleep(0.1)
    t.cancel()
    try:
        await t
        print("FAIL: no CancelledError")
    except asyncio.CancelledError:
        pass
    assert len(local_clean) == len(local_started) <= 4, (local_clean, local_started)
    assert len(local_started) >= 4
    print("PASS interrupt cleaned=%d started=%d" % (len(local_clean), len(local_started)))


async def phase3():
    # A failing job: others still finish and clean up, error propagates.
    cleaned = []

    async def bad():
        raise RuntimeError("boom")

    async def good(i):
        try:
            await asyncio.sleep(0.05)
        finally:
            cleaned.append(i)

    try:
        await run_tasks([bad] + [lambda i=i: good(i) for i in range(5)], 2)
        print("FAIL: no error")
    except RuntimeError:
        assert len(cleaned) == 5, cleaned
        print("PASS error-propagation cleaned=%d" % len(cleaned))


asyncio.run(asyncio.wait_for(phase1(), 5))
asyncio.run(asyncio.wait_for(phase2(), 5))
asyncio.run(asyncio.wait_for(phase3(), 5))
