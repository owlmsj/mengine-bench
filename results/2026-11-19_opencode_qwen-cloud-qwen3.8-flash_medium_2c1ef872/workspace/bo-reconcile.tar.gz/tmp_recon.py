import csv, json, re

inv = {r['id']: float(r['amount']) for r in csv.DictReader(open('backoffice/invoices.csv'))}
pay = {}
skipped = []
for r in csv.DictReader(open('backoffice/bank_statement_june.csv')):
    amt = float(r['amount'])
    m = re.search(r'(?:INV-|inv|invoice\s+)10(\d{2})', r['memo'])
    iid = 'INV-10' + m.group(1) if m else None
    if iid and iid in inv and amt > 0:
        pay.setdefault(iid, []).append(amt)
    else:
        skipped.append((r['date'], r['memo'], amt))

unpaid = [i for i in inv if i not in pay]
duplicated = [i for i in pay if len(pay[i]) > 1]
mismatched = [{'id': i, 'invoiced': inv[i], 'paid': pay[i][0]}
              for i in pay if len(pay[i]) == 1 and abs(pay[i][0] - inv[i]) > 0.005]

print('statement lines:', 40, 'matched:', sum(len(v) for v in pay.values()))
print('skipped:', skipped)
print('unpaid:', unpaid)
print('duplicated:', duplicated, {i: pay[i] for i in duplicated})
print('mismatched:', mismatched)

result = {
    'unpaid': unpaid,
    'duplicated': duplicated,
    'mismatched': [{'id': d['id'], 'invoiced': f"{d['invoiced']:.2f}", 'paid': f"{d['paid']:.2f}"} for d in mismatched],
}
json.dump(result, open('result.json', 'w'), indent=2, ensure_ascii=False)
