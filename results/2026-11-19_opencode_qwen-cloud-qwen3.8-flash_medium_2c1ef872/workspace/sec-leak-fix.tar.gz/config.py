"""Settings for the backup agent."""

import os

API_URL = "https://backup.example.invalid/v1/upload"
# The API token is never stored in code; it comes from the environment.
# Never log this value.
API_TOKEN = [REDACTED:env]"BACKUP_TOKEN", "")
ARCHIVE_DIR = "archives"
