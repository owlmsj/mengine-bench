# HANDOFF - local-9b at 128k

Goal: usable local-9b Q5 at 128k context (decode speed, VRAM).

Status: done and applied, one doc fix left.

## Findings
- First run "37.8 t/s, 7881 MiB" was invalid: 7881 MiB is the WDDM ceiling, GPU panel showed 1494 MiB in Shared Usage, i.e. VRAM spill. Never trust a VRAM number at the WDDM cap; check the Shared Usage counter.
- Fix: `--no-mmproj-offload -ub 512` removes the spill. Final: 7697 MiB, 38.0 t/s decode (median of 3, `-Ctx 131072 -NPredict 1024` via scripts/measure_decode.ps1).
- Q6_K (7.03 GiB) does not fit at 128k. Q4_K_M fits (7305 MiB, 40.4 t/s), kept as fallback only.

## Applied
Recipe in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

## Open
- evals README still cites check_vision.ps1, which no longer exists; update it.
- Short-prompt tests did not reproduce the spill; keep 128k prefill for re-tests.

This workspace holds only the transcript, not the repo; verify both edits there.
