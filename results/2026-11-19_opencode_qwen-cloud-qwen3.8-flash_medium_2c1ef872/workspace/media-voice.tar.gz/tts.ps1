Add-Type -AssemblyName System.Speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
$s.GetInstalledVoices() | ForEach-Object { Write-Output ($_.VoiceInfo.Name + ' | ' + $_.VoiceInfo.Culture + ' | ' + $_.VoiceInfo.Gender) }
$en = $s.GetInstalledVoices() | Where-Object { $_.VoiceInfo.Culture.Name -like 'en*' } | Select-Object -First 1
if ($en) { $s.SelectVoice($en.VoiceInfo.Name); Write-Output ('Using voice: ' + $en.VoiceInfo.Name) }
else { Write-Output 'Using default voice' }
$msg = 'Welcome aboard the evening ferry, please keep your bags clear of the doors.'
$out = Join-Path $PSScriptRoot 'announcement.wav'
$fmt = New-Object System.Speech.AudioFormat.SpeechAudioFormatInfo(22050, [System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen, [System.Speech.AudioFormat.AudioChannel]::Mono)
$s.Rate = -1
$s.SetOutputToWaveFile($out, $fmt)
$s.Speak($msg)
$s.SetOutputToNull()
$s.Dispose()
