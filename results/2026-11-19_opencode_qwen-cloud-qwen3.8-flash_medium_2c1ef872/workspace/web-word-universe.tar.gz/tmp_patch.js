const fs=require('fs');
const data=fs.readFileSync('tmp_layout.json','utf8').split('<').join('\\u003c');
let h=fs.readFileSync('universe/index.html','utf8');
const tag='<script type="application/json" id="universe">';
const a=h.indexOf(tag);
const b=h.indexOf('</scr'+'ipt>',a);
h=h.slice(0,a+tag.length)+data+h.slice(b);
fs.writeFileSync('universe/index.html',h);
console.log('patched data bytes',data.length);
