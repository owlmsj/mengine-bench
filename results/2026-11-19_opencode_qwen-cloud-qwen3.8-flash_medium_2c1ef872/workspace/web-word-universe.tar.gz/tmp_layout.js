const fs=require('fs'),path=require('path');
const dir='site';
const files=fs.readdirSync(dir).filter(f=>f.endsWith('.html'));
const lower=new Set(files.map(f=>f.toLowerCase()));
const skip=new Set(['index.html','sobre.html','contato.html']);
function decode(s){return s.replace(/&amp;/g,'&').replace(/&#(\d+);/g,(_,d)=>String.fromCodePoint(+d)).replace(/&#x([0-9a-f]+);/gi,(_,h)=>String.fromCodePoint(parseInt(h,16)));}
function resolve(f){f=decodeURIComponent(decode(f)).toLowerCase();
  while(lower.has(f)){const html=fs.readFileSync(path.join(dir,files.find(x=>x.toLowerCase()===f)),'utf8');
    const r=html.match(/url=([^"]+\.html)/); if(r&&!/<h1>/.test(html)){f=path.basename(r[1]).toLowerCase();continue;} break;} return f;}
const themes={};
for(const f of files){const k=f.toLowerCase(); if(skip.has(k))continue;
  const html=fs.readFileSync(path.join(dir,f),'utf8');
  const h1=html.match(/<h1>(.*?)<\/h1>/s); if(!h1)continue;
  const w=decode(h1[1]).trim().toLowerCase();
  const t=html.match(/Tema:\s*(.*?)<\/p>/s);
  themes[w]=t?decode(t[1]).trim().toLowerCase():'outros';
}
const words=JSON.parse(fs.readFileSync('words.json','utf8'));
for(const w of Object.keys(words)) if(!(w in themes)) console.log('NO THEME',w);
// layout: Fruchterman-Reingold 3D
const names=Object.keys(words);
const idx=new Map(names.map((n,i)=>[n,i]));
const N=names.length;
let pos=new Float64Array(N*3),disp=new Float64Array(N*3);
let seed=42;const rnd=()=>(seed=(seed*1103515245+12345)%2147483648)/2147483648;
for(let i=0;i<N*3;i++)pos[i]=(rnd()-0.5)*100;
const edges=[];const seen=new Set();
for(const [a,list] of Object.entries(words)) for(const b of list){const k=[a,b].sort().join('|');if(seen.has(k))continue;seen.add(k);edges.push([idx.get(a),idx.get(b)]);}
const deg=names.map((_,i)=>words[names[i]].length);
const L=100,k3=L*L*L/N,k=Math.cbrt(k3);
const ITER=400;
for(let it=0;it<ITER;it++){
  disp.fill(0);
  for(let i=0;i<N;i++)for(let j=i+1;j<N;j++){
    let dx=pos[i*3]-pos[j*3],dy=pos[i*3+1]-pos[j*3+1],dz=pos[i*3+2]-pos[j*3+2];
    let d=Math.sqrt(dx*dx+dy*dy+dz*dz)+1e-6;
    let f=k*k/d/d; // unit * magnitude
    dx*=f;dy*=f;dz*=f;
    disp[i*3]+=dx;disp[i*3+1]+=dy;disp[i*3+2]+=dz;
    disp[j*3]-=dx;disp[j*3+1]-=dy;disp[j*3+2]-=dz;
  }
  for(const [a,b] of edges){
    let dx=pos[a*3]-pos[b*3],dy=pos[a*3+1]-pos[b*3+1],dz=pos[a*3+2]-pos[b*3+2];
    let d=Math.sqrt(dx*dx+dy*dy+dz*dz)+1e-6;
    let f=d*d/k/d;
    dx*=f;dy*=f;dz*=f;
    disp[a*3]-=dx;disp[a*3+1]-=dy;disp[a*3+2]-=dz;
    disp[b*3]+=dx;disp[b*3+1]+=dy;disp[b*3+2]+=dz;
  }
  // mild gravity to keep components together
  for(let i=0;i<N;i++){const d=Math.hypot(pos[i*3],pos[i*3+1],pos[i*3+2])+1e-6;const g=0.15*d*d/k/N*3;
    disp[i*3]-=pos[i*3]/d*g;disp[i*3+1]-=pos[i*3+1]/d*g;disp[i*3+2]-=pos[i*3+2]/d*g;}
  const t=10*(1-it/ITER)+0.05;
  for(let i=0;i<N;i++){
    const d=Math.hypot(disp[i*3],disp[i*3+1],disp[i*3+2])+1e-6;
    const s=Math.min(d,t)/d;
    for(let c=0;c<3;c++)pos[i*3+c]+=disp[i*3+c]*s;
  }
}
// normalize scale
let maxr=0;for(let i=0;i<N;i++){const r=Math.hypot(pos[i*3],pos[i*3+1],pos[i*3+2]);if(r>maxr)maxr=r;}
const S=60/maxr;const P=new Array(N);for(let i=0;i<N;i++)P[i]=[+(pos[i*3]*S).toFixed(2),+(pos[i*3+1]*S).toFixed(2),+(pos[i*3+2]*S).toFixed(2)];
fs.writeFileSync('tmp_layout.json',JSON.stringify({names,edges:edges.map(e=>[e[0],e[1]]),deg,pos:P,themes:names.map(n=>themes[n]||'outros')}));
console.log('N',N,'E',edges.length,'themes',new Set(Object.values(themes)).size);
// sanity: symmetry check
let asym=0;for(const [a,l] of Object.entries(words))for(const b of l)if(!words[b]||!words[b].includes(a))asym++;
console.log('asymmetric entries',asym);
console.log('saudade ->',words['saudade']);
