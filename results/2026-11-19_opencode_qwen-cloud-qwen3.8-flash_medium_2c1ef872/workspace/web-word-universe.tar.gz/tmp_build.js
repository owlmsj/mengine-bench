const fs=require('fs');
const L=JSON.parse(fs.readFileSync('tmp_layout.json','utf8'));
const data=JSON.stringify(L).replace(/</g,'\\u003c');
const html=`<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>O Universo das Palavras · Dicionário Criativo</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,300;9..144,600&family=Space+Grotesk:wght@300;500&display=swap" rel="stylesheet">
<style>
:root{--bg:#05060e;--ink:#e8e6f2;--dim:#8b88a8;--accent:#ffd166;}
*{box-sizing:border-box;margin:0}
html,body{height:100%;background:var(--bg);color:var(--ink);font-family:'Space Grotesk',system-ui,sans-serif;overflow:hidden}
#app{position:fixed;inset:0}
canvas{display:block}
.hud{position:fixed;z-index:5;pointer-events:none}
.hud *{pointer-events:auto}
#title{top:22px;left:26px;max-width:44vw}
#title h1{font-family:'Fraunces',serif;font-weight:300;font-size:26px;letter-spacing:.02em}
#title h1 b{font-weight:600;color:var(--accent)}
#title p{color:var(--dim);font-size:12px;margin-top:6px;line-height:1.5}
#title .count{color:var(--ink)}
#search{top:22px;right:26px;display:flex;flex-direction:column;align-items:flex-end;gap:4px}
#q{width:250px;background:rgba(20,22,44,.8);border:1px solid #2c2f55;border-radius:10px;color:var(--ink);padding:10px 14px;font:14px 'Space Grotesk';outline:none}
#q:focus{border-color:var(--accent)}
#sug{display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end;max-width:320px}
#sug button{background:none;border:0;color:var(--dim);font:12px 'Space Grotesk';cursor:pointer;border-bottom:1px dashed #3a3d63}
#sug button:hover{color:var(--accent)}
#panel{right:26px;top:110px;bottom:26px;width:320px;background:rgba(13,15,32,.86);backdrop-filter:blur(8px);border:1px solid #26294a;border-radius:16px;padding:20px;overflow-y:auto;display:none}
#panel.on{display:block}
#panel h2{font-family:'Fraunces',serif;font-weight:600;font-size:30px;color:var(--accent)}
#panel .tema{margin:6px 0 14px;font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--dim)}
#panel .deg{font-size:12px;color:var(--dim);margin-bottom:12px}
#panel ul{list-style:none;display:flex;flex-wrap:wrap;gap:7px}
#panel li button{background:#1b1e3d;border:1px solid #303459;color:var(--ink);border-radius:999px;padding:5px 12px;font:13px 'Space Grotesk';cursor:pointer}
#panel li button:hover{border-color:var(--accent);color:var(--accent)}
#panel .close{float:right;background:none;border:0;color:var(--dim);font-size:18px;cursor:pointer}
#legend{left:26px;bottom:22px;display:flex;flex-wrap:wrap;gap:10px;max-width:60vw}
#legend span{font-size:11px;color:var(--dim);display:flex;align-items:center;gap:5px}
#legend i{width:9px;height:9px;border-radius:50%;display:inline-block}
#hint{left:50%;bottom:16px;transform:translateX(-50%);color:#55587c;font-size:11px;letter-spacing:.08em}
#noword{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);z-index:9;background:rgba(13,15,32,.92);border:1px solid #303459;border-radius:14px;padding:18px 24px;display:none;font-size:14px}
#noword b{color:var(--accent)}
</style>
</head>
<body>
<div id="app"></div>
<div class="hud" id="title">
  <h1>O universo das <b>palavras</b></h1>
  <p><span class="count" id="stats"></span> · cada luz é uma palavra, cada fio é um elo que o dicionário conhece. Arraste para girar, role para aproximar, clique numa palavra.</p>
</div>
<div class="hud" id="search">
  <input id="q" type="text" placeholder="buscar palavra… ex.: saudade" autocomplete="off" spellcheck="false">
  <div id="sug"></div>
</div>
<div class="hud" id="panel"></div>
<div class="hud" id="legend"></div>
<div class="hud" id="hint">?word=saudade abre qualquer palavra</div>
<div id="noword"></div>
<script type="application/json" id="universe">__DATA__</script>
<script type="module">
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js';
const D=JSON.parse(document.getElementById('universe').textContent);
const WORDS=D.names, N=WORDS.length, IDX=new Map(WORDS.map((w,i)=>[i?0:0,0]));
const idOf=new Map(WORDS.map((w,i)=>[w,i]));
const nbrs=Array.from({length:N},()=>new Set());
for(const [a,b] of D.edges){nbrs[a].add(b);nbrs[b].add(a);}
document.getElementById('stats').textContent=N+' palavras · '+D.edges.length+' ligações';
const THEME_HUES={};
D.themes.forEach((t,i)=>{if(!(t in THEME_HUES))THEME_HUES[t]=(Object.keys(THEME_HUES).length*36)%360;});
const legend=document.getElementById('legend');
legend.innerHTML=Object.keys(THEME_HUES).map(t=>'<span><i style=\\"background:hsl('+THEME_HUES[t]+' 80% 65%);box-shadow:0 0 6px hsl('+THEME_HUES[t]+' 80% 60%)\\"></i>'+t+'</span>').join('');

const scene=new THREE.Scene();
scene.fog=new THREE.FogExp2(0x05060e,0.006);
const camera=new THREE.PerspectiveCamera(55,innerWidth/innerHeight,0.1,2000);
camera.position.set(0,0,150);
const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true});
renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,2));
document.getElementById('app').appendChild(renderer.domElement);
// starfield
{const g=new THREE.BufferGeometry(),p=new Float32Array(1200*3);
for(let i=0;i<1200*3;i++)p[i]=(Math.random()-0.5)*900;
g.setAttribute('position',new THREE.BufferAttribute(p,3));
scene.add(new THREE.Points(g,new THREE.PointsMaterial({color:0x555a8a,size:0.7,transparent:true,opacity:0.5})));}
const maxDeg=Math.max(...D.deg);
const cols=[];const nodePos=[];
for(let i=0;i<N;i++){
  nodePos.push(new THREE.Vector3(...D.pos[i]));
  const c=new THREE.Color().setHSL(THEME_HUES[D.themes[i]]/360,0.75,0.45+0.25*D.deg[i]/maxDeg);
  cols.push(c.r,c.g,c.b);
}
const ng=new THREE.BufferGeometry();
ng.setAttribute('position',new THREE.Float32BufferAttribute(nodePos.flatMap(v=>[v.x,v.y,v.z]),3));
ng.setAttribute('color',new THREE.Float32BufferAttribute(cols,3));
const spheres=[];
for(let i=0;i<N;i++){
  const r=1.5+3.4*Math.sqrt(D.deg[i]/maxDeg);
  const m=new THREE.Mesh(new THREE.SphereGeometry(r,18,18),new THREE.MeshBasicMaterial({color:new THREE.Color(cols[i*3],cols[i*3+1],cols[i*3+2])}));
  m.position.copy(nodePos[i]);m.userData.i=i;scene.add(m);spheres.push(m);
}
const eBase=new Float32Array(D.edges.length*6),eCol=new Float32Array(D.edges.length*6);
D.edges.forEach(([a,b],k)=>{const pa=nodePos[a],pb=nodePos[b];
  eBase.set([pa.x,pa.y,pb.x,pb.y].length? [pa.x,pa.y,pa.z,pb.x,pb.y,pb.z]:[],k*6);
  eCol.set([0.25,0.27,0.5,0.25,0.27,0.5],k*6);});
const eg=new THREE.BufferGeometry();
eg.setAttribute('position',new THREE.BufferAttribute(eBase,3));
eg.setAttribute('color',new THREE.BufferAttribute(eCol,3));
const lines=new THREE.LineSegments(eg,new THREE.LineBasicMaterial({vertexColors:true,transparent:true,opacity:0.5}));
scene.add(lines);
// labels
const labelGroup=new THREE.Group();scene.add(labelGroup);
const labelCache=new Map();
function makeLabel(w){
  const c=document.createElement('canvas');const x=c.getContext('2d');
  const f='600 44px Fraunces, serif';x.font=f;
  const tw=x.measureText(w).width;c.width=tw+24;c.height=64;
  x.font=f;x.fillStyle='#f2f0ff';x.shadowColor='#000';x.shadowBlur=8;x.textBaseline='middle';x.fillText(w,12,34);
  const t=new THREE.CanvasTexture(c);t.anisotropy=4;
  const s=new THREE.Sprite(new THREE.SpriteMaterial({map:t,transparent:true,depthWrite:false}));
  s.scale.set(c.width/26,c.height/26,1);return s;
}
function spriteFor(i){let s=labelCache.get(i);if(!s){s=makeLabel(WORDS[i]);s.userData.i=i;labelCache.set(i,s);}return s;}
// controls (hand-rolled orbit)
let theta=0.3,phi=1.2,radius=105,drag=null,spin=0.0006;
addEventListener('pointerdown',e=>{drag=[e.clientX,e.clientY,theta,phi];});
addEventListener('pointerup',()=>drag=null);
addEventListener('pointermove',e=>{
  if(drag){theta=drag[2]-(e.clientX-drag[0])*0.005;phi=Math.max(0.05,Math.min(Math.PI-0.05,drag[3]-(e.clientY-drag[1])*0.005));}
  pick(e.clientX,e.clientY,false);
});
renderer.domElement.addEventListener('wheel',e=>{e.preventDefault();radius*=1+Math.sign(e.deltaY)*0.08;radius=Math.max(25,Math.min(320,radius));},{passive:false});
function camUpdate(){camera.position.set(radius*Math.sin(phi)*Math.sin(theta),radius*Math.cos(phi),radius*Math.sin(phi)*Math.cos(theta));camera.lookAt(camCenter);}
// picking
const ray=new THREE.Raycaster(),mouse=new THREE.Vector2();let hover=-1;
function pick(cx,cy,click){
  mouse.set(cx/innerWidth*2-1,-(cy/innerHeight)*2+1);
  ray.setFromCamera(mouse,camera);
  const hit=ray.intersectObjects(spheres,false)[0];
  hover=hit?hit.object.userData.i:-1;
  renderer.domElement.style.cursor=hover>=0?'pointer':(drag?'grabbing':'grab');
  if(click&&hover>=0)select(WORDS[hover],true);
  return hover;
}
renderer.domElement.addEventListener('click',e=>{if(!moved(e))pick(e.clientX,e.clientY,true);});
function moved(){return false;}
// selection
let sel=-1,dimT=1;
function applyHighlight(){
  labelGroup.clear();
  const focus=sel>=0?sel:hover;
  for(let i=0;i<D.edges.length;i++){
    const [a,b]=D.edges[i];let r=0.18,g=0.2,b2=0.42;
    if(focus>=0&&(a===focus||b===focus)){const c=spheres[focus].material.color;r=c.r;g=c.g;b2=c.b;}
    eCol.set([r,g,b2,r,g,b2],i*6);
  }
  eg.attributes.color.needsUpdate=true;
  for(const m of spheres){
    const on=focus<0||m.userData.i===focus||nbrs[focus].has(m.userData.i);
    m.material.opacity=on?1:0.22;m.material.transparent=focus>=0;
  }
  lines.material.opacity=focus>=0?0.35:0.5;
  if(focus>=0){
    const s=spriteFor(focus);s.position.copy(nodePos[focus]).add(new THREE.Vector3(0,2.6+2*Math.sqrt(D.deg[focus]/maxDeg),0));labelGroup.add(s);
    for(const j of nbrs[focus]){const l=spriteFor(j);l.position.copy(nodePos[j]).add(new THREE.Vector3(0,2.2,0));l.material.opacity=0.85;labelGroup.add(l);}
  }
}
function select(w,setUrl){
  const i=idOf.get(w.toLowerCase());
  const nw=WORDSET.has(w.toLowerCase());
  sel=i??-1;applyHighlight();
  const panel=document.getElementById('panel'),noword=document.getElementById('noword');
  if(sel<0){panel.classList.remove('on');
    if(w){noword.style.display='block';noword.innerHTML='“<b>'+w+'</b>” não existe neste universo. Tente: '+['saudade','amor','tempo','palavra'].map(x=>'<button onclick=\\\\'select(\\\''+x+'\\\\')\\'>' + x + '</button>').join(' ');}
    return;}
  noword.style.display='none';
  const list=[...nbrs[sel]].sort((a,b)=>D.deg[b]-D.deg[a]).map(j=>WORDS[j]);
  panel.classList.add('on');
  panel.innerHTML='<button class="close" onclick="closePanel()">✕</button><h2>'+WORDS[sel]+'</h2>'+
   '<div class="tema">'+D.themes[sel]+'</div>'+
   '<div class="deg">'+list.length+' ligações · grau '+D.deg[sel]+(D.deg[sel]===maxDeg?' (máximo do universo)':'')+'</div><ul>'+
   list.map(x=>'<li><button onclick="select(\\''+x.replace(/'/g,"\\\\'")+'\\',true)">'+x+'</button></li>').join('')+'</ul>';
  if(setUrl)history.replaceState(null,'','?word='+encodeURIComponent(WORDS[sel]));
}
const WORDSET=new Set(WORDS);
window.closePanel=()=>{sel=-1;applyHighlight();document.getElementById('panel').classList.remove('on');};
window.select=select;
document.addEventListener('click',e=>{const b=e.target.closest('button[data-w]');if(b)select(b.dataset.w,true);});
// search
const q=document.getElementById('q'),sug=document.getElementById('sug');
q.addEventListener('input',()=>{
  const v=q.value.trim().toLowerCase();if(!v){sug.innerHTML='';return;}
  const hits=WORDS.filter(w=>w.startsWith(v)).slice(0,5);
  sug.innerHTML=hits.map(w=>'<button onclick="select(\\''+w+'\\',true)">'+w+'</button>').join('');
});
q.addEventListener('keydown',e=>{
  if(e.key==='Enter'){const v=q.value.trim().toLowerCase();
    const hit=WORDS.find(w=>w===v)||WORDS.find(w=>w.startsWith(v));
    if(hit)select(hit,true);else select(v||'',true);sug.innerHTML='';}
});
// idle drift + focus easing
let target=sel;
function tick(){
  requestAnimationFrame(tick);
  if(!drag)theta+=spin;
  if(sel!==target){target=sel;}
  const t=sel>=0?nodePos[sel]:new THREE.Vector3();
  camCenter.lerp(t,0.04);
  camUpdate();
  renderer.render(scene,camera);
}
const camCenter=new THREE.Vector3();
applyHighlight();tick();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
// deep link
const p=new URLSearchParams(location.search),w0=p.get('word');
if(w0){q.value=w0;select(w0,false);}else{select('saudade',false);history.replaceState(null,'','?word=saudade');}
</script>
</body></html>`;
fs.mkdirSync('universe',{recursive:true});
fs.writeFileSync('universe/index.html',html.replace('__DATA__',data));
console.log('bytes',html.length+data.length);
