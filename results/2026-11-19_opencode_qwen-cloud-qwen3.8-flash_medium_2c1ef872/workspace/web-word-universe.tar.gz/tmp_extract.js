const fs = require('fs'), path = require('path');
const dir = 'site';
const files = fs.readdirSync(dir).filter(f => f.endsWith('.html'));
const skip = new Set(['index.html','sobre.html','contato.html']);
const exists = new Set(files.map(f=>f.toLowerCase()));
function resolve(f) {
  f = decodeURIComponent(f);
  while (exists.has(f.toLowerCase()) && !skip.has(f.toLowerCase())) {
    const html = fs.readFileSync(path.join(dir,f),'utf8');
    const r = html.match(/url=([^"]+\.html)/);
    const d = html.match(/<h1>/);
    if (r && !d) { f = path.basename(r[1]); continue; }
    break;
  }
  return f.toLowerCase();
}
// parse each word page: h1 = word, sections sinonimos/analogas links
const pages = {}; // file(lower) -> {word, links:Set}
function decode(s){return s.replace(/&amp;/g,'&').replace(/&#(\d+);/g,(_,d)=>String.fromCodePoint(+d)).replace(/&#x([0-9a-f]+);/gi,(_,h)=>String.fromCodePoint(parseInt(h,16)));}
for (const f of files) {
  const key = f.toLowerCase();
  if (skip.has(key)) continue;
  const html = fs.readFileSync(path.join(dir,f),'utf8');
  const h1 = html.match(/<h1>(.*?)<\/h1>/s);
  if (!h1) { console.log('NOH1', f); continue; }
  const word = decode(h1[1]).trim().toLowerCase();
  const main = html.match(/<main>([\s\S]*?)<\/main>/);
  const links = new Set();
  if (main) {
    for (const m of main[1].matchAll(/<a href="([^"#]+\.html)"/g)) {
      const t = resolve(path.basename(decode(m[1])));
      if (t !== key) links.add(t);
    }
  }
  pages[key] = { word, links };
}
const fileToWord = {};
for (const [k,v] of Object.entries(pages)) fileToWord[k]=v.word;
// check duplicate words
const byWord = {};
for (const [k,v] of Object.entries(pages)) (byWord[v.word] ||= []).push(k);
for (const [w,fs_] of Object.entries(byWord)) if (fs_.length>1) console.log('DUP WORD', w, fs_);
// adjacency by word (symmetrized)
const adj = {};
for (const w of Object.values(fileToWord)) adj[w] = new Set();
let pairs = new Set();
for (const [k,v] of Object.entries(pages)) {
  for (const l of v.links) {
    const lw = fileToWord[l];
    if (lw === undefined) { console.log('MISSING TARGET', k, l); continue; }
    if (lw === v.word) continue;
    adj[v.word].add(lw); adj[lw].add(v.word);
    pairs.add([v.word,lw].sort().join('|'));
  }
}
// merge duplicate word files adjacency already handled via words
const out = {};
for (const [w,s] of Object.entries(adj)) out[w] = [...s].sort();
fs.writeFileSync('words.json', JSON.stringify(out, null, 1));
const sorted = Object.entries(adj).map(([w,s])=>[w,s.size]).sort((a,b)=>b[1]-a[1]);
const maxDeg = sorted[0][1];
const top = sorted.filter(x=>x[1]===maxDeg).map(x=>x[0]).sort();
fs.writeFileSync('result.json', JSON.stringify({ words: Object.keys(out).length, relations: pairs.size, most_connected: top.length===1?top[0]:top }, null, 1));
console.log('words', Object.keys(out).length, 'pairs', pairs.size);
console.log('top', sorted.slice(0,8));
// counts: directed only vs symmetrized
let directed = new Set();
for (const [k,v] of Object.entries(pages)) for (const l of v.links) { const lw=fileToWord[l]; if(lw&&lw!==v.word) directed.add([v.word,lw].sort().join('|')); }
console.log('unique undirected from source edges', directed.size);
