//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

#[derive(Default)]
struct BoardState {
    players: HashMap<PlayerId, i64>,
    total: i64,
}

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    // A single lock protects both player scores and the running total so
    // read-modify-write updates stay atomic, total always matches player
    // scores, and multi-player transfers cannot deadlock.
    state: Arc<Mutex<BoardState>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        let mut state = self.state.lock().unwrap();
        if let Some(previous) = state.players.insert(id, score) {
            state.total -= previous;
        }
        state.total += score;
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let found = {
            let mut state = self.state.lock().unwrap();
            if let Some(score) = state.players.get_mut(&id) {
                *score += points;
                state.total += points;
                true
            } else {
                false
            }
        };
        if !found {
            panic!("unknown player: {id}");
        }
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let missing = {
            let mut state = self.state.lock().unwrap();
            if !state.players.contains_key(&from) {
                Some(from)
            } else if !state.players.contains_key(&to) {
                Some(to)
            } else {
                if from != to {
                    *state.players.get_mut(&from).unwrap() -= points;
                    *state.players.get_mut(&to).unwrap() += points;
                }
                None
            }
        };
        if let Some(id) = missing {
            panic!("unknown player: {id}");
        }
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        let score = self.state.lock().unwrap().players.get(&id).copied();
        score.unwrap_or_else(|| panic!("unknown player: {id}"))
    }

    pub fn total(&self) -> i64 {
        self.state.lock().unwrap().total
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::{mpsc, Barrier};
    use std::thread;
    use std::time::Duration;

    fn run_with_timeout<F>(timeout: Duration, f: F)
    where
        F: FnOnce() + Send + 'static,
    {
        let (tx, rx) = mpsc::channel();
        thread::spawn(move || {
            f();
            let _ = tx.send(());
        });
        rx.recv_timeout(timeout)
            .expect("operation timed out (likely deadlock)");
    }

    #[test]
    fn concurrent_award_does_not_lose_updates() {
        let board = Board::new();
        board.join(1, 0);
        board.join(2, 0);

        let threads = 8;
        let iters = 5_000;
        let barrier = Arc::new(Barrier::new(threads));

        let mut handles = Vec::with_capacity(threads);
        for t in 0..threads {
            let b = board.clone();
            let bar = Arc::clone(&barrier);
            handles.push(thread::spawn(move || {
                bar.wait();
                for _ in 0..iters {
                    let target = if t % 2 == 0 { 1 } else { 2 };
                    b.award(target, 1);
                }
            }));
        }
        for h in handles {
            h.join().unwrap();
        }

        let per_player = (threads / 2) as i64 * iters as i64;
        assert_eq!(board.score(1), per_player);
        assert_eq!(board.score(2), per_player);
        assert_eq!(board.total(), per_player * 2);
    }

    #[test]
    fn self_transfer_does_not_deadlock_or_change_score() {
        run_with_timeout(Duration::from_secs(2), || {
            let board = Board::new();
            board.join(1, 42);
            board.transfer(1, 1, 10);
            assert_eq!(board.score(1), 42);
            assert_eq!(board.total(), 42);
        });
    }

    #[test]
    fn concurrent_opposite_transfers_do_not_deadlock() {
        run_with_timeout(Duration::from_secs(3), || {
            let board = Board::new();
            board.join(1, 1_000);
            board.join(2, 1_000);

            let barrier = Arc::new(Barrier::new(4));
            let mut handles = Vec::new();
            for t in 0..4 {
                let b = board.clone();
                let bar = Arc::clone(&barrier);
                handles.push(thread::spawn(move || {
                    bar.wait();
                    let (from, to) = if t % 2 == 0 { (1, 2) } else { (2, 1) };
                    for _ in 0..10_000 {
                        b.transfer(from, to, 1);
                    }
                }));
            }
            for h in handles {
                h.join().unwrap();
            }

            assert_eq!(board.score(1), 1_000);
            assert_eq!(board.score(2), 1_000);
            assert_eq!(board.total(), 2_000);
        });
    }

    #[test]
    fn concurrent_mixed_load_keeps_exact_scores_and_total() {
        run_with_timeout(Duration::from_secs(5), || {
            let board = Board::new();
            let players: u32 = 4;
            for p in 1..=players {
                board.join(p, 100);
            }

            let threads = 8;
            let iters = 2_000;
            let barrier = Arc::new(Barrier::new(threads));
            let mut handles = Vec::new();

            for t in 0..threads {
                let b = board.clone();
                let bar = Arc::clone(&barrier);
                handles.push(thread::spawn(move || {
                    bar.wait();
                    for i in 0..iters {
                        let a = ((t + i) % players as usize) as u32 + 1;
                        let c = ((t + i + 1) % players as usize) as u32 + 1;
                        b.award(a, 3);
                        b.transfer(a, c, 2);
                        b.transfer(a, a, 7);
                        let _ = b.score(a);
                        let _ = b.total();
                    }
                }));
            }
            for h in handles {
                h.join().unwrap();
            }

            let expected_total = players as i64 * 100 + (threads * iters) as i64 * 3;
            let sum_scores: i64 = (1..=players).map(|p| board.score(p)).sum();
            assert_eq!(sum_scores, expected_total);
            assert_eq!(board.total(), expected_total);
        });
    }

    #[test]
    fn rejoin_updates_total_consistently() {
        let board = Board::new();
        board.join(1, 10);
        board.join(2, 20);
        board.join(1, 5);
        assert_eq!(board.score(1), 5);
        assert_eq!(board.score(2), 20);
        assert_eq!(board.total(), 25);
    }

    #[test]
    fn unknown_player_panic_does_not_poison_board() {
        fn assert_traits<T: Clone + Default + Send + Sync>() {}
        assert_traits::<Board>();

        let board = Board::new();
        board.join(1, 10);

        let b = board.clone();
        assert!(std::panic::catch_unwind(move || b.score(99)).is_err());
        let b = board.clone();
        assert!(std::panic::catch_unwind(move || b.award(99, 5)).is_err());
        let b = board.clone();
        assert!(std::panic::catch_unwind(move || b.transfer(99, 1, 5)).is_err());

        assert_eq!(board.score(1), 10);
        assert_eq!(board.total(), 10);
    }
}
