"""H1 2026 financial close: parses ./finance books, validates data, writes ./result.json and ./h1_2026_pnl.csv."""
from __future__ import annotations

import csv
import json
import re
from collections import defaultdict
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FINANCE_DIR = ROOT / "finance"
MONTHS = ["2026-01", "2026-02", "2026-03", "2026-04", "2026-05", "2026-06"]
LAST_3_MONTHS = ["2026-04", "2026-05", "2026-06"]


def parse_brl(raw: str) -> Decimal:
    cleaned = raw.strip().replace("R$", "").strip().replace(".", "").replace(",", ".")
    return Decimal(cleaned)


def round2(value: Decimal) -> float:
    return float(value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def load_coa() -> dict[str, dict[str, str]]:
    with (FINANCE_DIR / "chart_of_accounts.csv").open(encoding="utf-8") as f:
        return {row["account"].strip(): row for row in csv.DictReader(f, delimiter=";")}


def load_cash_balances() -> list[tuple[str, Decimal]]:
    balances: list[tuple[str, Decimal]] = []
    pattern = re.compile(r"(\d{2}/\d{2}/\d{4}):\s*R\$\s*([\d.,]+)")
    text = (FINANCE_DIR / "cash_balance.txt").read_text(encoding="utf-8")
    for match in pattern.finditer(text):
        balances.append((match.group(1), parse_brl(match.group(2))))
    if not balances:
        raise ValueError("No cash balances parsed from finance/cash_balance.txt")
    return balances


def main() -> None:
    coa = load_coa()
    cash_balances = load_cash_balances()

    by_m_line: dict[str, dict[str, Decimal]] = defaultdict(lambda: defaultdict(Decimal))
    by_m_acc: dict[str, dict[str, Decimal]] = defaultdict(lambda: defaultdict(Decimal))
    seen: set[tuple[str, str, str, str]] = set()
    row_count = 0

    with (FINANCE_DIR / "ledger.csv").open(encoding="utf-8") as f:
        for idx, row in enumerate(csv.DictReader(f, delimiter=";"), start=2):
            row_count += 1
            key = (row["date"], row["account"], row["description"], row["amount"])
            if key in seen:
                raise ValueError(f"Duplicate ledger row at line {idx}: {key}")
            seen.add(key)

            day, month, year = row["date"].strip().split("/")
            ym = f"{year}-{month}"
            if ym not in MONTHS:
                raise ValueError(f"Unexpected month {ym} at line {idx}")

            acc = row["account"].strip()
            if acc not in coa:
                raise ValueError(f"Unmapped account {acc} at line {idx}")

            amt = parse_brl(row["amount"])
            if acc in ("3.1.01", "3.1.02", "6.1.01"):
                assert amt > 0, f"Expected positive amount for {acc} at line {idx}: {amt}"
            else:
                assert amt < 0, f"Expected negative amount for {acc} at line {idx}: {amt}"

            line = coa[acc]["pnl_line"].strip()
            by_m_line[ym][line] += amt
            by_m_acc[ym][acc] += amt

    # Compute monthly P&L
    monthly: dict[str, dict[str, Decimal]] = {}
    for m in MONTHS:
        rev = by_m_line[m]["revenue"]
        cogs = by_m_line[m]["cogs"]
        gp = rev + cogs
        gm_pct = (gp / rev) * Decimal("100")
        sm = by_m_line[m]["sales_marketing"]
        rnd = by_m_line[m]["rnd"]
        ga = by_m_line[m]["ga"]
        opex = sm + rnd + ga
        ebitda = gp + opex
        fin = by_m_line[m]["financial"]
        net_income = ebitda + fin
        monthly[m] = {
            "revenue": rev,
            "cogs": cogs,
            "gross_profit": gp,
            "gross_margin_pct": gm_pct,
            "sales_marketing": sm,
            "rnd": rnd,
            "ga": ga,
            "opex": opex,
            "ebitda": ebitda,
            "ebitda_margin_pct": (ebitda / rev) * Decimal("100"),
            "financial": fin,
            "net_income": net_income,
        }

    # Board burn & runway definition (finance/README.md)
    burn = sum(-monthly[m]["ebitda"] for m in LAST_3_MONTHS) / Decimal("3")
    latest_cash_date, latest_cash = cash_balances[-1]
    prev_cash_date, prev_cash = cash_balances[-2]
    cash_delta_jun = latest_cash - prev_cash
    runway_months = latest_cash / burn
    cash_burn_runway = latest_cash / (-cash_delta_jun)

    # Reconciliation check: sum of all ledger rows equals sum of monthly net incomes
    total_ledger = sum(sum(by_m_acc[m].values()) for m in MONTHS)
    total_net_income = sum(monthly[m]["net_income"] for m in MONTHS)
    assert total_ledger == total_net_income, f"Reconciliation mismatch: {total_ledger} != {total_net_income}"

    # Write result.json
    result = {
        "revenue": {m: round2(monthly[m]["revenue"]) for m in MONTHS},
        "gross_margin_pct": {m: round2(monthly[m]["gross_margin_pct"]) for m in MONTHS},
        "ebitda": {m: round2(monthly[m]["ebitda"]) for m in MONTHS},
        "burn": round2(burn),
        "runway_months": round2(runway_months),
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")

    # Write h1_2026_pnl.csv
    def sum_range(ms: list[str], key: str) -> Decimal:
        return sum(monthly[m][key] for m in ms)

    q1_m = MONTHS[:3]
    q2_m = MONTHS[3:]

    csv_rows: list[list[str]] = [
        ["Line Item"] + MONTHS + ["Q1 2026", "Q2 2026", "H1 2026"]
    ]

    def fmt_row(label: str, vals: list[Decimal], is_pct: bool = False) -> list[str]:
        if is_pct:
            return [label] + [f"{round2(v):.2f}%" for v in vals]
        return [label] + [f"{round2(v):.2f}" for v in vals]

    def add_acc(acc: str) -> None:
        name = f"{acc} {coa[acc]['name']}"
        ms = [by_m_acc[m][acc] for m in MONTHS]
        q1 = sum(by_m_acc[m][acc] for m in q1_m)
        q2 = sum(by_m_acc[m][acc] for m in q2_m)
        h1 = q1 + q2
        csv_rows.append(fmt_row(name, ms + [q1, q2, h1]))

    def add_metric(label: str, key: str) -> None:
        ms = [monthly[m][key] for m in MONTHS]
        q1 = sum_range(q1_m, key)
        q2 = sum_range(q2_m, key)
        h1 = q1 + q2
        csv_rows.append(fmt_row(label, ms + [q1, q2, h1]))

    def add_ratio(label: str, num_key: str, den_key: str) -> None:
        ms = [(monthly[m][num_key] / monthly[m][den_key]) * Decimal("100") for m in MONTHS]
        q1 = (sum_range(q1_m, num_key) / sum_range(q1_m, den_key)) * Decimal("100")
        q2 = (sum_range(q2_m, num_key) / sum_range(q2_m, den_key)) * Decimal("100")
        h1 = (sum_range(MONTHS, num_key) / sum_range(MONTHS, den_key)) * Decimal("100")
        csv_rows.append(fmt_row(label, ms + [q1, q2, h1], is_pct=True))

    for acc in ["3.1.01", "3.1.02", "3.1.09"]:
        add_acc(acc)
    add_metric("Net Revenue", "revenue")
    for acc in ["4.1.01", "4.1.02"]:
        add_acc(acc)
    add_metric("Total COGS", "cogs")
    add_metric("Gross Profit", "gross_profit")
    add_ratio("Gross Margin %", "gross_profit", "revenue")
    for acc in ["5.1.01", "5.1.02"]:
        add_acc(acc)
    add_metric("Sales & Marketing", "sales_marketing")
    for acc in ["5.2.01", "5.2.02"]:
        add_acc(acc)
    add_metric("R&D", "rnd")
    for acc in ["5.3.01", "5.3.02"]:
        add_acc(acc)
    add_metric("G&A", "ga")
    add_metric("Total OpEx", "opex")
    add_metric("EBITDA", "ebitda")
    add_ratio("EBITDA Margin %", "ebitda", "revenue")
    for acc in ["6.1.01", "6.1.02"]:
        add_acc(acc)
    add_metric("Net Financial Result", "financial")
    add_metric("Net Income", "net_income")

    with (ROOT / "h1_2026_pnl.csv").open("w", encoding="utf-8", newline="") as f:
        csv.writer(f).writerows(csv_rows)

    # Print full diagnostic summary
    print(f"Validated {row_count} ledger rows, 0 duplicates, 0 unmapped accounts.")
    print(f"Total ledger sum == Total H1 Net Income == {total_ledger:.2f}")
    print("\n--- result.json ---")
    print(json.dumps(result, indent=2))
    print("\n--- Account Summary ---")
    for r in csv_rows:
        print(" | ".join(r))

    q1_rev = sum_range(q1_m, "revenue")
    q2_rev = sum_range(q2_m, "revenue")
    h1_rev = q1_rev + q2_rev
    rev_jan = monthly["2026-01"]["revenue"]
    rev_jun = monthly["2026-06"]["revenue"]
    saas_jan = by_m_acc["2026-01"]["3.1.01"]
    saas_jun = by_m_acc["2026-06"]["3.1.01"]
    cmgr = ((float(rev_jun / rev_jan)) ** (1 / 5) - 1) * 100
    saas_cmgr = ((float(saas_jun / saas_jan)) ** (1 / 5) - 1) * 100
    print("\n--- Key CFO Metrics ---")
    print(f"Jan->Jun Net Revenue growth: {(rev_jun / rev_jan - 1) * 100:.2f}% (CMGR {cmgr:.2f}%)")
    print(f"Jan->Jun SaaS MRR growth: {(saas_jun / saas_jan - 1) * 100:.2f}% (CMGR {saas_cmgr:.2f}%), Jun ARR: {saas_jun * 12:.2f}")
    print(f"Q1->Q2 Net Revenue growth: {(q2_rev / q1_rev - 1) * 100:.2f}%")
    print(f"Q1 EBITDA: {sum_range(q1_m, 'ebitda'):.2f}, Q2 EBITDA: {sum_range(q2_m, 'ebitda'):.2f}, H1 EBITDA: {sum_range(MONTHS, 'ebitda'):.2f}")
    print(f"Board Burn (Apr-Jun avg -EBITDA): {burn:.6f}")
    print(f"Latest Cash ({latest_cash_date}): {latest_cash:.2f} | Prev ({prev_cash_date}): {prev_cash:.2f}")
    print(f"June Cash Delta: {cash_delta_jun:.2f} vs June Net Income {monthly['2026-06']['net_income']:.2f} (Gap: {cash_delta_jun - monthly['2026-06']['net_income']:.2f})")
    print(f"June Cash Delta vs June EBITDA {monthly['2026-06']['ebitda']:.2f} (Gap: {cash_delta_jun - monthly['2026-06']['ebitda']:.2f})")
    print(f"Board Runway: {runway_months:.6f} months | Stress-test Runway at June cash delta: {cash_burn_runway:.6f} months")

    # MoM revenue growth & gross margin ex-refunds
    print("\n--- MoM Growth & Ex-Refunds ---")
    prev_r = None
    for m in MONTHS:
        r = monthly[m]["revenue"]
        mom = "n/a" if prev_r is None else f"{(r / prev_r - 1) * 100:+.2f}%"
        ref = by_m_acc[m]["3.1.09"]
        gross_rev = r - ref
        gm_ex_ref = ((gross_rev + monthly[m]["cogs"]) / gross_rev) * Decimal("100")
        print(f"{m}: Rev={r:.2f} (MoM {mom}), GrossRev={gross_rev:.2f}, Refunds={ref:.2f}, GM={monthly[m]['gross_margin_pct']:.2f}% (ex-refund {gm_ex_ref:.2f}%), OpEx%={(-monthly[m]['opex']/r)*100:.1f}%, EBITDA={monthly[m]['ebitda']:.2f}")
        prev_r = r


if __name__ == "__main__":
    main()
