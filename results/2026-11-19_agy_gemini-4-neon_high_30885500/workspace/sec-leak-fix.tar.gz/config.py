"""Settings for the backup agent."""

from __future__ import annotations

import os

API_URL = "https://backup.example.invalid/v1/upload"
ARCHIVE_DIR = "archives"
TOKEN_ENV_VAR = "BACKUP_TOKEN"


def get_api_token() -> str:
    """Return the backup API token from the BACKUP_TOKEN environment variable."""
    token = os.environ.get(TOKEN_ENV_VAR, "")
    if not token:
        raise RuntimeError(
            f"Missing API token: set the {TOKEN_ENV_VAR} environment variable."
        )
    return token
