"""Backup agent: packs a folder chosen in the intranet web form and uploads it to the backup API."""

from __future__ import annotations

import logging
import tarfile
import urllib.request
from pathlib import Path

import config

log = logging.getLogger("backup_agent")


def archive_folder(folder: str, out_dir: str = config.ARCHIVE_DIR) -> Path:
    """Packs `folder` into `out_dir/<folder name>.tar.gz` and returns the archive path."""
    if not isinstance(folder, (str, Path)) or not str(folder).strip():
        raise ValueError(f"Expected a non-empty folder path, got {folder!r}")

    source = Path(folder)
    if not source.exists():
        raise FileNotFoundError(f"Folder does not exist: {folder!r}")
    if not source.is_dir():
        raise NotADirectoryError(f"Path is not a directory: {folder!r}")

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    archive_name = (
        source.name
        if source.name not in ("", ".", "..")
        else (source.resolve().name or "archive")
    )
    target = out / f"{archive_name}.tar.gz"

    source_resolved = source.resolve()
    target_resolved = target.resolve()
    try:
        rel_target = target_resolved.relative_to(source_resolved).as_posix()
        excluded_arcname = f"{archive_name}/{rel_target}"
    except ValueError:
        excluded_arcname = None

    with tarfile.open(target, "w:gz") as archive:
        archive.add(
            source,
            arcname=archive_name,
            filter=(
                (lambda info: None if info.name == excluded_arcname else info)
                if excluded_arcname
                else None
            ),
        )
    return target


def send_archive(path: Path, url: str, token: str) -> int:
    """Uploads one archive to the backup API and returns the HTTP status."""
    request = urllib.request.Request(
        url,
        data=path.read_bytes(),
        method="POST",
        headers={"Authorization": f"Bearer {token}"},
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.status


def upload(path: Path) -> int:
    token = config.get_api_token()
    log.info("uploading %s to %s", path, config.API_URL)
    return send_archive(path, config.API_URL, token)


def handle_form(form: dict[str, str]) -> int:
    """Web form handler: backs up the folder the user typed."""
    archive = archive_folder(form["folder"])
    log.info("archived %s", archive)
    return upload(archive)
