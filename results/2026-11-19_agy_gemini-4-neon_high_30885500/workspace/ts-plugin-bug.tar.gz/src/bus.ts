/**
 * Hook bus for harness plugins (OpenCode-style hooks). The README states the contract:
 * handlers run one after another in subscription order, emit resolves after all of them,
 * a handler error rejects emit, and unsubscribing during an emit does not stop the others.
 */

export type Handler<T> = (payload: T) => void | Promise<void>;

type Entry = {
  handler: Handler<unknown>;
};

export class HookBus {
  private handlers: Map<string, Entry[]> = new Map();

  /** Subscribes a handler to an event; returns the function that unsubscribes it. */
  on<T>(event: string, handler: Handler<T>): () => void {
    const list = this.handlers.get(event) ?? [];
    const entry: Entry = { handler: handler as Handler<unknown> };
    list.push(entry);
    this.handlers.set(event, list);
    return () => {
      const current = this.handlers.get(event);
      if (!current) {
        return;
      }
      const index = current.indexOf(entry);
      if (index >= 0) {
        current.splice(index, 1);
        if (current.length === 0) {
          this.handlers.delete(event);
        }
      }
    };
  }

  /** Runs the handlers of an event with the payload. */
  async emit<T>(event: string, payload: T): Promise<void> {
    const list = this.handlers.get(event);
    if (!list || list.length === 0) {
      return;
    }
    // Snapshot subscriptions at emit start so mid-emit changes only affect later emits.
    const snapshot = [...list];
    for (const entry of snapshot) {
      await entry.handler(payload);
    }
  }

  /** How many handlers an event has. */
  count(event: string): number {
    return (this.handlers.get(event) ?? []).length;
  }
}
