# Handoff: local-9b Q5 at 128k Context

## Goal
Fit and benchmark `local-9b` Q5 at 128k (`131072`) context with zero WDDM VRAM spill.

## Verified Results
- Benchmark: `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`
- Invalid baseline (do not use): default Q5 reported 7881 MiB VRAM and 37.8 t/s, but 7881 MiB is the WDDM ceiling with 1494 MiB spilled in Shared Usage.
- Final Q5 config (no spill): `--no-mmproj-offload` and `-ub 512` -> **7697 MiB VRAM**, **38.0 t/s** decode (median of 3).
- Other quants: `Q6_K` (7.03 GiB) does not fit at 128k (discarded). `Q4_K_M` fits at 7305 MiB / 40.4 t/s (fallback only).

## Applied
- Recipe applied in `scripts/start_server.ps1:165` (`local9` block) and `profiles/local/local-9b.json`.

## Pending
- Update the evals README: it still cites `check_vision.ps1`, which no longer exists.
