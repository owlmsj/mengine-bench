import json
import tempfile
import unittest
from pathlib import Path

from arena_server.config.loader import load_config
from arena_server.models.profile import Profile
from arena_server.persistence.store import load, save
from arena_server.services.match_service import finish_match


class MatchFlow(unittest.TestCase):
    def test_event_weekend_win_is_paid_and_persisted(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg_file = Path(tmp) / "live.json"
            cfg_file.write_text(json.dumps({"kill_bonus": 50, "event_multiplier": 1.25}))
            cfg = load_config(cfg_file, env={"ARENA_KILL_BONUS": "75"})
            profile = Profile("player1", level=12, credits=100, cosmetics=["neoplastic_skin"])
            finish_match(profile, won=True, kills=5, cfg=cfg)
            save(profile, Path(tmp) / "player1.json")
            reloaded = load(Path(tmp) / "player1.json")
            self.assertEqual(reloaded.credits, 100 + 1590)


if __name__ == "__main__":
    unittest.main()
