import unittest

from arena_server.config.loader import load_config
from arena_server.models.profile import Profile


class CoreUnits(unittest.TestCase):
    def test_defaults_load(self):
        self.assertEqual(load_config(env={})["win_base"], 900)

    def test_profile_defaults(self):
        self.assertEqual(Profile("x").credits, 0)


if __name__ == "__main__":
    unittest.main()
