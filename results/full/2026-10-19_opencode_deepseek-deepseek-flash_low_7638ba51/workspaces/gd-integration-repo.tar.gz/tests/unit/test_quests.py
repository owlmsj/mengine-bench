import unittest

from arena_server.quests import registry, rules


class QuestsTest(unittest.TestCase):
    def test_describe(self):
        self.assertIn("quests", registry.describe())
        self.assertGreater(rules.rules_limit(), 0)
