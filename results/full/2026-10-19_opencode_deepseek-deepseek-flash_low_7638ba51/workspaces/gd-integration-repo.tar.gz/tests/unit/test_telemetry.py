import unittest

from arena_server.telemetry import registry, rules


class TelemetryTest(unittest.TestCase):
    def test_describe(self):
        self.assertIn("telemetry", registry.describe())
        self.assertGreater(rules.rules_limit(), 0)
