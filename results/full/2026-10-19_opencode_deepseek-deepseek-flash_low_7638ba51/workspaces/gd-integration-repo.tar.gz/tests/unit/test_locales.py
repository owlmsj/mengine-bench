import unittest

from arena_server.locales import registry, rules


class LocalesTest(unittest.TestCase):
    def test_describe(self):
        self.assertIn("locales", registry.describe())
        self.assertGreater(rules.rules_limit(), 0)
