import unittest

from arena_server.store import registry, rules


class StoreTest(unittest.TestCase):
    def test_describe(self):
        self.assertIn("store", registry.describe())
        self.assertGreater(rules.rules_limit(), 0)
