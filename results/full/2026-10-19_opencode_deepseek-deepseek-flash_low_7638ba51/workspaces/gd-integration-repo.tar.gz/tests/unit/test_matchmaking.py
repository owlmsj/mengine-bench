import unittest

from arena_server.matchmaking import registry, rules


class MatchmakingTest(unittest.TestCase):
    def test_describe(self):
        self.assertIn("matchmaking", registry.describe())
        self.assertGreater(rules.rules_limit(), 0)
