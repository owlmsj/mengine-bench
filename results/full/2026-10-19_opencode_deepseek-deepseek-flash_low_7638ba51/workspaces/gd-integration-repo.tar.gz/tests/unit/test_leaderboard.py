import unittest

from arena_server.leaderboard import registry, rules


class LeaderboardTest(unittest.TestCase):
    def test_describe(self):
        self.assertIn("leaderboard", registry.describe())
        self.assertGreater(rules.rules_limit(), 0)
