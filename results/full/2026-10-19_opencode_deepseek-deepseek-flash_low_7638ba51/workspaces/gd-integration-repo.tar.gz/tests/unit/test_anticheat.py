import unittest

from arena_server.anticheat import registry, rules


class AnticheatTest(unittest.TestCase):
    def test_describe(self):
        self.assertIn("anticheat", registry.describe())
        self.assertGreater(rules.rules_limit(), 0)
