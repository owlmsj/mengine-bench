import unittest

from arena_server.notifications import registry, rules


class NotificationsTest(unittest.TestCase):
    def test_describe(self):
        self.assertIn("notifications", registry.describe())
        self.assertGreater(rules.rules_limit(), 0)
