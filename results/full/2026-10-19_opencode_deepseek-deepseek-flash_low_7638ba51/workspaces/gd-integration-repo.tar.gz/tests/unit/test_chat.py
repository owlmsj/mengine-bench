import unittest

from arena_server.chat import registry, rules


class ChatTest(unittest.TestCase):
    def test_describe(self):
        self.assertIn("chat", registry.describe())
        self.assertGreater(rules.rules_limit(), 0)
