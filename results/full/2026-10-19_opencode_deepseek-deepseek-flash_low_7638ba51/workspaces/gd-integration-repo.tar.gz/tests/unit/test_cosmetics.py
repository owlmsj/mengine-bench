import unittest

from arena_server.cosmetics import registry, rules


class CosmeticsTest(unittest.TestCase):
    def test_describe(self):
        self.assertIn("cosmetics", registry.describe())
        self.assertGreater(rules.rules_limit(), 0)
