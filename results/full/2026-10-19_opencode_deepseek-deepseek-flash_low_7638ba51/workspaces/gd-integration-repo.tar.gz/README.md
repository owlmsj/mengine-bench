# arena-server

Backend of Pixel Arena: config, economy, profiles, matchmaking and live-ops services. Tests: `python -m unittest discover -s tests -t .`
