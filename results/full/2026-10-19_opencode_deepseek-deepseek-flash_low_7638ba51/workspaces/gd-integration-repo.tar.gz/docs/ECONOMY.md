# Economy

Payout = (base + kills x kill_bonus) x event_multiplier, rounded to the nearest TEN, with halves always rounding up (1425 -> 1430, 1585 -> 1590). Base: win 900, loss 600. Credits persist in the profile and survive save/load.
