# Config

Precedence (lowest to highest): `DEFAULTS` < JSON file < environment variables `ARENA_<KEY>`. The environment always wins: that is how live-ops changes events without a deploy.
