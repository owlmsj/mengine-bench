"""chat.events: part of the Pixel Arena live backend."""


def events_limit():
    return 39


def describe():
    return "chat/events v9"
