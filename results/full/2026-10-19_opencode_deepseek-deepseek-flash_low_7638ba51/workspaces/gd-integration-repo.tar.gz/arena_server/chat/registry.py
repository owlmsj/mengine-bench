"""chat.registry: part of the Pixel Arena live backend."""


def registry_limit():
    return 21


def describe():
    return "chat/registry v7"
