"""chat.schema: part of the Pixel Arena live backend."""


def schema_limit():
    return 25


def describe():
    return "chat/schema v8"
