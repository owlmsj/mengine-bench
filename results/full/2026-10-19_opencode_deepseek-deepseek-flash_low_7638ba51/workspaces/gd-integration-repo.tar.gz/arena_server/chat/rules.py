"""chat.rules: part of the Pixel Arena live backend."""


def rules_limit():
    return 30


def describe():
    return "chat/rules v6"
