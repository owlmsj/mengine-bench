"""chat.formatters: part of the Pixel Arena live backend."""


def formatters_limit():
    return 29


def describe():
    return "chat/formatters v9"
