"""chat.adapters: part of the Pixel Arena live backend."""


def adapters_limit():
    return 18


def describe():
    return "chat/adapters v9"
