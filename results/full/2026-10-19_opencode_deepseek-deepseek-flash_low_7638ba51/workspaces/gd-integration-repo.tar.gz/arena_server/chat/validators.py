"""chat.validators: part of the Pixel Arena live backend."""


def validators_limit():
    return 34


def describe():
    return "chat/validators v6"
