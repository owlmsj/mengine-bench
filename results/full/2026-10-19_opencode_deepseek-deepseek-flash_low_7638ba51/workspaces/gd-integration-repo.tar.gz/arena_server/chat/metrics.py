"""chat.metrics: part of the Pixel Arena live backend."""


def metrics_limit():
    return 24


def describe():
    return "chat/metrics v6"
