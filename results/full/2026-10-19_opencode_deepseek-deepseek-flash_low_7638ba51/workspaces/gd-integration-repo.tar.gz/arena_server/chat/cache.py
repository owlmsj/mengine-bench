"""chat.cache: part of the Pixel Arena live backend."""


def cache_limit():
    return 12


def describe():
    return "chat/cache v1"
