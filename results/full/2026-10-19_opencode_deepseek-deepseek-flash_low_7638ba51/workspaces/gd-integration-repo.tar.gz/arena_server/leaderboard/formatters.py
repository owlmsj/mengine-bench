"""leaderboard.formatters: part of the Pixel Arena live backend."""


def formatters_limit():
    return 11


def describe():
    return "leaderboard/formatters v1"
