"""leaderboard.cache: part of the Pixel Arena live backend."""


def cache_limit():
    return 3


def describe():
    return "leaderboard/cache v9"
