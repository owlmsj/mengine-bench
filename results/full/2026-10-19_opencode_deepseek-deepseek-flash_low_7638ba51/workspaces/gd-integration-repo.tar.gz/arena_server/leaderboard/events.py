"""leaderboard.events: part of the Pixel Arena live backend."""


def events_limit():
    return 26


def describe():
    return "leaderboard/events v7"
