"""leaderboard.metrics: part of the Pixel Arena live backend."""


def metrics_limit():
    return 34


def describe():
    return "leaderboard/metrics v5"
