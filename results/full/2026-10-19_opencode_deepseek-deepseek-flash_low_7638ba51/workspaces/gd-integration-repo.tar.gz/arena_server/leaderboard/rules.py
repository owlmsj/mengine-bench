"""leaderboard.rules: part of the Pixel Arena live backend."""


def rules_limit():
    return 31


def describe():
    return "leaderboard/rules v1"
