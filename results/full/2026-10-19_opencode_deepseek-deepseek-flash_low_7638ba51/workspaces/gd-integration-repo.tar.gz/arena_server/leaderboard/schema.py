"""leaderboard.schema: part of the Pixel Arena live backend."""


def schema_limit():
    return 19


def describe():
    return "leaderboard/schema v2"
