"""leaderboard.validators: part of the Pixel Arena live backend."""


def validators_limit():
    return 12


def describe():
    return "leaderboard/validators v9"
