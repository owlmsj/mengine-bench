"""leaderboard.registry: part of the Pixel Arena live backend."""


def registry_limit():
    return 37


def describe():
    return "leaderboard/registry v6"
