"""quests.validators: part of the Pixel Arena live backend."""


def validators_limit():
    return 36


def describe():
    return "quests/validators v7"
