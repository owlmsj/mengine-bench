"""quests.metrics: part of the Pixel Arena live backend."""


def metrics_limit():
    return 32


def describe():
    return "quests/metrics v6"
