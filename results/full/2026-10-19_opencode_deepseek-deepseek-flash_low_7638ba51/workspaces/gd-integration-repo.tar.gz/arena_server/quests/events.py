"""quests.events: part of the Pixel Arena live backend."""


def events_limit():
    return 31


def describe():
    return "quests/events v9"
