"""quests.formatters: part of the Pixel Arena live backend."""


def formatters_limit():
    return 8


def describe():
    return "quests/formatters v9"
