"""quests.schema: part of the Pixel Arena live backend."""


def schema_limit():
    return 22


def describe():
    return "quests/schema v7"
