"""quests.adapters: part of the Pixel Arena live backend."""


def adapters_limit():
    return 36


def describe():
    return "quests/adapters v4"
