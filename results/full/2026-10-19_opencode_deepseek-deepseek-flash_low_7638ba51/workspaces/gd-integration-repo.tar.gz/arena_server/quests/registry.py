"""quests.registry: part of the Pixel Arena live backend."""


def registry_limit():
    return 7


def describe():
    return "quests/registry v5"
