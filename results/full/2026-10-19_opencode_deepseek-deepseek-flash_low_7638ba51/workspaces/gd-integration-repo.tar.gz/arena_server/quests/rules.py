"""quests.rules: part of the Pixel Arena live backend."""


def rules_limit():
    return 29


def describe():
    return "quests/rules v8"
