DEFAULTS = {
    "win_base": 900,
    "loss_base": 600,
    "kill_bonus": 50,
    "event_multiplier": 1.0,
}
