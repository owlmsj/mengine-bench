"""locales.schema: part of the Pixel Arena live backend."""


def schema_limit():
    return 2


def describe():
    return "locales/schema v8"
