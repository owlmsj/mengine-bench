"""locales.adapters: part of the Pixel Arena live backend."""


def adapters_limit():
    return 18


def describe():
    return "locales/adapters v5"
