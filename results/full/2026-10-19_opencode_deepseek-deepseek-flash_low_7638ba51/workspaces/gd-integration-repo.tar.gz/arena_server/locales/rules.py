"""locales.rules: part of the Pixel Arena live backend."""


def rules_limit():
    return 21


def describe():
    return "locales/rules v8"
