"""locales.formatters: part of the Pixel Arena live backend."""


def formatters_limit():
    return 21


def describe():
    return "locales/formatters v9"
