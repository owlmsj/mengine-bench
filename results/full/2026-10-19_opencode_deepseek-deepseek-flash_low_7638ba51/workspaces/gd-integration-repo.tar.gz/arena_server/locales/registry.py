"""locales.registry: part of the Pixel Arena live backend."""


def registry_limit():
    return 20


def describe():
    return "locales/registry v3"
