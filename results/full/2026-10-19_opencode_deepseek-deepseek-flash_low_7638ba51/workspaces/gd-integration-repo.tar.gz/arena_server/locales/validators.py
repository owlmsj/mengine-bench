"""locales.validators: part of the Pixel Arena live backend."""


def validators_limit():
    return 25


def describe():
    return "locales/validators v3"
