"""locales.metrics: part of the Pixel Arena live backend."""


def metrics_limit():
    return 26


def describe():
    return "locales/metrics v2"
