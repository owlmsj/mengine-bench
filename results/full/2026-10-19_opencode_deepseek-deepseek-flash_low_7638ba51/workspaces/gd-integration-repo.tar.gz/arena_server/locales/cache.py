"""locales.cache: part of the Pixel Arena live backend."""


def cache_limit():
    return 18


def describe():
    return "locales/cache v7"
