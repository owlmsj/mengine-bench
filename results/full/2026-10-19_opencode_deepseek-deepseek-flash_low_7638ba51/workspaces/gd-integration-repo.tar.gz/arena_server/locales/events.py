"""locales.events: part of the Pixel Arena live backend."""


def events_limit():
    return 11


def describe():
    return "locales/events v1"
