"""notifications.metrics: part of the Pixel Arena live backend."""


def metrics_limit():
    return 33


def describe():
    return "notifications/metrics v9"
