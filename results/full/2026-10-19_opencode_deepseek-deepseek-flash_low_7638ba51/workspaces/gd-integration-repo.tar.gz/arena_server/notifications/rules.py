"""notifications.rules: part of the Pixel Arena live backend."""


def rules_limit():
    return 27


def describe():
    return "notifications/rules v3"
