"""notifications.adapters: part of the Pixel Arena live backend."""


def adapters_limit():
    return 11


def describe():
    return "notifications/adapters v8"
