"""notifications.cache: part of the Pixel Arena live backend."""


def cache_limit():
    return 37


def describe():
    return "notifications/cache v3"
