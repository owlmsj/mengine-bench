"""notifications.schema: part of the Pixel Arena live backend."""


def schema_limit():
    return 3


def describe():
    return "notifications/schema v5"
