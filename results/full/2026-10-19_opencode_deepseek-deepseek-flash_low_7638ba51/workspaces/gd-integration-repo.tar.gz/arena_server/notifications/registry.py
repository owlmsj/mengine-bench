"""notifications.registry: part of the Pixel Arena live backend."""


def registry_limit():
    return 30


def describe():
    return "notifications/registry v4"
