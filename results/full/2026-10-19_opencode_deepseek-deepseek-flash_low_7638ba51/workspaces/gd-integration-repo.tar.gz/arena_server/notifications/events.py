"""notifications.events: part of the Pixel Arena live backend."""


def events_limit():
    return 26


def describe():
    return "notifications/events v4"
