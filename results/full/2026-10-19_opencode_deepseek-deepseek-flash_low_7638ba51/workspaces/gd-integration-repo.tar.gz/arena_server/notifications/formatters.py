"""notifications.formatters: part of the Pixel Arena live backend."""


def formatters_limit():
    return 2


def describe():
    return "notifications/formatters v1"
