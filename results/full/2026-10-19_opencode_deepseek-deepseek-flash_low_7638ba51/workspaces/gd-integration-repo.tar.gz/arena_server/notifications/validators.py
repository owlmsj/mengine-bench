"""notifications.validators: part of the Pixel Arena live backend."""


def validators_limit():
    return 22


def describe():
    return "notifications/validators v6"
