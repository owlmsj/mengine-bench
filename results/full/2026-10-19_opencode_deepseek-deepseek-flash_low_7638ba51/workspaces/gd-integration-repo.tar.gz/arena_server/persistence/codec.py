import json

from arena_server.models.profile import Profile


def encode(profile):
    return json.dumps({"name": profile.name, "level": profile.level,
                       "credits": profile.credits, "cosmetics": profile.cosmetics})


def decode(blob):
    data = json.loads(blob)
    return Profile(
        name=data["name"],
        level=data.get("level", 1),
        credits=data.get("credits", 0),
        cosmetics=data.get("cosmetics", []),
    )
