from pathlib import Path

from arena_server.persistence.codec import decode, encode


def save(profile, path):
    Path(path).write_text(encode(profile), encoding="utf-8")


def load(path):
    return decode(Path(path).read_text(encoding="utf-8"))
