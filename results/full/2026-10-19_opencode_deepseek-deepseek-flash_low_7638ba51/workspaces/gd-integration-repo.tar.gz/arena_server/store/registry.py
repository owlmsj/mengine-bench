"""store.registry: part of the Pixel Arena live backend."""


def registry_limit():
    return 12


def describe():
    return "store/registry v9"
