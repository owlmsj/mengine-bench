"""store.rules: part of the Pixel Arena live backend."""


def rules_limit():
    return 4


def describe():
    return "store/rules v5"
