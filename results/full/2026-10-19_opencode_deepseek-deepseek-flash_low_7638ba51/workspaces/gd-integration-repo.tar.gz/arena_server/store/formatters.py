"""store.formatters: part of the Pixel Arena live backend."""


def formatters_limit():
    return 26


def describe():
    return "store/formatters v8"
