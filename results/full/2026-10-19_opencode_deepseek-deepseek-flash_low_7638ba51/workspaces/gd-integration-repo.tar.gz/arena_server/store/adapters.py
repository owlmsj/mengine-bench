"""store.adapters: part of the Pixel Arena live backend."""


def adapters_limit():
    return 20


def describe():
    return "store/adapters v5"
