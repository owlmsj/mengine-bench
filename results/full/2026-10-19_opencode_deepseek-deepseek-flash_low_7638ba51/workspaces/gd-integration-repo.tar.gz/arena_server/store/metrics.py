"""store.metrics: part of the Pixel Arena live backend."""


def metrics_limit():
    return 5


def describe():
    return "store/metrics v6"
