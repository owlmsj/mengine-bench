"""store.events: part of the Pixel Arena live backend."""


def events_limit():
    return 38


def describe():
    return "store/events v6"
