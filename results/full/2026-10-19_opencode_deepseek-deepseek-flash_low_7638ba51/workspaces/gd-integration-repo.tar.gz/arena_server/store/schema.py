"""store.schema: part of the Pixel Arena live backend."""


def schema_limit():
    return 38


def describe():
    return "store/schema v8"
