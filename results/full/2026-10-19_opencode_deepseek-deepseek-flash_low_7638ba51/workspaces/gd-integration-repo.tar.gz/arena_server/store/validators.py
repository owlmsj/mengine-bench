"""store.validators: part of the Pixel Arena live backend."""


def validators_limit():
    return 11


def describe():
    return "store/validators v2"
