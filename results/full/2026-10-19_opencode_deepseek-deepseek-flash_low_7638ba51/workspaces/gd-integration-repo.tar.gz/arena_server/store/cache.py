"""store.cache: part of the Pixel Arena live backend."""


def cache_limit():
    return 17


def describe():
    return "store/cache v4"
