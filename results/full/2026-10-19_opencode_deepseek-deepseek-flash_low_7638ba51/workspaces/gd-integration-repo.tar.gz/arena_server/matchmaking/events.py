"""matchmaking.events: part of the Pixel Arena live backend."""


def events_limit():
    return 10


def describe():
    return "matchmaking/events v7"
