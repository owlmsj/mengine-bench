"""matchmaking.cache: part of the Pixel Arena live backend."""


def cache_limit():
    return 12


def describe():
    return "matchmaking/cache v4"
