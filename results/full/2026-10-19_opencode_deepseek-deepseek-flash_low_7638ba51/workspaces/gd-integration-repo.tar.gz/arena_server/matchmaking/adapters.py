"""matchmaking.adapters: part of the Pixel Arena live backend."""


def adapters_limit():
    return 22


def describe():
    return "matchmaking/adapters v7"
