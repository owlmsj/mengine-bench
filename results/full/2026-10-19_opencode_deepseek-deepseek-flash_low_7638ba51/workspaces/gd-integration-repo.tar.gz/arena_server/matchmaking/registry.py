"""matchmaking.registry: part of the Pixel Arena live backend."""


def registry_limit():
    return 23


def describe():
    return "matchmaking/registry v4"
