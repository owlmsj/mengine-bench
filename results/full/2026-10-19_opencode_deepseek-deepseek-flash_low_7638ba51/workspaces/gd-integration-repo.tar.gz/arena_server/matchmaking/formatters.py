"""matchmaking.formatters: part of the Pixel Arena live backend."""


def formatters_limit():
    return 13


def describe():
    return "matchmaking/formatters v6"
