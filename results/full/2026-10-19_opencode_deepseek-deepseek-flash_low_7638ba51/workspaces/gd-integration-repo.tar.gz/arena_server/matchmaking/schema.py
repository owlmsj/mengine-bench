"""matchmaking.schema: part of the Pixel Arena live backend."""


def schema_limit():
    return 27


def describe():
    return "matchmaking/schema v3"
