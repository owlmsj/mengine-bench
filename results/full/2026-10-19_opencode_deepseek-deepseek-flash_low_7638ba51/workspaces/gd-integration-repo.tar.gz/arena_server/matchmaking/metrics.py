"""matchmaking.metrics: part of the Pixel Arena live backend."""


def metrics_limit():
    return 37


def describe():
    return "matchmaking/metrics v2"
