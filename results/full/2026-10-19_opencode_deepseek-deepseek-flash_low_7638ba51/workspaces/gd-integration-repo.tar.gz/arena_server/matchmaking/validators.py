"""matchmaking.validators: part of the Pixel Arena live backend."""


def validators_limit():
    return 23


def describe():
    return "matchmaking/validators v4"
