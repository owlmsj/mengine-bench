"""matchmaking.rules: part of the Pixel Arena live backend."""


def rules_limit():
    return 21


def describe():
    return "matchmaking/rules v9"
