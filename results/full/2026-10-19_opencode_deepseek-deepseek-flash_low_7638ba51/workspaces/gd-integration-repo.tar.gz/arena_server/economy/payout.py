"""Match payout. Rules live in docs/ECONOMY.md."""

from decimal import Decimal, ROUND_HALF_UP


def _decimal(value):
    return Decimal(str(value))


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    raw = (_decimal(base) + _decimal(kills) * _decimal(cfg["kill_bonus"])) * _decimal(
        cfg["event_multiplier"]
    )
    # Nearest ten with halves always up; round() would use banker's rounding.
    # "1E+1" is the exponent-1 Decimal that makes quantize() round to tens.
    return int(raw.quantize(Decimal("1E+1"), rounding=ROUND_HALF_UP))
