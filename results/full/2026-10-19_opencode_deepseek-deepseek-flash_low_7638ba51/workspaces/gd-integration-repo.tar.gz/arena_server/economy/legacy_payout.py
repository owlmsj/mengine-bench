"""DEPRECATED since 0.12 - kept for old replays only; not used by the live economy."""


def legacy_payout(won, kills):
    return (1000 if won else 500) + kills * 40
