from dataclasses import dataclass, field


@dataclass
class Profile:
    name: str
    level: int = 1
    credits: int = 0
    cosmetics: list = field(default_factory=list)
