from arena_server.economy.payout import match_payout


def finish_match(profile, won, kills, cfg):
    profile.credits += match_payout(won, kills, cfg)
    return profile
