"""telemetry.cache: part of the Pixel Arena live backend."""


def cache_limit():
    return 10


def describe():
    return "telemetry/cache v8"
