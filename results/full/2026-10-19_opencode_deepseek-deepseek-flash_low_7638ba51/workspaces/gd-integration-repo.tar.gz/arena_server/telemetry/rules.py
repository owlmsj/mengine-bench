"""telemetry.rules: part of the Pixel Arena live backend."""


def rules_limit():
    return 25


def describe():
    return "telemetry/rules v4"
