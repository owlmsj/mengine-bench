"""telemetry.schema: part of the Pixel Arena live backend."""


def schema_limit():
    return 40


def describe():
    return "telemetry/schema v1"
