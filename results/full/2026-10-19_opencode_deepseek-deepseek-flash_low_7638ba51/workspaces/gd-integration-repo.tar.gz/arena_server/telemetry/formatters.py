"""telemetry.formatters: part of the Pixel Arena live backend."""


def formatters_limit():
    return 33


def describe():
    return "telemetry/formatters v5"
