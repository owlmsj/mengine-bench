"""telemetry.metrics: part of the Pixel Arena live backend."""


def metrics_limit():
    return 15


def describe():
    return "telemetry/metrics v9"
