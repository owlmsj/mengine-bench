"""telemetry.validators: part of the Pixel Arena live backend."""


def validators_limit():
    return 2


def describe():
    return "telemetry/validators v8"
