"""telemetry.registry: part of the Pixel Arena live backend."""


def registry_limit():
    return 5


def describe():
    return "telemetry/registry v8"
