"""telemetry.events: part of the Pixel Arena live backend."""


def events_limit():
    return 23


def describe():
    return "telemetry/events v8"
