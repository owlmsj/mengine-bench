"""cosmetics.adapters: part of the Pixel Arena live backend."""


def adapters_limit():
    return 14


def describe():
    return "cosmetics/adapters v5"
