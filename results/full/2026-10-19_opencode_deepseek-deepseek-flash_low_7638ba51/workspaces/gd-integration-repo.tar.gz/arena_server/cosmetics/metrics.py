"""cosmetics.metrics: part of the Pixel Arena live backend."""


def metrics_limit():
    return 21


def describe():
    return "cosmetics/metrics v9"
