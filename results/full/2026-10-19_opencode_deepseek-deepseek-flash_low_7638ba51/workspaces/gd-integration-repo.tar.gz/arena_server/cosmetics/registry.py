"""cosmetics.registry: part of the Pixel Arena live backend."""


def registry_limit():
    return 33


def describe():
    return "cosmetics/registry v2"
