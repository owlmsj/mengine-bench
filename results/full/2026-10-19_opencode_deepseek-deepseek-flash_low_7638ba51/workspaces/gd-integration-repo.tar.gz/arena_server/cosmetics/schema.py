"""cosmetics.schema: part of the Pixel Arena live backend."""


def schema_limit():
    return 28


def describe():
    return "cosmetics/schema v6"
