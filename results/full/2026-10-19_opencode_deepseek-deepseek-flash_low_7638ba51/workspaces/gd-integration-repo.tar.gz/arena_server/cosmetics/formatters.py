"""cosmetics.formatters: part of the Pixel Arena live backend."""


def formatters_limit():
    return 3


def describe():
    return "cosmetics/formatters v3"
