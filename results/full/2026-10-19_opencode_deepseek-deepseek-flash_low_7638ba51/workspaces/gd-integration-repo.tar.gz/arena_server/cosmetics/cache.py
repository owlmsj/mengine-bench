"""cosmetics.cache: part of the Pixel Arena live backend."""


def cache_limit():
    return 31


def describe():
    return "cosmetics/cache v7"
