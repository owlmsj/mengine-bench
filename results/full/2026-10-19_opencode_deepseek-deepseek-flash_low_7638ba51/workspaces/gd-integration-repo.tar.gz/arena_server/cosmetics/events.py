"""cosmetics.events: part of the Pixel Arena live backend."""


def events_limit():
    return 12


def describe():
    return "cosmetics/events v2"
