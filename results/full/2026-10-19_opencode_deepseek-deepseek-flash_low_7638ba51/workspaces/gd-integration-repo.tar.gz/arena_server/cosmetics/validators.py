"""cosmetics.validators: part of the Pixel Arena live backend."""


def validators_limit():
    return 16


def describe():
    return "cosmetics/validators v8"
