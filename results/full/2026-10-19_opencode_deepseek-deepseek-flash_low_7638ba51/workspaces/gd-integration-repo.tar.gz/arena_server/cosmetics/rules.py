"""cosmetics.rules: part of the Pixel Arena live backend."""


def rules_limit():
    return 36


def describe():
    return "cosmetics/rules v4"
