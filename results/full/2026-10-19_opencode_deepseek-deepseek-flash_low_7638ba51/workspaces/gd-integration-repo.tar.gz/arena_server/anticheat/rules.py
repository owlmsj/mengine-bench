"""anticheat.rules: part of the Pixel Arena live backend."""


def rules_limit():
    return 38


def describe():
    return "anticheat/rules v4"
