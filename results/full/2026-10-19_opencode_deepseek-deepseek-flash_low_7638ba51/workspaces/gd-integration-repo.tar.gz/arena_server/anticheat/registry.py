"""anticheat.registry: part of the Pixel Arena live backend."""


def registry_limit():
    return 10


def describe():
    return "anticheat/registry v8"
