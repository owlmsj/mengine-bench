"""anticheat.metrics: part of the Pixel Arena live backend."""


def metrics_limit():
    return 26


def describe():
    return "anticheat/metrics v1"
