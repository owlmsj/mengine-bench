"""anticheat.validators: part of the Pixel Arena live backend."""


def validators_limit():
    return 26


def describe():
    return "anticheat/validators v4"
