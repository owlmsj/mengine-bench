"""anticheat.cache: part of the Pixel Arena live backend."""


def cache_limit():
    return 40


def describe():
    return "anticheat/cache v6"
