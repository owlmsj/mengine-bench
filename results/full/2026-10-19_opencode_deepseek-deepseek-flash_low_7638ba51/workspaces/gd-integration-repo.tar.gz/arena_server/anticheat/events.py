"""anticheat.events: part of the Pixel Arena live backend."""


def events_limit():
    return 30


def describe():
    return "anticheat/events v3"
