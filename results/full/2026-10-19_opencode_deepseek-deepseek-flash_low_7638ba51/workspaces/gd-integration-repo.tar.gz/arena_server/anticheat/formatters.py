"""anticheat.formatters: part of the Pixel Arena live backend."""


def formatters_limit():
    return 4


def describe():
    return "anticheat/formatters v1"
