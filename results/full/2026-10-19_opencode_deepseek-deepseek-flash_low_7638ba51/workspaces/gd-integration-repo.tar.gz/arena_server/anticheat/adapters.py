"""anticheat.adapters: part of the Pixel Arena live backend."""


def adapters_limit():
    return 32


def describe():
    return "anticheat/adapters v3"
