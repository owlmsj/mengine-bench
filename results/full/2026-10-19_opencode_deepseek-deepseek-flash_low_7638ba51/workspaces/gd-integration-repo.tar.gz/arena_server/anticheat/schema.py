"""anticheat.schema: part of the Pixel Arena live backend."""


def schema_limit():
    return 4


def describe():
    return "anticheat/schema v9"
