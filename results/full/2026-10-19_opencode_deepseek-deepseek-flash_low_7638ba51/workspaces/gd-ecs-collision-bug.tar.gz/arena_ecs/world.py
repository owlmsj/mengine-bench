class World:
    def __init__(self):
        self.entities = {}
        self._next = 1

    def spawn(self, **components):
        eid = self._next
        self._next += 1
        self.entities[eid] = dict(components)
        return eid

    def query(self, *names):
        for eid, comps in self.entities.items():
            if all(name in comps for name in names):
                yield eid, comps
