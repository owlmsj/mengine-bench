def overlaps(pa, ba, pb, bb):
    """Axis-aligned boxes anchored at their top-left corner; touching edges do not collide."""
    return (
        pa.x < pb.x + bb.w
        and pa.x + ba.w > pb.x
        and pa.y < pb.y + bb.h
        and pa.y + ba.h > pb.y
    )


def collision_system(world):
    hits = []
    bodies = list(world.query("pos", "box"))
    for i, (ea, ca) in enumerate(bodies):
        for eb, cb in bodies[i + 1:]:
            if overlaps(ca["pos"], ca["box"], cb["pos"], cb["box"]):
                hits.append((ea, eb))
    return hits
