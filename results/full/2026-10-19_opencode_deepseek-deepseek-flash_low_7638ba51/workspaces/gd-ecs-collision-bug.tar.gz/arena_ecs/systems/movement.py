def movement_system(world, dt):
    for _, comps in world.query("pos", "vel"):
        pos, vel = comps["pos"], comps["vel"]
        pos.x += vel.x * dt
        pos.y += vel.y * dt
