import unittest

from arena_ecs.components import Box, Position, Velocity
from arena_ecs.systems.collision import collision_system
from arena_ecs.systems.movement import movement_system
from arena_ecs.world import World


class SystemsTest(unittest.TestCase):
    def test_movement_uses_each_axis(self):
        world = World()
        eid = world.spawn(pos=Position(0, 0), vel=Velocity(2, -1))
        movement_system(world, 0.5)
        pos = world.entities[eid]["pos"]
        self.assertEqual((pos.x, pos.y), (1.0, -0.5))

    def test_vertical_gap_is_not_a_hit(self):
        world = World()
        world.spawn(pos=Position(0, 0), box=Box(1, 1))
        world.spawn(pos=Position(0, 5), box=Box(1, 1))
        self.assertEqual(collision_system(world), [])


if __name__ == "__main__":
    unittest.main()
