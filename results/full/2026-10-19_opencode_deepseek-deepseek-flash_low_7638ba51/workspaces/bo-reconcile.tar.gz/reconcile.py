import csv, json, re
from collections import defaultdict
from decimal import Decimal

BASE = "backoffice"

invoices = {}
with open(f"{BASE}/invoices.csv", newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = Decimal(row["amount"])

# Memo formats: "inv1007", "INV-1015", "invoice 1023", "TED invoice 1039".
# Only a token with 4 digits after inv/invoice counts; everything else is ignored.
INV_RE = re.compile(r"\binv(?:oice)?\s*[-_ ]?\s*(\d{4})\b", re.IGNORECASE)

payments = defaultdict(list)
with open(f"{BASE}/bank_statement_june.csv", newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        match = INV_RE.search(row["memo"])
        if not match:
            continue
        inv_id = f"INV-{match.group(1)}"
        if inv_id not in invoices:      # unknown id referenced: not an invoice we hold
            continue
        payments[inv_id].append(Decimal(row["amount"]))

unpaid = sorted(i for i in invoices if i not in payments)
duplicated = sorted(i for i, pays in payments.items() if len(pays) > 1)
# A duplicate is reported once, under "duplicated": each of its payments equals
# the invoice, so the surplus is the duplication, not a value mismatch.
mismatched = [
    {"id": i, "invoiced": str(invoices[i]), "paid": str(sum(payments[i]))}
    for i in sorted(payments)
    if len(payments[i]) == 1 and payments[i][0] != invoices[i]
]

result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
with open("reconciliation.json", "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
    f.write("\n")

print(json.dumps(result, ensure_ascii=False, indent=2))
print("invoices:", len(invoices), "payment rows identified:", sum(len(v) for v in payments.values()))
