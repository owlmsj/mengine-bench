# Term sheet - Series A (legal summary)

- Pre-money: BRL 40,000,000. New money: BRL 8,000,000 from the lead investor.
- Pre-round capitalization (C0) = all rows of cap_table.csv (shares, outstanding options and unallocated pool).
- Pool: after the round, the UNALLOCATED pool must be 12% of the post-round fully diluted. The pool
  top-up goes into the pre-money (it dilutes only current holders and the SAFEs).
- SAFEs convert at the lower of: valuation_cap / C0, and round price x (1 - discount).
- Round price = pre-money / (C0 + pool top-up + SAFE shares).
- Lead investor shares = new money / round price.
