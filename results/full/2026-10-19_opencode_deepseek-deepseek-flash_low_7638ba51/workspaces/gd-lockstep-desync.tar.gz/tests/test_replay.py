import os
import subprocess
import sys
import unittest

from lockstep.sim import simulate

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class ReplayTest(unittest.TestCase):
    def test_same_seed_same_hash(self):
        self.assertEqual(simulate(7, 40), simulate(7, 40))

    def test_same_seed_same_hash_across_processes(self):
        # Set iteration order and the module-global RNG depend on process state,
        # so in-process comparison alone cannot catch a desync. Vary
        # PYTHONHASHSEED to force distinct hash randomization per process.
        digests = set()
        for hash_seed in ("0", "1", "12345", "random"):
            env = dict(os.environ, PYTHONHASHSEED=hash_seed)
            out = subprocess.run(
                [sys.executable, "-c", "from lockstep.sim import simulate; print(simulate(7, 40))"],
                cwd=REPO_ROOT,
                env=env,
                capture_output=True,
                text=True,
                check=True,
            )
            digests.add(out.stdout.strip())
        self.assertEqual(len(digests), 1, digests)


if __name__ == "__main__":
    unittest.main()
