"""Pixel Arena level pathing: bots walk a tile map painted in primary colors."""

import heapq

Cell = tuple[int, int]  # (row, col)

_ENTER_COST = {".": 1, "D": 3, "S": 1, "G": 1}


def find_path(grid: list[str]) -> list[Cell] | None:
    """Cheapest 4-neighbour path from 'S' to 'G', both inclusive.

    '.' floor costs 1 to enter, 'D' door costs 3, '#' is a wall, 'S'/'G' cost 1.
    Return None when G is unreachable.
    """
    start = goal = None
    for row, line in enumerate(grid):
        for col, tile in enumerate(line):
            if tile == "S":
                start = (row, col)
            elif tile == "G":
                goal = (row, col)
    if start is None or goal is None:
        return None
    if start == goal:
        return [start]

    def heuristic(cell: Cell) -> int:
        # Manhattan is admissible: every enterable tile costs at least 1.
        return abs(cell[0] - goal[0]) + abs(cell[1] - goal[1])

    rows, cols = len(grid), len(grid[0])
    best = {start: 0}
    came_from: dict[Cell, Cell] = {}
    counter = 0
    frontier: list[tuple[int, int, Cell]] = [(heuristic(start), counter, start)]

    while frontier:
        _, _, current = heapq.heappop(frontier)
        if current == goal:
            path = [current]
            while current != start:
                current = came_from[current]
                path.append(current)
            path.reverse()
            return path
        current_cost = best[current]
        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            nxt = (current[0] + dr, current[1] + dc)
            if not (0 <= nxt[0] < rows and 0 <= nxt[1] < cols):
                continue
            tile = grid[nxt[0]][nxt[1]]
            if tile == "#":
                continue
            tentative = current_cost + _ENTER_COST[tile]
            if tentative < best.get(nxt, float("inf")):
                best[nxt] = tentative
                came_from[nxt] = current
                counter += 1
                heapq.heappush(frontier, (tentative + heuristic(nxt), counter, nxt))
    return None
