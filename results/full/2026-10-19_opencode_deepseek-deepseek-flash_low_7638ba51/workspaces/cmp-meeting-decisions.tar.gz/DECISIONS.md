# Ops decisions - 2026-06-30

Source: `meetings/2026-06-30-ops.md`. Line refs point there. Everything below is settled; proposals that lost are omitted.

## 1. Pro plan price
- Decided: Pro goes to BRL 55/month from Aug 1, 2026.
- Current payers stay at BRL 49 until Jan 31, 2027 (grandfathering).
- Context: list price was BRL 49, low churn, rising CAC; competitor range BRL 55-69 (L19); small studios feared BRL 59 (L31).
- Ref: L89.

## 2. Hiring
- Decided: hiring freeze, one exception: 1 SRE role.
- Owner: Alice. Must be opened by Jul 15, 2026.
- Other proposed roles (backend dev, designer) not opened.
- Designer: deferred to Q4 2026, only if revenue exceeds BRL 300k/month (Carla, L447).
- Ref: L173, L447.

## 3. Cloud cost
- Measured: BRL 71k spent in June 2026, driven by a test GPU left running (L245).
- Decided: cap of BRL 60k/month; billing alert at 80% of cap (= BRL 48k).
- Owner: Bruno.
- Ref: L357.

## 4. Billing
- Decided: migrate invoicing from manual bank slips to Stripe.
- Owner: Bruno, done by Jul 31, 2026.
- Carla validates the first month's reconciliation.
- Ref: L421.

## Open / to confirm
- SRE role opening (Alice, Jul 15).
- Stripe cutover (Bruno, Jul 31) + first reconciliation (Carla, no date set).
- Designer decision gated on BRL 300k/month revenue; re-check in Q4.
- No source line records a date for the revenue check or the reconciliation.
