# HANDOFF — local-9b Q5 @ 128k ctx

**State:** done. 128k context now runs with no VRAM spill. Q5_K_M is the choice.

**Final measured numbers:**
`pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024` with `--no-mmproj-offload -ub 512`:
- decode **38.0 t/s** (median of 3)
- VRAM **7697 MiB**, spill gone

**Superseded — do not quote:** same command without those flags = 37.8 t/s, 7881 MiB. 7881 MiB is the WDDM ceiling and Shared Usage showed **1494 MiB spilled**, so that number is invalid.

**Decisions:**
- Add `--no-mmproj-offload` and `-ub 512`; that is what removes the spill.
- Q6_K (7.03 GiB) does not fit at 128k — discarded.
- Q4_K_M fits (7305 MiB, 40.4 t/s) — fallback only, not the default.

**Changes in place:**
- `scripts/start_server.ps1:165` (local9 block)
- `profiles/local/local-9b.json`

**Pending:**
- evals README still cites `check_vision.ps1`; that file no longer exists.
- Review the scratchpad temp file names (noted, not started).

**Owners/deadlines:** none assigned in the transcript.
