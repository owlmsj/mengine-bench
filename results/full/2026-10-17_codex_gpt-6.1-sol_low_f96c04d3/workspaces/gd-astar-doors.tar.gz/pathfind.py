"""Pixel Arena level pathing: bots walk a tile map painted in primary colors."""

from heapq import heappop, heappush

Cell = tuple[int, int]  # (row, col)


def find_path(grid: list[str]) -> list[Cell] | None:
    """Cheapest 4-neighbour path from 'S' to 'G', both inclusive.

    '.' floor costs 1 to enter, 'D' door costs 3, '#' is a wall, 'S'/'G' cost 1.
    Return None when G is unreachable.
    """
    start = next(((r, c) for r, row in enumerate(grid)
                  for c, tile in enumerate(row) if tile == "S"), None)
    if start is None:
        return None

    frontier: list[tuple[int, Cell]] = [(0, start)]
    costs: dict[Cell, int] = {start: 0}
    previous: dict[Cell, Cell] = {}
    while frontier:
        cost, cell = heappop(frontier)
        if cost != costs[cell]:
            continue
        r, c = cell
        if grid[r][c] == "G":
            path = [cell]
            while cell in previous:
                cell = previous[cell]
                path.append(cell)
            return path[::-1]
        for nr, nc in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
            if not (0 <= nr < len(grid) and 0 <= nc < len(grid[nr])):
                continue
            tile = grid[nr][nc]
            if tile == "#":
                continue
            candidate = cost + (3 if tile == "D" else 1)
            neighbour = (nr, nc)
            if neighbour in costs and candidate >= costs[neighbour]:
                continue
            costs[neighbour] = candidate
            previous[neighbour] = (r, c)
            heappush(frontier, (candidate, neighbour))
    return None
