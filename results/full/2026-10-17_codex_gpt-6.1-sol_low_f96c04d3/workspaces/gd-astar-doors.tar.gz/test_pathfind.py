import unittest

from pathfind import find_path


class VisibleTest(unittest.TestCase):
    def test_longer_route_avoids_expensive_doors(self):
        grid = ["SDDG", "...."]
        path = find_path(grid)
        self.assertIsNotNone(path)
        self.assertEqual(path[0], (0, 0))
        self.assertEqual(path[-1], (0, 3))
        self.assertEqual(sum(3 if grid[r][c] == "D" else 1 for r, c in path[1:]), 5)

    def test_unreachable_goal(self):
        self.assertIsNone(find_path(["S#G"]))

    def test_straight_corridor(self):
        self.assertEqual(find_path(["S..G"]), [(0, 0), (0, 1), (0, 2), (0, 3)])


if __name__ == "__main__":
    unittest.main()
