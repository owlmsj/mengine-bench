import json
import tempfile
import unittest
from pathlib import Path

from arena_server.config.loader import load_config
from arena_server.economy.payout import match_payout
from arena_server.models.profile import Profile
from arena_server.persistence.codec import decode, encode


class EconomyRegressions(unittest.TestCase):
    def test_environment_overrides_file_and_file_overrides_defaults(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            config_path = Path(tmp) / "live.json"
            config_path.write_text(json.dumps({"kill_bonus": 60, "event_multiplier": 1.25}), encoding="utf-8")
            cfg = load_config(config_path, env={"ARENA_KILL_BONUS": "75", "ARENA_EVENT_MULTIPLIER": "1.5"})
            self.assertEqual(cfg["kill_bonus"], 75)
            self.assertEqual(cfg["event_multiplier"], 1.5)
            self.assertEqual(cfg["win_base"], 900)
            self.assertEqual(load_config(config_path, env={})["kill_bonus"], 60)

    def test_payout_rounds_to_tens_with_halves_up(self) -> None:
        for raw, expected in [(1424, 1420), (1425, 1430), (1426, 1430), (1585, 1590), (1595, 1600)]:
            with self.subTest(raw=raw):
                cfg = {"win_base": raw, "loss_base": raw, "kill_bonus": 0, "event_multiplier": 1.0}
                self.assertEqual(match_payout(True, 0, cfg), expected)
                self.assertEqual(match_payout(False, 0, cfg), expected)

    def test_profile_round_trip_preserves_every_field(self) -> None:
        profile = Profile("player1", level=12, credits=1690, cosmetics=["neoplastic_skin"])
        self.assertEqual(decode(encode(profile)), profile)

    def test_older_profile_without_credits_defaults_to_zero(self) -> None:
        self.assertEqual(decode('{"name": "older"}'), Profile("older"))
