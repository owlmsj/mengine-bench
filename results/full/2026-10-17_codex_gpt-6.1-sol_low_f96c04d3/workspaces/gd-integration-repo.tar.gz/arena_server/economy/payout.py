"""Match payout. Rules live in docs/ECONOMY.md."""

from collections.abc import Mapping
from decimal import Decimal, ROUND_HALF_UP


def match_payout(won: bool, kills: int, cfg: Mapping[str, int | float]) -> int:
    base = cfg["win_base"] if won else cfg["loss_base"]
    raw = (Decimal(str(base)) + kills * Decimal(str(cfg["kill_bonus"]))) * Decimal(str(cfg["event_multiplier"]))
    return int(raw.quantize(Decimal("1E1"), rounding=ROUND_HALF_UP))
