# Neoplastic map (current)

Red/blue/yellow grid; black lines are cover walls.

| Mode | Max players | Round time |
|---|---|---|
| Casual | 16 | 10 min |
| Ranked | 10 | 2 min 30 s |
