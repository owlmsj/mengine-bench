# Neoplastic v1 (DEPRECATED - see maps/neoplastic.md)

Ranked: 12 players. Casual: 20 players. Values from before the April rework.
