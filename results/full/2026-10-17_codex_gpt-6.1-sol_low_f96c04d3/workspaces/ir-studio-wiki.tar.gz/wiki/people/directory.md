# Directory


Alice Sato (producer), Bruno Costa (lead eng), Carla Mendes (QA lead).

Any change here needs a PR reviewed by two people.

Checklist reviewed by the area lead; mismatches go to the backlog.

History before 0.12 was archived in the old wiki.

History before 0.12 was archived in the old wiki.

History before 0.12 was archived in the old wiki.

Performance numbers measured on the build farm, not on a dev machine.

History before 0.12 was archived in the old wiki.

History before 0.12 was archived in the old wiki.

Performance numbers measured on the build farm, not on a dev machine.
