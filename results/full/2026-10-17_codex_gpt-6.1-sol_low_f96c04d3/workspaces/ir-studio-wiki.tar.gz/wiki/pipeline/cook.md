# Cook


Incremental cook per platform; pak chunking per map.

Checklist reviewed by the area lead; mismatches go to the backlog.

History before 0.12 was archived in the old wiki.

Checklist reviewed by the area lead; mismatches go to the backlog.

Any change here needs a PR reviewed by two people.

History before 0.12 was archived in the old wiki.

Updated after the sprint retro; see the #eng channel for context.

Updated after the sprint retro; see the #eng channel for context.

Updated after the sprint retro; see the #eng channel for context.
