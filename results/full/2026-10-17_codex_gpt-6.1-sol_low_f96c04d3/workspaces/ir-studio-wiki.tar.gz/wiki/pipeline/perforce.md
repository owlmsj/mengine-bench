# Perforce


mainline/release streams; shelve before cherry-pick.

Any change here needs a PR reviewed by two people.

Any change here needs a PR reviewed by two people.

Performance numbers measured on the build farm, not on a dev machine.

Any change here needs a PR reviewed by two people.

Updated after the sprint retro; see the #eng channel for context.

Updated after the sprint retro; see the #eng channel for context.

Updated after the sprint retro; see the #eng channel for context.

Updated after the sprint retro; see the #eng channel for context.

Checklist reviewed by the area lead; mismatches go to the backlog.
