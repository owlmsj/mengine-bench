# Build farm


Horde agents with UE 5.8, shared DDC cache, 4 Win64 agents.

Updated after the sprint retro; see the #eng channel for context.

Updated after the sprint retro; see the #eng channel for context.

Any change here needs a PR reviewed by two people.

Performance numbers measured on the build farm, not on a dev machine.

Any change here needs a PR reviewed by two people.

Any change here needs a PR reviewed by two people.

History before 0.12 was archived in the old wiki.

Updated after the sprint retro; see the #eng channel for context.

Any change here needs a PR reviewed by two people.

History before 0.12 was archived in the old wiki.

Any change here needs a PR reviewed by two people.

Updated after the sprint retro; see the #eng channel for context.
