# On-call


Weekly rotation; pager for S1.

Any change here needs a PR reviewed by two people.

Checklist reviewed by the area lead; mismatches go to the backlog.

Checklist reviewed by the area lead; mismatches go to the backlog.

History before 0.12 was archived in the old wiki.

Checklist reviewed by the area lead; mismatches go to the backlog.

Performance numbers measured on the build farm, not on a dev machine.
