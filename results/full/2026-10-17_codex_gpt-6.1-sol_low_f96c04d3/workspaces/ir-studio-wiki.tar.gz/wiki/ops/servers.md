# Servers


SA-East and US-East regions; tick 64.

Performance numbers measured on the build farm, not on a dev machine.

Any change here needs a PR reviewed by two people.

Performance numbers measured on the build farm, not on a dev machine.

Any change here needs a PR reviewed by two people.

Updated after the sprint retro; see the #eng channel for context.

History before 0.12 was archived in the old wiki.

Performance numbers measured on the build farm, not on a dev machine.

Any change here needs a PR reviewed by two people.

History before 0.12 was archived in the old wiki.

History before 0.12 was archived in the old wiki.
