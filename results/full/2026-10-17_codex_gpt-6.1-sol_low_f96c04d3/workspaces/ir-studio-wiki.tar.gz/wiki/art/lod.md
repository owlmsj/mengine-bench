# LODs


Nanite for environments, manual LODs for first-person weapons.

Performance numbers measured on the build farm, not on a dev machine.

Updated after the sprint retro; see the #eng channel for context.

Checklist reviewed by the area lead; mismatches go to the backlog.

Checklist reviewed by the area lead; mismatches go to the backlog.

History before 0.12 was archived in the old wiki.

Any change here needs a PR reviewed by two people.

Any change here needs a PR reviewed by two people.

Performance numbers measured on the build farm, not on a dev machine.
