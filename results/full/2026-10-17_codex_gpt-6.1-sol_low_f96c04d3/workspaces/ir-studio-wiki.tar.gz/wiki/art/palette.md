# Palette


Red #D40920, blue #1356A2, yellow #F7D842, black #000000.

Performance numbers measured on the build farm, not on a dev machine.

Performance numbers measured on the build farm, not on a dev machine.

Performance numbers measured on the build farm, not on a dev machine.

Any change here needs a PR reviewed by two people.

Any change here needs a PR reviewed by two people.

Any change here needs a PR reviewed by two people.

History before 0.12 was archived in the old wiki.

Any change here needs a PR reviewed by two people.
