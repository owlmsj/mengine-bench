# Weapons


SMG, rifle, sniper, shotgun, LMG; recoil by curve.

Any change here needs a PR reviewed by two people.

Any change here needs a PR reviewed by two people.

Updated after the sprint retro; see the #eng channel for context.

Performance numbers measured on the build farm, not on a dev machine.

Checklist reviewed by the area lead; mismatches go to the backlog.

History before 0.12 was archived in the old wiki.

Any change here needs a PR reviewed by two people.
