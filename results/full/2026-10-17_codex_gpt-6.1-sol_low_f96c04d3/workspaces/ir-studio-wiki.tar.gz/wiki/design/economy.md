# Economy


Credits per round: 900 win, 600 loss.

Updated after the sprint retro; see the #eng channel for context.

Any change here needs a PR reviewed by two people.

Performance numbers measured on the build farm, not on a dev machine.

Updated after the sprint retro; see the #eng channel for context.

Performance numbers measured on the build farm, not on a dev machine.

Updated after the sprint retro; see the #eng channel for context.

Performance numbers measured on the build farm, not on a dev machine.

Any change here needs a PR reviewed by two people.

History before 0.12 was archived in the old wiki.
