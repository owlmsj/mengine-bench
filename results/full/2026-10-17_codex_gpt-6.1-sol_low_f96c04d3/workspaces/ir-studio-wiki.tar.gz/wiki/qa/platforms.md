# Platforms


Win64 and Linux server; Steam Deck under evaluation.

Any change here needs a PR reviewed by two people.

Performance numbers measured on the build farm, not on a dev machine.

Updated after the sprint retro; see the #eng channel for context.

Updated after the sprint retro; see the #eng channel for context.

Checklist reviewed by the area lead; mismatches go to the backlog.

Checklist reviewed by the area lead; mismatches go to the backlog.

Performance numbers measured on the build farm, not on a dev machine.

Updated after the sprint retro; see the #eng channel for context.

Performance numbers measured on the build farm, not on a dev machine.
