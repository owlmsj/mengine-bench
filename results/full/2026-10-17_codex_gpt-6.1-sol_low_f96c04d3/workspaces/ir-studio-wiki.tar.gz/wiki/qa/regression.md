# Regression


Smoke suite per build; S1 blocks release.

Checklist reviewed by the area lead; mismatches go to the backlog.

Checklist reviewed by the area lead; mismatches go to the backlog.

Checklist reviewed by the area lead; mismatches go to the backlog.

Performance numbers measured on the build farm, not on a dev machine.

Performance numbers measured on the build farm, not on a dev machine.

Any change here needs a PR reviewed by two people.

Updated after the sprint retro; see the #eng channel for context.

Any change here needs a PR reviewed by two people.

Checklist reviewed by the area lead; mismatches go to the backlog.
