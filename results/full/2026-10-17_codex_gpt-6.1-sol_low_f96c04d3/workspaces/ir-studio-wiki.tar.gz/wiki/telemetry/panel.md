# Panel


stats-panel with SSO login; A/B by player_id hash.

Performance numbers measured on the build farm, not on a dev machine.

Performance numbers measured on the build farm, not on a dev machine.

Performance numbers measured on the build farm, not on a dev machine.

History before 0.12 was archived in the old wiki.

Updated after the sprint retro; see the #eng channel for context.

History before 0.12 was archived in the old wiki.

History before 0.12 was archived in the old wiki.

Checklist reviewed by the area lead; mismatches go to the backlog.

Any change here needs a PR reviewed by two people.

Performance numbers measured on the build farm, not on a dev machine.

Performance numbers measured on the build farm, not on a dev machine.
