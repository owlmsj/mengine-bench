# Events


tutorial_complete, match_end, weapon_swap.

Checklist reviewed by the area lead; mismatches go to the backlog.

Performance numbers measured on the build farm, not on a dev machine.

History before 0.12 was archived in the old wiki.

Performance numbers measured on the build farm, not on a dev machine.

Any change here needs a PR reviewed by two people.

History before 0.12 was archived in the old wiki.

Checklist reviewed by the area lead; mismatches go to the backlog.

History before 0.12 was archived in the old wiki.
