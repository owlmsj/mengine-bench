# Release process


RC on Tuesday, producer approval before the Steam push.

Any change here needs a PR reviewed by two people.

Performance numbers measured on the build farm, not on a dev machine.

Any change here needs a PR reviewed by two people.

Checklist reviewed by the area lead; mismatches go to the backlog.

Updated after the sprint retro; see the #eng channel for context.

Any change here needs a PR reviewed by two people.

Performance numbers measured on the build farm, not on a dev machine.

Any change here needs a PR reviewed by two people.
