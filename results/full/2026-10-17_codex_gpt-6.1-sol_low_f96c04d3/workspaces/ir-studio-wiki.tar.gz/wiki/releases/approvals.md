# Release approvals

| Build | Approved by | Date |
|---|---|---|
| 0.14.1 | Bruno Costa | 2026-04-22 |
| 0.14.2 | Carla Mendes | 2026-05-06 |
| 0.14.2.1 | Bruno Costa | 2026-05-09 |
| 0.14.3 | Alice Sato | 2026-05-19 |
| 0.15.0 | Carla Mendes | 2026-06-10 |
