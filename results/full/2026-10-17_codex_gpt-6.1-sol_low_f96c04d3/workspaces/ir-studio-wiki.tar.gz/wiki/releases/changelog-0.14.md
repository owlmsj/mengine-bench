# Changelog 0.14.x

## 0.14.1
- PR #790 SMG recoil balancing
- PR #795 lobby: region filter

## 0.14.2
- PR #805 fixes BUG-4417 (ultrawide crosshair)
- PR #807 tutorial telemetry for the stats-panel

## 0.14.2.1 (hotfix, cherry-pick of #809 only)
- PR #809 fixes audio crash on Linux

## 0.14.3
- PR #812 fixes weapon swap crash during respawn
- PR #815 new ranked map in rotation
