# Changelog 0.13


PR #702 bot respawn crash (a different bug), PR #733 HUD.

History before 0.12 was archived in the old wiki.

History before 0.12 was archived in the old wiki.

Updated after the sprint retro; see the #eng channel for context.

Checklist reviewed by the area lead; mismatches go to the backlog.

History before 0.12 was archived in the old wiki.

Checklist reviewed by the area lead; mismatches go to the backlog.

Any change here needs a PR reviewed by two people.

Checklist reviewed by the area lead; mismatches go to the backlog.

Checklist reviewed by the area lead; mismatches go to the backlog.
