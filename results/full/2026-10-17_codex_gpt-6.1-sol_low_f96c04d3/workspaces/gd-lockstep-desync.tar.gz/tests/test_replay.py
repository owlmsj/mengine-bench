import os
from pathlib import Path
import subprocess
import sys
import unittest

from lockstep.sim import simulate


class ReplayTest(unittest.TestCase):
    def test_replay_across_processes(self) -> None:
        hashes: list[str] = []
        for hash_seed in ("1", "2", "3"):
            environment = os.environ.copy()
            environment["PYTHONHASHSEED"] = hash_seed
            replay = subprocess.run(
                [sys.executable, "-c",
                 "import random; from lockstep.sim import simulate; "
                 f"random.seed({hash_seed}); "
                 "print([simulate(seed, 40) for seed in (0, 7, 42)])"],
                cwd=Path(__file__).resolve().parents[1],
                env=environment, capture_output=True, text=True, check=True,
            )
            hashes.append(replay.stdout.strip())
        self.assertEqual(hashes, [hashes[0]] * len(hashes))

    def test_same_seed_same_hash(self):
        self.assertEqual(simulate(7, 40), simulate(7, 40))


if __name__ == "__main__":
    unittest.main()
