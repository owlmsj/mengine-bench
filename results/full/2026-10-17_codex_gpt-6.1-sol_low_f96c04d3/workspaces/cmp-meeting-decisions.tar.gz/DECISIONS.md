# Operations handoff - 2026-06-30

- Pro: BRL 55/month from 2026-08-01; current payers keep BRL 49 through 2027-01-31. Implementation owner not assigned. Source: meetings/2026-06-30-ops.md:89.
- Hiring freeze except 1 SRE role. Alice must open it by 2026-07-15. Backend hiring remains frozen. Designer deferred to Q4 2026, conditional on revenue above BRL 300k/month; owner not assigned. Sources: meetings/2026-06-30-ops.md:173, meetings/2026-06-30-ops.md:447.
- Cloud: June spend BRL 71k, driven by a test GPU left running. Cap BRL 60k/month; billing alert at 80% of cap. Bruno owns implementation; no deadline stated. Sources: meetings/2026-06-30-ops.md:245, meetings/2026-06-30-ops.md:357.
- Billing: Bruno migrates invoicing from manual bank slips to Stripe by 2026-07-31. Carla validates the first month's reconciliation; no calendar deadline stated for validation. Source: meetings/2026-06-30-ops.md:421.

Pending: execute/confirm the pricing change, SRE posting, cloud cap/alert, Stripe migration and reconciliation; completion was not recorded. Assign pricing and conditional designer owners; establish missing deadlines. No commands or technical file:line references were supplied in the meeting.