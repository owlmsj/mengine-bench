[goal] local-9b Q5 com contexto obrigatório de 128k (131072).
[result] Receita final: `--no-mmproj-offload` e `-ub 512`; spill eliminado. VRAM final 7697 MiB; decode final 38.0 t/s (mediana de 3).
[action] Medição: `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`.
[result] Receita aplicada em `scripts/start_server.ps1:165` (bloco local9) e `profiles/local/local-9b.json` (linha não informada).
[result] Decisão: manter Q5. Q6_K (7.03 GiB) descartado porque não cabe em 128k. Q4_K_M apenas fallback: 7305 MiB, 40.4 t/s.
[next] Atualizar o README de evals: ainda referencia `check_vision.ps1`, arquivo que não existe mais. Caminho exato do README, substituto, responsável e prazo não informados. Nenhuma outra pendência substantiva registrada.
