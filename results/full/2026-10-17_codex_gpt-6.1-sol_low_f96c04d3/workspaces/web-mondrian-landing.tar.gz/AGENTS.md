Work only in this directory. Do not use credentials or billable resources.
