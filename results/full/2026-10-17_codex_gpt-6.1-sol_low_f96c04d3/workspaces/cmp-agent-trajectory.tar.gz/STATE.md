[goal] Continue tick/network optimization; final state is failing validation.

[result] Latest benchmark: `tools/bench_tick.sh` -> `tick p99 = 11.8 ms` (step 150, agent/trajectory.jsonl:151). This predates the final test and replication edits; performance after those edits is unmeasured.
Latest test: `ctest -R Net --output-on-failure` -> `1 failed: ReplicationTest.DeltaCompression` (step 159, agent/trajectory.jsonl:160). Do not report the earlier `12 passed` as current.

[action] Edited files: `server/sim/tick.cpp`, `server/net/serializer.cpp`, `tests/net_test.cpp`, `server/net/replication.cpp`. Last edits: tests step 155 (agent/trajectory.jsonl:156), replication step 157 (agent/trajectory.jsonl:158). Trajectory records no diffs or source line numbers, so exact implementation and failing assertion require inspection.

[decision] SIMD (AVX2) delta serializer was abandoned and reverted after a crash on the ARM64 dedicated server build (step 96, agent/trajectory.jsonl:97). Preserve that decision.

[next] Inspect `ReplicationTest.DeltaCompression` and the final test/replication edits; reproduce with `ctest -R Net --output-on-failure`, fix the regression, then rerun tests and `tools/bench_tick.sh` to establish final correctness/performance. No owner or deadline recorded. No commit/release status recorded.