"""Match payout. Rules live in docs/ECONOMY.md."""

import math


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    raw = (base + kills * cfg["kill_bonus"]) * cfg["event_multiplier"]
    # Nearest ten with halves always up; round() is half-to-even (1585 -> 1580).
    return int(math.floor(raw / 10 + 0.5) * 10)
