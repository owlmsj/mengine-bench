import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require('C:/Users/mstiilpenj/AppData/Roaming/npm/node_modules/playwright-core');

const browser = await chromium.launch({
  executablePath: 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
  headless: true,
  args: ['--use-angle=default', '--enable-webgl', '--ignore-gpu-blocklist'],
});
const page = await browser.newPage({ viewport: { width: 1600, height: 900 }, deviceScaleFactor: 1 });
const logs = [];
page.on('console', (m) => logs.push(`[${m.type()}] ${m.text()}`));
page.on('pageerror', (e) => logs.push(`[pageerror] ${e.message}`));
await page.goto('http://127.0.0.1:8137/index.html', { waitUntil: 'networkidle', timeout: 60000 });
await page.waitForFunction('window.__sceneReady === true', null, { timeout: 30000 }).catch(() => {});
await page.waitForTimeout(600);
await page.screenshot({ path: 'scene/cap-01.png' });
await page.waitForTimeout(1800);
await page.screenshot({ path: 'scene/cap-02.png' });
const info = await page.evaluate(() => {
  const c = document.querySelector('canvas');
  return {
    canvas: c ? { w: c.width, h: c.height, cssW: c.clientWidth, cssH: c.clientHeight } : null,
    ready: window.__sceneReady,
    gl: (() => {
      const gl = c && (c.getContext('webgl2') || c.getContext('webgl'));
      return gl ? gl.getParameter(gl.VERSION) : null;
    })(),
    anims: document.getAnimations().length,
  };
});
console.log(JSON.stringify({ logs, info }, null, 2));
await browser.close();
