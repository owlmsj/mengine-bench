"""Lockstep simulation of a Pixel Arena bot skirmish.

Determinism contract (every client must produce the same hash):
- The match RNG is `random.Random(seed)`, owned by World; nothing else draws randomness.
- Every tick, living units act in ascending unit id order.
"""

import hashlib
import random


class World:
    def __init__(self, seed: int) -> None:
        self.rng = random.Random(seed)
        self.units = {}
        for i in range(12):
            uid = f"u{i:02d}"
            self.units[uid] = {"team": i % 2, "hp": 100, "x": float(i * 3), "kills": 0}
        self.alive = set(self.units)

    def enemies_of(self, uid):
        team = self.units[uid]["team"]
        return {other for other in self.alive if self.units[other]["team"] != team}

    def tick(self) -> None:
        # Ascending id order and sorted candidates: set order varies per
        # process with hash randomization (BUG.md).
        for uid in sorted(self.alive):
            if uid not in self.alive:
                continue
            enemies = self.enemies_of(uid)
            if not enemies:
                return
            target = self.rng.choice(sorted(enemies))
            damage = self.rng.randint(8, 22)
            unit, victim = self.units[uid], self.units[target]
            unit["x"] += (victim["x"] - unit["x"]) * 0.1
            victim["hp"] -= damage
            if victim["hp"] <= 0:
                self.alive.discard(target)
                unit["kills"] += 1

    def state_hash(self) -> str:
        blob = repr(sorted((uid, u["hp"], round(u["x"], 6), u["kills"]) for uid, u in self.units.items()))
        return hashlib.sha256(blob.encode()).hexdigest()[:16]


def simulate(seed: int, ticks: int) -> str:
    world = World(seed)
    for _ in range(ticks):
        world.tick()
    return world.state_hash()
