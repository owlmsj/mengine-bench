import os
import subprocess
import sys
import unittest
from pathlib import Path

from lockstep.sim import simulate

REPO_ROOT = Path(__file__).resolve().parent.parent


class ReplayTest(unittest.TestCase):
    def test_same_seed_same_hash(self):
        self.assertEqual(simulate(7, 40), simulate(7, 40))

    def test_same_seed_same_hash_across_processes(self):
        # Distinct hash seeds reproduce the per-process set ordering that
        # desynced clients (BUG.md).
        hashes = set()
        for hash_seed in ("0", "1", "12345"):
            env = dict(os.environ, PYTHONHASHSEED=hash_seed)
            out = subprocess.run(
                [sys.executable, "-c", "from lockstep.sim import simulate; print(simulate(7, 40))"],
                cwd=REPO_ROOT,
                env=env,
                check=True,
                capture_output=True,
                text=True,
            )
            hashes.add(out.stdout.strip())
        self.assertEqual(len(hashes), 1, hashes)


if __name__ == "__main__":
    unittest.main()
