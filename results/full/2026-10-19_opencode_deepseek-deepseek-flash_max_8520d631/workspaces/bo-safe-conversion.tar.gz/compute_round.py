"""Solve the Series A round per round/term_sheet.md.

Unknowns are coupled: SAFE shares depend on the round price, and the round
price depends on SAFE shares and the pool top-up. Solved algebraically with
exact Fractions, then verified against every term-sheet constraint.
"""
import csv
import json
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ROUND = ROOT / "round"

PRE_MONEY = Fraction(40_000_000)
NEW_MONEY = Fraction(8_000_000)
POOL_TARGET = Fraction(12, 100)


def load_rows(path):
    with path.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


cap_rows = load_rows(ROUND / "cap_table.csv")
safe_rows = load_rows(ROUND / "safes.csv")

shares = {r["holder"]: Fraction(r["shares"]) for r in cap_rows}
c0 = sum(shares.values())  # all rows: common, options, unallocated pool
existing_pool = shares["Unallocated pool"]

# SAFE conversion price per SAFE is min(cap/C0, price * (1 - discount)).
# Assume cap binds first, solve the circular system exactly, then verify.
safe_principal = {r["investor"]: Fraction(r["amount"]) for r in safe_rows}
safe_cap_price = {
    r["investor"]: Fraction(r["valuation_cap"]) / c0 for r in safe_rows
}
safe_discount = {r["investor"]: Fraction(r["discount"]) for r in safe_rows}
safe_cap_shares = {
    inv: safe_principal[inv] / safe_cap_price[inv] for inv in safe_principal
}
total_safe_shares = sum(safe_cap_shares.values())

# Post-round FD = 1.2 * (C0 + top_up + safe_shares) because lead money is 20%
# of pre-money. Pool equation: existing_pool + top_up = 12% * post-round FD.
# top_up = (0.144 * (C0 + safe_shares) - existing_pool) / 0.856
top_up = (Fraction(144, 1000) * (c0 + total_safe_shares) - existing_pool) / Fraction(856, 1000)

price = PRE_MONEY / (c0 + top_up + total_safe_shares)
lead_shares = NEW_MONEY / price
post_fd = c0 + top_up + total_safe_shares + lead_shares
founders = shares["Founder Alice"] + shares["Founder Bruno"]
founders_pct = founders / post_fd * 100

# Verification against every term-sheet rule.
for inv in safe_principal:
    assert price * (1 - safe_discount[inv]) > safe_cap_price[inv], (
        f"{inv}: discount price undercuts cap; cap assumption wrong"
    )
assert existing_pool + top_up == POOL_TARGET * post_fd, "pool is not 12% of post-round FD"
assert price == PRE_MONEY / (c0 + top_up + total_safe_shares), "round price mismatch"
assert lead_shares == NEW_MONEY / price, "lead shares mismatch"

result = {
    "price_per_share": float(price),
    "new_pool_shares": float(top_up),
    "safe_shares": {inv: float(sh) for inv, sh in safe_cap_shares.items()},
    "new_investor_shares": float(lead_shares),
    "founders_ownership_pct": float(founders_pct),
}

print(f"C0={float(c0)}")
print(f"total_safe_shares={float(total_safe_shares)}")
print(f"post_fd={float(post_fd)}")
print(f"total_pool={float(existing_pool + top_up)} ({float((existing_pool + top_up) / post_fd * 100)}%)")
print(f"lead_check={float(lead_shares * price)}")
print(json.dumps(result, indent=2))

(ROOT / "round_result.json").write_text(
    json.dumps(result, indent=2) + "\n", encoding="utf-8"
)
