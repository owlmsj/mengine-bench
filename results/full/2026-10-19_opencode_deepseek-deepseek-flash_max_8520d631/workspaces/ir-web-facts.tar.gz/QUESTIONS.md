Answer using web search, citing URLs.
