# DECISIONS: Ops meeting 2026-06-30

Source: `meetings/2026-06-30-ops.md`. Final state only; repeated chatter and superseded proposals dropped.

## Decided

1. **Pro price**: BRL 55/month from 2026-08-01. Current payers keep BRL 49 until 2027-01-31. (`ops.md:89`; benchmark BRL 55-69, `ops.md:19`)
2. **Hiring**: freeze, except 1 SRE role. Owner Alice; open by 2026-07-15. (`ops.md:173`)
3. **Cloud**: cap BRL 60k/month; billing alert at 80% of cap. Owner Bruno. (`ops.md:357`)
4. **Billing**: migrate invoicing from manual bank slips to Stripe. Bruno by 2026-07-31; Carla validates the first month's reconciliation. (`ops.md:421`)

## Pending

- Designer role: deferred to Q4, only if revenue goes above BRL 300k/month. No owner assigned. (`ops.md:447`)
- June cloud spend was BRL 71k, driven by a test GPU left running (`ops.md:245`), above the new BRL 60k cap. No follow-up owner recorded.

## Dropped as noise

Room 2 AC drip, end-of-semester party vote, accountant tax-slip email, slow funnel dashboard (attributed to browser cache), "last quarter's numbers": no decisions or actions. Superseded proposals and duplicate asides omitted.
