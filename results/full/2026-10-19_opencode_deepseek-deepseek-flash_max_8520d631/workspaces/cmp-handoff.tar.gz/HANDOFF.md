# HANDOFF: local-9b Q5 at 128k

Goal: serve local-9b Q5 with 128k context and measure decode speed.

FINAL (use these):
- Flags `--no-mmproj-offload -ub 512`; spill gone.
- VRAM 7697 MiB; decode 38.0 t/s (median of 3).
- Command: `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`
- Applied in `scripts/start_server.ps1:165` (local9 block) and `profiles/local/local-9b.json`.

Superseded, do not quote:
- First run with same command: 37.8 t/s, VRAM 7881 MiB. Invalid: 7881 MiB is the WDDM ceiling and the Shared Usage counter showed 1494 MiB spilled.

Model alternatives:
- Q6_K: 7.03 GiB, does not fit at 128k. Discarded.
- Q4_K_M: fits at 7305 MiB, 40.4 t/s. Fallback only, not default.

Pending:
- Update the evals README: still cites `check_vision.ps1`, which no longer exists.
- Review scratchpad temp file names (noted, low priority).

Owner/deadline: none recorded in the transcript. No other open items.
