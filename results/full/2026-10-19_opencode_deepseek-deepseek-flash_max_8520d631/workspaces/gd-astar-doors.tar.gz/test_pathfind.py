import unittest

from pathfind import find_path


class VisibleTest(unittest.TestCase):
    def test_straight_corridor(self):
        self.assertEqual(find_path(["S..G"]), [(0, 0), (0, 1), (0, 2), (0, 3)])


if __name__ == "__main__":
    unittest.main()
