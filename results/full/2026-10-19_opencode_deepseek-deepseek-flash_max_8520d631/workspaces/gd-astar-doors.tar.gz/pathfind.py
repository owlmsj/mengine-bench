"""Pixel Arena level pathing: bots walk a tile map painted in primary colors."""

import heapq

Cell = tuple[int, int]  # (row, col)

ENTER_COST = {"S": 1, "G": 1, ".": 1, "D": 3}


def find_path(grid: list[str]) -> list[Cell] | None:
    """Cheapest 4-neighbour path from 'S' to 'G', both inclusive.

    '.' floor costs 1 to enter, 'D' door costs 3, '#' is a wall, 'S'/'G' cost 1.
    Return None when G is unreachable.
    """
    start: Cell | None = None
    goal: Cell | None = None
    for row, line in enumerate(grid):
        for col, tile in enumerate(line):
            if tile == "S":
                start = (row, col)
            elif tile == "G":
                goal = (row, col)

    if start is None or goal is None:
        return None

    rows = len(grid)
    best: dict[Cell, int] = {start: 0}
    previous: dict[Cell, Cell] = {}
    # (row, col) step order: right, down, left, up keeps ties deterministic.
    steps = ((0, 1), (1, 0), (0, -1), (-1, 0))
    queue: list[tuple[int, Cell]] = [(0, start)]

    while queue:
        cost, cell = heapq.heappop(queue)
        if cost > best.get(cell, cost + 1):
            continue
        if cell == goal:
            path = [cell]
            while path[-1] != start:
                path.append(previous[path[-1]])
            path.reverse()
            return path
        row, col = cell
        for d_row, d_col in steps:
            next_row, next_col = row + d_row, col + d_col
            if not (0 <= next_row < rows and 0 <= next_col < len(grid[next_row])):
                continue
            enter = ENTER_COST.get(grid[next_row][next_col])
            if enter is None:  # '#' or unknown tile
                continue
            next_cell = (next_row, next_col)
            next_cost = cost + enter
            if next_cost < best.get(next_cell, next_cost + 1):
                best[next_cell] = next_cost
                previous[next_cell] = cell
                heapq.heappush(queue, (next_cost, next_cell))

    return None
