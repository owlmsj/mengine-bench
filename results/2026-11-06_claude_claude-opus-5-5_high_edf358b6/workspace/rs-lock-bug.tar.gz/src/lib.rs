//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex, MutexGuard};

pub type PlayerId = u32;

#[derive(Default)]
struct BoardState {
    scores: HashMap<PlayerId, i64>,
    total: i64,
}

/// Clones share the same scores, so each match thread keeps its own handle.
///
/// All state sits behind one mutex: every operation is atomic, and there is
/// no lock order to get wrong. Per-player mutexes previously lost updates in
/// `award` (read and write under separate locks) and deadlocked `transfer`
/// (opposite lock order between threads, and double lock when from == to).
#[derive(Clone, Default)]
pub struct Board {
    state: Arc<Mutex<BoardState>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    fn lock_state(&self) -> MutexGuard<'_, BoardState> {
        // A panicking match thread must not take the whole board down with it.
        self.state.lock().unwrap_or_else(|poisoned| poisoned.into_inner())
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        let mut state = self.lock_state();
        state.scores.insert(id, score);
        state.total += score;
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let mut state = self.lock_state();
        *score_slot(&mut state.scores, id) += points;
        state.total += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let mut state = self.lock_state();
        // Validate both ids before mutating, so a bad id leaves no half transfer.
        score_slot(&mut state.scores, to);
        *score_slot(&mut state.scores, from) -= points;
        *score_slot(&mut state.scores, to) += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *score_slot(&mut self.lock_state().scores, id)
    }

    pub fn total(&self) -> i64 {
        self.lock_state().total
    }
}

fn score_slot(scores: &mut HashMap<PlayerId, i64>, id: PlayerId) -> &mut i64 {
    match scores.get_mut(&id) {
        Some(score) => score,
        None => panic!("unknown player id {id}; expected an id passed to Board::join"),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::mpsc;
    use std::thread;
    use std::time::Duration;

    const THREADS: u32 = 8;
    const ROUNDS: i64 = 20_000;

    /// Runs `body` on a helper thread and fails instead of hanging forever.
    fn within_deadline(body: impl FnOnce() + Send + 'static) {
        let (done_tx, done_rx) = mpsc::channel();
        thread::spawn(move || {
            body();
            done_tx.send(()).unwrap();
        });
        done_rx
            .recv_timeout(Duration::from_secs(20))
            .expect("board operations deadlocked: no finish within 20s");
    }

    #[test]
    fn concurrent_awards_lose_no_points() {
        within_deadline(|| {
            let board = Board::new();
            board.join(1, 0);
            let workers: Vec<_> = (0..THREADS)
                .map(|_| {
                    let board = board.clone();
                    thread::spawn(move || (0..ROUNDS).for_each(|_| board.award(1, 1)))
                })
                .collect();
            workers.into_iter().for_each(|w| w.join().unwrap());
            let expected = THREADS as i64 * ROUNDS;
            assert_eq!((board.score(1), board.total()), (expected, expected));
        });
    }

    #[test]
    fn opposite_transfers_do_not_deadlock() {
        within_deadline(|| {
            let board = Board::new();
            board.join(1, 0);
            board.join(2, 0);
            let workers: Vec<_> = (0..THREADS)
                .map(|n| {
                    let board = board.clone();
                    let (from, to) = if n % 2 == 0 { (1, 2) } else { (2, 1) };
                    thread::spawn(move || (0..ROUNDS).for_each(|_| board.transfer(from, to, 1)))
                })
                .collect();
            workers.into_iter().for_each(|w| w.join().unwrap());
            assert_eq!((board.score(1), board.score(2), board.total()), (0, 0, 0));
        });
    }

    #[test]
    fn self_transfer_changes_nothing() {
        within_deadline(|| {
            let board = Board::new();
            board.join(7, 40);
            board.transfer(7, 7, 15);
            assert_eq!((board.score(7), board.total()), (40, 40));
        });
    }
}
