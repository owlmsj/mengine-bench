"""Settings for the backup agent.

The API token is never stored here: it is read from the BACKUP_TOKEN environment variable at upload time.
"""

API_URL = "https://backup.example.invalid/v1/upload"
TOKEN_ENV_VAR = "BACKUP_TOKEN"
ARCHIVE_DIR = "archives"
