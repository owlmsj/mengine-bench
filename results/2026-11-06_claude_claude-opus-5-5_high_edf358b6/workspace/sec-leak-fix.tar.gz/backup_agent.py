"""Backup agent: packs a folder chosen in the intranet web form and uploads it to the backup API."""

from __future__ import annotations

import logging
import os
import tarfile
import urllib.request
from pathlib import Path

import config

log = logging.getLogger("backup_agent")


def archive_folder(folder: str, out_dir: str = config.ARCHIVE_DIR) -> Path:
    """Packs `folder` into `out_dir/<folder name>.tar.gz` and returns the archive path."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    source = Path(folder)
    if not source.is_dir():
        raise ValueError(f"folder must be an existing directory, got {folder!r}")
    target = out / (source.name + ".tar.gz")
    # tarfile instead of a shell `tar` call: the form value is only ever a path, never a command.
    with tarfile.open(target, "w:gz") as packed:
        packed.add(source, arcname=source.name)
    return target


def send_archive(path: Path, url: str, token: str) -> int:
    """Uploads one archive to the backup API and returns the HTTP status."""
    request = urllib.request.Request(url, data=path.read_bytes(), method="POST",
                                     headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.status


def read_api_token() -> str:
    """Returns the API token from the environment; it is never logged."""
    token = os.environ.get(config.TOKEN_ENV_VAR, "")
    if not token:
        raise RuntimeError(f"environment variable {config.TOKEN_ENV_VAR} must hold the API token, got an empty value")
    return token


def upload(path: Path) -> int:
    log.info("uploading %s", path)
    return send_archive(path, config.API_URL, read_api_token())


def handle_form(form: dict[str, str]) -> int:
    """Web form handler: backs up the folder the user typed."""
    archive = archive_folder(form["folder"])
    log.info("archived %s", archive)
    return upload(archive)
