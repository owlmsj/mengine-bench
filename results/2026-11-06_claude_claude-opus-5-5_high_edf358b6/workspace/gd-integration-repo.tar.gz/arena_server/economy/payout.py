"""Match payout. Rules live in docs/ECONOMY.md."""

from decimal import ROUND_HALF_UP, Decimal


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    # Decimal via str() so binary float error cannot push an exact half (x5) below .5
    multiplier = Decimal(str(cfg["event_multiplier"]))
    raw = (Decimal(base) + Decimal(kills) * Decimal(str(cfg["kill_bonus"]))) * multiplier
    tens = (raw / 10).quantize(Decimal(1), rounding=ROUND_HALF_UP)
    return int(tens * 10)
