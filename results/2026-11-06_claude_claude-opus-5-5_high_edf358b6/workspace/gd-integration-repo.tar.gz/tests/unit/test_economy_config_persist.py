import json
import tempfile
import unittest
from pathlib import Path

from arena_server.config.defaults import DEFAULTS
from arena_server.config.loader import load_config
from arena_server.economy.payout import match_payout
from arena_server.models.profile import Profile
from arena_server.persistence.codec import decode, encode


class EconomyConfigPersistRegression(unittest.TestCase):
    def test_env_beats_file(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as tmp:
            f = Path(tmp) / "c.json"
            f.write_text(json.dumps({"kill_bonus": 50}))
            self.assertEqual(load_config(f, env={"ARENA_KILL_BONUS": "75"})["kill_bonus"], 75)

    def test_credits_survive_codec(self):
        self.assertEqual(decode(encode(Profile("p", credits=1690))).credits, 1690)

    def test_doc_rounding_examples(self):
        cfg = dict(DEFAULTS)
        self.assertEqual(match_payout(True, 0, dict(cfg, win_base=1425)), 1430)
        self.assertEqual(match_payout(True, 0, dict(cfg, win_base=1585)), 1590)
        # float (900+8*50)*1.15 = 1494.9999...; exact 1495 must round up
        self.assertEqual(match_payout(True, 8, dict(cfg, event_multiplier=1.15)), 1500)


if __name__ == "__main__":
    unittest.main()
