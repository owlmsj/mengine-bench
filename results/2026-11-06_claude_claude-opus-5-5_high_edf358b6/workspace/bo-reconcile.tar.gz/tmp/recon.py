import csv, json, re, sys
from collections import defaultdict
base = sys.argv[1]
inv = {r['id']: round(float(r['amount']),2) for r in csv.DictReader(open(f'{base}/backoffice/invoices.csv', encoding='utf-8'))}
pays = defaultdict(list); ignored=[]
for r in csv.DictReader(open(f'{base}/backoffice/bank_statement_june.csv', encoding='utf-8')):
    m = re.search(r'\b(?:inv-?|invoice\s+)(\d{4})\b', r['memo'], re.I)
    iid = f'INV-{m.group(1)}' if m else None
    if iid not in inv: ignored.append(r); continue
    pays[iid].append(round(float(r['amount']),2))
unpaid = sorted(i for i in inv if i not in pays)
dup = sorted(i for i,p in pays.items() if len(p)>1)
mis = [{"id":i,"invoiced":inv[i],"paid":p[0]} for i,p in sorted(pays.items()) if len(p)==1 and abs(p[0]-inv[i])>0.005]
json.dump({"unpaid":unpaid,"duplicated":dup,"mismatched":mis}, open(f'{base}/result.json','w'), indent=2)
print("ignored:", ignored); print({i:pays[i] for i in dup})
