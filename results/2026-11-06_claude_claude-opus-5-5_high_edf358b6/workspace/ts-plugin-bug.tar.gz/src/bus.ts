/**
 * Hook bus for harness plugins (OpenCode-style hooks). The README states the contract:
 * handlers run one after another in subscription order, emit resolves after all of them,
 * a handler error rejects emit, and unsubscribing during an emit does not stop the others.
 */

export type Handler<T> = (payload: T) => void | Promise<void>;

export class HookBus {
  private handlers: Map<string, Handler<unknown>[]> = new Map();

  /** Subscribes a handler to an event; returns the function that unsubscribes it. */
  on<T>(event: string, handler: Handler<T>): () => void {
    const list = this.handlers.get(event) ?? [];
    list.push(handler as Handler<unknown>);
    this.handlers.set(event, list);
    let subscribed = true;
    return () => {
      // Idempotent: a second call must not remove another subscription of the same function.
      if (!subscribed) return;
      subscribed = false;
      const index = list.indexOf(handler as Handler<unknown>);
      if (index >= 0) list.splice(index, 1);
    };
  }

  /** Runs the handlers of an event with the payload. */
  async emit<T>(event: string, payload: T): Promise<void> {
    // Snapshot: (un)subscribing during this emit only counts from the next emit (README).
    const snapshot = [...(this.handlers.get(event) ?? [])];
    // Sequential await: forEach(async) fired handlers concurrently, never awaited them and
    // swallowed rejections (out-of-order, missed and silently ignored hooks).
    for (const handler of snapshot) {
      await handler(payload);
    }
  }

  /** How many handlers an event has. */
  count(event: string): number {
    return (this.handlers.get(event) ?? []).length;
  }
}
