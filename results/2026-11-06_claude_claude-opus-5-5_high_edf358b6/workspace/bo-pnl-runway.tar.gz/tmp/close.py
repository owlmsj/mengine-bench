import csv,json,sys,collections,re
coa={r['account']:r['pnl_line'] for r in csv.DictReader(open('finance/chart_of_accounts.csv',encoding='utf-8'),delimiter=';')}
rows=list(csv.DictReader(open('finance/ledger.csv',encoding='utf-8'),delimiter=';'))
print('rows',len(rows))
seen=collections.Counter((r['date'],r['account'],r['amount']) for r in rows)
print('dups',[k for k,v in seen.items() if v>1])
agg=collections.defaultdict(float);bad=[]
for r in rows:
    d=r['date'].strip()
    m=re.fullmatch(r'(\d{2})/(\d{2})/(\d{4})',d)
    if not m or r['account'] not in coa: bad.append(r);continue
    mon=f"{m[3]}-{m[2]}"
    amt=float(r['amount'].replace('.','').replace(',','.'))
    agg[(mon,coa[r['account']])]+=amt
print('bad',bad)
months=sorted({k[0] for k in agg});print(months)
res={'revenue':{},'gross_margin_pct':{},'ebitda':{}}
for mo in months:
    g=lambda l:agg.get((mo,l),0.0)
    rev=g('revenue');gp=rev+g('cogs');eb=gp+g('sales_marketing')+g('rnd')+g('ga')
    res['revenue'][mo]=round(rev,2);res['gross_margin_pct'][mo]=round(gp/rev*100,2);res['ebitda'][mo]=round(eb,2)
    print(mo,{l:round(g(l),2) for l in ['revenue','cogs','sales_marketing','rnd','ga','financial']},'GM%',round(gp/rev*100,2),'EBITDA',round(eb,2),'net',round(eb+g('financial'),2))
last3=[res['ebitda'][m] for m in ['2026-04','2026-05','2026-06']]
burn=round(-sum(last3)/3,2);res['burn']=burn;res['runway_months']=round(1847350.40/burn,2)
print(burn,res['runway_months'])
json.dump(res,open('result.json','w'),indent=2)
