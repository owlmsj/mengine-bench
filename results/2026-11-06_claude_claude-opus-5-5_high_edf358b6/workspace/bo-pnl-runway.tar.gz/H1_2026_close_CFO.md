# H1 2026 close (Jan-Jun), BRL

| Month | Net revenue | Gross margin % | EBITDA | Net result (after financial) |
|---|---|---|---|---|
| 2026-01 | 200,510.87 | 70.03 | -210,278.96 | -203,812.19 |
| 2026-02 | 216,328.06 | 70.29 | -212,300.08 | -205,001.69 |
| 2026-03 | 219,066.17 | 68.46 | -204,525.45 | -198,078.94 |
| 2026-04 | 238,163.26 | 70.24 | -196,950.65 | -189,670.28 |
| 2026-05 | 243,032.89 | 69.56 | -201,945.82 | -195,444.78 |
| 2026-06 | 272,391.57 | 72.41 | -192,968.22 | -187,346.57 |

- Revenue +35.8% Jan to Jun; gross margin stable at ~70% (Mar and May dipped from Kestrel refunds: -6,814.15 and -8,634.37).
- EBITDA losses narrowing slowly: -210k (Jan) to -193k (Jun).
- Burn (board definition, README: avg negative EBITDA Apr-Jun): **R$ 197,288.23/month**.
- Runway: closing cash 30/06/2026 R$ 1,847,350.40 / burn = **9.36 months** (to roughly mid-April 2027).

## Assumptions
- Revenue is net of refunds (3.1.09 maps to revenue in the chart of accounts).
- EBITDA = revenue - COGS - S&M - R&D - G&A; financial lines (6.x investment income, interest/IOF) excluded. No D&A accounts exist.
- Gross margin % = (revenue - COGS) / net revenue.

## Flag for the CFO
- Cash fell R$ 461,837.60 from 31/05 to 30/06, far above June net loss (-187k). Ledger has no balance-sheet accounts, so the gap (payables, capex, taxes, timing) is unexplained here. If June cash burn is the true rate, runway is about 4 months. Reconcile before presenting.
