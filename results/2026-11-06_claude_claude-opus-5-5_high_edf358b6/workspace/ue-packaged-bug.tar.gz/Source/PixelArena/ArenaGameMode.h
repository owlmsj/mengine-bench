#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "ArenaGameMode.generated.h"

class UArenaHud;
class UArenaPalette;
class UArenaScoreTracker;
struct FArenaStats;

UCLASS()
class PIXELARENA_API AArenaGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type Reason) override;

	void OnGoalScored(int32 TeamIndex);

private:
	UPROPERTY()
	TObjectPtr<UArenaHud> Hud;

	UPROPERTY()
	TObjectPtr<UArenaPalette> Palette;

	// UPROPERTY so GC sees the reference; a raw UObject* is purged by GC (crash in shipping log).
	UPROPERTY()
	TObjectPtr<UArenaScoreTracker> ScoreTracker;

	// Plain C++ data owned by this class, freed in EndPlay.
	FArenaStats* Stats = nullptr;
};
