import csv, json, math, sys
from collections import Counter
path = sys.argv[1]
rows = list(csv.DictReader(open(path, newline='', encoding='utf-8')))
print("raw rows", len(rows))
print("variants raw", Counter(r['variant'] for r in rows))
print("completed raw", Counter(r['completed_tutorial'] for r in rows))
by_session = {}
conflicts = 0
for r in rows:
    sid = r['session_id'].strip()
    rec = (r['variant'].strip().upper(), r['completed_tutorial'].strip())
    if sid in by_session and by_session[sid] != rec:
        conflicts += 1
        print("conflict", sid, by_session[sid], rec)
    by_session.setdefault(sid, rec)
print("unique sessions", len(by_session), "conflicts", conflicts)
n = Counter(); k = Counter()
for v, c in by_session.values():
    if c not in ('0', '1'):
        raise ValueError(f"completed_tutorial={c!r}, expected '0' or '1'")
    n[v] += 1; k[v] += int(c)
print(n, k)
na, nb, ka, kb = n['A'], n['B'], k['A'], k['B']
pa, pb = ka/na, kb/nb
pp = (ka+kb)/(na+nb)
se = math.sqrt(pp*(1-pp)*(1/na+1/nb))
z = (pb-pa)/se
p_two = math.erfc(abs(z)/math.sqrt(2))
p_one = 0.5*math.erfc(z/math.sqrt(2))
print(f"pa={pa:.4f} pb={pb:.4f} z={z:.4f} p_two={p_two:.4f} p_one={p_one:.4f}")
try:
    from scipy.stats import fisher_exact, chi2_contingency
    print("fisher", fisher_exact([[kb, nb-kb],[ka, na-ka]]))
    print("chi2 yates", chi2_contingency([[kb, nb-kb],[ka, na-ka]]))
except ImportError:
    print("no scipy")
out = {"ship_b": bool(p_two < 0.05 and pb > pa), "sessions_a": na, "sessions_b": nb,
       "completion_rate_a": round(pa, 4), "completion_rate_b": round(pb, 4), "p_value": round(p_two, 4)}
json.dump(out, open(sys.argv[2], 'w'), indent=2)
print(json.dumps(out))
