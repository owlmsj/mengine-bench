"""Bounded-concurrency runner for batch scripts (Python 3.11+, stdlib only)."""
import asyncio
from collections.abc import Awaitable, Callable, Iterable
from typing import TypeVar

T = TypeVar("T")


async def run_tasks(tasks: Iterable[Callable[[], Awaitable[T]]], max_concurrent: int) -> list[T]:
    """Run each zero-arg task factory, at most max_concurrent jobs at once.

    Factories are called lazily, only when a slot is free. Returns results in
    input order. If a job fails, the others are cancelled (their cleanup runs)
    and the error is raised. On Ctrl+C, asyncio.run cancels this coroutine;
    TaskGroup then cancels every running job and waits for its finally/except
    blocks before CancelledError/KeyboardInterrupt propagates.
    """
    if not isinstance(max_concurrent, int) or isinstance(max_concurrent, bool) or max_concurrent < 1:
        raise ValueError(f"max_concurrent must be an int >= 1, got {max_concurrent!r}")
    factories = list(tasks)
    results: list[T] = [None] * len(factories)  # type: ignore[list-item]
    next_index = iter(range(len(factories)))

    async def run_slot() -> None:
        for index in next_index:  # shared iterator: each index taken by one slot
            results[index] = await factories[index]()

    try:
        async with asyncio.TaskGroup() as group:
            for _ in range(min(max_concurrent, len(factories))):
                group.create_task(run_slot())
    except BaseExceptionGroup as group_error:
        if len(group_error.exceptions) == 1:
            raise group_error.exceptions[0] from None
        raise
    return results
