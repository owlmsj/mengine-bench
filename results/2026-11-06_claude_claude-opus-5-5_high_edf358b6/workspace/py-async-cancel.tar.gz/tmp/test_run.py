import asyncio, sys
sys.path.insert(0, ".")
from run import run_tasks

async def main():
    active = peak = 0; cleaned = []
    def make(i, d=0.05):
        async def job():
            nonlocal active, peak
            active += 1; peak = max(peak, active)
            try:
                await asyncio.sleep(d); return i
            finally:
                active -= 1; cleaned.append(i)
        return job
    r = await run_tasks([make(i) for i in range(10)], 3)
    assert r == list(range(10)) and peak == 3, (r, peak); print("limit ok peak", peak)
    cleaned.clear()
    t = asyncio.create_task(run_tasks([make(i, 10) for i in range(5)], 2))
    await asyncio.sleep(0.1); t.cancel()
    try: await t
    except asyncio.CancelledError: pass
    assert sorted(cleaned) == [0, 1] and active == 0, cleaned; print("cancel cleanup ok", cleaned)
    assert await run_tasks([], 2) == []; print("empty ok")
asyncio.run(main())
