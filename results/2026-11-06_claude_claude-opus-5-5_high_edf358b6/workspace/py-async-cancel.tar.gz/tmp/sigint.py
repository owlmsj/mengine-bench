import asyncio, sys, signal, threading, os
sys.path.insert(0, ".")
from run import run_tasks
def job(i):
    async def j():
        try: await asyncio.sleep(10)
        finally: print("cleanup", i, flush=True)
    return j
threading.Timer(0.3, lambda: signal.raise_signal(signal.SIGINT)).start()
try: asyncio.run(run_tasks([job(i) for i in range(4)], 2))
except KeyboardInterrupt: print("KeyboardInterrupt propagated")
