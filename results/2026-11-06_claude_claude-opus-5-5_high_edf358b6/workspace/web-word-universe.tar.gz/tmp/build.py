import os,re,json,sys,unicodedata,urllib.parse
from collections import defaultdict
S=sys.argv[1]
files={unicodedata.normalize('NFC',f).lower():f for f in os.listdir(S)}
def read(f): return open(os.path.join(S,f),encoding='utf-8').read()
def resolve(href,depth=0):
    h=unicodedata.normalize('NFC',urllib.parse.unquote(href)).lower()
    f=files.get(h)
    if not f or depth>5: return None
    t=read(f)
    m=re.search(r'http-equiv="refresh" content="[^"]*url=([^"]+)"',t)
    if m: return resolve(m.group(1),depth+1)
    m=re.search(r'<h1>([^<]*)</h1>',t)
    if not m or 'section id="sinonimos"' not in t: return None
    return unicodedata.normalize('NFC',m.group(1)).strip().lower()
edges={};tema={};dead=set()
for f in sorted(os.listdir(S)):
    w=resolve(f)
    if not w: continue
    t=read(f)
    m=re.search(r'class="tema">Tema: ([^<]*)<',t); tema[w]=m.group(1).strip() if m else ''
    for sec in ('sinonimos','analogas'):
        m=re.search(r'<section id="%s">(.*?)</section>'%sec,t,re.S)
        for href in re.findall(r'href="([^"]+)"',m.group(1) if m else ''):
            o=resolve(href)
            if not o: dead.add(href); continue
            if o==w: continue
            k=tuple(sorted((w,o)))
            if k not in edges or sec=='sinonimos': edges[k]='s' if sec=='sinonimos' else 'a'
adj=defaultdict(set)
for a,b in edges: adj[a].add(b); adj[b].add(a)
words=sorted(tema, key=lambda s: unicodedata.normalize('NFD',s))
wj={w:sorted(adj[w]) for w in words}
json.dump(wj,open('words.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
mx=max(len(v) for v in wj.values()); mc=sorted(w for w in words if len(wj[w])==mx)
json.dump({'words':len(words),'relations':len(edges),'most_connected':mc[0] if len(mc)==1 else mc},open('result.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
print(len(words),len(edges),mc,mx,'dead',sorted(dead),'isolated',[w for w in words if not wj[w]])
from collections import Counter; print(Counter(tema.values()))
open('tmp/graph.json','w',encoding='utf-8').write(json.dumps({'t':tema,'e':[[a,b,k] for (a,b),k in edges.items()]},ensure_ascii=False))
