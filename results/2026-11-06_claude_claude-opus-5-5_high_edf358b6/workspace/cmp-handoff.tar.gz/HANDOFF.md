# Handoff: local-9b Q5 at 128k context

Goal (user): local model needs 128k; measure local-9b Q5 at ctx 131072.

## Valid result
- Flags `--no-mmproj-offload -ub 512`: VRAM 7697 MiB, decode 38.0 t/s (median of 3), no spill.
- Already applied: scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.
- Measure: `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`

## Do NOT use
- First run 37.8 t/s / 7881 MiB: invalid. 7881 is the WDDM ceiling; Shared Usage showed 1494 MiB spilled.
- Q6_K (7.03 GiB): does not fit at 128k. Q4_K_M: 7305 MiB, 40.4 t/s, fallback only.

## Left to do
- Update evals README: still cites check_vision.ps1, which no longer exists.
- Not verified by me: I only read the transcript, re-ran nothing. Before re-measuring, check Shared GPU Usage is ~0 and no download is running.
