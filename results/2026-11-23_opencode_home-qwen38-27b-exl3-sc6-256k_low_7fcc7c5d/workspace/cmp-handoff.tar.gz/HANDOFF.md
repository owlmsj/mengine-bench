# Handoff: local-9b Q5 @ 128k context

Task: measure local-9b Q5 decode at 131072 ctx.

Done:
- Baseline (measure_decode.ps1 -Ctx 131072 -NPredict 1024): 37.8 t/s, VRAM 7881 MiB.
- 7881 MiB is the WDDM ceiling; Shared Usage showed 1494 MiB spilled -> invalid.
- Fix: --no-mmproj-offload + -ub 512 removes spill: 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k; discarded. Q4_K_M fits (7305 MiB, 40.4 t/s) - fallback only.
- Recipe applied in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

Left:
1. Review the names of the scratchpad temp files (noted for later, never done).
2. Evals README still cites check_vision.ps1, which no longer exists - update it.

Assumptions: no repo here, so paths are as recorded in session/transcript.md.

Found: the spill was the mmproj offload; the fix makes it fit at 128k. How I know: measured 7697 MiB / 38.0 t/s (median of 3) post-fix vs the invalid 7881 MiB baseline.