import struct
data = open(r"<WORKSPACE>\prices.db", "rb").read()

def varint(b, i):
    v = 0
    for k in range(9):
        c = b[i]; i += 1
        if k == 8:
            return (v << 8) | c, i
        v = (v << 7) | (c & 0x7F)
        if not (c & 0x80):
            return v, i

# first aid kit cell at 3901
p = 3901
off = p
payload_len, off = varint(data, off)
rowid, off = varint(data, off)
print("payload_len", payload_len, "rowid", rowid, "body starts at", off)
body = data[off:off+payload_len]
print("body hex", body.hex())
hlen, ho = varint(body, 0)
print("record header len", hlen)
serials = []
while ho < hlen:
    s, ho = varint(body, ho)
    serials.append(s)
print("serials", serials)
# decode each
vo = hlen
for s in serials:
    if s == 0:
        print("  NULL")
    elif 1 <= s <= 6:
        size = {1:1,2:2,3:3,4:4,5:6,6:8}[s]
        val = int.from_bytes(body[vo:vo+size], "big", signed=True)
        print("  int", val, "bytes", body[vo:vo+size].hex()); vo += size
    elif s == 7:
        val = struct.unpack(">d", body[vo:vo+8])[0]
        print("  float", val, "bytes", body[vo:vo+8].hex()); vo += 8
    elif s == 8:
        print("  int 0")
    elif s == 9:
        print("  int 1")
    elif s >= 12 and s % 2 == 0:
        size = (s-12)//2
        print("  text", body[vo:vo+size]); vo += size
    else:
        size = (s-13)//2
        print("  blob", body[vo:vo+size]); vo += size