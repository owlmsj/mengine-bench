import json, struct

data = open(r"<WORKSPACE>\prices.db", "rb").read()
print("file len", len(data))

# Scan for a b-tree header: type byte 0x0D (leaf) or 0x05 (interior), then cell count,
# then right-most ptr, then cell pointer array of 2-byte offsets within [0,4096].
def try_header(idx):
    h = data[idx:]
    if h[0] not in (0x0D, 0x05):
        return None
    n = struct.unpack(">H", h[3:5])[0]
    if n == 0 or n > 100:
        return None
    ptrs = [struct.unpack(">H", h[8 + 2*k:10 + 2*k])[0] for k in range(n)]
    if any(p >= 4096 for p in ptrs):
        return None
    return n, ptrs

idx = 0
n, ptrs = try_header(idx)
print("header at", idx, "cells", n, "ptrs", ptrs)

def varint(b, i):
    v = 0
    for k in range(9):
        c = b[i]; i += 1
        if k == 8:
            return (v << 8) | c, i
        v = (v << 7) | (c & 0x7F)
        if not (c & 0x80):
            return v, i

rows = []
for p in ptrs:
    off = p
    payload_len, off = varint(data, off)
    rowid, off = varint(data, off)
    body = data[off:off+payload_len]
    hlen, ho = varint(body, 0)
    serials = []
    while ho < hlen:
        s, ho = varint(body, ho)
        serials.append(s)
    vals = []
    vo = hlen
    for s in serials:
        if s == 0:
            vals.append(None)
        elif 1 <= s <= 6:
            size = {1:1,2:2,3:3,4:4,5:6,6:8}[s]
            vals.append(int.from_bytes(body[vo:vo+size], "big", signed=True)); vo += size
        elif s == 7:
            vals.append(1.0)
        elif s == 8:
            vals.append(0)
        elif s == 9:
            vals.append(1)
        elif s >= 12 and s % 2 == 0:
            size = (s - 12)//2
            vals.append(body[vo:vo+size].decode("utf-8")); vo += size
        else:
            size = (s - 13)//2
            vals.append(body[vo:vo+size]); vo += size
    rows.append((rowid, vals))
    print(rowid, vals)

out = []
for rowid, v in sorted(rows, key=lambda r: r[0]):
    item, price = v[1], v[2]
    if isinstance(item, str) and isinstance(price, (int, float)):
        out.append({"item": item, "price": price})
json.dump(out, open(r"<WORKSPACE>\recovered.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print("wrote", len(out), "rows")