import struct
data = open(r"<WORKSPACE>\prices.db", "rb").read()

def varint(b, i):
    v = 0
    for k in range(9):
        c = b[i]; i += 1
        if k == 8:
            return (v << 8) | c, i
        v = (v << 7) | (c & 0x7F)
        if not (c & 0x80):
            return v, i

ptrs = [3901, 4081, 4067, 4043, 4029, 4013, 3987, 3967, 3949, 3928]
for p in ptrs:
    off = p
    payload_len, off = varint(data, off)
    rowid, off = varint(data, off)
    body = data[off:off+payload_len]
    hlen, ho = varint(body, 0)
    serials = []
    while ho < hlen:
        s, ho = varint(body, ho)
        serials.append(s)
    print("ptr", p, "payload", payload_len, "rowid", rowid, "serials", serials, "body", body[:40].hex())