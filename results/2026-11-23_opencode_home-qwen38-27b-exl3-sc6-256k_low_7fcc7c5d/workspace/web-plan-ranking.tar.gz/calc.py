import json, datetime

ipca = {1985:242.23, 1986:79.66, 1987:363.41, 1988:980.21, 1989:1972.91,
        1990:1620.97, 1991:472.70, 1992:1119.10, 1993:2477.15, 1994:916.46,
        1995:22.41, 1996:9.56}

plans = [
    ("Cruzado", 1986, datetime.date(1986,2,28)),
    ("Bresser", 1987, datetime.date(1987,6,12)),
    ("Verao", 1989, datetime.date(1989,1,15)),
    ("Collor I", 1990, datetime.date(1990,3,15)),
    ("Collor II", 1991, datetime.date(1991,1,31)),
    ("Real", 1994, datetime.date(1994,7,1)),
]

def months_between(a, b):
    return (b.year - a.year) * 12 + (b.month - a.month)

results = []
for i, (name, year, launch) in enumerate(plans):
    if i + 1 < len(plans):
        next_launch = plans[i+1][2]
        months = months_between(launch, next_launch)
    else:
        months = 60
    before = ipca[year-1]
    after = ipca[year+1]
    drop = max(0.0, min(1.0, 1 - after/before))
    dur = min(months, 60)/60
    score = 0.7*drop + 0.3*dur
    results.append({"plan": name, "launch_date": launch.isoformat(),
                    "ipca_before": before, "ipca_after": after,
                    "months_lasted": months, "score": round(score,4),
                    "_drop": round(drop,4), "_dur": round(dur,4)})

for r in results:
    print(r)

top3 = [r["plan"] for r in sorted(results, key=lambda r: -r["score"])[:3]]
print("TOP3:", top3)