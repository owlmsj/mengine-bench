import csv, json, math

rows = {}
with open("telemetry/playtest_ab.csv", newline="") as f:
    for r in csv.DictReader(f):
        sid = r["session_id"].strip()
        # ETL resends sessions: keep first occurrence per session_id
        if sid not in rows:
            rows[sid] = r

n = {"a": 0, "b": 0}
c = {"a": 0, "b": 0}
for sid, r in rows.items():
    v = r["variant"].strip().lower()
    assert v in ("a", "b"), v
    comp = int(r["completed_tutorial"])
    n[v] += 1
    c[v] += comp

pa, pb = c["a"] / n["a"], c["b"] / n["b"]
p = (c["a"] + c["b"]) / (n["a"] + n["b"])
se = math.sqrt(p * (1 - p) * (1 / n["a"] + 1 / n["b"]))
z = (pb - pa) / se
# two-sided p-value from normal
pval = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))

out = {
    "ship_b": bool(pval < 0.05 and pb > pa),
    "sessions_a": n["a"],
    "sessions_b": n["b"],
    "completion_rate_a": pa,
    "completion_rate_b": pb,
    "p_value": pval,
}
print(json.dumps(out, indent=2))
print(f"z={z:.4f} completions a={c['a']} b={c['b']}")