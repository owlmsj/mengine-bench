import re

with open('regex.txt') as f:
    pattern = f.read().strip()

with open('server.log') as f:
    log = f.read()

result = re.findall(pattern, log, re.MULTILINE)
print("Sample log result:", result)
expected = ['2026-04-01', '2026-04-02', '2026-04-05']
print("Expected:        ", expected)
print("Match:", result == expected)

# Edge cases
tests = [
    # (line, expected)
    ("no address here 2026-01-15", []),                    # no IP
    ("10.0.0.1 did something 2026-01-15", ['2026-01-15']), # IP + date
    ("10.0.0.1", []),                                      # IP no date
    ("256.1.1.1 bad ip 2026-01-15", []),                   # invalid IP (256)
    ("01.2.3.4 leading zero 2026-01-15", []),              # leading zero in IP
    ("1.2.3.04 leading zero 2026-01-15", []),              # leading zero in IP
    ("1.2.3.4.5 too many 2026-01-15", []),                 # 5 parts
    ("1.2.3 too few 2026-01-15", []),                      # 3 parts
    ("a10.0.0.1 letter before 2026-01-15", []),            # letter before IP
    ("10.0.0.1a letter after 2026-01-15", []),             # letter after IP
    ("2026-13-01 bad month 10.0.0.1", []),                 # invalid month
    ("2026-00-10 bad month 10.0.0.1", []),                 # month 00
    ("2026-01-00 bad day 10.0.0.1", []),                   # day 00
    ("2026-02-29 ok leap 10.0.0.1", ['2026-02-29']),       # Feb 29 allowed
    ("2026-02-30 bad 10.0.0.1", []),                       # Feb 30
    ("2026-04-31 bad 10.0.0.1", []),                       # Apr 31
    ("2026-01-32 bad 10.0.0.1", []),                       # Jan 32
    ("10.0.0.1 first 2026-01-01 last 2026-12-31", ['2026-12-31']),  # last date
    ("10.0.0.1 2026-01-15", ['2026-01-15']),               # date right after IP
    ("12345678901234567890 10.0.0.1 2026-01-15", ['2026-01-15']),   # digits before IP
    ("10.0.0.1 12345678901234567890 2026-01-15", ['2026-01-15']),   # digits between
    ("x2026-01-15 letter before date 10.0.0.1", []),       # letter before date
    ("2026-01-15x letter after date 10.0.0.1", []),        # letter after date
    ("10.0.0.1 2026-01-15-31 extra dash 2026-06-15", ['2026-06-15']),  # date with extra dash
    ("10.0.0.1 2026-01-15.", ['2026-01-15']),              # date at end with period
    ("10.0.0.1 2026-01-15:30", ['2026-01-15']),            # time after date
]

all_pass = True
for line, expected in tests:
    result = re.findall(pattern, line, re.MULTILINE)
    status = "PASS" if result == expected else "FAIL"
    if result != expected:
        all_pass = False
    print(f"{status}: {line!r} -> {result} (expected {expected})")

print("\nAll tests pass:", all_pass)