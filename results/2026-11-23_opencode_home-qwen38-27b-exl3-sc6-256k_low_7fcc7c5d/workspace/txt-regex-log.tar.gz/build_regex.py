import re

octet = r'(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])'
ip = r'(?<![\w.])(?:' + octet + r'\.){3}' + octet + r'(?![\w.])'

date = (r'(?<![\w.])'
        r'(?:19|20)[0-9][0-9]'
        r'-'
        r'(?:'
            r'(?:0[13578]|1[02])-(?:0[1-9]|[12][0-9]|3[01])'
            r'|'
            r'(?:0[469]|11)-(?:0[1-9]|[12][0-9]|30)'
            r'|'
            r'02-(?:0[1-9]|1[0-9]|2[0-9])'
        r')'
        r'(?![\w.-])')

# The whole pattern is a zero-width anchor: ^ + lookahead for IP + lookahead
# that asserts the rest of the line contains a date. But findall returns the
# matched text, and a zero-width match returns ''. So we need the date to be
# the actual match.
#
# Strategy: match from ^ to the LAST date on the line, but only the date part
# should be in the result. Use a lookahead to skip everything before the last
# date, then match the date.
#
# We can do: ^(?=IP lookahead) then consume everything up to the last date
# using a lookahead that ensures no more dates follow, then match the date.
#
# Simpler: match the date, but ensure it's the last one on the line by
# asserting no other valid date appears after it on the same line.

# "No valid date after this position on the same line"
# This is tricky because we'd need to re-assert the date pattern.
# Alternative: use a greedy match to consume to end of line, then backtrack
# to the last date.

# Pattern: ^ (IP lookahead) [^\n]*? (date) where [^\n]*? is greedy enough
# to reach the LAST date. But [^\n]*? is lazy, so it finds the FIRST date.
# We need greedy: [^\n]* (date) — greedy [^\n]* consumes to end, then
# backtracks to find the last date.

pattern = r'^(?=[^\n]*' + ip + r')' + r'[^\n]*' + date

print("Pattern:", pattern)

with open('server.log') as f:
    log = f.read()

result = re.findall(pattern, log, re.MULTILINE)
print("Sample log result:", result)
expected = ['2026-04-01', '2026-04-02', '2026-04-05']
print("Expected:        ", expected)
print("Match:", result == expected)

tests = [
    ("no address here 2026-01-15", []),
    ("10.0.0.1 did something 2026-01-15", ['2026-01-15']),
    ("10.0.0.1", []),
    ("256.1.1.1 bad ip 2026-01-15", []),
    ("01.2.3.4 leading zero 2026-01-15", []),
    ("1.2.3.04 leading zero 2026-01-15", []),
    ("1.2.3.4.5 too many 2026-01-15", []),
    ("1.2.3 too few 2026-01-15", []),
    ("a10.0.0.1 letter before 2026-01-15", []),
    ("10.0.0.1a letter after 2026-01-15", []),
    ("2026-13-01 bad month 10.0.0.1", []),
    ("2026-00-10 bad month 10.0.0.1", []),
    ("2026-01-00 bad day 10.0.0.1", []),
    ("2026-02-29 ok leap 10.0.0.1", ['2026-02-29']),
    ("2026-02-30 bad 10.0.0.1", []),
    ("2026-04-31 bad 10.0.0.1", []),
    ("2026-01-32 bad 10.0.0.1", []),
    ("10.0.0.1 first 2026-01-01 last 2026-12-31", ['2026-12-31']),
    ("10.0.0.1 2026-01-15", ['2026-01-15']),
    ("x2026-01-15 letter before date 10.0.0.1", []),
    ("2026-01-15x letter after date 10.0.0.1", []),
    ("10.0.0.1 2026-01-15-31 extra dash 2026-06-15", ['2026-06-15']),
    ("10.0.0.1 2026-01-15.", ['2026-01-15']),
    ("10.0.0.1 2026-01-15:30", ['2026-01-15']),
]

all_pass = True
for line, expected in tests:
    result = re.findall(pattern, line, re.MULTILINE)
    status = "PASS" if result == expected else "FAIL"
    if result != expected:
        all_pass = False
    print(f"{status}: {line!r} -> {result} (expected {expected})")

print("\nAll tests pass:", all_pass)

with open('regex.txt', 'w') as f:
    f.write(pattern)
print("\nWrote regex.txt")