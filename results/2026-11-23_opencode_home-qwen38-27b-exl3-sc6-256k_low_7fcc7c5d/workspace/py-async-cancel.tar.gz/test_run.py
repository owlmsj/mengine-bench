import asyncio
import sys

from run import run_tasks

running = 0
peak = 0
cleanups = []


def make_task(i):
    async def job():
        global running, peak
        running += 1
        peak = max(peak, running)
        try:
            await asyncio.sleep(0.05)
        finally:
            running -= 1
            cleanups.append(i)
    return job


async def main():
    global peak
    peak = 0
    await run_tasks([make_task(i) for i in range(10)], max_concurrent=3)
    assert peak <= 3, f"peak {peak} exceeded limit"
    assert peak == 3, f"peak {peak} did not reach limit (wasted concurrency)"
    assert len(cleanups) == 10, f"cleanups {cleanups}"
    print("basic OK: peak =", peak, "cleanups =", len(cleanups))

    # KeyboardInterrupt path: simulate cancel of the gather
    cleanups.clear()
    peak = 0
    tasks = [make_task(i) for i in range(6)]

    async def run_and_interrupt():
        global peak
        peak = 0
        # emulate Ctrl+C by raising KeyboardInterrupt inside a job
        async def boom():
            global running
            running += 1
            try:
                await asyncio.sleep(10)
            finally:
                running -= 1
                cleanups.append("boom")
            raise KeyboardInterrupt

        jobs = [make_task(1), make_task(2), boom, make_task(3)]
        try:
            await run_tasks(jobs, max_concurrent=2)
            print("FAIL: KeyboardInterrupt not propagated")
            sys.exit(1)
        except KeyboardInterrupt:
            pass

    await run_and_interrupt()
    assert "boom" in cleanups, f"boom cleanup missing: {cleanups}"
    assert len(cleanups) == 4, f"expected 4 cleanups, got {cleanups}"
    print("interrupt OK: cleanups =", cleanups)

    # max_concurrent validation
    try:
        await run_tasks([], max_concurrent=0)
        print("FAIL: no ValueError")
        sys.exit(1)
    except ValueError:
        print("validation OK")


asyncio.run(main())
print("ALL PASS")