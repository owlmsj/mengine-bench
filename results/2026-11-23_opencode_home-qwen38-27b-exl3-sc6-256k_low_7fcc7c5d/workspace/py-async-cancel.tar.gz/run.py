"""Batch task runner.

Usage:
    from run import run_tasks
    await run_tasks([make_task_a, make_task_b, ...], max_concurrent=4)

Each element of ``tasks`` is a zero-argument callable that returns an
awaitable job.  At most ``max_concurrent`` jobs run at the same time.

Ctrl+C (KeyboardInterrupt) handling: when a KeyboardInterrupt is raised
(either from a job or from the event loop), all pending jobs are cancelled
and their ``finally``/``except`` cleanup code runs before the exception
propagates.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Iterable


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[object]]],
    max_concurrent: int,
) -> None:
    """Run ``tasks`` with at most ``max_concurrent`` jobs in flight.

    Args:
        tasks: zero-argument callables, each returning an awaitable.
        max_concurrent: maximum number of concurrently running jobs.
            Must be a positive integer.

    Returns once every job has finished (or been cancelled).

    Raises:
        ValueError: if ``max_concurrent`` < 1.
        KeyboardInterrupt: re-raised after all jobs' cleanup has run.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent}")

    sem = asyncio.Semaphore(max_concurrent)

    async def _run_one(make_job: Callable[[], Awaitable[object]]) -> None:
        async with sem:
            await make_job()

    # Wrap each job in its own Task so we can cancel the actual task
    # objects on interrupt (coroutines have no .done()/.cancel()).
    job_tasks = [asyncio.create_task(_run_one(f)) for f in tasks]
    try:
        await asyncio.gather(*job_tasks)
    except BaseException:
        # Cancel every pending job so its cleanup code runs, then wait
        # for them to finish cleaning up before re-raising.
        for t in job_tasks:
            if not t.done():
                t.cancel()
        await asyncio.gather(*job_tasks, return_exceptions=True)
        raise