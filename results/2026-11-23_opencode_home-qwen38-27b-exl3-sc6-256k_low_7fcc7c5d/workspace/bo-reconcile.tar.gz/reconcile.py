import csv, json, re
from collections import defaultdict

base = r"<WORKSPACE>\backoffice"

invoices = {}
with open(base + r"\invoices.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = float(row["amount"])

# payments per invoice id
paid = defaultdict(list)
ignored = []
with open(base + r"\bank_statement_june.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        amt = float(row["amount"])
        m = re.search(r"10\d{2}", memo)
        if not m:
            ignored.append(memo)
            continue
        inv = "INV-" + m.group(0)
        if inv not in invoices:
            ignored.append(memo)
            continue
        paid[inv].append(amt)

unpaid = sorted(i for i in invoices if i not in paid)
duplicated = sorted(i for i in paid if len(paid[i]) > 1)
mismatched = []
for inv in sorted(paid):
    if inv in duplicated:
        continue
    if len(paid[inv]) == 1:
        p = paid[inv][0]
        if abs(p - invoices[inv]) > 0.005:
            mismatched.append({"id": inv, "invoiced": invoices[inv], "paid": p})

result = {
    "unpaid": unpaid,
    "duplicated": duplicated,
    "mismatched": mismatched,
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)

print("ignored memos:", ignored)
print(json.dumps(result, indent=2, ensure_ascii=False))