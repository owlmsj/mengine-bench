"""Match payout. Rules live in docs/ECONOMY.md."""

import math


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    raw = (base + kills * cfg["kill_bonus"]) * cfg["event_multiplier"]
    # Round to the nearest ten; halves always round up (docs/ECONOMY.md).
    # Use ceil(raw/10 - 0.5) so a .5 half rounds up, immune to float error.
    return int(math.ceil(raw / 10 - 0.5) * 10)
