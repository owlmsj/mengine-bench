import csv, json
from collections import defaultdict

pnl = {}
with open('finance/chart_of_accounts.csv', encoding='utf-8') as f:
    r = csv.reader(f, delimiter=';')
    next(r)
    for row in r:
        if len(row) >= 3:
            pnl[row[0]] = row[2]

months = ['2026-01','2026-02','2026-03','2026-04','2026-05','2026-06']
rev = defaultdict(float); cogs = defaultdict(float); opex = defaultdict(float); fin = defaultdict(float)
n = 0
with open('finance/ledger.csv', encoding='utf-8') as f:
    r = csv.reader(f, delimiter=';')
    next(r)
    for row in r:
        if len(row) < 4: continue
        d, acc, desc, amt = row
        day, mon, yr = d.split('/')
        m = f'{yr}-{mon}'
        v = float(amt.replace('.', '').replace(',', '.'))
        line = pnl.get(acc)
        if line is None:
            print('UNMAPPED', acc); continue
        n += 1
        if line == 'revenue': rev[m] += v
        elif line == 'cogs': cogs[m] += v
        elif line == 'financial': fin[m] += v
        else: opex[m] += v

print('entries mapped:', n)
out = {}
ebitda = {}
for m in months:
    g = rev[m] + cogs[m]  # cogs is negative
    e = g + opex[m]       # opex already negative
    gm = (g / rev[m] * 100) if rev[m] else 0.0
    ebitda[m] = e
    out[m] = dict(revenue=round(rev[m],2), gross_margin_pct=round(gm,2), ebitda=round(e,2),
                  cogs=round(cogs[m],2), opex=round(opex[m],2), financial=round(fin[m],2))
    print(m, out[m])

# burn: avg monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = ['2026-04','2026-05','2026-06']
neg = [max(0.0, -ebitda[m]) for m in last3]
burn = sum(neg)/3
cash = 1847350.40
runway = cash/burn
print('last3 ebitda:', [round(ebitda[m],2) for m in last3])
print('burn:', round(burn,2), 'cash:', cash, 'runway:', round(runway,2))

result = {
  "revenue": {m: out[m]['revenue'] for m in months},
  "gross_margin_pct": {m: out[m]['gross_margin_pct'] for m in months},
  "ebitda": {m: out[m]['ebitda'] for m in months},
  "burn": round(burn,2),
  "runway_months": round(runway,2),
}
with open('result.json','w',encoding='utf-8') as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
print('wrote result.json')