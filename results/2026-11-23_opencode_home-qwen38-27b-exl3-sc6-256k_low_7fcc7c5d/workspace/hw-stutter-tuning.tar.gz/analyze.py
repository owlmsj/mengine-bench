import csv, json, statistics

rows = []
with open('capture/presentmon.csv') as f:
    for r in csv.DictReader(f):
        rows.append(r)

btw = [float(r['MsBetweenPresents']) for r in rows]
tsec = [float(r['TimeInSeconds']) for r in rows]
n = len(btw)
print('frames:', n)
print('capture seconds (last TimeInSeconds):', tsec[-1])
mean_ms = statistics.mean(btw)
print('mean MsBetweenPresents:', round(mean_ms, 4))
print('avg fps = 1000/mean:', round(1000/mean_ms, 2))

# p99 of MsBetweenPresents (nearest-rank on sorted values)
srt = sorted(btw)
# linear interpolation percentile
def pct(vals, p):
    vals = sorted(vals)
    k = (len(vals)-1) * p/100
    f = int(k); c = min(f+1, len(vals)-1)
    return vals[f] + (vals[c]-vals[f])*(k-f)
p99 = pct(btw, 99)
print('p99 ms:', round(p99, 4))
print('1% low fps = 1000/p99:', round(1000/p99, 2))

# find hitch frames: MsBetweenPresents > 2x median
med = statistics.median(btw)
print('median ms:', round(med, 3))
hitches = [(i, tsec[i], btw[i]) for i in range(n) if btw[i] > 3*med]
print('frames > 3x median:')
for i, t, ms in hitches:
    print(f'  idx {i} t={t:.3f}s ms={ms:.3f}')

# windows around each hitch: sum ms, count frames
for i, t, ms in hitches:
    lo = max(0, i-2); hi = min(n, i+3)
    print(f'  window t[{lo}:{hi}] times={[round(tsec[j],3) for j in range(lo,hi)]} ms={[round(btw[j],3) for j in range(lo,hi)]}')

# sensor correlation
print('\nsensors with DPC>300 or top!=Arena or link L1:')
with open('capture/sensors.csv') as f:
    for r in csv.DictReader(f):
        if (int(r['dpc_latency_us']) > 300 or r['top_cpu_process'] != 'Arena.exe'
            or r['gpu_pcie_link_state'] == 'L1' or int(r['disk_active_pct']) > 50):
            print(' ', r)