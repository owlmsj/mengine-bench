from PIL import Image, ImageDraw, ImageFont
import os

img = Image.new("RGB", (1200, 675), "#0b3954")
d = ImageDraw.Draw(img)

# simple harbor-ish background: sky gradient + sea + sun
for y in range(675):
    t = y / 675
    r = int(11 + t * 40)
    g = int(57 + t * 60)
    b = int(84 + t * 80)
    d.line([(0, y), (1200, y)], fill=(r, g, b))

# sun
d.ellipse([850, 90, 1010, 250], fill="#ffd166")
# sea
d.rectangle([0, 430, 1200, 675], fill="#132f43")
# waves
for i in range(0, 1200, 60):
    d.arc([i, 420, i + 90, 470], 0, 180, fill="#2a6f97", width=4)
# simple boat
d.polygon([(520, 430), (700, 430), (660, 470), (560, 470)], fill="#e9c46a")
d.polygon([(600, 330), (600, 430), (680, 430)], fill="#f4a261")

# title
font = None
for size in (96, 88, 80, 72):
    try:
        font = ImageFont.truetype("arialbd.ttf", size)
        break
    except Exception:
        try:
            font = ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf", size)
            break
        except Exception:
            font = ImageFont.load_default()
        break

text = "Harbor Day 2026"
bbox = d.textbbox((0, 0), text, font=font)
tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
x = (1200 - tw) // 2 - bbox[0]
y = 120 - bbox[1]
d.text((x + 4, y + 4), text, font=font, fill="#000000")
d.text((x, y), text, font=font, fill="#ffffff")

out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cover.png")
img.save(out, "PNG")
print(out, img.size)