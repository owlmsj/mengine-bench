import sqlite3
DB = r'<WORKSPACE>\analytics.db'
c = sqlite3.connect(DB)
# independent check: per platform, per step, count real users whose first occurrence
# of the step is at/after first occurrence of previous step
steps = ['install','tutorial_complete','first_match','purchase']
for plat in ['pc','steamdeck']:
    for i,s in enumerate(steps):
        q = f"""
        SELECT COUNT(DISTINCT e.user_id) FROM events e
        JOIN users u ON u.user_id=e.user_id
        WHERE u.platform='{plat}' AND u.is_test=0 AND e.name='{s}'
        """
        if i>0:
            q += f""" AND e.ts >= (SELECT MIN(e2.ts) FROM events e2
                    WHERE e2.user_id=e.user_id AND e2.name='{steps[i-1]}')"""
        print(plat, s, c.execute(q).fetchone()[0])
# sanity: any events with names outside steps, or unknown users?
print('other event names:', c.execute("SELECT DISTINCT name FROM events WHERE name NOT IN ('install','tutorial_complete','first_match','purchase')").fetchall())
print('events w/ unknown user:', c.execute("SELECT COUNT(*) FROM events e LEFT JOIN users u ON u.user_id=e.user_id WHERE u.user_id IS NULL").fetchone()[0])
print('test users:', c.execute("SELECT COUNT(*) FROM users WHERE is_test=1").fetchone()[0])