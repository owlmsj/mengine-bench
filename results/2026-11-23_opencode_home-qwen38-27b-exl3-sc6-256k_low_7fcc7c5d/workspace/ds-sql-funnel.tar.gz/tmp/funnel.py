import sqlite3, json

DB = r'<WORKSPACE>\analytics.db'
STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']

c = sqlite3.connect(DB)
users = {uid: (plat, test) for uid, plat, test in c.execute("SELECT user_id, platform, is_test FROM users")}

# first valid occurrence per (user, step): first event at/after previous step's first valid time
# process steps in order; for step i, a user's time is the earliest event for step i
# that is >= the user's valid time for step i-1 (or any time for i==0)
raw = {}  # (uid, step) -> list of ts
for uid, name, ts in c.execute("SELECT user_id, name, ts FROM events"):
    if name not in STEPS:
        continue
    if uid not in users or users[uid][1]:
        continue
    raw.setdefault((uid, name), []).append(ts)

valid_time = {}  # (uid, step) -> first valid ts
for i, step in enumerate(STEPS):
    for (uid, s), tss in raw.items():
        if s != step:
            continue
        if i == 0:
            t = min(tss)
        else:
            prev = valid_time.get((uid, STEPS[i-1]))
            if prev is None:
                continue
            t = min((t for t in tss if t >= prev), default=None)
            if t is None:
                continue
        valid_time[(uid, step)] = t

platforms = sorted({plat for plat, _ in users.values()})
funnel = {}
biggest = {}
for plat in platforms:
    counts = []
    for i, step in enumerate(STEPS):
        # step counts only at/after the player's previous step
        n = 0
        for uid, (p, test) in users.items():
            if p != plat or test:
                continue
            if (uid, step) in valid_time:
                n += 1
        counts.append(n)
    funnel[plat] = dict(zip(STEPS, counts))
    # conversion of step i (i>=1) = counts[i]/counts[i-1]; biggest drop = lowest conversion
    best = None
    for i in range(1, len(STEPS)):
        prev = counts[i-1]
        if prev == 0:
            conv = 0.0
        else:
            conv = counts[i] / prev
        if best is None or conv < best[1]:
            best = (STEPS[i], conv)
    biggest[plat] = best[0]

out = {'funnel': funnel, 'biggest_drop': biggest}
with open(r'<WORKSPACE>\result.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))