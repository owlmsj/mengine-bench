import asyncio

from run import run_tasks


def test_bounded_concurrency_and_completion():
    state = {"running": 0, "peak": 0}
    finished = []

    async def job(i):
        state["running"] += 1
        state["peak"] = max(state["peak"], state["running"])
        try:
            await asyncio.sleep(0.02)
            finished.append(i)
        finally:
            state["running"] -= 1

    asyncio.run(
        run_tasks([(lambda i=i: job(i)) for i in range(10)], 3)
    )
    assert state["peak"] == 3, state
    assert sorted(finished) == list(range(10)), finished
    print("ok: bounded concurrency + all jobs done")


def test_cancel_runs_cleanup():
    cleaned = []

    async def job(i):
        try:
            await asyncio.sleep(30)
        finally:
            cleaned.append(i)

    async def main():
        runner = asyncio.create_task(
            run_tasks([(lambda i=i: job(i)) for i in range(6)], 2)
        )
        await asyncio.sleep(0.05)  # let two jobs start
        runner.cancel()  # simulates what asyncio.run does on Ctrl+C
        try:
            await runner
        except asyncio.CancelledError:
            pass

    asyncio.run(main())
    assert len(cleaned) == 6, cleaned
    print("ok: cancellation still runs job cleanup")


def test_failure_cleans_up_rest():
    cleaned = []

    async def boom():
        raise RuntimeError("job failed")

    async def slow(i):
        try:
            await asyncio.sleep(30)
        finally:
            cleaned.append(i)

    try:
        asyncio.run(
            run_tasks([boom] + [(lambda i=i: slow(i)) for i in range(4)], 4)
        )
    except RuntimeError as exc:
        assert "job failed" in str(exc)
    assert len(cleaned) == 4, cleaned
    print("ok: job failure cancels and cleans up the rest")


if __name__ == "__main__":
    test_bounded_concurrency_and_completion()
    test_cancel_runs_cleanup()
    test_failure_cleans_up_rest()
    print("all ok")
