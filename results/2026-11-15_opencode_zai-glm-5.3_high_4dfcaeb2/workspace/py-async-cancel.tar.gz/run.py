"""Bounded-concurrency async job runner for batch scripts.

Public API::

    from run import run_tasks

    await run_tasks(tasks, max_concurrent)

``tasks`` is an iterable of zero-argument callables; each returns an
awaitable job when called. Standard library only, Python 3.11+.
"""

import asyncio
from typing import Any, Awaitable, Callable, Iterable

__all__ = ["run_tasks"]

TaskFactory = Callable[[], Awaitable[Any]]


async def run_tasks(tasks: Iterable[TaskFactory], max_concurrent: int) -> None:
    """Run every job with at most ``max_concurrent`` running at once.

    Each element of ``tasks`` is called (lazily, only once a concurrency
    slot is free) and the awaitable it returns is awaited. Returns when
    every job has finished.

    On cancellation - e.g. Ctrl+C while running under ``asyncio.run`` -
    the in-flight jobs are cancelled and awaited before the
    ``CancelledError`` is re-raised, so cleanup code inside the jobs
    (``finally`` / ``except asyncio.CancelledError`` blocks) still runs.
    The same happens if any job fails with an exception: the remaining
    jobs get cancelled and cleaned up, then the original error propagates.
    """
    if max_concurrent < 1:
        raise ValueError(
            f"max_concurrent must be >= 1, got {max_concurrent!r}"
        )

    gate = asyncio.Semaphore(max_concurrent)

    async def run_one(make_job: TaskFactory) -> None:
        async with gate:
            # Call the factory only after acquiring a slot, so at most
            # max_concurrent jobs are ever created/awaited at once.
            await make_job()

    wrappers = [asyncio.create_task(run_one(make_job)) for make_job in tasks]
    try:
        await asyncio.gather(*wrappers)
    except BaseException:
        # Cancel the rest, then wait so their finally blocks run before
        # the error/cancellation continues outward.
        for wrapper in wrappers:
            if not wrapper.done():
                wrapper.cancel()
        await asyncio.gather(*wrappers, return_exceptions=True)
        raise
