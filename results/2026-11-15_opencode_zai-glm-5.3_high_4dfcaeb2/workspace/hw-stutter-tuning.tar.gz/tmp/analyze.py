import csv, statistics
from collections import Counter

rows = []
with open(r"capture\presentmon.csv", newline="") as f:
    for r in csv.DictReader(f):
        rows.append((float(r["TimeInSeconds"]), float(r["MsBetweenPresents"])))

fts = [b for _, b in rows]  # frame times ms
n = len(fts)
secs = rows[-1][0] - rows[0][0]
mean_ft = statistics.mean(fts)
avg_fps = n / secs
s = sorted(fts)
p99 = s[int(round(0.99 * n)) - 1]
low1 = 1000 / p99
print(f"frames={n} span={secs:.3f}s mean_ft={mean_ft:.3f}ms avg_fps={avg_fps:.2f} p99_ft={p99:.3f} 1%low={low1:.2f}")

# hitch = frame time > 2x median
med = statistics.median(fts)
hitches = [(t, b) for t, b in rows if b > 2 * med]
print(f"median_ft={med:.3f} hitches(>2x median)={len(hitches)}")

# bucket hitches by whole second
bucket = Counter(int(t) for t, _ in hitches)
print("hitch count per second (only seconds with hitches):")
for sec in sorted(bucket):
    worst = max(b for t, b in hitches if int(t) == sec)
    print(f"  t={sec:3d}  count={bucket[sec]:3d}  worst_ms={worst:.1f}")

# interval between hitch seconds
secs_with = sorted(bucket)
print("seconds with hitches:", secs_with)
diffs = [b - a for a, b in zip(secs_with, secs_with[1:])]
print("gaps:", Counter(diffs).most_common())

# L1 seconds from sensors: t=2,6,10,... i.e. t%4==2
l1_secs = {2, 6, 10, 14, 18, 22, 26, 30, 34, 38, 42, 46, 50, 54, 58}
on_l1 = sum(c for s_, c in bucket.items() if s_ in l1_secs)
off_l1 = sum(c for s_, c in bucket.items() if s_ not in l1_secs)
print(f"hitches on L1 seconds: {on_l1}, elsewhere: {off_l1}")

# defender window 43-45
dfnd = sum(c for s_, c in bucket.items() if 43 <= s_ <= 45)
print(f"hitches in Defender window 43-45: {dfnd}")

# per-second mean frame time to see pattern
print("\nper-second mean frame time (ms) and max:")
by_sec = {}
for t, b in rows:
    by_sec.setdefault(int(t), []).append(b)
for sec in sorted(by_sec):
    v = by_sec[sec]
    tag = "L1" if sec in l1_secs else "  "
    d = "DEF" if 43 <= sec <= 45 else "   "
    print(f"  t={sec:3d} {tag}{d} mean={statistics.mean(v):7.2f} max={max(v):7.1f}")
