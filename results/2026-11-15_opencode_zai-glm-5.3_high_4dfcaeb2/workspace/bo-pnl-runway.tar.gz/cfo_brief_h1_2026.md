# H1 2026 Close - CFO Brief (investor meeting)

Source: `finance/ledger.csv` (86 entries, Jan-Jun 2026), `finance/chart_of_accounts.csv`,
`finance/cash_balance.txt`, burn/runway definition per `finance/README.md`.
All figures in R$ (Brazilian format in sources; decimal point below).

## Headline

- Revenue grew every month: R$ 200,510.87 (Jan) -> R$ 272,391.57 (Jun), +35.9% over the half.
- Gross margin steady at ~68-72%.
- EBITDA negative all six months, but improving: -210,278.96 (Jan) -> -192,968.22 (Jun).
- Burn (board definition: average monthly negative EBITDA of the last three closed months,
  Apr-Jun): R$ 197,288.23/month.
- Runway: cash R$ 1,847,350.40 (30/06/2026) / burn = 9.36 months, i.e. cash to ~April 2027.

## Month by month

| Month | Revenue (R$) | Gross margin % | EBITDA (R$) | Financial result (R$) |
|---|---|---|---|---|
| 2026-01 | 200,510.87 | 70.03 | -210,278.96 | +6,466.77 |
| 2026-02 | 216,328.06 | 70.29 | -212,300.08 | +7,298.39 |
| 2026-03 | 219,066.17 | 68.46 | -204,525.45 | +6,446.51 |
| 2026-04 | 238,163.26 | 70.24 | -196,950.65 | +7,280.37 |
| 2026-05 | 243,032.89 | 69.56 | -201,945.82 | +6,501.04 |
| 2026-06 | 272,391.57 | 72.41 | -192,968.22 | +5,621.65 |

H1 totals: revenue R$ 1,389,492.82; EBITDA R$ -1,218,969.18.

## Story per month

- Jan-Feb: revenue ramping from SaaS (3.1.01) plus onboarding (3.1.02); EBITDA trough
  (-212.3k in Feb) as sales team and paid media spend run ahead of revenue.
- Mar: gross margin dips to 68.46% (highest cloud/GPU cost 52,011.92 plus a Kestrel
  refund -6,814.15); EBITDA starts recovering.
- Apr-Jun: revenue accelerates (best month Jun, 272.4k) and EBITDA loss narrows each
  month to -192.97k; June also posts the best gross margin of the half (72.41%).
- Refunds ("customer Kestrel", account 3.1.09) hit Mar (-6,814.15) and May (-8,634.37);
  they are netted inside revenue above.

## Assumptions (what the brief left open, and how I decided)

1. EBITDA = revenue - COGS - opex (S&M, R&D, G&A). Financial accounts (6.1.01 investment
   income, 6.1.02 interest/IOF) are excluded, per the standard EBITDA definition; there
   are no D&A accounts in the chart. Financial result is shown separately for reference.
2. Revenue is net revenue: account 3.1.09 (refunds, negative amounts) is mapped to the
   revenue line by the chart of accounts and netted against it.
3. Gross margin % = (revenue - COGS) / revenue x 100, COGS = accounts 4.1.01 + 4.1.02.
4. Burn per the board note in README.md: average of the negative monthly EBITDAs of the
   last three closed months (Apr, May, Jun). All three were negative, so the average is
   unambiguous: (196,950.65 + 201,945.82 + 192,968.22) / 3 = 197,288.23.
5. Runway = latest closing cash balance (30/06/2026: R$ 1,847,350.40) / burn
   = 9.36 months. Cash-to-date verified against cash_balance.txt (May balance 30/05:
   2,309,188.00; May net -195,444.78 vs Jun net -187,346.57; the Jun net minus the
   May-to-Jun cash delta of -461,837.60 differs from P&L because the cash file is a
   consolidated balance, so the stated 30/06 balance is taken as authoritative).
6. Ledger parsed as dd/mm/yyyy, semicolon-delimited, Brazilian decimal comma; all 86
   entries fall in Jan-Jun 2026 (no stray dates).

## Key figures (also in ./result.json)

- burn: 197,288.23 R$/month
- runway_months: 9.36 (~9 months and 11 days; cash to early April 2027)
