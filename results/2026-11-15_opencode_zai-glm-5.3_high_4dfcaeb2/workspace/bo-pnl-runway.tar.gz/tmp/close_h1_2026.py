import csv, json
from collections import defaultdict

ACC = {}
with open('../finance/chart_of_accounts.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        ACC[row['account']] = row['pnl_line']

def amt(s):
    return float(s.replace('.', '').replace(',', '.'))

months = defaultdict(lambda: defaultdict(float))
with open('../finance/ledger.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        d, m, y = row['date'].split('/')
        assert y == '2026', row
        key = f"2026-{m}"
        months[key][ACC[row['account']]] += amt(row['amount'])

res = {}
for k in sorted(months):
    m = months[k]
    rev = m['revenue']
    cogs = m['cogs']
    gm = (rev + cogs) / rev * 100  # cogs stored negative
    ebitda = rev + cogs + m['sales_marketing'] + m['rnd'] + m['ga']
    fin = m['financial']
    res[k] = dict(revenue=round(rev, 2), cogs=round(cogs, 2),
                  gross_margin_pct=round(gm, 2), ebitda=round(ebitda, 2),
                  financial=round(fin, 2), net=round(ebitda + fin, 2))
    print(k, res[k])

last3 = [res[f'2026-{m:02d}']['ebitda'] for m in (4, 5, 6)]
neg = [-e for e in last3 if e < 0]
print('last3 ebitda', last3)
if neg:
    burn = sum(neg) / 3
else:
    burn = 0.0
cash = 1847350.40
runway = cash / burn if burn > 0 else None
print('burn', round(burn, 2), 'cash', cash, 'runway', round(runway, 2) if runway else None)

out = {
    'revenue': {k: res[k]['revenue'] for k in res},
    'gross_margin_pct': {k: res[k]['gross_margin_pct'] for k in res},
    'ebitda': {k: res[k]['ebitda'] for k in res},
    'burn': round(burn, 2),
    'runway_months': round(runway, 2) if runway else None,
}
with open('../result.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, indent=2, ensure_ascii=False)
print(json.dumps(out, indent=2, ensure_ascii=False))
