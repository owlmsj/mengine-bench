import sqlite3

con = sqlite3.connect('analytics.db')
cur = con.cursor()
tables = [r[0] for r in con.execute(
    "SELECT name FROM sqlite_master WHERE type IN ('table','view')").fetchall()]
for name in tables:
    sql = con.execute(
        "SELECT sql FROM sqlite_master WHERE name=?", (name,)).fetchone()[0]
    print(name)
    print(sql)
    n = cur.execute(f'SELECT COUNT(*) FROM "{name}"').fetchone()[0]
    print('rows:', n)
    for row in cur.execute(f'SELECT * FROM "{name}" LIMIT 8'):
        print(row)
    print('===')
print('platforms:', cur.execute(
    'SELECT platform, COUNT(*) FROM users GROUP BY platform').fetchall())
print('is_test values:', cur.execute(
    'SELECT is_test, COUNT(*) FROM users GROUP BY is_test').fetchall())
