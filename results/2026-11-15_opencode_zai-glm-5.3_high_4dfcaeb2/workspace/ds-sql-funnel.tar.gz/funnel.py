import sqlite3
from collections import defaultdict

con = sqlite3.connect('analytics.db')
cur = con.cursor()

STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']

print('distinct event names:', cur.execute(
    'SELECT name, COUNT(*) FROM events GROUP BY name').fetchall())
print('events from unknown users:', cur.execute(
    'SELECT COUNT(*) FROM events WHERE user_id NOT IN (SELECT user_id FROM users)').fetchone()[0])
print('events from test users:', cur.execute(
    'SELECT COUNT(*) FROM events e JOIN users u ON e.user_id=u.user_id WHERE u.is_test=1').fetchone()[0])

# events per real player
real = {uid: plat for uid, plat, t in cur.execute(
    'SELECT user_id, platform, is_test FROM users WHERE is_test=0')}
events = defaultdict(lambda: defaultdict(list))  # uid -> step -> [ts]
for uid, name, ts in cur.execute('SELECT user_id, name, ts FROM events'):
    if uid in real and name in STEPS:
        events[uid][name].append(ts)

funnel = {p: {s: 0 for s in STEPS} for p in sorted(set(real.values()))}
strict_players = {p: 0 for p in funnel}

for uid, evs in events.items():
    plat = real[uid]
    prev_ts = None
    counted_all = True
    for step in STEPS:
        ts_list = sorted(evs.get(step, []))
        chosen = None
        if prev_ts is None:
            # first step: first occurrence
            if ts_list:
                chosen = ts_list[0]
        else:
            for t in ts_list:
                if t >= prev_ts:  # at or after previous step's time
                    chosen = t
                    break
        if chosen is None:
            counted_all = False
            break
        funnel[plat][step] += 1
        prev_ts = chosen
    if counted_all:
        strict_players[plat] += 1

print()
for plat in funnel:
    print(plat, funnel[plat])

# conversion + biggest drop
result = {'funnel': {}, 'biggest_drop': {}}
for plat, counts in funnel.items():
    result['funnel'][plat] = counts
    convs = {}
    for i in range(1, len(STEPS)):
        prev, cur_s = STEPS[i-1], STEPS[i]
        c = counts[cur_s] / counts[prev] if counts[prev] else None
        convs[cur_s] = c
    # biggest drop = lowest conversion; tie -> earliest step
    best = None
    for s in STEPS[1:]:
        c = convs[s]
        if c is None:
            continue
        if best is None or c < convs[best]:
            best = s
    result['biggest_drop'][plat] = {'step': best, 'conversion': convs}
    print(plat, 'conversions:', {k: round(v, 4) if v is not None else None for k, v in convs.items()}, '-> drop at', best)

import json
with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2)
print('players completing all steps:', strict_players)
