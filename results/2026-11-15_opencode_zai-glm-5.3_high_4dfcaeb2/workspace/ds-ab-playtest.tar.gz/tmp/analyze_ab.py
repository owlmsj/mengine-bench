import csv, math
from collections import defaultdict

rows = list(csv.DictReader(open('./telemetry/playtest_ab.csv', encoding='utf-8-sig')))
print("raw rows:", len(rows))

# Dedupe by session_id (ETL resends). Check conflicting duplicates.
by_sid = defaultdict(list)
for r in rows:
    by_sid[r['session_id']].append(r)

conflicts = 0
for sid, rs in by_sid.items():
    variants = {r['variant'].strip().lower() for r in rs}
    comps = {r['completed_tutorial'] for r in rs}
    if len(variants) > 1 or len(comps) > 1:
        conflicts += 1
        if conflicts <= 5:
            print("CONFLICT", sid, rs)
print("unique sessions:", len(by_sid), "conflicting dups:", conflicts)

sessions = {}
for sid, rs in by_sid.items():
    r = rs[0]
    sessions[sid] = {
        'variant': r['variant'].strip().lower(),
        'completed': int(r['completed_tutorial']),
    }

# Normalization check: what values exist?
vals = defaultdict(int)
for r in rows:
    vals[repr(r['variant'])] += 1
print("raw variant values:", dict(vals))

va = [s['completed'] for s in sessions.values() if s['variant'] == 'a']
vb = [s['completed'] for s in sessions.values() if s['variant'] == 'b']
other = [s for s in sessions.values() if s['variant'] not in ('a', 'b')]
print("other variants:", len(other))

na, nb = len(va), len(vb)
ca, cb = sum(va), sum(vb)
ra, rb = ca / na, cb / nb
print(f"A: n={na} completed={ca} rate={ra:.4f}")
print(f"B: n={nb} completed={cb} rate={rb:.4f}")

# Two-proportion z-test (pooled), two-sided
pp = (ca + cb) / (na + nb)
se = math.sqrt(pp * (1 - pp) * (1/na + 1/nb))
z = (rb - ra) / se
p_two = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))
print(f"pooled p={pp:.4f} se={se:.6f} z={z:.4f} p(two-sided)={p_two:.6f}")

# Chi-square (unpooled) check via contingency table, with and without continuity correction
try:
    from scipy.stats import chi2_contingency, fisher_exact
    table = [[ca, na - ca], [cb, nb - cb]]
    chi2, p_chi, dof, _ = chi2_contingency(table, correction=True)
    chi2nc, p_chinc, _, _ = chi2_contingency(table, correction=False)
    odds, p_fisher = fisher_exact(table)
    print(f"chi2(corrected) p={p_chi:.6f}  chi2(no corr) p={p_chinc:.6f}  fisher p={p_fisher:.6f}")
except ImportError:
    print("scipy not available")

# Sensitivity: what if we did NOT dedupe?
ra_raw_a = sum(int(r['completed_tutorial']) for r in rows if r['variant'].strip().lower() == 'a')
ra_raw_b = sum(int(r['completed_tutorial']) for r in rows if r['variant'].strip().lower() == 'b')
na_raw = sum(1 for r in rows if r['variant'].strip().lower() == 'a')
nb_raw = sum(1 for r in rows if r['variant'].strip().lower() == 'b')
ppr = (ra_raw_a + ra_raw_b) / (na_raw + nb_raw)
ser = math.sqrt(ppr * (1 - ppr) * (1/na_raw + 1/nb_raw))
zr = (ra_raw_b/nb_raw - ra_raw_a/na_raw) / ser
pr = 2 * (1 - 0.5 * (1 + math.erf(abs(zr) / math.sqrt(2))))
print(f"no-dedupe: A n={na_raw} rate={ra_raw_a/na_raw:.4f}  B n={nb_raw} rate={ra_raw_b/nb_raw:.4f}  p={pr:.6f}")

# One-sided p (B > A)
p_one = 1 - 0.5 * (1 + math.erf(z / math.sqrt(2)))
print(f"one-sided p(B>A)={p_one:.6f}")
