import math

# Deduped contingency: A: 342/900, B: 420/900
ca, na, cb, nb = 342, 900, 420, 900
table = [[ca, na - ca], [cb, nb - cb]]  # [[342,558],[420,480]]

def logcomb(n, k):
    return math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1)

# Fisher exact, two-sided: sum of tables no more likely than observed
n1, n2 = na, nb
col1 = ca + cb
total = na + nb

def prob(x):
    return math.exp(logcomb(n1, x) + logcomb(n2, col1 - x) - logcomb(total, col1))

p_obs = prob(ca)
lo = max(0, col1 - n2)
hi = min(n1, col1)
p_val = sum(prob(x) for x in range(lo, hi + 1) if prob(x) <= p_obs * (1 + 1e-7))
print(f"fisher two-sided p={p_val:.6f}")

# 95% CI for risk difference (unpooled Wald)
ra, rb = ca/na, cb/nb
se = math.sqrt(ra*(1-ra)/na + rb*(1-rb)/nb)
d = rb - ra
print(f"risk diff={d:.4f}  95% CI [{d-1.96*se:.4f}, {d+1.96*se:.4f}]")
