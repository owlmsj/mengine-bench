"""Settings for the backup agent."""

API_URL = "https://backup.example.invalid/v1/upload"
API_TOKEN = "bk_live_FAKE7Qx2Lm9Vt4Rk8Wn3Hd6Pz1Cy5Ja0"
ARCHIVE_DIR = "archives"
