# -*- coding: utf-8 -*-
import json

rich = json.load(open('tmp/rich.json', encoding='utf-8'))
result = json.load(open('result.json', encoding='utf-8'))

PALETTE = {
    'linguagem': '#38bdf8', 'ofícios': '#f59e0b', 'sentimentos': '#fb7185',
    'lugares': '#2dd4bf', 'corpo': '#a78bfa', 'comida': '#fb923c',
    'tempo': '#e879f9', 'natureza': '#4ade80', 'artes': '#fde047',
    'família': '#60a5fa',
}

tpl = open('tmp/universe.template.html', encoding='utf-8').read()
out = (tpl
       .replace('__DATA__', json.dumps(rich, ensure_ascii=False))
       .replace('__RESULT__', json.dumps(result, ensure_ascii=False))
       .replace('__PALETTE__', json.dumps(PALETTE, ensure_ascii=False)))
import os
os.makedirs('universe', exist_ok=True)
open('universe/index.html', 'w', encoding='utf-8').write(out)
print('written', len(out), 'bytes')
