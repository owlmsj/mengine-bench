# -*- coding: utf-8 -*-
import os, re, json, sys
from urllib.parse import unquote

SITE = 'site'
SKIP = {'index.html', 'sobre.html', 'contato.html'}

files = [f for f in os.listdir(SITE) if f.lower().endswith('.html')]
disk_lower = {f.lower(): f for f in files}

pages = {}   # disk filename -> {h1, tema, sin:[], ana:[]}
no_tema = []
for f in sorted(files):
    if f in SKIP:
        continue
    html = open(os.path.join(SITE, f), encoding='utf-8').read()
    m_h1 = re.search(r'<h1>(.*?)</h1>', html)
    m_tema = re.search(r'<p class="tema">Tema:\s*(.*?)</p>', html)
    if not m_tema:
        no_tema.append(f)
        continue
    sin, ana = [], []
    m_sec = re.search(r'<section id="sinonimos">.*?</section>', html, re.S)
    if m_sec:
        sin = re.findall(r'href="([^"]+)"', m_sec.group(0))
    m_sec = re.search(r'<section id="analogas">.*?</section>', html, re.S)
    if m_sec:
        ana = re.findall(r'href="([^"]+)"', m_sec.group(0))
    pages[f] = {'h1': m_h1.group(1).strip() if m_h1 else None,
                'tema': m_tema.group(1).strip(), 'sin': sin, 'ana': ana}

# duplicate H1 check
from collections import Counter
h1s = Counter(p['h1'] for p in pages.values())
dups = {k: v for k, v in h1s.items() if v > 1}

REDIR = {}  # redirect filename -> target filename
for f in files:
    if f in SKIP:
        continue
    html = open(os.path.join(SITE, f), encoding='utf-8').read()
    m = re.search(r'http-equiv="refresh" content="0;\s*url=([^"]+)"', html)
    if m:
        REDIR[f] = unquote(m.group(1))

def resolve(href):
    """href -> disk filename of a word page, following redirects; None if dead"""
    href = unquote(href)
    if not href.lower().endswith('.html'):
        return None
    dl = href.lower()
    if dl in SKIP:
        return None
    if dl not in disk_lower:
        return None  # dead link
    fn = disk_lower[dl]
    if fn in REDIR:
        tgt = REDIR[fn]
        fn = disk_lower.get(tgt.lower())
        if fn is None:
            return None
    return fn if fn in pages else None

words = {}      # canonical -> ordered list of linked canonicals
meta = {}       # canonical -> tema
dead = set()
fname2canon = {fn: p['h1'] for fn, p in pages.items()}

for fn, p in pages.items():
    canon = p['h1']
    meta[canon] = p['tema']
    linked = []  # list of (target, kind)
    for href, kind in [(h, 'sin') for h in p['sin']] + [(h, 'ana') for h in p['ana']]:
        tgt = resolve(href)
        if tgt is None:
            dead.add((canon, unquote(href)))
            continue
        tcanon = fname2canon[tgt]
        if tcanon != canon and tcanon not in [t for t, _ in linked]:
            linked.append((tcanon, kind))
    words[canon] = linked

# plain mapping for words.json
words_plain = {w: [t for t, _ in lst] for w, lst in words.items()}

# undirected pairs + degree
pairs = set()
deg = {w: set() for w in words}
for a, lst in words.items():
    for b, _ in lst:
        key = tuple(sorted([a, b]))
        pairs.add(key)
        deg[a].add(b)
        deg[b].add(b) if False else deg[b].add(a)

most = max(deg, key=lambda w: len(deg[w]))
top = [w for w in deg if len(deg[w]) == len(deg[most])]

result = {
    'words': len(words),
    'relations': len(pairs),
    'most_connected': most if len(top) == 1 else sorted(top),
}

with open('words.json', 'w', encoding='utf-8') as fh:
    json.dump(words_plain, fh, ensure_ascii=False, indent=1)
with open('result.json', 'w', encoding='utf-8') as fh:
    json.dump(result, fh, ensure_ascii=False, indent=1)
# rich data for the visual (embedded in HTML)
rich = {
    'nodes': [{'w': w, 'tema': meta[w]} for w in sorted(words)],
    'links': [{'s': a, 't': b, 'k': k}
              for a, lst in words.items()
              for b, k in lst],
}
with open('tmp/rich.json', 'w', encoding='utf-8') as fh:
    json.dump(rich, fh, ensure_ascii=False)

print('word pages:', len(pages), '| no-tema pages skipped:', no_tema)
print('files total:', len(files))
print('dup h1:', dups)
print('dead links:', sorted(dead))
print('isolated (no links in or out):', [w for w in words if not deg[w]])
print('top degrees:', sorted(((len(v), k) for k, v in deg.items()), reverse=True)[:5])
print(json.dumps(result, ensure_ascii=False))
