# -*- coding: utf-8 -*-
import json, re, collections, os
from urllib.parse import unquote

w = json.load(open('words.json', encoding='utf-8'))
r = json.load(open('result.json', encoding='utf-8'))
pairs = set()
for a, l in w.items():
    for b in l:
        pairs.add(tuple(sorted((a, b))))
deg = collections.Counter()
for a, b in pairs:
    deg[a] += 1; deg[b] += 1
top = [k for k, v in deg.items() if v == max(deg.values())]
print('keys:', len(w), '| pairs:', len(pairs), '| top:', top, max(deg.values()))
print('sum out-links:', sum(len(v) for v in w.values()))
print('result.json:', r)

def read_word(fn):
    p = os.path.join('site', fn)
    if not os.path.exists(p):
        return None
    h = open(p, encoding='utf-8').read()
    m = re.search(r'http-equiv="refresh" content="0;\s*url=([^"]+)"', h)
    if m:
        h = open(os.path.join('site', unquote(m.group(1))), encoding='utf-8').read()
    if 'Tema:' not in h:
        return None
    return re.search(r'<h1>(.*?)</h1>', h).group(1)

for f in ['agua.html', 'tempo.html', 'pao.html', 'carinho.html', 'pulmão.html']:
    h = open(os.path.join('site', f), encoding='utf-8').read()
    h1 = re.search(r'<h1>(.*?)</h1>', h).group(1)
    secs = re.search(r'<section id="sinonimos">.*?</section>\s*<section id="analogas">.*?</section>', h, re.S).group(0)
    names = []
    for href in re.findall(r'href="([^"]+)"', secs):
        n = read_word(unquote(href))
        if n and n != h1 and n not in names:
            names.append(n)
    print(f, '->', h1, names, 'MATCH' if w[h1] == names else 'MISMATCH ' + str(w[h1]))
