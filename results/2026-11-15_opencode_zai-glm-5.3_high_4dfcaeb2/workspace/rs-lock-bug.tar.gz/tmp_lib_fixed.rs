//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        // Mutate under one lock hold: read-then-write with two separate locks
        // loses concurrent updates.
        *slot.lock().unwrap() += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return; // documented no-op; also avoids locking one mutex twice
        }
        let from_slot = self.slot(from);
        let to_slot = self.slot(to);
        // Always lock the smaller id first: opposite transfers locking in
        // opposite order used to deadlock the match threads.
        let (lo_slot, hi_slot) = if from < to {
            (&from_slot, &to_slot)
        } else {
            (&to_slot, &from_slot)
        };
        let mut lo = lo_slot.lock().unwrap();
        let mut hi = hi_slot.lock().unwrap();
        if from < to {
            *lo -= points;
            *hi += points;
        } else {
            *hi -= points;
            *lo += points;
        }
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}
