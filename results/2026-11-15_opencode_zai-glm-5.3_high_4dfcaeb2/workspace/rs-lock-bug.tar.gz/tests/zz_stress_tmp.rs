use arena_scores::Board;
use std::sync::Arc;
use std::thread;

// Regression: lost updates in award/transfer and ABBA deadlock in transfer.
#[test]
fn concurrent_awards_and_opposite_transfers_stay_consistent() {
    let board = Board::new();
    board.join(1, 0);
    board.join(2, 0);
    let b = Arc::new(board);
    let mut handles = Vec::new();
    for t in 0..8 {
        let b = Arc::clone(&b);
        let _ = t;
        handles.push(thread::spawn(move || {
            for _ in 0..2000 {
                b.award(1, 1);
                b.award(2, 1);
                b.transfer(1, 2, 1); // some threads go 1->2 ...
                b.transfer(2, 1, 1); // ... others 2->1 in the same thread
            }
        }));
    }
    for h in handles {
        h.join().unwrap(); // hangs before the fix
    }
    let (s1, s2, total) = (b.score(1), b.score(2), b.total());
    assert_eq!(s1 + s2, total, "per-player scores must sum to the total");
    assert_eq!(total, 8 * 2 * 2000, "every award must be counted");
}
