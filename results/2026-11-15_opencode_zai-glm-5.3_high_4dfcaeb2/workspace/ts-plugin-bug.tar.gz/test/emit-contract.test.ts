import { test } from "node:test";
import assert from "node:assert/strict";
import { HookBus } from "../src/bus.ts";

test("emit runs handlers sequentially in subscription order", async () => {
  const bus = new HookBus();
  const seen: string[] = [];
  bus.on<string>("tool.after", async () => {
    await new Promise((r) => setTimeout(r, 5));
    seen.push("slow-first");
  });
  bus.on<string>("tool.after", () => {
    seen.push("fast-second");
  });
  await bus.emit("tool.after", "x");
  assert.deepEqual(seen, ["slow-first", "fast-second"]);
});

test("emit resolves only after every handler settles", async () => {
  const bus = new HookBus();
  let done = false;
  bus.on<string>("tool.after", async () => {
    await new Promise((r) => setTimeout(r, 5));
    done = true;
  });
  await bus.emit("tool.after", "x");
  assert.equal(done, true);
});

test("a rejecting handler rejects emit with the same error and stops the rest", async () => {
  const bus = new HookBus();
  const boom = new Error("boom");
  const after: string[] = [];
  bus.on<string>("tool.after", () => {
    throw boom;
  });
  bus.on<string>("tool.after", () => {
    after.push("should not run");
  });
  await assert.rejects(bus.emit("tool.after", "x"), (err: unknown) => err === boom);
  assert.deepEqual(after, []);
});

test("unsubscribing during an emit does not stop the others in that emit", async () => {
  const bus = new HookBus();
  const seen: string[] = [];
  const off = bus.on<string>("tool.after", () => {
    off();
    seen.push("self-unsub");
  });
  bus.on<string>("tool.after", async () => {
    seen.push("still-runs");
  });
  await bus.emit("tool.after", "x");
  assert.deepEqual(seen, ["self-unsub", "still-runs"]);
  assert.equal(bus.count("tool.after"), 1);
});
