# Handoff: local-9b Q5 @ 128k ctx

Valid result: with `--no-mmproj-offload -ub 512`, VRAM 7697 MiB, decode 38.0 t/s, median of 3, no spill. That is the Q5 number.

Void: earlier 37.8 t/s @ 7881 MiB sat at the WDDM ceiling; Shared Usage showed 1494 MiB spilled. Discard any run near 7881 MiB.

Quants: Q6_K (7.03 GiB) does not fit at 128k, discarded. Q4_K_M fits (7305 MiB, 40.4 t/s), fallback only.

Applied: recipe in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json. No re-measure after that appears in the record; re-run `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024` to confirm, checking Shared Usage = 0 spill.

Left:
- evals README still cites check_vision.ps1; file no longer exists, update it.
- Review names of scratchpad temp files; noted repeatedly, never done.

Assumptions: 128k = ctx 131072; the repo lives on your side, this record was my only source and it is mostly no-op filler.
