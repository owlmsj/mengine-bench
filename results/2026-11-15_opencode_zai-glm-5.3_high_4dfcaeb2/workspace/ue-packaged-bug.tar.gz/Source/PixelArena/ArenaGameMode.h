#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "ArenaGameMode.generated.h"

class UArenaHud;
class UArenaPalette;
class UArenaScoreTracker;
struct FArenaStats;

UCLASS()
class PIXELARENA_API AArenaGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type Reason) override;

	void OnGoalScored(int32 TeamIndex);

private:
	UPROPERTY()
	TObjectPtr<UArenaHud> Hud;

	UPROPERTY()
	TObjectPtr<UArenaPalette> Palette;

	// Must be UPROPERTY: a NewObject'd UObject is only kept alive through the
	// reflection system. A raw pointer is invisible to GC and gets purged at
	// the next collect, leaving a dangling pointer (PixelArena-shipping.log:
	// "Collecting garbage: 412 objects purged", then AddPoints access violation).
	UPROPERTY()
	TObjectPtr<UArenaScoreTracker> ScoreTracker = nullptr;

	// Plain C++ data owned by this class, freed in EndPlay.
	FArenaStats* Stats = nullptr;
};
