"""Backup agent: packs a folder chosen in the intranet web form and uploads it to the backup API."""

from __future__ import annotations

import logging
import tarfile
import urllib.request
from pathlib import Path

import config

log = logging.getLogger("backup_agent")


def archive_folder(folder: str, out_dir: str = config.ARCHIVE_DIR) -> Path:
    """Packs `folder` into `out_dir/<folder name>.tar.gz` and returns the archive path."""
    # No shell and no external tar: the form text is only ever a filesystem path,
    # so shell metacharacters or tar options typed in the form cannot execute.
    source = Path(folder)
    if not source.is_dir():
        raise ValueError(f"folder {folder!r} is not an existing directory; expected a folder path")
    folder_name = source.resolve().name
    if not folder_name:
        raise ValueError(f"folder {folder!r} has no name; expected a folder below a drive or root")
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    target = out / (folder_name + ".tar.gz")
    with tarfile.open(target, "w:gz") as packed:
        packed.add(source, arcname=folder_name)
    return target


def send_archive(path: Path, url: str, token: str) -> int:
    """Uploads one archive to the backup API and returns the HTTP status."""
    request = urllib.request.Request(url, data=path.read_bytes(), method="POST",
                                     headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.status


def upload(path: Path) -> int:
    """Sends an archive with the API settings; the token is never logged."""
    log.info("uploading %r", str(path))
    return send_archive(path, config.API_URL, config.read_backup_api_token())


def handle_form(form: dict[str, str]) -> int:
    """Web form handler: backs up the folder the user typed."""
    archive = archive_folder(form["folder"])
    log.info("archived %r", str(archive))
    return upload(archive)
