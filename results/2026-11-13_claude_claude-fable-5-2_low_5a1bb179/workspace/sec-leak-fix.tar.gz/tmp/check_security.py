import io, logging, os, sys, tempfile
from pathlib import Path
from unittest import mock
os.environ["BACKUP_TOKEN"] = "secret-check-token-123"
sys.path.insert(0, os.getcwd())
import backup_agent
buf = io.StringIO(); logging.basicConfig(stream=buf, level=logging.DEBUG)
os.chdir(tempfile.mkdtemp(dir=os.path.join(os.getcwd(), "tmp")))
Path("docs").mkdir(); Path("docs/a.txt").write_text("x")
with mock.patch.object(backup_agent, "send_archive", return_value=200) as sent:
    assert backup_agent.handle_form({"folder": "docs"}) == 200
    assert sent.call_args.args[2] == "secret-check-token-123"
    for evil in ["docs; echo pwned > pwned.txt", "docs && echo pwned > pwned.txt", "$(echo pwned > pwned.txt)", "docs | echo pwned > pwned.txt", "--checkpoint-action=exec=echo"]:
        try: backup_agent.handle_form({"folder": evil}); print("NOT REJECTED", evil)
        except ValueError as e: print("rejected:", e)
print("pwned.txt exists:", Path("pwned.txt").exists())
print("token in log:", "secret-check-token-123" in buf.getvalue())
print("log:", buf.getvalue().strip())
