"""Settings for the backup agent."""

import os

API_URL = "https://backup.example.invalid/v1/upload"
API_TOKEN_ENV_VAR = "BACKUP_TOKEN"
ARCHIVE_DIR = "archives"


def read_backup_api_token() -> str:
    """Reads the API token from the environment; it must never live in the code."""
    token = os.environ.get(API_TOKEN_ENV_VAR, "")
    if not token:
        raise RuntimeError(
            f"environment variable {API_TOKEN_ENV_VAR} is unset or empty; expected a non-empty API token")
    return token
