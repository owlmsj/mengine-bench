import { test } from "node:test";
import assert from "node:assert/strict";
import { HookBus } from "./bus.ts";
import { registerAuditPlugin } from "./plugin.ts";

const tick = (ms: number) => new Promise((r) => setTimeout(r, ms));

test("handlers run sequentially in subscription order and emit waits", async () => {
  const bus = new HookBus();
  const seen: string[] = [];
  bus.on("e", async () => { await tick(10); seen.push("slow"); });
  bus.on("e", () => { seen.push("fast"); });
  await bus.emit("e", 1);
  assert.deepEqual(seen, ["slow", "fast"]);
});

test("a failing handler rejects emit with the same error and stops later handlers", async () => {
  const bus = new HookBus();
  const boom = new Error("boom");
  let later = false;
  bus.on("e", async () => { await tick(1); throw boom; });
  bus.on("e", () => { later = true; });
  await assert.rejects(bus.emit("e", 1), (err) => err === boom);
  assert.equal(later, false);
  const sync = new HookBus();
  sync.on("e", () => { throw boom; });
  await assert.rejects(sync.emit("e", 1), (err) => err === boom);
});

test("unsubscribing during an emit does not skip others; applies next emit", async () => {
  const bus = new HookBus();
  const seen: string[] = [];
  const offA = bus.on("e", () => { offA(); offC(); seen.push("a"); });
  bus.on("e", () => { seen.push("b"); bus.on("e", () => { seen.push("new"); }); });
  const offC = bus.on("e", () => { seen.push("c"); });
  await bus.emit("e", 1);
  assert.deepEqual(seen, ["a", "b", "c"]);
  seen.length = 0;
  await bus.emit("e", 1);
  assert.deepEqual(seen, ["b", "new"]);
});

test("same function subscribed twice: each unsubscribe removes only its own", async () => {
  const bus = new HookBus();
  const fn = () => {};
  const off1 = bus.on("e", fn);
  bus.on("e", fn);
  off1(); off1();
  assert.equal(bus.count("e"), 1);
});

test("audit plugin: notice once, redacted output logged, every emit", async () => {
  const bus = new HookBus();
  const audit: string[] = [];
  registerAuditPlugin(bus, audit);
  await bus.emit("tool.after", { tool: "sh", output: "password=hunter2 ok" });
  await bus.emit("tool.after", { tool: "sh", output: "password=x" });
  assert.deepEqual(audit, [
    "notice: tool output is audited",
    "sh: password=[redacted] ok",
    "sh: password=[redacted]",
  ]);
});
