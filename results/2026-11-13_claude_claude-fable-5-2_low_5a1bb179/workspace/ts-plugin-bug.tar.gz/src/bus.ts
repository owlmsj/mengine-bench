/**
 * Hook bus for harness plugins (OpenCode-style hooks). The README states the contract:
 * handlers run one after another in subscription order, emit resolves after all of them,
 * a handler error rejects emit, and unsubscribing during an emit does not stop the others.
 */

export type Handler<T> = (payload: T) => void | Promise<void>;

export class HookBus {
  private handlers: Map<string, { handler: Handler<unknown> }[]> = new Map();

  /** Subscribes a handler to an event; returns the function that unsubscribes it. */
  on<T>(event: string, handler: Handler<T>): () => void {
    const list = this.handlers.get(event) ?? [];
    // One entry object per subscription, so unsubscribing removes exactly this
    // subscription even when the same function is subscribed twice, and a
    // second call of the unsubscribe function is a no-op.
    const entry = { handler: handler as Handler<unknown> };
    list.push(entry);
    this.handlers.set(event, list);
    return () => {
      const index = list.indexOf(entry);
      if (index >= 0) {
        list.splice(index, 1);
      }
    };
  }

  /** Runs the handlers of an event with the payload, one after another, in subscription order. */
  async emit<T>(event: string, payload: T): Promise<void> {
    // Snapshot: handlers (un)subscribed during this emit count from the next emit on.
    const snapshot = [...(this.handlers.get(event) ?? [])];
    for (const entry of snapshot) {
      await entry.handler(payload);
    }
  }

  /** How many handlers an event has. */
  count(event: string): number {
    return (this.handlers.get(event) ?? []).length;
  }
}
