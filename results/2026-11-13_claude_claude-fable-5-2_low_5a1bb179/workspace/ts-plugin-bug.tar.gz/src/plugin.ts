import type { HookBus } from "./bus.ts";

export type ToolResult = { tool: string; output: string };

const PASSWORD = /password=\S+/g;

/** The redaction rules load asynchronously in production (from the workspace settings). */
async function loadRules(): Promise<RegExp> {
  await new Promise((resolve) => setTimeout(resolve, 5));
  return PASSWORD;
}

/** Audit plugin: a one-time notice, then redaction, then the audit log, in that order on every tool.after. */
export function registerAuditPlugin(bus: HookBus, audit: string[]): void {
  const stopNotice = bus.on<ToolResult>("tool.after", () => {
    stopNotice();
    audit.push("notice: tool output is audited");
  });
  bus.on<ToolResult>("tool.after", async (result) => {
    const rule = await loadRules();
    result.output = result.output.replace(rule, "password=[redacted]");
  });
  bus.on<ToolResult>("tool.after", (result) => {
    audit.push(`${result.tool}: ${result.output}`);
  });
}
