import { test } from "node:test";
import assert from "node:assert/strict";
import { HookBus } from "../src/bus.ts";

test("emit calls a subscribed handler with the payload", async () => {
  const bus = new HookBus();
  const seen: string[] = [];
  bus.on<string>("tool.after", (payload) => {
    seen.push(payload);
  });
  await bus.emit("tool.after", "read");
  assert.deepEqual(seen, ["read"]);
});

test("unsubscribe removes the handler", async () => {
  const bus = new HookBus();
  const off = bus.on("tool.after", () => {});
  assert.equal(bus.count("tool.after"), 1);
  off();
  assert.equal(bus.count("tool.after"), 0);
});
