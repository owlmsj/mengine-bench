# harness-hooks

The hook bus our harness plugins use (OpenCode-style hooks such as `tool.before` and `tool.after`).
Plain TypeScript run by Node 24 directly (`npm test` runs `node --test`); no dependencies.

## How the bus behaves

- `bus.on(event, handler)` subscribes a handler and returns a function that unsubscribes it.
- `await bus.emit(event, payload)` runs the handlers of that event one after another, in the order they
  subscribed: each handler finishes (its promise settles) before the next one starts.
- `emit` resolves only after every handler has finished.
- When a handler throws or rejects, `emit` rejects with that same error and the handlers after it do not run.
- `emit` runs the handlers that were subscribed when it started. A handler that unsubscribes itself (or another
  handler) during an emit does not stop the others in that emit; the change counts from the next emit on.

## Plugins

`src/plugin.ts` is the audit plugin: on `tool.after` it shows a one-time notice, redacts passwords from the tool
output, then appends the result to the audit log.
