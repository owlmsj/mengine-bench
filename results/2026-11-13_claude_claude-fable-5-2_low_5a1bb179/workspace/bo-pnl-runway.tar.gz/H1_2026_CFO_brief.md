# H1 2026 close - CFO brief

Values in R$. Source: finance/ledger.csv mapped via chart_of_accounts.csv.

| Month | Revenue (net) | COGS | Gross profit | GM % | S&M | R&D | G&A | EBITDA | Financial | Net result |
|---|---|---|---|---|---|---|---|---|---|---|
| 2026-01 | 200,510.87 | -60,091.92 | 140,418.95 | 70.03 | -143,475.23 | -163,396.33 | -43,826.35 | -210,278.96 | 6,466.77 | -203,812.19 |
| 2026-02 | 216,328.06 | -64,278.71 | 152,049.35 | 70.29 | -138,161.28 | -182,271.02 | -43,917.13 | -212,300.08 | 7,298.39 | -205,001.69 |
| 2026-03 | 219,066.17 | -69,096.05 | 149,970.12 | 68.46 | -135,519.34 | -171,742.87 | -47,233.36 | -204,525.45 | 6,446.51 | -198,078.94 |
| 2026-04 | 238,163.26 | -70,867.73 | 167,295.53 | 70.24 | -139,688.11 | -179,804.44 | -44,753.63 | -196,950.65 | 7,280.37 | -189,670.28 |
| 2026-05 | 243,032.89 | -73,973.13 | 169,059.76 | 69.56 | -138,680.10 | -185,905.30 | -46,420.18 | -201,945.82 | 6,501.04 | -195,444.78 |
| 2026-06 | 272,391.57 | -75,162.69 | 197,228.88 | 72.41 | -151,896.54 | -189,990.01 | -48,310.55 | -192,968.22 | 5,621.65 | -187,346.57 |

- Burn (avg negative EBITDA Apr-Jun 2026): 197,288.23 per month
- Cash on 30/06/2026: 1,847,350.40
- Runway: 9.36 months

## Assumptions
- Revenue is net of refunds (account 3.1.09).
- EBITDA = revenue + COGS + S&M + R&D + G&A; financial lines (6.x) excluded.
- Burn and runway follow the board definition in finance/README.md; cash = 30/06/2026 balance.
- Ledger treated as accrual by entry date; no adjustments made.
