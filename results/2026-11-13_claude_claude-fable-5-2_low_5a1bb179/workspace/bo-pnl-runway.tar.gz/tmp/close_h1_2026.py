import csv, json, sys, collections
fin = sys.argv[1]
def brl(s): return round(float(s.replace('.', '').replace(',', '.')), 2)
line = {r['account']: r['pnl_line'] for r in csv.DictReader(open(fin + '/chart_of_accounts.csv', encoding='utf-8-sig'), delimiter=';')}
rows = list(csv.DictReader(open(fin + '/ledger.csv', encoding='utf-8-sig'), delimiter=';'))
print('rows', len(rows))
seen = collections.Counter((r['date'], r['account'], r['description'], r['amount']) for r in rows)
print('dupes', [k for k, v in seen.items() if v > 1])
agg = collections.defaultdict(lambda: collections.defaultdict(float))
for r in rows:
    d, m, y = r['date'].split('/')
    if r['account'] not in line: print('UNKNOWN', r); continue
    agg[f'{y}-{m}'][line[r['account']]] += brl(r['amount'])
print('months', sorted(agg))
months = [f'2026-{i:02d}' for i in range(1, 7)]
res = {'revenue': {}, 'gross_margin_pct': {}, 'ebitda': {}}
tbl = []
for m in months:
    a = agg[m]; rev = a['revenue']; gp = rev + a['cogs']
    eb = gp + a['sales_marketing'] + a['rnd'] + a['ga']
    res['revenue'][m] = round(rev, 2); res['gross_margin_pct'][m] = round(gp / rev * 100, 2); res['ebitda'][m] = round(eb, 2)
    tbl.append((m, rev, a['cogs'], gp, gp / rev * 100, a['sales_marketing'], a['rnd'], a['ga'], eb, a['financial'], eb + a['financial']))
burn = round(-sum(res['ebitda'][m] for m in months[3:]) / 3, 2)
cash = 1847350.40
res['burn'] = burn; res['runway_months'] = round(cash / burn, 2)
json.dump(res, open('result.json', 'w'), indent=2)
f = lambda x: f'{x:,.2f}'
md = ['# H1 2026 close - CFO brief', '', 'Values in R$. Source: finance/ledger.csv mapped via chart_of_accounts.csv.', '',
 '| Month | Revenue (net) | COGS | Gross profit | GM % | S&M | R&D | G&A | EBITDA | Financial | Net result |', '|---|---|---|---|---|---|---|---|---|---|---|']
for t in tbl: md.append('| ' + ' | '.join([t[0]] + [f(x) for x in t[1:]]) + ' |')
md += ['', f'- Burn (avg negative EBITDA Apr-Jun 2026): {f(burn)} per month',
 f'- Cash on 30/06/2026: {f(cash)}', f'- Runway: {res["runway_months"]} months', '',
 '## Assumptions', '- Revenue is net of refunds (account 3.1.09).', '- EBITDA = revenue + COGS + S&M + R&D + G&A; financial lines (6.x) excluded.',
 '- Burn and runway follow the board definition in finance/README.md; cash = 30/06/2026 balance.',
 '- Ledger treated as accrual by entry date; no adjustments made.']
open('H1_2026_CFO_brief.md', 'w', encoding='utf-8').write('\n'.join(md) + '\n')
print('\n'.join(md)); print(json.dumps(res))
