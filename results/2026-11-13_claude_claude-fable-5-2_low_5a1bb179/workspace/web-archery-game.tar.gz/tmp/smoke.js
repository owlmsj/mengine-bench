const fs=require('fs');const h=fs.readFileSync('game/index.html','utf8');
const src=h.match(/<script>([\s\S]*)<\/script>/)[1];
const L={};const ctx=new Proxy({},{get:(t,k)=>k==='createLinearGradient'?()=>({addColorStop(){}}):(t[k]!==undefined?t[k]:()=>{}),set:(t,k,v)=>{t[k]=v;return true}});
const cv={getContext:()=>ctx,addEventListener:(n,f)=>L[n]=f,getBoundingClientRect:()=>({left:0,top:0,width:960,height:540})};
global.document={getElementById:()=>cv};global.window={addEventListener:(n,f)=>L[n]=f};
global.localStorage={getItem:()=>null,setItem(){}};let now=0;global.performance={now:()=>now};
let raf;global.requestAnimationFrame=f=>raf=f;
eval(src+';global.S=()=>({state,score,lives,popped,shots,nb:balloons.length})');
const step=n=>{for(let i=0;i<n;i++){now+=16;raf(now)}};
const ev=(x,y)=>({clientX:x,clientY:y,preventDefault(){}});
step(5);L.pointerdown(ev(500,300));console.log('start',JSON.stringify(S()));
for(let k=0;k<60;k++){step(40);L.pointerdown(ev(500,300));L.pointermove(ev(500-90-k%5*12,300+30+k%7*8));L.pointerup(ev(0,0));}
console.log('after shooting',JSON.stringify(S()));
L.pointerdown(ev(1,1));step(6000);console.log('idle run',JSON.stringify(S()));
