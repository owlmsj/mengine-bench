import json
import tempfile
import unittest
from pathlib import Path

from arena_server.config.loader import load_config
from arena_server.economy.payout import match_payout
from arena_server.models.profile import Profile
from arena_server.persistence.codec import decode, encode

CFG = {"win_base": 900, "loss_base": 600, "kill_bonus": 50, "event_multiplier": 1.0}


class DocsContract(unittest.TestCase):
    def test_env_beats_file_beats_defaults(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as tmp:
            cfg_file = Path(tmp) / "live.json"
            cfg_file.write_text(json.dumps({"kill_bonus": 60, "win_base": 950}))
            cfg = load_config(cfg_file, env={"ARENA_KILL_BONUS": "75", "ARENA_EVENT_MULTIPLIER": "1.5"})
        self.assertEqual(cfg["kill_bonus"], 75)
        self.assertEqual(cfg["win_base"], 950)
        self.assertEqual(cfg["loss_base"], 600)
        self.assertEqual(cfg["event_multiplier"], 1.5)

    def test_halves_round_up_to_ten(self):
        self.assertEqual(match_payout(True, 0, dict(CFG, win_base=1425)), 1430)
        self.assertEqual(match_payout(True, 0, dict(CFG, win_base=1585)), 1590)
        self.assertEqual(match_payout(False, 3, CFG), 750)
        # 1050 * 1.1 = 1155 exactly; binary floats give 1155.0000000000002 or less
        self.assertEqual(match_payout(True, 3, dict(CFG, event_multiplier=1.1)), 1160)
        # 650 * 1.15 = 747.5 exactly; floats give 747.4999999999999
        self.assertEqual(match_payout(False, 1, dict(CFG, event_multiplier=1.15)), 750)

    def test_credits_survive_codec(self):
        back = decode(encode(Profile("p", level=3, credits=420, cosmetics=["a"])))
        self.assertEqual((back.name, back.level, back.credits, back.cosmetics), ("p", 3, 420, ["a"]))


if __name__ == "__main__":
    unittest.main()
