"""Match payout. Rules live in docs/ECONOMY.md."""

from decimal import ROUND_HALF_UP, Decimal


def _exact(value):
    # str() keeps 1.1 as 1.1, so binary float noise cannot push a half below .5
    return Decimal(str(value))


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    raw = (_exact(base) + kills * _exact(cfg["kill_bonus"])) * _exact(cfg["event_multiplier"])
    return int((raw / 10).quantize(Decimal("1"), rounding=ROUND_HALF_UP)) * 10
