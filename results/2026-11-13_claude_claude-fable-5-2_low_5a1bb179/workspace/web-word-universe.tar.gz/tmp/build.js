const fs=require('fs'),path=require('path');
const dir='site';const files=fs.readdirSync(dir).filter(f=>f.endsWith('.html'));
const byLower={};files.forEach(f=>byLower[f.toLowerCase().normalize('NFC')]=f);
const pages={},redir={};
const resolveHref=h=>{h=decodeURIComponent(h.split('#')[0].split('?')[0]).replace(/^\.\//,'').normalize('NFC');return byLower[h.toLowerCase()]||null;};
for(const f of files){const s=fs.readFileSync(path.join(dir,f),'utf8');
  const r=s.match(/http-equiv="refresh"[^>]*url=([^"'>\s]+)/i);
  if(r){redir[f]=r[1];continue;}
  const tema=s.match(/class="tema">Tema:\s*([^<]*)/);
  if(!tema)continue;
  const h1=s.match(/<h1>([^<]*)<\/h1>/)[1].trim().normalize('NFC');
  const sec=id=>{const m=s.match(new RegExp('<section id="'+id+'">([^]*?)</section>'));return m?[...m[1].matchAll(/href="([^"]*)"/g)].map(x=>x[1]):[];};
  pages[f]={word:h1,tema:tema[1].trim(),sin:sec('sinonimos'),ana:sec('analogas')};}
const final=f=>{let n=0;while(f&&redir[f]&&n++<10)f=resolveHref(redir[f]);return f;};
const words=Object.values(pages).map(p=>p.word);
if(new Set(words.map(w=>w.toLowerCase())).size!==words.length)console.log('DUP WORDS',words.length);
const adj={},kind={};words.forEach(w=>adj[w]=new Set());
let dead=0,self=0,noise=0;
for(const f in pages){const p=pages[f];for(const [k,list] of [['s',p.sin],['a',p.ana]])for(const h of list){
  const t=final(resolveHref(h));if(!t||!pages[t]){dead++;console.log('dead',f,h);continue;}
  const w=pages[t].word;if(w===p.word){self++;continue;}
  adj[p.word].add(w);adj[w].add(p.word);const key=[p.word,w].sort().join('|');if(kind[key]!=='s')kind[key]=k;}}
const cmp=(a,b)=>a.localeCompare(b,'pt');
const out={};words.sort(cmp).forEach(w=>out[w]=[...adj[w]].sort(cmp));
const rel=Object.keys(kind).length;
const maxd=Math.max(...words.map(w=>out[w].length));
const top=words.filter(w=>out[w].length===maxd);
console.log({words:words.length,rel,maxd,top,dead,self,redir,isolated:words.filter(w=>!out[w].length)});
fs.writeFileSync('words.json',JSON.stringify(out,null,1));
fs.writeFileSync('result.json',JSON.stringify({words:words.length,relations:rel,most_connected:top[0]},null,1));
// layout
const temas=[...new Set(Object.values(pages).map(p=>p.tema))].sort(cmp);
const tOf={};Object.values(pages).forEach(p=>tOf[p.word]=temas.indexOf(p.tema));
const N=words.length,idx={};words.forEach((w,i)=>idx[w]=i);
let sd=7;const rnd=()=>(sd=(sd*16807)%2147483647)/2147483647;
const P=words.map(w=>{const a=tOf[w]/temas.length*6.283;return[Math.cos(a)*300+rnd()*80,Math.sin(a)*300+rnd()*80];});
const E=Object.keys(kind).map(k=>k.split('|').map(w=>idx[w]));
for(let it=0;it<500;it++){const F=P.map(()=>[0,0]),c=1-it/500;
  for(let i=0;i<N;i++)for(let j=i+1;j<N;j++){let dx=P[i][0]-P[j][0],dy=P[i][1]-P[j][1],d2=dx*dx+dy*dy+1,f=2500/d2;F[i][0]+=dx*f;F[i][1]+=dy*f;F[j][0]-=dx*f;F[j][1]-=dy*f;}
  for(const[a,b]of E){let dx=P[b][0]-P[a][0],dy=P[b][1]-P[a][1],d=Math.hypot(dx,dy)+.01,f=(d-45)*.03/d*(tOf[words[a]]===tOf[words[b]]?1:.35);F[a][0]+=dx*f;F[a][1]+=dy*f;F[b][0]-=dx*f;F[b][1]-=dy*f;}
  for(let i=0;i<N;i++){F[i][0]-=P[i][0]*.004;F[i][1]-=P[i][1]*.004;const m=Math.hypot(...F[i]),l=Math.min(m,20*c+.5)/(m||1);P[i][0]+=F[i][0]*l;P[i][1]+=F[i][1]*l;}}
const data={temas,nodes:words.map((w,i)=>[w,tOf[w],Math.round(P[i][0]),Math.round(P[i][1])]),edges:Object.keys(kind).map(k=>{const[a,b]=k.split('|');return[idx[a],idx[b],kind[k]];}),aliases:Object.fromEntries(Object.entries(redir).map(([f,t])=>[f.replace('.html',''),pages[final(f)]?.word]))};
fs.writeFileSync('universe/index.html',fs.readFileSync('tmp/tpl.html','utf8').replace('/*DATA*/',()=>JSON.stringify(data)));
