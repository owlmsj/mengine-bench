//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        // Each update happens under one lock hold: the old read-unlock-write
        // sequence let concurrent awards overwrite each other (lost updates).
        *slot.lock().unwrap() += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        // Same player: both slots are one mutex, locking it twice hangs.
        if from == to {
            return;
        }
        let from_slot = self.slot(from);
        let to_slot = self.slot(to);
        // Lock in ascending player id order so opposite transfers (a->b and
        // b->a) cannot each hold one slot while waiting for the other.
        let (mut from_score, mut to_score) = if from < to {
            let f = from_slot.lock().unwrap();
            let t = to_slot.lock().unwrap();
            (f, t)
        } else {
            let t = to_slot.lock().unwrap();
            let f = from_slot.lock().unwrap();
            (f, t)
        };
        *from_score -= points;
        *to_score += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}

#[cfg(test)]
mod concurrency_regression_tests {
    use super::*;
    use std::sync::mpsc;
    use std::thread;
    use std::time::Duration;

    fn finishes_within_10s(work: impl FnOnce() + Send + 'static) {
        let (done_tx, done_rx) = mpsc::channel();
        thread::spawn(move || {
            work();
            let _ = done_tx.send(());
        });
        done_rx
            .recv_timeout(Duration::from_secs(10))
            .expect("board operation hung (deadlock)");
    }

    #[test]
    fn concurrent_awards_lose_no_points() {
        let board = Board::new();
        board.join(1, 0);
        let workers: Vec<_> = (0..8)
            .map(|_| {
                let b = board.clone();
                thread::spawn(move || (0..20_000).for_each(|_| b.award(1, 1)))
            })
            .collect();
        workers.into_iter().for_each(|w| w.join().unwrap());
        assert_eq!(board.score(1), 160_000);
        assert_eq!(board.total(), 160_000);
    }

    #[test]
    fn opposite_transfers_do_not_deadlock() {
        finishes_within_10s(|| {
            let board = Board::new();
            board.join(1, 1_000);
            board.join(2, 1_000);
            let workers: Vec<_> = [(1, 2), (2, 1)]
                .into_iter()
                .map(|(from, to)| {
                    let b = board.clone();
                    thread::spawn(move || (0..50_000).for_each(|_| b.transfer(from, to, 1)))
                })
                .collect();
            workers.into_iter().for_each(|w| w.join().unwrap());
            assert_eq!(board.score(1) + board.score(2), 2_000);
            assert_eq!(board.total(), 2_000);
        });
    }

    #[test]
    fn self_transfer_changes_nothing_and_returns() {
        finishes_within_10s(|| {
            let board = Board::new();
            board.join(7, 50);
            board.transfer(7, 7, 10);
            assert_eq!(board.score(7), 50);
        });
    }
}
