"""Bounded-concurrency runner for batch jobs."""

import asyncio
from collections.abc import Awaitable, Callable, Iterable
from typing import TypeVar

T = TypeVar("T")


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[T]]], max_concurrent: int
) -> list[T]:
    """Run every job, at most max_concurrent at once; return results in task order.

    A task is only called when a slot is free. A failing job does not stop the
    others; after all are done the failure of the earliest task is re-raised.
    On cancellation (Ctrl+C under asyncio.run) running jobs are cancelled and
    awaited, so their finally/except cleanup completes before this re-raises.
    """
    if isinstance(max_concurrent, bool) or not isinstance(max_concurrent, int) or max_concurrent < 1:
        raise ValueError(f"max_concurrent must be an int >= 1, got {max_concurrent!r}")
    task_list = list(tasks)
    results: list[T | None] = [None] * len(task_list)
    failures: dict[int, Exception] = {}
    pending = iter(enumerate(task_list))

    async def slot_worker() -> None:
        for index, task in pending:
            try:
                results[index] = await task()
            except Exception as exc:  # CancelledError is BaseException: propagates
                failures[index] = exc

    workers = [
        asyncio.create_task(slot_worker())
        for _ in range(min(max_concurrent, len(task_list)))
    ]
    try:
        await asyncio.gather(*workers)
    except BaseException:
        for worker in workers:
            worker.cancel()
        # Wait for the jobs' cleanup code before letting the cancellation out.
        await asyncio.gather(*workers, return_exceptions=True)
        raise
    if failures:
        raise failures[min(failures)]
    return results  # type: ignore[return-value]
