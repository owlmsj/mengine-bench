import asyncio, sys
sys.path.insert(0, ".")
from run import run_tasks
live = peak = 0; cleaned = []
def mk(i, fail=False):
    async def job():
        global live, peak
        live += 1; peak = max(peak, live)
        try:
            await asyncio.sleep(0.05)
            if fail: raise RuntimeError(f"boom{i}")
            return i
        finally:
            await asyncio.sleep(0.01); cleaned.append(i); live -= 1
    return job
async def main():
    global peak
    print("results", await run_tasks([mk(i) for i in range(10)], 3), "peak", peak)
    cleaned.clear()
    try: await run_tasks([mk(0), mk(1, True), mk(2)], 2)
    except RuntimeError as e: print("raised", e, "cleaned", sorted(cleaned))
    cleaned.clear()
    t = asyncio.create_task(run_tasks([mk(i) for i in range(6)], 2))
    await asyncio.sleep(0.02); t.cancel()
    try: await t
    except asyncio.CancelledError: print("cancelled; cleaned", sorted(cleaned), "live", live)
    print("empty", await run_tasks([], 2))
asyncio.run(main())
