# HANDOFF: local-9b Q5 at 128k context

Goal (user): local model needs 128k ctx; measure local-9b Q5 there.

## Final result (use these)
- Flags: `--no-mmproj-offload -ub 512`, ctx 131072.
- VRAM 7697 MiB, decode 38.0 t/s (median of 3), no spill.
- Measure: `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`

## Do NOT cite
- First run 37.8 t/s / 7881 MiB: invalid. 7881 is the WDDM ceiling; 1494 MiB spilled to Shared Usage.

## Other quants at 128k
- Q6_K (7.03 GiB): does not fit, discarded.
- Q4_K_M: 7305 MiB, 40.4 t/s; fallback only.

## Applied
- scripts/start_server.ps1:165 (local9 block)
- profiles/local/local-9b.json

## Pending
- Evals README still cites check_vision.ps1, which no longer exists; update it.

## Notes
- Measure only when no download is running (contaminates numbers).
- Short prompt does not reproduce; needs large prefill.
- Not re-verified by me: edits and numbers come from the session log only.
