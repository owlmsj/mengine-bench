import sqlite3,json,collections
c=sqlite3.connect('analytics.db')
print(c.execute('select platform,is_test,count(*) from users group by 1,2').fetchall())
print(c.execute('select name,count(*),min(ts),max(ts),min(length(ts)),max(length(ts)) from events group by 1').fetchall())
print('unknown',c.execute('select count(*) from events where user_id not in (select user_id from users)').fetchone())
print('odd ids',c.execute("select count(*) from users where user_id!=trim(lower(user_id))").fetchone(), c.execute("select count(*) from events where ts is null or user_id is null").fetchone())
S=['install','tutorial_complete','first_match','purchase']
u={r[0]:r[1].strip().lower() for r in c.execute('select user_id,platform from users where coalesce(is_test,0)=0 and platform is not null')}
ev=collections.defaultdict(lambda:collections.defaultdict(list))
for uid,n,ts in c.execute('select user_id,name,ts from events where ts is not null'):
    if uid in u: ev[uid][(n or '').strip().lower()].append(ts)
f={p:{s:0 for s in S} for p in sorted(set(u.values()))}
for uid,e in ev.items():
    prev=''
    for s in S:
        v=[t for t in e.get(s,[]) if t>=prev]
        if not v: break
        prev=min(v); f[u[uid]][s]+=1
bd={}
for p,d in f.items():
    conv={S[i]:d[S[i]]/d[S[i-1]] for i in range(1,4) if d[S[i-1]]}
    bd[p]=min(conv,key=conv.get); print(p,d,{k:round(v,3) for k,v in conv.items()})
json.dump({'funnel':f,'biggest_drop':bd},open('result.json','w'),indent=2)
