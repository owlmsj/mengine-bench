import json, struct, sys
d = open(sys.argv[1], 'rb').read()
ps = struct.unpack('>H', d[16:18])[0] if d[:6] == b'SQLite' else 0
if ps == 1: ps = 65536
if ps < 512 or ps & (ps - 1): ps = 4096
print('size', len(d), 'pagesize', ps, 'hdr', d[:16])
def varint(b, i):
    v = 0
    for k in range(9):
        c = b[i + k]
        if k == 8: return (v << 8) | c, i + 9
        v = (v << 7) | (c & 0x7f)
        if not c & 0x80: return v, i + k + 1
def record(b, i, plen):
    hl, j = varint(b, i); end = i + hl; types = []
    while j < end:
        t, j = varint(b, j); types.append(t)
    vals = []; p = end
    for t in types:
        if t == 0: vals.append(None)
        elif t in (1, 2, 3, 4, 5, 6):
            n = (1, 2, 3, 4, 6, 8)[t - 1]; vals.append(int.from_bytes(b[p:p+n], 'big', signed=True)); assert p + n <= len(b); p += n
        elif t == 7: vals.append(struct.unpack('>d', b[p:p+8])[0]); p += 8
        elif t == 8: vals.append(0)
        elif t == 9: vals.append(1)
        elif t >= 12:
            n = (t - 12) // 2; assert p + n <= len(b)
            raw = b[p:p+n]; p += n
            vals.append(raw.decode('utf-8') if t % 2 else raw)
        else: raise ValueError(t)
    assert p - i == plen, (p - i, plen)
    return vals
rows = []; bad = 0
for pg in range(0, len(d), ps):
    page = d[pg:pg+ps]; h = 100 if (pg == 0 and d[:6] == b'SQLite') else 0
    if len(page) <= h + 8 or page[h] != 0x0d: 
        print('page', pg // ps + 1, 'type', page[h] if len(page) > h else None, 'len', len(page)); continue
    n = struct.unpack('>H', page[h+3:h+5])[0]
    print('page', pg // ps + 1, 'leaf cells', n, 'len', len(page))
    for k in range(n):
        try:
            off = struct.unpack('>H', page[h+8+2*k:h+10+2*k])[0]
            plen, i = varint(page, off); rid, i = varint(page, i)
            vals = record(page, i, plen)
        except Exception as e:
            bad += 1; print(' bad cell', k, repr(e)); continue
        if pg == 0 and d[:6] == b'SQLite': print(' schema', vals); continue
        ti = next((x for x, v in enumerate(vals) if isinstance(v, str)), None)
        if ti is None: bad += 1; print(' skip', vals); continue
        pr = next((v for v in vals[ti+1:] if isinstance(v, (int, float))), None)
        if pr is None: bad += 1; print(' skip', vals); continue
        rows.append({'item': vals[ti], 'price': pr})
print('recovered', len(rows), 'unreadable cells', bad); print(rows[:5], rows[-3:])
json.dump(rows, open(sys.argv[2], 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
