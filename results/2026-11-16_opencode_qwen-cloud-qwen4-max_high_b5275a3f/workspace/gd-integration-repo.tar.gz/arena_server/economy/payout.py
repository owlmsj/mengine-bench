"""Match payout. Rules live in docs/ECONOMY.md."""

from decimal import Decimal, ROUND_HALF_UP


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    # Decimal keeps halves exact (docs/ECONOMY.md: 1425 -> 1430, 1585 -> 1590);
    # binary floats can land just below a half and floor() would round down.
    raw = (Decimal(base) + Decimal(kills) * Decimal(cfg["kill_bonus"])) * Decimal(str(cfg["event_multiplier"]))
    return int(raw.quantize(Decimal("1E1"), rounding=ROUND_HALF_UP))
