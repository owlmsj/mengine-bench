# Handoff: local-9b Q5 @128k (Windows/WDDM)
Valid: `--no-mmproj-offload -ub 512` gives no spill, VRAM 7697 MiB, decode 38.0 t/s (median of 3).
Measure: `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`.
Invalid: first run 37.8 t/s @7881 MiB hit WDDM ceiling; Shared Usage showed 1494 MiB spill. Check Shared Usage, not VRAM alone.
Q6_K (7.03 GiB) does not fit at 128k, discarded. Q4_K_M fits (7305 MiB, 40.4 t/s), fallback only.
Applied: scripts/start_server.ps1:165 (local9 block) + profiles/local/local-9b.json.
TODO: evals README still cites deleted check_vision.ps1; review scratchpad temp-file names; measure only after downloads finish.
Dead ends: --help unhelpful; short-prompt repro useless; diffs formatting-only; git status repeats add nothing.
Assumption: repo is on host, not this workspace; only session/transcript.md was available. Verify files before editing.
Evidence: numbers verbatim from transcript steps 10,15,42,45,63; spill proven by Shared Usage counter.