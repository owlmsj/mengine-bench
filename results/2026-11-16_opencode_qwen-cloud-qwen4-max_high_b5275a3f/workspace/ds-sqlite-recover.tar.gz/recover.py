import struct, json, sys

data = open('prices.db','rb').read()
print('len', len(data), 'magic', data[:16])
ps = struct.unpack('>H', data[16:18])[0]
ps = 65536 if ps == 1 else ps
print('page size', ps, 'pages', len(data)//ps, 'db size hdr', struct.unpack('>I', data[28:32])[0])
print('header rest:', data[16:100].hex())

def varint(b, o):
    v = 0
    for i in range(9):
        c = b[o]; o += 1
        if i == 8:
            v = (v << 8) | c
            return v, o
        v = (v << 7) | (c & 0x7f)
        if not c & 0x80:
            return v, o
    return v, o

def serial(b, o, st):
    if st == 0: return None, o
    if st in (1,2,3,4,5,6):
        n = {1:1,2:2,3:3,4:4,5:6,6:8}[st]
        v = int.from_bytes(b[o:o+n], 'big', signed=True); return v, o+n
    if st == 7:
        v = struct.unpack('>d', b[o:o+8])[0]; return v, o+8
    if st == 8: return 0, o
    if st == 9: return 1, o
    if st >= 12:
        n = (st-12)//2 if st % 2 == 0 else (st-13)//2
        raw = b[o:o+n]
        if st % 2 == 0: return raw, o+n
        try: return raw.decode('utf-8'), o+n
        except Exception: return raw.decode('utf-8','replace'), o+n
    return None, o

rows = []
def parse_page(pno, usable=None):
    base = (pno-1)*ps
    off = base + (100 if pno == 1 else 0)
    if off >= len(data): return
    typ = data[off]
    if typ not in (2,5,10,13):
        print('page', pno, 'type', typ, 'skip'); return
    ncell = struct.unpack('>H', data[off+3:off+5])[0]
    cstart = struct.unpack('>H', data[off+5:off+7])[0]
    ptrbase = off + (12 if typ in (2,5) else 8)
    print('page', pno, 'type', typ, 'cells', ncell, 'content start', cstart)
    for i in range(ncell):
        po = struct.unpack('>H', data[ptrbase+2*i:ptrbase+2*i+2])[0]
        co = base + po
        if co >= len(data): continue
        if typ in (2,5):
            child = struct.unpack('>I', data[co:co+4])[0]
            parse_page(child)
            co += 4
        if typ == 5: continue
        plen, o = varint(data, co)
        rowid, o = varint(data, o)
        recstart = o
        if recstart + plen > len(data):
            print('cell truncated rowid', rowid, 'need', plen, 'have', len(data)-recstart)
        hlen, ho = varint(data, o)
        types = []
        while ho < recstart + hlen:
            st, ho = varint(data, ho)
            types.append(st)
        vals = []
        vo = recstart + hlen
        for st in types:
            v, vo = serial(data, vo, st)
            vals.append(v)
        rows.append((pno, rowid, vals))

for p in range(1, len(data)//ps + 1):
    parse_page(p)

for r in rows:
    print(r)
json.dump(rows, open('raw_rows.json','w'), default=str)