import assert from "node:assert/strict";
import { HookBus } from "../src/bus.ts";
import { registerAuditPlugin } from "../src/plugin.ts";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// 1. Sequential order with async handlers; emit waits for all.
{
  const bus = new HookBus();
  const log: string[] = [];
  bus.on("e", async () => { await sleep(20); log.push("a"); });
  bus.on("e", () => { log.push("b"); });
  bus.on("e", async () => { await sleep(1); log.push("c"); });
  await bus.emit("e", null);
  assert.deepEqual(log, ["a", "b", "c"], "order + await-all");
}

// 2. Failing handler rejects emit with same error; later handlers skipped.
{
  const bus = new HookBus();
  const err = new Error("boom");
  const log: string[] = [];
  bus.on("e", () => { log.push("first"); });
  bus.on("e", async () => { throw err; });
  bus.on("e", () => { log.push("never"); });
  await assert.rejects(bus.emit("e", null), (e) => e === err);
  assert.deepEqual(log, ["first"]);
}

// 3. Unsubscribe during emit does not stop others in that emit; counts next emit.
{
  const bus = new HookBus();
  const log: string[] = [];
  bus.on("e", () => { log.push("a"); offB(); });
  const offB = bus.on("e", () => { log.push("b"); });
  bus.on("e", () => { log.push("c"); });
  await bus.emit("e", null);
  assert.deepEqual(log, ["a", "b", "c"], "snapshot: b still runs this emit");
  log.length = 0;
  await bus.emit("e", null);
  assert.deepEqual(log, ["a", "c"], "b gone next emit");
  // Handler unsubscribing itself mid-emit still lets later handlers run.
  const bus2 = new HookBus();
  const log2: string[] = [];
  const offSelf = bus2.on("e", () => { log2.push("self"); offSelf(); });
  bus2.on("e", () => { log2.push("after"); });
  await bus2.emit("e", null);
  assert.deepEqual(log2, ["self", "after"]);
  log2.length = 0;
  await bus2.emit("e", null);
  assert.deepEqual(log2, ["after"]);
}

// 4. Audit plugin end-to-end: one-time notice, redaction before audit append.
{
  const bus = new HookBus();
  const audit: string[] = [];
  registerAuditPlugin(bus, audit);
  await bus.emit("tool.after", { tool: "shell", output: "login password=hunter2 ok" });
  assert.deepEqual(audit, [
    "notice: tool output is audited",
    "shell: login password=[redacted] ok",
  ]);
  await bus.emit("tool.after", { tool: "read", output: "password=abc" });
  assert.deepEqual(audit, [
    "notice: tool output is audited",
    "shell: login password=[redacted] ok",
    "read: password=[redacted]",
  ], "notice only once");
}

console.log("ALL CONTRACT CHECKS PASSED");