import json
import urllib.request
import http.cookiejar

BASE = "http://127.0.0.1:60348"
_cj = http.cookiejar.CookieJar()
_opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(_cj))


def token(nonce: str) -> str:
    out = ""
    for h in range(4):
        f = 0x811C9DC5
        for ch in nonce + "." + str(h):
            f ^= ord(ch)
            f = (f * 0x01000193) & 0xFFFFFFFF
        out += format(f, "08x")
    return out


import re
import urllib.parse  # noqa: E402


def refresh_token() -> str:
    global K
    with urllib.request.urlopen(BASE + "/", timeout=30) as r:
        html = r.read().decode()
    nonce = re.search(r'name="bh-boot" content="([0-9a-f]+)"', html).group(1)
    K = token(nonce)
    return K


K = refresh_token()


def call(method: str, params=None, body=None, ctype=None):
    url = BASE + "/xrpc/" + method
    if params:
        url += "?" + urllib.parse.urlencode(params)
    data = None
    headers = {}
    if body is not None:
        data = body if isinstance(body, bytes) else json.dumps(body).encode()
        headers["Content-Type"] = ctype or "application/json"
        headers["X-Bh-Token"] = K
    req = urllib.request.Request(url, data=data, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as err:
        detail = err.read().decode(errors="replace")
        raise RuntimeError(f"HTTP {err.code} on {method}: {detail}") from None


import urllib.parse  # noqa: E402

if __name__ == "__main__":
    print("token:", K)
    session = call("com.bluehaze.server.getSession")
    print("session:", json.dumps(session))
    feed = call("app.bluehaze.feed.getTimeline", {"limit": "30"})
    print("timeline count:", len(feed.get("feed", [])))
    for item in feed.get("feed", []):
        p = item["post"]
        print("-", p["uri"], "|", p["author"]["handle"], "|", repr(p["record"]["text"][:80]))
    author = call("app.bluehaze.feed.getAuthorFeed", {"actor": session["handle"], "limit": "30"})
    print("author feed count:", len(author.get("feed", [])))
    for item in author.get("feed", []):
        p = item["post"]
        print("-", p["uri"], "|", repr(p["record"]["text"][:80]))
    with open("baseline.json", "w", encoding="utf-8") as fh:
        json.dump({"session": session, "timeline": feed, "author": author}, fh, indent=1)
    print("baseline saved")