import json
import urllib.error
from bh_api import call

TEXT = "Testing the new Bluehaze uploader: Harbor Day is on."
ALT = "Poster with the title Harbor Day 2026."
COLL = "app.bluehaze.feed.post"

with open("baseline.json", encoding="utf-8") as fh:
    base = json.load(fh)
did = base["session"]["did"]

# sanity: cover.png is a real 1200x675 PNG
from PIL import Image
with Image.open("cover.png") as im:
    assert im.size == (1200, 675) and im.format == "PNG", (im.size, im.format)
print("cover.png verified: 1200x675 PNG")

png = open("cover.png", "rb").read()
up = call("com.bluehaze.repo.uploadBlob", body=png, ctype="image/png")
print("uploadBlob:", json.dumps(up))
blob = up["blob"]

import datetime
record = {
    "$type": COLL,
    "text": TEXT,
    "createdAt": datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z"),
    "embed": {"$type": "app.bluehaze.embed.images", "images": [{"image": blob, "alt": ALT}]},
}
created = call("com.bluehaze.repo.createRecord", body={"repo": did, "collection": COLL, "record": record})
print("createRecord:", json.dumps(created))
uri = created["uri"]
rkey = uri.split("/")[-1]

# verify live post
thread = call("app.bluehaze.feed.getPostThread", {"uri": uri})
post = thread["thread"]["post"]
assert post["record"]["text"] == TEXT, post["record"]["text"]
imgs = post["embed"]["images"]
assert len(imgs) == 1 and imgs[0]["alt"] == ALT, imgs
assert post["author"]["handle"] == "tester.bluehaze.test"
print("live post verified: exact text, 1 image, exact alt")
print("image src:", imgs[0].get("thumb") or imgs[0].get("fullsize"))

tl = call("app.bluehaze.feed.getTimeline", {"limit": "30"})
assert any(i["post"]["uri"] == uri for i in tl["feed"]), "new post missing from timeline"
print("post visible in timeline; total now:", len(tl["feed"]))

# delete only this post
call("com.bluehaze.repo.deleteRecord", body={"repo": did, "collection": COLL, "rkey": rkey})
print("deleteRecord done for", rkey)

# verify gone
try:
    call("app.bluehaze.feed.getPostThread", {"uri": uri})
    raise SystemExit("FAIL: post still exists after delete")
except RuntimeError as e:
    print("post thread after delete ->", e, "(gone)")

def sig(feed):
    return [(i["post"]["uri"], i["post"]["record"]["text"], i["post"].get("cid")) for i in feed["feed"]]

tl2 = call("app.bluehaze.feed.getTimeline", {"limit": "30"})
af2 = call("app.bluehaze.feed.getAuthorFeed", {"actor": "tester.bluehaze.test", "limit": "30"})
assert sig(tl2) == sig(base["timeline"]), "timeline differs from baseline"
assert sig(af2) == sig(base["author"]), "author feed differs from baseline"
assert not any(i["post"]["uri"] == uri for i in tl2["feed"])
print("final timeline identical to baseline:", len(tl2["feed"]), "posts")
print("final author feed identical to baseline:", len(af2["feed"]), "post(s)")
print("CYCLE OK: posted, verified, deleted; nothing else changed")