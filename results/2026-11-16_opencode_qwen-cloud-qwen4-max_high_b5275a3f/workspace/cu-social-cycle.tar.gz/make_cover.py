from PIL import Image, ImageDraw, ImageFont

W, H = 1200, 675
img = Image.new("RGB", (W, H))
d = ImageDraw.Draw(img)

# Sky gradient: deep blue to warm horizon
horizon = 430
for y in range(horizon):
    t = y / horizon
    r = int(24 + (242 - 24) * t)
    g = int(58 + (166 - 58) * t)
    b = int(92 + (90 - 92) * t)
    d.line([(0, y), (W, y)], fill=(r, g, b))
# Water gradient
for y in range(horizon, H):
    t = (y - horizon) / (H - horizon)
    r = int(16 + (8 - 16) * t)
    g = int(42 + (24 - 42) * t)
    b = int(70 + (44 - 70) * t)
    d.line([(0, y), (W, y)], fill=(r, g, b))

# Sun
d.ellipse([880, 250, 1010, 380], fill=(255, 214, 140))
# Sun reflection on water
for i, y in enumerate(range(440, 660, 14)):
    w = 90 - i * 3
    d.rectangle([945 - w // 2, y, 945 + w // 2, y + 5], fill=(255, 200, 120))

# Simple sailboat silhouette
d.polygon([(330, 470), (470, 470), (445, 500), (355, 500)], fill=(10, 20, 34))
d.line([(400, 470), (400, 360)], fill=(10, 20, 34), width=6)
d.polygon([(404, 365), (404, 460), (470, 460)], fill=(16, 30, 48))
d.polygon([(396, 380), (396, 460), (345, 460)], fill=(16, 30, 48))

# Title, large and legible
font = ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf", 108)
title = "Harbor Day 2026"
box = d.textbbox((0, 0), title, font=font)
tw, th = box[2] - box[0], box[3] - box[1]
x = (W - tw) // 2 - box[0]
y = 90 - box[1]
d.text((x + 4, y + 4), title, font=font, fill=(8, 16, 28))
d.text((x, y), title, font=font, fill=(255, 255, 255))

sub = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 34)
st = "A day by the water"
sb = d.textbbox((0, 0), st, font=sub)
d.text(((W - (sb[2] - sb[0])) // 2 - sb[0], 230 - sb[1]), st, font=sub, fill=(255, 236, 200))

img.save("cover.png")
print("saved", img.size, img.format)