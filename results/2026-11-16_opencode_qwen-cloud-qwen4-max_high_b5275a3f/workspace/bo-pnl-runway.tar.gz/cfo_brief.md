# CFO Brief - H1 2026 Close (investor meeting)

Currency: BRL (R$). Source: finance/ledger.csv (86 entries, Jan-Jun 2026),
finance/chart_of_accounts.csv, finance/cash_balance.txt, board definitions in finance/README.md.

## Monthly P&L

| Month | Revenue | COGS | Gross margin % | S&M | R&D | G&A | EBITDA | Financial | Net result |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 2026-01 | 200,510.87 | -60,091.92 | 70.03 | -143,475.23 | -163,396.33 | -43,826.35 | -210,278.96 | 6,466.77 | -203,812.19 |
| 2026-02 | 216,328.06 | -64,278.71 | 70.29 | -138,161.28 | -182,271.02 | -43,917.13 | -212,300.08 | 7,298.39 | -205,001.69 |
| 2026-03 | 219,066.17 | -69,096.05 | 68.46 | -135,519.34 | -171,742.87 | -47,233.36 | -204,525.45 | 6,446.51 | -198,078.94 |
| 2026-04 | 238,163.26 | -70,867.73 | 70.24 | -139,688.11 | -179,804.44 | -44,753.63 | -196,950.65 | 7,280.37 | -189,670.28 |
| 2026-05 | 243,032.89 | -73,973.13 | 69.56 | -138,680.10 | -185,905.30 | -46,420.18 | -201,945.82 | 6,501.04 | -195,444.78 |
| 2026-06 | 272,391.57 | -75,162.69 | 72.41 | -151,896.54 | -189,990.01 | -48,310.55 | -192,968.22 | 5,621.65 | -187,346.57 |

H1 totals: revenue 1,389,492.82; EBITDA -1,218,969.18; net result -1,179,354.45
(financial income net +39,614.73).

## How each month went
- Jan: baseline. Revenue 200.5k, margin 70.0%, EBITDA -210.3k.
- Feb: revenue +7.9% MoM but R&D jumped to 182.3k; worst EBITDA of H1 (-212.3k).
- Mar: revenue nearly flat (+1.3%); refunds of 6,814.15 (Kestrel) and COGS up pushed margin to H1 low 68.5%; EBITDA -204.5k.
- Apr: revenue +8.7% MoM, margin back to 70.2%; EBITDA improves to -197.0k.
- May: revenue +2.0%; refund 8,634.37 (Kestrel) and R&D 185.9k lift burn; EBITDA -201.9k.
- Jun: best month. Revenue +12.1% MoM to 272.4k, margin H1 high 72.4%; EBITDA -193.0k despite S&M spike to 151.9k.

Story for investors: revenue grew every month, +35.8% Jan to Jun; gross margin stable
around 70% and improving; EBITDA loss narrowing slowly (-210k to -193k). R&D is the
largest and fastest-growing cost line (163k to 190k); S&M flat except June push.

## Burn and runway (board definitions, finance/README.md)
- Burn = average monthly negative EBITDA of last 3 closed months (Apr-Jun):
  (196,950.65 + 201,945.82 + 192,968.22) / 3 = **R$ 197,288.23 / month**.
- Latest closing cash (30/06/2026): **R$ 1,847,350.40** (31/05: R$ 2,309,188.00).
- Runway = 1,847,350.40 / 197,288.23 = **9.36 months** (to roughly mid-April 2027).

Risk note: June cash fell 461,837.60 while June net P&L loss was only 187,346.57.
The ~274.5k gap is non-P&L cash movement (working capital / capex / financing);
the ledger contains only P&L accounts, so it cannot be itemized from these files.
If June's actual cash outflow repeated, runway would be 4.0 months. Recommend the
CFO reconcile June cash movements before the meeting and present 9.4 months as the
EBITDA-based board metric with this caveat.

## Assumptions
1. Revenue is net of refunds (account 3.1.09 is mapped to revenue and carries negative entries).
2. EBITDA = revenue - COGS - S&M - R&D - G&A; financial items (6.1.01 investment income,
   6.1.02 interest/IOF) sit below EBITDA per the chart of accounts "financial" line.
3. All three last closed months (Apr-Jun) have negative EBITDA, so burn is the simple
   average of their absolute EBITDA; no ambiguity in the README rule arose.
4. Runway uses the 30/06/2026 consolidated balance, the latest given.
5. Amounts parsed from Brazilian format (1.234,56); results rounded to 2 decimals.
6. No depreciation/amortization or tax accounts exist in the ledger, so EBITDA equals
   operating result here.

## Verification
- All 86 ledger entries mapped to a P&L line via the chart of accounts; 14-15 entries per month.
- Spot-checks by hand: Mar revenue 97,788.41+106,637.50+21,454.41-6,814.15 = 219,066.17;
  May 121,529.70+103,386.50+26,751.06-8,634.37 = 243,032.89;
  Jun 117,305.64+126,381.95+28,703.98 = 272,391.57. All match.
- Burn arithmetic: 591,864.69 / 3 = 197,288.23; runway 1,847,350.40 / 197,288.23 = 9.3637.
- Reproducible: `python compute_close.py` regenerates result.json and the full table.