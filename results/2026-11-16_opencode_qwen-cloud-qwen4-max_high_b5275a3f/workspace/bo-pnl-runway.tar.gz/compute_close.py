"""H1 2026 close: monthly P&L, burn and runway per finance/README.md board definitions."""
import csv
import json
from pathlib import Path

BASE = Path(__file__).parent
FIN = BASE / "finance"
MONTHS = [f"2026-{m:02d}" for m in range(1, 7)]
LINES = ["revenue", "cogs", "sales_marketing", "rnd", "ga", "financial"]


def brl(text: str) -> float:
    return float(text.strip().replace(".", "").replace(",", "."))


pnl_line = {}
with open(FIN / "chart_of_accounts.csv", encoding="utf-8") as fh:
    for row in csv.DictReader(fh, delimiter=";"):
        pnl_line[row["account"]] = row["pnl_line"]

sums = {m: {line: 0.0 for line in LINES} for m in MONTHS}
count = {m: 0 for m in MONTHS}
with open(FIN / "ledger.csv", encoding="utf-8") as fh:
    for row in csv.DictReader(fh, delimiter=";"):
        day, month, year = row["date"].split("/")
        key = f"{year}-{month}"
        line = pnl_line[row["account"]]
        sums[key][line] += brl(row["amount"])
        count[key] += 1

monthly = {}
for m in MONTHS:
    s = sums[m]
    revenue = s["revenue"]
    gross_profit = revenue + s["cogs"]
    ebitda = gross_profit + s["sales_marketing"] + s["rnd"] + s["ga"]
    monthly[m] = {
        "revenue": revenue,
        "cogs": s["cogs"],
        "gross_profit": gross_profit,
        "gross_margin_pct": gross_profit / revenue * 100.0,
        "sales_marketing": s["sales_marketing"],
        "rnd": s["rnd"],
        "ga": s["ga"],
        "ebitda": ebitda,
        "financial": s["financial"],
        "net_result": ebitda + s["financial"],
        "entries": count[m],
    }

# Board definition (finance/README.md): burn = average monthly negative EBITDA
# of the last three closed months (Apr-Jun 2026); runway = latest cash / burn.
last3 = MONTHS[-3:]
neg = {m: -monthly[m]["ebitda"] for m in last3 if monthly[m]["ebitda"] < 0}
burn = sum(neg.values()) / len(neg)

cash_lines = (FIN / "cash_balance.txt").read_text(encoding="utf-8").strip().splitlines()
cash_may = brl(cash_lines[0].split("R$")[1])
cash_jun = brl(cash_lines[-1].split("R$")[1])
runway = cash_jun / burn

result = {
    "revenue": {m: round(monthly[m]["revenue"], 2) for m in MONTHS},
    "gross_margin_pct": {m: round(monthly[m]["gross_margin_pct"], 2) for m in MONTHS},
    "ebitda": {m: round(monthly[m]["ebitda"], 2) for m in MONTHS},
    "burn": round(burn, 2),
    "runway_months": round(runway, 2),
}
(BASE / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")

print(f"{'month':8} {'revenue':>12} {'cogs':>12} {'gm%':>7} {'s&m':>12} {'rnd':>12} {'ga':>12} {'ebitda':>12} {'fin':>10} {'net':>12} n")
for m in MONTHS:
    d = monthly[m]
    print(f"{m:8} {d['revenue']:12.2f} {d['cogs']:12.2f} {d['gross_margin_pct']:7.2f} "
          f"{d['sales_marketing']:12.2f} {d['rnd']:12.2f} {d['ga']:12.2f} {d['ebitda']:12.2f} "
          f"{d['financial']:10.2f} {d['net_result']:12.2f} {d['entries']}")
print(f"\nlast3 EBITDA: {[round(monthly[m]['ebitda'], 2) for m in last3]}")
print(f"burn (avg negative EBITDA Apr-Jun): {burn:.2f}")
print(f"cash 31/05: {cash_may:.2f}  cash 30/06: {cash_jun:.2f}  delta: {cash_jun - cash_may:.2f}")
print(f"June net result (all P&L lines): {monthly['2026-06']['net_result']:.2f}")
print(f"cross-check delta vs June net: {abs((cash_jun - cash_may) - monthly['2026-06']['net_result']):.2f}")
print(f"runway_months: {runway:.4f}")
print(f"total entries: {sum(count.values())}")
print("\nresult.json:")
print(json.dumps(result, indent=2))