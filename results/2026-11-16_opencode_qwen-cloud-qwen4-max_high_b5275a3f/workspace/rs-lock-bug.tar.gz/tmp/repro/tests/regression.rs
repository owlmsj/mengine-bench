//! Regression repro for the match-server hangs and low scores.
//! Lives outside ./tests so the shipped test suite stays untouched.

use arena_scores::Board;
use std::sync::mpsc;
use std::thread;
use std::time::Duration;

/// Runs `f` on a worker thread and fails if it hangs or panics.
fn no_hang(name: &str, f: impl FnOnce() + Send + 'static) {
    let (tx, rx) = mpsc::channel();
    thread::spawn(move || {
        f();
        let _ = tx.send(());
    });
    match rx.recv_timeout(Duration::from_secs(5)) {
        Ok(()) => {}
        Err(mpsc::RecvTimeoutError::Timeout) => panic!("{name}: hung (deadlock)"),
        Err(mpsc::RecvTimeoutError::Disconnected) => panic!("{name}: worker panicked"),
    }
}

#[test]
fn concurrent_awards_lose_no_points() {
    let board = Board::new();
    board.join(1, 0);
    let threads: Vec<_> = (0..8)
        .map(|_| {
            let board = board.clone();
            thread::spawn(move || {
                for _ in 0..1000 {
                    board.award(1, 1);
                }
            })
        })
        .collect();
    for t in threads {
        t.join().unwrap();
    }
    assert_eq!(board.score(1), 8000, "lost award updates");
    assert_eq!(board.total(), 8000, "lost total updates");
}

#[test]
fn self_transfer_is_a_noop_and_does_not_hang() {
    no_hang("self_transfer", || {
        let board = Board::new();
        board.join(1, 10);
        board.transfer(1, 1, 5);
        assert_eq!(board.score(1), 10);
        assert_eq!(board.total(), 10);
    });
}

#[test]
fn opposite_transfers_do_not_deadlock() {
    no_hang("opposite_transfers", || {
        let board = Board::new();
        board.join(1, 100);
        board.join(2, 100);
        let a = {
            let board = board.clone();
            thread::spawn(move || {
                for _ in 0..5000 {
                    board.transfer(1, 2, 1);
                }
            })
        };
        let b = {
            let board = board.clone();
            thread::spawn(move || {
                for _ in 0..5000 {
                    board.transfer(2, 1, 1);
                }
            })
        };
        a.join().unwrap();
        b.join().unwrap();
        assert_eq!(board.total(), 200);
        assert_eq!(board.score(1) + board.score(2), 200);
    });
}