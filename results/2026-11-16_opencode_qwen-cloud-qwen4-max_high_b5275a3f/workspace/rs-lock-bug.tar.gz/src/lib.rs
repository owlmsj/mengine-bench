//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex, MutexGuard, PoisonError};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
///
/// All state sits behind one mutex: every read-modify-write is atomic (no
/// lost awards) and there is no lock ordering to invert (no deadlocks,
/// including transfer-to-self).
#[derive(Clone, Default)]
pub struct Board {
    inner: Arc<Mutex<Scores>>,
}

#[derive(Default)]
struct Scores {
    players: HashMap<PlayerId, i64>,
    total: i64,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    /// A panicking match thread must not take the whole board down with it.
    fn lock(&self) -> MutexGuard<'_, Scores> {
        self.inner.lock().unwrap_or_else(PoisonError::into_inner)
    }

    /// Re-joining replaces the player's score; the total moves by the
    /// difference so it always equals the sum of all player scores.
    pub fn join(&self, id: PlayerId, score: i64) {
        let mut scores = self.lock();
        let old = scores.players.insert(id, score).unwrap_or(0);
        scores.total += score - old;
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let mut scores = self.lock();
        *scores.players.get_mut(&id).expect("award: unknown player") += points;
        scores.total += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return;
        }
        let mut scores = self.lock();
        let from_score = scores.players[&from];
        let to_score = scores.players[&to];
        scores.players.insert(from, from_score - points);
        scores.players.insert(to, to_score + points);
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        self.lock().players[&id]
    }

    pub fn total(&self) -> i64 {
        self.lock().total
    }
}