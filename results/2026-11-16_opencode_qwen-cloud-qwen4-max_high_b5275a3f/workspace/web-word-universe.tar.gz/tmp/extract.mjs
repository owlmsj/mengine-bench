import { readFileSync, writeFileSync, readdirSync } from 'node:fs';

const files = readdirSync('site').filter(f => f.endsWith('.html'));
const skip = new Set(['index.html', 'sobre.html', 'contato.html']);
const slug = f => decodeURIComponent(f.replace(/\.html$/, '')).toLowerCase();
const valid = new Set(files.filter(f => !skip.has(f)).map(slug));

const nodes = {}; // id -> {label, theme}
const out = {};   // id -> [linked ids] (dedup, ordered)
const edgeTypes = new Map(); // "a|b" sorted -> Set(types)
const broken = [];

for (const f of files) {
  if (skip.has(f)) continue;
  const html = readFileSync('site/' + f, 'utf8');
  const id = slug(f);
  const label = (html.match(/<h1>([^<]*)<\/h1>/) || [])[1]?.trim().toLowerCase() || id;
  const theme = (html.match(/Tema:\s*([^<]*)</) || [])[1]?.trim() || 'sem tema';
  nodes[id] = { label, theme };
  const main = html.split('<main>')[1]?.split('</main>')[0] || '';
  const links = [];
  for (const sec of main.matchAll(/<section id="(sinonimos|analogas)">([\s\S]*?)<\/section>/g)) {
    const type = sec[1] === 'sinonimos' ? 'sinonimo' : 'analoga';
    for (const a of sec[2].matchAll(/href="([^"]+)"/g)) {
      const target = slug(a[1].split('/').pop());
      if (!valid.has(target)) { broken.push(`${id} -> ${a[1]}`); continue; }
      if (target === id) continue;
      if (!links.includes(target)) links.push(target);
      const key = [id, target].sort().join('|');
      if (!edgeTypes.has(key)) edgeTypes.set(key, new Set());
      edgeTypes.get(key).add(type);
    }
  }
  out[id] = links;
}

const edges = [...edgeTypes.entries()].map(([k, types]) => {
  const [a, b] = k.split('|');
  return { a, b, types: [...types].sort() };
});
const degree = {};
for (const e of edges) { degree[e.a] = (degree[e.a] || 0) + 1; degree[e.b] = (degree[e.b] || 0) + 1; }
const ranked = Object.keys(nodes).sort((x, y) => (degree[y] || 0) - (degree[x] || 0) || x.localeCompare(y));
const most = ranked[0];
const themes = {};
for (const n of Object.values(nodes)) themes[n.theme] = (themes[n.theme] || 0) + 1;

writeFileSync('words.json', JSON.stringify(out, null, 1));
writeFileSync('tmp/graph.json', JSON.stringify({ nodes, edges, themes }));
writeFileSync('result.json', JSON.stringify({
  words: Object.keys(nodes).length,
  relations: edges.length,
  most_connected: most
}, null, 2));

console.log('words:', Object.keys(nodes).length);
console.log('relations (distinct unordered pairs):', edges.length);
console.log('directed links:', Object.values(out).reduce((s, l) => s + l.length, 0));
console.log('most_connected:', most, 'degree', degree[most]);
console.log('top5:', ranked.slice(0, 5).map(w => `${w}:${degree[w]}`).join(' '));
console.log('themes:', JSON.stringify(themes));
console.log('broken links dropped:', broken.length, broken.slice(0, 8));
console.log('isolated words:', Object.keys(nodes).filter(w => !degree[w]).length);
