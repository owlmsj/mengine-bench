"""Pixel Arena tutorial A/B: dedupe by session_id, normalize variant, two-proportion z-test."""
import csv
import json
import math
from collections import Counter

rows = list(csv.DictReader(open("telemetry/playtest_ab.csv", newline="", encoding="utf-8")))
print("raw rows:", len(rows))

sessions = {}
conflicts = []
for r in rows:
    sid = r["session_id"].strip()
    variant = r["variant"].strip().lower()
    completed = int(r["completed_tutorial"])
    if variant not in ("a", "b"):
        raise ValueError(f"unexpected variant {r['variant']!r} for {sid}")
    if sid in sessions:
        prev = sessions[sid]
        if prev != (variant, completed):
            conflicts.append((sid, prev, (variant, completed)))
    else:
        sessions[sid] = (variant, completed)

print("unique sessions:", len(sessions))
print("conflicting duplicates:", len(conflicts))
for c in conflicts[:10]:
    print("  conflict:", c)

counts = Counter(v for v, _ in sessions.values())
print("variant counts (deduped):", dict(counts))

a = [c for v, c in sessions.values() if v == "a"]
b = [c for v, c in sessions.values() if v == "b"]
na, nb = len(a), len(b)
xa, xb = sum(a), sum(b)
pa, pb = xa / na, xb / nb
print(f"A: {xa}/{na} = {pa:.6f}")
print(f"B: {xb}/{nb} = {pb:.6f}")

# Two-sided two-proportion z-test, pooled variance under H0.
pp = (xa + xb) / (na + nb)
se = math.sqrt(pp * (1 - pp) * (1 / na + 1 / nb))
z = (pb - pa) / se
p_value = math.erfc(abs(z) / math.sqrt(2))  # two-sided normal tail
print(f"pooled p={pp:.6f} se={se:.6f} z={z:.6f} two-sided p={p_value:.6f}")

ship_b = (pb > pa) and (p_value < 0.05)
result = {
    "ship_b": ship_b,
    "sessions_a": na,
    "sessions_b": nb,
    "completion_rate_a": round(pa, 6),
    "completion_rate_b": round(pb, 6),
    "p_value": round(p_value, 6),
}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
    f.write("\n")
print(json.dumps(result, indent=2))
