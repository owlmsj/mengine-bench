import csv, math
from collections import defaultdict

rows = list(csv.DictReader(open("telemetry/playtest_ab.csv", newline="", encoding="utf-8")))
by_sid = defaultdict(list)
for r in rows:
    by_sid[r["session_id"].strip()].append(r)

# Integrity: do repeated session_ids agree on ALL fields (true re-sends)?
full_conflict = 0
player_conflict = 0
dup_groups = 0
for sid, grp in by_sid.items():
    if len(grp) > 1:
        dup_groups += 1
        keys = {tuple(sorted(g.items())) for g in grp}
        if len(keys) > 1:
            full_conflict += 1
        if len({g["player_id"] for g in grp}) > 1:
            player_conflict += 1
print("dup session groups:", dup_groups)
print("groups differing on ANY field:", full_conflict)
print("groups differing on player_id:", player_conflict)

# Build deduped 2x2 (first row per session).
seen = {}
for r in rows:
    sid = r["session_id"].strip()
    if sid not in seen:
        seen[sid] = (r["variant"].strip().lower(), int(r["completed_tutorial"]))
a1 = sum(c for v, c in seen.values() if v == "a")
b1 = sum(c for v, c in seen.values() if v == "b")
na = sum(1 for v, _ in seen.values() if v == "a")
nb = sum(1 for v, _ in seen.values() if v == "b")
a0, b0 = na - a1, nb - b1
print(f"2x2: A completed={a1} not={a0} (n={na}); B completed={b1} not={b0} (n={nb})")

# Chi-square (no continuity correction) == z^2; independent p via erfc.
n = na + nb
tot1 = a1 + b1
tot0 = a0 + b0
chi2 = 0.0
for obs, rowtot in ((a1, na), (a0, na), (b1, nb), (b0, nb)):
    pass
# expected per cell
exp = {(0,0): na*tot1/n, (0,1): na*tot0/n, (1,0): nb*tot1/n, (1,1): nb*tot0/n}
obs = {(0,0): a1, (0,1): a0, (1,0): b1, (1,1): b0}
chi2 = sum((obs[k]-exp[k])**2/exp[k] for k in obs)
p_chi2 = math.erfc(math.sqrt(chi2/2))  # chi2 with 1 df: p = erfc(sqrt(chi2/2))
print(f"chi2={chi2:.6f}  p_chi2={p_chi2:.6f}")

# Fisher exact (two-sided) via hypergeometric, independent of normal approx.
from math import lgamma, exp
def lcomb(n, k):
    return lgamma(n+1) - lgamma(k+1) - lgamma(n-k+1)
def hyper_p(x):
    # P(table with A-completed=x) given margins
    return exp(lcomb(na, x) + lcomb(nb, tot1-x) - lcomb(n, tot1))
p_obs = hyper_p(a1)
lo = max(0, tot1-nb); hi = min(na, tot1)
p_fisher = sum(hyper_p(x) for x in range(lo, hi+1) if hyper_p(x) <= p_obs + 1e-12)
print(f"fisher two-sided p={p_fisher:.6f}")
