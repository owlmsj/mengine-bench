
"use strict";
/* ================= Balloon Archer - Level 1 =================
   Single-file canvas game. Mouse aim, hold-to-draw power,
   physics arrows, rising balloons, combo scoring, 60s timer.
   All audio synthesized with WebAudio (no assets).           */

const W = 960, H = 600, GROUND = 556;
const TARGET = 250, TIME_LIMIT = 60;
const GRAVITY = 980, MIN_SPEED = 430, MAX_SPEED = 1060, DRAW_TIME = 0.85;

const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");
const DPR = Math.min(2, window.devicePixelRatio || 1);
canvas.width = W * DPR; canvas.height = H * DPR;
ctx.setTransform(DPR, 0, 0, DPR, 0, 0);

const stage = document.getElementById("stage");
const overlay = document.getElementById("overlay");
const dlgBar = document.getElementById("dlgBar");
const dlgBody = document.getElementById("dlgBody");
const scoreEl = document.getElementById("scoreVal");
const timeEl = document.getElementById("timeVal");
const timePanel = document.getElementById("timePanel");
const comboPanel = document.getElementById("comboPanel");
const comboEl = document.getElementById("comboVal");
const goalFill = document.getElementById("goalfill");
document.getElementById("goalVal").textContent = "/ " + TARGET;

/* ---------------- state ---------------- */
let state = "menu";            // menu | play | end
let score = 0, timeLeft = TIME_LIMIT, combo = 0, shots = 0, pops = 0;
let best = Number(localStorage.getItem("balloonArcherBest") || 0);
let balloons = [], arrows = [], stuck = [], particles = [], rings = [], floats = [];
let spawnTimer = 0, elapsed = 0, shake = 0;
let mouse = { x: 640, y: 220 };
let drawing = false, drawT = 0, power = 0;
let clouds = [];
for (let i = 0; i < 5; i++) clouds.push({ x: Math.random() * W, y: 40 + Math.random() * 160, s: .6 + Math.random() * .9, v: 6 + Math.random() * 10 });

const ARCHER = { x: 112, y: GROUND };
const SHOULDER = { x: ARCHER.x + 6, y: GROUND - 86 };
const BALLOON_COLORS = ["#e8484f", "#3f8fe8", "#43c04e", "#e8a53f", "#b45fe0", "#e85fa5", "#3fc8c0"];

/* ---------------- audio ---------------- */
let AC = null, master = null, muted = false, noiseBuf = null;
let drawOsc = null, drawGain = null;
function audio() {
  if (!AC) {
    AC = new (window.AudioContext || window.webkitAudioContext)();
    master = AC.createGain(); master.gain.value = muted ? 0 : 0.5; master.connect(AC.destination);
    noiseBuf = AC.createBuffer(1, AC.sampleRate, AC.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  }
  if (AC.state === "suspended") AC.resume();
  return AC;
}
function tone(type, f0, f1, dur, vol, when = 0) {
  const ac = audio(), t = ac.currentTime + when;
  const o = ac.createOscillator(), g = ac.createGain();
  o.type = type; o.frequency.setValueAtTime(f0, t);
  o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
  g.gain.setValueAtTime(vol, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g); g.connect(master); o.start(t); o.stop(t + dur + .02);
}
function noise(dur, vol, filterType, f0, f1, when = 0) {
  const ac = audio(), t = ac.currentTime + when;
  const s = ac.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
  const f = ac.createBiquadFilter(); f.type = filterType; f.Q.value = 1.2;
  f.frequency.setValueAtTime(f0, t);
  f.frequency.exponentialRampToValueAtTime(Math.max(40, f1), t + dur);
  const g = ac.createGain(); g.gain.setValueAtTime(vol, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  s.connect(f); f.connect(g); g.connect(master); s.start(t); s.stop(t + dur + .02);
}
const sfx = {
  click() { tone("square", 720, 500, .05, .12); },
  drawStart() {
    const ac = audio();
    drawOsc = ac.createOscillator(); drawGain = ac.createGain();
    const f = ac.createBiquadFilter(); f.type = "lowpass"; f.frequency.value = 320;
    drawOsc.type = "sawtooth"; drawOsc.frequency.value = 55;
    drawGain.gain.value = 0;
    drawOsc.connect(f); f.connect(drawGain); drawGain.connect(master);
    drawOsc.start();
    drawGain.gain.linearRampToValueAtTime(.06, ac.currentTime + .1);
  },
  drawUpdate(p) { if (drawOsc) drawOsc.frequency.value = 55 + p * 90; },
  drawStop() {
    if (!drawOsc) return;
    const ac = audio(), o = drawOsc, g = drawGain;
    drawOsc = null; drawGain = null;
    g.gain.cancelScheduledValues(ac.currentTime);
    g.gain.setValueAtTime(g.gain.value, ac.currentTime);
    g.gain.linearRampToValueAtTime(0, ac.currentTime + .04);
    o.stop(ac.currentTime + .06);
  },
  loose(p) {
    tone("triangle", 200 + p * 60, 70, .13, .3);
    noise(.16 + p * .1, .10 + p * .12, "bandpass", 500, 1800);
  },
  pop(c, gold) {
    const pitch = 1 + Math.min(c, 12) * .05;
    noise(.07, .5, "highpass", 900, 1400);
    tone("sine", 520 * pitch, 130, .1, .35);
    if (gold) { tone("sine", 880, 880, .09, .22, .03); tone("sine", 1318, 1318, .12, .22, .11); }
  },
  thud() { tone("sine", 110, 48, .12, .3); noise(.05, .12, "lowpass", 300, 120); },
  win() { [523, 659, 784, 1047].forEach((f, i) => tone("triangle", f, f, .16, .25, i * .12)); },
  lose() { [392, 330, 262].forEach((f, i) => tone("sawtooth", f, f * .97, .22, .14, i * .17)); }
};
function setMuted(m) {
  muted = m;
  if (master) master.gain.value = m ? 0 : 0.5;
  document.getElementById("muteBtn").style.opacity = m ? .45 : 1;
}
document.getElementById("muteBtn").addEventListener("click", () => { audio(); setMuted(!muted); sfx.click(); });

/* ---------------- dialogs ---------------- */
function showMenu() {
  state = "menu";
  overlay.classList.remove("hidden");
  dlgBar.textContent = "Welcome";
  dlgBody.innerHTML =
    "<h1>BALLOON ARCHER</h1>" +
    "<div class='sub'>Level 1 - Meadow Range</div>" +
    "<div class='rules'>" +
    "<b>AIM</b> with the mouse. <b>HOLD</b> to draw the bow, <b>RELEASE</b> to loose.<br>" +
    "Score <b>" + TARGET + " points</b> before the 60 seconds run out.<br>" +
    "Balloons = 10 pts &middot; <b>gold</b> = 50 pts &middot; chain hits for a combo multiplier.<br>" +
    "Arrows pierce - line up two balloons for a double!" +
    "</div>" +
    (best > 0 ? "<div class='sub'>Best score: " + best + "</div>" : "") +
    "<button class='bigbtn' id='startBtn'>START</button>";
  document.getElementById("startBtn").addEventListener("click", () => { audio(); sfx.click(); startGame(); });
  document.getElementById("startBtn").focus();
}
function showEnd(won, bonus) {
  state = "end";
  drawing = false; sfx.drawStop();
  overlay.classList.remove("hidden");
  best = Math.max(best, score);
  localStorage.setItem("balloonArcherBest", String(best));
  dlgBar.textContent = won ? "Level Complete" : "Game Over";
  dlgBody.innerHTML =
    "<h2 style='color:" + (won ? "#006000" : "#a00000") + "'>" + (won ? "LEVEL CLEAR!" : "TIME'S UP!") + "</h2>" +
    "<div class='stats'>Score: <b>" + score + "</b>" + (bonus ? " <span class='gold'>(+" + bonus + " time bonus)</span>" : "") + "<br>" +
    "Balloons popped: " + pops + " &middot; Shots: " + shots + "<br>" +
    "Best: " + best + "</div>" +
    "<button class='bigbtn' id='againBtn'>" + (won ? "PLAY AGAIN" : "TRY AGAIN") + "</button>";
  document.getElementById("againBtn").addEventListener("click", () => { sfx.click(); startGame(); });
  document.getElementById("againBtn").focus();
  if (won) sfx.win(); else sfx.lose();
}
document.getElementById("closeBtn").addEventListener("click", () => { if (state !== "menu") { sfx.click(); showMenu(); } });

function startGame() {
  score = 0; timeLeft = TIME_LIMIT; combo = 0; shots = 0; pops = 0;
  balloons = []; arrows = []; stuck = []; particles = []; rings = []; floats = [];
  spawnTimer = .4; elapsed = 0; shake = 0; drawing = false; power = 0;
  for (let i = 0; i < 4; i++) spawnBalloon(120 + Math.random() * 320);
  overlay.classList.add("hidden");
  state = "play";
}

/* ---------------- input ---------------- */
function toGame(e) {
  const r = canvas.getBoundingClientRect();
  return { x: (e.clientX - r.left) * W / r.width, y: (e.clientY - r.top) * H / r.height };
}
stage.addEventListener("pointermove", e => { mouse = toGame(e); });
stage.addEventListener("pointerdown", e => {
  if (e.button !== 0) return;
  audio();
  mouse = toGame(e);
  if (state === "play" && !drawing) { drawing = true; drawT = 0; power = 0; sfx.drawStart(); }
});
window.addEventListener("pointerup", e => {
  if (e.button !== 0 || !drawing) return;
  drawing = false; sfx.drawStop();
  if (state === "play" && power > .07) fire();
  power = 0;
});
stage.addEventListener("contextmenu", e => e.preventDefault());
window.addEventListener("keydown", e => {
  if (e.key === "m" || e.key === "M") { audio(); setMuted(!muted); }
  if ((e.key === "r" || e.key === "R") && state !== "menu") { audio(); sfx.click(); startGame(); }
  if ((e.key === "Enter" || e.key === " ") && state === "menu") { audio(); sfx.click(); startGame(); }
});
window.addEventListener("blur", () => { if (drawing) { drawing = false; power = 0; sfx.drawStop(); } });

/* ---------------- entities ---------------- */
function aimAngle() {
  const dx = mouse.x - SHOULDER.x, dy = mouse.y - SHOULDER.y;
  let a = Math.atan2(dy, dx);
  return Math.max(-1.5, Math.min(.35, a));
}
function fire() {
  const a = aimAngle();
  const speed = MIN_SPEED + (MAX_SPEED - MIN_SPEED) * power;
  const hx = SHOULDER.x + Math.cos(a) * 30, hy = SHOULDER.y + Math.sin(a) * 30;
  arrows.push({ x: hx, y: hy, vx: Math.cos(a) * speed, vy: Math.sin(a) * speed, px: hx, py: hy });
  shots++;
  sfx.loose(power);
  shake = Math.max(shake, 1.5 + power * 2);
}
function spawnBalloon(startY) {
  const gold = Math.random() < .13;
  const r = gold ? 14 + Math.random() * 5 : 19 + Math.random() * 11;
  balloons.push({
    baseX: 190 + Math.random() * (W - 250),
    y: startY !== undefined ? startY : H + 50,
    r, gold,
    vy: -(gold ? 115 + Math.random() * 45 : 46 + Math.random() * 50),
    amp: 10 + Math.random() * 18, freq: .8 + Math.random() * 1.2, phase: Math.random() * 6.28,
    color: gold ? "#f5c518" : BALLOON_COLORS[(Math.random() * BALLOON_COLORS.length) | 0],
    x: 0, t: 0
  });
}
function popBalloon(b, arrow) {
  b.dead = true;
  combo++; pops++;
  const mult = 1 + Math.min(4, Math.floor((combo - 1) / 3));
  const pts = (b.gold ? 50 : 10) * mult;
  score += pts;
  sfx.pop(combo, b.gold);
  shake = Math.max(shake, b.gold ? 6 : 3.5);
  rings.push({ x: b.x, y: b.y, r: b.r, life: .28, max: .28, color: b.color });
  for (let i = 0; i < 12; i++) {
    const a = Math.random() * 6.28, sp = 90 + Math.random() * 240;
    particles.push({ x: b.x, y: b.y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 60,
      life: .45 + Math.random() * .35, max: .8, color: b.color, rot: Math.random() * 6.28, vr: (Math.random() - .5) * 14, s: 3 + Math.random() * 5 });
  }
  floats.push({ x: b.x, y: b.y - b.r, text: "+" + pts + (mult > 1 ? "  x" + mult : ""), life: .9, max: .9, color: b.gold ? "#f5c518" : "#ffffff" });
  if (score >= TARGET) {
    const bonus = Math.ceil(timeLeft) * 5;
    score += bonus;
    showEnd(true, bonus);
  }
}
function distToSeg(px, py, ax, ay, bx, by) {
  const dx = bx - ax, dy = by - ay;
  const l2 = dx * dx + dy * dy;
  let t = l2 ? ((px - ax) * dx + (py - ay) * dy) / l2 : 0;
  t = Math.max(0, Math.min(1, t));
  const cx = ax + dx * t, cy = ay + dy * t;
  return Math.hypot(px - cx, py - cy);
}

/* ---------------- update ---------------- */
function update(dt) {
  elapsed += dt;
  for (const c of clouds) { c.x += c.v * dt; if (c.x > W + 120) c.x = -140; }
  if (state !== "play") { shake = Math.max(0, shake - dt * 20); return; }

  timeLeft -= dt;
  if (timeLeft <= 0) { timeLeft = 0; showEnd(false, 0); return; }

  if (drawing) {
    drawT += dt;
    power = Math.min(1, drawT / DRAW_TIME);
    sfx.drawUpdate(power);
  }

  spawnTimer -= dt;
  if (spawnTimer <= 0 && balloons.length < 12) {
    spawnBalloon();
    spawnTimer = Math.max(.5, 1.15 - elapsed * .011);
  }

  for (const b of balloons) {
    b.t += dt;
    b.y += b.vy * dt;
    b.x = b.baseX + Math.sin(b.t * b.freq + b.phase) * b.amp;
    if (b.y < -70) b.dead = true;
  }

  for (const ar of arrows) {
    ar.px = ar.x; ar.py = ar.y;
    ar.vy += GRAVITY * dt;
    ar.x += ar.vx * dt; ar.y += ar.vy * dt;
    const a = Math.atan2(ar.vy, ar.vx);
    const tx = ar.x + Math.cos(a) * 22, ty = ar.y + Math.sin(a) * 22;
    const ptx = ar.px + Math.cos(a) * 22, pty = ar.py + Math.sin(a) * 22;
    for (const b of balloons) {
      if (b.dead) continue;
      if (distToSeg(b.x, b.y, ptx, pty, tx, ty) < b.r + 2) popBalloon(b, ar);
      if (state !== "play") break;
    }
    if (state !== "play") break;
    if (ar.y >= GROUND - 2 && ar.vy > 0) {
      ar.dead = true;
      stuck.push({ x: ar.x, y: GROUND, a: Math.max(.5, Math.min(1.4, a)), life: 2.2 });
      sfx.thud();
      if (combo > 0) floats.push({ x: ar.x, y: GROUND - 24, text: "combo lost", life: .7, max: .7, color: "#ffd0d0" });
      combo = 0;
    } else if (ar.x > W + 80 || ar.x < -80 || ar.y > H + 80) {
      ar.dead = true; combo = 0;
    }
  }

  balloons = balloons.filter(b => !b.dead);
  arrows = arrows.filter(a => !a.dead);
  for (const s of stuck) s.life -= dt;
  stuck = stuck.filter(s => s.life > 0);
  for (const p of particles) { p.life -= dt; p.vy += 560 * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.vr * dt; }
  particles = particles.filter(p => p.life > 0);
  for (const r of rings) r.life -= dt;
  rings = rings.filter(r => r.life > 0);
  for (const f of floats) { f.life -= dt; f.y -= 46 * dt; }
  floats = floats.filter(f => f.life > 0);
  shake = Math.max(0, shake - dt * 22);
}

/* ---------------- drawing ---------------- */
function drawBackground() {
  const sky = ctx.createLinearGradient(0, 0, 0, H);
  sky.addColorStop(0, "#6db9f2"); sky.addColorStop(.65, "#b8e2fb"); sky.addColorStop(1, "#e6f6ff");
  ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H);
  // sun
  ctx.fillStyle = "rgba(255,240,160,.9)";
  ctx.beginPath(); ctx.arc(W - 110, 84, 38, 0, 6.29); ctx.fill();
  ctx.strokeStyle = "rgba(255,240,160,.5)"; ctx.lineWidth = 3;
  for (let i = 0; i < 8; i++) {
    const a = i * Math.PI / 4 + elapsed * .05;
    ctx.beginPath();
    ctx.moveTo(W - 110 + Math.cos(a) * 46, 84 + Math.sin(a) * 46);
    ctx.lineTo(W - 110 + Math.cos(a) * 58, 84 + Math.sin(a) * 58);
    ctx.stroke();
  }
  // clouds
  ctx.fillStyle = "rgba(255,255,255,.92)";
  for (const c of clouds) {
    ctx.beginPath();
    ctx.arc(c.x, c.y, 22 * c.s, 0, 6.29);
    ctx.arc(c.x + 24 * c.s, c.y + 6 * c.s, 18 * c.s, 0, 6.29);
    ctx.arc(c.x - 24 * c.s, c.y + 8 * c.s, 16 * c.s, 0, 6.29);
    ctx.fill();
  }
  // hills
  ctx.fillStyle = "#7cc96f";
  ctx.beginPath(); ctx.ellipse(230, GROUND + 60, 340, 130, 0, Math.PI, 0); ctx.fill();
  ctx.fillStyle = "#69bb5e";
  ctx.beginPath(); ctx.ellipse(760, GROUND + 80, 420, 160, 0, Math.PI, 0); ctx.fill();
  // ground
  ctx.fillStyle = "#3fae4a"; ctx.fillRect(0, GROUND, W, H - GROUND);
  ctx.fillStyle = "#2f8f3a"; ctx.fillRect(0, GROUND, W, 5);
  ctx.strokeStyle = "#2f8f3a"; ctx.lineWidth = 2;
  for (let i = 0; i < 40; i++) {
    const gx = (i * 97 + 31) % W;
    ctx.beginPath(); ctx.moveTo(gx, GROUND + 12); ctx.lineTo(gx + 3, GROUND + 4); ctx.stroke();
  }
}
function drawBalloon(b) {
  const wob = 1 + Math.sin(b.t * 3 + b.phase) * .03;
  ctx.save();
  ctx.translate(b.x, b.y);
  // string
  ctx.strokeStyle = "rgba(60,60,60,.7)"; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(0, b.r * 1.12);
  ctx.quadraticCurveTo(Math.sin(b.t * 2) * 8, b.r + 26, Math.sin(b.t * 1.4) * 5, b.r + 46);
  ctx.stroke();
  if (b.gold) { ctx.shadowColor = "#f5c518"; ctx.shadowBlur = 16; }
  const g = ctx.createRadialGradient(-b.r * .35, -b.r * .4, b.r * .15, 0, 0, b.r * 1.2);
  g.addColorStop(0, "#ffffff"); g.addColorStop(.25, b.color); g.addColorStop(1, shade(b.color, -.35));
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.ellipse(0, 0, b.r * .92 * wob, b.r * 1.08, 0, 0, 6.29); ctx.fill();
  ctx.shadowBlur = 0;
  // knot
  ctx.fillStyle = shade(b.color, -.3);
  ctx.beginPath(); ctx.moveTo(-4, b.r * 1.06); ctx.lineTo(4, b.r * 1.06); ctx.lineTo(0, b.r * 1.2); ctx.closePath(); ctx.fill();
  // shine
  ctx.fillStyle = "rgba(255,255,255,.55)";
  ctx.beginPath(); ctx.ellipse(-b.r * .34, -b.r * .42, b.r * .2, b.r * .3, -.5, 0, 6.29); ctx.fill();
  if (b.gold) {
    ctx.fillStyle = "#7a5200"; ctx.font = "20px VT323, monospace"; ctx.textAlign = "center";
    ctx.fillText("50", 0, 7);
  }
  ctx.restore();
}
function shade(hex, amt) {
  const n = parseInt(hex.slice(1), 16);
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  r = Math.max(0, Math.min(255, Math.round(r * (1 + amt))));
  g = Math.max(0, Math.min(255, Math.round(g * (1 + amt))));
  b = Math.max(0, Math.min(255, Math.round(b * (1 + amt))));
  return "rgb(" + r + "," + g + "," + b + ")";
}
function drawArcher() {
  const a = aimAngle();
  const pull = drawing ? power * 17 : 0;
  ctx.save();
  ctx.translate(ARCHER.x, ARCHER.y);
  // legs
  ctx.strokeStyle = "#5a3a1e"; ctx.lineWidth = 7; ctx.lineCap = "round";
  ctx.beginPath(); ctx.moveTo(0, -44); ctx.lineTo(-10, 0); ctx.moveTo(0, -44); ctx.lineTo(12, 0); ctx.stroke();
  // quiver
  ctx.save(); ctx.translate(-14, -66); ctx.rotate(.35);
  ctx.fillStyle = "#8a5a2a"; ctx.fillRect(-5, -14, 10, 30);
  ctx.strokeStyle = "#d8d8d8"; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(-2, -14); ctx.lineTo(-4, -22); ctx.moveTo(2, -14); ctx.lineTo(2, -23); ctx.stroke();
  ctx.restore();
  // body tunic
  ctx.fillStyle = "#2e7d32";
  ctx.beginPath(); ctx.moveTo(-11, -84); ctx.lineTo(11, -84); ctx.lineTo(14, -42); ctx.lineTo(-14, -42); ctx.closePath(); ctx.fill();
  ctx.fillStyle = "#7a4a20"; ctx.fillRect(-14, -52, 28, 5);
  // head + hood
  ctx.fillStyle = "#f0c090"; ctx.beginPath(); ctx.arc(2, -97, 10, 0, 6.29); ctx.fill();
  ctx.fillStyle = "#2e7d32"; ctx.beginPath(); ctx.arc(0, -100, 11, Math.PI * .9, Math.PI * 2.05); ctx.fill();
  ctx.fillStyle = "#204020"; ctx.beginPath(); ctx.arc(7, -97, 1.8, 0, 6.29); ctx.fill();
  ctx.restore();

  // bow arm + bow, rotated to aim
  ctx.save();
  ctx.translate(SHOULDER.x, SHOULDER.y);
  ctx.rotate(a);
  // back arm (pulling string)
  ctx.strokeStyle = "#f0c090"; ctx.lineWidth = 6; ctx.lineCap = "round";
  ctx.beginPath(); ctx.moveTo(-4, 4); ctx.lineTo(-10 - pull, 2); ctx.stroke();
  // front arm
  ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(28, 0); ctx.stroke();
  // bow limb
  ctx.strokeStyle = "#7a4a20"; ctx.lineWidth = 5;
  ctx.beginPath(); ctx.arc(20, 0, 34, -1.15, 1.15); ctx.stroke();
  const tipX = 20 + Math.cos(1.15) * 34, tipY = Math.sin(1.15) * 34;
  // string
  ctx.strokeStyle = "#e8e8e8"; ctx.lineWidth = 1.6;
  ctx.beginPath(); ctx.moveTo(tipX, -tipY); ctx.lineTo(24 - pull, 0); ctx.lineTo(tipX, tipY); ctx.stroke();
  // nocked arrow
  if (drawing || state === "play") {
    const nx = 24 - pull;
    ctx.strokeStyle = "#c8a060"; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(nx, 0); ctx.lineTo(nx + 46, 0); ctx.stroke();
    ctx.fillStyle = "#d0d0d0";
    ctx.beginPath(); ctx.moveTo(nx + 52, 0); ctx.lineTo(nx + 44, -3.5); ctx.lineTo(nx + 44, 3.5); ctx.closePath(); ctx.fill();
    ctx.fillStyle = "#e05050";
    ctx.beginPath(); ctx.moveTo(nx, 0); ctx.lineTo(nx + 8, -4); ctx.lineTo(nx + 12, 0); ctx.lineTo(nx + 8, 4); ctx.closePath(); ctx.fill();
  }
  ctx.restore();

  // trajectory preview while drawing
  if (drawing && state === "play") {
    const speed = MIN_SPEED + (MAX_SPEED - MIN_SPEED) * power;
    let px = SHOULDER.x + Math.cos(a) * 30, py = SHOULDER.y + Math.sin(a) * 30;
    let vx = Math.cos(a) * speed, vy = Math.sin(a) * speed;
    ctx.fillStyle = "rgba(255,255,255,.75)";
    for (let i = 0; i < 13; i++) {
      const st = .055;
      vy += GRAVITY * st; px += vx * st; py += vy * st;
      if (py > GROUND) break;
      ctx.globalAlpha = .8 - i * .055;
      ctx.beginPath(); ctx.arc(px, py, 2.6, 0, 6.29); ctx.fill();
    }
    ctx.globalAlpha = 1;
    // power meter above archer
    ctx.fillStyle = "rgba(0,0,0,.4)"; ctx.fillRect(ARCHER.x - 26, ARCHER.y - 132, 56, 9);
    ctx.fillStyle = power >= 1 ? "#ffd040" : "#70e070";
    ctx.fillRect(ARCHER.x - 24, ARCHER.y - 130, 52 * power, 5);
  }
}
function drawArrow(ar) {
  const a = Math.atan2(ar.vy, ar.vx);
  ctx.save(); ctx.translate(ar.x, ar.y); ctx.rotate(a);
  ctx.strokeStyle = "#c8a060"; ctx.lineWidth = 3; ctx.lineCap = "round";
  ctx.beginPath(); ctx.moveTo(-22, 0); ctx.lineTo(16, 0); ctx.stroke();
  ctx.fillStyle = "#d0d0d0";
  ctx.beginPath(); ctx.moveTo(22, 0); ctx.lineTo(14, -3.5); ctx.lineTo(14, 3.5); ctx.closePath(); ctx.fill();
  ctx.fillStyle = "#e05050";
  ctx.beginPath(); ctx.moveTo(-22, 0); ctx.lineTo(-14, -4); ctx.lineTo(-10, 0); ctx.lineTo(-14, 4); ctx.closePath(); ctx.fill();
  ctx.restore();
}
function drawEffects() {
  for (const s of stuck) {
    ctx.save(); ctx.translate(s.x, s.y); ctx.rotate(s.a);
    ctx.globalAlpha = Math.min(1, s.life);
    ctx.strokeStyle = "#c8a060"; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(-34, 0); ctx.lineTo(0, 0); ctx.stroke();
    ctx.fillStyle = "#e05050";
    ctx.beginPath(); ctx.moveTo(-34, 0); ctx.lineTo(-26, -4); ctx.lineTo(-22, 0); ctx.lineTo(-26, 4); ctx.closePath(); ctx.fill();
    ctx.restore();
  }
  ctx.globalAlpha = 1;
  for (const p of particles) {
    ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
    ctx.globalAlpha = Math.max(0, p.life / p.max);
    ctx.fillStyle = p.color; ctx.fillRect(-p.s / 2, -p.s / 2, p.s, p.s * .7);
    ctx.restore();
  }
  ctx.globalAlpha = 1;
  for (const r of rings) {
    const k = 1 - r.life / r.max;
    ctx.globalAlpha = (r.life / r.max) * .9;
    ctx.strokeStyle = r.color; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(r.x, r.y, r.r + k * 34, 0, 6.29); ctx.stroke();
  }
  ctx.globalAlpha = 1;
  ctx.textAlign = "center";
  for (const f of floats) {
    ctx.globalAlpha = Math.max(0, f.life / f.max);
    ctx.font = "26px VT323, monospace";
    ctx.fillStyle = "rgba(0,0,0,.6)"; ctx.fillText(f.text, f.x + 2, f.y + 2);
    ctx.fillStyle = f.color; ctx.fillText(f.text, f.x, f.y);
  }
  ctx.globalAlpha = 1;
}
function drawCrosshair() {
  if (state !== "play") return;
  const { x, y } = mouse;
  ctx.strokeStyle = drawing ? "#ffd040" : "rgba(255,255,255,.95)";
  ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(x, y, 11, 0, 6.29); ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(x - 17, y); ctx.lineTo(x - 6, y); ctx.moveTo(x + 6, y); ctx.lineTo(x + 17, y);
  ctx.moveTo(x, y - 17); ctx.lineTo(x, y - 6); ctx.moveTo(x, y + 6); ctx.lineTo(x, y + 17);
  ctx.stroke();
}
let lastHud = {};
function updateHud() {
  const t = Math.ceil(timeLeft);
  if (lastHud.score !== score) { scoreEl.textContent = score; goalFill.style.width = Math.min(100, score / TARGET * 100) + "%"; lastHud.score = score; }
  if (lastHud.t !== t) { timeEl.textContent = t; timePanel.classList.toggle("low", t <= 10 && state === "play"); lastHud.t = t; }
  const mult = 1 + Math.min(4, Math.floor(Math.max(0, combo - 1) / 3));
  const showCombo = combo >= 2 && state === "play";
  if (lastHud.combo !== combo) {
    comboPanel.style.visibility = showCombo ? "visible" : "hidden";
    comboEl.textContent = combo + " hits" + (mult > 1 ? " x" + mult : "");
    lastHud.combo = combo;
  }
}
function render() {
  ctx.save();
  if (shake > 0) ctx.translate((Math.random() - .5) * shake, (Math.random() - .5) * shake);
  drawBackground();
  for (const b of balloons) drawBalloon(b);
  drawArcher();
  for (const ar of arrows) drawArrow(ar);
  drawEffects();
  drawCrosshair();
  ctx.restore();
  updateHud();
}

/* ---------------- main loop ---------------- */
let last = performance.now();
function frame(now) {
  const dt = Math.min(.033, (now - last) / 1000);
  last = now;
  update(dt);
  render();
  requestAnimationFrame(frame);
}
showMenu();
requestAnimationFrame(frame);
/* headless smoke hook: open with #test to auto-start */
if (location.hash === "#test") startGame();

