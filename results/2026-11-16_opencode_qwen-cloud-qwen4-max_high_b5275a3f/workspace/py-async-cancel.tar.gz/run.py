"""Bounded-concurrency task runner for batch scripts (Python 3.11+, stdlib only).

Usage:
    from run import run_tasks
    asyncio.run(run_tasks([make_job_a, make_job_b, ...], max_concurrent=4))

Each item of `tasks` is a zero-argument callable returning an awaitable.
The callable is only invoked once a concurrency slot is free, so jobs are
started lazily. On cancellation (Ctrl+C under asyncio.run cancels the main
task), every started job is cancelled and awaited, so job-level try/finally
cleanup runs before run_tasks re-raises.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Iterable

JobFactory = Callable[[], Awaitable[object]]


async def run_tasks(tasks: Iterable[JobFactory], max_concurrent: int) -> None:
    """Run all jobs, at most `max_concurrent` at once; return when all are done.

    Raises ValueError for max_concurrent < 1. The first job exception
    propagates after all other jobs have been cancelled and their cleanup
    awaited. Cancellation (Ctrl+C) likewise runs every job's cleanup first.
    """
    if not isinstance(max_concurrent, int) or max_concurrent < 1:
        raise ValueError(
            f"max_concurrent must be an int >= 1, got {max_concurrent!r}"
        )

    gate = asyncio.Semaphore(max_concurrent)

    async def run_guarded(factory: JobFactory) -> None:
        async with gate:
            await factory()

    workers = [asyncio.create_task(run_guarded(factory)) for factory in tasks]
    if not workers:
        return
    try:
        await asyncio.gather(*workers)
    except BaseException:
        # Cancel stragglers, then await them so finally-blocks (cleanup)
        # complete before we propagate the error/cancellation.
        for worker in workers:
            worker.cancel()
        await asyncio.gather(*workers, return_exceptions=True)
        raise
