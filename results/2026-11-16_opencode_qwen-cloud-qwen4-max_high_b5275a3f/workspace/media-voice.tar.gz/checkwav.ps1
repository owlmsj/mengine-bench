$path = Join-Path $PSScriptRoot 'announcement.wav'
$b = [System.IO.File]::ReadAllBytes($path)
$pos = 12
while ($pos + 8 -le $b.Length) {
  $id = [System.Text.Encoding]::ASCII.GetString($b, $pos, 4)
  $size = [BitConverter]::ToInt32($b, $pos + 4)
  if ($id -eq 'fmt ') {
    $rate = [BitConverter]::ToInt32($b, $pos + 12)
    $ch = [BitConverter]::ToInt16($b, $pos + 10)
    $bits = [BitConverter]::ToInt16($b, $pos + 22)
  }
  if ($id -eq 'data') {
    $dur = $size / ($rate * $ch * ($bits / 8))
    Write-Output ("data_bytes={0} duration_seconds={1:N2} rate={2} ch={3} bits={4}" -f $size, $dur, $rate, $ch, $bits)
  }
  $pos += 8 + $size + ($size % 2)
}