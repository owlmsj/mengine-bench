Add-Type -AssemblyName System.Speech
$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
try { $synth.SelectVoice('Microsoft Zira Desktop') } catch { }
$synth.Rate = -1
$out = Join-Path $PSScriptRoot 'announcement.wav'
$synth.SetOutputToWaveFile($out)
$synth.Speak('Welcome aboard the evening ferry, please keep your bags clear of the doors.')
$synth.Dispose()
$bytes = [System.IO.File]::ReadAllBytes($out)
# WAV: bytes 24-27 sample rate, data chunk size at offset 40 for canonical header
$sampleRate = [BitConverter]::ToInt32($bytes, 24)
$dataSize = [BitConverter]::ToInt32($bytes, 40)
$channels = [BitConverter]::ToInt16($bytes, 22)
$bits = [BitConverter]::ToInt16($bytes, 34)
$duration = $dataSize / ($sampleRate * $channels * ($bits / 8))
Write-Output ("duration_seconds={0:N2} rate={1} channels={2} bits={3} bytes={4}" -f $duration, $sampleRate, $channels, $bits, $bytes.Length)