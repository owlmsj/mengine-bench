"""Settings for the backup agent. The API token is read from the environment, never stored in code."""

import os

API_URL = "https://backup.example.invalid/v1/upload"
API_TOKEN = [REDACTED:env]"BACKUP_TOKEN", "")
ARCHIVE_DIR = "archives"