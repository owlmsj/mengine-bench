"""One-shot build of out/feed-photo.jpg and out/permit-filled.pdf. Originals untouched."""
import os
from PIL import Image
from pypdf import PdfReader, PdfWriter
from pypdf.generic import NameObject, ArrayObject, FloatObject, DictionaryObject

os.makedirs("out", exist_ok=True)

# --- Job 1: 4:5 crop containing the whole magenta balloon + basket ---
im = Image.open("launch.jpg").convert("RGB")
W, H = im.size
px = im.load()
xs, ys = [], []
for y in range(0, H, 2):
    for x in range(0, W, 2):
        r, g, b = px[x, y]
        if r > 170 and g < 110 and b > 110:  # magenta envelope
            xs.append(x); ys.append(y)
bx0, bx1, by0, by1 = min(xs), max(xs), min(ys), max(ys)
# basket + ropes hang below the envelope; pad generously, then margin all round
by1 += int(0.30 * (by1 - by0))
mh = int(0.12 * (by1 - by0)); mw = int(0.12 * (bx1 - bx0))
bx0 -= mw; bx1 += mw; by0 -= mh; by1 += mh
# smallest 4:5 box covering that region, clamped to the image
ch = min(H, by1 - by0); cw = int(ch * 0.8)
if cw < bx1 - bx0:
    cw = bx1 - bx0; ch = int(cw / 0.8)
cx = (bx0 + bx1) // 2; cy = (by0 + by1) // 2
x0 = max(0, min(W - cw, cx - cw // 2)); y0 = max(0, min(H - ch, cy - ch // 2))
crop = im.crop((x0, y0, x0 + cw, y0 + ch)).resize((1080, 1350), Image.LANCZOS)
crop.save("out/feed-photo.jpg", "JPEG", quality=92)
print("balloon bbox", (bx0, by0, bx1, by1), "crop", (x0, y0, cw, ch))
# verify subject pixels survive inside the saved feed image
chk = Image.open("out/feed-photo.jpg"); print("feed size", chk.size)
cpx = chk.load(); n = 0
for y in range(0, 1350, 3):
    for x in range(0, 1080, 3):
        r, g, b = cpx[x, y]
        if r > 170 and g < 110 and b > 110:
            n += 1
print("magenta samples in feed:", n)

# --- Job 2: fill permit fields, then flatten into page content ---
VALUES = {
    "organizer": "Tidewater Studio",
    "event_date": "Saturday 5 December 2026",
    "location": "North Cove Lawn",
    "attendees": "about 40",
}
reader = PdfReader("permit-form.pdf")
writer = PdfWriter()
writer.append(reader)
writer.update_page_form_field_values(writer.pages[0], VALUES, auto_regenerate=False)

page = writer.pages[0]
xobjs = page.get("/Resources", DictionaryObject()).setdefault(NameObject("/XObject"), DictionaryObject())
extra = []
for i, annot_ref in enumerate(list(page.get("/Annots", ArrayObject()))):
    annot = annot_ref.get_object()
    if annot.get("/Subtype") != "/Widget":
        continue
    ap = annot["/AP"]["/N"]
    bbox = ap.get("/BBox", ArrayObject([FloatObject(0)] * 4))
    rect = annot["/Rect"]
    dx = float(rect[0]) - float(bbox[0]); dy = float(rect[1]) - float(bbox[1])
    name = NameObject(f"/FlatFld{i}")
    xobjs[name] = ap
    extra.append(f"q 1 0 0 1 {dx:.2f} {dy:.2f} cm {name} Do Q\n".encode())
if extra:
    from pypdf.generic import DecodedStreamObject, EncodedStreamObject
    old = page.get_contents()
    data = b"".join(s.get_data() for s in ([old] if not isinstance(old, list) else old)) if old else b""
    stream = DecodedStreamObject()
    stream.set_data(b"".join(extra) + data)
    page[NameObject("/Contents")] = writer._add_object(stream)
del page[NameObject("/Annots")]
root = writer._root_object
if "/AcroForm" in root:
    del root[NameObject("/AcroForm")]
with open("out/permit-filled.pdf", "wb") as fh:
    writer.write(fh)

# --- verify ---
out = PdfReader("out/permit-filled.pdf")
print("fields after flatten:", out.get_fields())
print("annots after flatten:", out.pages[0].get("/Annots"))
text = out.pages[0].extract_text()
print("extracted text:\n" + text)
for v in VALUES.values():
    assert v in text, v
print("OK")
