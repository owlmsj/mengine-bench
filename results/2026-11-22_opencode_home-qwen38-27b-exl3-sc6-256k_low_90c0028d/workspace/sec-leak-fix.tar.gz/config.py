"""Settings for the backup agent."""

import os

API_URL = "https://backup.example.invalid/v1/upload"
try:
    API_TOKEN = [REDACTED:env]"BACKUP_TOKEN"]
except KeyError:
    raise RuntimeError("BACKUP_TOKEN environment variable is not set") from None
ARCHIVE_DIR = "archives"
