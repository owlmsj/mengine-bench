import json

# Alfa 10/02/2026 (first report) values, in Alfa units
alfa = {
    "Glicose em jejum": 92,      # mg/dL, ref 70-99
    "Colesterol LDL": 118,        # mg/dL, ref < 130
    "Creatinina": 0.95,          # mg/dL, ref 0.70-1.30
    "Hemoglobina glicada (HbA1c)": 5.4,  # %, ref 4.0-5.6
}
# Beta 18/08/2026 raw values
beta_raw = {
    "Glicose em jejum": 6.1,        # mmol/L
    "Colesterol LDL": 3.70,         # mmol/L
    "Creatinina": 76,               # umol/L
    "Hemoglobina glicada (HbA1c)": 37,  # mmol/mol
}
# Conversions to Alfa units (standard factors)
def to_alfa(marker, v):
    if marker == "Glicose em jejum":
        return round(v * 18.0156, 1)          # mg/dL
    if marker == "Colesterol LDL":
        return round(v * 38.6687, 1)          # mg/dL
    if marker == "Creatinina":
        return round(v / 88.42, 2)           # mg/dL
    if marker == "Hemoglobina glicada (HbA1c)":
        return round(0.091529 * v + 2.1523, 2)  # NGSP %

history = {}
for m in alfa:
    history[m] = {"2026-02-10": alfa[m], "2026-08-18": to_alfa(m, beta_raw[m])}

# Worse: increased AND outside first report's reference range
def outside(m, v):
    if m == "Glicose em jejum":
        return not (70 <= v <= 99)
    if m == "Colesterol LDL":
        return v >= 130
    if m == "Creatinina":
        return not (0.70 <= v <= 1.30)
    if m == "Hemoglobina glicada (HbA1c)":
        return not (4.0 <= v <= 5.6)

worse = [m for m in alfa if history[m]["2026-08-18"] > history[m]["2026-02-10"] and outside(m, history[m]["2026-08-18"])]

out = {"history": history, "worse": worse}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print(json.dumps(out, ensure_ascii=False, indent=2))
