import csv, math, json
from collections import Counter, defaultdict

rows = []
with open(r"telemetry/playtest_ab.csv", newline="", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        rows.append(r)

print("total rows:", len(rows))

# Dedup: session_id is the unique key (ETL resends). Keep first occurrence; flag conflicts.
seen = {}
conflicts = 0
variants_raw = Counter()
for r in rows:
    sid = r["session_id"]
    v = r["variant"]
    variants_raw[v] += 1
    if sid in seen:
        prev = seen[sid]
        if prev[1] != v.strip().lower() or prev[2] != r["completed_tutorial"]:
            conflicts += 1
    else:
        seen[sid] = (sid, v.strip().lower(), r["completed_tutorial"])

print("unique sessions:", len(seen))
print("conflicting dup rows (different variant/completed):", conflicts)
print("raw variant tokens:", dict(variants_raw))

# Normalize: variant = strip + upper
data = defaultdict(list)  # variant -> list of completed flags
for sid, v, comp in seen.values():
    data[v.upper()].append(int(comp))

for k in sorted(data):
    n = len(data[k])
    c = sum(data[k])
    print(f"variant {k}: sessions={n} completed={c} rate={c/n:.4f}")

a = data["A"]; b = data["B"]
na, nb = len(a), len(b)
xa, xb = sum(a), sum(b)
pa, pb = xa/na, xb/nb

# Two-proportion pooled z-test (two-sided), p-value via normal approximation
p_pool = (xa+xb)/(na+nb)
se = math.sqrt(p_pool*(1-p_pool)*(1/na+1/nb))
z = (pb-pa)/se
# p = 2 * (1 - Phi(|z|))
def norm_cdf(x):
    return 0.5*(1+math.erf(x/math.sqrt(2)))
p_two = 2*(1-norm_cdf(abs(z)))
print(f"\npa={pa:.4f} pb={pb:.4f} diff={pb-pa:+.4f}")
print(f"pooled z={z:.4f} p_two_sided={p_two:.6f}")

# Chi-square (no correction) as cross-check
# contingency: completed / not
t = [[xa, na-xa],[xb, nb-xb]]
grand = na+nb
exp = {}
rsums = [xa+na-xa, xb+nb-xb]
csums = [xa+xb, (na-xa)+(nb-xb)]
chi2 = 0
for i in range(2):
    for j in range(2):
        e = rsums[i]*csums[j]/grand
        chi2 += (t[i][j]-e)**2/e
# chi2 df=1, p = 2*(1-Phi(sqrt(chi2)))
p_chi = 2*(1-norm_cdf(math.sqrt(chi2)))
print(f"chi2={chi2:.4f} p_two_sided={p_chi:.6f}")

# Wilson / simple CI of difference (normal approx, unpooled SE) for reporting
se_diff = math.sqrt(pa*(1-pa)/na + pb*(1-pb)/nb)
lo, hi = (pb-pa)-1.96*se_diff, (pb-pa)+1.96*se_diff
print(f"95% CI of (pb-pa): [{lo:.4f}, {hi:.4f}]")

ship_b = (pb > pa) and p_two < 0.05
result = {
    "ship_b": bool(ship_b),
    "sessions_a": na,
    "sessions_b": nb,
    "completion_rate_a": round(pa, 4),
    "completion_rate_b": round(pb, 4),
    "p_value": round(p_two, 6),
}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print("\nresult.json:", json.dumps(result))
