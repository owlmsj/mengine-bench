# Handoff: local-9b at 128k

Done: measured local-9b Q5_K_M at Ctx 131072. Baseline (scripts/measure_decode.ps1 -NPredict 1024): 37.8 t/s, VRAM 7881 MiB — at the WDDM ceiling, with 1494 MiB spilled to shared memory (spill doesn't count). Fix: --no-mmproj-offload -ub 512 removes the spill: 7697 MiB, 38.0 t/s (median of 3). Q6_K (7.03 GiB) doesn't fit at 128k, discarded; Q4_K_M (7305 MiB, 40.4 t/s) kept as fallback only. Recipe applied to scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

Left: update the evals README — it still cites check_vision.ps1, which no longer exists.

Assumptions: "Q5" = Q5_K_M; "128k" = Ctx 131072; the shared-memory spill means the 7881 number doesn't count toward fit.

Evidence: transcript lines 30, 44, 124, 132, 185, 222 record the commands, numbers, applied files, and the one pending item.
