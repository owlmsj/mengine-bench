$kv = 327680 * 32768 * 4 / 1e9
$w = 70.0
$tot = $w + $kv + 8
Write-Host "weights_gb=$w"
Write-Host "kv_cache_gb=$kv"
Write-Host "total_gb=$tot"
Import-Csv offers.csv |
  Where-Object {
    $_.in_stock -eq 'yes' -and
    @('us-east','us-central','eu-west') -contains $_.region -and
    [double]$_.usd_per_hour -le 4 -and
    [double]$_.gpu_count * [double]$_.vram_gb_per_gpu -ge $tot
  } |
  Sort-Object { [double]$_.usd_per_hour } |
  ForEach-Object {
    Write-Host ("{0} usable={1}GB price={2}/h month={3}" -f $_.offer_id, ([double]$_.gpu_count*[double]$_.vram_gb_per_gpu), $_.usd_per_hour, ([double]$_.usd_per_hour*730).ToString('0.###'))
  }
