import os, re, json, sys
from urllib.parse import unquote

SITE = r"<WORKSPACE>\site"

files = sorted(os.listdir(SITE))
section_ids = {}
redirects = {}
words = {}   # stem -> {display, tema, links: [{text, stem}]}
non_word = []
missing_targets = set()

for fn in files:
    if not fn.lower().endswith(".html"):
        continue
    p = os.path.join(SITE, fn)
    html = open(p, encoding="utf-8").read()
    stem = fn[:-5]
    # redirect?
    m = re.search(r'meta http-equiv="refresh"[^>]*url=([^\s";]+)', html)
    if m:
        redirects[stem] = unquote(m.group(1).replace(".html",""))
        continue
    h1 = re.search(r"<h1>(.*?)</h1>", html)
    tema = re.search(r'<p class="tema">Tema:\s*(.*?)</p>', html)
    if not h1 or not tema:
        non_word.append(stem)
        continue
    display = h1.group(1).strip()
    links = []
    for sec in re.findall(r'<section id="([^"]+)"[^>]*>(.*?)</section>', html, re.S):
        sid, body = sec
        section_ids[sid] = section_ids.get(sid, 0) + 1
        for href, text in re.findall(r'<a href="([^"]+)">(.*?)</a>', body):
            tstem = unquote(href).rsplit(".html",1)[0]
            links.append({"text": text.strip(), "stem": tstem})
    words[stem] = {"display": display, "tema": tema.group(1).strip(), "links": links}

print("word pages:", len(words))
print("non-word pages:", non_word)
print("redirects:", redirects)
print("section ids:", section_ids)

existing = set(words)
for stem, w in words.items():
    for l in w["links"]:
        if l["stem"] not in existing:
            missing_targets.add(l["stem"])
print("missing link targets:", sorted(missing_targets))
# display vs stem mismatches
mm = {s: w["display"] for s, w in words.items() if s.lower() != w["display"].lower()}
print("display != stem (case/accents):", mm)
# themes
from collections import Counter
print("temas:", Counter(w["tema"] for w in words.values()))

json.dump({"words": words, "redirects": redirects}, open(r".\graph_raw.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
