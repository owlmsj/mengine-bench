import json, re

data = json.load(open(r".\data_full.json", encoding="utf-8"))
words = set(data.keys())
alias = {}
# redirect stubs found in the site
# redirect stub -> target file stem -> its display (h1) name
for k, stem in {"saudades": "saudade", "coracoes": "coracao", "paixoes": "paixao"}.items():
    disp = next((d for d in words if d.startswith(stem[:4])), None)
    alias[k] = disp

html = open(r".\universe\index.html", encoding="utf-8").read()
assert "__DATA__" in html and "__ALIAS__" in html
js_data = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
js_alias = json.dumps(alias, ensure_ascii=False)
html = html.replace("__DATA__", js_data).replace("__ALIAS__", js_alias)
open(r".\universe\index.html", "w", encoding="utf-8").write(html)
print("injected", len(data), "words;", len(alias), "aliases;", "file bytes:", len(html.encode("utf-8")))
