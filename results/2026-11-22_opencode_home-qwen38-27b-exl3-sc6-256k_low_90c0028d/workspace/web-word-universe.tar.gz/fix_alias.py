p = r".\universe\index.html"
h = open(p, encoding="utf-8").read()
old = 'const ALIAS = {"saudades": "saudade"};'
new = 'const ALIAS = {"saudades":"saudade","coracoes":"cor\u00e3o","paixoes":"paix\u00e3o"};'
assert old in h, "old alias not found"
h = h.replace(old, new, 1)
open(p, "w", encoding="utf-8").write(h)
print("alias fixed:", new in h)
