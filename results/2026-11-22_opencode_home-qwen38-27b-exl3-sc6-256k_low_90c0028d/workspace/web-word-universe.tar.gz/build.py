import json, re
from collections import Counter

raw = json.load(open(r".\graph_raw.json", encoding="utf-8"))
W = raw["words"]; R = raw["redirects"]

def resolve(stem):
    seen = set()
    while stem in R and stem not in seen:
        seen.add(stem); stem = R[stem]
    return stem

# stem -> display
disp = {s: w["display"] for s, w in W.items()}
# word key = display name
by_stem = {}
edges = {}  # display -> {"sinonimos": [], "analogas": []}
for stem, w in W.items():
    d = w["display"]
    edges.setdefault(d, {"sinonimos": [], "analogas": []})
    for l in w["links"]:
        t = resolve(l["stem"])
        if t not in W:
            continue  # dangling target (rascunho-3, em-construcao, ...)
        td = disp[t]
        if td == d:
            continue  # self
        # find which section: relink by scanning raw links with stem->section
    # need section info: re-parse raw links (we stored text+stem only; map by order)
# raw["words"][stem]["links"] lost section id; recompute section per link:
# simpler: re-read the section split from graph_raw? we only saved text/stem.
# Re-derive: in the site, sinonimos links come before analogas; we stored order.
# Instead, recompute properly by re-parsing with a section tag (quick re-scan).
import os, urllib.parse
SITE = r".\site"
sec = {}
for stem, w in W.items():
    html = open(os.path.join(SITE, stem + ".html"), encoding="utf-8").read()
    for sid, body in re.findall(r'<section id="([^"]+)"[^>]*>(.*?)</section>', html, re.S):
        for href, text in re.findall(r'<a href="([^"]+)">(.*?)</a>', body):
            t = resolve(urllib.parse.unquote(href).rsplit(".html",1)[0])
            if t not in W: continue
            td = disp[t]
            if td == w["display"]: continue
            sec.setdefault((w["display"], sid), set()).add(td)

# words.json: display -> sorted list of related display words
words_json = {}
for d, e in edges.items():
    e["sinonimos"] = sorted(sec.get((d, "sinonimos"), set()))
    e["analogas"] = sorted(sec.get((d, "analogas"), set()))
    words_json[d] = sorted(set(e["sinonimos"]) | set(e["analogas"]))

# relations: distinct unordered pairs
pairs = set()
deg = Counter()
for d, lst in words_json.items():
    for t in lst:
        a, b = (d, t) if d < t else (t, d)
        pairs.add((a, b))
        deg[a] += 1; deg[b] += 1
most = sorted(deg.items(), key=lambda x: (-x[1], x[0]))
print("words:", len(words_json))
print("relations:", len(pairs))
print("top10:", most[:10])

json.dump(words_json, open(r".\words.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
json.dump({"words": len(words_json), "relations": len(pairs),
          "most_connected": most[0][0]}, open(r".\result.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
# full graph with types + tema for the view
data = {}
for stem, w in W.items():
    d = w["display"]
    data[d] = {"tema": w["tema"], "sinonimos": e["sinonimos"], "analogas": e["analogas"]} if False else None
# reassemble cleanly:
data = {}
for d in words_json:
    data[d] = {"tema": [w["tema"] for s,w in W.items() if w["display"]==d][0],
               "sinonimos": edges[d]["sinonimos"], "analogas": edges[d]["analogas"]}
json.dump(data, open(r".\data_full.json","w",encoding="utf-8"), ensure_ascii=False)
print("dangling excluded:", sorted({"coracoes","paixoes","saudades","em-construcao","link-antigo","pagina-removida","rascunho-3","xpto-2"} - set(R)))
