Add-Type -AssemblyName System.Speech
$path = "$PSScriptRoot\announcement.wav"
$fs = [System.IO.File]::OpenWrite($path)
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
$s.SetOutputToWaveStream($fs)
$s.Speak("Welcome aboard the evening ferry, please keep your bags clear of the doors.")
$s.Dispose()
$fs.Flush()
$fs.Dispose()
$f = Get-Item $path
Write-Output ("Bytes: " + $f.Length)
