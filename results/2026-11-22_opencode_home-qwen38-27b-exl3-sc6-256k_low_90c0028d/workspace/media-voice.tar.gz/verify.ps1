$p = "$PSScriptRoot\announcement.wav"
$b = [System.IO.File]::ReadAllBytes($p)
$rate = [BitConverter]::ToInt32($b, 24)
$bits = [BitConverter]::ToInt16($b, 22)
$ch = [BitConverter]::ToInt16($b, 20)
$bytes = $b.Length - 44
$dur = $bytes / ($rate * [int]($bits / 8) * $ch)
Write-Output ("Rate: " + $rate)
Write-Output ("Channels: " + $ch)
Write-Output ("Bits: " + $bits)
Write-Output ("Duration: " + $dur.ToString("F2") + "s")
$max = 0
for ($i = 44; $i -lt $b.Length - 1; $i += 2) {
  $v = [Math]::Abs([BitConverter]::ToInt16($b, $i))
  if ($v -gt $max) { $max = $v }
}
Write-Output ("MaxSample: " + $max)
