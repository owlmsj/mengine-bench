$inv = @{}
Get-Content backoffice/invoices.csv | Select-Object -Skip 1 | ForEach-Object {
  $f = $_ -split ','
  $inv[$f[0]] = [decimal]$f[2]
}

$payments = @{}   # id -> list of paid amounts
$ignored = @()
Get-Content backoffice/bank_statement_june.csv | Select-Object -Skip 1 | ForEach-Object {
  $f = $_ -split ','
  $memo = $f[1]; $amt = [decimal]$f[2]
  $m = [regex]::Match($memo, '(?:inv|invoice)[- ]?(\d{4})', 'IgnoreCase')
  if (-not $m.Success -or -not $inv.ContainsKey("INV-" + $m.Groups[1].Value)) {
    $ignored += "$memo => $amt"
    return
  }
  $id = "INV-" + $m.Groups[1].Value
  if (-not $payments.ContainsKey($id)) { $payments[$id] = @() }
  $payments[$id] += $amt
}

$unpaid = $inv.Keys | Where-Object { -not $payments.ContainsKey($_) } | Sort-Object
$duplicated = $payments.Keys | Where-Object { $payments[$_].Count -gt 1 } | Sort-Object
$mismatched = @()
foreach ($id in ($payments.Keys | Sort-Object)) {
  $p = $payments[$id]
  if ($p.Count -gt 1) { continue }  # duplicated: excluded from mismatch per README
  if ($p[0] -ne $inv[$id]) {
    $mismatched += [pscustomobject]@{ id = $id; invoiced = $inv[$id]; paid = $p[0] }
  }
}

Write-Host "Ignored rows:"
$ignored
$result = [ordered]@{
  unpaid = @($unpaid)
  duplicated = @($duplicated)
  mismatched = $mismatched
}
$result | ConvertTo-Json | Set-Content result.json
Write-Host "wrote result.json"
