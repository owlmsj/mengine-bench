//! Player scores shared between the match threads of the Pixel Arena server.
//!
//! All state lives behind one lock. The earlier design used one `Mutex` per
//! player slot plus a separate `Mutex` for the total, which had two failure
//! modes under load:
//!
//! * `award` read a slot and the total, then wrote them back under *separate*
//!   lock acquisitions, so concurrent awards lost updates and final scores
//!   came out low.
//! * `transfer` locked the `from` slot and then the `to` slot, so two threads
//!   moving points in opposite directions deadlocked (and `transfer(x, x, _)`
//!   deadlocked on its own non-reentrant slot lock).

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

#[derive(Default)]
struct Inner {
    players: HashMap<PlayerId, i64>,
    total: i64,
}

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    inner: Arc<Mutex<Inner>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        let mut inner = self.inner.lock().unwrap();
        inner.players.insert(id, score);
        inner.total += score;
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let mut inner = self.inner.lock().unwrap();
        *inner.players.get_mut(&id).expect("award for unknown player") += points;
        inner.total += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let mut inner = self.inner.lock().unwrap();
        *inner.players.get_mut(&from).expect("transfer from unknown player") -= points;
        *inner.players.get_mut(&to).expect("transfer to unknown player") += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self
            .inner
            .lock()
            .unwrap()
            .players
            .get(&id)
            .expect("score of unknown player")
    }

    pub fn total(&self) -> i64 {
        self.inner.lock().unwrap().total
    }
}
