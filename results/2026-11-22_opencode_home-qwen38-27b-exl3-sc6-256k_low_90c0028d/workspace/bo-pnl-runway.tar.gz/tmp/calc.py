import csv, json, re
from collections import defaultdict

path = r"<WORKSPACE>\finance\ledger.csv"
coa = {}
with open(r"<WORKSPACE>\finance\chart_of_accounts.csv", encoding="utf-8") as f:
    for row in csv.reader(f, delimiter=";"):
        if len(row) >= 3 and row[0] != "account":
            coa[row[0].strip()] = row[2].strip()

months = ["2026-01","2026-02","2026-03","2026-04","2026-05","2026-06"]
agg = {m: defaultdict(float) for m in months}
count = 0
with open(path, encoding="utf-8") as f:
    for row in csv.reader(f, delimiter=";"):
        if len(row) < 4 or row[0] == "date":
            continue
        d, acct, desc, amt = row
        dd, mm, yy = d.split("/")
        m = f"{yy}-{mm}"
        line = coa.get(acct.strip())
        assert line, f"no COA mapping for {acct}"
        a = amt.strip().replace("-","").replace(".","").replace(",",".")
        v = float(a)
        if amt.strip().startswith("-"):
            v = -v
        agg[m][line] += v
        count += 1

print("entries:", count)
rev = {}; cogs = {}; opex = {}
for m in months:
    rev[m] = agg[m]["revenue"]
    cogs[m] = agg[m]["cogs"]
    opex[m] = agg[m]["sales_marketing"] + agg[m]["rnd"] + agg[m]["ga"]
    pass

res = {}
for m in months:
    gm = (rev[m] - abs(cogs[m])) / rev[m] * 100 if rev[m] else None  # cogs carries a minus sign in the ledger
    ebitda = rev[m] + cogs[m] + opex[m]  # ledger values carry their signs
    res[m] = {"revenue": round(rev[m],2), "gross_margin_pct": round(gm,2), "ebitda": round(ebitda,2)}
    print(m, f"rev={rev[m]:,.2f}", f"cogs={cogs[m]:,.2f}", f"opex={opex[m]:,.2f}", f"fin={agg[m]['financial']:,.2f}", f"GM={gm:.2f}%", f"EBITDA={ebitda:,.2f}")

burn = -sum(res[m]["ebitda"] for m in ["2026-04","2026-05","2026-06"]) / 3
cash = 1847350.40
runway = cash / burn
print(f"burn (avg neg EBITDA Apr-Jun) = {burn:,.2f}")
print(f"runway = {runway:.2f} months")

out = {
    "revenue": {m: res[m]["revenue"] for m in months},
    "gross_margin_pct": {m: res[m]["gross_margin_pct"] for m in months},
    "ebitda": {m: res[m]["ebitda"] for m in months},
    "burn": round(burn, 2),
    "runway_months": round(runway, 2),
}
with open(r"<WORKSPACE>\result.json","w",encoding="utf-8") as f:
    json.dump(out, f, indent=2, ensure_ascii=False)
print("wrote result.json")
