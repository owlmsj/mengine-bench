# H1 2026 close - CFO presentation

All figures from finance/ledger.csv (86 entries, Jan-Jun 2026), classified via
chart_of_accounts.csv. Amounts in BRL.

## Monthly P&L (EBITDA = operating profit; financial lines 6.x excluded)

| Month  | Revenue   | COGS      | Opex (S&M+R&D+G&A) | EBITDA     | Gross margin |
|--------|-----------|-----------|-------------------|------------|--------------|
| 2026-01 | 200,510.87 | 60,091.92 | 350,697.91 | -210,278.96 | 70.0% |
| 2026-02 | 216,328.06 | 64,278.71 | 364,349.43 | -212,300.08 | 70.3% |
| 2026-03 | 219,066.17 | 69,096.05 | 354,495.57 | -204,525.45 | 68.5% |
| 2026-04 | 238,163.26 | 70,867.73 | 364,246.18 | -196,950.65 | 70.2% |
| 2026-05 | 243,032.89 | 73,973.13 | 371,005.58 | -201,945.82 | 69.6% |
| 2026-06 | 272,391.57 | 75,162.69 | 390,197.10 | -192,968.22 | 72.4% |

## Headline for the board

- Revenue grew 35.6% from Jan (200.5k) to Jun (272.4k), with 272.4k in June alone
  - a record month, +12% vs May.
- Gross margin stable at ~70% (68.5%-72.4%).
- Every month ran a negative EBITDA of ~193k-212k; opex (mostly R&D + sales)
  outgrew revenue growth, so EBITDA improved only slightly H1.
- Burn (board definition: avg monthly negative EBITDA of last 3 closed months,
  Apr-Jun): R$ 197,288.23/month.
- Cash on 30/06/2026 (consolidated): R$ 1,847,350.40.
- Runway: 1,847,350.40 / 197,288.23 = 9.36 months (~late Mar 2027).

## Assumptions

1. Revenue is net of refunds (3.1.09 negative entries included).
2. EBITDA excludes financial result (investment income, interest/IOF); no D&A
   exists in the books.
3. "Last three closed months" = Apr, May, Jun 2026 (all H1 months closed).
4. Runway uses the 30/06/2026 consolidated balance from cash_balance.txt.
