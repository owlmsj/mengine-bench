import sqlite3
c = sqlite3.connect(r'<WORKSPACE>\analytics.db')
print('installs by platform (non-test, known users):')
for r in c.execute("""SELECT u.platform, COUNT(DISTINCT e.user_id)
                      FROM events e JOIN users u ON u.user_id=e.user_id
                      WHERE e.name='install' AND u.is_test=0
                      GROUP BY u.platform"""):
    print(' ', r)
print('events with unknown user_id:', c.execute("SELECT COUNT(*) FROM events WHERE user_id NOT IN (SELECT user_id FROM users)").fetchone()[0])
print('event names:', c.execute("SELECT DISTINCT name FROM events").fetchall())
print('test users:', c.execute("SELECT COUNT(*) FROM users WHERE is_test=1").fetchone()[0])
