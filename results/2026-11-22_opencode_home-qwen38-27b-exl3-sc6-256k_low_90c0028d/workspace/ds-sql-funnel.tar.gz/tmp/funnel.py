import sqlite3, json

DB = r'<WORKSPACE>\analytics.db'
STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']

c = sqlite3.connect(DB)
users = {}  # user_id -> platform, non-test only
for uid, platform, is_test in c.execute("SELECT user_id, platform, is_test FROM users"):
    if is_test == 0:
        users[uid] = platform

# events per (platform, user, name): sorted list of ts
from collections import defaultdict
ev = defaultdict(list)
for uid, name, ts in c.execute("SELECT user_id, name, ts FROM events"):
    if uid in users and name in STEPS:
        ev[(users[uid], uid, name)].append(ts)
for k in ev:
    ev[k].sort()

funnel = defaultdict(lambda: {s: 0 for s in STEPS})
for (plat, uid, name), tss in ev.items():
    pass

# Per player, compute first valid ts per step in order
# Group events by (platform, user)
by_player = defaultdict(lambda: defaultdict(list))
for (plat, uid, name), tss in ev.items():
    by_player[(plat, uid)][name] = tss

for (plat, uid), steps in by_player.items():
    prev_ts = None
    for i, s in enumerate(STEPS):
        tss = steps.get(s, [])
        valid = None
        for ts in tss:  # sorted
            if prev_ts is None or ts >= prev_ts:
                valid = ts
                break
        if valid is not None:
            funnel[plat][s] += 1
            prev_ts = valid
        else:
            break  # no later steps can be valid without this one

result = {
    'funnel': {p: {s: funnel[p][s] for s in STEPS} for p in sorted(funnel)},
    'biggest_drop': {},
}
for plat, f in result['funnel'].items():
    best_step, best_conv = None, None
    for i in range(1, len(STEPS)):
        prev, cur = f[STEPS[i-1]], f[STEPS[i]]
        conv = (cur / prev) if prev else 0.0
        if best_conv is None or conv < best_conv:
            best_conv, best_step = conv, STEPS[i]
    result['biggest_drop'][plat] = best_step

print(json.dumps(result, indent=2))
with open(r'<WORKSPACE>\result.json', 'w') as f2:
    json.dump(result, f2, indent=2)

# sanity: per-platform user totals vs install counts
print('users per platform:', dict((p, sum(1 for u in users.values() if u == p)) for p in {v for v in users.values()}))
