import sqlite3, json
c = sqlite3.connect(r'<WORKSPACE>\analytics.db')
tables = c.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
print("TABLES:", tables)
for (t,) in tables:
    print("\n== ", t)
    print(c.execute(f"SELECT sql FROM sqlite_master WHERE name='{t}'").fetchone()[0])
    for row in c.execute(f"SELECT * FROM {t} LIMIT 8"):
        print(row)
    print("rows:", c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0])
