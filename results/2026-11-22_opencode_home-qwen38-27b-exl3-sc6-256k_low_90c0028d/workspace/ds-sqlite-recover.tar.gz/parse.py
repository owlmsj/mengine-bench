import struct, json

with open('prices.db','rb') as f:
    data = f.read()

def varint(buf, i):
    # SQLite big-endian varint, up to 9 bytes
    v = 0
    for n in range(9):
        b = buf[i+n]
        if n == 8:
            v = (v << 8) | b
            return v, i+9
        v = (v << 7) | (b & 0x7f)
        if not (b & 0x80):
            return v, i+n+1
    raise ValueError('bad varint')

def read_serial(buf, i, st):
    if st == 0: return None, i
    if st == 1: return struct.unpack('>b', buf[i:i+1])[0], i+1
    if st == 2: return struct.unpack('>h', buf[i:i+2])[0], i+2
    if st == 3: return struct.unpack('>i', buf[i:i+4])[0], i+4
    if st == 4: return struct.unpack('>q', buf[i:i+8])[0], i+8
    if st == 5:
        v, = struct.unpack('>d', buf[i:i+8]); return v, i+8
    if st == 6: return 0, i
    if st == 7: return 1, i
    if st == 8: return buf[i:i+24], i+24
    if st >= 12 and st % 2 == 0:
        L = (st-12)//2; return buf[i:i+L], i+L
    if st >= 13:
        L = (st-13)//2; return buf[i:i+L].decode('utf-8', 'replace'), i+L
    raise ValueError('bad serial %d' % st)

ptrs = [struct.unpack('>H', data[8+2*k:10+2*k])[0] for k in range(10)]
print('cell pointers:', ptrs)
ncells = struct.unpack('>H', data[3:5])[0]
print('ncells field:', ncells)

rows = []
for idx, p in enumerate(ptrs):
    # cell: payload_size varint, rowid varint, payload
    try:
        pl, i = varint(data, p)
        rid, i = varint(data, i)
        if i + pl > len(data):
            print(f'cell {idx} @{p}: payload {pl} exceeds EOF ({len(data)}), cut off')
            continue
        payload = data[i:i+pl]
        hsz, j = varint(payload, 0)
        stypes = []
        while j < hsz:
            st, j = varint(payload, j)
            stypes.append(st)
        vals = []
        k = hsz
        for st in stypes:
            v, k = read_serial(payload, k, st)
            vals.append(v)
        print(f'cell {idx} @{p}: rowid={rid} stypes={stypes} vals={vals!r}')
        rows.append((rid, vals))
    except Exception as e:
        print(f'cell {idx} @{p}: error {e!r}')

print()
print('parsed rows:', len(rows))
out = []
for rid, vals in rows:
    # assume (item, price)
    if len(vals) == 2 and isinstance(vals[0], str):
        out.append({'item': vals[0], 'price': vals[1]})
for r in out:
    print(r)
with open('recovered.json','w',encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print('wrote', len(out), 'rows')
