import { HookBus } from "../src/bus.ts";

// 1. async handlers run in subscription order, one after another
{
  const bus = new HookBus();
  const order = [];
  bus.on(async () => { await new Promise(r => setTimeout(r, 30)); order.push("slow"); });
  bus.on(async () => { await new Promise(r => setTimeout(r, 10)); order.push("fast"); });
  bus.on(() => order.push("sync"));
  await bus.emit("e", null);
  console.log("order:", order.join(","), order.join() === "sync,slow,fast" ? "OK" : "FAIL");
}

// 2. emit resolves only after every handler has finished
{
  const bus = new HookBus();
  let done = false;
  bus.on(async () => { await new Promise(r => setTimeout(r, 20)); done = true; });
  const p = bus.emit("e", null);
  console.log("done before resolve:", done, done === false ? "OK" : "FAIL");
  await p;
  console.log("done after resolve:", done, done === true ? "OK" : "FAIL");
}

// 3. a rejecting handler rejects emit with the same error; later handlers do not run
{
  const bus = new HookBus();
  const ran = [];
  bus.on(() => { ran.push("a"); });
  bus.on(() => { throw new Error("boom"); });
  bus.on(() => { ran.push("c"); });
  let caught = null;
  try { await bus.emit("e", null); } catch (err) { caught = err; }
  console.log("caught:", caught && caught.message, "ran:", ran.join(","),
    caught && caught.message === "boom" && ran.join() === "a" ? "OK" : "FAIL");
}

// 4. self-unsubscribe during emit does not stop the other handlers in that emit
{
  const bus = new HookBus();
  const ran = [];
  const off = bus.on(() => { off(); ran.push("1"); });
  bus.on(() => ran.push("2"));
  bus.on(() => ran.push("3"));
  await bus.emit("e", null);
  console.log("self-off ran:", ran.join(","), "count after:", bus.count("e"),
    ran.join() === "1,2,3" && bus.count("e") === 2 ? "OK" : "FAIL");
  await bus.emit("e", null);
  console.log("next emit ran:", ran.join(","), ran.slice(3).join() === "2,3" ? "OK" : "FAIL");
}

// 5. plugin scenario: notice (self-unsubscribes), async redact, audit log
{
  const bus = new HookBus();
  const audit = [];
  const off = bus.on(() => { off(); audit.push("notice"); });
  bus.on(async (r) => { await new Promise(r2 => setTimeout(r2, 5)); r.output = r.output.replace(/password=\S+/g, "password=[redacted]"); });
  bus.on((r) => audit.push(r.tool + ":" + r.output));
  const res = { tool: "exec", output: "password=secret ok" };
  await bus.emit("tool.after", res);
  console.log("plugin:", JSON.stringify(audit),
    audit.length === 2 && audit[1] === "exec:password=[redacted] ok" ? "OK" : "FAIL");
}
