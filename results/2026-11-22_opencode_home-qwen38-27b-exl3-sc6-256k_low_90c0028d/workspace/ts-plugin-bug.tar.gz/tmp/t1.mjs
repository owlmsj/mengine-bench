import { HookBus } from "../src/bus.ts";
const bus = new HookBus();
const order = [];
bus.on(async () => { await new Promise(r => setTimeout(r, 30)); order.push("slow"); });
bus.on(async () => { await new Promise(r => setTimeout(r, 10)); order.push("fast"); });
bus.on(() => order.push("sync"));
console.log("count after on:", bus.count("e"));
await bus.emit("e", null);
console.log("order:", order.join(","));
