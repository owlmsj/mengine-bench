from PIL import Image, ImageDraw, ImageFont

W, H = 1200, 675
img = Image.new("RGB", (W, H), (22, 60, 102))
d = ImageDraw.Draw(img)
# subtle gradient bands for depth
for i in range(H):
    d.line([(0, i), (W, i)], fill=(22 + i // 25, 60 + i // 12, 102 + i // 20))

font = None
for name in ["DejaVuSans-Bold.ttf", "arialbd.ttf", "arial.ttf"]:
    try:
        font = ImageFont.truetype(name, 96)
        break
    except OSError:
        continue
if font is None:
    font = ImageFont.load_default()

title = "Harbor Day 2026"
bbox = d.textbbox((0, 0), title, font=font)
tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
d.text(((W - tw) / 2, (H - th) / 2 - bbox[1]), title, fill=(255, 255, 255), font=font)

img.save("cover.png")
print("saved", img.size)
