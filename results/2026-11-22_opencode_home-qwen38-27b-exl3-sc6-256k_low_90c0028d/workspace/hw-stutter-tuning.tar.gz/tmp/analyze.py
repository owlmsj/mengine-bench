import csv, statistics, json

base = r"<WORKSPACE>"

# presentmon
rows = []
with open(base + r"\capture\presentmon.csv", newline="") as f:
    r = csv.DictReader(f)
    fields = r.fieldnames
    for row in r:
        rows.append(row)
print("presentmon fields:", fields)
print("rows:", len(rows))
print("first row:", rows[0])
print("last row:", rows[-1])

ms_key = None
for k in fields:
    if "Ms" in k or "ms" in k.lower():
        ms_key = k
print("ms key:", ms_key)

def ms(row):
    v = row[ms_key]
    try:
        return float(v)
    except:
        return None

vals = [ms(r) for r in rows]
vals = [v for v in vals if v is not None]
mean = statistics.fmean(vals)
# p99
sv = sorted(vals)
def pct(p):
    idx = int(round(p/100 * (len(sv)-1)))
    return sv[idx]
p99 = pct(99)
print(f"n={len(vals)} mean_ms={mean:.3f} p99_ms={p99:.3f}")
print(f"avg_fps={1000/mean:.2f} low1={1000/p99:.2f}")

# find big hitches: ms > 3x mean
big = [(i, v) for i, v in enumerate(vals) if v > 3*mean]
print("hitches (>3x mean):", len(big))
for i, v in big[:40]:
    print(f"  idx {i}: {v:.1f} ms")

# sensors
with open(base + r"\capture\sensors.csv", newline="") as f:
    r = csv.DictReader(f)
    sfields = r.fieldnames
    srows = list(r)
print("sensor fields:", sfields)
print("sensor rows:", len(srows))
for row in srows:
    print(row)
