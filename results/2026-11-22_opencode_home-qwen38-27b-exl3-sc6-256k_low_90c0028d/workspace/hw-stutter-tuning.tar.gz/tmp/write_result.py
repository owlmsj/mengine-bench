import csv, statistics, json

base = r"<WORKSPACE>"
rows = list(csv.DictReader(open(base + r"\capture\presentmon.csv", newline="")))
ms = [float(r["MsBetweenPresents"]) for r in rows]
mean = statistics.fmean(ms)
sv = sorted(ms)
p99 = sv[int(round(99/100*(len(sv)-1)))]
avg = 1000/mean
low = 1000/p99
result = {
  "avg_fps": round(avg, 2),
  "low_1pct_fps": round(low, 2),
  "cause": "The GPU's PCIe Gen5 x4 link repeatedly drops into the ASPM L1 power state (sensors show gpu_pcie_link_state = L1 at t=2,6,10,...,58 s, every 4 s) because pcie_aspm_rp1_gpu is set to L1. Each L1->L0 exit stalls frames for ~22 ms (all 177 frame times above 3x the 6.96 ms median occur in those exact seconds), producing a hitch every few seconds and poor 1% lows while the average stays ~137 fps. The MsMpEng.exe/Defender episode at t=43-45 s raised DPC latency to ~420 us but produced no frame spikes >8 ms, so it is not the hitch cause. Fix: disable PCIe ASPM L1 on the GPU root port, which does not change link speed/width (Gen5 x4) and touches no overclocking (XMP/PBO/ratio).",
  "changes": [
    {"setting": "pcie_aspm_rp1_gpu", "from": "L1", "to": "disabled"}
  ]
}
with open(base + r"\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
print(json.dumps(result, indent=2, ensure_ascii=False))
