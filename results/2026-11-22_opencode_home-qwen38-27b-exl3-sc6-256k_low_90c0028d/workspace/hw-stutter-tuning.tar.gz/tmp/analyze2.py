import csv, statistics

base = r"<WORKSPACE>"
rows = list(csv.DictReader(open(base + r"\capture\presentmon.csv", newline="")))
ms = [float(r["MsBetweenPresents"]) for r in rows]
t  = [float(r["TimeInSeconds"]) for r in rows]

n = len(ms)
mean = statistics.fmean(ms)
sv = sorted(ms)
def pct(p):
    return sv[int(round(p/100*(len(sv)-1)))]
p99 = pct(99)
print(f"n={n} mean_ms={mean:.3f} p99_ms={p99:.3f}")
print(f"avg_fps={1000/mean:.2f} low_1pct={1000/p99:.2f}")

med = statistics.median(ms)
print("median_ms:", round(med,2))

# hitches: > 3x median
th = 3*med
hits = [(t[i], ms[i]) for i in range(n) if ms[i] > th]
print(f"\nhitches > {th:.1f}ms ({3}x median): {len(hits)}")
for tt, v in hits[:80]:
    print(f"  t={tt:8.3f}  {v:7.1f} ms")

# per-second max frame time, seconds 0..59
import collections
secmax = collections.defaultdict(float)
for tt, v in zip(t, ms):
    s = int(tt)
    if v > secmax[s]:
        secmax[s] = v
print("\nseconds with max frame time:")
for s in range(60):
    v = secmax[s]
    flag = "  <--" if v > th else ""
    print(f"  s{s:02d}: {v:7.1f}{flag}")

# L1 seconds from sensors
sens = list(csv.DictReader(open(base + r"\capture\sensors.csv", newline="")))
l1 = [int(r["time_s"]) for r in sens if r["gpu_pcie_link_state"]=="L1"]
print("\nL1 seconds:", l1)
# hitches falling in L1 seconds vs not
in_l1 = sum(1 for tt,_ in hits if int(tt) in set(l1))
print(f"hitches in L1 seconds: {in_l1}/{len(hits)}")

# dropped frames / present flags
drops = sum(1 for r in rows if r["Dropped"] not in ("0",""))
print("dropped frames:", drops)
flags = collections.Counter(r["PresentFlags"] for r in rows)
print("present flags:", dict(flags))
print("syncintervals:", dict(collections.Counter(r["SyncInterval"] for r in rows)))
