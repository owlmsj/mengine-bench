from PIL import Image
import numpy as np
import pymupdf
import os

ws = r"<WORKSPACE>"
os.makedirs(os.path.join(ws, "out"), exist_ok=True)

# --- 1. Feed photo: crop 4:5 containing the magenta balloon, resize 1080x1350 ---
im = Image.open(os.path.join(ws, "launch.jpg")).convert("RGB")
arr = np.asarray(im)
H, W, _ = arr.shape
r, g, b = arr[..., 0].astype(int), arr[..., 1].astype(int), arr[..., 2].astype(int)
# magenta: red and blue high, green low
mask = (r > 150) & (b > 150) & (g < 120) & (r > g + 60) & (b > g + 60)
ys, xs = np.where(mask)
print("magenta pixels:", mask.sum())
x0, x1 = xs.min(), xs.max()
y0, y1 = ys.min(), ys.max()
print("balloon bbox:", x0, y0, x1, y1, "center:", (x0+x1)//2, (y0+y1)//2)

# 4:5 crop from 3000x2000 -> crop 1600 x 2000
cw, ch = 1600, 2000
cx = (x0 + x1) // 2
left = min(max(cx - cw // 2, 0), W - cw)
top = 0
box = (left, top, left + cw, top + ch)
print("crop box:", box)
crop = im.crop(box)
out_im = crop.resize((1080, 1350), Image.LANCZOS)
out_im.save(os.path.join(ws, "out", "feed-photo.jpg"), quality=90)
print("saved feed-photo.jpg", out_im.size)

# verify balloon fully inside: bbox relative to crop
bx0, by0, bx1, by1 = x0 - left, y0 - top, x1 - left, y1 - top
assert 0 <= bx0 and by0 >= 0 and bx1 <= cw and by1 <= ch, "balloon outside crop!"
print("balloon inside crop:", (bx0, by0, bx1, by1))

# --- 2. Fill permit form and flatten ---
doc = pymupdf.open(os.path.join(ws, "permit-form.pdf"))
page = doc[0]
values = {
    "organizer": "Tidewater Studio",
    "event_date": "2026-12-05",
    "location": "North Cove Lawn",
    "attendees": "about 40",
}
for w in page.widgets():
    if w.field_name in values:
        w.field_value = values[w.field_name]
        w.update()
    print("field:", w.field_name, "->", w.field_value)
page.flatten()
doc.save(os.path.join(ws, "out", "permit-filled.pdf"), deflate=True, garbage=3, clean=True)
doc.close()
print("saved permit-filled.pdf")

# verify: reopen, check no editable widgets and values rendered as text
d2 = pymupdf.open(os.path.join(ws, "out", "permit-filled.pdf"))
p2 = d2[0]
widgets = list(p2.widgets()) if p2.widgets() else []
print("remaining widgets:", len(widgets))
txt = p2.get_text()
for k, v in values.items():
    print(k, "present in text:", v in txt)
print(txt)
