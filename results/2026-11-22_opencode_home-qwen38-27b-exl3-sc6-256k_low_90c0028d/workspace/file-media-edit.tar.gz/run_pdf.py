import pymupdf
import os

ws = r"<WORKSPACE>"
doc = pymupdf.open(os.path.join(ws, "permit-form.pdf"))
page = doc[0]
values = {
    "organizer": "Tidewater Studio",
    "event_date": "2026-12-05",
    "location": "North Cove Lawn",
    "attendees": "about 40",
}
widgets = list(page.widgets())
for w in widgets:
    v = values.get(w.field_name)
    if v is None:
        continue
    r = w.rect
    # fit font size to rect
    fs = 11
    while fs > 4:
        tw = pymupdf.get_text_length(v, fontname="helv", fontsize=fs)
        if tw <= r.width - 6:
            break
        fs -= 1
    page.insert_text((r.x0 + 3, r.y1 - 4), v, fontname="helv", fontsize=fs, color=(0, 0, 0))
    print("drew", w.field_name, "in", r, "fs", fs)
    page.delete_widget(w)
doc.save(os.path.join(ws, "out", "permit-filled.pdf"), deflate=True, garbage=3, clean=True)
doc.close()

d2 = pymupdf.open(os.path.join(ws, "out", "permit-filled.pdf"))
p2 = d2[0]
ws2 = list(p2.widgets()) if p2.widgets() else []
print("remaining widgets:", len(ws2))
xref = d2.xref_length()
# ensure no AcroForm
import re
data = p2.read_contents().decode("latin1") if hasattr(p2, "read_contents") else ""
txt = p2.get_text()
print("fields present in text:")
for v in values.values():
    print(repr(v), v in txt)
print(txt)
# check AcroForm key in doc catalog
cat = d2.pdf_catalog()
print("catalog xref:", cat)
