function MB([datetime]$a,[datetime]$b){ $m=($b.Year-$a.Year)*12+($b.Month-$a.Month); if($b.Day -lt $a.Day){$m--}; return $m }
$plans = @(
  @{name='Cruzado';  launch='1986-02-28'; next='1987-06-12'; before=264.69;  after=412.43},
  @{name='Bresser';  launch='1987-06-12'; next='1989-01-15'; before=756.98;  after=621.40},
  @{name='Verao';    launch='1989-01-15'; next='1990-03-15'; before=621.40;  after=2853.51},
  @{name='Collor I'; launch='1990-03-15'; next='1991-01-31'; before=1228.93; after=470.83},
  @{name='Collor II';launch='1991-01-31'; next='1994-07-01'; before=2853.51; after=111.29},
  @{name='Real';     launch='1994-07-01'; next=$null;         before=2476.82; after=22.41}
)
foreach($p in $plans){
  if($p.next){$m = MB ([datetime]$p.launch) ([datetime]$p.next)} else {$m = 60}
  $drop = 1 - ($p.after/$p.before); if($drop -lt 0){$drop=0}; if($drop -gt 1){$drop=1}
  $dur = [Math]::Min($m,60)/60
  $score = 0.7*$drop + 0.3*$dur
  '{0}: months_lasted={1} drop={2:F4} dur={3:F4} score={4:F4}' -f $p.name,$m,$drop,$dur,$score
}
