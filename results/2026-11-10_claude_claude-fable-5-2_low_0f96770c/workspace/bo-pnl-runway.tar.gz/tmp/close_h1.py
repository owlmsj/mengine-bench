import csv, json, sys, collections
fin = sys.argv[1]
coa = {r['account']: r for r in csv.DictReader(open(fin+'/chart_of_accounts.csv', encoding='utf-8-sig'), delimiter=';')}
rows = list(csv.DictReader(open(fin+'/ledger.csv', encoding='utf-8-sig'), delimiter=';'))
num = lambda s: float(s.strip().replace('R$','').replace('.','').replace(',','.'))
seen = collections.Counter(); P = collections.defaultdict(lambda: collections.defaultdict(float))
for r in rows:
    k = tuple(r.values()); seen[k] += 1
    d, m, y = r['date'].strip().split('/')
    line = coa[r['account'].strip()]['pnl_line'] if r['account'].strip() in coa else None
    if line is None or not r['description'].startswith(r['account']) or seen[k] > 1 or not (y == '2026' and '01' <= m <= '06'):
        print('ODD', r, seen[k], line)
    if line: P[f'{y}-{m}'][line] += num(r['amount'])
print(len(rows), 'rows')
out = {'revenue': {}, 'gross_margin_pct': {}, 'ebitda': {}}
for mth in sorted(P):
    p = P[mth]; rev = p['revenue']; gp = rev + p['cogs']
    e = gp + p['sales_marketing'] + p['rnd'] + p['ga']
    print(mth, {k: round(v, 2) for k, v in p.items()}, 'GP', round(gp, 2), 'EBITDA', round(e, 2), 'net', round(e + p['financial'], 2))
    if '2026-01' <= mth <= '2026-06':
        out['revenue'][mth] = round(rev, 2); out['gross_margin_pct'][mth] = round(gp / rev * 100, 2); out['ebitda'][mth] = round(e, 2)
burn = -sum(out['ebitda'][m] for m in ['2026-04', '2026-05', '2026-06']) / 3
cash = 1847350.40
out['burn'] = round(burn, 2); out['runway_months'] = round(cash / burn, 2)
json.dump(out, open(sys.argv[2], 'w'), indent=2)
print(json.dumps(out, indent=2))
