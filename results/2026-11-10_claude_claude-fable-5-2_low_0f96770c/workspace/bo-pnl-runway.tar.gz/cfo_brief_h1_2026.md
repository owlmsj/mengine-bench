# H1 2026 close: CFO brief

Source: finance/ledger.csv (86 entries, all Jan-Jun 2026, all mapped to the chart of accounts, no duplicates). Amounts in R$.

| Month | Revenue (net of refunds) | Gross margin % | EBITDA |
|---|---:|---:|---:|
| 2026-01 | 200,510.87 | 70.03 | -210,278.96 |
| 2026-02 | 216,328.06 | 70.29 | -212,300.08 |
| 2026-03 | 219,066.17 | 68.46 | -204,525.45 |
| 2026-04 | 238,163.26 | 70.24 | -196,950.65 |
| 2026-05 | 243,032.89 | 69.56 | -201,945.82 |
| 2026-06 | 272,391.57 | 72.41 | -192,968.22 |
| H1 | 1,389,492.82 | | -1,218,969.18 |

## Cash and runway (board definition)
- Burn = average negative EBITDA of Apr, May, Jun = 197,288.23 per month.
- Closing cash 30/06/2026 = 1,847,350.40.
- Runway = 1,847,350.40 / 197,288.23 = 9.36 months (to about April 2027).

## Messages
- Revenue up 36% from January to June; June is the best month on revenue, margin and EBITDA.
- Gross margin stable around 70%, 72.41% in June.
- EBITDA loss narrowing slowly: -210k in January to -193k in June. Still loss-making every month.
- Refunds to customer Kestrel in March (6,814.15) and May (8,634.37) are deducted from revenue.

## Point to prepare for: cash fell faster than the P&L in June
Bank cash dropped 461,837.60 from 31/05 to 30/06, while June EBITDA was -192,968.22 (-187,346.57 after financial items). About 274k of June cash outflow is not explained by the ledger (working capital, capex, debt or tax payments are not in these books). If June's actual cash drop were the run rate, runway would be about 4.0 months, not 9.36. Reconcile before the meeting.

## Assumptions
- Revenue = accounts 3.1.x including refunds (net revenue).
- Gross margin = (revenue - COGS) / revenue.
- EBITDA = revenue - COGS - sales and marketing - R&D - G&A; financial lines (6.1.x) excluded. No depreciation appears in the ledger.
- Months by entry date; "last three closed months" = April to June 2026.
