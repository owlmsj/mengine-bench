import re, json, os, sys, urllib.parse, collections
S='site'
files={f:open(os.path.join(S,f),encoding='utf-8').read() for f in os.listdir(S)}
word={}; theme={}; redir={}
for f,h in files.items():
    m=re.search(r'http-equiv="refresh" content="0; url=([^"]+)"',h)
    if m: redir[f]=urllib.parse.unquote(m.group(1)); continue
    t=re.search(r'class="tema">Tema: ([^<]*)',h); h1=re.search(r'<h1>([^<]*)</h1>',h)
    if t and h1: word[f]=h1.group(1).strip(); theme[word[f]]=t.group(1).strip()
assert len(set(word.values()))==len(word)
def res(href):
    f=urllib.parse.unquote(href)
    for _ in range(5):
        if f in redir: f=redir[f]
    return word.get(f)
out={w:{'s':[],'a':[]} for w in word.values()}; dead=0
adj=collections.defaultdict(set)
for f,w in word.items():
    for sid,k in (('sinonimos','s'),('analogas','a')):
        sec=re.search(r'<section id="%s">(.*?)</section>'%sid,files[f],re.S).group(1)
        for href in re.findall(r'href="([^"]+)"',sec):
            t=res(href)
            if t is None: dead+=1; continue
            if t==w: continue
            if t not in out[w][k]: out[w][k].append(t)
            adj[w].add(t); adj[t].add(w)
ws=sorted(word.values())
wj={w:sorted(adj[w]) for w in ws}
pairs={tuple(sorted((a,b))) for a in adj for b in adj[a]}
deg=sorted(ws,key=lambda w:(-len(adj[w]),w))
json.dump(wj,open('words.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
json.dump({'words':len(ws),'relations':len(pairs),'most_connected':deg[0]},open('result.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
alias={}
for f,t in redir.items():
    m=re.search(r'<title>([^<|]*)',files[f]); 
    if res(f): alias[m.group(1).strip()]=res(f)
data={'n':[{'w':w,'t':theme[w],'s':out[w]['s'],'a':out[w]['a']} for w in ws],'alias':alias}
tpl=open('tmp/tpl.html',encoding='utf-8').read()
open('universe/index.html','w',encoding='utf-8').write(tpl.replace('/*DATA*/',json.dumps(data,ensure_ascii=False,separators=(',',':'))))
print(len(ws),len(pairs),dead,[(w,len(adj[w])) for w in deg[:4]],alias,'isolated',sum(1 for w in ws if not adj[w]))
