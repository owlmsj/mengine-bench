# Pixel Arena

A match game painted in primary colors, on Unreal Engine 5.

- `Source/PixelArena`: the game module.
- `Config`: project settings.
- `Saved/Logs/PixelArena-shipping.log`: log of the packaged run that crashed.
