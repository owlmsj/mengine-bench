"""Settings for the backup agent."""

import os

API_URL = "https://backup.example.invalid/v1/upload"
ARCHIVE_DIR = "archives"
BACKUP_TOKEN_ENV_NAME = "BACKUP_TOKEN"


def read_backup_token() -> str:
    """Reads the API token from the environment at call time; it is never stored in code."""
    token = os.environ.get(BACKUP_TOKEN_ENV_NAME, "")
    if not token:
        raise RuntimeError(
            f"environment variable {BACKUP_TOKEN_ENV_NAME} is unset or empty; expected a non-empty API token")
    return token
