import csv,sys,glob,statistics as st
for f in glob.glob(sys.argv[1]+'/*'):
    rows=list(csv.DictReader(open(f,encoding='utf-8-sig')))
    print(f,len(rows),list(rows[0].keys()))
    if 'MsBetweenPresents' in rows[0]:
        v=[float(r['MsBetweenPresents']) for r in rows]
        s=sorted(v);n=len(s)
        import math
        print('avg',1000/st.mean(v),'sum_s',sum(v)/1000)
        for name,p in(('nearest',s[math.ceil(.99*n)-1]),('linear',st.quantiles(v,n=100,method='inclusive')[98])):print(name,p,1000/p)
        t=0
        for r,x in zip(rows,v):
            t+=x
            if x>3*st.median(v):print('spike',round(t/1000,2),x,{k:r[k] for k in r if k!='MsBetweenPresents'})
    else:
        for r in rows:print(list(r.values()))
