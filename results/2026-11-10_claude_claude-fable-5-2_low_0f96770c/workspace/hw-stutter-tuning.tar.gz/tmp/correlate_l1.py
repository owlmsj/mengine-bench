import csv,sys,collections
d=sys.argv[1]
sp=collections.Counter()
for r in csv.DictReader(open(d+'/presentmon.csv',encoding='utf-8-sig')):
    if float(r['MsBetweenPresents'])>15: sp[int(float(r['TimeInSeconds']))]+=1
for r in csv.DictReader(open(d+'/sensors.csv',encoding='utf-8-sig')):
    t=int(r['time_s'])
    if sp[t] or r['gpu_pcie_link_state']!='L0' or int(r['dpc_latency_us'])>300 or int(r['disk_active_pct'])>30 or r['top_cpu_process']!='Arena.exe' or int(r['cpu_clock_mhz'])<4800:
        print(t,sp[t],list(r.values())[1:])
