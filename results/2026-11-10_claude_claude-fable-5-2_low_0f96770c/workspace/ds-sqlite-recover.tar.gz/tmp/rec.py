import sys,json,struct
d=open(sys.argv[1],'rb').read()
print(len(d),d[:16],d[:110].hex())
ps=struct.unpack('>H',d[16:18])[0]
if ps==1:ps=65536
if ps<512 or ps&(ps-1):ps=4096
def vi(b,o):
    v=0
    for i in range(9):
        c=b[o+i]
        if i==8:return (v<<8)|c,o+9
        v=(v<<7)|(c&127)
        if c<128:return v,o+i+1
out=[];raw=[]
for pn in range((len(d)+ps-1)//ps):
    p=d[pn*ps:(pn+1)*ps];h=0
    if len(p)<h+8 or p[h]!=13:print('page',pn+1,'type',p[h] if len(p)>h else None,len(p));continue
    n=struct.unpack('>H',p[h+3:h+5])[0];print('page',pn+1,'leaf cells',n,len(p))
    for i in range(n):
        try:
            o=struct.unpack('>H',p[h+8+2*i:h+10+2*i])[0]
            pl,o2=vi(p,o);rid,o2=vi(p,o2)
            if o2+pl>len(p):print(' cell',i,'truncated/overflow');continue
            hs,o3=vi(p,o2);he=o2+hs;ts=[]
            while o3<he:
                t,o3=vi(p,o3);ts.append(t)
            vals=[];o4=he
            for t in ts:
                if t==0:v=None;l=0
                elif t<=6:l=[0,1,2,3,4,6,8][t];v=int.from_bytes(p[o4:o4+l],'big',signed=True)
                elif t==7:l=8;v=struct.unpack('>d',p[o4:o4+8])[0]
                elif t in(8,9):l=0;v=t-8
                elif t>=13 and t%2:l=(t-13)//2;v=p[o4:o4+l].decode('utf-8')
                else:l=(t-12)//2;v=p[o4:o4+l].hex()
                vals.append(v);o4+=l
            raw.append((pn+1,rid,vals))
        except Exception as e:print(' cell',i,'err',e)
for r in raw:print(r)
json.dump(raw,open(sys.argv[2],'w'),ensure_ascii=False)
