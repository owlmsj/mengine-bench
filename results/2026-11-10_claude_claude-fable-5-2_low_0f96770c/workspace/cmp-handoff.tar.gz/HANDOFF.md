# HANDOFF: local-9b Q5 at 128k context

Goal (user): local model needs 128k ctx; measure local-9b Q5 there.

## Done
- Recipe: `--no-mmproj-offload -ub 512`. Result: VRAM 7697 MiB, decode 38.0 t/s (median of 3), no spill.
- Applied in `scripts/start_server.ps1:165` (local9 block) and `profiles/local/local-9b.json`.
- Measure: `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`

## Traps
- IGNORE the earlier 37.8 t/s / 7881 MiB: 7881 is the WDDM ceiling, 1494 MiB had spilled to Shared Usage. Always check the Shared Usage counter.
- Q6_K (7.03 GiB) does not fit at 128k: discarded.
- Q4_K_M fits (7305 MiB, 40.4 t/s): fallback only.
- Short prompt does not reproduce; wait for downloads before measuring.

## Left
1. Evals README still cites `check_vision.ps1` (file no longer exists): update it.

## Not verified
- No re-measure after the recipe was written to the script/profile.
- Commit state unknown; diffs seen were formatting only.
