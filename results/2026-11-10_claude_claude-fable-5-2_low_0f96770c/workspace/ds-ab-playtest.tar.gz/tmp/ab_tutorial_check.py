import csv, sys, json, math
from collections import Counter, defaultdict
rows=list(csv.DictReader(open(sys.argv[1],encoding='utf-8-sig')))
print('raw rows',len(rows), Counter(r['variant'] for r in rows), Counter(r['completed_tutorial'] for r in rows))
by=defaultdict(set)
for r in rows: by[r['session_id'].strip()].add((r['variant'].strip().upper(),r['completed_tutorial'].strip(),r['player_id'].strip()))
print('unique sessions',len(by),'conflicting',sum(len(v)>1 for v in by.values()))
S={k:next(iter(v)) for k,v in by.items()}
def test(xa,na,xb,nb):
    p=(xa+xb)/(na+nb); se=math.sqrt(p*(1-p)*(1/na+1/nb)); z=(xb/nb-xa/na)/se
    return z, math.erfc(abs(z)/math.sqrt(2))
n=Counter(v[0] for v in S.values()); x=Counter(v[0] for v in S.values() if v[1]=='1')
z,p=test(x['A'],n['A'],x['B'],n['B'])
print('sessions',n,x,'z',z,'p',p)
# raw (naive) for contrast
rn=Counter(r['variant'].strip().upper() for r in rows); rx=Counter(r['variant'].strip().upper() for r in rows if r['completed_tutorial'].strip()=='1')
print('naive raw',rn,rx,test(rx['A'],rn['A'],rx['B'],rn['B']))
# player level
pv=defaultdict(set); pc=defaultdict(list)
for v in S.values(): pv[v[2]].add(v[0]); pc[(v[2],v[0])].append(int(v[1]))
print('players',len(pv),'in both variants',sum(len(s)>1 for s in pv.values()),'max sess/player-variant',max(len(c) for c in pc.values()))
# first... player-level: any completion, players in single variant only
pn=Counter();px=Counter()
for (pl,va),c in pc.items():
    if len(pv[pl])==1: pn[va]+=1; px[va]+=max(c)
print('player-level single-variant',pn,px,test(px['A'],pn['A'],px['B'],pn['B']))
try:
    from scipy.stats import fisher_exact
    print('fisher',fisher_exact([[x['B'],n['B']-x['B']],[x['A'],n['A']-x['A']]]))
except Exception as e: print(e)
ra=x['A']/n['A']; rb=x['B']/n['B']
json.dump({"ship_b":bool(p<0.05 and rb>ra),"sessions_a":n['A'],"sessions_b":n['B'],"completion_rate_a":round(ra,4),"completion_rate_b":round(rb,4),"p_value":round(p,4)},open(sys.argv[2],'w'),indent=2)
print(open(sys.argv[2]).read())
