import asyncio, sys
sys.path.insert(0, ".")
from run import run_tasks
live = peak = 0; cleaned = []
def mk(i, fail=False):
    async def job():
        global live, peak
        live += 1; peak = max(peak, live)
        try:
            await asyncio.sleep(0.05)
            if fail: raise RuntimeError(i)
            return i
        finally:
            await asyncio.sleep(0.01); live -= 1; cleaned.append(i)
    return job
async def main():
    global peak
    print("order", await run_tasks([mk(i) for i in range(10)], 3) == list(range(10)), "peak", peak)
    try: await run_tasks([mk(0, True), mk(1)], 2)
    except ExceptionGroup as g: print("group", len(g.exceptions), "others finished", 1 in cleaned)
    cleaned.clear()
    t = asyncio.create_task(run_tasks([mk(i) for i in range(10)], 3))
    await asyncio.sleep(0.02); t.cancel()
    try: await t
    except asyncio.CancelledError: print("cancelled; cleaned", sorted(cleaned), "live", live)
    print("empty", await run_tasks([], 2))
asyncio.run(main())
