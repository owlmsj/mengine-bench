"""Bounded-concurrency runner for batch jobs: `from run import run_tasks`."""

import asyncio
from collections.abc import Awaitable, Callable, Iterable
from typing import TypeVar

JobResult = TypeVar("JobResult")


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[JobResult]]],
    max_concurrent: int,
) -> list[JobResult]:
    """Run every task, at most max_concurrent jobs at once; results in task order.

    A failing job does not stop the others; once all are done the failures are
    raised together as an ExceptionGroup. On cancellation (Ctrl+C under
    asyncio.run) running jobs are cancelled and awaited, so their
    finally/except cleanup completes before this returns; unstarted tasks are
    never called.
    """
    if isinstance(max_concurrent, bool) or not isinstance(max_concurrent, int) or max_concurrent < 1:
        raise ValueError(f"max_concurrent must be an int >= 1, got {max_concurrent!r}")
    task_list = list(tasks)
    results: list[JobResult | None] = [None] * len(task_list)
    failures: list[Exception] = []
    pending = iter(enumerate(task_list))

    async def drain_pending_jobs() -> None:
        for index, make_job in pending:
            try:
                results[index] = await make_job()
            except Exception as job_error:
                failures.append(job_error)

    workers = [
        asyncio.create_task(drain_pending_jobs())
        for _ in range(min(max_concurrent, len(task_list)))
    ]
    try:
        await asyncio.gather(*workers)
    except BaseException:
        # Why: gather cancels children but does not wait for them; wait here
        # so job cleanup finishes before the cancellation propagates.
        for worker in workers:
            worker.cancel()
        await asyncio.gather(*workers, return_exceptions=True)
        raise
    if failures:
        raise ExceptionGroup(f"{len(failures)} of {len(task_list)} jobs failed", failures)
    return results  # type: ignore[return-value]
