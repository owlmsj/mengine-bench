# Handoff: local-9b @ 128k context

Done: measured Q5 at 131072 ctx. First run: 37.8 t/s, VRAM 7881 MiB — invalid (WDDM ceiling; 1494 MiB spilled to Shared Usage). Fixed with `--no-mmproj-offload` and `-ub 512`: spill gone, final 7697 MiB, decode 38.0 t/s (median of 3).
Recipe applied in `scripts/start_server.ps1:165` (local9 block) and `profiles/local/local-9b.json`.
Quant choice: Q6_K (7.03 GiB) does NOT fit at 128k — discarded. Q4_K_M fits (7305 MiB, 40.4 t/s), kept only as fallback.

Open:
1. Update evals README — it still cites `check_vision.ps1`, which no longer exists.
2. Scratchpad temp file names need review (deferred repeatedly, never done).

Assumptions: Q5 is the target quant; 128k means 131072; measurements were taken after downloads finished so are uncontaminated.
Evidence: transcript steps 30/42/45 show the measured numbers and fix; final recipe locations confirmed at step 63.
