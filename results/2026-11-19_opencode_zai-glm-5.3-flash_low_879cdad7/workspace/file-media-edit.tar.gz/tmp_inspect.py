from PIL import Image
im = Image.open('launch.jpg').convert('RGB')
px = im.load()
# sample a horizontal row through the magenta balloon center
y = 700
prev = None
for x in range(2300, 2800, 4):
    r,g,b = px[x,y]
    tag = 'M' if (r>180 and g<100 and b>120) else '.'
    if tag != prev:
        print(x, (r,g,b), tag)
        prev = tag
# brown basket search
minx=miny=10**9; maxx=maxy=-1
for yy in range(880, 1100, 2):
    for xx in range(2300, 2850, 2):
        r,g,b = px[xx,yy]
        if 100<r<190 and 50<g<120 and b<90:
            minx=min(minx,xx); miny=min(miny,yy); maxx=max(maxx,xx); maxy=max(maxy,yy)
print('brown bbox:', minx,miny,maxx,maxy)
