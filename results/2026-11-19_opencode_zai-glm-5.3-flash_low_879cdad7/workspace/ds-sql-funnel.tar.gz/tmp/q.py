import sqlite3
c = sqlite3.connect('analytics.db')
steps = ['install', 'tutorial_complete', 'first_match', 'purchase']
# only known, non-test players
users = {u: (p, t) for u, p, t in c.execute("select user_id, platform, is_test from users")}
# first valid occurrence per player per step
first = {}
for u, name, ts in c.execute("select user_id, name, ts from events"):
    if u not in users or name not in steps:
        continue
    key = (u, name)
    if key not in first or ts < first[key]:
        first[key] = ts
from collections import defaultdict
counts = defaultdict(lambda: [0]*4)
plat_users = defaultdict(int)
for u, (p, t) in users.items():
    if t:
        continue
    plat_users[p] += 1
    prev_ts = None
    for i, s in enumerate(steps):
        ts = first.get((u, s))
        if ts is not None and (prev_ts is None or ts >= prev_ts):
            counts[p][i] += 1
            prev_ts = ts
for p in plat_users:
    print(p, plat_users[p], counts[p])
