use arena_scores::Board;
use std::sync::Arc;

fn main() {
    let board = Arc::new(Board::new());
    board.join(1, 0);
    board.join(2, 0);
    let mut handles = vec![];
    for _ in 0..4 {
        let b = board.clone();
        handles.push(std::thread::spawn(move || {
            for _ in 0..10_000 {
                b.award(1, 1);
            }
        }));
    }
    // Opposite-direction transfers between the same pair, plus self-transfers.
    for i in 0..4 {
        let b = board.clone();
        handles.push(std::thread::spawn(move || {
            for _ in 0..10_000 {
                if i % 2 == 0 { b.transfer(1, 2, 0); } else { b.transfer(2, 1, 0); }
                b.transfer(1, 1, 0);
            }
        }));
    }
    for h in handles { h.join().unwrap(); }
    let s = board.score(1);
    assert_eq!(s, 40_000, "score 1 = {}", s);
    assert_eq!(board.total(), 40_000);
    println!("OK score={} total={}", s, board.total());
}
