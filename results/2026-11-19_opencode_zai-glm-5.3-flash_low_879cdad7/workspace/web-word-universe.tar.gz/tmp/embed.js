const fs=require('fs');
const words=JSON.parse(fs.readFileSync('./words.json','utf8'));
const result=JSON.parse(fs.readFileSync('./result.json','utf8'));
const themes=[...new Set(Object.values(words).map(w=>w.tema).filter(Boolean))];
const html=fs.readFileSync('./universe/index.html','utf8');
const data=JSON.stringify({words,relations:result.relations,themes,most_connected:result.most_connected});
const out=html.replace('/*__DATA__*/',data);
fs.writeFileSync('./universe/index.html',out);
console.log('embedded bytes:',data.length,'html size:',out.length);
