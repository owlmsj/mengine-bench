const fs=require('fs'),path=require('path');
const dir='./site';
const files=fs.readdirSync(dir).filter(f=>f.endsWith('.html'));
const pages={}; // canonical slug -> {word, tema, rel:{sin:[],ana:[]}, hrefName}
const redirect={};
function norm(s){return s.normalize('NFC');}
for(const f of files){
  const html=fs.readFileSync(path.join(dir,f),'utf8');
  const m=html.match(/<meta http-equiv="refresh" content="0;\s*url=([^"]+)"/i);
  if(m){redirect[f.toLowerCase()]=m[1].toLowerCase();continue;}
  const h1=html.match(/<main><h1>([^<]+)<\/h1>/);
  const tema=html.match(/<p class="tema">Tema:\s*([^<]+)<\/p>/);
  if(!h1) continue;
  const rel={sin:[],ana:[]};
  for(const sec of html.matchAll(/<section id="(sinonimos|analogas)"><h2>[^<]*<\/h2>(.*?)<\/section>/gs)){
    const kind=sec[1]==='sinonimos'?'sin':'ana';
    for(const a of sec[2].matchAll(/<a href="([^"]+)">([^<]*)<\/a>/g)){
      rel[kind].push({href:decodeURIComponent(a[1]),text:norm(a[2])});
    }
  }
  pages[f.toLowerCase()]={file:f,word:norm(h1[1]),tema:tema?norm(tema[1]).trim():'',rel};
}
// resolve canonical target for each relation
const canon={}; // href lowercase -> page key
for(const k in pages) canon[k]=k;
for(const k in redirect){ let t=redirect[k]; while(redirect[t]) t=redirect[t]; if(pages[t]) canon[k]=t; }
const adj={}; // canonical key -> Set of canonical keys
const pairSet=new Set();
const missing=new Set();
for(const k in pages){
  const p=pages[k];
  if(!adj[k]) adj[k]=new Set();
  for(const r of [...p.rel.sin,...p.rel.ana]){
    let h=r.href.toLowerCase();
    if(!h.endsWith('.html')) continue;
    let t=canon[h]||h;
    if(!pages[t]){missing.add(r.href);continue;}
    adj[k].add(t);
    if(!adj[t]) adj[t]=new Set();
    adj[t].add(k);
    pairSet.add([k,t].sort().join('|'));
  }
}
// words.json: canonical word -> sorted list of linked words (with section info? brief says words it is linked to)
const words={};
const byKey={};
for(const k in pages) byKey[k]=pages[k].word;
const keys=Object.keys(pages).sort((a,b)=>byKey[a].localeCompare(byKey[b],'pt'));
for(const k of keys) words[byKey[k]]={[k]:{tema:pages[k].tema,links:adj[k]&&[...adj[k]].map(t=>byKey[t]).sort((a,b)=>a.localeCompare(b,'pt'))||[]}};
fs.writeFileSync('./tmp/graph.json',JSON.stringify({redirect,missing:[...missing]},null,1));
const out={};
for(const k of keys) out[byKey[k]]=(adj[k]||[]).length;
const top=Object.entries(out).sort((a,b)=>b[1]-a[1]).slice(0,10);
console.log('pages:',Object.keys(pages).length,'redirects:',Object.keys(redirect).length,'pairs:',pairSet.size,'missing:',[...missing].join(', '));
console.log('top:',JSON.stringify(top));
// save canonical words.json (simple mapping word->linked words) and aux
const simple={};
for(const k of keys) simple[byKey[k]]=[...(adj[k]||[])].map(t=>byKey[t]).sort((a,b)=>a.localeCompare(b,'pt'));
fs.writeFileSync('./tmp/words_simple.json',JSON.stringify(simple,null,1));
fs.writeFileSync('./tmp/meta.json',JSON.stringify(keys.map(k=>({key:k,word:byKey[k],tema:pages[k].tema,deg:(adj[k]||[]).length,sin:pages[k].rel.sin.map(r=>byKey[canon[r.href.toLowerCase()]]||null),ana:pages[k].rel.ana.map(r=>byKey[canon[r.href.toLowerCase()]]||null)})),null,1));
