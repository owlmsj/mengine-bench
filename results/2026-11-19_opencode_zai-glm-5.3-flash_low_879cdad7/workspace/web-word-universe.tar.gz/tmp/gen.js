const fs=require('fs');
const meta=require('./meta.json');
// degree
for(const x of meta) x.deg=(x.sin.concat(x.ana)).filter(Boolean).length;
// dedupe links per word preserving order
function uniq(a){return [...new Set(a)];}
const words={};
for(const x of meta){
  words[x.word]={tema:x.tema,sinonimos:uniq(x.sin.filter(Boolean)),analogas:uniq(x.ana.filter(Boolean))};
}
// result: distinct unordered pairs
const pairs=new Set();
for(const w in words){
  for(const l of words[w].sinonimos.concat(words[w].analogas)){
    if(words[l]) pairs.add([w,l].sort().join('|'));
  }
}
const most=Object.entries(words).map(([w,v])=>[w,uniq(v.sinonimos.concat(v.analogas)).length]).sort((a,b)=>b[1]-a[1]);
const result={words:Object.keys(words).length,relations:pairs.size,most_connected:most.slice(0,10).map(([w,n])=>({word:w,relations:n}))};
fs.writeFileSync('../words.json',JSON.stringify(words,null,1));
fs.writeFileSync('../result.json',JSON.stringify(result,null,1));
console.log(JSON.stringify(result,null,1));
