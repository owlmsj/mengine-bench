"""Helper to run async job batches with bounded concurrency.

Tasks are zero-argument callables returning an awaitable job. At most
`max_concurrent` jobs run at once. On Ctrl+C (KeyboardInterrupt) every job is
cancelled, so each job's own cleanup code (finally / __aexit__ / except) runs
before run_tasks propagates the interruption.
"""

import asyncio
from typing import Callable, Iterable

__all__ = ["run_tasks"]


async def _run_one(task: Callable[[], object], sem: asyncio.Semaphore) -> None:
    """Await one job while holding a semaphore slot."""
    async with sem:
        await task()  # a non-awaitable return raises TypeError early


async def run_tasks(tasks: Iterable[Callable[[], object]], max_concurrent: int) -> None:
    """Run every job, at most `max_concurrent` at a time.

    Returns when every job is done. On KeyboardInterrupt, cancels all running
    jobs, waits for their cleanup, then re-raises KeyboardInterrupt.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent!r}")

    sem = asyncio.Semaphore(max_concurrent)
    jobs = [asyncio.ensure_future(_run_one(t, sem)) for t in tasks]

    try:
        await asyncio.gather(*jobs)
        return
    except KeyboardInterrupt:
        pass  # fall through to cancellation + cleanup below
    except asyncio.CancelledError:
        raise  # our own caller cancelled us; nothing extra to do

    # Ctrl+C path: cancel every job and wait so their cleanup runs.
    for j in jobs:
        j.cancel()
    results = await asyncio.gather(*jobs, return_exceptions=True)
    errors = [r for r in results if isinstance(r, BaseException)
              and not isinstance(r, asyncio.CancelledError)]
    if errors:
        raise KeyboardInterrupt from errors[0]
    raise KeyboardInterrupt
