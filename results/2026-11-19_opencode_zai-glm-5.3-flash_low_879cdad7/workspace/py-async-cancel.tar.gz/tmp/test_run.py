import asyncio, sys
sys.path.insert(0, r"<WORKSPACE>")
from run import run_tasks

async def test_normal():
    order, cleanup = [], []
    running = 0
    def mk(i):
        async def job():
            nonlocal running
            running += 1
            assert running <= 2, "concurrency exceeded"
            await asyncio.sleep(0.02)
            running -= 1
            order.append(i)
            try:
                yield  # not a generator; placeholder no-op
            except StopIteration:
                pass
        return job
    # clean job with finally cleanup
    def mk2(i):
        async def job():
            try:
                await asyncio.sleep(0.02)
                order.append(i)
            finally:
                cleanup.append(i)
        return job
    await asyncio.wait_for(run_tasks([mk2(i) for i in range(5)], 2), 2)
    assert order == [0, 1, 2, 3, 4], order
    assert sorted(cleanup) == [0, 1, 2, 3, 4]
    print("normal OK")

async def test_interrupt():
    cleanup = []
    started = []
    def mk(i):
        async def job():
            started.append(i)
            try:
                await asyncio.sleep(5)
            finally:
                cleanup.append(i)
        return job
    async def run():
        await run_tasks([mk(i) for i in range(4)], 2)
    t = asyncio.ensure_future(run())
    await asyncio.sleep(0.1)  # let 2 jobs start
    t.cancel()  # simulates Ctrl+C reaching the outer task (CancellationError path)
    try:
        await t
    except (KeyboardInterrupt, asyncio.CancelledError):
        pass
    assert len(started) == 2, started
    assert sorted(cleanup) == sorted(started), (started, cleanup)
    print("interrupt-outer OK")

async def test_kb_direct():
    # simulate the KeyboardInterrupt arriving inside run_tasks' gather
    cleanup = []
    def mk(i):
        async def job():
            try:
                await asyncio.sleep(5)
            finally:
                cleanup.append(i)
        return job
    async def sleeper():
        await asyncio.sleep(0.1)
        raise KeyboardInterrupt
    async def run():
        await asyncio.gather(run_tasks([mk(i) for i in range(4)], 2), sleeper())
    try:
        await asyncio.wait_for(run(), 3)
    except (KeyboardInterrupt, asyncio.CancelledError):
        pass
    except Exception:
        raise
    assert len(cleanup) > 0, cleanup
    print("interrupt-inner OK (cleanup ran for", len(cleanup), "jobs)")

asyncio.run(test_normal())
asyncio.run(test_interrupt())
asyncio.run(test_kb_direct())
print("ALL PASS")
