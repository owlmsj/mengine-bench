# HANDOFF — local-9b 128k context

## Goal
Get local-9b running at 128k context (131072) with a clean VRAM number.

## Done
- Measured local-9b Q5 @ 128k: `scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024` → 37.8 t/s, VRAM 7881 MiB.
- 7881 MiB is the WDDM ceiling; Shared Usage counter showed 1494 MiB spilled — that number is not usable.
- Fix found: `--no-mmproj-offload -ub 512` removes the spill → final VRAM 7697 MiB, decode 38.0 t/s (median of 3).
- Recipe applied in `scripts/start_server.ps1:165` (local9 block) and `profiles/local/local-9b.json`.
- Q6_K (7.03 GiB) does not fit at 128k — discarded. Q4_K_M fits (7305 MiB, 40.4 t/s) — kept only as fallback.

## Left
1. Evals README still cites `check_vision.ps1`, which no longer exists — update it.
2. Scratchpad temp file names need a review (noted repeatedly, never done).

## Assumptions
- The transcript is the only record; no second turn possible.
- "The number does not count" = the 7881 MiB WDDM figure, not the 7697 MiB post-fix figure.
- 38.0 t/s / 7697 MiB are the accepted final numbers.

## How I know it is right
- The fix line (step 42) and the applied-recipe line (step 63) are explicit in the transcript.
- Q6_K/Q4_K_M verdict is explicit (step 45).
- Pending README item is explicit (step 76).
- No contradicting numbers elsewhere in the transcript.