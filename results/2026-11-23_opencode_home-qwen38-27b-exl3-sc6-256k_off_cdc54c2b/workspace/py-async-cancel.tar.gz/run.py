"""Batch task runner: run callables that return awaitables, with a concurrency cap.

Usage:
    from run import run_tasks
    await run_tasks([job_factory_a, job_factory_b, ...], max_concurrent=4)

Each task is a zero-argument callable; calling it returns an awaitable job.
At most `max_concurrent` jobs run at the same time. run_tasks returns when
every job has finished (including cancelled ones, after their cleanup).

KeyboardInterrupt (Ctrl+C) handling: when the run is interrupted, every
in-flight job is cancelled and awaited, so their cleanup code (finally blocks,
async with __aexit__, except/finally around awaits) runs before run_tasks
re-raises the KeyboardInterrupt.
"""

from __future__ import annotations

import asyncio
from typing import Any, Awaitable, Callable, Iterable


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[Any]]],
    max_concurrent: int,
) -> list[Any]:
    """Run all tasks with at most *max_concurrent* running at once.

    Args:
        tasks: iterable of zero-argument callables returning awaitables.
        max_concurrent: maximum number of jobs running simultaneously.
            Must be >= 1.

    Returns:
        List of results, in task order.

    Raises:
        ValueError: if max_concurrent < 1.
        KeyboardInterrupt: re-raised after all in-flight jobs have been
            cancelled and their cleanup has run.
        Exception from a task: the first task exception propagates (gather
            semantics); remaining jobs are cancelled and awaited.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent!r}")

    factories = list(tasks)
    sem = asyncio.Semaphore(max_concurrent)

    async def guarded(factory: Callable[[], Awaitable[Any]]):
        async with sem:
            return await factory()

    # Wrap each guarded coroutine in a Task so we can cancel it individually
    # on interrupt; gather over Tasks keeps results in input order.
    job_tasks = [asyncio.ensure_future(guarded(f)) for f in factories]
    try:
        return list(await asyncio.gather(*job_tasks))
    except (KeyboardInterrupt, asyncio.CancelledError) as exc:
        # Cancel every in-flight job and wait for all of their cleanup to
        # finish, then propagate the original interrupt. gather with
        # return_exceptions=True ensures one task's exception (CancelledError,
        # KI, job error) cannot abort the wait for the others.
        for t in job_tasks:
            t.cancel()
        await asyncio.gather(*job_tasks, return_exceptions=True)
        raise exc