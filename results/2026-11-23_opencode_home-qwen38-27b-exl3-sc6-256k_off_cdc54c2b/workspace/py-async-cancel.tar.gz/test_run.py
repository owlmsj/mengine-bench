import asyncio, run

# 1) basic: all run, order preserved, cap respected
async def t1():
    running = []
    peak = 0
    def make(i):
        async def job():
            nonlocal peak
            running.append(1); peak = max(peak, len(running))
            await asyncio.sleep(0.05)
            running.pop()
            return i
        return job
    out = await run.run_tasks([make(i) for i in range(10)], 3)
    assert out == list(range(10)), out
    assert peak <= 3, peak
    print("basic ok, peak =", peak)

# 2) KeyboardInterrupt raised inside a job (as Ctrl+C does): cleanup must run
cleaned = []
def make_ki(i):
    async def job():
        try:
            if i == 0:
                raise KeyboardInterrupt   # simulate Ctrl+C hitting the loop
            await asyncio.sleep(10)
        finally:
            cleaned.append(i)
    return job

async def t2():
    await run.run_tasks([make_ki(i) for i in range(4)], 4)

try:
    asyncio.run(t2())
except KeyboardInterrupt:
    pass
print("cleanup ran for jobs:", sorted(cleaned))
assert sorted(cleaned) == [0, 1, 2, 3], cleaned

# 3) task exception: first error propagates, other jobs cancelled+cleaned
cleaned3 = []
def make_err(i):
    async def job():
        try:
            if i == 1:
                raise ValueError("boom")
            await asyncio.sleep(10)
        finally:
            cleaned3.append(i)
    return job

async def t3():
    await run.run_tasks([make_err(i) for i in range(3)], 3)

try:
    asyncio.run(t3())
    raise AssertionError("expected ValueError")
except ValueError as e:
    assert str(e) == "boom"
print("exception cleanup:", sorted(cleaned3))
assert sorted(cleaned3) == [0, 1, 2], cleaned3

print("all ok")