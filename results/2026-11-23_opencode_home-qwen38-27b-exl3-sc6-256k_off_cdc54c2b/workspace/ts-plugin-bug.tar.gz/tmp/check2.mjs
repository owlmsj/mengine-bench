import { HookBus } from "../src/bus.ts";

async function main() {
  console.log("start");
  const bus = new HookBus();
  const order = [];
  bus.on("e", () => new Promise((r) => setTimeout(() => order.push(1), 20)));
  bus.on("e", () => new Promise((r) => setTimeout(() => order.push(2), 5)));
  console.log("subscribed, count =", bus.count("e"));
  await bus.emit("e", null);
  console.log("emitted, order =", order);
}

main().then(() => console.log("done")).catch((e) => { console.error("FAIL:", e); process.exit(1); });