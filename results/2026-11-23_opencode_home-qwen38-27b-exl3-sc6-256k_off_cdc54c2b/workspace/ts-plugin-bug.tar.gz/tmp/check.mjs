import { HookBus } from "../src/bus.ts";
import { registerAuditPlugin } from "../src/plugin.ts";

const tick = (n) => new Promise((r) => {
  let i = 0;
  const step = () => { if (++i < n) Promise.resolve().then(step); else r(); };
  Promise.resolve().then(step);
});

async function main() {
  // 1. Plugin order: notice -> redaction -> audit log
  {
    const bus = new HookBus();
    const audit = [];
    registerAuditPlugin(bus, audit);
    await bus.emit("tool.after", { tool: "shell", output: "password=secret123 done" });
    if (audit[0] !== "notice: tool output is audited") throw new Error("notice not first: " + audit[0]);
    if (audit[1] !== "shell: password=[redacted] done") throw new Error("redaction wrong: " + audit[1]);
    console.log("ok: plugin order + redaction:", JSON.stringify(audit));
  }

  // 2. Async handlers run in subscription order (slow first, fast second)
  {
    const bus = new HookBus();
    const order = [];
    bus.on("e", async () => { await tick(5); order.push(1); });
    bus.on("e", async () => { await tick(1); order.push(2); });
    await bus.emit("e", null);
    if (JSON.stringify(order) !== "[1,2]") throw new Error("out of order: " + order);
    console.log("ok: sequential subscription order:", order);
  }

  // 3. Failing handler rejects emit; later handlers do not run
  {
    const bus = new HookBus();
    const ran = [];
    bus.on("e", () => { ran.push("a"); });
    bus.on("e", () => { throw new Error("boom"); });
    bus.on("e", () => { ran.push("c"); });
    let err;
    try { await bus.emit("e", null); } catch (e) { err = e; }
    if (!err || err.message !== "boom") throw new Error("emit did not reject with handler error");
    if (JSON.stringify(ran) !== '["a"]') throw new Error("later handler ran: " + ran);
    console.log("ok: error rejects emit, later handlers skipped");
  }

  // 4. Rejected (async) handler rejects emit too
  {
    const bus = new HookBus();
    bus.on("e", async () => { throw new Error("async boom"); });
    let err;
    try { await bus.emit("e", null); } catch (e) { err = e; }
    if (!err || err.message !== "async boom") throw new Error("async rejection not propagated");
    console.log("ok: async rejection propagates");
  }

  // 5. Self-unsubscribe during emit does not stop the others in that emit
  {
    const bus = new HookBus();
    const ran = [];
    const off = bus.on("e", () => { ran.push("a"); off(); });
    bus.on("e", () => { ran.push("b"); });
    await bus.emit("e", null);
    if (JSON.stringify(ran) !== '["a","b"]') throw new Error("emit aborted early: " + ran);
    if (bus.count("e") !== 1) throw new Error("unsub did not count: " + bus.count("e"));
    await bus.emit("e", null);
    if (JSON.stringify(ran) !== '["a","b","b"]') throw new Error("second emit wrong: " + ran);
    console.log("ok: unsubscribe during emit counts from next emit");
  }

  console.log("ALL CHECKS PASSED");
}

main().catch((e) => { console.error("FAIL:", e); process.exit(1); });