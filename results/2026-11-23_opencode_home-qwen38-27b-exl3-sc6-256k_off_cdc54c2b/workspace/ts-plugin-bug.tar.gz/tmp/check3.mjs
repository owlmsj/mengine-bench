import { HookBus } from "../src/bus.ts";

async function main() {
  const bus = new HookBus();
  const order = [];
  bus.on("e", () => { order.push(1); });
  bus.on("e", () => { order.push(2); });
  await bus.emit("e", null);
  console.log("sync handlers order =", order);

  const bus2 = new HookBus();
  const order2 = [];
  bus2.on("e", () => Promise.resolve().then(() => order2.push(1)));
  bus2.on("e", () => Promise.resolve().then(() => order2.push(2)));
  await bus2.emit("e", null);
  console.log("microtask handlers order =", order2);

  const bus3 = new HookBus();
  const order3 = [];
  bus3.on("e", () => new Promise((r) => setTimeout(() => order3.push(1), 20)));
  await bus3.emit("e", null);
  console.log("timer handler order =", order3);
}

main().then(() => console.log("done")).catch((e) => { console.error("FAIL:", e); process.exit(1); });