import csv, json, io, os

BASE = os.path.dirname(os.path.abspath(__file__))

def parse_amt(s):
    # pt-BR: 1.234.567,89 ; negative: -56.661,03
    s = s.strip()
    neg = s.startswith('-')
    s = s.lstrip('-')
    s = s.replace('.', '').replace(',', '.')
    v = float(s)
    return -v if neg else v

pnl_map = {}
with open(os.path.join(BASE, 'chart_of_accounts.csv'), encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        pnl_map[row['account']] = row['pnl_line']

months = ['2026-01','2026-02','2026-03','2026-04','2026-05','2026-06']
lines = ['revenue','cogs','sales_marketing','rnd','ga','financial']
agg = {m: {l: 0.0 for l in lines} for m in months}

with open(os.path.join(BASE, 'ledger.csv'), encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        d = row['date'].strip()
        day, mon, yr = d.split('/')
        m = f"{yr}-{mon}"
        acct = row['account'].strip()
        amt = parse_amt(row['amount'])
        line = pnl_map[acct]
        agg[m][line] += amt

result = {'revenue': {}, 'gross_margin_pct': {}, 'ebitda': {},
          'burn': None, 'runway_months': None}

ebitda = {}
for m in months:
    a = agg[m]
    rev = a['revenue']
    cogs = a['cogs']
    gross = rev + cogs  # cogs is negative
    gm = (gross / rev * 100) if rev else 0.0
    # EBITDA: operating lines only (exclude financial)
    e = rev + a['cogs'] + a['sales_marketing'] + a['rnd'] + a['ga']
    ebitda[m] = e
    result['revenue'][m] = round(rev, 2)
    result['gross_margin_pct'][m] = round(gm, 2)
    result['ebitda'][m] = round(e, 2)

# burn: average monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = [ebitda[m] for m in ['2026-04','2026-05','2026-06']]
burn = -sum(last3) / 3
cash = 1847350.40  # 30/06/2026 closing balance
runway = cash / burn

result['burn'] = round(burn, 2)
result['runway_months'] = round(runway, 2)

with open(os.path.join(os.path.dirname(BASE), 'result.json'), 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2, ensure_ascii=False)

print(json.dumps(result, indent=2))
print()
for m in months:
    a = agg[m]
    print(m, {k: round(v,2) for k,v in a.items()})