import re

raw = open(r"<WORKSPACE>\regex.txt").read()
pattern = raw.strip()
log = open(r"<WORKSPACE>\server.log").read()
result = re.findall(pattern, log, re.MULTILINE)
print("File stripped length:", len(pattern))
print("findall over server.log:", result)
expected = ['2026-04-01', '2026-04-05', '2026-04-02']
print("Matches expected:", result == expected)
# also confirm single group so findall returns strings
print("Group count:", re.compile(pattern).groups)