import json

# Annual IPCA (IBGE, % calendar year), source: ipeadata.gov.br (IBGE consolidated)
ipca = {
    1985: 242.23, 1986: 79.66, 1987: 363.41, 1988: 980.21, 1989: 1972.91,
    1990: 1620.97, 1991: 472.70, 1992: 1119.10, 1993: 2477.15, 1994: 916.46,
    1995: 22.41,
}

# Launch dates (day, month, year)
plans = [
    ("Cruzado",  1986, (28, 2, 1986)),
    ("Bresser",  1987, (12, 6, 1987)),
    ("Verao",    1989, (15, 1, 1989)),
    ("Collor I", 1990, (16, 3, 1990)),
    ("Collor II",1991, (31, 1, 1991)),
    ("Real",     1994, (1, 7, 1994)),  # currency circulation; URV created 27 Feb 1994
]

def months_between(d1, d2):
    _, m1, y1 = d1
    _, m2, y2 = d2
    return (y2 - y1) * 12 + (m2 - m1)

results = []
for i, (name, year, launch) in enumerate(plans):
    next_plan = plans[i+1][2] if i+1 < len(plans) else None
    if name == "Real":
        months_lasted = 60
    else:
        months_lasted = months_between(launch, next_plan)
    ipca_before = ipca[year - 1]
    ipca_after = ipca[year + 1]
    score_drop = max(0.0, min(1.0, 1 - ipca_after / ipca_before))
    score_durability = min(months_lasted, 60) / 60
    score = 0.7 * score_drop + 0.3 * score_durability
    results.append({
        "plan": name,
        "launch_date": f"{launch[0]:02d}-{launch[1]:02d}-{launch[2]}",
        "ipca_before": ipca_before,
        "ipca_after": ipca_after,
        "months_lasted": months_lasted,
        "score_drop": round(score_drop, 4),
        "score_durability": round(score_durability, 4),
        "score": round(score, 4),
    })

results.sort(key=lambda r: r["score"], reverse=True)
for r in results:
    print(f"{r['plan']:10} before={r['ipca_before']:>9} after={r['ipca_after']:>9} "
          f"months={r['months_lasted']:>3} drop={r['score_drop']:.4f} dur={r['score_durability']:.4f} "
          f"score={r['score']:.4f}")

top3 = [r["plan"] for r in results[:3]]
print("\nTOP3:", top3)

with open("result.json", "w", encoding="utf-8") as f:
    json.dump({
        "plans": [
            {
                "plan": r["plan"],
                "launch_date": r["launch_date"],
                "ipca_before": r["ipca_before"],
                "ipca_after": r["ipca_after"],
                "months_lasted": r["months_lasted"],
                "score": r["score"],
                "sources": [
                    "https://www.ipeadata.gov.br/ExibeSerie.aspx?module=m&serid=1410807112&oper=view",
                    "https://sidra.ibge.gov.br/tabela/1737",
                    "https://atlas.fgv.br/verbete/6306",
                    "https://pt.wikipedia.org/wiki/Plano_Cruzado",
                ],
            } for r in results
        ],
        "top3": top3,
    }, f, ensure_ascii=False, indent=2)
print("\nresult.json written")