import csv, json, math

path = r"<WORKSPACE>\telemetry\playtest_ab.csv"

rows = []
with open(path, newline="", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        rows.append(r)

print("total data rows:", len(rows))

# Normalize variant: strip whitespace, lowercase
def norm_variant(v):
    return v.strip().lower()

# Dedupe by session_id: keep first occurrence; verify consistency
seen = {}
dup_conflicts = 0
for r in rows:
    sid = r["session_id"].strip()
    v = norm_variant(r["variant"])
    c = int(r["completed_tutorial"])
    if sid in seen:
        prev = seen[sid]
        if prev[0] != v or prev[1] != c:
            dup_conflicts += 1
    else:
        seen[sid] = (v, c)

print("unique sessions:", len(seen))
print("duplicate rows:", len(rows) - len(seen))
print("dup rows with conflicting variant/completed:", dup_conflicts)

a = [c for (v, c) in seen.values() if v == "a"]
b = [c for (v, c) in seen.values() if v == "b"]
other = [v for (v, c) in seen.values() if v not in ("a", "b")]
print("variant 'a' sessions:", len(a), "completed:", sum(a))
print("variant 'b' sessions:", len(b), "completed:", sum(b))
print("other variants:", set(other))

n_a, n_b = len(a), len(b)
x_a, x_b = sum(a), sum(b)
p_a = x_a / n_a
p_b = x_b / n_b
print("completion rate A: %.6f" % p_a)
print("completion rate B: %.6f" % p_b)
print("absolute gain B-A: %.6f" % (p_b - p_a))

# Two-proportion z-test, pooled, two-sided
p_pool = (x_a + x_b) / (n_a + n_b)
se = math.sqrt(p_pool * (1 - p_pool) * (1 / n_a + 1 / n_b))
z = (p_b - p_a) / se
# two-sided p-value via normal CDF
def norm_cdf(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))
p_value = 2 * (1 - norm_cdf(abs(z)))
print("pooled p: %.6f" % p_pool)
print("SE: %.6f" % se)
print("z: %.6f" % z)
print("two-sided p-value: %.6f" % p_value)
print("significant at 5%:", p_value < 0.05)

# Also one-sided (is B better than A)
p_one = 1 - norm_cdf(z)
print("one-sided p (B>A): %.6f" % p_one)

# 95% CI for difference (unpooled SE)
se_diff = math.sqrt(p_a * (1 - p_a) / n_a + p_b * (1 - p_b) / n_b)
diff = p_b - p_a
print("95%% CI for diff: [%.4f, %.4f]" % (diff - 1.959964 * se_diff, diff + 1.959964 * se_diff))

result = {
    "ship_b": bool(p_b > p_a and p_value < 0.05),
    "sessions_a": n_a,
    "sessions_b": n_b,
    "completion_rate_a": round(p_a, 6),
    "completion_rate_b": round(p_b, 6),
    "p_value": round(p_value, 6),
}
out = r"<WORKSPACE>\result.json"
with open(out, "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print("wrote", out)
print(json.dumps(result, indent=2))