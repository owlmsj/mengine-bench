import sqlite3, json
con = sqlite3.connect(r'<WORKSPACE>\analytics.db')
steps = ["install", "tutorial_complete", "first_match", "purchase"]
users = {uid: (plat, test) for uid, plat, test in con.execute("SELECT user_id, platform, is_test FROM users")}
# first occurrence per user per event name
first = {}
for uid, name, ts in con.execute("SELECT user_id, name, MIN(ts) FROM events GROUP BY user_id, name"):
    first.setdefault(uid, {})[name] = ts
funnel = {}
for uid, (plat, test) in users.items():
    if test:
        continue
    ev = first.get(uid, {})
    # step counts only at or after the player's previous step; time = first valid occurrence
    prev_ts = None
    for s in steps:
        if s in ev and (prev_ts is None or ev[s] >= prev_ts):
            funnel.setdefault(plat, {st: 0 for st in steps})[s] += 1
            prev_ts = ev[s]
result = {"funnel": {p: {s: d.get(s, 0) for s in steps} for p, d in funnel.items()}, "biggest_drop": {}}
for p, d in result["funnel"].items():
    best_step, best_conv = None, None
    for i, s in enumerate(steps[1:], 1):
        prev = d[steps[i-1]]
        conv = d[s] / prev if prev else 0.0
        if best_conv is None or conv < best_conv:
            best_conv, best_step = conv, s
    result["biggest_drop"][p] = best_step
print(json.dumps(result, indent=2))
with open(r'<WORKSPACE>\result.json', 'w') as f:
    json.dump(result, f, indent=2)