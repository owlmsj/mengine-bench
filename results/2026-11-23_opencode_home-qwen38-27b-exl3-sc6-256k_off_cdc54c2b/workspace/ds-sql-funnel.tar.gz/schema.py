import sqlite3
con = sqlite3.connect(r'<WORKSPACE>\analytics.db')
for r in con.execute("SELECT name, sql FROM sqlite_master WHERE type='table'"):
    print(r[1])
    print('---')
for t in con.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall():
    print(t[0], con.execute(f"SELECT COUNT(*) FROM {t[0]}").fetchone()[0])
    for row in con.execute(f"SELECT * FROM {t[0]} LIMIT 5"):
        print(row)