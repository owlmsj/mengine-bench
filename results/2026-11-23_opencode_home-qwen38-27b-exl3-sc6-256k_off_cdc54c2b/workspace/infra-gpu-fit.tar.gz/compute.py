import csv, json

# Model memory (GB = 10^9 bytes)
weights_gb = 70.0  # 70B params, FP8 = 1 byte each
kv_per_token = 327680 / 1e9  # GB per token
kv_cache_gb = kv_per_token * 32768 * 4  # full context, 4 sequences
overhead_gb = 8.0
total_gb = weights_gb + kv_cache_gb + overhead_gb
print(f"weights={weights_gb} kv={kv_cache_gb} total={total_gb}")

allowed = {"us-east", "us-central", "eu-west"}
cap = 4.0
rows = list(csv.DictReader(open("offers.csv")))
ok = []
for r in rows:
    if r["in_stock"] != "yes":
        print(f"skip {r['offer_id']}: out of stock"); continue
    if r["region"] not in allowed:
        print(f"skip {r['offer_id']}: region {r['region']}"); continue
    price = float(r["usd_per_hour"])
    if price > cap:
        print(f"skip {r['offer_id']}: ${price}/h over cap"); continue
    vram = int(r["gpu_count"]) * float(r["vram_gb_per_gpu"])
    if vram < total_gb:
        print(f"skip {r['offer_id']}: vram {vram} < {total_gb}"); continue
    ok.append((price, r["offer_id"], vram))
    print(f"ok   {r['offer_id']}: vram={vram} ${price}/h")

ok.sort()
best_price, best_id, best_vram = ok[0]
result = {
    "weights_gb": weights_gb,
    "kv_cache_gb": kv_cache_gb,
    "total_gb": total_gb,
    "offer_id": best_id,
    "usd_per_hour": best_price,
    "usd_per_month": round(best_price * 730, 2),
}
json.dump(result, open("result.json", "w"), indent=2)
print(json.dumps(result, indent=2))