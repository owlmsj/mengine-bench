import csv, json, re
from collections import defaultdict

base = r"<WORKSPACE>\backoffice"

invoices = {}
with open(f"{base}/invoices.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = float(row["amount"])

payments = defaultdict(list)  # invoice id -> list of paid amounts
with open(f"{base}/bank_statement_june.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        m = re.search(r"(?:INV|invoice)[- \s]?(10\d\d)", memo, re.IGNORECASE)
        if not m:
            # fees, interest, unidentified PIX -> ignore
            continue
        inv_id = f"INV-{m.group(1)}"
        payments[inv_id].append(float(row["amount"]))

unpaid = []
duplicated = []
mismatched = []
for inv_id in sorted(invoices):
    paid = payments.get(inv_id, [])
    if not paid:
        unpaid.append(inv_id)
    elif len(paid) > 1:
        duplicated.append(inv_id)
    else:
        if abs(paid[0] - invoices[inv_id]) > 0.005:
            mismatched.append({
                "id": inv_id,
                "invoiced": invoices[inv_id],
                "paid": paid[0],
            })

result = {
    "unpaid": unpaid,
    "duplicated": duplicated,
    "mismatched": mismatched,
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)

print(json.dumps(result, indent=2))