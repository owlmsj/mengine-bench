# -*- coding: utf-8 -*-
import json, os, re, html as htmllib, urllib.parse

BASE = os.path.dirname(os.path.abspath(__file__))
SITE = os.path.join(BASE, "site")

def canon(s):
    return s.strip().lower()

pages = {}   # canonical name -> {theme, synonyms[], analogous[]}
hrefmap = {} # filename stem (lower) -> canonical name

# pass 1: read all pages, get canonical name from <h1>
for fn in sorted(os.listdir(SITE)):
    if not fn.endswith(".html") or fn == "index.html":
        continue
    with open(os.path.join(SITE, fn), encoding="utf-8") as f:
        html = f.read()
    m = re.search(r'<main><h1>(.*?)</h1>', html)
    name = canon(htmllib.unescape(m.group(1))) if m else canon(fn[:-5])
    hrefmap[canon(fn[:-5])] = name
    pages[name] = {"theme": None, "synonyms": [], "analogous": [], "html": html}

# pass 2: parse sections
for name, d in pages.items():
    m = re.search(r'<p class="tema">Tema:\s*(.*?)</p>', d["html"])
    if m:
        d["theme"] = htmllib.unescape(m.group(1)).strip()
    for sec in re.finditer(r'<section id="(\w+)">(.*?)</section>', d["html"], re.S):
        sid, body = sec.group(1), sec.group(2)
        for href, label in re.findall(r'<li><a href="([^"]+)">(.*?)</a></li>', body):
            target = canon(urllib.parse.unquote(href)[:-5] if href.endswith(".html") else urllib.parse.unquote(href))
            # resolve: prefer href's canonical page if it exists, else label text
            resolved = hrefmap.get(target) or canon(htmllib.unescape(label))
            if sid == "sinonimos":
                d["synonyms"].append(resolved)
            elif sid == "analogas":
                d["analogous"].append(resolved)
    del d["html"]

# dedupe per word, keep order
for name, d in pages.items():
    seen = set(); s = []
    for x in d["synonyms"]:
        if x not in seen: seen.add(x); s.append(x)
    d["synonyms"] = s
    seen = set(); a = []
    for x in d["analogous"]:
        if x not in seen: seen.add(x); a.append(x)
    d["analogous"] = a

# link map
linkmap = {w: sorted(set(d["synonyms"] + d["analogous"])) for w, d in pages.items()}

with open(os.path.join(BASE, "words.json"), "w", encoding="utf-8") as f:
    json.dump({w: linkmap[w] for w in sorted(pages)}, f, ensure_ascii=False, indent=1)
# meta for the universe view (synonym/analogous split + theme)
with open(os.path.join(BASE, "meta.json"), "w", encoding="utf-8") as f:
    json.dump({w: {"synonyms": pages[w]["synonyms"], "analogous": pages[w]["analogous"], "theme": pages[w]["theme"]} for w in sorted(pages)}, f, ensure_ascii=False, indent=1)

pairs = set()
for w, links in linkmap.items():
    for l in links:
        a, b = (w, l) if w < l else (l, w)
        pairs.add((a, b))

counts = {w: len(l) for w, l in linkmap.items()}
maxc = max(counts.values())
most = sorted([w for w, c in counts.items() if c == maxc])

with open(os.path.join(BASE, "result.json"), "w", encoding="utf-8") as f:
    json.dump({"words": len(pages), "relations": len(pairs), "most_connected": most}, f, ensure_ascii=False, indent=1)

print("words:", len(pages))
print("pairs:", len(pairs))
print("most:", most, "count:", maxc)
missing = sorted({l for links in linkmap.values() for l in links if l not in pages})
print("unresolved:", missing)
print("saudade:", pages.get("saudade"))