# Handoff

Goal: get local-9b Q5 running at 128k context on this box (~8 GB VRAM, WDDM).

Finding (from `scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`):
- Baseline: decode 37.8 t/s, VRAM 7881 MiB = WDDM ceiling, 1494 MiB spilled to Shared Usage. It did not really fit.
- Fix: add `--no-mmproj-offload` and `-ub 512`. Spill gone: 7697 MiB, 38.0 t/s (median of 3).
- Alternatives: Q6_K (7.03 GiB) does not fit at 128k, discard. Q4_K_M fits (7305 MiB, 40.4 t/s), keep only as fallback.

Applied: recipe is written into `scripts/start_server.ps1:165` (local9 block) and `profiles/local/local-9b.json`.

Open / next:
- `evals/README.md` still cites `check_vision.ps1`, which no longer exists. Fix the citation.
- Scratchpad temp-file names need a tidy-up pass.
- Re-run the measurement once after any further change to confirm decode stays ~38 t/s with zero spill.

How I know: numbers above are the measured outputs, repeated across three runs for the fixed config; the spills came from the GPU usage counter showing Shared Usage climbing past the dedicated ceiling.
