import csv, json, math
from collections import defaultdict, OrderedDict

rows = []
with open('./telemetry/playtest_ab.csv', newline='', encoding='utf-8') as f:
    r = csv.DictReader(f)
    for row in r:
        rows.append(row)

# Dedupe by session_id (README: repeated rows = same session; keep first).
seen = set()
kept = []
conflicts = 0
for row in rows:
    sid = row['session_id'].strip()
    if sid in seen:
        kept_row = next(k for k in kept if k['session_id'].strip() == sid)
        if kept_row['completed_tutorial'].strip() != row['completed_tutorial'].strip():
            conflicts += 1
        continue
    seen.add(sid)
    kept.append(row)

print("total_rows:", len(rows), "unique_sessions:", len(kept), "dup_conflicts:", conflicts)

def norm_variant(v):
    return v.strip().lower()

# Per-variant counts. Track any unexpected variants.
counts = defaultdict(lambda: {'n': 0, 'completed': 0})
sid_variant = {}
unexpected = []
for row in kept:
    v = norm_variant(row['variant'])
    c = int(row['completed_tutorial'].strip())
    counts[v]['n'] += 1
    counts[v]['completed'] += c
    sid_variant[row['session_id']] = v
    if v not in ('a', 'b'):
        unexpected.append((row['session_id'], repr(row['variant'])))

print("variants:", dict(counts))
print("unexpected_variants:", unexpected[:10], "..." if len(unexpected) > 10 else "")
print("by_session_id_variant_check:", {v: sum(1 for s in sid_variant.values() if s == v) for v in ('a','b')})

na = counts['a']['n']; ka = counts['a']['completed']
nb = counts['b']['n']; kb = counts['b']['completed']
pa = ka / na
pb = kb / nb

p_pool = (ka + kb) / (na + nb)
se_pool = math.sqrt(p_pool * (1 - p_pool) * (1/na + 1/nb))
z = (pb - pa) / se_pool
# two-sided p-value from standard normal via erfc
pval = math.erfc(abs(z) / math.sqrt(2))

alpha = 0.05
ship_b = (pb > pa) and (pval < alpha)

result = OrderedDict([
    ("ship_b", ship_b),
    ("sessions_a", na),
    ("sessions_b", nb),
    ("completion_rate_a", round(pa, 6)),
    ("completion_rate_b", round(pb, 6)),
    ("p_value", round(pval, 6)),
])
print("RESULT:", json.dumps(result, indent=2))
print("delta_pp:", round((pb-pa)*100, 2), "pp")

with open('./result.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2)
    f.write('\n')
print("WROTE ./result.json")
