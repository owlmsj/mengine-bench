import re, struct, json

data = open('prices.db', 'rb').read()
print('file size:', len(data))

# Identify nonzero runs (already known but recompute)
runs = []
prev = False
start = 0
for i, b in enumerate(data):
    nz = b != 0
    if nz and not prev:
        start = i
    if prev and not nz:
        runs.append((start, i))
    prev = nz
if prev:
    runs.append((start, len(data)))

text_re = re.compile(rb'[\x20-\x7e]{1,}')

# Walk runs. Each "record" is a contiguous chunk of bytes separated from the next
# by one or more zero bytes AND ending at a record boundary. Records are short and
# share a common structural pattern: [len?][type?][TEXT][binary trailer].
# We will split purely on text-token + trailing binary until the next gap.

# Combine runs that are close together (gap <= some small threshold) into fragments.
# Looking at the data, gaps between records range 1..6 bytes. Records themselves
# contain non-zero text plus a few non-zero binary bytes; then zeros until next record.

fragments = []
cur_start = None
cur_end = None
for s, e in runs:
    if cur_start is None:
        cur_start = s
        cur_end = e
    else:
        # If the previous run ended exactly where this begins (no zero gap), merge
        if s == cur_end:
            cur_end = e
        else:
            fragments.append((cur_start, cur_end))
            cur_start = s
            cur_end = e
if cur_start is not None:
    fragments.append((cur_start, cur_end))

print('nonzero fragments (contiguous):')
for s, e in fragments:
    print(hex(s), hex(e), repr(data[s:e]))

print()
print('=== Text tokens per fragment ===')
for s, e in fragments:
    toks = text_re.findall(data[s:e])
    print(hex(s), [t.decode() for t in toks])
