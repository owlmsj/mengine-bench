import csv, statistics
times=[]; mbp=[]
with open(r"<WORKSPACE>\capture\presentmon.csv") as f:
    r=csv.DictReader(f)
    for row in r:
        times.append(float(row['TimeInSeconds'])); mbp.append(float(row['MsBetweenPresents']))
for lo,hi in [(42,47),(2,6)]:
    sub=[(t,m) for t,m in zip(times,mbp) if lo<=t<=hi]
    print(f"frames {lo}-{hi}s: n={len(sub)} mean={statistics.mean(m for _,m in sub):.2f} max={max(m for _,m in sub):.2f} min={min(m for _,m in sub):.2f}")
