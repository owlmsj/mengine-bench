import csv, statistics, math

pm_path = r"<WORKSPACE>\capture\presentmon.csv"
times=[]; mbp=[]; sync=[]; flags=[]; dropped=[]; render=[]; displayed=[]; api=[]
with open(pm_path) as f:
    r=csv.DictReader(f)
    for row in r:
        times.append(float(row['TimeInSeconds']))
        mbp.append(float(row['MsBetweenPresents']))
        sync.append(int(row['SyncInterval']))
        flags.append(int(row['PresentFlags']))
        dropped.append(int(row['Dropped']))
        render.append(float(row['MsUntilRenderComplete']))
        displayed.append(float(row['MsUntilDisplayed']))
        api.append(float(row['MsInPresentAPI']))

n=len(mbp)
print("frames:",n)
print("time span:",times[-1])
mean_mbp=statistics.mean(mbp)
avg_fps=1000/mean_mbp
print("mean Mbp:",round(mean_mbp,3),"-> avg FPS:",round(avg_fps,2))
srt=sorted(mbp)
idx=math.ceil(0.99*n)-1
p99=srt[idx]
low_1pct=1000/p99
print("p99 Mbp:",round(p99,3),"-> 1% low FPS:",round(low_1pct,2))
print("max Mbp:",round(max(mbp),3),"min Mbp:",round(min(mbp),3))
med=statistics.median(mbp)
print("median Mbp:",round(med,3))
threshold=med*2.5
hitch_idx=[i for i,v in enumerate(mbp) if v>threshold]
print("hitch count (>2.5x median):",len(hitch_idx))
for i in hitch_idx[:60]:
    print(f"  t={times[i]:.3f}s frame#{i} Mbp={mbp[i]:.2f} SyncInt={sync[i]} Flags={flags[i]} Dropped={dropped[i]} render={render[i]:.2f} displayed={displayed[i]:.2f} api={api[i]:.3f}")

# also dump the worst 15
worst=sorted(range(n),key=lambda i:mbp[i],reverse=True)[:15]
print("\n--- worst 15 frames ---")
for i in worst:
    print(f"  t={times[i]:.3f}s frame#{i} Mbp={mbp[i]:.2f} SyncInt={sync[i]} Flags={flags[i]} Dropped={dropped[i]} render={render[i]:.2f} displayed={displayed[i]:.2f} api={api[i]:.3f}")

# Distribution of present flags
from collections import Counter
print("\nSyncInterval counts:",Counter(sync))
print("PresentFlags counts:",Counter(flags))
print("Dropped counts:",Counter(dropped))
