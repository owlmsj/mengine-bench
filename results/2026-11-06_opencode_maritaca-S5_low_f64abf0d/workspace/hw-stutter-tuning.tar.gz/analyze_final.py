import csv, statistics, math

pm_path = r"<WORKSPACE>\capture\presentmon.csv"
sn_path = r"<WORKSPACE>\capture\sensors.csv"

times=[]; mbp=[]
with open(pm_path) as f:
    r=csv.DictReader(f)
    for row in r:
        times.append(float(row['TimeInSeconds']))
        mbp.append(float(row['MsBetweenPresents']))
n=len(mbp)
mean_mbp=statistics.mean(mbp)
avg_fps=1000/mean_mbp
srt=sorted(mbp)
idx=math.ceil(0.99*n)-1
p99=srt[idx]
low_1pct=1000/p99

# sensor: classify each presentmon frame by whether its timestamp falls in an L1 second
s_time=[]; s_gpustate=[]; s_dpc=[]; s_proc=[]
with open(sn_path) as f:
    r=csv.DictReader(f)
    for row in r:
        s_time.append(int(row['time_s']))
        s_gpustate.append(row['gpu_pcie_link_state'])
        s_dpc.append(int(row['dpc_latency_us']))
        s_proc.append(row['top_cpu_process'])
state_by_sec={t:g for t,g in zip(s_time,s_gpustate)}
dpc_by_sec={t:d for t,d in zip(s_time,s_dpc)}
proc_by_sec={t:p for t,p in zip(s_time,s_proc)}

# map each frame to nearest sensor second
l1_frames=[]; l0_frames=[]
for t,m in zip(times,mbp):
    sec=int(t)  # floor -> sensor sample taken at start of second covers [sec, sec+1)
    st=state_by_sec.get(sec)
    if st=='L1':
        l1_frames.append(m)
    elif st=='L0':
        l0_frames.append(m)
print(f"L1-second frames: n={len(l1_frames)} mean={statistics.mean(l1_frames):.2f}ms ({1000/statistics.mean(l1_frames):.1f} fps)")
print(f"L0-second frames: n={len(l0_frames)} mean={statistics.mean(l0_frames):.2f}ms ({1000/statistics.mean(l0_frames):.1f} fps)")

# Confirm: do ALL L1 seconds coincide with high frame times? List them.
print("\nPer-L1-second stats:")
for sec in sorted(state_by_sec):
    if state_by_sec[sec]=='L1':
        fs=[m for t,m in zip(times,mbp) if int(t)==sec]
        if fs:
            print(f"  sec={sec}: n={len(fs)} mean={statistics.mean(fs):.2f}ms min={min(fs):.2f} max={max(fs):.2f} proc={proc_by_sec[sec]} dpc={dpc_by_sec[sec]}us")

print(f"\nFINAL avg_fps={round(avg_fps,2)} low_1pct_fps={round(low_1pct,2)}")
print(f"p99 Mbp={p99:.3f} mean Mbp={mean_mbp:.3f}")
