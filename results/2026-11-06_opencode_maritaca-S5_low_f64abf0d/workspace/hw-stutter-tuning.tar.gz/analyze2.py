import csv, statistics, math
from collections import Counter

pm_path = r"<WORKSPACE>\capture\presentmon.csv"
sn_path = r"<WORKSPACE>\capture\sensors.csv"

times=[]; mbp=[]; render=[]; displayed=[]; api=[]
with open(pm_path) as f:
    r=csv.DictReader(f)
    for row in r:
        times.append(float(row['TimeInSeconds']))
        mbp.append(float(row['MsBetweenPresents']))
        render.append(float(row['MsUntilRenderComplete']))
        displayed.append(float(row['MsUntilDisplayed']))
        api.append(float(row['MsInPresentAPI']))
n=len(mbp)

s_time=[]; s_cpuclk=[]; s_cpuutil=[]; s_gpustate=[]; s_dpc=[]; s_disk=[]; s_proc=[]
with open(sn_path) as f:
    r=csv.DictReader(f)
    for row in r:
        s_time.append(int(row['time_s']))
        s_cpuclk.append(int(row['cpu_clock_mhz']))
        s_cpuutil.append(int(row['cpu_util_pct']))
        s_gpustate.append(row['gpu_pcie_link_state'])
        s_dpc.append(int(row['dpc_latency_us']))
        s_disk.append(int(row['disk_active_pct']))
        s_proc.append(row['top_cpu_process'])

med=statistics.median(mbp)

hitch_times=[]
in_burst=False
for i,v in enumerate(mbp):
    if v > med*1.8 and not in_burst:
        hitch_times.append(times[i])
        in_burst=True
    elif v < med*1.3:
        in_burst=False
print("Hitch burst onsets (sec):", [round(t,2) for t in hitch_times])
diffs=[round(hitch_times[i+1]-hitch_times[i],2) for i in range(len(hitch_times)-1)]
print("Inter-hitch diffs:", diffs)

print("\nSensor rows with DPC > 150us:")
for i,t in enumerate(s_time):
    if s_dpc[i]>150:
        print(f"  t={t}s dpc={s_dpc[i]}us cpuclk={s_cpuclk[i]} cpuutil={s_cpuutil[i]} gpustate={s_gpustate[i]} disk={s_disk[i]} proc={s_proc[i]}")

hitch_set=set()
for t in hitch_times:
    hi=int(t)
    for dt in (-1,0,1,2,3,4):
        hitch_set.add(hi+dt)
dpc_hitch=[s_dpc[i] for i,t in enumerate(s_time) if t in hitch_set]
dpc_norm=[s_dpc[i] for i,t in enumerate(s_time) if t not in hitch_set]
print("\nAvg DPC us during hitch-window:", round(statistics.mean(dpc_hitch),1))
print("Avg DPC us outside:", round(statistics.mean(dpc_norm),1))

l1_to_l0=sum(1 for i in range(1,len(s_gpustate)) if s_gpustate[i]=='L0' and s_gpustate[i-1]=='L1')
l0_to_l1=sum(1 for i in range(1,len(s_gpustate)) if s_gpustate[i]=='L1' and s_gpustate[i-1]=='L0')
print("\nGPU PCIe L1->L0 transitions:", l1_to_l0, " L0->L1:", l0_to_l1)

l1to0_secs=[s_time[i] for i in range(1,len(s_gpustate)) if s_gpustate[i]=='L0' and s_gpustate[i-1]=='L1']
print("L1->L0 transition seconds:", l1to0_secs)

# For each hitch onset second, what was the link state in the preceding second?
print("\nLink state around each hitch onset (sensor sec -1,0,+1):")
for t in hitch_times:
    hi=int(round(t))
    idx=s_time.index(hi) if hi in s_time else None
    if idx is not None:
        lo=max(0,idx-1); hi_i=min(len(s_time)-1,idx+1)
        print(f"  hitch@{t:.2f}s -> {s_time[lo:hi_i+1]} states={s_gpustate[lo:hi_i+1]} dpc={s_dpc[lo:hi_i+1]}")
