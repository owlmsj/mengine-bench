import re
pat = open(r'<WORKSPACE>\regex.txt').read().strip()
log = open(r'<WORKSPACE>\server.log').read()
print('PATTERN:', repr(pat))
print('---')
found = re.findall(pat, log, re.MULTILINE)
for m in found:
    print(m)
print('---count', len(found))

# Additional edge cases
tests = [
    # line, expected date or None
    ("2026-04-02 07:15:09 INFO gateway accepted 10.12.0.7 for build 2026-04-01", "2026-04-02"),
    ("2026-04-02 07:15:11 INFO cache warm, 412 keys, next sweep 2026-04-03", None),  # no IP
    ("2026-04-02 07:16:40 WARN peer 192.168.40.3 slow, retry window 2026-04-02 to 2026-04-05", "2026-04-05"),
    ("2026-04-02 07:18:02 INFO job 7781-20-4410 queued by scheduler", None),
    ("2026-04-02 07:19:30 ERROR upstream 172.20.1.14 refused handshake", "2026-04-02"),
    # tricky ones
    ("no ip here 2026-02-30 but date invalid", None),  # Feb 30 invalid -> should NOT match (but also no IP so none anyway)
    ("1.2.3.4 2026-02-29 ok", "2026-02-29"),  # Feb 29 allowed every year per brief
    ("1.2.3.4 2026-02-30 bad", None),  # Feb 30 invalid
    ("1.2.3.4 2026-13-01 bad month", None),
    ("1.2.3.4 2026-04-31", None),  # April 31 invalid
    ("1.2.3.4 2026-04-30", "2026-04-30"),
    ("1.2.3.4 2026-04-01extra", None),  # letter right after date -> not count
    ("x1.2.3.4 2026-04-01", None),  # letter before IP -> IP doesn't count -> line has no valid IP -> nothing
    ("1.2.3.4x 2026-04-01", None),  # letter after IP
    ("10.0.0.1 2026-04-01 2026-04-02", "2026-04-02"),  # last date on line
    ("255.255.255.255 2026-04-01", "2026-04-01"),
    ("256.1.1.1 2026-04-01", None),  # invalid octet -> no IP -> nothing? Actually 256 invalid; but could the rest match? whole IP must be valid
    ("1.2.3.4 2026-04-01 2026-04-02 2026-04-03", "2026-04-03"),
    ("2026-04-01 1.2.3.4 2026-04-02", "2026-04-02"),
    ("2026-04-01 2026-04-02 1.2.3.4", "2026-04-02"),
    ("0.0.0.0 2026-04-01", "2026-04-01"),
    ("00.00.00.00 2026-04-01", None),  # leading zeros -> invalid IP
    ("01.02.03.04 2026-04-01", None),  # leading zeros
]
print("=== edge ===")
for line, exp in tests:
    got = re.findall(pat, line, re.MULTILINE)
    g = got[0] if got else None
    status = 'OK' if g == exp else 'FAIL'
    print(f"{status}: {line!r} -> got={g!r} exp={exp!r}")
