//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        let mut score = slot.lock().unwrap();
        *score += points;
        // Drop the player lock before taking the total lock, so `award` and
        // `transfer` never hold both at once (they lock in disjoint pairs).
        drop(score);
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return; // locking the same slot twice would deadlock
        }
        let from_slot = self.slot(from);
        let to_slot = self.slot(to);
        // Acquire the two slot locks in a fixed order (by player id) so two
        // concurrent transfers involving the same pair cannot deadlock.
        let (first, second) = if from < to {
            (&from_slot, &to_slot)
        } else {
            (&to_slot, &from_slot)
        };
        let mut a = first.lock().unwrap();
        let mut b = second.lock().unwrap();
        // After sorting, `a` is the `from` slot when from < to, otherwise `b`.
        if from < to {
            *a -= points;
            *b += points;
        } else {
            *b -= points;
            *a += points;
        }
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}

#[cfg(test)]
mod stress {
    use super::*;
    use std::thread;

    #[test]
    fn concurrent_transfers_and_awards_no_deadlock() {
        let board = Board::new();
        for i in 0..8u32 {
            board.join(i, 0);
        }
        let mut handles = vec![];
        for t in 0..16usize {
            let b = board.clone();
            handles.push(thread::spawn(move || {
                for _ in 0..500 {
                    if t % 2 == 0 {
                        b.award((t as u32) % 8, 1);
                    } else {
                        let from = (t as u32) % 8;
                        let to = ((t as u32) + 1) % 8;
                        b.transfer(from, to, 1);
                    }
                }
            }));
        }
        for h in handles {
            h.join().unwrap();
        }
        assert_eq!(board.total(), 8 * 500);
    }
}
