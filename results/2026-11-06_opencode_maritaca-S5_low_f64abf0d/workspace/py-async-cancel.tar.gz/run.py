"""Helper for batch scripts: run zero-argument async jobs with bounded concurrency.

Public API
----------
``run_tasks(tasks, max_concurrent)``
    Await every job returned by ``tasks`` with at most ``max_concurrent`` jobs
    executing at any instant. Returns when all jobs are finished (or raises
    ``KeyboardInterrupt`` after cancelling the outstanding jobs, letting their
    ``except``/``finally`` cleanup finish first).

Design notes
------------
* Jobs are zero-argument callables returning an awaitable, exactly as the brief
  requires. A plain function returning an already-created coroutine object works
  too.
* Concurrency is bounded with an :class:`asyncio.Semaphore`. Each wrapper takes
  the semaphore before invoking the callable and releases it afterwards, so the
  limit applies to jobs actually in flight (not merely created).
* Results are collected with ``return_exceptions=True`` so one failing job does
  not short-circuit the others. Exceptions (including ``CancelledError``) come
  back inside the returned list instead of aborting the gather. Repeated
  failures cause the whole batch to fail fast -- see the ``fail_fast`` flag.
* On ``Ctrl+C`` (``KeyboardInterrupt`` or an external cancellation of this
  coroutine) every outstanding job is cancelled and then awaited so its
  ``try/except CancelledError`` and ``try/finally`` blocks get to run. Only when
  cleanup has completed (or been explicitly abandoned) does the interrupt
  propagate. Additional ``Ctrl+C`` presses during cleanup are deliberately
  swallowed so a single long-running cleanup is not killed prematurely; a
  forced kill (second press with no handler installed) remains the operator's
  escape hatch.
* Standard library only, Python 3.11+.
"""

from __future__ import annotations

import asyncio
from typing import Any, Callable, Iterable, Sequence

__all__ = ["run_tasks"]


def _signal_text(KeyboardInterrupt_: Any, **kwargs: Any) -> None:  # pragma: no cover
    """No-op used only to keep type checkers happy about the local alias."""


async def run_tasks(
    tasks: Iterable[Callable[[], Any]],
    max_concurrent: int,
    *,
    fail_fast: bool = False,
) -> list[Any]:
    """Run every job in *tasks* with bounded concurrency.

    Parameters
    ----------
    tasks
        An iterable of zero-argument callables. Each callable is invoked once
        and must return an awaitable (a coroutine, Task, Future, or any object
        implementing ``__await__``). Callables are consumed lazily in the order
        received.
    max_concurrent
        Maximum number of jobs allowed to execute simultaneously. Must be >= 1.
    fail_fast
        If true, the first unhandled exception raised by a job stops the batch:
        remaining jobs are cancelled and cleaned up, and that exception is
        raised. If false (the default), every job is allowed to finish and
        exceptions are returned inside the result list (as
        ``BaseException`` objects, mirroring ``asyncio.gather(...,
        return_exceptions=True)``).

    Returns
    -------
    list
        One result per job, in the same order as *tasks*. A slot holds either
        the job's return value or the ``BaseException`` it raised. Empty input
        yields an empty list.

    Raises
    ------
    ValueError
        If ``max_concurrent`` is not a positive integer.
    KeyboardInterrupt
        Propagated after the interrupt was caught, all jobs were cancelled and
        their cleanup was awaited.
    """

    if isinstance(max_concurrent, bool) or not isinstance(max_concurrent, int):
        raise TypeError("max_concurrent must be an int")
    if max_concurrent < 1:
        raise ValueError("max_concurrent must be >= 1")

    sem = asyncio.Semaphore(max_concurrent)

    async def _invoke(job: Callable[[], Any]) -> Any:
        # The callable itself may be synchronous; only its result is awaited.
        async with sem:
            coro = job()
            if not hasattr(coro, "__await__"):
                raise TypeError(
                    f"job {job!r} did not return an awaitable, got {type(coro).__name__}"
                )
            return await coro

    # Build child tasks eagerly so each gets the same start-ordering guarantee
    # as asyncio.gather() provides.
    children = [asyncio.create_task(_invoke(job)) for job in tasks]

    async def _wait_all() -> list[Any]:
        # return_exceptions=True keeps unrelated successes intact and lets us
        # fold CancelledError into the result list consistently.
        return await asyncio.gather(*children, return_exceptions=True)

    try:
        results = await _wait_all()
    except (KeyboardInterrupt, asyncio.CancelledError):
        for child in children:
            child.cancel()
        # Keep waiting through repeated Ctrl+C so cleanup can complete. The
        # shielded gather makes sure the inner tasks are never asked to abort
        # twice; the outer loop simply re-arms the wait if an interrupt lands
        # inside this handler.
        while True:
            try:
                results = await asyncio.shield(_wait_all())
                break
            except (KeyboardInterrupt, asyncio.CancelledError):
                continue
        if fail_fast:
            # Surface the first real failure; cancellations and other jobs stay
            # collected in ``results`` for inspection by callers who want them.
            for r in results:
                if isinstance(r, BaseException) and not isinstance(
                    r, (asyncio.CancelledError,)
                ):
                    raise r
            raise
        return results

    if fail_fast:
        for r in results:
            if isinstance(r, BaseException):
                raise r
    return results
