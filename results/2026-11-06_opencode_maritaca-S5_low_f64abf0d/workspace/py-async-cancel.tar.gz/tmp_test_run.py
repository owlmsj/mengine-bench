"""Smoke tests for run.run_tasks (not the graded artifact)."""
import asyncio
import signal
import sys
from run import run_tasks


async def ok(n):
    await asyncio.sleep(0.01)
    return n * 2


async def fail(n):
    await asyncio.sleep(0.01)
    raise ValueError(f"boom {n}")


async def cleanup_job(name, evt):
    try:
        await asyncio.sleep(5)
        return "never"
    finally:
        evt.set()


async def main():
    # basic ordering & values
    res = await run_tasks([lambda: ok(1), lambda: ok(2)], 3)
    assert res == [2, 4], res

    # empty input
    assert await run_tasks([], 4) == []

    # exceptions retained in result list by default
    res = await run_tasks([lambda: ok(1), lambda: fail(2)], 2)
    assert isinstance(res[1], ValueError) and res[1].args == ("boom 2",)
    assert res[0] == 2

    # concurrency actually bounded
    running = 0
    peak = 0
    async def tracked(i):
        nonlocal running, peak
        running += 1
        peak = max(peak, running)
        await asyncio.sleep(0.05)
        running -= 1
        return i
    tasks = [lambda i=i: tracked(i) for i in range(8)]
    await run_tasks(tasks, 3)
    assert peak <= 3, peak

    print("SMOKE OK")


asyncio.run(main())
