import asyncio, sys
print("platform:", sys.platform)
p = asyncio.new_event_loop()
try:
    p.add_signal_handler(2, lambda: None)
    print("add_signal_handler OK")
except Exception as e:
    print("add_signal_handler FAIL:", type(e).__name__, e)
