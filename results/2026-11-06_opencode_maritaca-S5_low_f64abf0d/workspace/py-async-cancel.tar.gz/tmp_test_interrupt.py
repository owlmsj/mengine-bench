"""Interrupt / cleanup smoke test for run.run_tasks."""
import asyncio
from run import run_tasks


async def main():
    done = asyncio.Event()
    started = asyncio.Event()

    async def slow():
        started.set()
        try:
            await asyncio.sleep(60)
        finally:
            # cleanup must be allowed to complete even under repeat interrupts
            await asyncio.sleep(0.5)
            done.set()

    task = asyncio.create_task(run_tasks([lambda: slow()], 1))
    await started.wait()
    await asyncio.sleep(0.05)

    # Simulate Ctrl+C arriving *inside* the wait loop of run_tasks: cancel
    # the outer task, which should trigger cancellation + cleanup then propagate.
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass

    assert done.is_set(), "cleanup did not run"
    print("INTERRUPT CLEANUP OK")


asyncio.run(main())
