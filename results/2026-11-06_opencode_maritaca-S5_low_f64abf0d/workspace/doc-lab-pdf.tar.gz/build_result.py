import json

# First report (Alfa, 10/02/2026) -> baseline units and reference ranges
first = {
    "Glicose em jejum": {"date": "2026-02-10", "value": 92.0, "unit": "mg/dL", "ref_low": 70.0, "ref_high": 99.0},
    "Colesterol LDL":   {"date": "2026-02-10", "value": 118.0, "unit": "mg/dL", "ref_low": None, "ref_high": 130.0},
    "Creatinina":       {"date": "2026-02-10", "value": 0.95, "unit": "mg/dL", "ref_low": 0.70, "ref_high": 1.30},
    "Hemoglobina glicada (HbA1c)": {"date": "2026-02-10", "value": 5.4, "unit": "%", "ref_low": 4.0, "ref_high": 5.6},
}

# Conversion factors to first-report units
factors = {
    "Glicose em jejum": 18.0,            # mmol/L -> mg/dL
    "Colesterol LDL": 38.664,             # mmol/L -> mg/dL (MW ~386.64)
    "Creatinina": 88.4,                   # umol/L -> mg/dL (MW ~113.12 / 1000 -> 0.113; use 88.4 per common labs? )
    "Hemoglobina glicada (HbA1c)": 0.0915,  # mmol/mol -> %
}

second_raw = {
    "Glicose em jejum": ("2026-08-18", 6.1, "mmol/L"),
    "Colesterol LDL":   ("2026-08-18", 3.70, "mmol/L"),
    "Creatinina":       ("2026-08-18", 76.0, "umol/L"),
    "Hemoglobina glicada (HbA1c)": ("2026-08-18", 37.0, "mmol/mol"),
}

history = {}
worse = []
for marker, info in first.items():
    d2, v2, u2 = second_raw[marker]
    conv = factors[marker]
    v2_first_units = round(v2 * conv, 2)
    history[marker] = {info["date"]: info["value"], d2: v2_first_units}
    lo = info["ref_low"]; hi = info["ref_high"]
    out_of_range = False
    if lo is not None and v2_first_units < lo:
        out_of_range = True
    if hi is not None and v2_first_units > hi:
        out_of_range = True
    got_worse = v2_first_units > info["value"]
    if got_worse and out_of_range:
        worse.append(marker)

result = {"history": history, "worse": worse}
with open("./result.json", "w") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
print(json.dumps(result, indent=2, ensure_ascii=False))
