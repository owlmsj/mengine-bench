/**
 * Hook bus for harness plugins (OpenCode-style hooks). The README states the contract:
 * handlers run one after another in subscription order, emit resolves after all of them,
 * a handler error rejects emit, and unsubscribing during an emit does not stop the others.
 */

export type Handler<T> = (payload: T) => void | Promise<void>;

export class HookBus {
  private handlers: Map<string, Handler<unknown>[]> = new Map();

  /** Subscribes a handler to an event; returns the function that unsubscribes it. */
  on<T>(event: string, handler: Handler<T>): () => void {
    const list = this.handlers.get(event) ?? [];
    list.push(handler as Handler<unknown>);
    this.handlers.set(event, list);
    return () => {
      const index = list.indexOf(handler as Handler<unknown>);
      if (index >= 0) {
        list.splice(index, 1);
      }
    };
  }

  /** Runs the handlers of an event with the payload. */
  async emit<T>(event: string, payload: T): Promise<void> {
    // Snapshot the subscribers that existed when emit started, so that
    // unsubscribing (or subscribing) during an emit does not change which
    // handlers run in this emit.
    const list = [...(this.handlers.get(event) ?? [])];
    // Sequential on purpose: each handler settles before the next starts, and
    // a rejection aborts the remaining handlers and rejects emit.
    for (const handler of list) {
      await handler(payload);
    }
  }

  /** How many handlers an event has. */
  count(event: string): number {
    return (this.handlers.get(event) ?? []).length;
  }
}
