# CFO Briefing - H1 2026 Closed Books

**Prepared:** 2026-11-06
**Scope:** Jan-Jun 2026 (first half of 2026, closed)
**Source ledger:** finance/ledger.csv (86 postings), cash_balance.txt, chart_of_accounts.csv

---

## Monthly P&L Summary (BRL)

| Month | Revenue | Gross Profit | GM % | Opex | EBITDA |
|-------|---------|-------------|------|------|--------|
| 2026-01 | 200,510.87 | 140,418.95 | 70.03% | -350,697.91 | -210,278.96 |
| 2026-02 | 216,328.06 | 152,049.35 | 70.29% | -364,349.43 | -212,300.08 |
| 2026-03 | 219,066.17 | 149,970.12 | 68.46% | -354,495.57 | -204,525.45 |
| 2026-04 | 238,163.26 | 167,295.53 | 70.24% | -364,246.18 | -196,950.65 |
| 2026-05 | 243,032.89 | 169,059.76 | 69.56% | -371,005.58 | -201,945.82 |
| 2026-06 | 272,391.57 | 197,228.88 | 72.41% | -390,197.10 | -192,968.22 |

H1 totals: Revenue R$ 1,389,492.82; Gross Profit R$ 975,822.59; blended GM ~70.2%; EBITDA R$ -1,218,869.18.

## How each month went

- **January:** Highest gross margin quarter-start at 70.0%. Biggest single drag in the period: combined sales + marketing (R$143k) and R&D (R$163k). Largest monthly loss (-R$210k).
- **February:** Margin holds (70.3%). Sales/marketing slightly lower but R&D spikes to R$182k. Loss flat vs January.
- **March:** Margin dips to 68.5% (lowest in H1). Cost discipline on both COGS and opex improved slightly, but revenue growth softened. Refunds hit R$6,814.
- **April:** Margin recovers to 70.2%. First real inflection: revenue jumps to R$238k (+9% MoM) and losses narrow to -R$197k (best so far).
- **May:** Margin eases back to 69.6%. Revenue keeps climbing (+6% MoM) to R$243k; COGS grows faster than revenue that month, narrowing net gain.
- **June:** Best performance in H1. Revenue accelerates to R$272k (+12% MoM, fastest growth in the half). Gross margin peaks at 72.4%, COGS ratio tightens, and EBITDA improves to -R$193k. The trajectory is moving the right way into Q3.

Trend line: Revenue up 35.8% Jan -> Jun (CAGR ~7.5%/month); Gross margin expanded 240 bps over the half; losses narrowed every other month as scale began to outpace spend.

## Cash & Runway

- Latest closing cash: R$ 1,847,350.40 (30/06/2026, from cash_balance.txt).
- Burn (board definition = avg negative EBITDA of last three closed months Apr/May/Jun): R$ 197,288.23 / month.
- **Runway: 9.36 months** from 30/06/2026 (cash covers burn through roughly mid-April 2027).

Comparison anchor: 31/05/2026 cash was R$ 2,309,188.00. Net drawdown of R$ 461,837.60 across May->June, broadly consistent with the June EBITDA plus working-capital movement.

## Headline numbers for the deck

- H1-2026 revenue: **R$ 1.39M**, growing ~7.5%/month.
- Blended gross margin: **~70.2%**; exits June at **72.4%**.
- H1 EBITDA burn: **-R$ 1.22M**; monthly burn rate trending down to -R$ 193k.
- Cash position: **R$ 1.85M**; runway **9.4 months** at current board-defined burn.

## Open items flagged by the books (not changes, questions for the CFO)

1. `3.1.09` shows two "Refund customer Kestrel" entries (Mar and May, -R$6,814.15 and -R$8,634.37). Confirm whether this is one-off churn or recurring dispute exposure.
2. COG ratios tighten meaningfully in June; worth confirming no deferred/cloud-cost catching up ahead.
3. Board notes define burn off EBITDA only (no capex, tax, debt service, or working capital adjustments). Flag explicitly if the investor deck wants fully-loaded cash burn instead.
