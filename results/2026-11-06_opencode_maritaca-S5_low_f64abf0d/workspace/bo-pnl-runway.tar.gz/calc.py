import csv, re

def brl(s):
    s = s.strip()
    s = re.sub(r'\.', '', s)
    s = s.replace(',', '.')
    return float(s)

# chart of accounts
coa = {}
with open('./finance/chart_of_accounts.csv') as f:
    r = csv.DictReader(f, delimiter=';')
    for row in r:
        coa[row['account']] = (row['name'], row['pnl_line'])

rows = []
with open('./finance/ledger.csv') as f:
    r = csv.DictReader(f, delimiter=';')
    for row in r:
        d, m, a = row['date'].split('/')
        dt = "{}-{}-{}".format(a, m, d)
        acct = row['account']
        amt = brl(row['amount'])
        name, line = coa[acct]
        rows.append((dt, acct, name, line, amt))

from collections import defaultdict
months = defaultdict(lambda: defaultdict(float))
for dt, acct, name, line, amt in rows:
    mo = dt[:7]
    months[mo][line] += amt

lines = ['revenue', 'cogs', 'sales_marketing', 'rnd', 'ga', 'financial']
print("Month | " + " | ".join(lines))
data = {}
for mo in sorted(months):
    vals = [round(months[mo][l], 2) for l in lines]
    data[mo] = dict(zip(lines, vals))
    print(mo + " | " + " | ".join("{:>12,.2f}".format(v) for v in vals))

print("")
print("Per-month derived:")
for mo in sorted(data):
    d = data[mo]
    rev = d['revenue']
    cogs = d['cogs']
    gp = rev + cogs
    gm = gp / rev * 100 if rev else 0
    opex = d['sales_marketing'] + d['rnd'] + d['ga']
    ebitda = gp + opex  # excludes financial (interest & taxes)
    print("{}: revenue={:,.2f} gross_profit={:,.2f} gm%={:.2f} opex={:,.2f} ebitda={:,.2f}".format(mo, rev, gp, gm, opex, ebitda))

# Cash
cash_30jun = brl('1847350,40')
print("\nLatest cash (30/06/2026):", "{:,.2f}".format(cash_30jun))

# Burn = avg monthly negative EBITDA of last 3 closed months (Apr,May,Jun)
last3 = ['2026-04', '2026-05', '2026-06']
ebitdas = [(data[m]['revenue'] + data[m]['cogs'] + data[m]['sales_marketing'] + data[m]['rnd'] + data[m]['ga']) for m in last3]
print("Last3 EBITDA:", ["{:,.2f}".format(e) for e in ebitdas])
burn = sum([abs(e) for e in ebitdas]) / 3
print("Burn (avg |negative EBITDA|):", "{:,.2f}".format(burn))
runway = cash_30jun / burn
print("Runway months:", round(runway, 2))