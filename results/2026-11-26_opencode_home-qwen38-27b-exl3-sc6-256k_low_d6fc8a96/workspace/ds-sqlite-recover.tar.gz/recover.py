import json, struct, re

data = open('prices.db','rb').read()
print('size', len(data))
print('head', data[:16].hex())

rows = []
# scan for readable text fragments
i = 0
frags = []
while i < len(data):
    j = i
    while j < len(data) and 32 <= data[j] < 127:
        j += 1
    if j - i >= 3:
        frags.append((i, data[i:j].decode('ascii')))
    i = j if j > i else i + 1
print('fragments:')
for off, s in frags:
    print(off, repr(s))