import json, struct

data = open('prices.db','rb').read()

def varint(buf, i):
    n = len(buf)
    result = 0
    for pos in range(9):
        if i + pos >= n:
            return None, i
        b = buf[i+pos]
        if pos == 8:
            return (result << 8) | b, i+9
        result = (result << 7) | (b & 0x7f)
        if not (b & 0x80):
            return result, i+pos+1
    return result, i+9

def sval(buf, i, st):
    if st == 0: return None
    if st == 1: return struct.unpack_from('>b', buf, i)[0]
    if st == 2: return struct.unpack_from('>h', buf, i)[0]
    if st in (3,4): return struct.unpack_from('>i', buf, i)[0]
    if st in (5,6): return struct.unpack_from('>q', buf, i)[0]
    if st == 7: return struct.unpack_from('>d', buf, i)[0]
    if st == 8: return 0
    if st == 9: return 1
    if st >= 12:
        ln = (st-12)//2
        return buf[i:i+ln].decode('utf-8','replace')
    return None

rows = []
off = 0
while off < len(data):
    idx = data.find(b'\x0a', off)
    if idx < 0: break
    off = idx + 1
    hlen, i = varint(data, idx+1)
    if hlen is None or hlen < 4 or hlen > 32:
        continue
    ncol, j = varint(data, idx+1+hlen)
    if ncol is None or ncol != 2:
        continue
    serials = []
    ok = True
    for _ in range(2):
        st, j = varint(data, j)
        if st is None: ok = False; break
        serials.append(st)
    if not ok: continue
    k = idx + 1 + hlen
    vals = []
    for st in serials:
        if st in (0,8,9):
            vals.append(sval(data, k, st)); continue
        if st == 1: ln=1
        elif st == 2: ln=2
        elif st in (3,4): ln=4
        elif st in (5,6,7): ln=8
        elif st >= 12: ln=(st-12)//2
        else: break
        if k+ln > len(data): break
        vals.append(sval(data, k, st))
        k += ln
    if len(vals) == 2 and isinstance(vals[0], str) and vals[0].isprintable() and len(vals[0]) >= 3:
        rows.append({"item": vals[0], "price": vals[1]})
        print(idx, serials, vals)

json.dump(rows, open('recovered.json','w'), indent=2)
print('rows:', len(rows))