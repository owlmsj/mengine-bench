import json, struct

data = open('prices.db','rb').read()

def varint(buf, i):
    n = len(buf)
    result = 0
    for pos in range(9):
        if i + pos >= n:
            return None, i
        b = buf[i+pos]
        if pos == 8:
            result = (result << 8) | b
            return result, i+9
        result = (result << 7) | (b & 0x7f)
        if not (b & 0x80):
            return result, i+pos+1
    return result, i+9

def serial_value(buf, i, st):
    if st in (0, 8, 9, 12, 13):
        return None
    if st == 1: return struct.unpack_from('>b', buf, i)[0]
    if st == 2: return struct.unpack_from('>h', buf, i)[0]
    if st == 3: return struct.unpack_from('>i', buf, i)[0]
    if st == 4: return struct.unpack_from('>i', buf, i)[0]
    if st == 5: return struct.unpack_from('>q', buf, i)[0]
    if st == 6: return struct.unpack_from('>q', buf, i)[0]
    if st == 7: return struct.unpack_from('>d', buf, i)[0]
    if st == 8: return 0
    if st == 9: return 1
    if st >= 12:
        ln = (st - 12) // 2
        return buf[i:i+ln].decode('utf-8', 'replace')
    if st >= 13:
        ln = (st - 13) // 2
        return buf[i:i+ln]
    return None

rows = []
# find record starts: byte 0x0a followed by plausible header
off = 3896
while off < len(data):
    if data[off] != 0x0a:
        off += 1
        continue
    hlen, i = varint(data, off+1)
    if hlen is None or hlen < 3 or hlen > 64:
        off += 1
        continue
    ncol, i2 = varint(data, off+1+hlen)
    if ncol is None or ncol != 2:
        off += 1
        continue
    serials = []
    j = i2
    ok = True
    for _ in range(2):
        st, j = varint(data, j)
        if st is None: ok = False; break
        serials.append(st)
    if not ok:
        off += 1
        continue
    # body
    k = off + 1 + hlen
    vals = []
    ok = True
    for st in serials:
        if st in (0,8,9):
            vals.append(None if st==0 else (0 if st==8 else 1)); continue
        if st == 1: ln=1
        elif st == 2: ln=2
        elif st in (3,4): ln=4
        elif st in (5,6,7): ln=8
        elif st >= 12: ln=(st-12)//2
        else: ok=False; break
        if k+ln > len(data): ok=False; break
        vals.append(serial_value(data, k, st))
        k += ln
    if not ok:
        off += 1
        continue
    item, price = vals
    if isinstance(item, str) and item.isprintable() and len(item) >= 3:
        rows.append({"item": item, "price": price})
    off = k

print(json.dumps(rows, indent=1))
json.dump(rows, open('recovered.json','w'), indent=2)