data = open('prices.db','rb').read()
# dump region 3800..4096 in hex + ascii
for off in range(3800, len(data), 16):
    chunk = data[off:off+16]
    hexs = ' '.join(f'{b:02x}' for b in chunk)
    asc = ''.join(chr(b) if 32 <= b < 127 else '.' for b in chunk)
    print(f'{off:5d}  {hexs:<48}  {asc}')