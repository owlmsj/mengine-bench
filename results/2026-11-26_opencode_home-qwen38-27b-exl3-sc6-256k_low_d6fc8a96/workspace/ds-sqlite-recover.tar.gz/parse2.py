import json, struct

data = open('prices.db','rb').read()

def varint(buf, i):
    n = len(buf)
    result = 0
    for pos in range(9):
        if i + pos >= n:
            return None, i
        b = buf[i+pos]
        if pos == 8:
            return (result << 8) | b, i+9
        result = (result << 7) | (b & 0x7f)
        if not (b & 0x80):
            return result, i+pos+1
    return result, i+9

def sval(buf, i, st):
    if st == 0: return None
    if st == 1: return struct.unpack_from('>b', buf, i)[0]
    if st == 2: return struct.unpack_from('>h', buf, i)[0]
    if st in (3,4): return struct.unpack_from('>i', buf, i)[0]
    if st in (5,6): return struct.unpack_from('>q', buf, i)[0]
    if st == 7: return struct.unpack_from('>d', buf, i)[0]
    if st == 8: return 0
    if st == 9: return 1
    if st >= 12:
        ln = (st-12)//2
        return buf[i:i+ln].decode('utf-8','replace')
    return None

rows = []
# known record starts from hex dump
starts = [3896, 3928, 3944, 3961, 3978, 3990, 4007, 4023, 4038, 4058, 4071]
for off in starts:
    if data[off] != 0x0a:
        print('skip', off, data[off:off+4].hex())
        continue
    hlen, i = varint(data, off+1)
    ncol, j = varint(data, off+1+hlen)
    serials = []
    for _ in range(ncol):
        st, j = varint(data, j)
        serials.append(st)
    k = off + 1 + hlen
    vals = []
    ok = True
    for st in serials:
        if st in (0,8,9):
            vals.append(sval(data, k, st)); continue
        if st == 1: ln=1
        elif st == 2: ln=2
        elif st in (3,4): ln=4
        elif st in (5,6,7): ln=8
        elif st >= 12: ln=(st-12)//2
        else: ok=False; break
        if k+ln > len(data): ok=False; break
        vals.append(sval(data, k, st))
        k += ln
    if ok:
        rows.append({"item": vals[0], "price": vals[1]})
        print(off, serials, vals)
    else:
        print(off, 'FAIL', serials)

json.dump(rows, open('recovered.json','w'), indent=2)
print('rows:', len(rows))