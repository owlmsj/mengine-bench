import json, struct

data = open('prices.db','rb').read()

def varint(buf, i):
    n = len(buf)
    result = 0
    for pos in range(9):
        if i + pos >= n:
            return None, i
        b = buf[i+pos]
        if pos == 8:
            return (result << 8) | b, i+9
        result = (result << 7) | (b & 0x7f)
        if not (b & 0x80):
            return result, i+pos+1
    return result, i+9

def sval(buf, i, st):
    if st == 0: return None
    if st == 1: return struct.unpack_from('>b', buf, i)[0]
    if st == 2: return struct.unpack_from('>h', buf, i)[0]
    if st in (3,4): return struct.unpack_from('>i', buf, i)[0]
    if st in (5,6): return struct.unpack_from('>q', buf, i)[0]
    if st == 7: return struct.unpack_from('>d', buf, i)[0]
    if st == 8: return 0
    if st == 9: return 1
    if st >= 12:
        ln = (st-12)//2
        return buf[i:i+ln].decode('utf-8','replace')
    return None

# From hex dump, record starts (0x0a byte) and their serial types:
# 3896: hlen=0x19=25, ncol=0x0a=10?? no...
# Let me re-read the hex dump carefully.
# 3896: 00 00 00 00 00 19 0a 04 00 27 07 66 69 72 73 74
# So at 3901: 19 0a 04 00 27 07 66...
# 0x19 = 25 = header length
# 0x0a = 10 = ncol? No, that's too many.
# Wait, the record format is: 0x0a (rowid marker?) then header_len varint, then ncol varint, then serial types...
# Actually in SQLite, a record is: header_size varint, ncol varint, serial_type[0], serial_type[1], ...
# The 0x0a might be part of the page structure, not the record.
# Let me look at the hex again:
# 3896: 00 00 00 00 00 19 0a 04 00 27 07 66 69 72 73 74
# 3912: 20 61 69 64 20 6b 69 74 3f ef ae 14 7a e1 47 ae
# 3928: 13 09 04 00 1b 07 63 6f 6d 70 61 73 73 40 2f 00
# 3944: 00 00 00 00 00 10 08 04 00 21 02 63 61 6d 70 20
# 3960: 73 74 6f 76 65 01 36 12 07 04 00 25 02 73 6c 65
# 3976: 65 70 69 6e 67 20 62 61 67 00 81 18 06 04 00 25
# 3992: 07 77 61 74 65 72 20 66 69 6c 74 65 72 40 43 f3
# 4008: 33 33 33 33 33 0e 05 04 00 1f 01 72 6f 70 65 20
# 4024: 63 6f 69 6c 12 0c 04 04 00 1b 01 6c 61 6e 74 65
# 4040: 72 6e 18 16 03 04 00 21 07 74 65 6e 74 20 73 74
# 4056: 61 6b 65 40 06 00 00 00 00 00 00 0c 02 04 00 1d
# 4072: 09 6d 61 74 63 68 62 6f 78 0d 01 04 00 1f 08 74
# 4088: 72 61 69 6c 20 6d 61 70

# Looking at the pattern, I see records starting with:
# 3901: 19 0a 04 00 27 07 66 69 72 73 74 20 61 69 64 20 6b 69 74 3f ef ae 14 7a e1 47 ae 13
# header_len=0x19=25, then 0a 04 00 27 07... 
# ncol would be 0x0a=10? No.
# Actually wait: 19 = header size in bytes. Then the header contains ncol varint + serial types.
# 19 bytes header: 19 0a 04 00 27 07 66 69 72 73 74 20 61 69 64 20 6b 69 74 3f ef ae 14 7a e1
# That's 25 bytes. ncol = 0x0a = 10? That doesn't make sense for a 2-column table.

# Let me reconsider. Maybe the record format here is different.
# Looking at: 04 00 27 07 66 69 72 73 74 20 61 69 64 20 6b 69 74 3f
# 04 = serial type 4 (4-byte int), 00 = serial type 0 (NULL)
# Then body: 27 07 66 69 72 73 74 20 61 69 64 20 6b 69 74 3f
# 27 07 = ? 0x27 = 39, 0x07 = 7
# Hmm, maybe 0x27 is the rowid or something else.

# Actually, I think the structure is:
# [header_size varint] [ncol varint] [serial_type_0] [serial_type_1] ... [body]
# For 2 columns: header_size = 1 (ncol) + 1 (st0) + 1 (st1) = 3, or more if varints are multi-byte.

# Let me look at the second record:
# 3928: 13 09 04 00 1b 07 63 6f 6d 70 61 73 73 40 2f 00
# 13 = 19 decimal = header size
# 09 = ncol = 9? No...
# 04 = st0 = 4 (4-byte int)
# 00 = st1 = 0 (NULL)
# 1b = ? 
# 07 = ?
# 63 6f 6d 70 61 73 73 = "compass"
# 40 2f = ?
# 00 = ?

# I think I'm overcomplicating this. Let me just look at the item names and try to find prices nearby.
# Items found: first aid kit, compass, camp stove, sleeping bag, water filter, rope coil, lantern, tent stake, matchbox, trail map
# That's 10 items. Let me look for numeric values near each.

# Actually, looking more carefully at the hex:
# Record 1: "first aid kit" - after the name: 3f ef ae 14 7a e1 47 ae 13
# Record 2: "compass" - after: 40 2f 00 00 00 00 00 10 08 04 00 21 02
# Record 3: "camp stove" - after: 01 36 12 07 04 00 25 02
# Record 4: "sleeping bag" - after: 00 81 18 06 04 00 25 07
# Record 5: "water filter" - after: 40 43 f3 33 33 33 33 33 0e 05 04 00 1f 01
# Record 6: "rope coil" - after: 12 0c 04 04 00 1b 01
# Record 7: "lantern" - after: 18 16 03 04 00 21 07
# Record 8: "tent stake" - after: 40 06 00 00 00 00 00 00 0c 02 04 00 1d 09
# Record 9: "matchbox" - after: 0d 01 04 00 1f 08
# Record 10: "trail map" - (end of file)

# The prices might be encoded in the bytes between item names.
# Let me try a different approach: look for the SQLite record structure more carefully.

# In SQLite, a table b-tree leaf cell is:
# [payload_size varint] [rowid varint] [payload]
# Where payload = [header_size varint] [ncol varint] [serial_types...] [values...]

# So for each record, I need to find: payload_size, rowid, then the payload.
# The payload starts with header_size varint.

# Let me look at the bytes before each item name to find the cell structure.
# "first aid kit" starts at 3906 (0x66 = 'f')
# Before it: 3896: 00 00 00 00 00 19 0a 04 00 27 07
# So: 00 00 00 00 00 = padding? 19 = 25 = payload_size? 0a = rowid? 04 = header_size? 00 = ncol? 27 07 = ?

# Actually 0x0a = 10 could be the rowid. 0x19 = 25 could be payload size.
# Then payload: 04 00 27 07 66 69 72 73 74 20 61 69 64 20 6b 69 74 3f ef ae 14 7a e1 47 ae 13
# header_size = 0x04 = 4? ncol = 0x00 = 0? That doesn't work.

# Let me try: payload_size = 0x19 = 25, rowid = 0x0a = 10
# payload = 25 bytes starting at 3903: 04 00 27 07 66 69 72 73 74 20 61 69 64 20 6b 69 74 3f ef ae 14 7a e1 47 ae 13
# header_size = 0x04 = 4
# ncol = 0x00 = 0? No...

# I'm going in circles. Let me just try to extract the item names and look for reasonable price values.
# The items are camping gear, so prices would be in the range of $1-$200 or so.

# Let me look at the bytes more carefully. The pattern seems to be:
# [some header bytes] [item name] [some bytes] [next item name] ...
# The bytes between item names might contain the price.

# Between "first aid kit" (ends at 3921) and "compass" (starts at 3934):
# 3922: 3f ef ae 14 7a e1 47 ae 13 09 04 00 1b 07
# 3f = '?', ef ae 14 7a e1 47 ae = binary, 13 09 04 00 1b 07 = header for next record?

# Between "compass" (ends at 3941) and "camp stove" (starts at 3955):
# 3942: 40 2f 00 00 00 00 00 10 08 04 00 21 02
# 40 2f = 65.1875 as float? 00 00 00 00 00 = padding? 10 08 04 00 21 02 = header?

# Between "camp stove" (ends at 3966) and "sleeping bag" (starts at 3973):
# 3967: 01 36 12 07 04 00 25 02
# 01 36 = 330? 12 07 04 00 25 02 = header?

# Between "sleeping bag" (ends at 3988) and "water filter" (starts at 3993):
# 3989: 00 81 18 06 04 00 25 07
# 00 81 = 129? 18 06 04 00 25 07 = header?

# Between "water filter" (ends at 4007) and "rope coil" (starts at 4019):
# 4008: 40 43 f3 33 33 33 33 33 0e 05 04 00 1f 01
# 40 43 = 65.25 as float? f3 33 33 33 33 33 = ? 0e 05 04 00 1f 01 = header?

# Between "rope coil" (ends at 4030) and "lantern" (starts at 4035):
# 4031: 12 0c 04 04 00 1b 01
# 12 0c = 4608? 04 04 00 1b 01 = header?

# Between "lantern" (ends at 4045) and "tent stake" (starts at 4049):
# 4046: 18 16 03 04 00 21 07
# 18 16 = 6166? 03 04 00 21 07 = header?

# Between "tent stake" (ends at 4064) and "matchbox" (starts at 4073):
# 4065: 40 06 00 00 00 00 00 00 0c 02 04 00 1d 09
# 40 06 = 64.0234375 as float? 00 00 00 00 00 00 00 = padding? 0c 02 04 00 1d 09 = header?

# Between "matchbox" (ends at 4084) and "trail map" (starts at 4087):
# 4085: 0d 01 04 00 1f 08
# 0d 01 = 3329? 04 00 1f 08 = header?

# This is getting too speculative. Let me try a completely different approach:
# Use Python's sqlite3 module to try to read the file, or use a hex editor approach.

# Actually, the simplest approach: the file is 4096 bytes (one SQLite page).
# The first 100 bytes are the page header. The rest is the cell pointer array and cells.
# Let me parse the page header first.

print("Page header:")
print(data[:100].hex())
print("Page type:", data[0])
print("First free block:", struct.unpack_from('>H', data, 1)[0])
print("Cell count:", struct.unpack_from('>H', data, 3)[0])
print("Cell content start:", struct.unpack_from('>H', data, 5)[0])
print("Free bytes:", struct.unpack_from('>H', data, 7)[0])

# Cell pointer array starts at offset 100 (for leaf table b-tree page)
# or at offset 8 (for interior pages)
# For a leaf table b-tree page (type 0x0d), cell pointers start at offset 100.
cell_count = struct.unpack_from('>H', data, 3)[0]
print("Cell count:", cell_count)
cell_ptrs = []
for i in range(cell_count):
    ptr = struct.unpack_from('>H', data, 100 + i*2)[0]
    cell_ptrs.append(ptr)
print("Cell pointers:", cell_ptrs)

# Now parse each cell
for ptr in cell_ptrs:
    print(f"\nCell at {ptr}:")
    print(data[ptr:ptr+64].hex())