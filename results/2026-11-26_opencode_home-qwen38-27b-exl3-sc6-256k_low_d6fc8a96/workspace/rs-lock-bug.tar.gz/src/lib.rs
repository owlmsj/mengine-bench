//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        let mut players = self.players.lock().unwrap();
        // If the player already has a slot, move the total from the old
        // score to the new one instead of adding the new score on top.
        let delta = match players.get(&id) {
            Some(old) => score - *old.lock().unwrap(),
            None => score,
        };
        players.insert(id, Arc::new(Mutex::new(score)));
        drop(players);
        if delta != 0 {
            let mut total = self.total.lock().unwrap();
            *total += delta;
        }
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        // Hold the slot lock across the read-modify-write so concurrent
        // awards to the same player cannot lose updates.
        let mut score = slot.lock().unwrap();
        *score += points;
        drop(score);
        let mut total = self.total.lock().unwrap();
        *total += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return;
        }
        // Lock both slots in a consistent global order (by PlayerId) so that
        // concurrent opposite-direction transfers cannot deadlock, and do the
        // read-modify-write while holding both locks.
        let (first, second) = if from < to {
            (self.slot(from), self.slot(to))
        } else {
            (self.slot(to), self.slot(from))
        };
        let mut first_guard = first.lock().unwrap();
        let mut second_guard = second.lock().unwrap();
        if from < to {
            *first_guard -= points;
            *second_guard += points;
        } else {
            *second_guard -= points;
            *first_guard += points;
        }
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}