import sqlite3, json
from collections import defaultdict

c = sqlite3.connect('analytics.db')
users = {uid: (plat, test) for uid, plat, test in c.execute("select user_id, platform, is_test from users")}
steps = ['install', 'tutorial_complete', 'first_match', 'purchase']

# first valid occurrence per user per event
first = {}
for uid, name, ts in c.execute("select user_id, name, ts from events"):
    if uid not in users or users[uid][1]:
        continue
    if name not in steps:
        continue
    if uid not in first or ts < first[uid].get(name, '9999'):
        first.setdefault(uid, {})[name] = ts

funnel = defaultdict(lambda: [0]*4)
for uid, ev in first.items():
    plat = users[uid][0]
    last_ts = None
    for i, s in enumerate(steps):
        ts = ev.get(s)
        if ts is None:
            break
        if last_ts is not None and ts < last_ts:
            break  # out of order: not a valid step
        funnel[plat][i] += 1
        last_ts = ts

out = {"funnel": {}, "biggest_drop": {}}
for plat in sorted(funnel):
    f = funnel[plat]
    out["funnel"][plat] = {s: f[i] for i, s in enumerate(steps)}
    conv = {}
    for i in range(1, 4):
        conv[steps[i]] = (f[i] / f[i-1]) if f[i-1] else None
    valid = {s: v for s, v in conv.items() if v is not None}
    out["biggest_drop"][plat] = min(valid, key=valid.get) if valid else None

print(json.dumps(out, indent=2))
with open('result.json', 'w', encoding='utf-8') as fh:
    json.dump(out, fh, indent=2)