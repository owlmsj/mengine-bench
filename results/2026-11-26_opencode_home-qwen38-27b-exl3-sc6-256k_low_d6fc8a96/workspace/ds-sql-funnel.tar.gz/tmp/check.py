import sqlite3
c = sqlite3.connect('analytics.db')
users = {uid: (plat, test) for uid, plat, test in c.execute("select user_id, platform, is_test from users")}
steps = ['install', 'tutorial_complete', 'first_match', 'purchase']
first = {}
for uid, name, ts in c.execute("select user_id, name, ts from events"):
    if uid not in users or users[uid][1] or name not in steps:
        continue
    if name not in first.get(uid, {}) or ts < first[uid][name]:
        first.setdefault(uid, {})[name] = ts

# users whose purchase ts < first_match ts (the diverging case)
n = 0
for uid, ev in first.items():
    if 'purchase' in ev and 'first_match' in ev and ev['purchase'] < ev['first_match']:
        n += 1
print("purchase-before-first_match users:", n)
# also check equal timestamps
n2 = sum(1 for ev in first.values() if 'purchase' in ev and 'first_match' in ev and ev['purchase'] == ev['first_match'])
print("equal ts:", n2)
# check out-of-order for other pairs
for a, b in [('install','tutorial_complete'),('tutorial_complete','first_match')]:
    print(a, 'after', b, sum(1 for ev in first.values() if a in ev and b in ev and ev[a] > ev[b]))