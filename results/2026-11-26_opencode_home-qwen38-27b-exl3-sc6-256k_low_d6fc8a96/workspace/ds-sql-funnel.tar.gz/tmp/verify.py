import sqlite3
c = sqlite3.connect('analytics.db')
q = """
with real as (select user_id, platform from users where is_test=0),
first as (select e.user_id, e.name, min(e.ts) ts from events e join real r on r.user_id=e.user_id
          where e.name in ('install','tutorial_complete','first_match','purchase') group by e.user_id, e.name),
chain as (
  select f.user_id, f.name, f.ts from first f
  where not exists (select 1 from first g where g.user_id=f.user_id
    and (g.name='install' and f.name<>'install' and g.ts>f.ts)
    or (g.name='tutorial_complete' and f.name in ('first_match','purchase') and g.ts>f.ts)
    or (g.name='first_match' and f.name='purchase' and g.ts>f.ts))
)
select r.platform, f.name, count(*) from first f join real r on r.user_id=f.user_id
where f.user_id in (select user_id from chain)
group by r.platform, f.name order by 1,2
"""
for row in c.execute(q):
    print(row)