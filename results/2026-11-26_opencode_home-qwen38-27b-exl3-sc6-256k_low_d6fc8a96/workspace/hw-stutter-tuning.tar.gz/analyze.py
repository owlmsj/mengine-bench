import csv, json, statistics

# presentmon
rows = list(csv.DictReader(open(r'capture\presentmon.csv')))
mbp = [float(r['MsBetweenPresents']) for r in rows]
n = len(mbp)
avg_fps = 1000.0 / (sum(mbp)/n)
srt = sorted(mbp)
p99 = srt[int(0.99*(n-1))]
low1 = 1000.0 / p99
print(f"frames={n} avg_fps={avg_fps:.2f} p99_ms={p99:.3f} low1={low1:.2f}")
print(f"max_ms={max(mbp):.3f} min_ms={min(mbp):.3f}")

# sensor
sens = list(csv.DictReader(open(r'capture\sensors.csv')))
print("sensor rows:", len(sens))

# slow frames: present time in second s, ms > 20 (hitch)
slow = [(float(r['TimeInSeconds']), float(r['MsBetweenPresents'])) for r in rows if float(r['MsBetweenPresents']) > 20]
print("slow frames (>20ms):", len(slow))
for t, ms in slow[:40]:
    s = int(t)
    row = sens[s] if s < len(sens) else None
    print(f"t={t:.3f} ms={ms:.1f} sensor[{s}]: link={row['gpu_pcie_link_state']} dpc={row['dpc_latency_us']} disk={row['disk_active_pct']} top={row['top_cpu_process']} cpu={row['cpu_util_pct']}")

# distribution of link states
from collections import Counter
print("link states:", Counter(r['gpu_pcie_link_state'] for r in sens))
print("dpc>1000 count:", sum(1 for r in sens if int(r['dpc_latency_us'])>1000))
print("disk>50 count:", sum(1 for r in sens if int(r['disk_active_pct'])>50))
print("top procs:", Counter(r['top_cpu_process'] for r in sens))
# correlation: slow frames in L1 seconds vs L0 seconds
l1secs = {i for i,r in enumerate(sens) if r['gpu_pcie_link_state']=='L1'}
slow_in_l1 = sum(1 for t,ms in slow if int(t) in l1secs)
print(f"slow frames in L1 secs: {slow_in_l1}/{len(slow)}; L1 secs={len(l1secs)}")
# dpc in slow seconds
for t,ms in slow[:10]:
    s=int(t)
    if s < len(sens):
        print(f"  slow t={t:.3f} ms={ms:.1f} dpc={sens[s]['dpc_latency_us']}us link={sens[s]['gpu_pcie_link_state']}")