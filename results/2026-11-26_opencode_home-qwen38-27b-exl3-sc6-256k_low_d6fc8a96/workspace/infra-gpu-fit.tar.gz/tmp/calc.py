import csv

weights_gb = 70  # 70B params, FP8 = 1 byte/param -> 70e9 bytes = 70 GB
kv_per_token = 327680
ctx = 32768
seqs = 4
kv_cache_gb = kv_per_token * ctx * seqs / 1e9
overhead_gb = 8
total_gb = weights_gb + kv_cache_gb + overhead_gb
print(f"weights_gb={weights_gb} kv_cache_gb={kv_cache_gb} total_gb={total_gb}")

cap = 4.0
regions = {"us-east", "us-central", "eu-west"}
rows = list(csv.DictReader(open("offers.csv", newline="", encoding="utf-8")))
best = None
for r in rows:
    ok_stock = r["in_stock"] == "yes"
    ok_region = r["region"] in regions
    price = float(r["usd_per_hour"])
    ok_cap = price <= cap
    mem = int(r["gpu_count"]) * float(r["vram_gb_per_gpu"])
    ok_mem = mem >= total_gb
    status = "OK" if (ok_stock and ok_region and ok_cap and ok_mem) else "no"
    print(f"{r['offer_id']} {r['gpu']} x{r['gpu_count']} mem={mem} ${price}/h stock={r['in_stock']} region={r['region']} -> {status}")
    if ok_stock and ok_region and ok_cap and ok_mem:
        if best is None or price < best[1]:
            best = (r["offer_id"], price)
if best:
    oid, p = best
    print(f"BEST: {oid} ${p}/h ${p*730}/month")
else:
    print("NO OFFER QUALIFIES")