import json
from datetime import date

ipca = {
    1985: 242.23, 1986: 79.66, 1987: 363.41, 1988: 980.21, 1989: 1972.91,
    1990: 1620.97, 1991: 472.70, 1992: 1119.10, 1993: 2477.15, 1994: 916.46,
    1995: 22.41,
}

plans = [
    ("Cruzado", date(1986, 2, 28), date(1987, 6, 12)),
    ("Bresser", date(1987, 6, 12), date(1989, 1, 15)),
    ("Verao", date(1989, 1, 15), date(1990, 3, 16)),
    ("Collor I", date(1990, 3, 16), date(1991, 1, 31)),
    ("Collor II", date(1991, 1, 31), date(1994, 7, 1)),
    ("Real", date(1994, 7, 1), None),
]

def months_between(a, b):
    return (b.year - a.year) * 12 + (b.month - a.month)

results = []
for name, launch, nxt in plans:
    y = launch.year
    before = ipca[y - 1]
    after = ipca[y + 1]
    drop = max(0.0, min(1.0, 1 - after / before))
    if nxt is None:
        lasted = 60
    else:
        lasted = months_between(launch, nxt)
    dur = min(lasted, 60) / 60
    score = 0.7 * drop + 0.3 * dur
    results.append({
        "plan": name,
        "launch_date": launch.isoformat(),
        "ipca_before": before,
        "ipca_after": after,
        "months_lasted": lasted,
        "score_drop": round(drop, 4),
        "score_durability": round(dur, 4),
        "score": round(score, 4),
    })

for r in results:
    print(r)

ranked = sorted(results, key=lambda r: r["score"], reverse=True)
top3 = [r["plan"] for r in ranked[:3]]
print("TOP3:", top3)