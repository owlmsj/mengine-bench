import { HookBus } from "../src/bus.ts";
import assert from "node:assert/strict";

// 1. Order: async handlers must settle in subscription order, not completion order.
{
  const bus = new HookBus();
  const order = [];
  bus.on("e", async () => { await new Promise(r => setTimeout(r, 30)); order.push("slow-first"); });
  bus.on("e", async () => { order.push("fast-second"); });
  await bus.emit("e", null);
  assert.deepEqual(order, ["slow-first", "fast-second"], "handlers must run in subscription order");
}

// 2. emit resolves only after every handler finished.
{
  const bus = new HookBus();
  let done = false;
  bus.on("e", async () => { await new Promise(r => setTimeout(r, 20)); done = true; });
  await bus.emit("e", null);
  assert.equal(done, true, "emit must await all handlers");
}

// 3. A failing hook rejects emit with the same error; later handlers do not run.
{
  const bus = new HookBus();
  const ran = [];
  bus.on("e", () => { ran.push("a"); });
  bus.on("e", () => { throw new Error("boom"); });
  bus.on("e", () => { ran.push("c"); });
  await assert.rejects(bus.emit("e", null), { message: "boom" }, "emit must reject with the handler error");
  assert.deepEqual(ran, ["a"], "handlers after the failing one must not run");
}

// 4. Self-unsubscribe during emit does not stop the others in that emit.
{
  const bus = new HookBus();
  const ran = [];
  const off = bus.on("e", () => { ran.push("a"); off(); });
  bus.on("e", () => { ran.push("b"); });
  await bus.emit("e", null);
  assert.deepEqual(ran, ["a", "b"], "self-unsubscribe must not stop the current emit");
  await bus.emit("e", null);
  assert.deepEqual(ran, ["a", "b", "b"], "unsubscribed handler must not run on the next emit");
}

console.log("all 4 symptom checks passed");