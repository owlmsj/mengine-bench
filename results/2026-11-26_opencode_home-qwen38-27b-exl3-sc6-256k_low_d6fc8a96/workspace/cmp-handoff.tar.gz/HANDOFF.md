# HANDOFF — local-9b Q5 @ 128k VRAM spill

## Done (measured)
- Baseline: decode 37.8 t/s, VRAM 7881 MiB = WDDM ceiling; 1494 MiB spilled (Shared Usage).
- Fix: `--no-mmproj-offload` + `-ub 512` → spill gone, 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k; discarded. Q4_K_M fits (7305 MiB, 40.4 t/s) — fallback only.
- Recipe applied in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

## Open
1. Evals README still cites check_vision.ps1 — file no longer exists; update it.
2. Review scratchpad temp-file names (noted repeatedly, never done).

## Assumptions
- Applied files exist in the real repo; this workspace has only the transcript.
- 128k = 131072 ctx, measured via scripts/measure_decode.ps1 -NPredict 1024.

## How I know it's right
Numbers quoted verbatim from session/transcript.md (steps 10, 42, 45, 63); the 38.0 t/s / 7697 MiB line is the median-of-3 after the flag change.