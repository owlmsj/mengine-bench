import csv, re, json
from collections import defaultdict

base = r"<WORKSPACE>"

invoices = {}
with open(base + r"\backoffice\invoices.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = float(row["amount"])

payments = defaultdict(list)  # invoice id -> list of paid amounts
with open(base + r"\backoffice\bank_statement_june.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        m = re.search(r"(\d{4})", memo)
        if not m:
            continue
        inv = "INV-" + m.group(1)
        if inv not in invoices:
            continue
        payments[inv].append(float(row["amount"]))

unpaid, duplicated, mismatched = [], [], []
for inv, amt in invoices.items():
    pays = payments.get(inv, [])
    if not pays:
        unpaid.append(inv)
    elif len(pays) > 1:
        duplicated.append(inv)
    elif pays[0] != amt:
        mismatched.append({"id": inv, "invoiced": amt, "paid": pays[0]})

unpaid.sort(); duplicated.sort()
mismatched.sort(key=lambda x: x["id"])

result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
with open(base + r"\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))