import re, datetime

pattern = open('regex.txt').read().strip()
log = open('server.log').read()
got = re.findall(pattern, log, re.MULTILINE)
print("sample:", got)

cases = [
    # (line, expected dates)
    ("2026-04-02 07:15:09 INFO  gateway accepted 10.12.0.7 for build 2026-04-01", ["2026-04-01"]),
    ("2026-04-02 07:15:11 INFO  cache warm, 412 keys, next sweep 2026-04-03", []),
    ("2026-04-02 07:16:40 WARN  peer 192.168.40.3 slow, retry window 2026-04-02 to 2026-04-05", ["2026-04-05"]),
    ("2026-04-02 07:18:02 INFO  job 7781-20-4410 queued by scheduler", []),
    ("2026-04-02 07:19:30 ERROR upstream 172.20.1.14 refused handshake", ["2026-04-02"]),
    # IP validity
    ("x 256.1.1.1 2026-01-01", []),
    ("x 1.2.3.256 2026-01-01", []),
    ("x 01.2.3.4 2026-01-01", []),
    ("x 1.02.3.4 2026-01-01", []),
    ("x 1.2.3.04 2026-01-01", []),
    ("x 255.255.255.255 2026-01-01", ["2026-01-01"]),
    ("x 0.0.0.0 2026-01-01", ["2026-01-01"]),
    ("x 256.1.1.1", []),
    ("x 1.2.3 2026-01-01", []),
    ("x 1.2.3.4.5 2026-01-01", []),
    ("x 1.2.3.4a 2026-01-01", []),
    ("x a1.2.3.4 2026-01-01", []),
    ("x 1.2.3.4- 2026-01-01", ["2026-01-01"]),
    ("x -1.2.3.4 2026-01-01", ["2026-01-01"]),
    ("x 1.2.3.4.5 2026-01-01", []),
    ("x 10.0.0.1 2026-01-01-2", []),
    ("x 10.0.0.1 2026-01-01.", ["2026-01-01"]),
    ("x 1.2.3.4- 2026-01-01", ["2026-01-01"]),
    # date validity
    ("x 10.0.0.1 2026-02-28", ["2026-02-28"]),
    ("x 10.0.0.1 2026-02-29", ["2026-02-29"]),
    ("x 10.0.0.1 2026-02-30", []),
    ("x 10.0.0.1 2026-04-31", []),
    ("x 10.0.0.1 2026-13-01", []),
    ("x 10.0.0.1 2026-00-10", []),
    ("x 10.0.0.1 2026-01-00", []),
    ("x 10.0.0.1 2026-01-32", []),
    ("x 10.0.0.1 2026-1-1", []),
    ("x 10.0.0.1 26-01-01", []),
    ("x 10.0.0.1 1999-12-31", ["1999-12-31"]),
    # adjacency
    ("x 10.0.0.1 2026-01-01a", []),
    ("x 10.0.0.1 a2026-01-01", []),
    ("x 10.0.0.1 12026-01-01", []),
    ("x 10.0.0.1 2026-01-012", []),
    ("x 10.0.0.1 2026-01-01-2", []),
    ("x 10.0.0.1 2026-01-01.", ["2026-01-01"]),
    ("x 10.0.0.1 2026-01-01-2", []),
    ("x 10.0.0.1 2026-01-01 2026-01-02", ["2026-01-02"]),
    # last date on line
    ("2026-01-01 10.0.0.1 2026-01-02 2026-01-03", ["2026-01-03"]),
    # no IP anywhere
    ("2026-01-01 just a date 2026-01-02", []),
    # IP on line, date earlier in line
    ("2026-05-05 10.0.0.1 started 2026-05-04", ["2026-05-04"]),
]

ok = True
for line, exp in cases:
    got = re.findall(pattern, line + "\n", re.MULTILINE)
    if got != exp:
        ok = False
        print(f"FAIL: {line!r} -> {got}, expected {exp}")
print("ALL OK" if ok else "FAILURES")

# brute-force cross-check: for random lines, compare against a reference implementation
import random
random.seed(1)
def ref_ip_ok(s):
    parts = s.split('.')
    if len(parts) != 4: return False
    for p in parts:
        if not p.isdigit(): return False
        if len(p) > 1 and p[0] == '0': return False
        if int(p) > 255: return False
    return True
def ref_date_ok(s):
    m = re.fullmatch(r'(\d{4})-(\d{2})-(\d{2})', s)
    if not m: return False
    y, mo, d = map(int, m.groups())
    if mo == 2:
        return 1 <= d <= 29
    if mo in (1, 3, 5, 7, 8, 10, 12):
        return 1 <= d <= 31
    if mo in (4, 6, 9, 11):
        return 1 <= d <= 30
    return False
def ref(line):
    # find IP tokens with word boundaries, no alnum adjacency
    has_ip = False
    for m in re.finditer(r'(?<![0-9a-zA-Z])(\d{1,3}(?:\.\d{1,3}){3})(?![0-9a-zA-Z])', line):
        if ref_ip_ok(m.group(1)):
            has_ip = True
            break
    if not has_ip:
        return []
    dates = []
    for m in re.finditer(r'(?<![0-9a-zA-Z])(\d{4}-\d{2}-\d{2})(?![0-9a-zA-Z])', line):
        if ref_date_ok(m.group(1)):
            dates.append(m.group(1))
    return [dates[-1]] if dates else []

bad = 0
for _ in range(20000):
    n = random.randint(1, 6)
    toks = []
    for _ in range(n):
        r = random.random()
        if r < 0.4:
            toks.append(f"{random.randint(0,300)}.{random.randint(0,300)}.{random.randint(0,300)}.{random.randint(0,300)}")
        elif r < 0.8:
            y = random.choice([1999, 2000, 2020, 2026])
            mo = random.randint(0, 13)
            d = random.randint(0, 31)
            toks.append(f"{y:04d}-{mo:02d}-{d:02d}")
        else:
            toks.append(random.choice(["INFO", "x", "7781-20-4410", "a", "01.2.3.4", "2026-1-1", "2026-02-30x", "92026-01-01"]))
    line = " ".join(toks)
    exp = ref(line)
    got = re.findall(pattern, line + "\n", re.MULTILINE)
    if got != exp:
        bad += 1
        if bad <= 10:
            print(f"MISMATCH: {line!r} got={got} exp={exp}")
print("fuzz bad:", bad)