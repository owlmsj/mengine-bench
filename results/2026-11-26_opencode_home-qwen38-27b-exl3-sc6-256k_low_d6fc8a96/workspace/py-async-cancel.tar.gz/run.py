"""Batch task runner.

Usage:
    from run import run_tasks
    await run_tasks(tasks, max_concurrent)

Each task is a zero-argument callable returning an awaitable job.
At most max_concurrent jobs run at once. Returns when every job is done.
On Ctrl+C (KeyboardInterrupt) the in-flight jobs are allowed to finish
their cleanup (finally blocks) before the interrupt propagates.
"""

import asyncio


async def run_tasks(tasks, max_concurrent):
    sem = asyncio.Semaphore(max_concurrent)

    async def wrap(task):
        async with sem:
            return await task()

    return await asyncio.gather(*(wrap(t) for t in tasks))