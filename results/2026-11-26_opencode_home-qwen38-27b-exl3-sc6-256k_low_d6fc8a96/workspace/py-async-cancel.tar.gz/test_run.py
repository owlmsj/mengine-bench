import asyncio
import time
from run import run_tasks


async def test_concurrency_limit():
    running = 0
    max_seen = 0
    results = []

    def make(i):
        async def job():
            nonlocal running, max_seen
            running += 1
            max_seen = max(max_seen, running)
            await asyncio.sleep(0.05)
            running -= 1
            return i
        return job

    out = await run_tasks([make(i) for i in range(10)], 3)
    assert out == list(range(10)), out
    assert max_seen <= 3, max_seen
    assert max_seen == 3, max_seen  # actually hits the limit
    print("concurrency limit OK, max_seen =", max_seen)


async def test_cleanup_on_interrupt():
    cleaned = []

    def make(i):
        async def job():
            try:
                await asyncio.sleep(10)
            finally:
                cleaned.append(i)
        return job

    runner = asyncio.create_task(run_tasks([make(i) for i in range(4)], 2))
    await asyncio.sleep(0.1)
    # Simulate Ctrl+C: cancel the runner, which cancels in-flight jobs.
    # Their finally blocks (cleanup) must still run.
    runner.cancel()
    try:
        await runner
    except (asyncio.CancelledError, KeyboardInterrupt):
        pass
    assert len(cleaned) == 2, cleaned  # the 2 in-flight jobs cleaned up
    print("cleanup on interrupt OK, cleaned =", cleaned)


async def test_sequential_results_order():
    def make(i):
        async def job():
            await asyncio.sleep(0.01 * (5 - i))
            return i
        return job

    out = await run_tasks([make(i) for i in range(5)], 2)
    assert out == list(range(5)), out
    print("result order OK")


async def main():
    await test_concurrency_limit()
    await test_cleanup_on_interrupt()
    await test_sequential_results_order()
    print("ALL TESTS PASSED")


asyncio.run(main())