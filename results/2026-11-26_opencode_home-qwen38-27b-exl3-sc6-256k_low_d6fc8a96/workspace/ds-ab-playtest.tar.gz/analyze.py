import csv, json, math

path = r"<WORKSPACE>\telemetry\playtest_ab.csv"

sessions = {}
dup_rows = 0
with open(path, newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        sid = row["session_id"].strip()
        variant = row["variant"].strip().lower()
        completed = int(row["completed_tutorial"])
        if sid in sessions:
            dup_rows += 1
            # verify resend consistency
            prev = sessions[sid]
            if prev != (variant, completed):
                print(f"INCONSISTENT DUP: {sid} {prev} vs {(variant, completed)}")
        else:
            sessions[sid] = (variant, completed)

a_n = a_c = b_n = b_c = 0
for sid, (variant, completed) in sessions.items():
    if variant == "a":
        a_n += 1
        a_c += completed
    elif variant == "b":
        b_n += 1
        b_c += completed
    else:
        print(f"UNEXPECTED VARIANT: {variant!r} {sid}")

p_a = a_c / a_n
p_b = b_c / b_n
p_pool = (a_c + b_c) / (a_n + b_n)
se = math.sqrt(p_pool * (1 - p_pool) * (1 / a_n + 1 / b_n))
z = (p_b - p_a) / se
# two-sided p-value via normal CDF
p_value = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))

print(f"total rows deduped: {len(sessions)} unique sessions, {dup_rows} duplicate rows dropped")
print(f"A: n={a_n} completed={a_c} rate={p_a:.6f}")
print(f"B: n={b_n} completed={b_c} rate={p_b:.6f}")
print(f"diff={p_b - p_a:+.6f} z={z:.4f} p={p_value:.6g}")

result = {
    "ship_b": bool(p_value < 0.05 and p_b > p_a),
    "sessions_a": a_n,
    "sessions_b": b_n,
    "completion_rate_a": round(p_a, 6),
    "completion_rate_b": round(p_b, 6),
    "p_value": round(p_value, 6),
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))