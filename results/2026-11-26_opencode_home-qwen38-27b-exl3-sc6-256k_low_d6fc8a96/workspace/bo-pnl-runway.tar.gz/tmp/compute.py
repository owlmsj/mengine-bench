import csv, json
from collections import defaultdict

base = r"<WORKSPACE>\finance"

coa = {}
with open(base + r"\chart_of_accounts.csv", encoding="utf-8") as f:
    r = csv.reader(f, delimiter=";")
    next(r)
    for row in r:
        coa[row[0]] = row[2]

months = ["2026-01","2026-02","2026-03","2026-04","2026-05","2026-06"]
lines = defaultdict(lambda: defaultdict(float))
with open(base + r"\ledger.csv", encoding="utf-8") as f:
    r = csv.reader(f, delimiter=";")
    next(r)
    for date, acct, desc, amt in r:
        d, m, y = date.split("/")
        key = f"{y}-{m}"
        amt = float(amt.replace(".", "").replace(",", "."))
        lines[key][coa[acct]] += amt

out = {"revenue": {}, "gross_margin_pct": {}, "ebitda": {}, "burn": None, "runway_months": None}
eb = {}
for k in months:
    rev = lines[k].get("revenue", 0.0)
    cogs = lines[k].get("cogs", 0.0)
    ebitda = sum(v for line, v in lines[k].items() if line != "financial")
    gm = (rev + cogs) / rev * 100 if rev else None
    out["revenue"][k] = round(rev, 2)
    out["gross_margin_pct"][k] = round(gm, 2)
    out["ebitda"][k] = round(ebitda, 2)
    eb[k] = ebitda

# burn: average monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = [eb[k] for k in ["2026-04","2026-05","2026-06"]]
burn = -sum(last3)/3
out["burn"] = round(burn, 2)
cash = 1847350.40
out["runway_months"] = round(cash / burn, 2)

print(json.dumps(out, indent=2))
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2)