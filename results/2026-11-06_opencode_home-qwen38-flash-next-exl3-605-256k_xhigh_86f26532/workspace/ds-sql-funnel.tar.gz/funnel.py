import sqlite3, json
from collections import defaultdict

STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']
con = sqlite3.connect('analytics.db')

valid_users = {u: p for u, p in con.execute(
    "SELECT user_id, platform FROM users WHERE is_test = 0")}

events = defaultdict(lambda: defaultdict(list))  # user -> step -> [ts]
for uid, name, ts in con.execute("SELECT user_id, name, ts FROM events"):
    if uid in valid_users and name in STEPS:
        events[uid][name].append(ts)

counts = {p: dict.fromkeys(STEPS, 0) for p in valid_users.values()}
for uid, platform in valid_users.items():
    prev = None
    for step in STEPS:
        times = sorted(events.get(uid, {}).get(step, []))
        hit = next((t for t in times if prev is None or t >= prev), None)
        if hit is None:
            break
        counts[platform][step] += 1
        prev = hit

funnel = {p: counts[p] for p in sorted(counts)}
biggest = {}
for p, c in sorted(counts.items()):
    rates = []
    for i in range(1, len(STEPS)):
        prev_n = c[STEPS[i-1]]
        rates.append((c[STEPS[i]] / prev_n if prev_n else 0.0, STEPS[i]))
    worst_rate, worst_step = min(rates, key=lambda x: (x[0], STEPS.index(x[1])))
    biggest[p] = {'step': worst_step,
                  'conversion': round(worst_rate, 4),
                  'dropped_players': counts[p][STEPS[STEPS.index(worst_step)-1]] - counts[p][worst_step]}

result = {'funnel': funnel, 'biggest_drop': biggest}
with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
print('total users:', len(valid_users), 'test rows:',
      con.execute('SELECT COUNT(*) FROM users WHERE is_test=1').fetchone()[0],
      'unknown-player events:',
      con.execute("SELECT COUNT(*) FROM events WHERE user_id NOT IN (SELECT user_id FROM users)").fetchone()[0])