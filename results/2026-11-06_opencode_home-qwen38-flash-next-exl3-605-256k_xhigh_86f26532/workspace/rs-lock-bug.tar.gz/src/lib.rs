//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    /// The read-modify-write of both counters happens in one critical section
    /// per counter, so concurrent awards never overwrite each other.
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        *slot.lock().unwrap() += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    /// Slots are always locked in ascending player order, so two threads
    /// transferring in opposite directions cannot deadlock.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let from_slot = self.slot(from);
        let to_slot = self.slot(to);
        // Same slot: locking it twice would deadlock a std Mutex.
        if Arc::ptr_eq(&from_slot, &to_slot) {
            return;
        }
        if from < to {
            let mut from_score = from_slot.lock().unwrap();
            let mut to_score = to_slot.lock().unwrap();
            *from_score -= points;
            *to_score += points;
        } else {
            let mut to_score = to_slot.lock().unwrap();
            let mut from_score = from_slot.lock().unwrap();
            *from_score -= points;
            *to_score += points;
        }
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}

#[cfg(test)]
mod concurrency {
    use super::*;
    use std::thread;

    #[test]
    fn self_transfer_does_not_deadlock() {
        let board = Board::new();
        board.join(7, 100);
        board.transfer(7, 7, 40);
        assert_eq!((board.score(7), board.total()), (100, 100));
    }

    #[test]
    fn opposite_transfers_do_not_deadlock() {
        let board = Board::new();
        board.join(1, 1000);
        board.join(2, 1000);
        let handles: Vec<_> = (0..8)
            .map(|n| {
                let board = board.clone();
                thread::spawn(move || {
                    for _ in 0..2000 {
                        if n % 2 == 0 {
                            board.transfer(1, 2, 1);
                        } else {
                            board.transfer(2, 1, 1);
                        }
                    }
                })
            })
            .collect();
        for h in handles {
            h.join().unwrap();
        }
        assert_eq!(board.total(), 2000);
        assert_eq!(board.score(1) + board.score(2), 2000);
    }

    #[test]
    fn concurrent_awards_lose_no_points() {
        let board = Board::new();
        board.join(1, 0);
        let handles: Vec<_> = (0..8)
            .map(|_| {
                let board = board.clone();
                thread::spawn(move || {
                    for _ in 0..5000 {
                        board.award(1, 1);
                    }
                })
            })
            .collect();
        for h in handles {
            h.join().unwrap();
        }
        assert_eq!(board.score(1), 40000);
        assert_eq!(board.total(), 40000);
    }
}
