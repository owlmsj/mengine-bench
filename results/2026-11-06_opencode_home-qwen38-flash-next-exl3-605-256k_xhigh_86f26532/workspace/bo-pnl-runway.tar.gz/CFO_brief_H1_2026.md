# CFO Briefing: H1 2026 Close (Investor Meeting)

Currency: BRL (R$). Source: finance/ledger.csv (84 entries, DD/MM/YYYY), classified per finance/chart_of_accounts.csv. Cash per finance/cash_balance.txt.

## Monthly P&L (H1 2026)

| Month | Revenue | COGS | Gross margin | Opex (S&M+R&D+G&A) | EBITDA |
|---|---:|---:|---:|---:|---:|
| Jan | 200,510.87 | 60,091.92 | 70.0% | 350,697.91 | (210,278.96) |
| Feb | 216,328.06 | 64,278.71 | 70.3% | 364,349.43 | (212,300.08) |
| Mar | 219,066.17 | 69,096.05 | 68.5% | 354,495.57 | (204,525.45) |
| Apr | 238,163.26 | 70,867.73 | 70.2% | 364,246.18 | (196,950.65) |
| May | 243,032.89 | 73,973.13 | 69.6% | 371,005.58 | (201,945.82) |
| Jun | 272,391.57 | 75,162.69 | 72.4% | 390,197.10 | (192,968.22) |
| **H1** | **1,389,492.82** | **413,470.23** | **70.2%** | **2,194,991.77** | **(1,218,969.18)** |

Revenue = SaaS subscriptions (3.1.01) + onboarding (3.1.02) net of refunds/cancellations (3.1.09). EBITDA excludes financial items (6.1.x: net investment income ~6–7k/month, positive).

## Narrative: how each month went
- Revenue grew every month: +35.8% Jan to Jun (200.5k to 272.4k); SaaS subscriptions are the driver, refunds are small (two Kestrel refunds, Jun 28: -8,634.37; Mar 28: -6,814.15).
- Gross margin held ~68–72%, ending at the H1 high of 72.4% in June; cloud/GPU cost grows slower than revenue.
- EBITDA loss is flat-to-improving: worst in Feb (-212.3k), best in Jun (-193.0k). Opex grows (+11.3% Jan to Jun, mostly sales team and engineering) but slower than revenue, so losses narrow.
- H1 EBITDA -1,218,969.18; monthly loss narrowed ~8% from Jan to Jun.

## Burn and runway (board definition, finance/README.md)
- Burn = average monthly negative EBITDA of last three closed months (Apr–Jun) = **R$ 197,288.23/month**.
- Latest closing cash (30/06/2026) = R$ 1,847,350.40.
- Runway = 1,847,350.40 / 197,288.23 = **9.4 months** (cash-out ~early April 2027).

## Assumptions
- Ledger dates are DD/MM/YYYY (matches cash_balance.txt format; day values exceed 12).
- Amounts use pt-BR format (dot = thousands, comma = decimal).
- EBITDA = revenue - COGS - S&M - R&D - G&A; financial income/expense excluded; no D&A or capex accounts exist in the chart, so EBITDA = operating result.
- Refunds (3.1.09) netted against revenue per chart_of_accounts pnl_line.
- Cash movement May→Jun (-461,837.60) is larger than June P&L; assumed working capital/capex effects not in the ledger; runway uses the stated closing balance per board rule.

Key figures delivered in result.json.