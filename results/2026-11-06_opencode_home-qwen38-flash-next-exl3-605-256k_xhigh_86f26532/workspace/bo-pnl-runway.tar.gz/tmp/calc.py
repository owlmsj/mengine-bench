import csv, json
from collections import defaultdict

def num(s):
    return float(s.replace('.', '').replace(',', '.'))

coa = {}
with open('finance/chart_of_accounts.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        coa[row['account']] = row['pnl_line']

months = ['2026-0%d' % m for m in range(1, 7)]
agg = {m: defaultdict(float) for m in months}
with open('finance/ledger.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        mo = row['date'][6:10] + '-' + row['date'][3:5]
        line = coa[row['account']]
        amt = num(row['amount'])
        if line == 'revenue':
            agg[mo]['rev'] += amt
        elif line in ('cogs',):
            agg[mo]['cogs'] += -amt
        elif line in ('sales_marketing', 'rnd', 'ga'):
            agg[mo]['opex'] += -amt
        elif line == 'financial':
            agg[mo]['fin'] += amt
        else:
            raise ValueError(line)

out = {'revenue': {}, 'gross_margin_pct': {}, 'ebitda': {}}
rows = []
for m in months:
    a = agg[m]
    rev = a['rev']; cogs = a['cogs']; opex = a['opex']
    gm = (rev - cogs) / rev * 100
    ebitda = rev - cogs - opex
    out['revenue'][m] = round(rev, 2)
    out['gross_margin_pct'][m] = round(gm, 1)
    out['ebitda'][m] = round(ebitda, 2)
    rows.append((m, rev, cogs, opex, gm, ebitda, a['fin']))
    print('%s rev=%12.2f cogs=%10.2f opex=%10.2f gm=%5.1f%% ebitda=%12.2f fin=%9.2f' % rows[-1])

last3 = [out['ebitda'][m] for m in months[-3:]]
assert all(e < 0 for e in last3), last3
burn = -sum(last3) / 3
cash = 1847350.40
runway = cash / burn
out['burn'] = round(burn, 2)
out['runway_months'] = round(runway, 1)
print('burn(last3 neg ebitda avg)=%.2f cash=%.2f runway=%.2f' % (burn, cash, runway))
print('sum ebitda H1=%.2f  net cash delta Jun-May=%.2f' % (sum(out['ebitda'].values()), 1847350.40 - 2309188.00))
with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, indent=2)