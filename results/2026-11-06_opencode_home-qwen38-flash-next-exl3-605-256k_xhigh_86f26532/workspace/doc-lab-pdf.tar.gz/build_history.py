"""Build one marker history from the two lab PDFs, in the first report's units.

Sources: exams/laudo_alfa.pdf (coleta 10/02/2026, mg/dL / %) and
exams/resultado_beta.pdf (coleta 18/08/2026, SI units).
Conversion factors: standard clinical ones (glucose x18.0182, LDL x38.67,
creatinine /88.4, HbA1c NGSP% = 0.09148*IFCC + 2.152).
"""
import json

FIRST, SECOND = "2026-02-10", "2026-08-18"

# marker -> (first value, first unit, ref range in first units, high_is_worse)
DATA = {
    "Glicose em jejum": (92.0, "mg/dL", (70.0, 99.0),
                         6.1 * 18.0182),
    "Colesterol LDL": (118.0, "mg/dL", (None, 130.0),
                       3.70 * 38.67),
    "Creatinina": (0.95, "mg/dL", (0.70, 1.30),
                   76.0 / 88.4),
    "Hemoglobina glicada (HbA1c)": (5.4, "%", (4.0, 5.6),
                                    0.09148 * 37.0 + 2.152),
}

history, worse = {}, []
for marker, (first, unit, (lo, hi), second) in DATA.items():
    second = round(second, 2)
    history[marker] = {FIRST: first, SECOND: second}
    outside = (hi is not None and second > hi) or (lo is not None and second < lo)
    if second > first and outside:
        worse.append(marker)
    print(f"{marker:32} {first} -> {second} {unit}  ref {lo}-{hi}  "
          f"delta {round(second - first, 2):+}  outside={outside}")

out = {"history": history, "worse": worse,
       "units": {m: DATA[m][1] for m in DATA},
       "assumptions": {
           "first_report": "laudo_alfa.pdf (coleta 10/02/2026) defines units and reference ranges",
           "dates": "collection dates, ISO YYYY-MM-DD",
           "conversions": "glucose mmol/L x18.0182; LDL mmol/L x38.67; creatinine umol/L /88.4; HbA1c %% = 0.09148 x mmol/mol + 2.152 (IFCC->NGSP)",
           "worse_rule": "value moved in the unfavourable direction (all four markers: higher is worse) AND is outside the first report's reference range"}}
with open("result.json", "w", encoding="utf-8") as fh:
    json.dump(out, fh, ensure_ascii=False, indent=2)
print("worse:", worse)