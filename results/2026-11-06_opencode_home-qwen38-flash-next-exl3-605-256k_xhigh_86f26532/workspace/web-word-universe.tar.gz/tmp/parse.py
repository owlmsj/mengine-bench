import os, re, json, urllib.parse
from collections import defaultdict

SITE = "site"
skip = {"index.html", "sobre.html", "contato.html"}
files = [f for f in os.listdir(SITE) if f.endswith(".html") and f.lower() not in skip]

# canonical word per file = <h1>
word_of = {}
redirect = {}
for f in files:
    t = open(os.path.join(SITE, f), encoding="utf-8").read()
    m = re.search(r"<h1>([^<]+)</h1>", t)
    if m:
        word_of[f.lower()] = m.group(1).strip()
    else:  # meta-refresh stub
        r = re.search(r'url=([^">]+)"', t)
        redirect[f.lower()] = urllib.parse.unquote(r.group(1)).lower()
for k, v in redirect.items():
    word_of[k] = word_of[v]  # resolve to target word
files = [f for f in files if f.lower() not in redirect]

words = {}
links = defaultdict(set)   # word -> set(words) direct as published
for f in files:
    t = open(os.path.join(SITE, f), encoding="utf-8").read()
    src = word_of[f.lower()]
    main = re.search(r"<main>.*?</main>", t, re.S)
    body = main.group(0) if main else ""
    for sec in re.finditer(r'<section id="(sinonimos|analogas)">(.*?)</section>', body, re.S):
        for href in re.findall(r'href="([^"]+)"', sec.group(2)):
            key = urllib.parse.unquote(href).lower()
            if key in word_of:
                dst = word_of[key]
                if dst != src:
                    links[src].add(dst)

for w in word_of.values():
    links.setdefault(w, set())
words_json = {w: sorted(links[w]) for w in sorted(links, key=str.lower)}

pairs = set()
for a, bs in links.items():
    for b in bs:
        pairs.add(frozenset((a, b)))
deg = defaultdict(int)
for p in pairs:
    a, b = tuple(p)
    deg[a] += 1
    deg[b] += 1
top = max(deg.items(), key=lambda kv: (kv[1], kv[0].lower()))
ties = sorted([w for w, d in deg.items() if d == top[1]], key=str.lower)

json.dump(words_json, open("words.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
res = {"words": len(words_json), "relations": len(pairs), "most_connected": top[0]}
json.dump(res, open("result.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(res, "ties:", ties[:5])
print("max deg:", top[1], "min:", min(deg.values()), "avg:", round(2*len(pairs)/len(deg),2))
print("sample:", list(words_json.items())[:2])