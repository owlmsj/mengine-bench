import os, re, json, urllib.parse, random, math
from collections import defaultdict

SITE = "site"
skip = {"index.html", "sobre.html", "contato.html"}
files = [f for f in os.listdir(SITE) if f.endswith(".html") and f.lower() not in skip]

word_of, redirect, tema = {}, {}, {}
for f in files:
    t = open(os.path.join(SITE, f), encoding="utf-8").read()
    m = re.search(r"<h1>([^<]+)</h1>", t)
    if m:
        w = m.group(1).strip()
        word_of[f.lower()] = w
        tm = re.search(r'class="tema">Tema: ([^<]+)</p>', t)
        tema[w] = tm.group(1).strip() if tm else "outro"
    else:
        r = re.search(r'url=([^">]+)"', t)
        redirect[f.lower()] = urllib.parse.unquote(r.group(1)).lower()
for k, v in redirect.items():
    word_of[k] = word_of[v]
files = [f for f in files if f.lower() not in redirect]

links = defaultdict(set)
for f in files:
    t = open(os.path.join(SITE, f), encoding="utf-8").read()
    src = word_of[f.lower()]
    main = re.search(r"<main>.*?</main>", t, re.S)
    for sec in re.finditer(r'<section id="(sinonimos|analogas)">(.*?)</section>', main.group(0), re.S):
        for href in re.findall(r'href="([^"]+)"', sec.group(2)):
            key = urllib.parse.unquote(href).lower()
            if key in word_of and word_of[key] != src:
                links[src].add(word_of[key])
for w in word_of.values():
    links.setdefault(w, set())

words_json = {w: sorted(links[w], key=str.lower) for w in sorted(links, key=str.lower)}
json.dump(words_json, open("words.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

pairs = set()
for a, bs in links.items():
    for b in bs:
        pairs.add(frozenset((a, b)))
deg = defaultdict(int)
edges = []
for p in pairs:
    a, b = sorted(p, key=str.lower)
    edges.append((a, b))
    deg[a] += 1
    deg[b] += 1
edges.sort()
topdeg = max(deg.values())
most = sorted(w for w, d in deg.items() if d == topdeg)[0]
res = {"words": len(words_json), "relations": len(pairs), "most_connected": most}
json.dump(res, open("result.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(res, "topdeg", topdeg, "ties", sorted(w for w, d in deg.items() if d == topdeg))

# 3D Fruchterman-Reingold layout
names = sorted(links, key=str.lower)
idx = {w: i for i, w in enumerate(names)}
n = len(names)
random.seed(7)
pos = [[random.uniform(-50, 50) for _ in range(3)] for _ in range(n)]
ea = [(idx[a], idx[b]) for a, b in edges]
k = 12.0
T = 30.0
for it in range(220):
    disp = [[0.0, 0.0, 0.0] for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            d = [pos[i][c] - pos[j][c] for c in range(3)]
            dist = max(math.sqrt(sum(x * x for x in d)), 0.1)
            f = k * k / dist
            for c in range(3):
                disp[i][c] += d[c] / dist * f
                disp[j][c] -= d[c] / dist * f
    for a, b in ea:
        d = [pos[a][c] - pos[b][c] for c in range(3)]
        dist = max(math.sqrt(sum(x * x for x in d)), 0.1)
        f = dist * dist / k
        for c in range(3):
            disp[a][c] -= d[c] / dist * f
            disp[b][c] += d[c] / dist * f
    for i in range(n):
        dl = max(math.sqrt(sum(x * x for x in disp[i])), 0.01)
        s = min(dl, T) / dl
        for c in range(3):
            pos[i][c] += disp[i][c] * s
    T *= 0.985
cx = [sum(p[c] for p in pos) / n for c in range(3)]
pos = [[round(p[c] - cx[c], 1) for c in range(3)] for p in pos]
data = {"words": words_json, "tema": {w: tema.get(w, "outro") for w in names},
        "pos": {w: pos[idx[w]] for w in names}, "deg": {w: deg[w] for w in names}}
open("tmp/data.json", "w", encoding="utf-8").write(json.dumps(data, ensure_ascii=False, separators=(",", ":")))
print("data bytes:", os.path.getsize("tmp/data.json"))