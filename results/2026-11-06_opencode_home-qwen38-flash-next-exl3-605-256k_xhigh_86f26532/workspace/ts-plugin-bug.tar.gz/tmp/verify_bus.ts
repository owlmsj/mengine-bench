import assert from "node:assert/strict";
import { HookBus } from "../src/bus.ts";
import { registerAuditPlugin } from "../src/plugin.ts";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
process.on("unhandledRejection", (err) => {
  console.error("UNHANDLED REJECTION", err);
  process.exitCode = 1;
});
const checks: string[] = [];
const ok = (name: string) => checks.push(name);

// 1. sequential, subscription order, slow handler first
{
  const bus = new HookBus();
  const log: string[] = [];
  bus.on("e", async () => { await sleep(20); log.push("a"); });
  bus.on("e", () => { log.push("b"); });
  bus.on("e", async () => { await sleep(5); log.push("c"); });
  await bus.emit("e", 1);
  assert.deepEqual(log, ["a", "b", "c"]);
  ok("sequential in subscription order");
}

// 2. emit resolves only after the last handler finishes
{
  const bus = new HookBus();
  let done = false;
  bus.on("e", async () => { await sleep(25); done = true; });
  await bus.emit("e", undefined);
  assert.equal(done, true);
  ok("emit waits for every handler");
}

// 3. throwing handler rejects emit with the same error, later handlers skipped
{
  const bus = new HookBus();
  const boom = new Error("boom");
  const log: string[] = [];
  bus.on("e", () => { log.push("first"); });
  bus.on("e", () => { throw boom; });
  bus.on("e", async () => { log.push("never"); });
  await assert.rejects(() => bus.emit("e", undefined), (err) => err === boom);
  assert.deepEqual(log, ["first"]);
  ok("sync throw rejects emit, rest skipped");
}

// 4. rejecting handler: same error object, no unhandled rejection
{
  const bus = new HookBus();
  const boom = new Error("nope");
  let ran = false;
  bus.on("e", async () => { throw boom; });
  bus.on("e", () => { ran = true; });
  await assert.rejects(() => bus.emit("e", undefined), (err) => err === boom);
  assert.equal(ran, false);
  ok("rejection rejects emit with same error");
}

// 5. unsubscribe during emit does not stop the others; counts from next emit
{
  const bus = new HookBus();
  const log: string[] = [];
  let offB = () => {};
  bus.on("e", () => { log.push("a"); });
  offB = bus.on("e", () => { offB(); log.push("b"); });
  bus.on("e", () => { log.push("c"); });
  await bus.emit("e", undefined);
  assert.deepEqual(log, ["a", "b", "c"]);
  assert.equal(bus.count("e"), 2);
  log.length = 0;
  await bus.emit("e", undefined);
  assert.deepEqual(log, ["a", "c"]);
  ok("unsubscribe during emit applies next emit");
}

// 6. subscribe during emit does not join that emit
{
  const bus = new HookBus();
  const log: string[] = [];
  bus.on("e", () => { bus.on("e", () => log.push("late")); });
  bus.on("e", () => log.push("b"));
  await bus.emit("e", undefined);
  assert.deepEqual(log, ["b"]);
  log.length = 0;
  await bus.emit("e", undefined);
  assert.deepEqual(log, ["b", "late"]);
  ok("subscribe during emit applies next emit");
}

// 7. same function subscribed twice, one unsubscribe removes one registration
{
  const bus = new HookBus();
  let calls = 0;
  const h = () => { calls++; };
  const off1 = bus.on("e", h);
  bus.on("e", h);
  off1();
  assert.equal(bus.count("e"), 1);
  await bus.emit("e", undefined);
  assert.equal(calls, 1);
  off1();
  assert.equal(bus.count("e"), 1);
  ok("duplicate handler: unsubscribe is exact and idempotent");
}

// 8. events are isolated, unknown event is a no-op
{
  const bus = new HookBus();
  let hits = 0;
  bus.on("a", () => { hits++; });
  await bus.emit("b", undefined);
  assert.equal(hits, 0);
  ok("unknown event no-op");
}

// 9. plugin contract: notice once, redaction before the audit line
{
  const bus = new HookBus();
  const audit: string[] = [];
  registerAuditPlugin(bus, audit);
  await bus.emit("tool.after", { tool: "read", output: "secret password=hunter2 end" });
  await bus.emit("tool.after", { tool: "write", output: "clean" });
  assert.deepEqual(audit, [
    "notice: tool output is audited",
    "read: secret password=[redacted] end",
    "write: clean",
  ]);
  ok("plugin: notice once, redacted before audit");
}

await sleep(50);
console.log(checks.map((c) => "PASS " + c).join("\n"));
console.log(checks.length + " checks passed");