/**
 * Hook bus for harness plugins (OpenCode-style hooks). The README states the contract:
 * handlers run one after another in subscription order, emit resolves after all of them,
 * a handler error rejects emit, and unsubscribing during an emit does not stop the others.
 */

export type Handler<T> = (payload: T) => void | Promise<void>;

/**
 * A subscription wrapper. It gives every `on()` call its own identity, so an
 * unsubscribe removes exactly its own registration even when the same handler
 * function was subscribed more than once.
 */
type Registration = { handler: Handler<unknown> };

export class HookBus {
  private handlers: Map<string, Registration[]> = new Map();

  /** Subscribes a handler to an event; returns the function that unsubscribes it. */
  on<T>(event: string, handler: Handler<T>): () => void {
    const registration: Registration = { handler: handler as Handler<unknown> };
    const list = this.handlers.get(event) ?? [];
    list.push(registration);
    this.handlers.set(event, list);
    return () => {
      const live = this.handlers.get(event);
      if (!live) return;
      const index = live.indexOf(registration);
      if (index < 0) return;
      live.splice(index, 1);
    };
  }

  /**
   * Runs the handlers that were subscribed when emit started, one after another in
   * subscription order: each one settles before the next starts. A throw or rejection
   * rejects emit with that same error and skips the handlers after it. The snapshot
   * keeps subscribe/unsubscribe during an emit from changing that emit; it counts
   * from the next emit on.
   */
  async emit<T>(event: string, payload: T): Promise<void> {
    const started = [...(this.handlers.get(event) ?? [])];
    for (const { handler } of started) {
      await handler(payload);
    }
  }

  /** How many handlers an event has. */
  count(event: string): number {
    return (this.handlers.get(event) ?? []).length;
  }
}