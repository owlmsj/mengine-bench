# HANDOFF: local-9b Q5 at 128k

Goal was to measure local-9b Q5 at 128k context. Done; fix applied; one doc task left.

Measured (scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024):
- First Q5 run: 37.8 t/s, 7881 MiB. Invalid: 7881 MiB is the WDDM ceiling; Shared Usage showed 1494 MiB spilled to RAM.
- Fix: --no-mmproj-offload plus -ub 512 removes the spill. Final: 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k; dropped. Q4_K_M fits: 7305 MiB, 40.4 t/s; kept as fallback only.

Applied: recipe written into scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

Still open:
1. evals README still cites check_vision.ps1, a deleted file; update it.
2. Minor: scratchpad temp-file names were noted for review, never done.

Assumptions: this folder holds only the transcript; the repo files above live elsewhere. Numbers are from the session log, not re-measured here.