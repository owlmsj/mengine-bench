"""Settings for the backup agent."""

import os

API_URL = "https://backup.example.invalid/v1/upload"
ARCHIVE_DIR = "archives"


def api_token() -> str:
    """Reads the API token from the environment; it is never stored in code."""
    token = os.environ.get("BACKUP_TOKEN", "")
    if not token:
        raise RuntimeError("BACKUP_TOKEN environment variable is not set")
    return token