"""Checks for run_tasks: concurrency cap, order, cleanup on cancel, errors."""

import asyncio

from run import run_tasks

live = 0
peak = 0


def job(i, dur=0.02, log=None):
    async def run():
        global live, peak
        live += 1
        peak = max(peak, live)
        try:
            await asyncio.sleep(dur)
        finally:
            live -= 1
            if log is not None:
                log.append(i)
        return i

    return run


async def t_cap_and_order():
    global peak
    peak = 0
    log = []
    res = await run_tasks([job(i, log=log) for i in range(10)], 3)
    assert res == list(range(10)), res
    assert peak == 3, peak
    assert sorted(log) == list(range(10)), log
    print("cap_and_order ok peak=", peak)


async def t_cleanup_on_cancel():
    global peak
    peak = 0
    log = []
    started = asyncio.Event()

    def slow(i):
        async def run():
            nonlocal started
            started.set()
            try:
                await asyncio.sleep(5)
            finally:
                await asyncio.sleep(0.01)  # async cleanup
                log.append(i)

        return run

    runner = asyncio.ensure_future(run_tasks([job(0, log=log), slow(1)], 2))
    await started.wait()
    runner.cancel()
    try:
        await runner
        raise AssertionError("expected CancelledError")
    except asyncio.CancelledError:
        pass
    assert sorted(log) == [0, 1], log
    assert live == 0, live
    print("cleanup_on_cancel ok log=", log)


async def t_second_ctrlc_keeps_cleanup():
    log = []
    started = []

    def slow(i):
        async def run():
            started.append(i)
            try:
                await asyncio.sleep(5)
            finally:
                await asyncio.sleep(0.05)
                log.append(i)

        return run

    # 3 jobs, cap 2: job 2 never starts, so it has no cleanup to run.
    runner = asyncio.ensure_future(run_tasks([slow(i) for i in range(3)], 2))
    await asyncio.sleep(0.02)
    runner.cancel()
    for _ in range(5):  # repeat Ctrl+C while cleanup is in flight
        await asyncio.sleep(0.01)
        runner.cancel()
    try:
        await runner
        raise AssertionError("expected CancelledError")
    except asyncio.CancelledError:
        pass
    assert sorted(started) == [0, 1], started
    assert sorted(log) == [0, 1], log
    print("second_ctrlc ok log=", log)


async def t_error_waits_for_siblings():
    log = []

    def boom():
        async def run():
            raise RuntimeError("boom")

        return run

    try:
        await run_tasks([boom(), job(1, dur=0.05, log=log)], 2)
        raise AssertionError("expected RuntimeError")
    except RuntimeError as exc:
        assert str(exc) == "boom", exc
    assert log == [1], log
    print("error_waits ok log=", log)


async def t_edge():
    assert await run_tasks([], 1) == []
    for bad in (0, -1):
        try:
            await run_tasks([], bad)
            raise AssertionError("expected ValueError")
        except ValueError:
            pass
    try:
        await run_tasks([], "2")
        raise AssertionError("expected TypeError")
    except TypeError:
        pass
    print("edge ok")


async def main():
    await t_cap_and_order()
    await t_cleanup_on_cancel()
    await t_second_ctrlc_keeps_cleanup()
    await t_error_waits_for_siblings()
    await t_edge()
    print("ALL OK")


asyncio.run(main())