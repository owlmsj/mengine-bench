"""Bounded-concurrency runner for batch scripts.

    from run import run_tasks
    await run_tasks(jobs, max_concurrent=4)

Design decisions (the brief leaves these open):
- Results are returned as a list in the same order as ``tasks``.
- Every job is started and awaited; one job failing does not cancel the
  others. The first exception (in task order) is re-raised once all jobs
  have settled, so nothing is left running in the background.
- Cancellation (Ctrl+C) cancels each job once, then waits for every job to
  unwind so its ``finally`` / async cleanup completes, before re-raising
  ``CancelledError``. Extra Ctrl+C presses cannot abort that cleanup.
- Jobs are never awaited through ``gather``: ``gather`` forwards every new
  ``cancel()`` to the children, which would kill cleanup mid-flight.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Sequence
from typing import TypeVar

T = TypeVar("T")

__all__ = ["run_tasks"]


async def run_tasks(
    tasks: Sequence[Callable[[], Awaitable[T]]],
    max_concurrent: int,
) -> list[T]:
    """Run zero-argument job factories with at most ``max_concurrent`` live.

    Each element of ``tasks`` is called with no arguments and must return an
    awaitable; that awaitable is the job. Returns when every job is done.
    """
    if isinstance(max_concurrent, bool) or not isinstance(max_concurrent, int):
        raise TypeError(f"max_concurrent must be an int, got {max_concurrent!r}")
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent!r}")

    slots = asyncio.Semaphore(max_concurrent)

    async def worker(job: Callable[[], Awaitable[T]]) -> T:
        async with slots:
            return await job()

    children = [asyncio.ensure_future(worker(job)) for job in tasks]
    if not children:
        return []

    settled = asyncio.Event()
    unfinished = len(children)

    def on_done(_child: asyncio.Task) -> None:
        nonlocal unfinished
        unfinished -= 1
        if unfinished == 0:
            settled.set()

    for child in children:
        child.add_done_callback(on_done)

    try:
        await settled.wait()
    except asyncio.CancelledError:
        for child in children:
            child.cancel()
        # Wait out the unwinding. Cancelling *this* waiter is harmless: the
        # event and the child tasks are independent of it.
        while not settled.is_set():
            try:
                await settled.wait()
            except asyncio.CancelledError:
                continue
        raise

    outcomes = [
        asyncio.CancelledError() if c.cancelled() else c.exception()
        for c in children
    ]
    failure = next((o for o in outcomes if o is not None), None)
    if failure is not None:
        raise failure
    return [c.result() for c in children]