import re, sys
data = open('prices.db', 'rb').read()
print('len', len(data))
for m in re.finditer(rb'[^\x00]{2,}', data):
    print(m.start(), m.end(), m.group()[:100])