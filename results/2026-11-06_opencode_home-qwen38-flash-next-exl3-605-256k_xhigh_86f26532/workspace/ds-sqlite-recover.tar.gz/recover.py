import json, struct

data = open('prices.db', 'rb').read()
n = len(data)

def varint(buf, off):
    v = 0
    for i in range(9):
        if off >= len(buf):
            return None, off
        b = buf[off]; off += 1
        if i == 8:
            v = (v << 8) | b
        else:
            v = (v << 7) | (b & 0x7f)
            if not (b & 0x80):
                break
    return v, off

def parse_record(buf, off, end):
    hdr_start = off
    hdr_size, off = varint(buf, off)
    if hdr_size is None or hdr_size < 1:
        raise ValueError('bad hdr size')
    types = []
    p = off
    types_end = hdr_start + hdr_size
    while p < types_end:
        t, p = varint(buf, p)
        if t is None:
            raise ValueError('truncated type list')
        types.append(t)
    vals = []
    for t in types:
        if t == 0:
            vals.append(None)
        elif 1 <= t <= 4:
            if off + t > end: raise ValueError('trunc int')
            vals.append(int.from_bytes(buf[off:off+t], 'big', signed=True)); off += t
        elif t == 5:
            if off + 6 > end: raise ValueError('trunc int48')
            vals.append(int.from_bytes(buf[off:off+6], 'big', signed=True)); off += 6
        elif t == 6:
            if off + 8 > end: raise ValueError('trunc int64')
            vals.append(int.from_bytes(buf[off:off+8], 'big', signed=True)); off += 8
        elif t == 7:
            if off + 8 > end: raise ValueError('trunc real')
            vals.append(struct.unpack('>d', buf[off:off+8])[0]); off += 8
        elif t == 8:
            vals.append(0)
        elif t == 9:
            vals.append(1)
        elif t >= 12 and t % 2 == 0:
            ln = (t - 12) // 2
            if off + ln > end: raise ValueError('trunc blob')
            vals.append(buf[off:off+ln]); off += ln
        elif t >= 13:
            ln = (t - 13) // 2
            if off + ln > end: raise ValueError('trunc text')
            vals.append(buf[off:off+ln].decode('utf-8')); off += ln
    return vals

pgtype = data[0]
first_free, ncells, content_start, frag = struct.unpack('>HHHB', data[1:8])
print('page type', hex(pgtype), 'ncells', ncells, 'content', hex(content_start))
ptrs = [struct.unpack('>H', data[8+2*i:10+2*i])[0] for i in range(ncells)]
print('cell ptrs', [hex(p) for p in ptrs])

rows = []
for i, p in enumerate(sorted(ptrs)):
    try:
        payload_len, q = varint(data, p)
        rowid, q = varint(data, q)
        end = min(p + (q - p) + payload_len, n)
        cell_end = q + payload_len
        if cell_end > n:
            print(f'cell {i} at {p}: TRUNCATED (needs {cell_end}, file {n})')
            continue
        vals = parse_record(data, q, cell_end)
        print(f'cell {i} ptr {p} rowid {rowid} payload {payload_len} -> {vals!r}')
        rows.append((rowid, vals))
    except Exception as e:
        print(f'cell {i} ptr {p}: ERROR {e}')

out = []
for rowid, vals in rows:
    item = next((v for v in vals if isinstance(v, str)), None)
    price = next((v for v in vals if isinstance(v, (int, float)) and not isinstance(v, bool)), None)
    if item is None or price is None:
        print('skip non-matching row', vals)
        continue
    out.append({'item': item, 'price': price})

json.dump(out, open('recovered.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
print('recovered', len(out), 'rows')