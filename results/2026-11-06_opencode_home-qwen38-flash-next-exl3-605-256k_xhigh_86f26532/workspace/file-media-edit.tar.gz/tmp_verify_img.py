from PIL import Image
import numpy as np

im = Image.open('out/feed-photo.jpg').convert('RGB')
a = np.asarray(im).astype(int)
r, g, b = a[..., 0], a[..., 1], a[..., 2]
mask = (r > 120) & (b > 90) & (r - g > 60) & (b - g > 40)
ys, xs = np.nonzero(mask)
print('out size', im.size, 'magenta px', len(xs))
print('bbox x', xs.min(), xs.max(), 'y', ys.min(), ys.max())
print('margins L,T,R,B:', xs.min(), ys.min(), im.width - 1 - xs.max(), im.height - 1 - ys.max())