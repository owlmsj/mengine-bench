import fitz  # PyMuPDF

VALUES = {
    'organizer': 'Tidewater Studio',
    # form label asks for YYYY-MM-DD; keep Ines's wording alongside it
    'event_date': '2026-12-05 (Saturday 5 December 2026)',
    'location': 'North Cove Lawn',
    'attendees': 'about 40',
}

doc = fitz.open('permit-form.pdf')
filled = []
for page in doc:
    for w in page.widgets():
        name = w.field_name
        if name in VALUES:
            w.field_value = VALUES[name]
            w.update()
            filled.append((name, VALUES[name]))
print('filled:', filled)
doc.bake()  # flatten: widgets become page content, no editable form left
doc.save('out/permit-filled.pdf', garbage=3, deflate=True)
doc.close()

# verify
chk = fitz.open('out/permit-filled.pdf')
print('widgets after bake:', [w.field_name for p in chk for w in p.widgets()])
print('has form:', chk.is_form_pdf)
txt = chk[0].get_text()
for v in VALUES.values():
    print(repr(v), 'in page text:', v in txt)
print('---page text---')
print(txt)