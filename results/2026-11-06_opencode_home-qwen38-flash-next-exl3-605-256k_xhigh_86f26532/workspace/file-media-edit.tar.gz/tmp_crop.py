from PIL import Image
import os

im = Image.open('launch.jpg').convert('RGB')
W, H = im.size  # 3000x2000
CW, CH = 1080, 1350

# balloon bbox from detection: x 2350-2751, y 500-901 (centroid 2550,700)
bx0, by0, bx1, by1 = 2350, 500, 2751, 901
assert bx1 - bx0 + 1 <= CW and by1 - by0 + 1 <= CH

# center crop on balloon, clamp to image bounds
x0 = min(max(0, (bx0 + bx1) // 2 - CW // 2), W - CW)
y0 = min(max(0, (by0 + by1) // 2 - CH // 2), H - CH)
x1, y1 = x0 + CW, y0 + CH
assert bx0 >= x0 and bx1 < x1 and by0 >= y0 and by1 < y1, (x0, y0, x1, y1)

crop = im.crop((x0, y0, x1, y1))
os.makedirs('out', exist_ok=True)
crop.save('out/feed-photo.jpg', 'JPEG', quality=92, optimize=True)
print('crop window', x0, y0, x1, y1)
out = Image.open('out/feed-photo.jpg')
print('out size', out.size, out.format, out.mode)