from PIL import Image
import pypdf
im = Image.open('launch.jpg')
print('size', im.size)
r = pypdf.PdfReader('permit-form.pdf')
f = r.get_fields() or {}
for k, v in f.items():
    print(repr(k), v.get('/FT'), repr(v.get('/V')), repr(v.get('/Tu')))