from PIL import Image
import numpy as np

im = Image.open('launch.jpg').convert('RGB')
a = np.asarray(im).astype(int)
r, g, b = a[..., 0], a[..., 1], a[..., 2]
# magenta: red+blue high, green low
mask = (r > 120) & (b > 90) & (r - g > 60) & (b - g > 40)
ys, xs = np.nonzero(mask)
print('magenta px', len(xs))
if len(xs):
    print('bbox x', xs.min(), xs.max(), 'y', ys.min(), ys.max())
    print('bbox w', xs.max()-xs.min()+1, 'h', ys.max()-ys.min()+1)
    print('centroid', int(xs.mean()), int(ys.mean()))