"""Match payout. Rules live in docs/ECONOMY.md."""

from decimal import ROUND_HALF_UP, Decimal

_TEN = Decimal("10")
_ONE = Decimal("1")


def _exact(value):
    # str() first: Decimal(float) would keep the binary error of 1.25 style
    # multipliers and break the "halves round up" rule (docs/ECONOMY.md).
    return Decimal(str(value))


def match_payout(won, kills, cfg):
    base = _exact(cfg["win_base"] if won else cfg["loss_base"])
    raw = (base + _exact(cfg["kill_bonus"]) * kills) * _exact(cfg["event_multiplier"])
    return int((raw / _TEN).quantize(_ONE, rounding=ROUND_HALF_UP) * _TEN)