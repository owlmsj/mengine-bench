import csv, statistics as st, collections
rows = []
with open(r'capture\presentmon.csv') as f:
    for r in csv.DictReader(f):
        rows.append((float(r['TimeInSeconds']), float(r['MsBetweenPresents'])))
sens = list(csv.DictReader(open(r'capture\sensors.csv')))
per = collections.defaultdict(list)
for t, m in rows:
    per[int(t)].append(m)
print('sec n  mean  max   link dpc disk top')
for s in sens:
    i = int(s['time_s']); v = per.get(i, [])
    if not v: continue
    star = '*' if max(v) > 13.9 else ' '
    print('%3d %4d %6.2f %6.2f %s %3s %4s %3s %s' % (i, len(v), st.mean(v), max(v), star,
          s['gpu_pcie_link_state'], s['dpc_latency_us'], s['disk_active_pct'], s['top_cpu_process']))
bursts = [i for i in sorted(per) if max(per[i]) > 13.9]
l1 = [int(s['time_s']) for s in sens if s['gpu_pcie_link_state'] != 'L0']
print('burst seconds', bursts)
print('L1 seconds  ', l1)
print('identical:', bursts == l1)
n = sum(1 for _, m in rows if m > 13.9)
print('slow frames', n, 'in', len(bursts), 'bursts; per burst', n/len(bursts))
print('defender window 43-45 max ms', max(max(per[i]) for i in (43,44,45)), 'mean', st.mean([m for i in (43,44,45) for m in per[i]]))
base = st.mean([m for t,m in rows if m <= 13.9])
print('baseline mean ms (non-slow)', round(base,3), '-> fps', round(1000/base,1))
print('slow mean ms', round(st.mean([m for t,m in rows if m>13.9]),2))
# projected: if slow frames behaved like baseline
allm = [m for t,m in rows]
fixed = [base if m > 13.9 else m for m in allm]
import math
fx = sorted(fixed)
k=(len(fx)-1)*0.99; lo=int(k)
p99f = fx[lo]+(fx[lo+1]-fx[lo])*(k-lo)
print('projected avg fps %.1f  projected 1%% low %.1f' % (1000/st.mean(fixed), 1000/p99f))