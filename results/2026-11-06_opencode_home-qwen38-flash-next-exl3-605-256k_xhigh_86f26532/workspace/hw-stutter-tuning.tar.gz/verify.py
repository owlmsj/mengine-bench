import json, csv, statistics as st
d = json.load(open('result.json'))
print('keys', sorted(d.keys()))
print('avg', d['avg_fps'], 'low1pct', d['low_1pct_fps'], 'changes', len(d['changes']))
src = open('settings.json').read()
for c in d['changes']:
    assert sorted(c.keys()) == ['from', 'setting', 'to'], c
    assert '"%s"' % c['setting'] in src, c
    assert '"%s"' % c['from'] in src, c
    print('ok', c['setting'], c['from'], '->', c['to'])
m = [float(r['MsBetweenPresents']) for r in csv.DictReader(open('capture/presentmon.csv'))]
s = sorted(m)
k = (len(s) - 1) * 0.99; lo = int(k)
p99 = s[lo] + (s[lo + 1] - s[lo]) * (k - lo)
assert abs(round(1000 / st.mean(m), 2) - d['avg_fps']) < 0.01
assert abs(round(1000 / p99, 2) - d['low_1pct_fps']) < 0.01
print('metrics match capture:', round(1000 / st.mean(m), 2), round(1000 / p99, 2))
print('cause mentions Gen5 x4 untouched:', 'Gen5 x4' in d['cause'])