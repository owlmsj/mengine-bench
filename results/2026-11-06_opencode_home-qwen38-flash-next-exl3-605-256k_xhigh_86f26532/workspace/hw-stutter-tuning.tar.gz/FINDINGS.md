# arena-01 hitch diagnosis

Capture: `capture/presentmon.csv` (8238 presents, 59.999 s span, no dropped rows) +
`capture/sensors.csv` (60 x 1 s, same clock). Analysis: `analyze.py`, `analyze2.py`.

## Measured (owner's formulas, NOTES.md)
| metric | value |
|---|---|
| mean MsBetweenPresents | 7.284 ms |
| avg fps = 1000/mean | **137.29** |
| p99 MsBetweenPresents | 22.049 ms (nearest-rank and interpolated agree) |
| 1% low = 1000/p99 | **45.35** |
| median / p95 frame time | 6.96 / 7.52 ms (clean baseline ~143.8 fps) |

## Cause: PCIe ASPM L1 on the GPU root port
- Stall threshold (2x median = 13.9 ms) isolates 180 frames = 15 bursts of exactly 12 frames,
  repeating every 3.76 s of frame time (once every 4 s).
- Burst seconds: 2, 6, 10, 14, 18, 22, 26, 30, 34, 38, 42, 46, 50, 54, 58.
- Sensor `gpu_pcie_link_state != L0` seconds: **identical list** (`bursts == l1` -> True, 15/15).
- Every stall frame is ~22.0 ms (mean 22.04, max 23.68); every L0 second has max <= 8.2 ms.
- During a stall `MsInPresentAPI` = 0.2-0.4 ms and `MsUntilRenderComplete` ~5 ms, so the game
  thread and the GPU finish normally; the ~15 ms deficit is spent on the link (L1 exit/recovery).
- Link speed stays `Gen5 x4` in all 60 samples, so this is the ASPM power state, not the link width.

## Ruled out (distractors)
| suspect | evidence |
|---|---|
| Defender quick scan (s 43-45: MsMpEng top CPU, disk 94/83/80%, DPC 420/455/396 us) | no slow frame in that window: worst 8.13 ms, mean 6.96 ms |
| NVMe disk spikes (s 13/27/52: 92/86/85%) | max frame 7.73 / 7.83 / 7.67 ms |
| DPC latency | max 455 us = 0.46 ms, vs 15 ms deficit |
| CPU/GPU downclock, core parking, min core state | CPU 5150-5450 MHz, GPU 2710-2759 MHz, no dip |
| Vsync / frame limiter / Game DVR / HVCI | off / none / off / off already |

## Changes (within constraints: Gen5 x4 kept, no XMP/PBO/ratio edits)
1. `pcie_aspm_rp1_gpu`: `L1` -> `disabled` (BIOS). Direct fix: removes L1 entry on the GPU root
   port. `pcie_aspm_rp2_chipset` is already `disabled` and shows no L1 seconds.
2. `power_plan`: `Balanced` -> `High performance` (Windows). Stops the OS PCIe Link State Power
   Management policy from re-arming link power savings on the same port.
   Not changed: `gpu_link_speed`/`gpu_link_width` (fixed), `xmp_profile`, `cpu_pbo`,
   `cpu_core_ratio` (fixed), `defender_*` (no frame impact), `pcie_aspm_rp0_nvme` (no stalls).

Projected after fix (stall frames replaced by the 6.955 ms baseline): avg ~143.8 fps,
1% low ~130.7 fps. Not measured on hardware; this rig was not touched.