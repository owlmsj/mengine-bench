import csv, statistics as st

rows = []
with open(r'capture\presentmon.csv') as f:
    for r in csv.DictReader(f):
        if r['Dropped'] and r['Dropped'].strip() not in ('0', '', 'FALSE'):
            pass
        try:
            t = float(r['TimeInSeconds']); mbp = float(r['MsBetweenPresents'])
        except (ValueError, TypeError):
            continue
        rows.append((t, mbp, r['Dropped'], r['PresentFlags'], r['SyncInterval'],
                     float(r['MsInPresentAPI'] or 0), float(r['MsUntilRenderComplete'] or 0)))

mbps = sorted(x[1] for x in rows)
n = len(mbps)
mean = st.mean(mbps)
def pct(p):
    k = (n - 1) * p
    lo = int(k); hi = min(lo + 1, n - 1)
    return mbps[lo] + (mbps[hi] - mbps[lo]) * (k - lo)
p99 = pct(0.99)
print('frames', n, 'span_s', round(rows[-1][0] - rows[0][0], 3))
print('mean_ms %.3f avg_fps %.2f' % (mean, 1000 / mean))
print('p99_ms %.3f low1pct_fps %.2f' % (p99, 1000 / p99))
print('median %.2f p95 %.2f max %.2f' % (pct(.5), pct(.95), mbps[-1]))

sens = []
with open(r'capture\sensors.csv') as f:
    for r in csv.DictReader(f):
        sens.append(r)
print('sensor rows', len(sens))

# threshold: frames slower than 2x median
thr = pct(.5) * 2
slow = [x for x in rows if x[1] >= thr]
print('slow frames (>=%.1f ms): %d' % (thr, len(slow)))
gaps = [round(slow[i+1][0]-slow[i][0],2) for i in range(len(slow)-1)]
print('slow intervals', gaps[:40])

print('\nidx t_s mbp drop flags sync api render | sec cpuMHz cpuUtil gpuMHz link speed dpc_us disk top')
for x in slow[:40]:
    s = sens[int(round(x[0]))] if 0 <= int(round(x[0])) < len(sens) else {}
    print('%8.3f %7.2f %s %-6s %s %5.1f %6.1f | %s %s %s %s %s %s %s %s %s' % (
        x[0], x[1], x[2], x[3].strip(), x[4], x[5], x[6],
        s.get('time_s'), s.get('cpu_clock_mhz'), s.get('cpu_util_pct'), s.get('gpu_clock_mhz'),
        s.get('gpu_pcie_link_state'), s.get('gpu_pcie_link_speed'), s.get('dpc_latency_us'),
        s.get('disk_active_pct'), s.get('top_cpu_process')))

# sensor summaries
import collections
print('\nlink states', collections.Counter(s['gpu_pcie_link_state'] for s in sens))
print('link speeds', collections.Counter(s['gpu_pcie_link_speed'] for s in sens))
print('top procs', collections.Counter(s['top_cpu_process'] for s in sens))
dpc = sorted(int(s['dpc_latency_us']) for s in sens)
print('dpc us min/med/max', dpc[0], dpc[len(dpc)//2], dpc[-1])
clk = sorted(int(s['cpu_clock_mhz']) for s in sens)
print('cpu mhz min/med/max', clk[0], clk[len(clk)//2], clk[-1])
gclk = sorted(int(s['gpu_clock_mhz']) for s in sens)
print('gpu mhz min/med/max', gclk[0], gclk[len(gclk)//2], gclk[-1])
disk = sorted(int(s['disk_active_pct']) for s in sens)
print('disk min/med/max', disk[0], disk[len(disk)//2], disk[-1])
print('\nhigh dpc seconds (>500):', [s['time_s'] for s in sens if int(s['dpc_latency_us']) > 500])
print('low cpu clock seconds (<2000):', [s['time_s'] for s in sens if int(s['cpu_clock_mhz']) < 2000])
print('L1 seconds:', [s['time_s'] for s in sens if s['gpu_pcie_link_state'] != 'L0'])
print('non-Arena top proc seconds:', [(s['time_s'], s['top_cpu_process'], s['disk_active_pct'], s['dpc_latency_us']) for s in sens if s['top_cpu_process'] != 'Arena.exe'])