import json, datetime

# Annual IPCA (IBGE), calendar year %  - values verified against sources below
ipca = {1985: 226.22, 1986: 77.38, 1987: 236.62, 1988: 933.42, 1989: 1764.98,
        1990: 1589.83, 1991: 472.26, 1992: 1119.14, 1993: 2477.15, 1994: 916.14,
        1995: 22.41}

plans = [
    ("Cruzado",  datetime.date(1986, 2, 28), datetime.date(1987, 6, 12)),
    ("Bresser",  datetime.date(1987, 6, 12), datetime.date(1989, 1, 15)),
    ("Verao",    datetime.date(1989, 1, 15), datetime.date(1990, 3, 16)),
    ("Collor I", datetime.date(1990, 3, 16), datetime.date(1991, 1, 31)),
    ("Collor II",datetime.date(1991, 1, 31), datetime.date(1994, 7, 1)),
    ("Real",     datetime.date(1994, 7, 1),  None),
]

def whole_months(a, b):
    m = (b.year - a.year) * 12 + (b.month - a.month)
    if b.day < a.day:
        m -= 1
    return m

rows = []
for name, start, nxt in plans:
    y = start.year
    before, after = ipca[y - 1], ipca[y + 1]
    drop = max(0.0, min(1.0, 1 - after / before))
    months = 60 if nxt is None else whole_months(start, nxt)
    dur = min(months, 60) / 60
    score = 0.7 * drop + 0.3 * dur
    rows.append((name, y - 1, before, y + 1, after, months, round(score, 4)))

for r in rows:
    print(r)
print("TOP3:", [r[0] for r in sorted(rows, key=lambda r: -r[6])[:3]])