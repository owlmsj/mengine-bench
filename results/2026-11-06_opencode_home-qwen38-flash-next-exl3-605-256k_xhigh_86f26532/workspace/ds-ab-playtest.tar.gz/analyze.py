import csv, json, math
from collections import OrderedDict

rows = OrderedDict()
conflicts = 0
raw = 0
with open("telemetry/playtest_ab.csv", newline="") as f:
    for r in csv.DictReader(f):
        raw += 1
        sid = r["session_id"].strip()
        v = r["variant"].strip().upper()
        rec = (v, int(r["completed_tutorial"]))
        if sid in rows:
            if rows[sid] != rec:
                conflicts += 1
        else:
            rows[sid] = rec

n = {"A": 0, "B": 0}
k = {"A": 0, "B": 0}
for v, c in rows.values():
    n[v] += 1
    k[v] += c

pA, pB = k["A"] / n["A"], k["B"] / n["B"]
p_pool = (k["A"] + k["B"]) / (n["A"] + n["B"])
se = math.sqrt(p_pool * (1 - p_pool) * (1 / n["A"] + 1 / n["B"]))
z = (pB - pA) / se
# two-sided p-value from normal CDF
pval = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))

print(f"raw rows: {raw}, unique sessions: {len(rows)}, conflicting dup rows: {conflicts}")
print(f"A: {k['A']}/{n['A']} = {pA:.4f}")
print(f"B: {k['B']}/{n['B']} = {pB:.4f}")
print(f"diff (B-A): {pB-pA:+.4f}, z = {z:.4f}, two-sided p = {pval:.4f}")

out = {
    "ship_b": bool(pval < 0.05 and pB > pA),
    "sessions_a": n["A"],
    "sessions_b": n["B"],
    "completion_rate_a": round(pA, 4),
    "completion_rate_b": round(pB, 4),
    "p_value": round(pval, 4),
}
with open("result.json", "w") as f:
    json.dump(out, f, indent=2)
print(json.dumps(out))