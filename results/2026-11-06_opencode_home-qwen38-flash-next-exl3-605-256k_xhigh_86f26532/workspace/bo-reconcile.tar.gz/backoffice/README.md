# How we reconcile receivables

- The bank memo cites the invoice in different formats.
- Ignore fees, interest and PIX transfers without an identifiable invoice.
- unpaid: invoices with no payment. duplicated: invoices paid more than once.
- mismatched: a single payment whose amount differs from its invoice.
- The three categories are exclusive: a duplicated invoice is never also mismatched.
