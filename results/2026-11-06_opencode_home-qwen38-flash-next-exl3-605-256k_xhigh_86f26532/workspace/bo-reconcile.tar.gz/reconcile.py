import csv, json, re
from collections import defaultdict

inv = {}
with open('backoffice/invoices.csv', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        inv[r['id']] = float(r['amount'])

pat = re.compile(r'(?:inv-?|invoice\s+)(\d{4})', re.I)
pays = defaultdict(list)
ignored = []
with open('backoffice/bank_statement_june.csv', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        m = pat.search(r['memo'])
        key = f"INV-{m.group(1)}" if m else None
        if key not in inv or float(r['amount']) <= 0:
            ignored.append((r['date'], r['memo'], r['amount']))
            continue
        pays[key].append(float(r['amount']))

unpaid = sorted(i for i in inv if i not in pays)
duplicated = sorted(i for i, p in pays.items() if len(p) > 1)
mismatched = [{'id': i, 'invoiced': round(inv[i], 2), 'paid': round(p[0], 2)}
              for i, p in sorted(pays.items())
              if len(p) == 1 and abs(p[0] - inv[i]) > 0.005]

out = {'unpaid': unpaid, 'duplicated': duplicated, 'mismatched': mismatched}
with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
    f.write('\n')
print(json.dumps(out, ensure_ascii=False, indent=2))
print('ignored:', ignored)
print('matched invoices:', len(pays), 'of', len(inv))