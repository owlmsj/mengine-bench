# HANDOFF — local-9b 128k

Done:
- Baseline (`scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`): decode 37.8 t/s, VRAM 7881 MiB.
- Root cause: 7881 MiB is the WDDM ceiling; Shared Usage showed 1494 MiB spilled to shared memory, so 'all on GPU' was false.
- Fix: `--no-mmproj-offload -ub 512` removes the spill: VRAM 7697 MiB, decode 38.0 t/s (median of 3).
- Quants: Q6_K (7.03 GiB) does not fit at 128k, discarded; Q4_K_M fits at 7305 MiB / 40.4 t/s, fallback only.
- Applied in the local9 block of `scripts/start_server.ps1:165` and in profile `profiles/local/local-9b.json`.

Left to do (only open item):
- The evals README still cites `check_vision.ps1`, which no longer exists. Update or remove that reference.

Verify: rerun the measure command with the new flags; expect ≤7697 MiB, no Shared Usage spill, decode ≈38 t/s.

Assumptions: transcript numbers trusted as measured; this workspace holds only `session/` and `AGENTS.md`, so those repo files live in the real checkout.
