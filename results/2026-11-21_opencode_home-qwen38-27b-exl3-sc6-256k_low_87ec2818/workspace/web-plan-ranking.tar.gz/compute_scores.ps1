$ErrorActionPreference = 'Stop'

# Annual IPCA (IBGE), % of calendar year. Official series: IBGE IPCA page + IpeData serid 43465.
$ipca = @{
  1985 = 218.36
  1986 = 545.71
  1987 = 311.62
  1988 = 1116.65
  1989 = 764.50
  1990 = 574.13
  1991 = 471.43
  1992 = 271.38
  1993 = 247.69
  1994 = 91.63
  1995 = 0.97
}

$ibge  = 'https://www.ibge.gov.br/estatisticas/economicas/precos-e-custos/9256-indice-nacional-de-precos-ao-consumidor-amplo.html'
$ipe   = 'https://www.ipeadata.gov.br/ExibeSerie.aspx?serid=43465'
$wikip = 'https://pt.wikipedia.org/wiki/Hiperinflacao_no_Brasil'

# plan: name, launch date, next-plan launch date (Real: none -> 60 months per rubric)
$plans = @(
  @{ name='Cruzado';  launch=[datetime]'1986-02-28'; next=[datetime]'1987-06-12'; src=@("https://pt.wikipedia.org/wiki/Plano_Cruzado"); year=1986 },
  @{ name='Bresser';  launch=[datetime]'1987-06-12'; next=[datetime]'1989-01-15'; src=@($wikip); year=1987 },
  @{ name='Verao';    launch=[datetime]'1989-01-15'; next=[datetime]'1990-03-15'; src=@($wikip); year=1989 },
  @{ name='Collor I'; launch=[datetime]'1990-03-15'; next=[datetime]'1991-01-31'; src=@("https://pt.wikipedia.org/wiki/Plano_Collor"); year=1990 },
  @{ name='Collor II';launch=[datetime]'1991-01-31'; next=[datetime]'1994-07-01'; src=@("https://pt.wikipedia.org/wiki/Plano_Collor"); year=1991 },
  @{ name='Real';     launch=[datetime]'1994-07-01'; next=$null; src=@("https://pt.wikipedia.org/wiki/Plano_Real"); year=1994 }
)

function WholeMonths([datetime]$a, [datetime]$b) {
  $m = ($b.Year - $a.Year) * 12 + ($b.Month - $a.Month)
  if ($b.Day -lt $a.Day) { $m-- }
  return $m
}

$results = @()
foreach ($p in $plans) {
  $before = $ipca[$p.year - 1]
  $after  = $ipca[$p.year + 1]
  $drop   = [math]::Min(1.0, [math]::Max(0.0, 1.0 - ($after / $before)))
  if ($null -eq $p.next) { $months = 60 } else { $months = WholeMonths $p.launch $p.next }
  $dur    = [math]::Min($months, 60) / 60.0
  $score  = 0.7 * $drop + 0.3 * $dur
  $sources = @($ibge, $ipe) + $p.src + @($wikip) | Select-Object -Unique
  $results += [pscustomobject]@{
    plan = $p.name
    launch_date = $p.launch.ToString('yyyy-MM-dd')
    ipca_before = $before
    ipca_after  = $after
    months_lasted = $months
    score = [math]::Round($score, 4)
    sources = $sources
  }
  Write-Host ("{0}: before={1} after={2} drop={3:F4} months={4} dur={5:F4} score={6:F4}" -f $p.name,$before,$after,$drop,$months,$dur,$score)
}

$top3 = $results | Sort-Object score -Descending | Select-Object -First 3
$out = [pscustomobject]@{
  plans = $results
  top3  = @($top3 | ForEach-Object { $_.plan })
}
$json = $out | ConvertTo-Json -Depth 5
Set-Content -Path (Join-Path $PSScriptRoot 'result.json') -Value $json -Encoding utf8
Write-Host "TOP3: " + (($top3 | ForEach-Object { $_.plan }) -join ' > ')
