import sqlite3, json
c = sqlite3.connect(r'./analytics.db')
users = {}
for uid, plat, is_test in c.execute("SELECT user_id, platform, is_test FROM users"):
    users[uid] = (plat, is_test)
ev_names = {}
events = {}
unknown = 0
for uid, name, ts in c.execute("SELECT user_id, name, ts FROM events"):
    ev_names[name] = ev_names.get(name, 0) + 1
    if uid not in users:
        unknown += 1
        continue
    events.setdefault(uid, []).append((ts, name))
print("event names:", ev_names)
print("events from unknown users:", unknown)

STEPS = ["install", "tutorial_complete", "first_match", "purchase"]
per = {}
for uid, (plat, is_test) in users.items():
    if is_test:
        continue
    per.setdefault(plat, {}).setdefault(uid, {})
    prev = None
    for ts, name in sorted(events.get(uid, [])):
        if name not in STEPS or name in per[plat][uid]:
            continue
        if prev is not None and ts < prev:
            continue
        if name == STEPS[0] or (prev and ts >= prev):
            per[plat][uid][name] = ts
            prev = ts

out = {"funnel": {}, "biggest_drop": {}}
for plat, players in sorted(per.items()):
    fun = [sum(1 for p in players.values() if s in p) for s in STEPS]
    out["funnel"][plat] = dict(zip(STEPS, fun))
    conv = []
    for i in range(1, 4):
        if fun[i-1] == 0:
            conv.append(None)
        else:
            conv.append(round(fun[i] / fun[i-1], 6))
    # biggest drop = step with lowest conversion
    valid = [(conv[i], STEPS[i+1]) for i in range(3) if conv[i] is not None]
    drop = min(valid, key=lambda x: x[0])[1] if valid else None
    out["biggest_drop"][plat] = drop
    print(plat, fun, conv, "-> drop:", drop)

json.dump(out, open(r'./result.json', 'w'), indent=2)
print("written")
