import sqlite3, json
c = sqlite3.connect(r'./analytics.db')
tables = [r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")]
for t in tables:
    cols = [d[1] for d in c.execute(f"PRAGMA table_info({t})")]
    n = c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
    print(t, cols, "rows:", n)
    for r in c.execute(f"SELECT * FROM {t} LIMIT 5"):
        print("  ", r)
