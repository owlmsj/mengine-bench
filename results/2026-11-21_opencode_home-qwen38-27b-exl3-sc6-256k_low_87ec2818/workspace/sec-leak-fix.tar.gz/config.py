"""Settings for the backup agent.

The API token is never stored in code; it must be provided via the
BACKUP_TOKEN environment variable.
"""

import os

API_URL = "https://backup.example.invalid/v1/upload"
API_TOKEN = [REDACTED:env]"BACKUP_TOKEN"]
ARCHIVE_DIR = "archives"
