# Monthly P&L, burn, runway from finance/ledger.csv
import csv, json
from decimal import Decimal, ROUND_HALF_UP
from collections import defaultdict

coa = {}
with open(r"finance/chart_of_accounts.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        coa[row["account"].strip()] = (row["name"].strip(), row["pnl_line"].strip())

months = ["2026-01", "2026-02", "2026-03", "2026-04", "2026-05", "2026-06"]
sums = {m: defaultdict(Decimal) for m in months}
cash_change = {m: Decimal(0) for m in months}

with open(r"finance/ledger.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        d, acct = row["date"].strip(), row["account"].strip()
        day, mo, yr = d.split("/")
        key = f"{yr}-{mo}"
        amt = Decimal(row["amount"].strip().replace(".", "").replace(",", "."))
        _, line = coa[acct]
        sums[key][line] += amt
        cash_change[key] += amt

def r2(x): return float(Decimal(x).quantize(Decimal("0.01"), ROUND_HALF_UP))

print(f"{'month':8} {'revenue':>13} {'cogs':>13} {'S&M':>12} {'R&D':>12} {'G&A':>12} {'fin':>11} {'EBITDA':>13} {'GM%':>7}")
for m in months:
    s = sums[m]
    rev, cogs = s["revenue"], s["cogs"]
    gm = (rev + cogs) / rev * 100 if rev else Decimal(0)
    ebitda = sum(v for k, v in s.items() if k != "financial")
    print(f"{m:8} {rev:>13} {cogs:>13} {s['sales_marketing']:>12} {s['rnd']:>12} {s['ga']:>12} {s['financial']:>11} {ebitda:>13} {gm:>7.2f}")

# Cross-check: June ledger total must equal cash change 31/05 -> 30/06
delta = Decimal("1847350.40") - Decimal("2309188.00")
print(f"\ncheck June: ledger total {cash_change['2026-06']} vs cash delta {delta} -> match={cash_change['2026-06'] == delta}")

# Board burn: average monthly negative EBITDA of last 3 closed months (Apr, May, Jun)
burn_months = ["2026-04", "2026-05", "2026-06"]
eb = {}
for m in months:
    s = sums[m]
    eb[m] = sum(v for k, v in s.items() if k != "financial")
negs = {m: -eb[m] for m in burn_months}
for m in burn_months:
    print(f"neg EBITDA {m}: {negs[m]}")
burn = sum(negs.values()) / 3
cash = Decimal("1847350.40")
runway = cash / burn
print(f"burn = {burn}\nrunway = {runway} months")

result = {
    "revenue": {m: r2(sums[m]["revenue"]) for m in months},
    "gross_margin_pct": {m: r2((sums[m]["revenue"] + sums[m]["cogs"]) / sums[m]["revenue"] * 100) for m in months},
    "ebitda": {m: r2(eb[m]) for m in months},
    "burn": r2(burn),
    "runway_months": round(float(runway), 2),
}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
print("\nresult.json written")
