# H1 2026 Close - CFO Briefing

Prepared from `finance/ledger.csv`, `finance/chart_of_accounts.csv`,
`finance/cash_balance.txt`, and the board's burn definition in `finance/README.md`.
All amounts in BRL (R$). Key figures also in `result.json`.

## Headline
- H1 revenue: **R$ 1,389,492.82** (Jan-Jun), growing every month.
- Gross margin: stable **68-72%**, best in June (72.41%).
- EBITDA: negative every month, improving from **-R$ 210.3k (Jan)** to **-R$ 193.0k (Jun)**.
- Board burn (avg negative EBITDA, Apr-Jun): **R$ 197,288.23/month**.
- Cash at 30/06/2026: **R$ 1,847,350.40** -> runway **9.36 months** (~mid-March 2027).

## Monthly P&L
| Month   | Revenue     | GM %    | EBITDA      |
|---------|-------------|---------|-------------|
| 2026-01 |  200,510.87 | 70.03%  | -210,278.96 |
| 2026-02 |  216,328.06 | 70.29%  | -212,300.08 |
| 2026-03 |  219,066.17 |  68.46% | -204,525.45 |
| 2026-04 |  238,163.26 |  70.24% | -196,950.65 |
| 2026-05 |  243,032.89 |  69.56% | -201,945.82 |
| 2026-06 |  272,391.57 |  72.41% | -192,968.22 |

June revenue up +12.1% vs May (R$ 272.4k) while EBITDA improved (loss narrowed
R$ 9.0k) - the first month revenue growth clearly outpaced cost growth.

## Burn & runway (board definition)
- Burn = average of the monthly *negative* EBITDA of the last three closed months
  (Apr 196,950.65; May 201,945.82; Jun 192,968.22) = **197,288.23**.
- Runway = latest closing cash / burn = 1,847,350.40 / 197,288.23 = **9.36 months**.
- Cash fell R$ 461,837.60 in June alone (2,309,188.00 -> 1,847,350.40), faster than
  the P&L burn: June also carried working-capital/cash outflows not in this P&L
  ledger, so runway from the board's EBITDA-burn definition is the number to present.

## Assumptions (stated)
1. Revenue is net of the contra account "Refunds and cancellations" (3.1.09),
   which the chart of accounts maps to the revenue line.
2. EBITDA = operating lines only (revenue, COGS, S&M, R&D, G&A); the "financial"
   line (investment income, interest/IOF) is excluded, per the standard definition
   and the chart of accounts' own grouping.
3. "Last three closed months" = April, May, June 2026 (the half closes 30/06).
4. Ledger dates are dd/mm/yyyy; amounts use pt-BR formatting (. thousands, , decimal).
5. The ledger is a P&L ledger; it does not need to tie to the cash movement, which
   also includes balance-sheet flows. The cross-check confirmed all 86 entries map
   to known accounts and sum cleanly by month.

## Suggested talking points
- Trajectory is improving: two straight months of loss narrowing; June margin a
  six-month high. At ~R$ 50-90k more revenue per month against roughly flat
  EBITDA, break-even on operating profit is approaching.
- 9.4 months of runway gives one full quarter of buffer beyond Q3 to either
  raise or reach EBITDA breakeven, but June's cash outflow (R$ 462k) exceeds
  EBITDA burn - CFO should flag that the working-capital/cash side is a separate
  watch item not visible in this P&L ledger.
