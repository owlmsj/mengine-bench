import csv, json

GB = 1e9
params = 70e9
weights_gb = params * 1.0 / GB  # FP8: 1 byte per parameter
kv_per_token = 327_680          # bytes, FP16, all layers, K and V
ctx = 32_768                    # tokens per sequence
seqs = 4
kv_gb = kv_per_token * ctx * seqs / GB
overhead_gb = 8.0
total_gb = weights_gb + kv_gb + overhead_gb
print(f"weights_gb={weights_gb}")
print(f"kv_cache_gb={kv_gb}")
print(f"total_gb={total_gb}")

allowed = {"us-east", "us-central", "eu-west"}
best = None
with open("offers.csv", newline="") as f:
    for row in csv.DictReader(f):
        usable = int(row["gpu_count"]) * float(row["vram_gb_per_gpu"])
        hr = float(row["usd_per_hour"])
        ok_stock = row["in_stock"].strip() == "yes"
        ok_region = row["region"] in allowed
        ok_cap = hr <= 4.0
        ok_mem = usable >= total_gb
        eligible = ok_stock and ok_region and ok_cap and ok_mem
        print(f"{row['offer_id']:8} usable={usable:6.1f} hr={hr:4.2f} "
              f"stock={ok_stock} region={ok_region} cap={ok_cap} mem={ok_mem} -> eligible={eligible}")
        if eligible and (best is None or hr < best[1]):
            best = (row["offer_id"], hr)

offer_id, hr = best
result = {
    "weights_gb": weights_gb,
    "kv_cache_gb": kv_gb,
    "total_gb": total_gb,
    "offer_id": offer_id,
    "usd_per_hour": hr,
    "usd_per_month": round(hr * 730, 2),
}
print(json.dumps(result, indent=2))
with open("result.json", "w") as f:
    json.dump(result, f, indent=2)
