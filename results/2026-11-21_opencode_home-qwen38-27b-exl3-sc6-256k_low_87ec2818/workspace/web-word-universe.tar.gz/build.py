# -*- coding: utf-8 -*-
"""Inject the parsed graph into universe/index.html (no build step at review)."""
import json, os

ROOT = os.path.dirname(os.path.abspath(__file__))
def load(name):
    return json.load(open(os.path.join(ROOT, name), encoding="utf-8"))

words = load("words.json")
meta = load("graph.json")
result = load("result.json")

# theme colors (10 themes of the dictionary)
colors = {
    "artes": "#f59e0b",
    "comida": "#ef4444",
    "corpo": "#fb7185",
    "família": "#a78bfa",
    "linguagem": "#38bdf8",
    "lugares": "#2dd4bf",
    "natureza": "#10b981",
    "ofícios": "#eab308",
    "sentimentos": "#ec4899",
    "tempo": "#818cf8",
}

# edge list: distinct pairs among words + word->ghost links
edges = set()
for w, ls in words.items():
    for t in ls:
        edges.add(tuple(sorted([w.lower(), t.lower()])))
ghost_edges = set()
for g, d in result["broken_links"].items():
    for w in d["from"]:
        ghost_edges.add((w.lower(), g))
edges = sorted(edges) + sorted(tuple(sorted(e)) for e in ghost_edges)

payload = {
    "words": {w: sorted(ls, key=str.lower) for w, ls in words.items()},
    "meta": {w: {"tema": meta[w]["tema"], "degree": meta[w]["degree"], "pos": meta[w]["pos"]}
             for w in meta},
    "sin": {w: meta[w]["sin"] for w in meta},
    "anw": {w: meta[w]["an"] for w in meta},
    "ghosts": result["broken_links"],
    "themes": sorted(colors),
    "colors": colors,
    "stats": {
        "words": result["words"],
        "relations": result["relations"],
        "most_connected": result["most_connected"],
    },
    "edges": [list(e) for e in edges],
}

tpl = open(os.path.join(ROOT, "universe", "index.html"), encoding="utf-8").read()
assert "__PAYLOAD__" in tpl
out = tpl.replace("__PAYLOAD__", json.dumps(payload, ensure_ascii=False, separators=(",", ":")))
open(os.path.join(ROOT, "universe", "index.html"), "w", encoding="utf-8").write(out)
print("injected", len(payload["edges"]), "edges;",
      len(payload["words"]), "words;", len(payload["ghosts"]), "ghosts")
