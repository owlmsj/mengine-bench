# -*- coding: utf-8 -*-
"""Parse the creative dictionary site into a word graph."""
import json, os, re, html
from urllib.parse import unquote

SITE = os.path.join(os.path.dirname(__file__), "site")
SKIP = {"index.html", "sobre.html", "contato.html"}

def read(p):
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            return open(p, encoding=enc).read()
        except UnicodeDecodeError:
            continue
    raise ValueError("undecodable: " + p)

# 1) canonical name per file: h1 (display form), fallback percent-decoded stem
files = {}
for fn in sorted(os.listdir(SITE)):
    if not fn.lower().endswith(".html") or fn in SKIP:
        continue
    text = read(os.path.join(SITE, fn))
    m = re.search(r"<h1>(.*?)</h1>", text)
    h1 = html.unescape(m.group(1)).strip() if m else None
    stem = unquote(os.path.splitext(fn)[0])
    files[fn] = {"stem": stem, "h1": h1, "text": text}

print("files:", len(files))
print("stem2word:", len(stem2word))
import sys
if not files: sys.exit(0)
# normalize: lowercase, keep accents
def norm(s):
    return s.strip().lower()

# key (lowercase stem) -> canonical word
stem2word = {}
for fn, d in files.items():
    key = norm(d["stem"])
    stem2word[key] = d["h1"] if d["h1"] else key

# resolve a href to a canonical word, or None if it is not a word page
def resolve(href):
    if href in SKIP or not href.lower().endswith(".html"):
        return None
    key = norm(unquote(href))
    if key in stem2word:
        return stem2word[key]
    # case-insensitive filesystem match (handles Alfaiate.html vs alfaiate.html)
    for fn in files:
        if norm(os.path.splitext(fn)[0]) == key:
            return stem2word[key]
    return None

# 2) extract relations from sections only (sinonimos + analogas)
link_re = re.compile(r"<section id=\"([^\"]+)\">(.*?)</section>", re.S)
a_re = re.compile(r"<a href=\"([^\"]+)\">([^<]*)</a>")

graph = {}
ghosts = {}  # word -> count of links pointing at missing pages
for fn, d in files.items():
    word = stem2word[norm(d["stem"])]
    links = []
    for sid, body in link_re.findall(d["text"]):
        for href, label in a_re.findall(body):
            tgt = resolve(href)
            if tgt is None:
                ghosts.setdefault(norm(unquote(href)), []).append((word, label, sid))
                continue
            links.append(tgt)
    graph[word] = links

# canonicalize: keep the first (page) spelling as the word's name
words = {}
for w, ls in graph.items():
    words[w] = sorted(set(ls), key=str.lower)

print("graph entries:", len(graph), "with links:", sum(1 for v in graph.values() if v))
print("sample:", list(graph.items())[:2])
# 3) stats
def key(w):
    return norm(w)
degree = {}
pairs = set()
for w, ls in words.items():
    for t in ls:
        a, b = sorted([key(w), key(t)])
        pairs.add((a, b))
        degree[key(w)] = degree.get(key(w), 0)
        degree[key(t)] = degree.get(key(t), 0) + 1

best_key = max(sorted(degree), key=lambda k: (degree[k], k))
best_word = next(w for w in words if key(w) == best_key)

result = {
    "words": len(words),
    "relations": len(pairs),
    "most_connected": best_word,
    "most_connected_degree": degree[best_key],
    "ghost_links": {k: v for k, v in ghosts.items()},
    "top5": sorted(((w, degree[key(w)]) for w in words), key=lambda x: -x[1])[:5],
}

out = os.path.dirname(__file__)
json.dump(words, open(os.path.join(out, "words.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
json.dump(result, open(os.path.join(out, "result.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)

# also dump ghost targets for the visualization
ghost_words = {}
for k, v in ghosts.items():
    ghost_words[k] = {"label": v[0][1], "seen_from": sorted(set(w for w, _, _ in v))}
json.dump(ghost_words, open(os.path.join(out, "ghosts.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)

print("words:", len(words))
print("distinct pairs:", len(pairs))
print("most connected:", best_word, degree[best_key])
print("top5:", result["top5"])
print("ghosts:", ghost_words)
# duplicates with same stem?
from collections import Counter
c = Counter(key(w) for w in words)
dups = {k: v for k, v in c.items() if v > 1}
print("duplicate keys:", dups)
# words with empty link lists
print("no-links:", [w for w, ls in words.items() if not ls])

