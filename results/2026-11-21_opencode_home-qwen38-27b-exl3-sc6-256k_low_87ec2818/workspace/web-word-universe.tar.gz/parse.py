# -*- coding: utf-8 -*-
"""Parse the creative dictionary site into a word graph + 3D layout.

Canonical word name comes from each page's <h1> (filenames on disk are
mojibake; HTML hrefs are properly percent-encoded). Pages with a
< meta refresh > are redirect stubs, not words: links to them follow the
redirect one level. Relations are the links inside a page's
< section > (sinonimos / analogas); the aside and footer are navigation.
"""
import json, math, os, re, html
from urllib.parse import unquote

ROOT = os.path.dirname(os.path.abspath(__file__))
SITE = os.path.join(ROOT, "site")
SKIP = {"index.html", "sobre.html", "contato.html"}

def read(p):
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            return open(p, encoding=enc).read()
        except UnicodeDecodeError:
            continue
    raise ValueError("undecodable: " + p)

def norm(s):
    return s.strip().lower()

pages = {}
for fn in sorted(os.listdir(SITE)):
    if not fn.lower().endswith(".html") or fn in SKIP:
        continue
    pages[fn] = read(os.path.join(SITE, fn))

def norm_noaccent(s):
    import unicodedata
    d = unicodedata.normalize("NFD", s)
    return "".join(c for c in d if unicodedata.category(c) != "Mn")

# classify pages
redirects = {}   # stem -> target stem (meta refresh)
entries = {}     # word (h1) -> {tema, stem, text}
for fn, text in pages.items():
    m = re.search(r'<meta http-equiv="refresh" content="\d+;\s*url=([^">]+)"', text)
    if m:
        redirects[norm(unquote(os.path.splitext(fn)[0]))] = norm(unquote(os.path.splitext(m.group(1))[0]))
        continue
    hm = re.search(r"<h1>(.*?)</h1>", text)
    word = html.unescape(hm.group(1)).strip() if hm else norm(unquote(os.path.splitext(fn)[0]))
    tm = re.search(r'<p class="tema">Tema:\s*([^<]+)</p>', text)
    tema = tm.group(1).strip() if tm else ""
    entries[word] = {"tema": tema, "stem": norm(unquote(os.path.splitext(fn)[0])), "text": text}

# lookup: word by h1 (accented, from content) and by raw stem (mojibake-safe)
key2word = {}
for w, d in entries.items():
    key2word[norm(w)] = w
    key2word[d["stem"]] = w

def stem_of(href):
    return norm(unquote(os.path.splitext(href)[0]))

def resolve(href):
    """Canonical word an href points to, following one redirect. None if unknown."""
    if href in SKIP or not href.lower().endswith(".html"):
        return None
    k = stem_of(href)
    if k in redirects:
        k = redirects[k]
    return key2word.get(k)

link_re = re.compile(r"<section id=\"([^\"]+)\">(.*?)</section>", re.S)
a_re = re.compile(r"<a href=\"([^\"]+)\">([^<]*)</a>")

graph = {}
ghosts = {}
for w, d in entries.items():
    g = graph.setdefault(w, {"sinonimos": set(), "analogas": set()})
    for sid, body in link_re.findall(d["text"]):
        for href, label in a_re.findall(body):
            tgt = resolve(href)
            if tgt is None:
                gg = ghosts.setdefault(stem_of(href), {"label": label, "from": set()})
                gg["from"].add(w)
                continue
            g["sinonimos" if sid == "sinonimos" else "analogas"].add(tgt)

for g in ghosts.values():
    g["from"] = sorted(set(g["from"]))

words = {}
for w in sorted(entries, key=norm):
    g = graph[w]
    linked = list(g["sinonimos"]) + [x for x in g["analogas"] if x not in g["sinonimos"]]
    words[w] = sorted(set(linked), key=norm)

# ---- stats
degree = {}
pairs = set()
for w, ls in words.items():
    for t in ls:
        a, b = tuple(sorted([norm(w), norm(t)]))
        pairs.add((a, b))
        degree[a] = degree.get(a, 0) + 1
        degree[b] = degree.get(b, 0) + 1
best_key = max(degree, key=lambda k: (degree[k], k))
best_word = next(w for w in words if norm(w) == best_key)
result = {
    "words": len(words),
    "relations": len(pairs),
    "most_connected": best_word,
    "most_connected_degree": degree[best_key],
    "redirects": redirects,
    "broken_links": ghosts,
}

# ---- 3D layout: theme clusters on a sphere + force refinement
themes = sorted({d["tema"] for d in entries.values() if d["tema"]}, key=norm_noaccent)
tmap = {t: i for i, t in enumerate(themes)}
theme_of = {w: d["tema"] for w, d in entries.items()}
n = len(words)
ids = sorted(words, key=norm)
idx = {w: i for i, w in enumerate(ids)}

# golden-spiral points for theme centers
import math
def spiral(i, total, r):
    phi = math.acos(1 - 2 * (i + 0.5) / total)
    theta = math.pi * (1 + math.sqrt(5)) * i
    return [r * math.sin(phi) * math.cos(theta),
            r * math.sin(phi) * math.sin(theta),
            r * math.cos(phi)]
centers = [spiral(i, len(themes), 34) for i in range(len(themes))]
def tcenter(w):
    t = theme_of[w]
    return centers[tmap[t]] if t in tmap else [0, 0, 0]

import random
rng = random.Random(42)
pos = {}
for w in ids:
    c = tcenter(w)
    pos[w] = [c[0] + rng.uniform(-9, 9), c[1] + rng.uniform(-9, 9), c[2] + rng.uniform(-9, 9)]
adj = list(pairs)
for it in range(220):
    cool = 1 - it / 220
    move = {w: [0.0, 0.0, 0.0] for w in ids}
    # repulsion (all pairs, capped)
    for i in range(n):
        a = ids[i]
        pa = pos[a]
        for j in range(i + 1, n):
            b = ids[j]
            pb = pos[b]
            dx, dy, dz = pa[0] - pb[0], pa[1] - pb[1], pa[2] - pb[2]
            d2 = dx * dx + dy * dy + dz * dz + 0.01
            if d2 > 900:
                continue
            f = 14.0 / d2
            d = math.sqrt(d2)
            fx, fy, fz = f * dx / d, f * dy / d, f * dz / d
            move[a][0] += fx; move[a][1] += fy; move[a][2] += fz
            move[b][0] -= fx; move[b][1] -= fy; move[b][2] -= fz
    # springs along edges
    for a, b in adj:
        pa, pb = pos[a], pos[b]
        dx, dy, dz = pb[0] - pa[0], pb[1] - pa[1], pb[2] - pa[2]
        d = math.sqrt(dx * dx + dy * dy + dz * dz) + 0.01
        f = 0.02 * (d - 12.0)
        fx, fy, fz = f * dx / d, f * dy / d, f * dz / d
        move[a][0] += fx; move[a][1] += fy; move[a][2] += fz
        move[b][0] -= fx; move[b][1] -= fy; move[b][2] -= fz
    # pull toward theme center
    for w in ids:
        c = tcenter(w)
        p = pos[w]
        move[w][0] += 0.015 * (c[0] - p[0])
        move[w][1] += 0.015 * (c[1] - p[1])
        move[w][2] += 0.015 * (c[2] - p[2])
    for w in ids:
        s = min(1.0, cool * 0.9)
        m = move[w]
        pos[w][0] += m[0] * s; pos[w][1] += m[1] * s; pos[w][2] += m[2] * s

out = {}
for w in ids:
    out[w] = {
        "tema": theme_of[w],
        "degree": degree.get(norm(w), 0),
        "pos": [round(v, 2) for v in pos[w]],
        "sin": sorted(graph[w]["sinonimos"], key=norm),
        "an": sorted(graph[w]["analogas"], key=norm),
    }
json.dump(words, open(os.path.join(ROOT, "words.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
json.dump(result, open(os.path.join(ROOT, "result.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
json.dump(out, open(os.path.join(ROOT, "graph.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)

print("entries:", len(entries), "redirect stubs:", redirects)
print("words:", len(words))
print("distinct pairs:", len(pairs))
print("most connected:", best_word, degree[best_key])
print("top10:", sorted(((w, degree[norm(w)]) for w in words), key=lambda x: (-x[1], x[0]))[:10])
print("themes:", {t: sum(1 for w in ids if theme_of[w] == t) for t in themes})
print("ghosts:", {k: v["from"] for k, v in ghosts.items()})
print("no-links:", [w for w, ls in words.items() if not ls])
