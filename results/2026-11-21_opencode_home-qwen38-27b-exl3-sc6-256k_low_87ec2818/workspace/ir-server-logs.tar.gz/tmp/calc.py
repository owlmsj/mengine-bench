from datetime import datetime

start = datetime.fromisoformat("2026-06-02T03:17:42")
end = datetime.fromisoformat("2026-06-02T03:53:31")
down = (end - start).total_seconds()

june_seconds = 30 * 86400
avail = (june_seconds - down) / june_seconds * 100

print("down_seconds =", down)
print("minutes_exact =", down / 60)
print("availability_pct =", avail)
print("slo_ok =", avail >= 99.9)
