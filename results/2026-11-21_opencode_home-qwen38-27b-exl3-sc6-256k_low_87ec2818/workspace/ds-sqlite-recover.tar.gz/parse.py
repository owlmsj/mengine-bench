import struct, json, sys

data = open(r"<WORKSPACE>\prices.db", "rb").read()
assert len(data) == 4096, len(data)

def varint(buf, off):
    v = 0
    for i in range(8):
        b = buf[off + i]
        if i == 7:
            v = (v << 8) | b
            return v, off + 8
        v = (v << 7) | (b & 0x7F)
        if not (b & 0x80):
            return v, off + i + 1
    raise ValueError("bad varint at %d" % off)

def serial_type_decode(buf, off, st):
    if st == 0:
        return None, off
    if st == 1:
        return struct.unpack_from(">b", buf, off)[0], off + 1
    if st == 2:
        return struct.unpack_from(">h", buf, off)[0], off + 2
    if st == 3:
        v = buf[off] << 16 | buf[off + 1] << 8 | buf[off + 2]
        if v >= 0x800000:
            v -= 1 << 24
        return v, off + 3
    if st == 4:
        return struct.unpack_from(">i", buf, off)[0], off + 4
    if st == 5:
        return struct.unpack_from(">q", buf, off)[0], off + 6
    if st == 6:
        return struct.unpack_from(">q", buf, off)[0], off + 8
    if st == 7:
        return struct.unpack_from(">d", buf, off)[0], off + 8
    if st == 8:
        return 0, off
    if st == 9:
        return 1, off
    if st >= 12:
        n = (st - 12) // 2
        if st % 2 == 0:
            return bytes(buf[off:off + n]), off + n
        return buf[off:off + n].decode("utf-8"), off + n
    raise ValueError("bad serial type %d" % st)

# B-tree leaf table page header
ptype = data[0]
first_free = struct.unpack_from(">H", data, 1)[0]
ncell = struct.unpack_from(">H", data, 3)[0]
content_start = struct.unpack_from(">H", data, 5)[0]
frag = data[7]
print(f"page type={ptype} cells={ncell} content_start={content_start} frag={frag}")
assert ptype == 13 and frag == 0

pointers = [struct.unpack_from(">H", data, 8 + 2 * i)[0] for i in range(ncell)]
print("cell pointers:", pointers)

rows = []
ok = True
for idx, ptr in enumerate(pointers):
    try:
        off = ptr
        payload, off = varint(data, off)
        rowid, off = varint(data, off)
        hdr_size, off2 = varint(data, off)
        assert off2 + hdr_size == off + 0 or True
        # header size includes itself; data starts at off + hdr_size
        serials = []
        hoff = off2
        while hoff < off2 + hdr_size - 1:
            st, hoff = varint(data, hoff)
            serials.append(st)
        assert hoff == off2 + hdr_size, (idx, hoff, off2 + hdr_size)
        d = off + hdr_size
        vals = []
        for st in serials:
            v, d = serial_type_decode(data, d, st)
            vals.append(v)
        # cell must end within page
        assert d <= 4096, (idx, d)
        print(f"cell {idx+1}: rowid={rowid} payload={payload} serials={serials} vals={vals!r} end={d}")
        rows.append((rowid, vals))
    except Exception as e:
        ok = False
        print(f"cell {idx+1}: PARSE FAIL {e!r}")

rows.sort(key=lambda r: r[0])
out = []
for rowid, vals in rows:
    item = vals[0]
    price = vals[1] if len(vals) > 1 else None
    if isinstance(price, float) and price.is_integer():
        price = int(price)
    out.append({"item": item, "price": price})
with open(r"<WORKSPACE>\recovered.json", "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2)
print("wrote", len(out), "rows, all_ok=", ok)
