import csv, re, json, os

base = r'<WORKSPACE>'
inv = {}
with open(os.path.join(base, 'backoffice/invoices.csv'), encoding='utf-8') as f:
    for row in csv.DictReader(f):
        inv[row['id']] = round(float(row['amount']), 2)

num2id = {i.split('-')[1]: i for i in inv}
pays = {}
skipped = []
with open(os.path.join(base, 'backoffice/bank_statement_june.csv'), encoding='utf-8') as f:
    for row in csv.DictReader(f):
        memo = row['memo']
        ids = [num2id[n] for n in re.findall(r'10\d{2}', memo) if n in num2id]
        if len(ids) == 1:
            pays.setdefault(ids[0], []).append(round(float(row['amount']), 2))
        else:
            skipped.append((row['date'], memo, row['amount']))

unpaid = sorted(i for i in inv if i not in pays)
duplicated = sorted(i for i, ps in pays.items() if len(ps) > 1)
mismatched = [
    {'id': i, 'invoiced': inv[i], 'paid': ps[0]}
    for i, ps in sorted(pays.items())
    if len(ps) == 1 and ps[0] != inv[i]
]

result = {'unpaid': unpaid, 'duplicated': duplicated, 'mismatched': mismatched}
with open(os.path.join(base, 'result.json'), 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2)
    f.write('\n')

print('paid invoices:', len(pays), 'of', len(inv))
print('skipped rows:', skipped)
print(json.dumps(result, indent=2))
