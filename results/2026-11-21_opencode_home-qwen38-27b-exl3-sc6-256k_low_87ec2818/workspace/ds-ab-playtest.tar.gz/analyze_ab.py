import csv, math, json, collections

path = r"telemetry\playtest_ab.csv"
raw_variants = collections.Counter()
rows = []
with open(path, newline="", encoding="utf-8-sig") as f:
    for row in csv.DictReader(f):
        sid = row["session_id"].strip()
        var = row["variant"].strip().lower()
        comp = row["completed_tutorial"].strip()
        raw_variants[row["variant"]] += 1
        rows.append((sid, var, comp, row["match_minutes"]))

print("raw variant spellings:", dict(raw_variants))

seen = {}
conflicts = []
for sid, var, comp, mins in rows:
    if sid in seen:
        if seen[sid] != (var, comp):
            conflicts.append((sid, seen[sid], (var, comp)))
    else:
        seen[sid] = (var, comp)

sessions = list(seen.items())
na_rows = len(rows)
n = len(sessions)
print(f"rows={na_rows} unique_sessions={n} dup_rows={na_rows-n} conflicting_dups={len(conflicts)}")
for c in conflicts[:10]:
    print("conflict:", c)

def stats(v):
    sub = [c for _, (vv, c) in sessions if vv == v]
    k = sum(int(c) for c in sub)
    return len(sub), k, k / len(sub)

na, ka, pa = stats("a")
nb, kb, pb = stats("b")
print(f"A: n={na} completions={ka} rate={pa:.6f}")
print(f"B: n={nb} completions={kb} rate={pb:.6f}")

# pooled two-proportion z-test, one-sided H1: B > A
p_pool = (ka + kb) / (na + nb)
se = math.sqrt(p_pool * (1 - p_pool) * (1 / na + 1 / nb))
z = (pb - pa) / se
def ncdf(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))
p_one = 1 - ncdf(z)
p_two = 2 * (1 - ncdf(abs(z)))
print(f"z={z:.4f} p_one_sided={p_one:.6f} p_two_sided={p_two:.6f}")

# unweighted SE check (same conclusion expected)
se2 = math.sqrt(pa * (1 - pa) / na + pb * (1 - pb) / nb)
z2 = (pb - pa) / se2
p_two_u = 2 * (1 - ncdf(abs(z2)))
print(f"unpooled z={z2:.4f} p_two_sided={p_two_u:.6f}")

result = {
    "ship_b": p_one < 0.05 and pb > pa,
    "sessions_a": na,
    "sessions_b": nb,
    "completion_rate_a": round(pa, 4),
    "completion_rate_b": round(pb, 4),
    "p_value": round(p_one, 6),
}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result))
