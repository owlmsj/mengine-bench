from PIL import Image, ImageDraw, ImageFont

img = Image.new("RGB", (1200, 675), (11, 42, 62))
d = ImageDraw.Draw(img)

# simple harbor-ish background: water band + sky
d.rectangle((0, 0, 1200, 420), fill=(34, 68, 96))
d.rectangle((0, 420, 1200, 675), fill=(18, 48, 70))
# sun
d.ellipse((950, 80, 1110, 240), fill=(255, 214, 102))
# boats
for x in (180, 480, 780):
    d.polygon([(x, 470), (x + 160, 470), (x + 120, 530), (x + 40, 530)], fill=(232, 228, 214))
    d.polygon([(x + 80, 380), (x + 80, 470), (x + 140, 470)], fill=(200, 196, 182))

font_paths = [
    r"C:\Windows\Fonts\arialbd.ttf",
    r"C:\Windows\Fonts\segoeuib.ttf",
    r"C:\Windows\Fonts\calibrib.ttf",
    r"C:\Windows\Fonts\verdanab.ttf",
]
font = None
for fp in font_paths:
    try:
        font = ImageFont.truetype(fp, 110)
        break
    except Exception:
        pass
if font is None:
    font = ImageFont.load_default()

text = "Harbor Day 2026"
bbox = d.textbbox((0, 0), text, font=font)
w = bbox[2] - bbox[0]
h = bbox[3] - bbox[1]
x = (1200 - w) / 2
y = (675 - h) / 2 - bbox[1]
# shadow then text for legibility
d.text((x + 4, y + 4), text, fill=(0, 0, 0), font=font)
d.text((x, y), text, fill=(255, 255, 255), font=font)

img.save("cover.png", "PNG")
print("saved", img.size, img.format)
