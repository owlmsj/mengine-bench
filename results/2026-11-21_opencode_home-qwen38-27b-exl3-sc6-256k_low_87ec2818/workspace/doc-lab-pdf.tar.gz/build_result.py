# -*- coding: utf-8 -*-
# Builds result.json from the two lab reports.
# Alfa (first report, 10/02/2026) units: mg/dL, mg/dL, mg/dL, %
# Beta (18/08/2026) units: mmol/L, mmol/L, umol/L, mmol/mol -> converted to Alfa units.

import json

# Conversion factors (standard laboratory conversions)
MGDL_PER_MMOL_GLUCOSE = 18.015588      # 1 mmol/L glucose = 18.0156 mg/dL
MGDL_PER_MMOL_CHOL = 38.6665           # 1 mmol/L cholesterol = 38.6665 mg/dL
MGDL_PER_UMOL_CREAT = 1.0 / 88.42      # 1 umol/L creatinine = 1/88.42 mg/dL
HBA1C_PCT_PER_MMOL = lambda mmol: mmol * 0.0915 + 2.153  # IFCC mmol/mol -> NGSP %

glucose = round(6.1 * MGDL_PER_MMOL_GLUCOSE, 1)      # Beta -> mg/dL
ldl = round(3.70 * MGDL_PER_MMOL_CHOL, 1)            # Beta -> mg/dL
creat = round(76.0 * MGDL_PER_UMOL_CREAT, 2)         # Beta -> mg/dL
hba1c = round(HBA1C_PCT_PER_MMOL(37.0), 2)           # Beta -> %

history = {
    "GLICOSE EM JEJUM": {"2026-02-10": 92.0, "2026-08-18": glucose},
    "COLESTEROL LDL": {"2026-02-10": 118.0, "2026-08-18": ldl},
    "CREATININA": {"2026-02-10": 0.95, "2026-08-18": creat},
    "HEMOGLOBINA GLICADA (HbA1c)": {"2026-02-10": 5.4, "2026-08-18": hba1c},
}

# First report's reference ranges:
#  GLICOSE EM JEJUM: 70-99 mg/dL
#  COLESTEROL LDL: < 130 mg/dL
#  CREATININA: 0.70-1.30 mg/dL
#  HbA1c: 4.0-5.6 %

worse = []
# glucose: 92 -> glucose, up is bad, range 70-99
if glucose > 92 and glucose > 99:
    worse.append("GLICOSE EM JEJUM")
# LDL: 118 -> ldl, up is bad, desirable < 130
if ldl > 118 and ldl >= 130:
    worse.append("COLESTEROL LDL")
# creatinine: 0.95 -> creat, up is bad, range 0.70-1.30
if creat > 0.95 and not (0.70 <= creat <= 1.30):
    worse.append("CREATININA")
# HbA1c: 5.4 -> hba1c, up is bad, range 4.0-5.6
if hba1c > 5.4 and not (4.0 <= hba1c <= 5.6):
    worse.append("HEMOGLOBINA GLICADA (HbA1c)")

result = {"history": history, "worse": worse}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
    f.write("\n")

print(json.dumps(result, ensure_ascii=False, indent=2))
