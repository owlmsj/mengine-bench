import csv, json, math

path = r"<WORKSPACE>\telemetry\playtest_ab.csv"

sessions = {}
dupes = 0
bad_variant = 0
with open(path, newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        sid = row["session_id"].strip()
        v = row["variant"].strip().lower()
        if v not in ("a", "b"):
            bad_variant += 1
            continue
        comp = int(row["completed_tutorial"])
        if sid in sessions:
            dupes += 1
            # verify consistency of the resend
            prev = sessions[sid]
            if prev != (v, comp):
                print("INCONSISTENT DUPE:", sid, prev, (v, comp))
            continue
        sessions[sid] = (v, comp)

a_n = a_c = b_n = b_c = 0
for v, comp in sessions.values():
    if v == "a":
        a_n += 1; a_c += comp
    else:
        b_n += 1; b_c += comp

p_a = a_c / a_n
p_b = b_c / b_n
p_pool = (a_c + b_c) / (a_n + b_n)
se = math.sqrt(p_pool * (1 - p_pool) * (1 / a_n + 1 / b_n))
z = (p_b - p_a) / se
# two-sided p-value
p_value = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))

print(f"dupes_dropped={dupes} bad_variant={bad_variant}")
print(f"sessions_a={a_n} completed_a={a_c} rate_a={p_a:.6f}")
print(f"sessions_b={b_n} completed_b={b_c} rate_b={p_b:.6f}")
print(f"z={z:.6f} p_value={p_value:.6g}")
print(f"significant_at_5%={p_value < 0.05}")

result = {
    "ship_b": p_b > p_a and p_value < 0.05,
    "sessions_a": a_n,
    "sessions_b": b_n,
    "completion_rate_a": round(p_a, 6),
    "completion_rate_b": round(p_b, 6),
    "p_value": round(p_value, 6),
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))