import re, io

pat = open("regex.txt", encoding="utf-8").read().strip()
log = open("server.log", encoding="utf-8").read()
print("sample:", re.findall(pat, log, re.MULTILINE))

cases = [
    # (line, expected)
    ("2026-04-02 INFO x 10.12.0.7 build 2026-04-01", ["2026-04-01"]),
    ("2026-04-02 INFO no address here 2026-04-03", []),
    ("2026-04-02 WARN peer 192.168.40.3 retry 2026-04-02 to 2026-04-05", ["2026-04-05"]),
    ("2026-04-02 ERROR upstream 172.20.1.14 refused", []),
    # address invalid: leading zero
    ("2026-04-02 INFO 010.1.1.1 date 2026-04-09", []),
    # address invalid: 256
    ("2026-04-02 INFO 256.1.1.1 date 2026-04-09", []),
    # address invalid: 300
    ("2026-04-02 INFO 300.1.1.1 date 2026-04-09", []),
    # address valid 255.255.255.255
    ("2026-04-02 INFO 255.255.255.255 date 2026-04-09", ["2026-04-09"]),
    # address valid 0.0.0.0
    ("2026-04-02 INFO 0.0.0.0 date 2026-04-09", ["2026-04-09"]),
    # address with letter before
    ("2026-04-02 INFO a10.1.1.1 date 2026-04-09", []),
    # address with letter after
    ("2026-04-02 INFO 10.1.1.1a date 2026-04-09", []),
    # address with digit before
    ("2026-04-02 INFO 910.1.1.1 date 2026-04-09", []),
    # address with digit after (10.1.1.19 is a valid address, part 19)
    ("2026-04-02 INFO 10.1.1.19 date 2026-04-09", ["2026-04-09"]),
    # address with digit after (10.1.1.129 valid)
    ("2026-04-02 INFO 10.1.1.129 date 2026-04-09", ["2026-04-09"]),
    # address with dot after (10.1.1.1.2)
    ("2026-04-02 INFO 10.1.1.1.2 date 2026-04-09", []),
    # address with dot before
    ("2026-04-02 INFO .10.1.1.1 date 2026-04-09", []),
    # date with letter before
    ("2026-04-02 INFO 10.1.1.1 date a2026-04-09", []),
    # date with letter after
    ("2026-04-02 INFO 10.1.1.1 date 2026-04-09x", []),
    # date with digit before
    ("2026-04-02 INFO 10.1.1.1 date 92026-04-09", []),
    # date with digit after
    ("2026-04-02 INFO 10.1.1.1 date 2026-04-099", []),
    # Feb 29 allowed in every year per brief
    ("2026-04-02 INFO 10.1.1.1 date 2026-02-29", ["2026-02-29"]),
    # Feb 29 in leap year -> valid
    ("2026-04-02 INFO 10.1.1.1 date 2024-02-29", ["2024-02-29"]),
    # Feb 30 invalid
    ("2026-04-02 INFO 10.1.1.1 date 2024-02-30", []),
    # Apr 31 invalid
    ("2026-04-02 INFO 10.1.1.1 date 2024-04-31", []),
    # Dec 31 valid
    ("2026-04-02 INFO 10.1.1.1 date 2024-12-31", ["2024-12-31"]),
    # month 13 invalid
    ("2026-04-02 INFO 10.1.1.1 date 2024-13-01", []),
    # day 00 invalid
    ("2026-04-02 INFO 10.1.1.1 date 2024-01-00", []),
    # multiple dates, last one wins
    ("2026-04-02 INFO 10.1.1.1 a 2024-01-01 b 2024-06-15 c 2024-12-31", ["2024-12-31"]),
    # address then date then address then date: last date on line
    ("2026-04-02 INFO 10.1.1.1 2024-01-01 10.2.2.2 2024-07-07", ["2024-07-07"]),
    # no date at all but has address
    ("2026-04-02 INFO 10.1.1.1 no date", []),
    # date at line end
    ("2026-04-02 INFO 10.1.1.1 date 2024-03-05", ["2024-03-05"]),
    # address at line end, no date
    ("2026-04-02 INFO 10.1.1.1", []),
    # 2026-02-29 valid (Feb 29 allowed in every year per brief)
    ("2026-04-02 INFO 10.1.1.1 2026-02-29", ["2026-02-29"]),
    # 2000-02-29 valid (leap)
    ("2026-04-02 INFO 10.1.1.1 2000-02-29", ["2000-02-29"]),
    # 1900-02-29 valid (Feb 29 allowed in every year per brief)
    ("2026-04-02 INFO 10.1.1.1 1900-02-29", ["1900-02-29"]),
    # 1996-02-29 valid
    ("2026-04-02 INFO 10.1.1.1 1996-02-29", ["1996-02-29"]),
    # year 2026-02-28 valid
    ("2026-04-02 INFO 10.1.1.1 2026-02-28", ["2026-02-28"]),
    # address part with 3 digits > 255
    ("2026-04-02 INFO 100.1.1.1 2024-01-01", ["2024-01-01"]),
    # address part 99 valid
    ("2026-04-02 INFO 99.1.1.1 2024-01-01", ["2024-01-01"]),
    # address part 09 invalid (leading zero)
    ("2026-04-02 INFO 09.1.1.1 2024-01-01", []),
    # address part 0 valid
    ("2026-04-02 INFO 0.1.1.1 2024-01-01", ["2024-01-01"]),
]

fails = 0
for line, expected in cases:
    got = re.findall(pat, line, re.MULTILINE)
    if got != expected:
        fails += 1
        print(f"FAIL: {line!r} expected {expected} got {got}")
print(f"{len(cases)-fails}/{len(cases)} passed")