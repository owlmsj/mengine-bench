import csv, re, json
from collections import defaultdict

base = r"<WORKSPACE>\backoffice"

invoices = {}
with open(base + r"\invoices.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = float(row["amount"])

payments = defaultdict(list)  # invoice id -> list of amounts
ignored = []
with open(base + r"\bank_statement_june.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        m = re.search(r"(?:inv|invoice)\s*-?(\d{4})", memo, re.IGNORECASE)
        if not m:
            ignored.append((row["date"], memo, row["amount"]))
            continue
        inv_id = "INV-" + m.group(1)
        if inv_id not in invoices:
            ignored.append((row["date"], memo, row["amount"]))
            continue
        payments[inv_id].append(float(row["amount"]))

unpaid = sorted(i for i in invoices if i not in payments)
duplicated = sorted(i for i, amts in payments.items() if len(amts) > 1)
mismatched = []
for i, amts in sorted(payments.items()):
    if len(amts) == 1 and amts[0] != invoices[i]:
        mismatched.append({"id": i, "invoiced": invoices[i], "paid": amts[0]})

print("ignored rows:")
for r in ignored:
    print("  ", r)
print("unpaid:", unpaid)
print("duplicated:", duplicated)
print("mismatched:", mismatched)

result = {
    "unpaid": unpaid,
    "duplicated": duplicated,
    "mismatched": [
        {"id": m["id"], "invoiced": m["invoiced"], "paid": m["paid"]} for m in mismatched
    ],
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print("written result.json")