import json, struct

b = open('prices.db','rb').read()

def varint(off):
    v = 0
    for i in range(9):
        byte = b[off+i]
        if i == 8:
            return (v << 8) | byte, off+9
        v = (v << 7) | (byte & 0x7f)
        if not byte & 0x80:
            return v, off+i+1

hdr = 0x0f3c
assert b[hdr] == 0x0d, hex(b[hdr])
ncells = struct.unpack('>H', b[hdr+3:hdr+5])[0]
ptrs = [struct.unpack('>H', b[hdr+8+i*2:hdr+10+i*2])[0] for i in range(ncells)]
print('ncells', ncells, 'ptrs', [hex(p) for p in ptrs])

rows = []
for p in ptrs:
    off = p
    payload, off = varint(off)
    rowid, off = varint(off)
    hdrsize, h = varint(off)
    end = off + hdrsize
    types = []
    while h < end:
        t, h = varint(h)
        types.append(t)
    vals = []
    d = end
    for t in types:
        if t == 0:
            vals.append(None)
        elif t in (1,2,3,4,5,6):
            n = {1:1,2:2,3:3,4:4,5:6,6:8}[t]
            vals.append(int.from_bytes(b[d:d+n],'big',signed=True)); d += n
        elif t == 7:
            vals.append(struct.unpack('>d', b[d:d+8])[0]); d += 8
        elif t >= 13 and t % 2 == 1:
            n = (t-13)//2
            vals.append(b[d:d+n].decode('utf-8','replace')); d += n
        else:
            n = (t-12)//2
            vals.append(b[d:d+n]); d += n
    rows.append((rowid, vals))
    print(rowid, vals)

out = [{'item': v[0], 'price': v[1]} for _, v in rows
       if len(v) >= 2 and isinstance(v[0], str) and isinstance(v[1], (int, float))]
json.dump(out, open('recovered.json','w'), indent=2)
print('wrote', len(out))