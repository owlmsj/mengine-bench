import json, datetime

ipca = {1985: 242.23, 1986: 79.66, 1987: 363.41, 1988: 980.21, 1989: 1972.91,
        1990: 1620.97, 1991: 472.70, 1992: 1119.10, 1993: 2477.15, 1994: 916.46, 1995: 22.41}

plans = [
    ("Cruzado",  "1986-02-28", "Bresser"),
    ("Bresser",  "1987-06-12", "Verao"),
    ("Verao",    "1989-01-15", "Collor I"),
    ("Collor I", "1990-03-15", "Collor II"),
    ("Collor II","1991-01-31", "Real"),
    ("Real",     "1994-07-01", None),
]
launch = {n: datetime.date.fromisoformat(d) for n, d, _ in plans}

def months_between(a, b):
    return (b.year - a.year) * 12 + (b.month - a.month)

out = []
for name, ds, nxt in plans:
    d = datetime.date.fromisoformat(ds)
    Y = d.year
    before = ipca[Y - 1]
    after = ipca[Y + 1]
    drop = max(0.0, min(1.0, 1 - after / before))
    if nxt is None:
        m = 60
    else:
        m = months_between(d, launch[nxt])
    dur = min(m, 60) / 60
    score = 0.7 * drop + 0.3 * dur
    out.append({"plan": name, "launch_date": ds, "ipca_before": before, "ipca_after": after,
                "months_lasted": m, "score": round(score, 4)})

out.sort(key=lambda r: -r["score"])
print(json.dumps(out, indent=1))
print("TOP3:", [r["plan"] for r in out[:3]])