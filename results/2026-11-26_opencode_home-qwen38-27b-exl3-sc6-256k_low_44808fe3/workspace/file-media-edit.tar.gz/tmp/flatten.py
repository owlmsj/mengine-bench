import pymupdf, shutil

ws = r"<WORKSPACE>"
doc = pymupdf.open(ws + r"\permit-form.pdf")
vals = {
    "organizer": "Tidewater Studio",
    "event_date": "2026-12-05",
    "location": "North Cove Lawn",
    "attendees": "about 40",
}
for p in doc:
    for w in p.widgets():
        if w.field_name in vals:
            w.field_value = vals[w.field_name]
            w.update()
    # stamp values onto page content
    for w in p.widgets():
        txt = w.field_value or ""
        if txt:
            rect = w.rect
            fs = min(rect.height * 0.65, 13)
            p.insert_textbox(rect, txt, fontsize=fs, fontname="helv")
doc.save(ws + r"\out\permit-filled.pdf", deflate=True, garbage=3)
doc.close()

# now remove all form fields
doc = pymupdf.open(ws + r"\out\permit-filled.pdf")
for p in doc:
    # collect then delete each widget
    ws_list = list(p.widgets())
    for w in ws_list:
        p.delete_widget(w) if hasattr(p, "delete_widget") else None
# fallback: clear AcroForm
xref = doc.pdf_catalog()
if xref:
    doc.xref_set_key(xref, "AcroForm", "null")
doc.save(ws + r"\out\permit-flat-tmp.pdf", deflate=True, garbage=4)
doc.close()
shutil.move(ws + r"\out\permit-flat-tmp.pdf", ws + r"\out\permit-filled.pdf")

chk = pymupdf.open(ws + r"\out\permit-filled.pdf")
print("widgets", sum(len(list(p.widgets())) for p in chk))
print(repr(chk[0].get_text()))