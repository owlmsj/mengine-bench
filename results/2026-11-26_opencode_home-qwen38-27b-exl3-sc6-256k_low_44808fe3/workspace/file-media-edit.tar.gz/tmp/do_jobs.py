from PIL import Image
import numpy as np
import pymupdf

import os
ws = r"<WORKSPACE>"
os.makedirs(ws + r"\out", exist_ok=True)

# --- Job 1: feed photo 1080x1350 (4:5), balloon fully inside ---
im = Image.open(ws + r"\launch.jpg").convert("RGB")
a = np.asarray(im).astype(int)
r, g, b = a[:, :, 0], a[:, :, 1], a[:, :, 2]
mask = (r > 150) & (g < 120) & (b > 150)
ys, xs = np.where(mask)
x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
print("balloon bbox", x0, y0, x1, y1)

W, H = 1080, 1350
# source crop: 4:5, must contain bbox
sw, sh = x1 - x0 + 1, y1 - y0 + 1
# crop size in source px: pick height = sh + margin, keep 4:5
# margin: 15% of balloon size each side
mx, my = int(sw * 0.25), int(sh * 0.25)
need_w, need_h = sw + 2 * mx, sh + 2 * my
# scale to 4:5
if need_w / need_h > W / H:
    cw, ch = need_w, int(need_w * H / W)
else:
    ch, cw = need_h, int(need_h * W / H)
cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
left = int(cx - cw / 2)
top = int(cy - ch / 2)
# clamp to image
left = max(0, min(left, im.width - cw))
top = max(0, min(top, im.height - ch))
crop = im.crop((left, top, left + cw, top + ch)).resize((W, H), Image.LANCZOS)
crop.save(ws + r"\out\feed-photo.jpg", quality=92)
print("crop", left, top, cw, ch, "-> saved feed-photo.jpg")

# verify balloon fully inside
a2 = np.asarray(crop).astype(int)
m2 = (a2[:, :, 0] > 150) & (a2[:, :, 1] < 120) & (a2[:, :, 2] > 150)
ys2, xs2 = np.where(m2)
print("in-crop magenta px", len(xs2), "bbox", xs2.min(), ys2.min(), xs2.max(), ys2.max())

# --- Job 2: fill permit form and flatten ---
doc = pymupdf.open(ws + r"\permit-form.pdf")
vals = {
    "organizer": "Tidewater Studio",
    "event_date": "2026-12-05",
    "location": "North Cove Lawn",
    "attendees": "about 40",
}
for p in doc:
    for w in p.widgets():
        if w.field_name in vals:
            w.field_value = vals[w.field_name]
            w.update()
doc.save(ws + r"\out\permit-filled.pdf", deflate=True, garbage=3)
doc.close()

# flatten: render each page to image and rebuild single-page PDF (no form fields)
doc2 = pymupdf.open(ws + r"\out\permit-filled.pdf")
flat = pymupdf.open()
for p in doc2:
    pix = p.get_pixmap(dpi=150)
    pg = flat.new_page(width=p.rect.width, height=p.rect.height)
    pg.insert_image(p.rect, pixmap=pix)
flat.save(ws + r"\out\permit-flat-tmp.pdf", deflate=True, garbage=4)
flat.close()
import shutil
shutil.move(ws + r"\out\permit-flat-tmp.pdf", ws + r"\out\permit-filled.pdf")

# verify no widgets remain
chk = pymupdf.open(ws + r"\out\permit-filled.pdf")
n = sum(len(list(p.widgets())) for p in chk)
print("remaining widgets", n)
print(chk[0].get_text())