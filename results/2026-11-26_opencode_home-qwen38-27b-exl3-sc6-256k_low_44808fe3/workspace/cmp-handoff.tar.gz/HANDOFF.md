# Handoff: local-9b at 128k context

Goal: measure local-9b Q5 at 128k context.

Done (scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024):
- Baseline Q5: 37.8 t/s, VRAM 7881 MiB — that is the WDDM ceiling; Shared Usage showed 1494 MiB spilled, so it does not count.
- Fix: `--no-mmproj-offload` + `-ub 512` removes the spill: 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k; discarded. Q4_K_M fits (7305 MiB, 40.4 t/s), fallback only.
- Recipe applied in scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

Open:
1. Review scratchpad temp file names (noted repeatedly, never done).
2. Evals README still cites check_vision.ps1, which no longer exists; update it.

Assumptions: Q5 is the required quant; 128k = 131072; the start_server.ps1/profile change is final.

Found: the spill came from the mmproj offload; disabling it plus -ub 512 fits in 7697 MiB at 38.0 t/s. Known because Shared Usage showed 1494 MiB spill before, gone after.