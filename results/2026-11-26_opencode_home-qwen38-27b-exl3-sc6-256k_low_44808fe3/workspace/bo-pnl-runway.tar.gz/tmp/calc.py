import csv, json
from collections import defaultdict

base = r"<WORKSPACE>\finance"

coa = {}
with open(base + r"\chart_of_accounts.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        coa[row["account"]] = row["pnl_line"]

months = ["2026-01","2026-02","2026-03","2026-04","2026-05","2026-06"]
sums = {m: defaultdict(float) for m in months}

with open(base + r"\ledger.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        d = row["date"]  # dd/mm/yyyy
        m = f"2026-{d[3:5]}"
        amt = float(row["amount"].replace(".", "").replace(",", "."))
        line = coa[row["account"]]
        sums[m][line] += amt

out = {"revenue": {}, "gross_margin_pct": {}, "ebitda": {}}
for m in months:
    s = sums[m]
    rev = s["revenue"]
    cogs = s["cogs"]
    gm = (rev + cogs) / rev * 100 if rev else 0.0  # cogs negative
    ebitda = rev + cogs + s["sales_marketing"] + s["rnd"] + s["ga"]
    out["revenue"][m] = round(rev, 2)
    out["gross_margin_pct"][m] = round(gm, 2)
    out["ebitda"][m] = round(ebitda, 2)

# burn: avg monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = [out["ebitda"][m] for m in ["2026-04","2026-05","2026-06"]]
burn = -sum(last3) / 3
cash = 1847350.40
runway = cash / burn
out["burn"] = round(burn, 2)
out["runway_months"] = round(runway, 2)

with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))