"""Helper for running batches of async jobs with bounded concurrency.

Usage:
    from run import run_tasks
    await run_tasks([make_job_a, make_job_b, ...], max_concurrent=4)

Each task is a zero-argument callable that returns an awaitable job.
At most max_concurrent jobs run at once. run_tasks returns when every
job is done. On Ctrl+C (KeyboardInterrupt) or asyncio.CancelledError,
all started jobs are cancelled and their cleanup (finally /
async with / try-except) code runs before run_tasks re-raises.

Assumptions (the brief leaves these open):
- A job that raises its own exception does not stop the other jobs;
  the first such exception is re-raised after all jobs have finished.
- run_tasks returns a list of results in task order; a job that raised
  contributes None at its position.
- max_concurrent < 1 is a programming error -> ValueError.
"""

import asyncio


async def run_tasks(tasks, max_concurrent):
    """Run zero-arg callables returning awaitables, bounded by max_concurrent.

    Args:
        tasks: iterable of zero-argument callables; each call returns an
            awaitable (coroutine, Task, or any awaitable job).
        max_concurrent: maximum number of jobs running at once (>= 1).

    Returns:
        A list of the jobs' results, in the order of `tasks`.

    Raises:
        ValueError: if max_concurrent < 1.
        The first job exception, if any, after all jobs have finished.
        KeyboardInterrupt / asyncio.CancelledError: re-raised after all
            started jobs have been cancelled and their cleanup has run.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent}")

    factories = list(tasks)
    semaphore = asyncio.Semaphore(max_concurrent)
    results = [None] * len(factories)
    first_error = None
    pending = set()

    async def _run(index, factory):
        nonlocal first_error
        async with semaphore:
            job = factory()
            task = job if isinstance(job, asyncio.Task) else asyncio.ensure_future(job)
            try:
                results[index] = await task
            except (KeyboardInterrupt, asyncio.CancelledError):
                raise
            except BaseException as exc:
                # Record the first job error; let the other jobs finish.
                if first_error is None:
                    first_error = exc

    try:
        for i, factory in enumerate(factories):
            pending.add(asyncio.ensure_future(_run(i, factory)))
        while pending:
            done, pending = await asyncio.wait(pending)
            # Pull exceptions out of done wrappers so they are not
            # reported as unhandled; _run already recorded them.
            for d in done:
                d.exception()
    except (KeyboardInterrupt, asyncio.CancelledError):
        for t in pending:
            t.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)
        raise
    finally:
        # Safety net: cancel anything still pending.
        for t in pending:
            t.cancel()
        if pending:
            await asyncio.gather(*pending, return_exceptions=True)

    if first_error is not None:
        raise first_error
    return results