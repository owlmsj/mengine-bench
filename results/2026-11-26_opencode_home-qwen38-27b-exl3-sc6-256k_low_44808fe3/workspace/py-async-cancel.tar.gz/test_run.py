import asyncio
import time
from run import run_tasks

# 1) Concurrency bound: 6 jobs, max 2, each 0.1s -> ~0.3s total, never >2 concurrent.
active = 0
peak = 0

def make_job(i):
    async def job():
        global active, peak
        active += 1
        peak = max(peak, active)
        await asyncio.sleep(0.1)
        active -= 1
        return i * 10
    return job

async def t1():
    global peak
    peak = 0
    t0 = time.monotonic()
    res = await run_tasks([make_job(i) for i in range(6)], 2)
    dt = time.monotonic() - t0
    assert res == [0, 10, 20, 30, 40, 50], res
    assert peak == 2, peak
    assert dt >= 0.29, dt
    print("t1 ok: results ordered, peak=2, dt=%.2f" % dt)

# 2) Cancel: job 0 sleeps long; cancel after 0.05s; cleanup must run.
cleanups = []

def make_cancel_job(i):
    async def job():
        try:
            await asyncio.sleep(10)
            return i
        finally:
            cleanups.append(i)
    return job

async def t2():
    async def main():
        await run_tasks([make_cancel_job(i) for i in range(4)], 4)
    task = asyncio.ensure_future(main())
    await asyncio.sleep(0.05)
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass
    await asyncio.sleep(0.05)
    assert sorted(cleanups) == [0, 1, 2, 3], cleanups
    print("t2 ok: all 4 cleanups ran after cancel:", sorted(cleanups))

# 3) max_concurrent=1 runs sequentially.
async def t3():
    order = []
    def mk(i):
        async def job():
            order.append(("start", i))
            await asyncio.sleep(0.01)
            order.append(("end", i))
        return job
    await run_tasks([mk(i) for i in range(3)], 1)
    assert order == [("start",0),("end",0),("start",1),("end",1),("start",2),("end",2)], order
    print("t3 ok: sequential")

# 4) ValueError on bad max_concurrent.
async def t4():
    try:
        await run_tasks([], 0)
        assert False
    except ValueError:
        pass
    print("t4 ok: ValueError")

# 5) A failing job does not stop siblings; first error re-raised at the end.
async def t5():
    ran = []
    def mk(i):
        async def job():
            await asyncio.sleep(0.01)
            ran.append(i)
            if i == 1:
                raise RuntimeError("boom")
            return i
        return job
    try:
        await run_tasks([mk(i) for i in range(3)], 3)
        assert False
    except RuntimeError as e:
        assert str(e) == "boom"
    assert sorted(ran) == [0, 1, 2], ran
    print("t5 ok: siblings finished, first error raised")

asyncio.run(t1())
asyncio.run(t2())
asyncio.run(t3())
asyncio.run(t4())
asyncio.run(t5())
print("ALL OK")