import sqlite3
c = sqlite3.connect('analytics.db')
for r in c.execute("select name, sql from sqlite_master where type='table'"):
    print(r[0])
    print(r[1])
    print('---')
for t in [r[0] for r in c.execute("select name from sqlite_master where type='table'")]:
    n = c.execute(f"select count(*) from {t}").fetchone()[0]
    print(t, 'rows:', n)
    for row in c.execute(f"select * from {t} limit 3"):
        print(row)