import sqlite3, json
c = sqlite3.connect('analytics.db')
steps = ['install', 'tutorial_complete', 'first_match', 'purchase']
# first valid occurrence per user per event
first = {}
for uid, name, ts in c.execute("select user_id, name, ts from events"):
    if name in steps:
        k = (uid, name)
        if k not in first or ts < first[k]:
            first[k] = ts
# users: platform, is_test
users = {uid: (plat, test) for uid, plat, test in c.execute("select user_id, platform, is_test from users")}
# events from unknown players (not in users) are excluded automatically since we iterate users
funnel = {}
for plat in sorted({p for p, t in users.values()}):
    counts = {}
    for i, s in enumerate(steps):
        prev = steps[i-1] if i > 0 else None
        n = 0
        for uid, (p, test) in users.items():
            if p != plat or test:
                continue
            ts = first.get((uid, s))
            if ts is None:
                continue
            if prev is not None:
                pts = first.get((uid, prev))
                if pts is None or ts < pts:
                    continue
            n += 1
        counts[s] = n
    funnel[plat] = counts
# biggest drop: step with lowest conversion (players over previous step)
biggest = {}
for plat, counts in funnel.items():
    best_step, best_conv = None, None
    for i, s in enumerate(steps):
        if i == 0:
            continue
        prev = steps[i-1]
        if counts[prev] == 0:
            conv = 0.0
        else:
            conv = counts[s] / counts[prev]
        if best_conv is None or conv < best_conv:
            best_conv, best_step = conv, s
    biggest[plat] = best_step
result = {'funnel': funnel, 'biggest_drop': biggest}
with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))