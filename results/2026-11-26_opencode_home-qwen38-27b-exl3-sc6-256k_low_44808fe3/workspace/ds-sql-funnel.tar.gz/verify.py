import sqlite3
c = sqlite3.connect('analytics.db')
# independent check: per platform, count users with first valid occurrence chain
steps = ['install', 'tutorial_complete', 'first_match', 'purchase']
for plat in ('pc', 'steamdeck'):
    print(plat)
    for i, s in enumerate(steps):
        prev = steps[i-1] if i else None
        q = f"""
        select count(distinct u.user_id) from users u
        where u.platform='{plat}' and u.is_test=0
          and exists(select 1 from events e where e.user_id=u.user_id and e.name='{s}')
        """
        if prev:
            q += f""" and exists(select 1 from events e2 where e2.user_id=u.user_id and e2.name='{prev}')
               and (select min(ts) from events e3 where e3.user_id=u.user_id and e3.name='{s}')
                 >= (select min(ts) from events e4 where e4.user_id=u.user_id and e4.name='{prev}')
        """
        print(' ', s, c.execute(q).fetchone()[0])
# sanity: total users, test users, unknown-player events
print('total users', c.execute("select count(*) from users").fetchone()[0])
print('test users', c.execute("select count(*) from users where is_test=1").fetchone()[0])
print('events w/ unknown player', c.execute("select count(*) from events e where not exists(select 1 from users u where u.user_id=e.user_id)").fetchone()[0])
print('distinct event names', [r[0] for r in c.execute("select distinct name from events")])