import csv

# Memory requirements (GB = 10^9 bytes)
weights_gb = 70e9 / 1e9  # 70B params, FP8 = 1 byte/param -> 70 GB
kv_per_token = 327_680   # bytes
ctx = 32_768
seqs = 4
kv_cache_gb = kv_per_token * ctx * seqs / 1e9
overhead_gb = 8.0
total_gb = weights_gb + kv_cache_gb + overhead_gb

print(f"weights_gb={weights_gb}")
print(f"kv_cache_gb={kv_cache_gb}")
print(f"total_gb={total_gb}")

allowed_regions = {"us-east", "us-central", "eu-west"}
cap = 4.0

rows = list(csv.DictReader(open(r"<WORKSPACE>\offers.csv")))
best = None
for r in rows:
    ok = True
    reasons = []
    if r["in_stock"] != "yes":
        ok = False; reasons.append("out of stock")
    if r["region"] not in allowed_regions:
        ok = False; reasons.append("region not allowed")
    price = float(r["usd_per_hour"])
    if price > cap:
        ok = False; reasons.append("over hourly cap")
    vram = int(r["gpu_count"]) * float(r["vram_gb_per_gpu"])
    if vram < total_gb:
        ok = False; reasons.append(f"vram {vram} < total {total_gb}")
    status = "OK " if ok else "NO " + "; ".join(reasons)
    print(f"{r['offer_id']}: {status} (vram={vram}, price={price})")
    if ok and (best is None or price < best[1]):
        best = (r["offer_id"], price)

print("BEST:", best)
if best:
    print(f"usd_per_month={best[1]*730}")