import csv, re, json

base = r"<WORKSPACE>\backoffice"

invoices = {}
with open(base + r"\invoices.csv", newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = float(row["amount"])

payments = []  # (invoice_id, amount)
with open(base + r"\bank_statement_june.csv", newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        m = re.search(r"(10\d{2})", memo)
        if not m:
            continue  # fees, interest, unidentified
        inv_id = "INV-" + m.group(1)
        if inv_id not in invoices:
            continue  # no matching invoice (e.g. unidentified PIX)
        payments.append((inv_id, float(row["amount"])))

paid = {}
for inv_id, amt in payments:
    paid.setdefault(inv_id, []).append(amt)

unpaid = sorted(i for i in invoices if i not in paid)
duplicated = sorted(i for i in paid if len(paid[i]) > 1)
mismatched = []
for i in paid:
    if i in duplicated:
        continue
    amt = paid[i][0]
    if amt != invoices[i]:
        mismatched.append({"id": i, "invoiced": invoices[i], "paid": amt})
mismatched.sort(key=lambda x: x["id"])

result = {
    "unpaid": unpaid,
    "duplicated": duplicated,
    "mismatched": mismatched,
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
print(json.dumps(result, indent=2, ensure_ascii=False))