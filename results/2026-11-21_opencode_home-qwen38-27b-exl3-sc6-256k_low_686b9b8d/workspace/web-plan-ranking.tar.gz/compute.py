# IPCA annual (IBGE), %
ipca = {
    1985: 242.23, 1986: 79.66, 1987: 363.41, 1988: 980.21,
    1989: 1972.91, 1990: 1620.97, 1991: 472.70, 1992: 1119.10,
    1993: 2477.15, 1994: 916.46, 1995: 22.41, 1996: 9.56,
}

# plan: (launch y-m-d, next plan launch y-m-d or None)
plans = [
    ("Cruzado",   "1986-02-28", "1987-06-12"),
    ("Bresser",   "1987-06-12", "1989-01-15"),
    ("Verao",     "1989-01-15", "1990-03-16"),
    ("Collor I",  "1990-03-16", "1991-01-31"),
    ("Collor II", "1991-01-31", "1994-07-01"),
    ("Real",      "1994-07-01", None),
]

import datetime
def months(a, b):
    ya, ma, da = map(int, a.split("-"))
    yb, mb, db = map(int, b.split("-"))
    return (yb - ya) * 12 + (mb - ma) + (1 if db >= da else 0)

for name, launch, nxt in plans:
    y = int(launch[:4])
    before, after = ipca[y-1], ipca[y+1]
    drop = max(0.0, min(1.0, 1 - after/before))
    m = 60 if nxt is None else months(launch, nxt)
    dur = min(m, 60)/60
    score = 0.7*drop + 0.3*dur
    print(f"{name:10s} before={before:9.2f} after={after:9.2f} drop={drop:.4f} months={m:3d} dur={dur:.4f} score={score:.4f}")