import csv, json

# Memory requirements (GB = 10^9 bytes)
weights_gb = 70e9 * 1 / 1e9  # 70B params, 1 byte each (FP8) = 70 GB
kv_cache_gb = 327680 * 32768 * 4 / 1e9  # per token * context * 4 sequences
overhead_gb = 8.0
total_gb = weights_gb + kv_cache_gb + overhead_gb
print(f"weights={weights_gb} kv={kv_cache_gb} total={total_gb}")

CAP = 4.0
REGIONS = {"us-east", "us-central", "eu-west"}

rows = list(csv.DictReader(open("offers.csv")))
ok = []
for r in rows:
    reasons = []
    if r["in_stock"] != "yes":
        reasons.append("out of stock")
    if r["region"] not in REGIONS:
        reasons.append(f"region {r['region']} not allowed")
    price = float(r["usd_per_hour"])
    if price > CAP:
        reasons.append(f"price {price} > cap {CAP}")
    vram = int(r["gpu_count"]) * float(r["vram_gb_per_gpu"])
    if vram < total_gb:
        reasons.append(f"vram {vram} < {total_gb}")
    if reasons:
        print(f"reject {r['offer_id']}: {', '.join(reasons)}")
    else:
        ok.append((price, r["offer_id"], vram, price * 730))

ok.sort()
print("eligible:", ok)
best_price, best_id, best_vram, best_month = ok[0]
result = {
    "weights_gb": weights_gb,
    "kv_cache_gb": kv_cache_gb,
    "total_gb": total_gb,
    "offer_id": best_id,
    "usd_per_hour": best_price,
    "usd_per_month": best_month,
}
json.dump(result, open("result.json", "w"), indent=2)
print(json.dumps(result, indent=2))