import csv, statistics

rows = []
with open(r"capture/presentmon.csv") as f:
    for r in csv.DictReader(f):
        rows.append((float(r["TimeInSeconds"]), float(r["MsBetweenPresents"])))

ms = [m for _, m in rows]
n = len(ms)
t_end = rows[-1][0]
avg_fps = 1000.0 / (sum(ms) / n)
ms_sorted = sorted(ms)
p99 = ms_sorted[int(0.99 * (n - 1))]
low1 = 1000.0 / p99
print(f"frames={n} span={t_end:.3f}s")
print(f"avg_ms={sum(ms)/n:.3f} avg_fps={avg_fps:.2f}")
print(f"p99_ms={p99:.3f} low1pct_fps={low1:.2f}")

# hitches: frames slower than 3x median
med = statistics.median(ms)
hitches = [(t, m) for t, m in rows if m > 3 * med]
print(f"median_ms={med:.3f} hitches(>3x med)={len(hitches)}")
for t, m in hitches:
    print(f"  t={t:.3f}s ms={m:.2f}")

# sensor: L1 seconds and DPC spikes
with open(r"capture/sensors.csv") as f:
    sens = list(csv.DictReader(f))
l1 = [int(r["time_s"]) for r in sens if r["gpu_pcie_link_state"] == "L1"]
dpc = [(int(r["time_s"]), int(r["dpc_latency_us"]), r["top_cpu_process"]) for r in sens if int(r["dpc_latency_us"]) > 200]
print("L1 seconds:", l1)
print("dpc>200us:", dpc)