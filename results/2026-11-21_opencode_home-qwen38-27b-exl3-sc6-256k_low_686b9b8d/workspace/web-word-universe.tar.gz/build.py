import re, json, os, html, unicodedata
from urllib.parse import unquote
from collections import Counter

SITE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "site")
files = [f for f in os.listdir(SITE) if f.endswith(".html")]

def norm(s):
    s = unicodedata.normalize("NFC", s)
    return s.strip().lower()

# preload all files, build word_of first, then parse links
pages = {}
for f in files:
    pages[f] = open(os.path.join(SITE, f), encoding="utf-8").read()

word_of = {}
for f, raw in pages.items():
    m = re.search(r"<h1>(.*?)</h1>", raw)
    if m:
        word_of[f] = norm(html.unescape(m.group(1)).strip())

data = {}
dangling = []
for f, raw in pages.items():
    if f not in word_of:
        continue  # index.html etc.
    key = word_of[f]
    word = html.unescape(re.search(r"<h1>(.*?)</h1>", raw).group(1)).strip()
    tema = re.search(r'class="tema">Tema:\s*(.*?)</p>', raw)
    tema = tema.group(1).strip() if tema else None
    links = []
    for sec in re.findall(r'<section id="(sinonimos|analogas)">.*?<ul>(.*?)</ul>', raw, re.S):
        for a in re.findall(r'<a href="([^"]+)">([^<]*)</a>', sec[1]):
            href = unquote(html.unescape(a[0]))
            if href in word_of:
                links.append(word_of[href])
            else:
                dangling.append((word, a[1], href))
    data[key] = {"word": word, "tema": tema, "links": sorted(set(links))}

# dedupe self-links
for k in data:
    data[k]["links"] = [l for l in data[k]["links"] if l != k]

words = len(data)
pairs = set()
deg = Counter()
for k, v in data.items():
    for l in v["links"]:
        a, b = sorted((k, l))
        pairs.add((a, b))
        deg[k] += 1
most = deg.most_common()
top = most[0][0] if most else None
print("words:", words)
print("pairs:", len(pairs))
print("most_connected:", top, most[:5])
print("dangling:", dangling)

# words.json: word -> linked words
words_json = {k: data[k]["links"] for k in sorted(data)}
with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "words.json"), "w", encoding="utf-8") as fh:
    json.dump(words_json, fh, ensure_ascii=False, indent=1)

result = {"words": words, "relations": len(pairs), "most_connected": top}
with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "result.json"), "w", encoding="utf-8") as fh:
    json.dump(result, fh, ensure_ascii=False, indent=1)

# extra payload for the page: display word + tema
extra = {k: {"word": data[k]["word"], "tema": data[k]["tema"]} for k in data}
with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "meta.json"), "w", encoding="utf-8") as fh:
    json.dump(extra, fh, ensure_ascii=False, indent=1)