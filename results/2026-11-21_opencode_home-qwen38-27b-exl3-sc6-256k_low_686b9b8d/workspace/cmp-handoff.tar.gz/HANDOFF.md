# Handoff: local-9b Q5 @ 128k

Goal: run local-9b Q5 with 128k context, measured.

Done (measured):
- Baseline `scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`: 37.8 t/s, VRAM 7881 MiB.
- 7881 MiB is the WDDM ceiling; Shared Usage counter showed 1494 MiB spilled to RAM.
- Fix `--no-mmproj-offload -ub 512`: spill gone, VRAM 7697 MiB, decode 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k; discarded. Q4_K_M fits (7305 MiB, 40.4 t/s), fallback only.
- Recipe applied: `scripts/start_server.ps1:165` (local9 block), `profiles/local/local-9b.json`.

Open:
1. Review scratchpad temp-file names (noted, never done).
2. Evals README still cites `check_vision.ps1`, which no longer exists.

Assumptions: 7881 MiB is WDDM-reported and includes the spill; "median of 3" = three same runs.

Found: working config is local-9b Q5 with `--no-mmproj-offload -ub 512` at 128k. How I know: spill counter went to zero, VRAM below ceiling (7697 < 7881 MiB), decode unchanged (38.0 vs 37.8 t/s).