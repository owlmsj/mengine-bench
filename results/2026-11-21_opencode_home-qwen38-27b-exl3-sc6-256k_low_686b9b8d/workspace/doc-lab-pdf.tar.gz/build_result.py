import json

# First report (Alfa, 10/02/2026) defines units and reference ranges:
# GLICOSE: mg/dL (70-99); LDL: mg/dL (<130); CREATININA: mg/dL (0.70-1.30); HbA1c: % (4.0-5.6)
# Conversions (standard factors):
# glucose: mmol/L * 18.016 mg/dL per mmol/L
# LDL: mmol/L * 38.67 mg/dL per mmol/L
# creatinine: umol/L / 88.42 umol/L per mg/dL
# HbA1c: mmol/mol -> %: (mmol/mol + 23.5) * 0.099
g2 = round(6.1 * 18.016, 1)
ldl2 = round(3.70 * 38.67, 1)
cr2 = round(76 / 88.42, 2)
h2 = round((37 + 23.5) * 0.099, 1)

history = {
    "glicose": {"2026-02-10": 92, "2026-08-18": g2},
    "colesterol_ldl": {"2026-02-10": 118, "2026-08-18": ldl2},
    "creatinina": {"2026-02-10": 0.95, "2026-08-18": cr2},
    "hemoglobina_glicada": {"2026-02-10": 5.4, "2026-08-18": h2},
}

# First report reference ranges (in first report units):
ranges = {
    "glicose": (70, 99),
    "colesterol_ldl": (None, 130),  # desirable < 130
    "creatinina": (0.70, 1.30),
    "hemoglobina_glicada": (4.0, 5.6),
}

worse = []
for m, d in history.items():
    first, second = d["2026-02-10"], d["2026-08-18"]
    lo, hi = ranges[m]
    outside = (lo is not None and second < lo) or (hi is not None and second > hi)
    if second > first and outside:
        worse.append(m)

result = {"history": history, "worse": worse}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
print(json.dumps(result, ensure_ascii=False, indent=2))