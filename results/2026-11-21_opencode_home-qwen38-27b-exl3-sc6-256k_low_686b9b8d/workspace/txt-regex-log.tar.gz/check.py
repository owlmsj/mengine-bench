import re
pat = open('regex.txt').read().strip()
log = open('server.log').read()
print(re.findall(pat, log, re.MULTILINE))