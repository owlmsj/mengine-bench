import struct, json

data = open("prices.db", "rb").read()
print("file size:", len(data))

# page 1 header
magic = data[:16]
print("magic:", magic)
# header is corrupted (page size field invalid); file is 4096 bytes, try 2048
page_size = 2048
print("page size:", page_size)
n_pages = struct.unpack(">I", data[28:32])[0]
print("db size pages (header):", n_pages)
text_enc = data[56]
print("text encoding:", text_enc)
# schema cookie etc
print("schema cookie:", struct.unpack(">I", data[40:44])[0])

def varint(buf, off):
    v = 0
    for i in range(9):
        b = buf[off + i]
        if i == 8:
            v = (v << 8) | b
            return v, off + 9
        v = (v << 7) | (b & 0x7F)
        if not (b & 0x80):
            return v, off + i + 1
    return v, off + 9

def serial_len(t):
    if t < 12:
        return t - 6
    if t < 0x14:
        return (t - 12) * 2
    if t < 0x1A:
        return (t - 18) * 3
    if t < 0x20:
        return (t - 24) * 4
    if t == 0x20:
        return 8
    if t == 0x21:
        return 12
    if t == 0x22:
        return 16
    if t == 0x23:
        return 24
    if t == 0x24:
        return 4294967296
    return 0

def serial_value(t, buf, off):
    n = serial_len(t)
    raw = buf[off:off + n]
    if t == 0:
        return None
    if t == 1:
        return int.from_bytes(raw, "big", signed=True)
    if t in (2, 3, 4, 5, 6, 7):
        return int.from_bytes(raw, "big", signed=True)
    if t == 8:
        return struct.unpack(">q", raw)[0]
    if t == 9:
        return struct.unpack(">d", raw)[0]
    if t == 10:
        return 0
    if t == 11:
        return 1
    return raw.decode("utf-8", errors="replace")

rows = []
# scan each page for leaf table b-tree pages (type 13)
for p in range(len(data) // page_size):
    off = p * page_size
    if off + 8 > len(data):
        break
    ptype = data[off]
    if ptype not in (13, 5):
        print(f"page {p+1}: type {ptype}")
        continue
    first_free = struct.unpack(">H", data[off+1:off+3])[0]
    ncells = struct.unpack(">H", data[off+3:off+5])[0]
    print(f"page {p+1}: type {ptype}, cells {ncells}, first_free {first_free}")
    cellptr_off = off + 8 if ptype == 13 else off + 12
    for c in range(ncells):
        cp = struct.unpack(">H", data[cellptr_off + 2*c: cellptr_off + 2*c + 2])[0]
        coff = off + cp
        try:
            payload, o = varint(data, coff)
            rowid, o2 = varint(data, o)
            hdr, o3 = varint(data, o2)
            hdr_end = o3 + hdr
            types = []
            ho = o3
            while ho < hdr_end:
                t, ho = varint(data, ho)
                types.append(t)
            body = hdr_end
            vals = []
            for t in types:
                vals.append(serial_value(t, data, body))
                body += serial_len(t)
            rows.append((p + 1, rowid, vals))
        except Exception as e:
            print(f"  cell {c} at {coff}: error {e}")

print("rows:", rows)
out = []
for p, rowid, vals in rows:
    # find text and numeric
    texts = [v for v in vals if isinstance(v, str)]
    nums = [v for v in vals if isinstance(v, (int, float))]
    if texts and nums:
        out.append({"item": texts[0], "price": nums[0]})
    else:
        print("unparsed:", p, rowid, vals)
json.dump(out, open("recovered.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print(json.dumps(out, ensure_ascii=False))