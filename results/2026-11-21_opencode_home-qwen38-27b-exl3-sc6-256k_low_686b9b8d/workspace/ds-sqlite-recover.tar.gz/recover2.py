import struct, json, re

data = open("prices.db", "rb").read()

def varint(buf, off):
    v = 0
    for i in range(9):
        b = buf[off + i]
        if i == 8:
            v = (v << 8) | b
            return v, off + 9
        v = (v << 7) | (b & 0x7F)
        if not (b & 0x80):
            return v, off + i + 1
    return v, off + 9

def serial_len(t):
    if t < 12:
        return t - 6
    if t < 0x14:
        return (t - 12) * 2
    if t < 0x1A:
        return (t - 18) * 3
    if t < 0x20:
        return (t - 24) * 4
    if t == 0x20:
        return 8
    if t == 0x21:
        return 12
    if t == 0x22:
        return 16
    if t == 0x23:
        return 24
    if t == 0x24:
        return 4294967296
    return 0

def serial_value(t, buf, off):
    n = serial_len(t)
    raw = buf[off:off + n]
    if t == 0:
        return None
    if 1 <= t <= 6:
        return int.from_bytes(raw, "big", signed=True)
    if t == 7:
        return int.from_bytes(raw, "big", signed=True)
    if t == 8:
        return struct.unpack(">q", raw)[0]
    if t == 9:
        return struct.unpack(">d", raw)[0]
    if t == 10:
        return 0
    if t == 11:
        return 1
    return raw.decode("utf-8", errors="replace")

# scan every offset for a plausible record: varint rowid (small), varint hdr,
# then exactly 2 serial types: text (item) and integer (price)
cands = []
for off in range(len(data) - 4):
    try:
        rowid, o = varint(data, off)
        if rowid < 1 or rowid > 100000:
            continue
        hdr, o2 = varint(data, o)
        if hdr < 1 or hdr > 64:
            continue
        # read 2 serial types
        types = []
        ho = o2
        ok = True
        for _ in range(2):
            t, ho = varint(data, ho)
            types.append(t)
        if ho - o2 != hdr:
            continue
        t1, t2 = types
        # t1 must be text (>=13), t2 must be integer (1..9)
        if t1 < 13 or t1 >= 0x20:
            continue
        if t2 < 1 or t2 > 9:
            continue
        body = ho
        n1 = serial_len(t1)
        n2 = serial_len(t2)
        if body + n1 + n2 > len(data):
            continue
        item = serial_value(t1, data, body)
        price = serial_value(t2, data, body + n1)
        # item must be printable ascii text, price a sane number
        if not isinstance(item, str) or not item or not all(32 <= ord(c) < 127 for c in item):
            continue
        if not isinstance(price, int) or price < 0 or price > 1000000:
            continue
        cands.append((off, rowid, item, price))
    except Exception:
        continue

print("candidates:", len(cands))
for c in cands:
    print(c)

# dedupe: same item+price once
seen = set()
out = []
for off, rowid, item, price in cands:
    if (item, price) in seen:
        continue
    seen.add((item, price))
    out.append({"item": item, "price": price})
print(json.dumps(out, ensure_ascii=False, indent=2))
json.dump(out, open("recovered.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)