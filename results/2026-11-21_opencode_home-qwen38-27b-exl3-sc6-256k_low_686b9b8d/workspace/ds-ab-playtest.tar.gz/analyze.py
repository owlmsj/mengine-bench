import csv, json, math

path = r"<WORKSPACE>\telemetry\playtest_ab.csv"

sessions = {}
dup_rows = 0
bad_variant = 0
with open(path, newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        sid = row["session_id"].strip()
        v = row["variant"].strip().lower()
        if v not in ("a", "b"):
            bad_variant += 1
            continue
        comp = int(row["completed_tutorial"])
        if sid in sessions:
            dup_rows += 1
            # verify duplicate rows are identical
            prev = sessions[sid]
            assert prev == (v, comp), f"conflicting duplicate for {sid}: {prev} vs {(v, comp)}"
        else:
            sessions[sid] = (v, comp)

a = [c for v, c in sessions.values() if v == "a"]
b = [c for v, c in sessions.values() if v == "b"]
na, nb = len(a), len(b)
xa, xb = sum(a), sum(b)
pa, pb = xa / na, xb / nb
p = (xa + xb) / (na + nb)
se = math.sqrt(p * (1 - p) * (1 / na + 1 / nb))
z = (pb - pa) / se
# two-sided p-value
p_value = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))

print("dup rows:", dup_rows, "bad variant:", bad_variant)
print("sessions_a:", na, "completed_a:", xa, "rate_a:", round(pa, 4))
print("sessions_b:", nb, "completed_b:", xb, "rate_b:", round(pb, 4))
print("z:", round(z, 4), "p_value:", p_value)

result = {
    "ship_b": p_value < 0.05 and pb > pa,
    "sessions_a": na,
    "sessions_b": nb,
    "completion_rate_a": round(pa, 4),
    "completion_rate_b": round(pb, 4),
    "p_value": round(p_value, 6),
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))