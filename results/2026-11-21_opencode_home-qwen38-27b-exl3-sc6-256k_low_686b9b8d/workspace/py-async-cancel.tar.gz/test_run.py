import asyncio
import sys

sys.path.insert(0, r"<WORKSPACE>")
from run import run_tasks


def make_task(i, running, log):
    def factory():
        async def job():
            running[i] = True
            log.append(f"start {i}")
            try:
                await asyncio.sleep(0.05)
                log.append(f"body {i}")
                return i * 10
            finally:
                log.append(f"cleanup {i}")
                running[i] = False
        return job()
    return factory


async def test_basic():
    running = [False] * 5
    log = []
    tasks = [make_task(i, running, log) for i in range(5)]
    results = await run_tasks(tasks, 2)
    assert results == [0, 10, 20, 30, 40], results
    # at most 2 concurrent: check via log interleaving is hard; use counter instead
    print("basic ok:", results)


async def test_limit():
    peak = 0
    cur = 0

    def factory(i):
        async def job():
            nonlocal cur, peak
            cur += 1
            peak = max(peak, cur)
            try:
                await asyncio.sleep(0.02)
            finally:
                cur -= 1
            return i
        return job()

    results = await run_tasks([lambda i=i: factory(i) for i in range(10)], 3)
    assert results == list(range(10)), results
    assert peak <= 3, peak
    print("limit ok, peak =", peak)


async def test_cancel_cleanup():
    log = []

    def factory(i):
        async def job():
            log.append(f"start {i}")
            try:
                await asyncio.sleep(5)
                return i
            finally:
                log.append(f"cleanup {i}")
        return job()

    async def main():
        t = asyncio.create_task(run_tasks([lambda i=i: factory(i) for i in range(4)], 2))
        await asyncio.sleep(0.05)
        t.cancel()
        try:
            await t
        except (asyncio.CancelledError, KeyboardInterrupt):
            pass
        # give cleanup a moment
        await asyncio.sleep(0.05)
        return log

    log = await main()
    started = [l for l in log if l.startswith("start")]
    cleaned = [l for l in log if l.startswith("cleanup")]
    print("cancel log:", log)
    assert len(started) == 2, started  # only 2 started with max_concurrent=2
    assert len(cleaned) == 2, cleaned  # both cleaned up
    print("cancel cleanup ok")


async def test_empty():
    assert await run_tasks([], 3) == []
    print("empty ok")


async def test_bad():
    try:
        await run_tasks([], 0)
    except ValueError as e:
        print("bad ok:", e)
    else:
        raise AssertionError("no ValueError")


async def main():
    await test_basic()
    await test_limit()
    await test_cancel_cleanup()
    await test_empty()
    await test_bad()
    print("ALL OK")


asyncio.run(main())