"""Batch task runner.

Usage:
    from run import run_tasks
    await run_tasks(tasks, max_concurrent)

Each task is a zero-argument callable returning an awaitable job.
At most max_concurrent jobs run at once. On Ctrl+C (KeyboardInterrupt)
or any cancellation, every job's cleanup code (finally blocks /
asyncio.shielded teardown) is allowed to finish before run_tasks returns.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Iterable
from typing import TypeVar

T = TypeVar("T")


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[T]]],
    max_concurrent: int,
) -> list[T]:
    """Run zero-arg callables returning awaitables, bounded by max_concurrent.

    Returns the list of job results in the order of `tasks`.

    Cancellation policy: if run_tasks itself is cancelled (e.g. the
    surrounding task is cancelled after KeyboardInterrupt is delivered),
    all in-flight jobs are cancelled too, but we wait for them to finish
    their cleanup (finally blocks, __aexit__ of async with, etc.) before
    propagating the cancellation.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent}")

    factories = list(tasks)
    if not factories:
        return []

    sem = asyncio.Semaphore(max_concurrent)
    results: list[T | None] = [None] * len(factories)
    done_events: list[asyncio.Event] = [asyncio.Event() for _ in factories]

    async def worker(index: int) -> None:
        async with sem:
            results[index] = await factories[index]()
        done_events[index].set()

    workers = [asyncio.create_task(worker(i)) for i in range(len(factories))]
    try:
        await asyncio.gather(*workers)
    except (KeyboardInterrupt, asyncio.CancelledError):
        # Ctrl+C: Python delivers KeyboardInterrupt to the main thread;
        # the running loop's tasks are not auto-cancelled, but the caller
        # (or the loop's shutdown) may cancel us. In either case, cancel
        # any jobs that are still running and wait for their cleanup to
        # complete so finally blocks / __aexit__ code runs.
        for w in workers:
            if not w.done():
                w.cancel()
        # Wait for every worker to fully finish (including cleanup).
        # Return exceptions so we do not mask the original error.
        await asyncio.gather(*workers, return_exceptions=True)
        raise
    finally:
        # Safety net: if something odd left workers pending, cancel them.
        for w in workers:
            if not w.done():
                w.cancel()

    return results  # type: ignore[return-value]