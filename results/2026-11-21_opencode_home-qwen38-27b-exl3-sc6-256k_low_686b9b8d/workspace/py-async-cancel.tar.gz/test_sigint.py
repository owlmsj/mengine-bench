import asyncio
import os
import signal
import sys
import time

sys.path.insert(0, r"<WORKSPACE>")
from run import run_tasks

log = []

def factory(i):
    async def job():
        log.append(f"start {i}")
        try:
            await asyncio.sleep(10)
        finally:
            log.append(f"cleanup {i}")
    return job

async def main():
    await run_tasks([lambda i=i: factory(i) for i in range(4)], 2)

# Install a SIGINT handler that raises KeyboardInterrupt in the main thread.
# On Windows, signal handlers run in the main thread between bytecodes, so
# this simulates a real Ctrl+C while the loop is running.
def on_sigint(signum, frame):
    raise KeyboardInterrupt

signal.signal(signal.SIGINT, on_sigint)

loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)
task = asyncio.ensure_future(main())

def send_sigint():
    time.sleep(0.2)
    os.kill(os.getpid(), signal.SIGINT)

import threading
t = threading.Thread(target=send_sigint)
t.start()
try:
    loop.run_until_complete(task)
    print("completed normally (unexpected)")
except KeyboardInterrupt:
    print("got KeyboardInterrupt")
finally:
    t.join()
    loop.close()

print("log:", log)
started = [l for l in log if l.startswith("start")]
cleaned = [l for l in log if l.startswith("cleanup")]
assert len(started) == 2, started
assert len(cleaned) == 2, cleaned
print("SIGINT cleanup OK")