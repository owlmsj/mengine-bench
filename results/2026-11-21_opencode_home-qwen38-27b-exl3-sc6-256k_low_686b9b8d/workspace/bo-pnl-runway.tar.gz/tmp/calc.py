import csv, json
from collections import defaultdict

fin = r"<WORKSPACE>\finance"

coa = {}
with open(fin + r"\chart_of_accounts.csv", encoding="utf-8") as f:
    for row in csv.reader(f, delimiter=";"):
        if row[0] == "account":
            continue
        coa[row[0]] = row[2]

def money(s):
    s = s.replace(" ", "")
    neg = s.startswith("-")
    s = s.lstrip("-")
    s = s.replace(".", "").replace(",", ".")
    v = float(s)
    return -v if neg else v

months = ["2026-01", "2026-02", "2026-03", "2026-04", "2026-05", "2026-06"]
agg = {m: defaultdict(float) for m in months}

with open(fin + r"\ledger.csv", encoding="utf-8") as f:
    for row in csv.reader(f, delimiter=";"):
        if row[0] == "date":
            continue
        d, acct, desc, amt = row
        dd, mm, yyyy = d.split("/")
        m = f"{yyyy}-{mm}"
        if m not in agg:
            continue
        agg[m][coa[acct]] += money(amt)

out = {}
ebitda = {}
for m in months:
    a = agg[m]
    rev = a["revenue"]
    cogs = a["cogs"]
    gm = (rev + cogs) / rev * 100 if rev else 0.0
    e = rev + cogs + a["sales_marketing"] + a["rnd"] + a["ga"] + a["financial"]
    out[m] = {"revenue": round(rev, 2), "gross_margin_pct": round(gm, 2), "ebitda": round(e, 2)}
    ebitda[m] = e

# burn: avg monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = [ebitda[m] for m in ["2026-04", "2026-05", "2026-06"]]
neg = [e for e in last3 if e < 0]
burn = round(-sum(neg) / len(neg), 2) if neg else 0.0
cash = 1847350.40
runway = round(cash / burn, 2) if burn else 0.0

result = {
    "revenue": {m: out[m]["revenue"] for m in months},
    "gross_margin_pct": {m: out[m]["gross_margin_pct"] for m in months},
    "ebitda": {m: out[m]["ebitda"] for m in months},
    "burn": burn,
    "runway_months": runway,
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
print(json.dumps(result, indent=2))
print("last3 ebitda:", [round(e, 2) for e in last3])
print("cash:", cash)