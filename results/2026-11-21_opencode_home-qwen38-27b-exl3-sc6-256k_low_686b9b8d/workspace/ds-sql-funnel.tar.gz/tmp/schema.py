import sqlite3
c = sqlite3.connect('analytics.db')
for r in c.execute("select name, sql from sqlite_master where type='table'"):
    print(r[1])
    print('---')