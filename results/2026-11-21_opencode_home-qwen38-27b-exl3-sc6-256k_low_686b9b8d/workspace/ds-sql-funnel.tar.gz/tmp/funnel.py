import sqlite3, json
c = sqlite3.connect('analytics.db')
STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']

# per user: platform, is_test, first ts per step
rows = c.execute("""
  select u.platform, u.is_test, e.user_id, e.name, min(e.ts)
  from events e join users u on u.user_id = e.user_id
  where e.name in ('install','tutorial_complete','first_match','purchase')
  group by e.user_id, e.name
""").fetchall()

first = {}  # (user) -> {step: ts}
plat = {}
for p, t, uid, name, ts in rows:
    first.setdefault(uid, {})[name] = ts
    plat[uid] = (p, t)

funnel = {}
for p in sorted(plat.values(), key=lambda x: x[0]):
    pass
platforms = sorted({p for p, t in plat.values()})
for p in platforms:
    counts = {}
    prev_ok = {}  # uid -> ts of previous step (or None for install)
    for i, step in enumerate(STEPS):
        n = 0
        ok = {}
        for uid, steps in first.items():
            if plat[uid][0] != p or plat[uid][1]:
                continue
            if step not in steps:
                continue
            ts = steps[step]
            if i == 0:
                ok[uid] = ts
            else:
                prev = prev_ok.get(uid)
                if prev is not None and ts >= prev:
                    ok[uid] = ts
        counts[step] = len(ok)
        prev_ok = ok
    funnel[p] = counts

# biggest drop: step with lowest conversion (step / previous step)
biggest = {}
for p, counts in funnel.items():
    best = None
    for i in range(1, len(STEPS)):
        prev_n = counts[STEPS[i-1]]
        conv = counts[STEPS[i]] / prev_n if prev_n else 0.0
        if best is None or conv < best[1]:
            best = (STEPS[i], conv)
    biggest[p] = best[0]

out = {'funnel': funnel, 'biggest_drop': biggest}
with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))