import sqlite3
c = sqlite3.connect('analytics.db')
# independent check: for each platform, count users whose first valid ts chain holds
q = """
with f as (
  select e.user_id, e.name, min(e.ts) ts
  from events e join users u on u.user_id=e.user_id
  where u.is_test=0 and e.name in ('install','tutorial_complete','first_match','purchase')
  group by e.user_id, e.name
),
piv as (
  select u.platform, f.user_id,
    max(case f.name when 'install' then f.ts end) i,
    max(case f.name when 'tutorial_complete' then f.ts end) t,
    max(case f.name when 'first_match' then f.ts end) m,
    max(case f.name when 'purchase' then f.ts end) pu
  from f join users u on u.user_id=f.user_id
  group by u.platform, f.user_id
)
select platform,
  sum(i is not null) install,
  sum(t is not null and t>=i) tutorial,
  sum(m is not null and m>=t) first_match,
  sum(pu is not null and pu>=m) purchase
from piv group by platform
"""
for r in c.execute(q):
    print(r)