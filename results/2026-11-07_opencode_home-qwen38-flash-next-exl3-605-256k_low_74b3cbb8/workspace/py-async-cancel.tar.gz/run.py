"""Bounded-concurrency batch runner for zero-argument async task factories.

Public API: ``run_tasks(tasks, max_concurrent)``.
Standard library only, Python 3.11+.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Iterable
from typing import TypeVar

T = TypeVar("T")


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[T]]],
    max_concurrent: int,
) -> list[T]:
    """Run every job produced by *tasks*, at most *max_concurrent* at once.

    Each element of *tasks* is a zero-argument callable that returns an
    awaitable; it is called once, inside the concurrency window, and the
    awaitable is awaited. Returns a list of job results (in task order) once
    every job is done.

    Failure policy (not specified in the brief): every job still runs to
    completion, then all job exceptions are raised together as an
    ExceptionGroup. Nothing is silently swallowed.

    Cancellation policy: if the caller is cancelled (task.cancel(), or
    Ctrl+C delivered as KeyboardInterrupt/CancelledError under
    asyncio.run), every job is cancelled and this coroutine waits for the
    jobs' cleanup (finally blocks, async context managers) to finish before
    re-raising. A second cancellation during that wait cannot mask the
    original one.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent!r}")

    semaphore = asyncio.Semaphore(max_concurrent)

    async def _bounded(factory: Callable[[], Awaitable[T]]) -> T:
        async with semaphore:
            return await factory()

    # Own the tasks (not gather) so cancelling our own await never silently
    # drops the jobs: we cancel and await them explicitly in the handler.
    jobs = [asyncio.create_task(_bounded(factory)) for factory in tasks]
    try:
        outcomes = await asyncio.gather(*jobs, return_exceptions=True)
    except BaseException:
        for job in jobs:
            job.cancel()
        try:
            await asyncio.gather(*jobs, return_exceptions=True)
        except BaseException:
            pass  # a second Ctrl+C must not hide the original cancellation
        raise

    errors = [outcome for outcome in outcomes if isinstance(outcome, BaseException)]
    if errors:
        raise ExceptionGroup("run_tasks: one or more jobs failed", errors)
    return outcomes  # type: ignore[return-value]  # all outcomes are results here