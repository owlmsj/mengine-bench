"""Verification for run_tasks: limit, completion, cleanup on cancel, errors."""

import asyncio

from run import run_tasks


async def test_concurrency_limit_and_completion():
    running = 0
    peak = 0
    done = []

    def make(i):
        async def job():
            nonlocal running, peak
            running += 1
            peak = max(peak, running)
            await asyncio.sleep(0.01)
            running -= 1
            done.append(i)
            return i
        return job

    results = await run_tasks([make(i) for i in range(10)], 3)
    assert results == list(range(10)), results
    assert len(done) == 10
    assert peak <= 3, peak
    assert peak == 3, peak  # actually uses the window


async def test_cleanup_on_cancel():
    started, cleaned = [], []

    def make(i):
        async def job():
            started.append(i)
            try:
                await asyncio.sleep(5)
            finally:
                await asyncio.sleep(0.01)  # async cleanup
                cleaned.append(i)
        return job

    runner = asyncio.create_task(run_tasks([make(i) for i in range(5)], 2))
    await asyncio.sleep(0.05)
    runner.cancel()
    try:
        await runner
        raise AssertionError("expected CancelledError")
    except asyncio.CancelledError:
        pass
    assert started == [0, 1], started          # only window-size started
    assert cleaned == started, (cleaned, started)  # every started job cleaned up


async def test_errors_after_all_complete():
    finished = []

    def good(i):
        async def job():
            await asyncio.sleep(0.02)
            finished.append(i)
        return job

    def bad(msg):
        async def job():
            await asyncio.sleep(0.01)
            raise RuntimeError(msg)
        return job

    try:
        await run_tasks([good(0), bad("a"), good(1), bad("b")], 4)
        raise AssertionError("expected ExceptionGroup")
    except ExceptionGroup as eg:
        assert sorted(str(e) for e in eg.exceptions) == ["a", "b"], eg.exceptions
    assert sorted(finished) == [0, 1]  # good jobs still ran to completion


async def test_empty_and_invalid():
    assert await run_tasks([], 4) == []
    try:
        await run_tasks([], 0)
        raise AssertionError("expected ValueError")
    except ValueError:
        pass


async def main():
    await test_concurrency_limit_and_completion()
    await test_cleanup_on_cancel()
    await test_errors_after_all_complete()
    await test_empty_and_invalid()
    print("all tests passed")


if __name__ == "__main__":
    asyncio.run(main())