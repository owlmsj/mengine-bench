"""Real SIGINT (Ctrl+C) test: cleanup must run, exit must be clean-ish."""
import asyncio, os, signal, sys, threading

from run import run_tasks

MARKER = "cleanup-done"

def make(i):
    async def job():
        try:
            await asyncio.sleep(5)
        finally:
            await asyncio.sleep(0.01)
            print(f"{MARKER} {i}", flush=True)
    return job

def interrupt():
    import time
    time.sleep(0.3)
    os.kill(os.getpid(), signal.SIGINT)  # like Ctrl+C

if __name__ == "__main__":
    threading.Thread(target=interrupt, daemon=True).start()
    try:
        asyncio.run(run_tasks([make(i) for i in range(4)], 2))
    except KeyboardInterrupt:
        print("interrupted", flush=True)