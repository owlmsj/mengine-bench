import sqlite3, json

STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']
con = sqlite3.connect('analytics.db')

# exclude test accounts; events from unknown players dropped via join
valid_users = {u: p for u, p in con.execute(
    "SELECT user_id, platform FROM users WHERE is_test = 0")}

events = {}  # user -> name -> sorted ts list
for u, n, ts in con.execute("SELECT user_id, name, ts FROM events ORDER BY ts"):
    if u in valid_users and n in STEPS:
        events.setdefault(u, {}).setdefault(n, []).append(ts)

counts = {}
for u, plat in valid_users.items():
    ev = events.get(u, {})
    prev = None
    for step in STEPS:
        ts_list = ev.get(step, [])
        cand = next((t for t in ts_list if prev is None or t >= prev), None)
        if cand is None:
            break
        prev = cand
        counts.setdefault(plat, {}).setdefault(step, 0)
        counts[plat][step] += 1

funnel = {}
biggest = {}
for plat in sorted(counts):
    funnel[plat] = {s: counts[plat].get(s, 0) for s in STEPS}
    worst_step, worst_conv = None, None
    for i in range(1, len(STEPS)):
        prev_n = counts[plat].get(STEPS[i-1], 0)
        if prev_n == 0:
            continue
        conv = counts[plat].get(STEPS[i], 0) / prev_n
        if worst_conv is None or conv < worst_conv:
            worst_step, worst_conv = STEPS[i], conv
    biggest[plat] = worst_step

result = {'funnel': funnel, 'biggest_drop': biggest}
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
# extra: conversions for verification
for plat in sorted(counts):
    convs = {STEPS[i]: round(counts[plat].get(STEPS[i],0)/counts[plat][STEPS[i-1]], 3)
             for i in range(1, 4) if counts[plat].get(STEPS[i-1], 0)}
    print(plat, convs)
print('test users:', con.execute("SELECT COUNT(*) FROM users WHERE is_test=1").fetchone()[0])
print('unknown-player events:', con.execute(
    "SELECT COUNT(*) FROM events e LEFT JOIN users u ON e.user_id=u.user_id WHERE u.user_id IS NULL").fetchone()[0])