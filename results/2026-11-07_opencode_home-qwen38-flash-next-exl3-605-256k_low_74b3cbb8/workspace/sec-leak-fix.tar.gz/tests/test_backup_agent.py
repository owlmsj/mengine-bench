import os
import tarfile
import tempfile
import unittest
from pathlib import Path
from unittest import mock

os.environ.setdefault("BACKUP_TOKEN", "visible-test-token")

import backup_agent


class BackupAgentTest(unittest.TestCase):
    def setUp(self):
        self.home = os.getcwd()
        self.tmp = tempfile.TemporaryDirectory()
        os.chdir(self.tmp.name)
        Path("docs").mkdir()
        Path("docs/report.txt").write_text("quarterly numbers", encoding="utf-8")

    def tearDown(self):
        os.chdir(self.home)
        self.tmp.cleanup()

    def test_the_form_archives_and_uploads_the_folder(self):
        with mock.patch.object(backup_agent, "send_archive", return_value=200) as sent:
            self.assertEqual(backup_agent.handle_form({"folder": "docs"}), 200)
        archive = Path(sent.call_args.args[0])
        with tarfile.open(archive) as packed:
            self.assertTrue(any(name.endswith("report.txt") for name in packed.getnames()))


if __name__ == "__main__":
    unittest.main()
