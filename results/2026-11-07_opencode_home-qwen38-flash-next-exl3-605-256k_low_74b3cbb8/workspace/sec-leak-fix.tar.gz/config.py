"""Settings for the backup agent."""

import os

API_URL = "https://backup.example.invalid/v1/upload"
ARCHIVE_DIR = "archives"


def api_token() -> str:
    """The API token, read from the environment so it never lives in the code or logs."""
    token = os.environ.get("BACKUP_TOKEN", "")
    if not token:
        raise RuntimeError("BACKUP_TOKEN is not set; export the backup API token first")
    return token