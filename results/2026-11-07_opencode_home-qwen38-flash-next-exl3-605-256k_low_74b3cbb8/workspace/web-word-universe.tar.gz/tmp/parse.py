import os, re, json, collections
from urllib.parse import unquote

site = r".\site"
EXCLUDE = {"index.html", "sobre.html", "contato.html"}
files = [f for f in os.listdir(site) if f.lower().endswith(".html") and f.lower() not in EXCLUDE]

canon, raw, redirects = {}, {}, {}
for f in files:
    t = open(os.path.join(site, f), encoding="utf-8", errors="replace").read()
    k = f.lower()
    r = re.search(r'url=([^"]+)\.html', t)
    m = re.search(r"<main><h1>(.*?)</h1>", t)
    if m:
        canon[k] = m.group(1).strip(); raw[k] = t
    elif r:
        redirects[k] = unquote(r.group(1)).lower() + ".html"
    else:
        print("ORPHAN", f)

def resolve(href):
    k = unquote(href).lower() + ".html"
    seen = 0
    while k in redirects and seen < 5:
        k = redirects[k]; seen += 1
    return canon.get(k)

links = collections.defaultdict(set)
dead = collections.Counter()
for k, t in raw.items():
    main = re.search(r"<main>.*?</main>", t, re.S).group(0)
    src = canon[k]
    for href in re.findall(r'<a href="([^"#]+?)\.html"', main):
        dst = resolve(href)
        if dst is None:
            dead[href] += 1; continue
        if dst.lower() != src.lower():
            links[src.lower()].add(dst.lower())

adj = {n.lower(): set() for n in canon.values()}
for s, ds in links.items():
    for d in ds:
        adj[s].add(d); adj[d].add(s)

words = {n: sorted(adj[n]) for n in sorted(adj)}
themes = {}
for k, t in raw.items():
    m = re.search(r'class="tema">Tema:\s*(.*?)</p>', t)
    themes[canon[k].lower()] = m.group(1).strip() if m else "outros"
json.dump(themes, open("tmp/themes.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("themes:", sorted(set(themes.values())))
pairs = {tuple(sorted((s, d))) for s, ds in adj.items() for d in ds}
deg = {n: len(v) for n, v in adj.items()}
mx = max(deg.values())
result = {"words": len(words), "relations": len(pairs),
          "most_connected": sorted(n for n, d in deg.items() if d == mx)}
json.dump(words, open("words.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
json.dump(result, open("result.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(json.dumps(result, ensure_ascii=False))
print("dead:", dict(dead))
print("saudade:", words["saudade"])
print("tempo deg:", deg["tempo"], "amor:", words["amor"])