import json

# Beta values converted to Alfa (first report) units
glucose = round(6.1 * 18.0182, 1)          # mmol/L -> mg/dL
ldl = round(3.70 * 38.67, 1)               # mmol/L -> mg/dL
creat = round(76 / 88.4, 2)                # umol/L -> mg/dL
hba1c = round(0.09148 * 37 + 2.152, 2)     # IFCC mmol/mol -> NGSP %

history = {
    "Glicose em jejum": {"2026-02-10": 92.0, "2026-08-18": glucose},
    "Colesterol LDL": {"2026-02-10": 118.0, "2026-08-18": ldl},
    "Creatinina": {"2026-02-10": 0.95, "2026-08-18": creat},
    "Hemoglobina glicada (HbA1c)": {"2026-02-10": 5.4, "2026-08-18": hba1c},
}

# First-report reference ranges; direction = higher is worse
ranges = {
    "Glicose em jejum": (70, 99),
    "Colesterol LDL": (None, 130),   # "Desejavel: inferior a 130"
    "Creatinina": (0.70, 1.30),
    "Hemoglobina glicada (HbA1c)": (4.0, 5.6),
}

worse = []
for m, h in history.items():
    lo, hi = ranges[m]
    v0, v1 = h["2026-02-10"], h["2026-08-18"]
    out = (hi is not None and v1 > hi) or (lo is not None and v1 < lo)
    if v1 > v0 and out:
        worse.append(m)

result = {"history": history, "worse": worse}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
print(json.dumps(result, ensure_ascii=False, indent=2))