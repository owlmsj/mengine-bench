# HANDOFF: local-9b Q5 at 128k

Goal: run local-9b Q5 at 128k context on this GPU.

Settled:
- Baseline (scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024): 37.8 t/s at 7881 MiB. Invalid: 7881 MiB is the WDDM ceiling; Shared Usage showed 1494 MiB spilled to RAM.
- Fix: --no-mmproj-offload + -ub 512 removes the spill. Final: 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k; dropped. Q4_K_M fits (7305 MiB, 40.4 t/s), kept only as fallback.
- Recipe applied at scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

Open:
- evals README still cites check_vision.ps1, a deleted file; update it.
- This folder holds only session/transcript.md, so the two edits above are unverified here: diff those files and rerun measure_decode.ps1 to confirm.

Method: judge fit by the Shared Usage counter, not dedicated VRAM alone.