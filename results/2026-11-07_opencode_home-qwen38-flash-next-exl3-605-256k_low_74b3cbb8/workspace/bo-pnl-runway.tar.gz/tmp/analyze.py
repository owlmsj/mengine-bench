import csv, json
from collections import defaultdict

coa = {}
with open('finance/chart_of_accounts.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        coa[row['account']] = row['pnl_line']

def parse(s):
    return float(s.replace('.', '').replace(',', '.'))

months = ['2026-0%d' % m for m in range(1, 7)]
agg = {m: defaultdict(float) for m in months}
with open('finance/ledger.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        d, mth = row['date'], row['date'][-4:] + '-' + row['date'][3:5]
        line = coa[row['account']]
        agg[mth][line] += parse(row['amount'])

out = {'revenue': {}, 'gross_margin_pct': {}, 'ebitda': {}}
rows = []
for m in months:
    a = agg[m]
    rev = a['revenue']; cogs = a['cogs']
    gm = (rev + cogs) / rev * 100
    ebitda = rev + cogs + a['sales_marketing'] + a['rnd'] + a['ga']
    out['revenue'][m] = round(rev, 2)
    out['gross_margin_pct'][m] = round(gm, 2)
    out['ebitda'][m] = round(ebitda, 2)
    rows.append((m, rev, cogs, a['sales_marketing'], a['rnd'], a['ga'], a['financial'], gm, ebitda))

last3 = [out['ebitda'][m] for m in months[-3:]]
neg = [e for e in last3 if e < 0]
burn = -sum(neg) / len(neg) if neg else 0.0
cash = 1847350.40
runway = cash / burn
out['burn'] = round(burn, 2)
out['runway_months'] = round(runway, 2)

print('month  revenue     cogs       s&m        rnd        ga         fin        gm%    ebitda')
for r in rows:
    print('%s %11.2f %10.2f %10.2f %10.2f %10.2f %10.2f %6.2f %10.2f' % r)
print('last3 ebitda:', last3)
print('burn:', burn, 'cash:', cash, 'runway:', runway)

with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, indent=2, ensure_ascii=False)
print(json.dumps(out, indent=2))