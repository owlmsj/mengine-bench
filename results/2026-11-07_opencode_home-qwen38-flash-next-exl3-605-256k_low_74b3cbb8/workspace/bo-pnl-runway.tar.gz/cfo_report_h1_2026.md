# H1 2026 Financial Review (CFO briefing)

Currency: BRL (R$). Source: `finance/ledger.csv` (86 entries, Jan-Jun 2026),
`finance/chart_of_accounts.csv`, `finance/cash_balance.txt`, board definition in `finance/README.md`.

## Definitions used
- Revenue = accounts 3.1.01 + 3.1.02 + 3.1.09 (refunds netted against revenue).
- Gross margin % = (revenue + COGS) / revenue, COGS = 4.1.01 + 4.1.02.
- EBITDA = revenue + COGS + S&M + R&D + G&A; financial results (6.x) excluded; no D&A in the chart.
- Burn = average monthly negative EBITDA of the last three closed months (Apr-Jun 2026), per board notes.
- Runway = latest closing cash (30/06/2026: R$ 1,847,350.40) / burn.

## Monthly P&L (R$)

| Month | Revenue | COGS | S&M | R&D | G&A | EBITDA | Gross margin |
|-------|---------:|---------:|---------:|---------:|--------:|----------:|------:|
| 2026-01 | 200,510.87 | -60,091.92 | -143,475.23 | -163,396.33 | -43,826.35 | -210,278.96 | 70.03% |
| 2026-02 | 216,328.06 | -64,278.71 | -138,161.28 | -182,271.02 | -43,917.13 | -212,300.08 | 70.29% |
| 2026-03 | 219,066.17 | -69,096.05 | -135,519.34 | -171,742.87 | -47,233.36 | -204,525.45 | 68.46% |
| 2026-04 | 238,163.26 | -70,867.73 | -139,688.11 | -179,804.44 | -44,753.63 | -196,950.65 | 70.24% |
| 2026-05 | 243,032.89 | -73,973.13 | -138,680.10 | -185,905.30 | -46,420.18 | -201,945.82 | 69.56% |
| 2026-06 | 272,391.57 | -75,162.69 | -151,896.54 | -189,990.01 | -48,310.55 | -192,968.22 | 72.41% |

## How each month went
- Revenue grew every month: R$ 200.5k (Jan) to R$ 272.4k (Jun), +35.8% over H1; June was the strongest month.
- Gross margin is stable around 68-72%, ending H1 at its best (72.41% in June).
- EBITDA losses are flat-to-improving: from -R$ 210.3k (Jan) to -R$ 193.0k (Jun). Operating cost growth is lagging revenue growth, so the loss is narrowing.
- Refunds (account 3.1.09, customer Kestrel: -R$ 6,814.15 in Mar, -R$ 8,634.37 in May) are already netted in revenue.

## Burn and runway
- Burn = mean of Apr/May/Jun EBITDA = (196,950.65 + 201,945.82 + 192,968.22) / 3 = **R$ 197,288.23 / month**.
- Cash at 30/06/2026 = R$ 1,847,350.40 (down from R$ 2,309,188.00 at 31/05/2026).
- Runway = 1,847,350.40 / 197,288.23 = **9.36 months** (to roughly mid-Aug 2027 if burn holds).

## Message for investors
H1 shows consistent revenue growth (+35.8% Jan-Jun), stable ~70% gross margin, and a
slowly narrowing EBITDA loss. At the current burn of ~R$ 197k/month, cash covers ~9.4
months, so a funding decision is needed within the year on current trajectory.

## Assumptions
- Dates are DD/MM/YYYY (Brazilian format), consistent with cash_balance.txt.
- Financial income/expense (6.x) is excluded from EBITDA and from burn, per the board's burn definition.
- Cash figures are taken as given from cash_balance.txt; the ledger does not reconcile to the full cash movement, so runway uses the stated closing balance.
- Values rounded to 2 decimals in `result.json`.