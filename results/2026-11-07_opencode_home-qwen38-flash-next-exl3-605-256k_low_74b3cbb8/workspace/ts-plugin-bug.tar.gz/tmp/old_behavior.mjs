// Proof of the reported symptoms with the pre-fix emit (forEach + async callback).
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const handlers = [];
async function emitOld(payload) {
  handlers.forEach(async (handler) => { await handler(payload); });
}
const seen = [];
handlers.push(async () => { await sleep(20); seen.push("slow"); });
handlers.push(() => { seen.push("fast"); });
handlers.push(async () => { seen.push("boom"); throw new Error("hook failed"); });
handlers.push(() => { seen.push("last"); });

process.on("unhandledRejection", (e) => console.log("SILENT (unhandled) rejection:", e.message));
await emitOld(1);
console.log("right after await emit:", seen, "<- emit resolved early: hooks appear to never run, order wrong");
await sleep(40);
console.log("later:", seen);