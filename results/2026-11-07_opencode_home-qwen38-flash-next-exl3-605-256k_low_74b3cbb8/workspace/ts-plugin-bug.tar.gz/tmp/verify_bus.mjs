import assert from "node:assert/strict";
import { HookBus } from "<WORKSPACE>/src/bus.ts";
import { registerAuditPlugin } from "<WORKSPACE>/src/plugin.ts";

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// 1. sequential order, slow handler first (the reported out-of-order bug)
{
  const bus = new HookBus();
  const seen = [];
  bus.on("e", async () => { await sleep(20); seen.push("slow"); });
  bus.on("e", () => { seen.push("fast"); });
  bus.on("e", async () => { await sleep(5); seen.push("mid"); });
  await bus.emit("e", 1);
  assert.deepEqual(seen, ["slow", "fast", "mid"], "order");
}

// 2. emit resolves only after every handler finished
{
  const bus = new HookBus();
  let done = false;
  bus.on("e", async () => { await sleep(15); done = true; });
  await bus.emit("e", 1);
  assert.equal(done, true, "emit resolved before handler finished");
}

// 3. failing handler rejects emit with the same error, later handlers skipped
{
  const bus = new HookBus();
  const boom = new Error("hook failed");
  const seen = [];
  bus.on("e", () => { seen.push("first"); });
  bus.on("e", async () => { await sleep(5); throw boom; });
  bus.on("e", () => { seen.push("never"); });
  await assert.rejects(() => bus.emit("e", 1), (err) => err === boom);
  assert.deepEqual(seen, ["first"], "handlers after the failure must not run");
}

// 4. unsubscribe during emit does not stop the others; counts from next emit
{
  const bus = new HookBus();
  const seen = [];
  let offB;
  bus.on("e", () => { seen.push("a"); offB(); });
  offB = bus.on("e", () => { seen.push("b"); });
  bus.on("e", () => { seen.push("c"); });
  await bus.emit("e", 1);
  assert.deepEqual(seen, ["a", "b", "c"], "snapshot at emit start");
  seen.length = 0;
  await bus.emit("e", 2);
  assert.deepEqual(seen, ["a", "c"], "unsubscribe counts from next emit");
  assert.equal(bus.count("e"), 2);
}

// 5. subscribing during emit does not join that emit
{
  const bus = new HookBus();
  const seen = [];
  bus.on("e", () => { bus.on("e", () => seen.push("late")); });
  await bus.emit("e", 1);
  assert.deepEqual(seen, []);
  await bus.emit("e", 2);
  assert.deepEqual(seen, ["late"]);
}

// 6. audit plugin contract: one-time notice, redaction, then log, in order
{
  const bus = new HookBus();
  const audit = [];
  registerAuditPlugin(bus, audit);
  await bus.emit("tool.after", { tool: "read", output: "secret password=hunter2 ok" });
  assert.deepEqual(audit, [
    "notice: tool output is audited",
    "read: secret password=[redacted] ok",
  ], "first emit");
  await bus.emit("tool.after", { tool: "write", output: "password=x" });
  assert.deepEqual(audit.slice(2), ["write: password=[redacted]"], "notice is one-time");
  assert.equal(bus.count("tool.after"), 2);
}

// 7. no unhandled rejection when a handler fails and emit is awaited
{
  process.on("unhandledRejection", (e) => { throw new Error("unhandled: " + e); });
  const bus = new HookBus();
  bus.on("e", async () => { await sleep(5); throw new Error("x"); });
  await assert.rejects(() => bus.emit("e", 1));
  await sleep(20);
}

console.log("ALL CHECKS PASSED");