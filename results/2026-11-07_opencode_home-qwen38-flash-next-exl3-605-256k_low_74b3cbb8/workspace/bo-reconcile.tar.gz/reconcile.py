import csv, json, re
from collections import defaultdict

inv = {}
with open('backoffice/invoices.csv', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        inv[r['id']] = float(r['amount'])

pays = defaultdict(list)
ignored = []
with open('backoffice/bank_statement_june.csv', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        m = re.search(r'(?:INV-|invoice |inv)(\d{4})', r['memo'])
        if not m or float(r['amount']) <= 0:
            ignored.append(r['memo'])
            continue
        iid = f"INV-{m.group(1)}"
        if iid not in inv:
            ignored.append(r['memo'])
            continue
        pays[iid].append(float(r['amount']))

unpaid = sorted(i for i in inv if i not in pays)
dup = sorted(i for i, p in pays.items() if len(p) > 1)
mis = [{'id': i, 'invoiced': inv[i], 'paid': p[0]}
       for i, p in sorted(pays.items())
       if len(p) == 1 and abs(p[0] - inv[i]) > 0.005]

out = {'unpaid': unpaid, 'duplicated': dup, 'mismatched': mis}
print(json.dumps(out, indent=2, ensure_ascii=False))
print('ignored:', ignored)
print('paid invoices:', len(pays), 'unpaid:', len(unpaid),
      'total inv:', len(inv), 'sum check:', len(pays) + len(unpaid) == len(inv))
with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, indent=2, ensure_ascii=False)