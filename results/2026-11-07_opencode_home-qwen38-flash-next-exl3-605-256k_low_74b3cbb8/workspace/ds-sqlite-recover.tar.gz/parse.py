import json, struct

data = open('prices.db', 'rb').read()
pagesize = 4096

def varint(buf, off):
    val = 0
    for i in range(9):
        b = buf[off + i]
        if i == 8:
            val = (val << 8) | b
            return val, off + 9
        val = (val << 7) | (b & 0x7f)
        if not (b & 0x80):
            return val, off + i + 1

rows = []
for pstart in range(0, len(data), pagesize):
    page = data[pstart:pstart + pagesize]
    if len(page) < 8:
        continue
    ptype = page[0]
    # allow page1 with 16-byte magic overwritten: header may be at 0 or 100
    hoff = 0
    if ptype != 0x0d and page[100] == 0x0d:
        hoff = 100
    if page[hoff] != 0x0d:
        continue
    ncells = struct.unpack('>H', page[hoff + 3:hoff + 5])[0]
    ptrs = [struct.unpack('>H', page[hoff + 8 + 2 * i:hoff + 10 + 2 * i])[0]
            for i in range(ncells)]
    for ptr in ptrs:
        off = ptr
        plen, off = varint(page, off)
        rowid, off = varint(page, off)
        end = off + plen
        hlen, off = varint(page, off)
        hend = ptr + hlen if False else off + hlen - _hdrvar if False else None
        # parse serial types until we reach end of record header
        types = []
        hstart = off
        while off < hstart + (hlen - (off - hstart)) if False else True:
            break
        # recompute: header size includes its own varint
        hdr_end = ptr + 0  # unknown; use: header started at 'off' before reading hlen? no
        # redo properly
        off2 = ptr
        plen2, off2 = varint(page, off2)
        rowid2, off2 = varint(page, off2)
        hdr_start = off2
        hlen2, off2 = varint(page, off2)
        hdr_end = hdr_start + hlen2
        while off2 < hdr_end:
            t, off2 = varint(page, off2)
            types.append(t)
        vals = []
        for t in types:
            if t == 0:
                vals.append(None)
            elif t == 1:
                vals.append(int.from_bytes(page[off2:off2 + 1], 'big', signed=True)); off2 += 1
            elif t == 2:
                vals.append(int.from_bytes(page[off2:off2 + 2], 'big', signed=True)); off2 += 2
            elif t == 3:
                vals.append(int.from_bytes(page[off2:off2 + 3], 'big', signed=True)); off2 += 3
            elif t == 4:
                vals.append(int.from_bytes(page[off2:off2 + 4], 'big', signed=True)); off2 += 4
            elif t == 5:
                vals.append(int.from_bytes(page[off2:off2 + 6], 'big', signed=True)); off2 += 6
            elif t == 6:
                vals.append(int.from_bytes(page[off2:off2 + 8], 'big', signed=True)); off2 += 8
            elif t == 7:
                vals.append(struct.unpack('>d', page[off2:off2 + 8])[0]); off2 += 8
            elif t == 8:
                vals.append(0)
            elif t == 9:
                vals.append(1)
            elif t >= 13 and t % 2 == 1:
                n = (t - 13) // 2
                vals.append(page[off2:off2 + n].decode('utf-8', 'replace')); off2 += n
            elif t >= 12 and t % 2 == 0:
                n = (t - 12) // 2
                vals.append(page[off2:off2 + n]); off2 += n
            else:
                vals.append(None)
        rows.append((rowid2, vals))

out = []
for rowid, vals in rows:
    item = None
    price = None
    for v in vals:
        if isinstance(v, str) and item is None:
            item = v
        elif isinstance(v, (int, float)) and not isinstance(v, bool) and price is None:
            price = v
    if item is not None and price is not None:
        out.append({"item": item, "price": price})
    else:
        out.append({"item": item, "price": price, "_raw": [repr(v) for v in vals]})

print(json.dumps(out, indent=1))
json.dump(out, open('recovered.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=2)