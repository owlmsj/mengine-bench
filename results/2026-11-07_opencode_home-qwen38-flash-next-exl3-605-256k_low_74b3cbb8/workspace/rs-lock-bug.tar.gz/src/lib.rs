//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        // Read and write under one lock: two separate lock/unlock pairs let a
        // concurrent award slip in between and overwrite the update.
        *slot.lock().unwrap() += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return;
        }
        let from_slot = self.slot(from);
        let to_slot = self.slot(to);
        // Always take the lower player id first: two opposite transfers that
        // each held one lock would otherwise wait on each other forever.
        let (low, high) = if from < to {
            (from_slot.lock().unwrap(), to_slot.lock().unwrap())
        } else {
            (to_slot.lock().unwrap(), from_slot.lock().unwrap())
        };
        let (mut from_score, mut to_score) = if from < to { (low, high) } else { (high, low) };
        *from_score -= points;
        *to_score += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::mpsc;
    use std::thread;
    use std::time::Duration;

    // Fails on the old code: transfer(1, 1, ..) locked the same mutex twice.
    #[test]
    fn transfer_to_same_player_changes_nothing() {
        let board = Board::new();
        board.join(1, 10);
        board.transfer(1, 1, 5);
        assert_eq!((board.score(1), board.total()), (10, 10));
    }

    // Fails on the old code: opposite transfers deadlocked, and the
    // non-atomic read-modify-write in award lost concurrent updates.
    #[test]
    fn concurrent_awards_and_opposite_transfers_keep_exact_scores() {
        let board = Board::new();
        board.join(1, 0);
        board.join(2, 0);

        let (done_tx, done_rx) = mpsc::channel();
        let worker = {
            let board = board.clone();
            thread::spawn(move || {
                for _ in 0..2000 {
                    board.award(1, 1);
                    board.award(2, 1);
                    board.transfer(1, 2, 1);
                    board.transfer(2, 1, 1);
                }
                let _ = done_tx.send(board.score(1) + board.score(2));
            })
        };

        // recv_timeout: a deadlock fails here instead of hanging the suite.
        let sum = done_rx
            .recv_timeout(Duration::from_secs(30))
            .expect("match threads hung");
        worker.join().unwrap();
        assert_eq!(sum, 4000);
        assert_eq!(board.total(), 4000);
        assert_eq!(board.score(1) + board.score(2), 4000);
    }
}