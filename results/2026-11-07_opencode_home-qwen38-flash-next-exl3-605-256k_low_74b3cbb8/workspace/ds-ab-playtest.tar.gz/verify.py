import csv
import json
import math
from collections import Counter, defaultdict

rows = list(csv.DictReader(open("telemetry/playtest_ab.csv",
                                newline="", encoding="utf-8-sig")))
print("raw_rows", len(rows))
print("variant_raw", Counter(r["variant"] for r in rows))
print("session_id_raw", Counter(r["session_id"] for r in rows))
print("completed_raw", Counter(r["completed_tutorial"] for r in rows))
print("blank_or_bad", sum(1 for r in rows
                          if not r["session_id"].strip()
                          or r["completed_tutorial"].strip() not in ("0", "1")))

# dedupe on session_id only
first = {}
last = {}
for r in rows:
    sid = r["session_id"].strip()
    first.setdefault(sid, r)
    last[sid] = r
print("unique_sessions", len(first))

# does the first row per session differ from the last on variant/completed?
diff = [s for s in first
        if (first[s]["variant"].strip().lower(), first[s]["completed_tutorial"])
        != (last[s]["variant"].strip().lower(), last[s]["completed_tutorial"])]
print("first_vs_last_diff", len(diff))

def stats(pick):
    agg = defaultdict(lambda: [0, 0])
    for sid, r in pick.items():
        v = r["variant"].strip().lower()
        agg[v][1] += 1
        agg[v][0] += int(r["completed_tutorial"])
    return agg

for name, pick in (("first", first), ("last", last)):
    agg = stats(pick)
    ad, an = agg["a"]
    bd, bn = agg["b"]
    ra, rb = ad / an, bd / bn
    p = (ad + bd) / (an + bn)
    se = math.sqrt(p * (1 - p) * (1 / an + 1 / bn))
    z = (rb - ra) / se
    pv = math.erfc(abs(z) / math.sqrt(2))
    ci = 1.96 * math.sqrt(ra * (1 - ra) / an + rb * (1 - rb) / bn)
    print(name, "a", ad, an, round(ra, 4), "b", bd, bn, round(rb, 4),
          "diff", round(rb - ra, 4), "ci", round(rb - ra - ci, 4),
          round(rb - ra + ci, 4), "z", round(z, 3), "p", round(pv, 6))

res = json.load(open("result.json"))
agg = stats(first)
ad, an = agg["a"]
bd, bn = agg["b"]
assert res["sessions_a"] == an and res["sessions_b"] == bn
assert abs(res["completion_rate_a"] - ad / an) < 5e-5
assert abs(res["completion_rate_b"] - bd / bn) < 5e-5
assert res["p_value"] < 0.05 and res["ship_b"] is True
print("result.json", res)