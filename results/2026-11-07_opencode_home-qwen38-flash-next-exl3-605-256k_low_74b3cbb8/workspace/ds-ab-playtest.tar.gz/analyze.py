import csv
import json
import math
from collections import defaultdict

RAW = "telemetry/playtest_ab.csv"

rows = list(csv.DictReader(open(RAW, newline="", encoding="utf-8-sig")))
raw_rows = len(rows)

# session_id is the unique key; variant needs trim + case fold.
sessions = {}
dirty_variant = 0
dupes = 0
conflicts = []
for r in rows:
    sid = r["session_id"].strip()
    v = r["variant"].strip().lower()
    if r["variant"] != v:
        dirty_variant += 1
    done = int(r["completed_tutorial"])
    if sid in sessions:
        dupes += 1
        prev = sessions[sid]
        if prev[0] != v or prev[1] != done:
            conflicts.append((sid, prev, (v, done)))
    sessions[sid] = (v, done)

counts = defaultdict(lambda: [0, 0])  # variant -> [completed, total]
for v, done in sessions.values():
    counts[v][1] += 1
    counts[v][0] += done

a_done, a_n = counts["a"]
b_done, b_n = counts["b"]
rate_a = a_done / a_n
rate_b = b_done / b_n

# two proportion z test, pooled
p_pool = (a_done + b_done) / (a_n + b_n)
se = math.sqrt(p_pool * (1 - p_pool) * (1 / a_n + 1 / b_n))
z = (rate_b - rate_a) / se
p_value = 2 * (1 - 0.5 * math.erfc(-abs(z) / math.sqrt(2)))

# fisher exact two sided, for cross check
def fisher_p(a, b, c, d):
    n = a + b + c + d
    def logc(x, y):
        return math.lgamma(x + 1) - math.lgamma(y + 1) - math.lgamma(x - y + 1)
    def prob(x, y):
        return math.exp(-logc(n, a + c) + logc(a + b, x)
                        + logc(n - a - b, a + c - x))
    p_obs = prob(a, b)
    total = 0.0
    for x in range(0, min(a + c, n) + 1):
        y = (a + b) - x
        if 0 <= y <= b + d:
            p = prob(x, y)
            if p <= p_obs * (1 + 1e-9):
                total += p
    return min(1.0, total)

p_fisher = fisher_p(b_done, b_n - b_done, a_done, a_n - a_done)

ship_b = (b_done / b_n) > (a_done / a_n) and p_value < 0.05

out = {
    "ship_b": ship_b,
    "sessions_a": a_n,
    "sessions_b": b_n,
    "completion_rate_a": round(rate_a, 4),
    "completion_rate_b": round(rate_b, 4),
    "p_value": round(p_value, 4),
}
json.dump(out, open("result.json", "w", encoding="utf-8"), indent=2)

print("raw_rows", raw_rows, "dupes", dupes, "dirty_variant", dirty_variant,
      "conflicts", len(conflicts), conflicts[:5])
print("variants", dict(counts))
print("z", round(z, 4), "p", round(p_value, 4), "fisher_p", round(p_fisher, 4))
print(json.dumps(out))