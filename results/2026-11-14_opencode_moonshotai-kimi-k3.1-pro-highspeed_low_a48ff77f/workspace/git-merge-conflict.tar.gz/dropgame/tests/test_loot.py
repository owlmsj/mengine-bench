import unittest

from loot import LootTable


class DropTest(unittest.TestCase):
    def test_a_low_roll_drops_a_rare(self) -> None:
        self.assertEqual(LootTable().drop(0.01), "rare")

    def test_a_high_roll_drops_a_common(self) -> None:
        self.assertEqual(LootTable().drop(0.5), "common")
