import unittest

from loot import LootTable


class EventTest(unittest.TestCase):
    def test_the_event_raises_the_rare_chance(self) -> None:
        self.assertEqual(LootTable(event_multiplier=2.0).drop(0.08), "rare")
        self.assertEqual(LootTable().drop(0.08), "common")
