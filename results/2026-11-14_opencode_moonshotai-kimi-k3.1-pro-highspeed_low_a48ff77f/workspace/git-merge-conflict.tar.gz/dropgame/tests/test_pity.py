import unittest

from loot import PITY_LIMIT, LootTable


class PityTest(unittest.TestCase):
    def test_the_drop_after_the_limit_is_rare(self) -> None:
        table = LootTable()
        drops = [table.drop(0.99) for _ in range(PITY_LIMIT + 1)]
        self.assertEqual(drops, ["common"] * PITY_LIMIT + ["rare"])
