"""Run awaitable jobs with a fixed concurrency limit."""

import asyncio
from collections.abc import Awaitable, Callable, Iterable
from typing import TypeVar

T = TypeVar("T")
TaskFactory = Callable[[], Awaitable[T]]


async def run_tasks(
    tasks: Iterable[TaskFactory[T]], max_concurrent: int
) -> list[T | None]:
    """Run every task factory and return results in input order.

    At most ``max_concurrent`` factories have active jobs at once. If this
    coroutine is cancelled (as by Ctrl+C under ``asyncio.run``), active jobs
    are cancelled and awaited so their ``finally`` blocks can finish. No new
    jobs are started after cancellation. A factory or job failure likewise
    stops and cleans up the other workers before the exception is re-raised.

    ``tasks`` may be any finite iterable. Results for jobs not completed after
    a failure or cancellation are irrelevant because an exception is raised.
    """
    if not isinstance(max_concurrent, int) or isinstance(max_concurrent, bool):
        raise TypeError(f"max_concurrent must be an int, got {max_concurrent!r}")
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be at least 1, got {max_concurrent!r}")

    indexed_tasks = iter(enumerate(tasks))
    results: list[T | None] = []

    async def worker() -> None:
        while True:
            try:
                index, factory = next(indexed_tasks)
            except StopIteration:
                return
            results.append(None)
            results[index] = await factory()

    workers = [asyncio.create_task(worker()) for _ in range(max_concurrent)]
    try:
        await asyncio.gather(*workers)
    except BaseException:
        for worker_task in workers:
            worker_task.cancel()
        await asyncio.gather(*workers, return_exceptions=True)
        raise
    return results
