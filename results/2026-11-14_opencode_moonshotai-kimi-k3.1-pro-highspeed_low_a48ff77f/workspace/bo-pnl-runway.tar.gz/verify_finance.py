import csv
import json
from collections import Counter, defaultdict
from decimal import Decimal

result = json.load(open("result.json", encoding="utf-8"))
coa = {
    row["account"]: row["pnl_line"]
    for row in csv.DictReader(open("finance/chart_of_accounts.csv", encoding="utf-8-sig"), delimiter=";")
}
rows = list(csv.DictReader(open("finance/ledger.csv", encoding="utf-8-sig"), delimiter=";"))
assert len(rows) == 86
assert all(row["account"] in coa for row in rows)
assert Counter(row["date"][3:] for row in rows) == Counter({
    "01/2026": 14, "02/2026": 14, "03/2026": 15,
    "04/2026": 14, "05/2026": 15, "06/2026": 14,
})
monthly = defaultdict(lambda: defaultdict(Decimal))
for row in rows:
    month = "2026-" + row["date"][3:5]
    amount = Decimal(row["amount"].replace(".", "").replace(",", "."))
    monthly[month][coa[row["account"]]] += amount
for month, values in monthly.items():
    assert float(values["revenue"]) == result["revenue"][month]
    margin = round((values["revenue"] + values["cogs"]) / values["revenue"] * 100, 2)
    assert float(margin) == result["gross_margin_pct"][month]
    ebitda = sum(values[line] for line in ("revenue", "cogs", "sales_marketing", "rnd", "ga"))
    assert float(ebitda) == result["ebitda"][month]
ebitda = result["ebitda"]
burn = round(-sum(ebitda[f"2026-{month:02d}"] for month in (4, 5, 6)) / 3, 2)
assert burn == result["burn"]
assert round(1847350.40 / burn, 2) == result["runway_months"]
print("PASS: all 86 ledger rows mapped to known accounts; monthly coverage 14/14/15/14/15/14; all 18 monthly outputs, burn and runway independently recomputed.")
