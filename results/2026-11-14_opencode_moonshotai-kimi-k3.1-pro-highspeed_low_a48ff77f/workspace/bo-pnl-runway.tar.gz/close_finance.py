import csv
import json
from collections import defaultdict
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

ROOT = Path(__file__).parent
MONTHS = [f"2026-{month:02d}" for month in range(1, 7)]
CENT = Decimal("0.01")


def money(value):
    return Decimal(value.replace(".", "").replace(",", "."))


def rounded(value):
    return value.quantize(CENT, rounding=ROUND_HALF_UP)


lines = {}
with (ROOT / "finance" / "chart_of_accounts.csv").open(encoding="utf-8-sig", newline="") as source:
    for row in csv.DictReader(source, delimiter=";"):
        lines[row["account"]] = row["pnl_line"]

monthly = defaultdict(lambda: defaultdict(Decimal))
with (ROOT / "finance" / "ledger.csv").open(encoding="utf-8-sig", newline="") as source:
    for row in csv.DictReader(source, delimiter=";"):
        month = datetime.strptime(row["date"], "%d/%m/%Y").strftime("%Y-%m")
        if month in MONTHS:
            monthly[month][lines[row["account"]]] += money(row["amount"])

revenue = {}
gross_margin_pct = {}
ebitda = {}
operating_lines = {"revenue", "cogs", "sales_marketing", "rnd", "ga"}
for month in MONTHS:
    values = monthly[month]
    revenue[month] = rounded(values["revenue"])
    gross_margin_pct[month] = rounded((values["revenue"] + values["cogs"]) / values["revenue"] * 100)
    ebitda[month] = rounded(sum(values[line] for line in operating_lines))

burn = rounded(-sum(Decimal(ebitda[month]) for month in MONTHS[-3:]) / 3)
cash_text = (ROOT / "finance" / "cash_balance.txt").read_text(encoding="utf-8")
cash = money(cash_text.split("30/06/2026: R$ ")[1].strip())
runway_months = rounded(cash / burn)
result = {
    "revenue": revenue,
    "gross_margin_pct": gross_margin_pct,
    "ebitda": ebitda,
    "burn": burn,
    "runway_months": runway_months,
}


def json_number(value):
    return float(value) if value == value.to_integral() else float(value)


class FinanceEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return json_number(obj)
        return super().default(obj)


(ROOT / "result.json").write_text(json.dumps(result, indent=2, cls=FinanceEncoder) + "\n", encoding="utf-8")

report = [
    "# CFO close: first half 2026",
    "",
    "All monetary amounts are BRL. Revenue is net of refunds; gross margin is (revenue less COGS) / revenue. EBITDA includes revenue, COGS, sales and marketing, R&D, and G&A, and excludes investment income, interest and IOF tax.",
    "",
    "| Month | Revenue | Gross margin | EBITDA |",
    "|---|---:|---:|---:|",
]
for month in MONTHS:
    report.append(f"| {month} | {revenue[month]:,.2f} | {gross_margin_pct[month]:.2f}% | {ebitda[month]:,.2f} |")
report += [
    "",
    f"Current burn is BRL {burn:,.2f} per month: the average negative EBITDA for April, May and June 2026.",
    f"Closing cash on 30 June 2026 is BRL {cash:,.2f}; runway is {runway_months:.2f} months at that burn.",
    "",
    "Source: finance/ledger.csv classified with finance/chart_of_accounts.csv; burn, runway and closing cash follow finance/README.md and finance/cash_balance.txt.",
]
(ROOT / "cfo_summary.md").write_text("\n".join(report) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2, cls=FinanceEncoder))
