# CFO close: first half 2026

All monetary amounts are BRL. Revenue is net of refunds; gross margin is (revenue less COGS) / revenue. EBITDA includes revenue, COGS, sales and marketing, R&D, and G&A, and excludes investment income, interest and IOF tax.

| Month | Revenue | Gross margin | EBITDA |
|---|---:|---:|---:|
| 2026-01 | 200,510.87 | 70.03% | -210,278.96 |
| 2026-02 | 216,328.06 | 70.29% | -212,300.08 |
| 2026-03 | 219,066.17 | 68.46% | -204,525.45 |
| 2026-04 | 238,163.26 | 70.24% | -196,950.65 |
| 2026-05 | 243,032.89 | 69.56% | -201,945.82 |
| 2026-06 | 272,391.57 | 72.41% | -192,968.22 |

Current burn is BRL 197,288.23 per month: the average negative EBITDA for April, May and June 2026.
Closing cash on 30 June 2026 is BRL 1,847,350.40; runway is 9.36 months at that burn.

Source: finance/ledger.csv classified with finance/chart_of_accounts.csv; burn, runway and closing cash follow finance/README.md and finance/cash_balance.txt.
