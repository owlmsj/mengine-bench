# Handoff: local-9b at 128k

Goal: make local-9b Q5 run at 131072 context without WDDM shared-memory spill.

Done: initial run gave 37.8 t/s but was invalid: 7881 MiB was the WDDM ceiling and Shared Usage showed 1494 MiB spilled. Adding `--no-mmproj-offload` and `-ub 512` removed spill; final VRAM 7697 MiB, decode 38.0 t/s (median of 3). Recipe applied in `scripts/start_server.ps1:165` (local9 block) and `profiles/local/local-9b.json`.

Alternatives: Q6_K (7.03 GiB) does not fit at 128k; discarded. Q4_K_M fits at 7305 MiB and 40.4 t/s; fallback only.

Next: update evals README; it still references removed `check_vision.ps1`. Also review scratchpad temp filenames if still relevant. Re-run the full-context decode measurement after any config change and check Dedicated + Shared GPU memory, not just the WDDM-capped counter.

Assumption: no unrecorded work exists; status is based solely on the supplied transcript. No apps were opened.
