from PIL import Image
from pypdf import PdfReader, PdfWriter
from pypdf.generic import ArrayObject, DecodedStreamObject, NameObject, NumberObject
im=Image.open('launch.jpg')
im.crop((900,0,1966,1333)).resize((1080,1350),Image.Resampling.LANCZOS).save('out/feed-photo.jpg','JPEG',quality=95,subsampling=0)
r=PdfReader('permit-form.pdf'); w=PdfWriter(); w.clone_document_from_reader(r)
w.update_page_form_field_values(w.pages[0], {'organizer':'Tidewater Studio','event_date':'2026-12-05','location':'North Cove Lawn','attendees':'40'}, auto_regenerate=False)
p=w.pages[0]
annots=p.get('/Annots',[])
for ref in list(annots):
 a=ref.get_object(); ap=a['/AP']['/N'].get_object(); rect=a['/Rect']
 stream=DecodedStreamObject(); stream.set_data(b'q\n1 0 0 1 '+str(float(rect[0])).encode()+b' '+str(float(rect[1])).encode()+b' cm\n'+ap.get_data()+b'\nQ\n')
 pref=w._add_object(stream)
 contents=p.get('/Contents')
 if not isinstance(contents,ArrayObject):
  arr=ArrayObject(); arr.append(contents); arr.append(pref); p[NameObject('/Contents')]=arr
 else: contents.append(pref)
del p['/Annots']
if '/AcroForm' in w._root_object: del w._root_object['/AcroForm']
with open('out/permit-filled.pdf','wb') as f:w.write(f)
print('created')
