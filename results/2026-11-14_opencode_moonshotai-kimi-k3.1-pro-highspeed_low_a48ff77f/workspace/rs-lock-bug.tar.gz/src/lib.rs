//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        *slot.lock().unwrap() += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return;
        }

        let from_slot = self.slot(from);
        let to_slot = self.slot(to);
        let (mut from_score, mut to_score) = if from < to {
            let from_score = from_slot.lock().unwrap();
            let to_score = to_slot.lock().unwrap();
            (from_score, to_score)
        } else {
            let to_score = to_slot.lock().unwrap();
            let from_score = from_slot.lock().unwrap();
            (from_score, to_score)
        };
        *from_score -= points;
        *to_score += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}

#[cfg(test)]
mod tests {
    use super::Board;
    use std::thread;

    #[test]
    fn concurrent_operations_preserve_scores_and_do_not_deadlock() {
        let board = Board::new();
        board.join(1, 0);
        board.join(2, 0);
        board.transfer(1, 1, 5);

        let mut workers = Vec::new();
        for worker in 0..8 {
            let board = board.clone();
            workers.push(thread::spawn(move || {
                for _ in 0..1_000 {
                    board.award(1, 1);
                    if worker % 2 == 0 {
                        board.transfer(1, 2, 1);
                    } else {
                        board.transfer(2, 1, 1);
                    }
                }
            }));
        }
        for worker in workers {
            worker.join().unwrap();
        }

        assert_eq!(board.score(1) + board.score(2), 8_000);
        assert_eq!(board.total(), 8_000);
    }
}
