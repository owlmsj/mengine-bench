Use any skill, tool or MCP server you have. Write local files only inside this directory.
You may read installed tools and skills outside it, but not other task workspaces, runs or benchmark answers.
Other programs run on this machine: stop only the processes you started, by their id, never by name.
Do not print credentials, environment variables or personal data: this session is published.
