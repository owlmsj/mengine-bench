import pathlib,re,json,html
from collections import defaultdict
site=pathlib.Path('site'); words={}; themes={}
for p in site.glob('*.html'):
 s=p.read_text(encoding='utf-8')
 m=re.search(r'<main>.*?<h1>(.*?)</h1>(.*?)</main>',s,re.S|re.I)
 if not m: continue
 w=html.unescape(re.sub('<[^>]+>','',m.group(1))).strip().lower()
 if w=='dicionário criativo': continue
 words.setdefault(w,set())
 tm=re.search(r'class="tema">Tema:\s*([^<]+)',m.group(2),re.I)
 if tm: themes[w]=html.unescape(tm.group(1)).strip()
 for sec in re.findall(r'<section id="(?:sinonimos|analogas)".*?</section>',m.group(2),re.S|re.I):
  for a in re.findall(r'<a\b[^>]*>(.*?)</a>',sec,re.S|re.I):
   v=html.unescape(re.sub('<[^>]+>','',a)).strip().lower()
   if v!=w: words[w].add(v)
# keep links to collected dictionary entries, make symmetric
words={w:{v for v in vs if v in words} for w,vs in words.items()}
for w,vs in list(words.items()):
 for v in vs: words[v].add(w)
data={w:sorted(words[w]) for w in sorted(words)}
pairs={tuple(sorted((w,v))) for w,vs in data.items() for v in vs}
rank=sorted(data,key=lambda w:(-len(data[w]),w))
pathlib.Path('words.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
pathlib.Path('result.json').write_text(json.dumps({'words':len(data),'relations':len(pairs),'most_connected':rank[0]},ensure_ascii=False,indent=2),encoding='utf-8')
pathlib.Path('tmp').mkdir(exist_ok=True)
pathlib.Path('tmp/themes.json').write_text(json.dumps(themes,ensure_ascii=False),encoding='utf-8')
print(len(data),len(pairs),rank[:5],[(w,len(data[w])) for w in rank[:5]])
