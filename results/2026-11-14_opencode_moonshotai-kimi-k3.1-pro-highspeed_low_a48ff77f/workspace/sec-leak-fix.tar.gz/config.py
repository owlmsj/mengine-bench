"""Settings for the backup agent."""

import os

API_URL = "https://backup.example.invalid/v1/upload"
API_TOKEN = [REDACTED:env]"BACKUP_TOKEN"]
ARCHIVE_DIR = "archives"
