const fs=require('fs'),{pathToFileURL}=require('url'),path=require('path');
(async()=>{const [port,browserPath]=fs.readFileSync('tmp/edge/DevToolsActivePort','utf8').trim().split(/\r?\n/);
async function connect(url){let w=new WebSocket(url);await new Promise(r=>w.onopen=r);let id=0,m=new Map();w.onmessage=e=>{const d=JSON.parse(e.data);if(m.has(d.id)){m.get(d.id)(d.result);m.delete(d.id)}};return (method,params={})=>new Promise(r=>{m.set(++id,r);w.send(JSON.stringify({id,method,params}))})}
let close=await connect('ws://127.0.0.1:'+port+browserPath);
try{let tabs=await (await fetch('http://127.0.0.1:'+port+'/json/list')).json(),call=await connect(tabs.find(x=>x.type==='page').webSocketDebuggerUrl);
await call('Page.navigate',{url:pathToFileURL(path.resolve('landing/index.html')).href});await new Promise(r=>setTimeout(r,300));
for(let width of [1440,390]){await call('Emulation.setDeviceMetricsOverride',{width,height:900,deviceScaleFactor:1,mobile:false});let {result}=await call('Runtime.evaluate',{expression:"JSON.stringify({width:innerWidth,overflow:document.documentElement.scrollWidth>innerWidth,headings:[...document.querySelectorAll('h1,h2')].map(x=>x.innerText.replace(/\\n/g,' ')),links:[...document.links].every(a=>a.hash?!!document.querySelector(a.hash):a.href==='https://en.wikipedia.org/wiki/Composition_with_Red,_Blue_and_Yellow')})"});console.log(result.value);if(width===1440){let s=await call('Page.captureScreenshot',{format:'jpeg',quality:65});fs.writeFileSync('tmp/desktop.jpg',Buffer.from(s.data,'base64'))}}
}finally{await close('Browser.close')}})()
