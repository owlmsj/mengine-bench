function boats() {
  const ink = "#192f43", rail = "#eed2a0", warm = "#c88b5f";
  function vessel(a, b, c, size, z, timber, crewStart, crewEnd) {
    // A quadratic sheer line keeps the long gunwales continuous around the swell.
    function frame(t) {
      const s = 1-t;
      const dx = 2*(s*(b[0]-a[0])+t*(c[0]-b[0]));
      const dy = 2*(s*(b[1]-a[1])+t*(c[1]-b[1]));
      const length = Math.hypot(dx,dy);
      return [s*s*a[0]+2*s*t*b[0]+t*t*c[0],s*s*a[1]+2*s*t*b[1]+t*t*c[1],dx/length,dy/length];
    }
    function beam(t) {return size*Math.pow(Math.max(0,Math.sin(Math.PI*t)),.72);}
    function pt(t, across) {
      const [x,y,tx,ty]=frame(t);
      return [x-ty*across,y+tx*across];
    }
    function ribbon(t0,t1,lo,hi,color,layer,steps) {
      const edge = [], reverse = [];
      for (let i=0;i<=steps;i++) {
        const t=t0+(t1-t0)*i/steps;
        edge.push(pt(t,lo(t)));
        reverse.push(pt(t,hi(t)));
      }
      poly(edge.concat(reverse.reverse()),color,z+layer);
    }
    const width = n => t => beam(t)*n;
    ribbon(0,1,width(-.23),width(1.02),ink,0,24);
    ribbon(.004,.996,width(-.16),width(.94),timber,.05,24);
    ribbon(.015,.988,width(.66),width(.92),warm,.12,20);
    ribbon(.02,.98,width(.84),width(.96),"#9e7157",.14,19);
    for(let i=0;i<11;i++){
      let t=.06+i*.078;
      poly([pt(t,beam(t)*.64),pt(t+.069,beam(t+.069)*.64),pt(t+.041,beam(t+.041)*.91)],mix(warm,timber,.2+rand()*.6),z+.17);
    }
    ribbon(.05,.95,width(.61),width(.636),"#916e54",.2,20);
    // Recessed deck, far rail and timber thwarts.
    ribbon(.09,.94,width(-.12),width(.32),"#735b47",.24,24);
    ribbon(.12,.91,width(-.08),width(.16),"#ae9271",.26,21);
    ribbon(.025,.972,width(-.18),width(-.115),rail,.28,20);
    for(let i=0;i<18;i++) {
      const t=.14+.042*i;
      poly([pt(t,-beam(t)*.1),pt(t+.008,-beam(t)*.1),pt(t+.015,beam(t)*.27),pt(t+.003,beam(t)*.27)],i%3?"#d6bd90":"#f1dca9",z+.3);
    }
    // Short raised bamboo cargo cover below the bow.
    const coverStart=.18, coverEnd=.40;
    ribbon(coverStart,coverEnd,width(-.18),width(.24),"#324754",.32,6);
    ribbon(coverStart+.008,coverEnd-.008,width(-.15),width(.17),"#dfc699",.33,6);
    for(let i=0;i<11;i++){
      const t=coverStart+.014+i*.018;
      poly([pt(t,-beam(t)*.14),pt(t+.003,-beam(t)*.14),pt(t+.012,beam(t)*.16),pt(t+.008,beam(t)*.16)],"#736f60",z+.34);
    }
    // Hunched sailors face the bow, hands tucked around the inboard rail.
    for(let i=0;i<8;i++){
      const t=crewStart+(crewEnd-crewStart)*i/7;
      const [x,y,tx,ty]=frame(t), scale=size*.029*(.87+rand()*.17);
      function local(shape,color,layer) {
        poly(shape.map(([u,v])=>[x+scale*(u*tx-v*ty),y+scale*(u*ty+v*tx)]),color,z+.38+i*.011+layer);
      }
      local([[-10,1],[-7,-7],[-1,-12],[5,-13],[10,-9],[13,-2],[9,2]],ink,0);
      local([[-6,-5],[-1,-11],[4,-12],[8,-9],[5,-4],[0,0]],i%3===1?"#365d76":"#244a68",.001);
      local([[1,-10],[5,-12],[9,-8],[5,-7]],"#54778a",.002);
      local([[-5,-8],[-8,-9],[-11,-6],[-11,-2],[-8,0],[-4,-2]],"#dcb48d",.003);
      local([[-8,-8],[-10,-6],[-10,-3],[-7,-2],[-5,-5]],"#f1d7ac",.004);
      local([[-11,-6],[-10,-9],[-7,-10],[-4,-8],[-5,-7],[-8,-8]],ink,.005);
      local([[0,-3],[-4,1],[-10,4],[-11,3],[-5,-1],[-3,-4]],"#d5b188",.006);
    }
    ribbon(.035,.965,width(.25),width(.32),ink,.57,24);
    ribbon(.045,.955,width(.27),width(.299),rail,.59,24);
    for (let i=0;i<13;i++){
      const t=.13+i*.061, h=beam(t);
      poly([pt(t,h*.39),pt(t+.0028,h*.36),pt(t+.006,h*.43),pt(t+.003,h*.48)],"#77654f",z+.61);
    }
  }
  vessel([36,406],[118,592],[422,579],29,35,"#d8b282",.60,.88);
  vessel([706,593],[940,730],[1169,447],22,14,"#e8bb88",.66,.88);
  vessel([518,650],[710,870],[1093,718],32,46,"#e5aa7d",.69,.89);
}
