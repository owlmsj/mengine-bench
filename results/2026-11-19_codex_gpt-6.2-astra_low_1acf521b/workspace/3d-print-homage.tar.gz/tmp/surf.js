function surf() {
  const ink = '#173c58', deep = '#214d6c', denim = '#316582';
  const blue = '#4d8498', aqua = '#97c2c2', mist = '#c9d9c9';
  const cream = '#f5edd6', chalk = '#fff6e1';
  function profile(nodes, x) {
    let i = 1;
    while (i < nodes.length - 1 && x > nodes[i][0]) i++;
    const a = nodes[i - 1], b = nodes[i];
    return a[1] + (b[1] - a[1]) * (x - a[0]) / (b[0] - a[0]);
  }
  function swell(nodes, floor, z, bands, spacing, phase) {
    const xs = nodes.map(p => p[0]);
    for (let x = nodes[0][0] + 13; x < nodes[nodes.length - 1][0]; x += spacing * (.7 + rand() * .6)) xs.push(x);
    xs.sort((a,b) => a-b);
    const columns = xs.map(x => {
      const top = profile(nodes,x);
      return bands.map(([fraction],j) => {
        const wiggle = Math.sin(fraction * Math.PI) * (6 * Math.sin(x / 61 + phase + j*.65) + 4 * Math.sin(x / 117 - j*.41));
        return [x, top + fraction * (floor - top) + wiggle, .42 * Math.sin(Math.PI*fraction) * Math.cos(x/92 + phase)];
      });
    });
    for (let i=1;i<columns.length;i++) {
      for (let j=0;j<bands.length-1;j++) {
        const a=columns[i-1][j], b=columns[i][j], c=columns[i][j+1], d=columns[i-1][j+1];
        const tone=bands[j][1], amount=.04+.085*rand();
        poly([a,b,d], mix(tone, rand()>.51?chalk:ink,amount), z);
        poly([b,c,d], mix(tone, rand()>.51?chalk:ink,amount*.8), z);
      }
    }
  }
  // Tapered woodcut strokes follow the curving face between successive ridges.
  function streaks(nodes,floor,z,num,colors) {
    for (let i=0;i<num;i++) {
      const x=nodes[0][0]+rand()*(nodes[nodes.length-1][0]-nodes[0][0]);
      const length=17+Math.pow(rand(),1.5)*96, t=.03+rand()*.76;
      const h=1+rand()*3.5, p=[];
      for(let k=0;k<5;k++) {
        const u=k/4, xx=x+u*length;
        const top=profile(nodes,xx);
        p.push([xx,top+(floor-top)*t+Math.sin(u*Math.PI)*h]);
      }
      const tone=colors[Math.floor(rand()*colors.length)];
      for(let j=0;j<4;j++) {
        const a=p[j], b=p[j+1];
        poly([a,b,[b[0],b[1]+Math.sin((j+1)*Math.PI/4)*h],[a[0],a[1]+Math.sin(j*Math.PI/4)*h]],tone,z);
      }
    }
  }
  const distant=[[-48,567],[100,585],[300,605],[530,635],[658,639],[712,622],[786,618],[886,630],[982,601],[1061,561],[1131,495],[1206,402],[1280,340],[1330,310]];
  swell(distant,925,5,[[0,ink],[.012,cream],[.07,mist],[.10,cream],[.18,aqua],[.23,deep],[.31,cream],[.40,denim],[.47,ink],[.60,aqua],[.69,deep],[1,deep]],35,.3);
  streaks(distant,925,6,71,[cream,ink,aqua]);
  const middle=[[-42,636],[16,649],[72,644],[123,637],[191,629],[242,618],[298,590],[349,558],[391,513],[417,486],[432,480],[445,483],[463,497],[495,507],[525,537],[551,561],[590,580],[617,590],[650,621],[687,641],[729,656],[773,668],[829,675],[888,677],[957,669],[1029,650],[1104,624],[1170,606],[1234,578],[1328,523]];
  swell(middle,923,40,[[0,cream],[.052,chalk],[.13,mist],[.175,cream],[.235,aqua],[.29,cream],[.36,blue],[.41,denim],[.49,ink],[.57,deep],[.64,blue],[.695,mist],[.725,cream],[.78,deep],[.88,ink],[1,deep]],35,2.4);
  streaks(middle,923,41,94,[cream,mist,denim,ink]);

  // Small hooked caps divide the froth on the near side of the peak.
  function hook(x,y,s,angle,z) {
    const point=(u,v) => [x+s*(u*Math.cos(angle)-v*Math.sin(angle)),y+s*(u*Math.sin(angle)+v*Math.cos(angle))];
    const draw=(path,color,d) => poly(path.map(p=>point(...p)),color,z+d);
    draw([[-16,10],[-13,2],[-7,-5],[1,-9],[8,-8],[12,-3],[11,2],[7,6],[8,1],[5,-2],[1,-2],[-3,2],[-5,9]],ink,0);
    draw([[-19,12],[-15,2],[-10,-6],[-1,-11],[6,-11],[10,-7],[12,-3],[8,-6],[3,-7],[-2,-4],[-6,1],[-9,9]],chalk,.02);
    draw([[-19,12],[-15,2],[-10,-6],[-6,-8],[-10,-2],[-12,5]],aqua,.03);
  }
  const near=[[-48,661],[15,646],[62,642],[96,641],[134,623],[163,621],[195,633],[231,636],[257,645],[282,657],[300,664],[327,655],[348,634],[377,622],[396,605],[411,599],[430,591],[448,560],[462,569],[480,612],[503,641],[520,658],[539,690],[564,733],[587,771],[618,799],[655,820],[698,837],[756,843],[808,839],[867,829],[923,812],[971,798],[1025,774],[1080,737],[1131,702],[1177,653],[1224,614],[1281,570],[1332,548]];
  swell(near,940,50,[[0,cream],[.056,chalk],[.13,mist],[.17,cream],[.234,aqua],[.285,cream],[.34,denim],[.39,ink],[.50,deep],[.54,blue],[.63,cream],[.676,aqua],[.72,deep],[.83,denim],[.91,ink],[1,deep]],31,1.2);
  streaks(near,940,51,95,[cream,aqua,ink,denim]);
  // Irregular curling foam is dense on the near left crest, sparse in the trough.
  for(let i=0;i<121;i++) {
    const x=-18+rand()*550;
    const t=rand(), y=profile(near,x)+4+t*(45+54*Math.sin(x/126+1)**2);
    const size=(.32+rand()*.80)*(1-.23*t);
    hook(x,y,size,-.55+rand()*1.22,52);
    if(rand()>.48) hook(x-8*size,y+3*size,size*.52,-.66+rand()*.72,52.1);
  }
}
