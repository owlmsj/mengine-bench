const {spawn}=require('node:child_process'),fs=require('node:fs'),path=require('node:path'),{pathToFileURL}=require('node:url');
const delay=t=>new Promise(r=>setTimeout(r,t));
(async()=>{const dir=path.resolve('tmp/edge2');fs.mkdirSync(dir,{recursive:true});
const p=fs.existsSync(dir+'/DevToolsActivePort')?null:spawn('C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',['--headless=new','--disable-gpu','--disable-extensions','--no-first-run','--disable-background-networking','--remote-debugging-port=0','--user-data-dir='+dir,'--window-size=1280,940','about:blank'],{windowsHide:true,stdio:'ignore'});
let browser;
try{let port;for(let i=0;i<100&&!port;i++){await delay(100);try{port=fs.readFileSync(dir+'/DevToolsActivePort','utf8').split(/\s+/)[0]}catch{}}
async function connect(url){let sock=new WebSocket(url),seq=0,h=new Map();await new Promise(r=>sock.onopen=r);sock.onmessage=e=>{let a=JSON.parse(e.data);if(h.has(a.id)){h.get(a.id)(a.result);h.delete(a.id)}};return (method,params={})=>new Promise(r=>{h.set(++seq,r);sock.send(JSON.stringify({id:seq,method,params}))})}
let base='http://127.0.0.1:'+port;browser=await connect((await(await fetch(base+'/json/version')).json()).webSocketDebuggerUrl);
let tab=await connect((await(await fetch(base+'/json/new?about:blank',{method:'PUT'})).json()).webSocketDebuggerUrl);
await tab('Emulation.setDeviceMetricsOverride',{width:1280,height:860,deviceScaleFactor:1,mobile:false});await tab('Page.navigate',{url:pathToFileURL(path.resolve('scene/index.html')).href});await delay(750);
async function ev(expression){let a=await tab('Runtime.evaluate',{expression,returnByValue:true});return a.result.value??a.exceptionDetails?.exception?.description}
console.log('Scene:',await ev("JSON.stringify({faces:faces.length,depthGroups:groups.length,width:art.width,height:art.height})"));
let a=await ev('art.toDataURL()');await delay(380);console.log('Distinct animated frames:',a!==await ev('art.toDataURL()'));await ev('control.click()');await delay(120);let b=await ev('art.toDataURL()');await delay(180);console.log('Paused frame stable:',b===await ev('art.toDataURL()'));
let shot=await tab('Page.captureScreenshot',{format:'jpeg',quality:85});fs.writeFileSync('tmp/review.jpg',Buffer.from(shot.data,'base64'));
console.log('Metadata:',fs.readFileSync('result.json','utf8').trim().replace(/\s+/g,' '));
}finally{if(browser)await browser('Browser.close');else p.kill()}})().catch(e=>{console.error(e);process.exitCode=1})


