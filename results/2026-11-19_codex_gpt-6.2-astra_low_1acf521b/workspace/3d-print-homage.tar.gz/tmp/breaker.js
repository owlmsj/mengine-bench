function breaker() {
  const ink = "#173958", deepest = "#173e61", ocean = "#205778";
  const warm = "#fff2d3", chalk = "#f9f1d7", ice = "#c4dacf", pale = "#dee6d5";
  const draw = (p,c,z) => poly(p,c,z);
  const lerp = (a,b,t) => a+(b-a)*t;
  function curve(pts,t) {
    const s=Math.max(0,Math.min(t,1))*(pts.length-1), i=Math.min(pts.length-2,Math.floor(s)), f=s-i;
    const a=pts[Math.max(0,i-1)], b=pts[i], c=pts[i+1], d=pts[Math.min(pts.length-1,i+2)];
    return [0,1].map(k=>0.5*(2*b[k]+(-a[k]+c[k])*f+(2*a[k]-5*b[k]+4*c[k]-d[k])*f*f+(-a[k]+3*b[k]-3*c[k]+d[k])*f*f*f));
  }
  const crest=[[-100,373],[6,357],[108,317],[185,282],[260,249],[324,221],[386,190],[445,173],[495,176],[527,196],[565,242]];
  const foot=[[-190,633],[-40,633],[92,641],[205,646],[326,629],[429,606],[497,608],[556,622],[615,643],[666,659],[729,677]];
  function surface(u,v) {
    const a=curve(crest,u), b=curve(foot,u), d=Math.sin(v*Math.PI);
    const sweep=d*(80+u*42);
    return [lerp(a[0],b[0],v)-sweep,lerp(a[1],b[1],v)+d*(13-19*u),1.15*d*Math.sin(u*26)+2*d];
  }
  const us=[0,.037,.082,.115,.166,.21,.247,.295,.337,.39,.44,.476,.52,.566,.60,.651,.69,.747,.785,.825,.864,.911,.949,1];
  const vs=[0,.13,.28,.47,.66,.83,1];
  const colors=["#1c496b","#205677","#295f80","#1d486a","#234c6e","#1d4365","#286384","#193e60"];
  const lattice=us.map((u,i)=>vs.map((v,j)=>surface(u+(i>0&&i<us.length-1&&j>0&&j<vs.length-1?(rand()-.5)*.025:0),v+(j>0&&j<vs.length-1?(rand()-.5)*.06:0))));
  for(let i=0;i<us.length-1;i++) {
    const c=colors[i%colors.length];
    for(let j=0;j<vs.length-1;j++) {
      const a=lattice[i][j], b=lattice[i+1][j], d=lattice[i][j+1], e=lattice[i+1][j+1];
      draw([a,b,d],mix(c,"#81a6a6",rand()*.14),20);
      draw([b,e,d],mix(c,"#0d2f52",rand()*.25),20);
    }
  }
  // Long unbroken cuts follow the folded face of the wave.
  for(let i=0;i<15;i++) {
    const u=.035+i*.065, w=.003+rand()*.012, start=.02+rand()*.22, end=.68+rand()*.3;
    const c=i%3===0?"#5a93a1":i%3===1?"#337793":"#183d60";
    let a=surface(u,start), b=a;
    for(let j=1;j<=9;j++){
      const k=j/9,v=lerp(start,end,k), q=u+Math.sin(k*5+i)*.007;
      const h=surface(q,v), l=surface(q+w*Math.sin(k*Math.PI),v);
      draw([a,b,l,h],c,22); a=h;b=l;
    }
  }
  const outer=[[-110,358],[-22,354],[69,329],[142,267],[208,194],[272,143],[338,105],[404,85],[468,76],[515,81],[560,103],[605,132],[635,160],[647,190],[676,211],[708,226],[739,252],[752,284],[741,303],[719,305],[687,292],[657,277],[625,263],[592,253],[563,244]];
  const underside=[[-110,377],[-22,367],[69,336],[142,304],[208,273],[272,248],[308,227],[348,205],[387,187],[424,174],[461,168],[488,174],[513,184],[533,201],[549,222],[568,242],[594,264],[620,281],[649,306],[670,328],[690,338],[711,350],[727,357],[705,317],[563,244]];
  // A raised, folded snow-white mantle, drawn in irregular triangular planes.
  const rows=[];
  for(let i=0;i<outer.length;i++){
    const a=outer[i], b=underside[i], t=.34+rand()*.28;
    rows.push([a,[lerp(a[0],b[0],t),lerp(a[1],b[1],t),2+rand()*2],b]);
  }
  for(let i=0;i<rows.length-1;i++){
    const a=rows[i],b=rows[i+1];
    for(let j=0;j<2;j++){
      const c=j===0?warm:chalk;
      draw([a[j],b[j],a[j+1]],mix(c,j===0?"#d7d9be":ice,rand()*(j===0?.29:.62)),24);
      draw([b[j],b[j+1],a[j+1]],mix(c,ice,rand()*.66),24);
    }
  }
  function shard(x,y,w,h,c,z=28) {
    draw([[x-w*.44,y-h*.2],[x+w*.08,y-h*.57],[x+w*.56,y-h*.14],[x+w*.25,y+h*.29],[x-w*.42,y+h*.48]],c,z);
  }
  // Each foam finger has an elbow, projecting knuckle and sharply returning tip.
  function claw(x,y,s,angle,shade=ice) {
    const ca=Math.cos(angle),sa=Math.sin(angle);
    const at=([a,b])=>[x+(a*ca-b*sa)*s,y+(b*ca+a*sa)*s];
    const p=[[-20,-4],[-10,-9],[0,-10],[9,-6],[16,1],[20,9],[18,16],[13,20],[13,14],[11,9],[5,6],[0,6],[-5,10],[-10,7],[-8,2],[-14,2],[-19,6]];
    const a=p.map(at);
    draw(a.map(([px,py])=>[px+1.2*s,py+2.7*s]),ink,25);
    draw(a,chalk,26);
    draw([[-20,-4],[-10,-9],[0,-10],[9,-6],[1,-4],[-8,-3],[-14,2]].map(at),shade,26.1);
    draw([[9,-6],[16,1],[20,9],[18,16],[13,20],[16,11]].map(at),pale,26.2);
  }
  for(let i=0;i<18;i++){
    const u=.28+i*.04, p=curve(crest,u);
    claw(p[0],p[1]+2,.48+rand()*.47,-.94+rand()*.42);
    if(i%3===1)claw(p[0]+7,p[1]+11,.4,-.38);
  }
  const fingers=[[463,115,.55,-.70],[505,110,.68,-.55],[536,104,.56,.04],[557,123,.59,.02],[581,133,.78,-.2],[606,144,.72,.1],[621,158,.84,.17],[590,164,.71,.38],[553,151,.52,.05],[521,144,.67,-.32],[565,179,.62,.15],[613,187,.84,.26],[636,192,.78,.4],[638,216,.67,.32],[668,221,.85,.25],[692,230,.85,.2],[708,246,1.03,.18],[735,264,.74,.25],[743,284,.7,.5],[686,261,.64,.45],[661,247,.72,.38],[631,237,.52,.55],[603,229,.67,.24],[574,229,.55,.48],[586,252,.72,.7],[605,269,.84,.52],[621,283,.73,.71],[638,293,.99,.66],[650,308,.75,.79],[667,321,1,.57],[684,336,.77,.74],[700,345,.85,.68],[715,358,.89,.59],[731,335,.7,.35],[710,306,.74,.65],[684,291,.79,.37],[658,278,.52,.5],[626,257,.6,.23]];
  fingers.forEach(([x,y,s,a])=>claw(x,y,s,a));
  for(let i=0;i<163;i++){
    const u=.05+rand()*.945,v=.02+Math.pow(rand(),1.65)*.91, p=surface(u,v);
    const s=1.4+rand()*3.6;shard(p[0],p[1],s,s*(1+rand()*.6),rand()<.25?ice:chalk);
  }
  for(let i=0;i<48;i++){
    const t=rand(), x=570+190*t+(rand()-.5)*56, y=265+t*100+Math.pow(rand(),2)*135;
    if(x<735||y<375){ const s=1.3+rand()*3.8;shard(x,y,s,s*1.45,rand()<.35?ice:chalk);}
  }
  // Crossing foam seam on the breaker face. Forked fingers leave pockets of blue.
  const lace=[[-26,450],[12,436],[45,402],[76,389],[115,396],[153,365],[175,349],[202,366],[225,345],[244,371],[278,383],[307,359],[326,339],[351,373],[385,376],[413,357],[438,365],[460,393]];
  for(let i=0;i<lace.length-1;i++){
    const [x,y]=lace[i],[xx,yy]=lace[i+1],v=13+rand()*17,m=(x+xx)/2,n=(y+yy)/2;
    draw([[x,y],[m,n-8],[xx,yy],[xx+4,yy+14],[m+6,n+v],[x+1,y+15]],chalk,24.3);
    draw([[x,y],[m,n-8],[xx,yy],[m+2,n+5]],ice,24.4);
    for(let k=0;k<3;k++){
      const t=(k+rand()*.45)/3,fx=lerp(x,xx,t),fy=lerp(y,yy,t);
      claw(fx,fy-3,.38+rand()*.5,-.8+rand()*.7);
      if(k%2===0){claw(fx+5,fy+13,.4+rand()*.44,.3+rand()*.8);
      const drop=14+rand()*42;draw([[fx,fy+9],[fx+6,fy+19],[fx+17,fy+drop],[fx+9,fy+drop-2],[fx+3,fy+23]],chalk,24.8);
      claw(fx+12,fy+drop,.30+rand()*.4,.55)}
    }
  }
  for(let i=0;i<160;i++){const x=rand()*465,y=396+rand()*126;if(y<510+20*Math.sin(x*.045))shard(x,y,1+rand()*3,3+rand()*3,chalk)}
  for(let i=1;i<14;i++){
    const a=outer[i-1],b=outer[i];draw([a,b,[b[0],b[1]+1.6],[a[0],a[1]+1.6]],ink,24.6)
  }
}