local-9b Q5 is measured and configured. Assumption: 128k means a configured context of 131072 tokens. The benchmark measured decode throughput.

To reproduce, use the local9 block in `scripts/start_server.ps1:165` and the profile `profiles/local/local-9b.json`. Both have the tested settings `--no-mmproj-offload` and `-ub 512`. Run:
```powershell
pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024
```

Discard the initial 37.8 t/s result. Dedicated VRAM hit the 7881 MiB WDDM ceiling and Shared Usage showed 1494 MiB of spill. Q6_K (7.03 GiB) did not fit at 128k. Keep Q4_K_M as fallback only (7305 MiB, 40.4 t/s).

Remaining work: update the evals README to remove the stale reference to the deleted `check_vision.ps1`.

Keep Q5 at 128k. With the applied settings, Shared Usage showed no spill, VRAM was 7697 MiB and median decode was 38.0 t/s across three runs.
