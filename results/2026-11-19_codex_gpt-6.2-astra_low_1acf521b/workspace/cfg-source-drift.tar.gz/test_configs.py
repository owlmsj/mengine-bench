import json
import tomllib
import unittest
from pathlib import Path

import gen


class HarnessConfigTest(unittest.TestCase):
    def test_fast_coder_context(self):
        models = json.loads((gen.ROOT / "models.json").read_text())["models"]
        for filename, render, context in (
            ("opencode.json", gen.opencode, lambda s: json.loads(s)["provider"]["workstation"]["models"]["fast-coder"]["limit"]["context"]),
            ("codex.toml", gen.codex, lambda s: tomllib.loads(s)["models"]["fast-coder"]["context_window"]),
            ("claude.json", gen.claude, lambda s: next(m["contextWindow"] for m in json.loads(s)["models"] if m["id"] == "fast-coder")),
        ):
            with self.subTest(filename=filename):
                generated = render(models)
                self.assertEqual(context(generated), 262144)
                self.assertEqual((gen.ROOT / "out" / filename).read_bytes(), generated.encode("utf-8"))


if __name__ == "__main__":
    unittest.main()
