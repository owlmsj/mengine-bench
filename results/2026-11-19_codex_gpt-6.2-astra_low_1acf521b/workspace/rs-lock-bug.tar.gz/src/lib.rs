//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

#[derive(Default)]
struct Scores {
    players: HashMap<PlayerId, i64>,
    total: i64,
}

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    scores: Arc<Mutex<Scores>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        let mut scores = self.scores.lock().unwrap();
        let previous = scores.players.get(&id).copied().unwrap_or(0);
        // The replacement delta can exceed i64 even when the final total fits.
        let total = i128::from(scores.total) - i128::from(previous) + i128::from(score);
        scores.total = i64::try_from(total).expect("board total exceeds i64");
        scores.players.insert(id, score);
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let mut scores = self.scores.lock().unwrap();
        let updated = scores.players[&id] + points;
        scores.total += points;
        scores.players.insert(id, updated);
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let mut scores = self.scores.lock().unwrap();
        let source = scores.players[&from];
        if from == to {
            return;
        }
        let destination = scores.players[&to] + points;
        scores.players.insert(from, source - points);
        scores.players.insert(to, destination);
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        self.scores.lock().unwrap().players[&id]
    }

    pub fn total(&self) -> i64 {
        self.scores.lock().unwrap().total
    }
}

#[cfg(test)]
mod tests {
    use super::Board;
    use std::sync::{mpsc, Barrier};
    use std::{sync::Arc, thread, time::Duration};

    #[test]
    fn concurrent_updates_finish_and_preserve_scores() {
        let board = Board::new();
        board.join(1, 9);
        board.join(2, 0);
        let start = Arc::new(Barrier::new(4));
        let (done, finished) = mpsc::channel();
        for worker in 0..4 {
            let (board, start, done) = (board.clone(), start.clone(), done.clone());
            thread::spawn(move || {
                let (from, to) = if worker % 2 == 0 { (1, 2) } else { (2, 1) };
                start.wait();
                board.transfer(from, from, 7);
                for _ in 0..1000 {
                    board.award(1, 1);
                    board.transfer(from, to, 1);
                }
                done.send(()).unwrap();
            });
        }
        drop(done);
        for _ in 0..4 {
            finished
                .recv_timeout(Duration::from_secs(5))
                .expect("worker stalled");
        }
        assert_eq!(
            (board.score(1), board.score(2), board.total()),
            (4009, 0, 4009)
        );
        board.join(1, 3);
        assert_eq!((board.score(1), board.total()), (3, 3));
    }
}
