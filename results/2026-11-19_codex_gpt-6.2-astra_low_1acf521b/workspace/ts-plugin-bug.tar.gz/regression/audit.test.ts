import assert from "node:assert/strict";
import { test } from "node:test";
import { HookBus } from "../src/bus.ts";
import { registerAuditPlugin } from "../src/plugin.ts";

test("tool.after audits redacted output in order across two emits", async () => {
  const bus = new HookBus();
  const audit: string[] = [];
  registerAuditPlugin(bus, audit);
  for (const tool of ["first", "second"]) {
    await bus.emit("tool.after", { tool, output: "password=fixture" });
    assert.equal(audit.at(-1), tool + ": password=[redacted]");
  }
  assert.deepEqual(audit, [
    "notice: tool output is audited",
    "first: password=[redacted]",
    "second: password=[redacted]",
  ]);
});
