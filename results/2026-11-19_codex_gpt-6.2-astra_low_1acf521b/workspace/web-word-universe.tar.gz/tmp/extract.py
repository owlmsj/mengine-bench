from pathlib import Path
from urllib.parse import unquote,urlsplit
import re,json,unicodedata,collections
from html import unescape
def norm(s): return unicodedata.normalize("NFC",unescape(s).strip()).casefold()
def save(path,data): Path(path).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf8")
pages={norm(p.name):p.read_text(encoding="utf8") for p in Path("site").glob("*.html")}
entries={}; redirect={}; themes={}
for f,src in pages.items():
    if m:=re.search(r'class="tema">Tema: ([^<]+)',src):
        word=norm(re.search(r'<h1>([^<]+)',src)[1]);entries[f]=word;themes[word]=m[1]
    elif m:=re.search(r'url=([^"]+)',src): redirect[f]=norm(m[1])
graph={w:set() for w in themes}; types={}
for f,w in entries.items():
    for kind,section in re.findall(r'<section id="(sinonimos|analogas)">(.*?)</section>',pages[f],re.S):
        for href in re.findall(r'href="([^"]+)"',section):
            target=norm(unquote(urlsplit(href).path)); target=redirect.get(target,target);v=entries.get(target)
            if not v or v==w:continue
            graph[w].add(v);graph[v].add(w)
            pair='|'.join(sorted((w,v)));types[pair]=types.get(pair,0)|(1 if kind=='sinonimos' else 2)
data={w:sorted(graph[w]) for w in sorted(graph)}
most=max(data,key=lambda w:len(data[w]))
save("words.json",data);save("result.json",dict(words=len(graph),relations=len(types),most_connected=sorted(w for w in graph if len(graph[w])==len(graph[most]))))
print(len(graph),len(types),most,len(graph[most]),[w for w in graph if len(graph[w])==len(graph[most])])
Path("tmp/data").write_text(json.dumps([data,themes,types],ensure_ascii=False,separators=(',',':')),encoding='utf8')

