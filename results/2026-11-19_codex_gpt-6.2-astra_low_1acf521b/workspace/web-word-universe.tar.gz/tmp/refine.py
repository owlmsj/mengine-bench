from pathlib import Path
p=Path('tmp/page');s=p.read_text(encoding='utf-8-sig').replace('100vh - 272px','100vh - 310px').replace('height:54vh;min-height:360px','height:clamp(250px,71vw,410px);min-height:250px')
s=s.replace('</style>','.hubs{border-top:1px solid var(--line);padding-top:13px;margin-top:16px;color:var(--muted);font-size:11px}.hubs div{display:flex;gap:7px;margin-top:8px}.hubs a{border:1px solid #344154;border-radius:5px;padding:4px 9px;text-decoration:none;color:#d6dfe9}.hubs a:hover{background:#253143}</style>')
s=s.replace('<div id="neighbors"></div></aside>','<div id="neighbors"></div><div class="hubs">Mais conectadas<div id="hublinks"></div></div></aside>')
s=s.replace("totals.innerHTML=", """let peak=Math.max(...words.map(w=>graph[w].length));for(let w of words.filter(w=>graph[w].length===peak)){let a=document.createElement('a');a.href=link(w);a.textContent=w+' ↗';a.onclick=e=>{e.preventDefault();selectWord(w,true)};hublinks.append(a)}
totals.innerHTML=""")
Path('universe/index.html').write_text(s.replace('__DATA__',Path('tmp/data').read_text(encoding='utf8')),encoding='utf8')
