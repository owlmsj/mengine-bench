import xml.etree.ElementTree as ET,json
from pathlib import Path
from urllib.parse import unquote
from unicodedata import normalize
def key(x):return normalize("NFC",x.casefold())
pages={key(p.name):ET.fromstring(p.read_text(encoding='utf8').split('<html',1)[1].join(['<html','']).replace('<meta charset="utf-8">','').replace('<head>','<head>').replace('"></head>','"/></head>')) for p in Path('site').glob('*.html')}
entries={f:r.findtext('.//main/h1') for f,r in pages.items() if r.find('.//main/section') is not None}
aliases={f:r.find('.//body/p/a').get('href') for f,r in pages.items() if r.find('.//head/meta') is not None}
expected=set()
for f,w in entries.items():
 for a in pages[f].findall('.//main/section/ul/li/a'):
  v=key(unquote(a.get('href')));other=entries.get(key(aliases.get(v,v)))
  if other and other!=w:expected.add(tuple(sorted((w,other))))
graph=json.loads(Path('words.json').read_text(encoding='utf8'));assert set(graph)==set(entries.values())
assert expected=={tuple(sorted((w,v))) for w in graph for v in graph[w]}
assert all(w in graph[v] for w in graph for v in graph[w])
print(f'Source audit: {len(graph)} headwords, {len(expected)} distinct pairs, all reciprocal.')
