"""Bounded execution of asynchronous batch jobs."""

import asyncio
from collections.abc import Awaitable, Callable, Iterable


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[object]]], max_concurrent: int
) -> None:
    """Run a finite batch, waiting for cleanup before returning or raising.

    Ordinary job failures are reported together after the batch finishes.
    Cancelling the caller cancels unfinished jobs.
    """
    if isinstance(max_concurrent, bool) or not isinstance(max_concurrent, int):
        raise TypeError(f"expected a positive integer, got {max_concurrent!r}")
    if max_concurrent < 1:
        raise ValueError(f"expected a positive integer, got {max_concurrent!r}")

    slots = asyncio.Semaphore(max_concurrent)
    errors: list[Exception] = []

    async def run_one(factory: Callable[[], Awaitable[object]]) -> None:
        async with slots:
            try:
                await factory()
            except Exception as error:
                errors.append(error)

    async with asyncio.TaskGroup() as group:
        for factory in tasks:
            group.create_task(run_one(factory))

    if errors:
        raise ExceptionGroup("batch jobs failed", errors)
