import asyncio
import unittest

from run import run_tasks


class RunTasksTest(unittest.IsolatedAsyncioTestCase):
    async def test_cancel_at_limit(self):
        ready = asyncio.Event()
        started = []
        cleaned = []

        async def job(i):
            started.append(i)
            try:
                if len(started) == 2:
                    ready.set()
                await asyncio.Future()
            finally:
                await asyncio.sleep(0)
                cleaned.append(i)

        runner = asyncio.create_task(run_tasks(
            [lambda i=i: job(i) for i in range(5)], 2
        ))
        await asyncio.wait_for(ready.wait(), 2)
        runner.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await runner
        self.assertEqual(started, [0, 1])
        self.assertCountEqual(cleaned, started)
