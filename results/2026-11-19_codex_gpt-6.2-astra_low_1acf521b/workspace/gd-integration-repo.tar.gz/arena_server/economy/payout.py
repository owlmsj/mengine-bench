"""Match payout. Rules live in docs/ECONOMY.md."""

from decimal import Decimal, ROUND_HALF_UP


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    subtotal = Decimal(str(base)) + kills * Decimal(str(cfg["kill_bonus"]))
    raw = subtotal * Decimal(str(cfg["event_multiplier"]))
    return int(raw.quantize(Decimal("1E1"), rounding=ROUND_HALF_UP))
