import tempfile
import unittest
from pathlib import Path

from arena_server.config.loader import load_config
from arena_server.economy.payout import match_payout
from arena_server.models.profile import Profile
from arena_server.persistence.codec import decode, encode


class EconomyContract(unittest.TestCase):
    def test_environment_overrides_file(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            path = Path(directory) / "config.json"
            path.write_text('{"kill_bonus": 40, "loss_base": 700}', encoding="utf-8")
            cfg = load_config(path, env={"ARENA_KILL_BONUS": "75"})
        self.assertEqual((cfg["kill_bonus"], cfg["loss_base"]), (75, 700))

    def test_decimal_half_rounds_up(self):
        cfg = load_config(env={"ARENA_EVENT_MULTIPLIER": "0.7"})
        self.assertEqual(match_payout(False, 1, cfg), 460)

    def test_profile_credit_round_trip(self):
        profile = Profile("player", 3, 125, ["skin"])
        self.assertEqual(decode(encode(profile)), profile)
        self.assertEqual(decode('{"name":"player"}'), Profile("player"))
