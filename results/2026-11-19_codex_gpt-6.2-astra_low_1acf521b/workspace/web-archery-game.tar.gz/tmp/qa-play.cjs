module.exports=async({drag,state,screenshot,delay,evaluate})=>{
 const aim=()=>evaluate(`(()=>{const c=document.querySelector('#field'),d=c.getContext('2d').getImageData(0,0,640,300).data;const cols=new Set(['238,112,88','98,175,151','239,168,78','193,107,134']);let hits=[];for(let x=155;x<610;x+=2){for(let y=10;y<288;y+=2){let j=(640*y+x)*4;if(cols.has(d[j]+','+d[j+1]+','+d[j+2])){const found=hits.find(h=>Math.abs(h.x/h.n-x)<17 && Math.abs(h.y/h.n-y)<19);if(found){found.x+=x;found.y+=y;found.n++}else hits.push({x,y,n:1})}}}return hits.filter(h=>h.n>7).map(h=>[h.x/h.n,h.y/h.n]).sort((a,b)=>a[0]-b[0])[0]})()`);
 for(let k=0;k<32;k++){
  const target=await aim();if(!target){await delay(240);continue}
  const [x,y]=target,t=Math.hypot(x-78,y-215)/670;await drag(x+2,y+1-42*t*t-8*t);
  const s=await state();if(k===0){console.log('First shot '+JSON.stringify(s)); await screenshot('playing')}
  if(s.action==='Play again')break;
 }
 console.log('Finish '+JSON.stringify(await state()));
 console.log('Audio oscillators '+await evaluate('window.qaTones'));
 await evaluate('document.querySelector("#action").click();document.querySelector("#pause").click()');console.log('Pause '+await evaluate('document.querySelector("#pause").getAttribute("aria-label")'));
 await evaluate('document.querySelector("#pause").click();window.qaSpeed=24');
 for(let k=0;k<70 && (await state()).action!=='Play again';k++)await delay(80);
 console.log('Idle finish (accelerated frames) '+JSON.stringify(await state()));
 await evaluate('window.qaSpeed=1;document.querySelector("#action").click()');
 console.log('Restart '+JSON.stringify(await state()));
};
