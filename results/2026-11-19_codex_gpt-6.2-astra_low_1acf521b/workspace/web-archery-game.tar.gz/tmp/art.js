const ridgeArt=(()=>{
  const c=document.createElement('canvas');c.width=640;c.height=300;
  const g=c.getContext('2d');
  let seed=16381;
  const rand=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/4294967296);
  const rect=(x,y,w,h,col)=>{g.fillStyle=col;g.fillRect(x|0,y|0,w|0,h|0)};
  const poly=(pts,col)=>{g.fillStyle=col;g.beginPath();pts.forEach(([x,y],i)=>i?g.lineTo(x|0,y|0):g.moveTo(x|0,y|0));g.closePath();g.fill()};
  function stair(x,y,X,Y,col,size=2){let n=Math.ceil(Math.max(Math.abs(X-x),Math.abs(Y-y))/size);for(let i=0;i<=n;i++)rect(x+(X-x)*i/n,y+(Y-y)*i/n,size,size,col)}
  const sky=g.createLinearGradient(0,0,0,225);[['#e9a18a',0],['#f6c495',.42],['#ffdda5',.78],['#e8bb99',1]].forEach(([v,p])=>sky.addColorStop(p,v));g.fillStyle=sky;g.fillRect(0,0,640,300);
  for(let y=-26;y<=26;y++){let w=Math.floor(Math.sqrt(26*26-y*y));rect(455-w,65+y,w*2,1,'#fff0ba')}
  for(let i=0;i<24;i++){let x=rand()*650-20,y=rand()*104+9,w=12+rand()*65;rect(x,y,w,2,'#f5bf99');rect(x+7,y-2,w*.6,2,'#f5bf99');rect(x+13,y+2,w*.85,1,'#ffdbad')}
  function mountain(points,col){let heights=[];for(let i=1;i<points.length;i++){let [x,y]=points[i-1],[X,Y]=points[i];for(let j=x;j<X;j+=2){let h= Math.round((y+(Y-y)*(j-x)/(X-x)+Math.sin(j*.4)*1.5)/2)*2;rect(j,h,2,300-h,col);heights[j]=heights[j+1]=h}}return heights}
  mountain([[0,139],[32,125],[65,135],[119,97],[145,110],[199,73],[216,91],[234,85],[274,117],[314,97],[345,119],[403,90],[430,107],[496,79],[512,90],[553,71],[610,111],[640,102]],'#dca98f');
  mountain([[0,158],[43,135],[73,144],[135,104],[151,114],[182,130],[230,110],[267,130],[298,108],[325,118],[359,93],[396,124],[410,117],[436,130],[486,98],[501,110],[531,97],[579,128],[615,113],[640,125]],'#c09287');
  let ridges=[[0,157],[55,130],[88,145],[127,126],[160,146],[201,157],[245,137],[282,159],[314,151],[353,129],[383,149],[418,143],[453,155],[509,133],[532,143],[580,119],[610,133],[640,123]];
  mountain(ridges,'#a88984');
  for(let i=0;i<100;i++){let x=rand()*640,y=158+rand()*30;rect(x,y,3+rand()*17,1,'#bc9889')}
  function pine(x,y,h,col){rect(x-1,y-h,2,h,col);for(let j=1;j<=5;j++){let span=Math.max(2,Math.floor(j*h/24));let by=y-h+j*h/6;poly([[x,by-h*.29],[x+span,by],[x+2,by],[x+span*.75,by+2],[x-span,by+2]],col)}}
  const mid=mountain([[0,160],[45,153],[99,169],[145,162],[185,178],[226,170],[270,183],[305,175],[349,186],[402,179],[442,170],[486,177],[539,153],[577,148],[614,139],[640,147]],'#84958a');
  for(let x=0;x<640;x+=3+Math.floor(rand()*4)){pine(x,mid[x]+2,3+rand()*9,'#84958a')}
  function temple(x,y){const dark='#565d62',roof='#48585b',trim='#c98f6a';rect(x-16,y-4,32,5,dark);for(let k=0;k<3;k++){let w=15-3*k,b=y-4-k*10;rect(x-w+3,b-8,2*w-6,9,trim);for(let j=-w+5;j<w-3;j+=5)rect(x+j,b-6,3,6,dark);poly([[x-w-4,b-11],[x-w,b-9],[x-5,b-12],[x,b-16],[x+5,b-12],[x+w,b-9],[x+w+4,b-11],[x+w+1,b-6],[x-w,b-6]],roof);rect(x-w,b-7,w*2,1,'#a57c65')}rect(x-1,y-44,2,11,roof);rect(x-2,y-40,4,2,roof)}
  temple(555,158);
  mountain([[0,181],[42,175],[93,183],[135,191],[186,184],[254,193],[286,190],[341,202],[381,193],[418,197],[472,185],[503,182],[549,160],[574,164],[617,151],[640,152]],'#68867c');
  for(let i=0;i<115;i++){let x=rand()*640,y=207+rand()*78;rect(x,y,7+rand()*45,1+rand()*2,'#89a091')}
  let near=mountain([[0,218],[54,196],[91,202],[130,224],[163,233],[195,242],[233,245],[273,264],[309,275],[343,281],[389,269],[421,265],[469,242],[492,237],[534,218],[583,209],[610,199],[640,194]],'#476c64');
  for(let x=0;x<640;x+=3+Math.floor(rand()*5))pine(x,near[x]+4,6+rand()*13,'#476c64');
  const edge=[[0,244],[14,241],[38,243],[52,242],[77,244],[96,243],[109,246],[123,247],[127,251],[120,255],[122,261],[115,264],[110,280],[102,284],[99,300],[0,300]];
  poly(edge,'#394448');poly([[0,250],[32,248],[49,250],[71,249],[95,251],[112,250],[125,251],[118,255],[90,255],[83,259],[56,256],[44,259],[16,255],[0,258]],'#897660');
  poly([[0,243],[22,240],[49,242],[62,240],[90,243],[110,244],[126,249],[115,251],[90,248],[62,249],[30,245],[0,248]],'#b7aa70');
  for(let i=0;i<48;i++){let x=rand()*103,y=258+rand()*42;rect(x,y,2+rand()*9,2,'#515656')}
  for(let i=0;i<60;i++){let x=rand()*115,y=241+x*.035+rand()*3;stair(x,y,x+rand()*3-1,y-rand()*5,'#819260',1)}
  for(let i=0;i<14;i++){let x=5+rand()*103,y=241+x*.035;rect(x,y-5,1,6,'#708354');rect(x-1,y-6,3,2,'#eeb782')}
  // A leaning pine frames the open sky.
  poly([[0,0],[16,0],[27,15],[46,24],[85,32],[86,35],[48,30],[29,24],[12,17],[0,15]],'#394d4c');
  for(let [x,y,X,Y] of [[32,23,57,7],[54,29,77,19],[72,32,97,26],[16,16,27,41],[30,23,52,43],[65,31,77,42]])stair(x,y,X,Y,'#3d5050',3);
  for(let [cx,cy,w] of [[10,4,44],[46,7,32],[65,17,20],[89,25,24],[23,36,24],[50,40,21],[78,40,15]]){for(let i=0;i<44;i++){let x=cx+(rand()-.5)*w*1.6,y=cy+rand()*7;rect(x,y,3+rand()*6,2+rand()*2,'#405e56');if(i%4===0)rect(x,y-2,5,2,'#61816a')}}
  return c;
})();
function scenery(ctx,t){ctx.drawImage(ridgeArt,0,0);ctx.fillStyle='#987e70';for(let i=0;i<4;i++){let x=(260+i*10+t*2)%660,y=43+i%2*4+Math.sin(t+i)*1.5;ctx.fillRect(x|0,y|0,2,1);ctx.fillRect((x+2)|0,(y+1)|0,1,1);ctx.fillRect((x+3)|0,y|0,2,1)}}
function archer(ctx,t,angle,power,recoil){
  const r=(x,y,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(x|0,y|0,w,h)};
  const p=(a,c)=>{ctx.fillStyle=c;ctx.beginPath();a.forEach(([x,y],i)=>i?ctx.lineTo(x|0,y|0):ctx.moveTo(x|0,y|0));ctx.closePath();ctx.fill()};
  const line=(x,y,X,Y,c,w)=>{let n=Math.max(1,Math.ceil(Math.hypot(X-x,Y-y)));for(let i=0;i<=n;i++)r(x+(X-x)*i/n,y+(Y-y)*i/n,w,w,c)};
  r(51,244,29,2,'#69705c');p([[58,225],[68,225],[70,233],[76,241],[72,244],[65,237],[62,233],[60,240],[56,244],[52,242]],'#313b43');
  r(50,242,9,3,'#493c3c');r(71,242,9,3,'#493c3c');line(57,229,54,239,'#596068',3);
  line(49,204,56,227,'#795444',4);for(let i=0;i<3;i++){line(48+i*2,198-i%2*4,56+i,218,'#8b6949',1);r(46+i*2,196-i%2*4,3,4,'#eadab3')}
  p([[58,207],[65,206],[70,211],[66,222],[71,229],[64,231],[59,229],[53,231],[56,219],[53,214]],'#2d6662');p([[57,211],[61,210],[59,222],[55,226]],'#54877a');r(55,220,12,3,'#c39257');r(60,220,3,3,'#f1c57d');
  r(58,198,9,9,'#ce9368');r(63,198,5,7,'#eab384');r(66,201,3,2,'#edbc8c');r(65,200,2,1,'#533e37');r(56,194,10,5,'#36393b');r(54,196,5,8,'#36393b');r(54,198,13,2,'#b94f40');r(51,198,4,3,'#e38159');
  let tail=Math.sin(t*5)*2;p([[56,199],[49,202],[43,201+tail],[46,204+tail],[40,205+tail],[49,206],[56,202]],'#ad4d42');
  const ax=78-3*recoil,ay=215+recoil,dx=Math.cos(angle),dy=Math.sin(angle),nx=-dy,ny=dx;
  line(64,211,ax-4*dx,ay-4*dy,'#45786d',4);line(ax-7*dx,ay-7*dy,ax,ay,'#e2ae80',3);
  let draw=4+Math.min(1,Math.max(0,power||0))*14;
  line(58,211,56,217,'#487d70',4);line(56,217,ax-dx*draw,ay-dy*draw,'#e4af7c',3);
  const pos=(s,n)=>[ax+dx*s+nx*n,ay+dy*s+ny*n];let pts=[pos(-6,-16),pos(-2,-14),pos(2,-9),pos(3,0),pos(2,9),pos(-2,14),pos(-6,16)];
  for(let j=1;j<pts.length;j++)line(...pts[j-1],...pts[j],'#996039',2);
  line(...pts[0],...pos(-draw,0),'#fff1c7',1);line(...pos(-draw,0),...pts[6],'#fff1c7',1);
  if(!(recoil>0)){line(...pos(-draw-3,0),...pos(14,0),'#694b40',1);line(...pos(-draw-4,-2),...pos(-draw,0),'#e8dfb1',2);p([pos(17,0),pos(12,-2),pos(12,2)],'#495257')}
}
