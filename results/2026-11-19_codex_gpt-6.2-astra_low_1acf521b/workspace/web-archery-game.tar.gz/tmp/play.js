(() => {
  const el = id => document.getElementById(id);
  const canvas = el('field'), ctx = canvas.getContext('2d');
  const origin = {x:78,y:215};
  let state='ready', time=0, elapsed=0, score=0, popped=0, escaped=0;
  let prev=0, audio, muted=false, draw=null, aim=-0.25, power=0, recoil=0, spawn=0;
  let rings=[], balloons=[], arrows=[], particles=[], labels=[], chain=0, lastHit=-10, pointer=null;
  const colors=[
    ['#77323e','#bf494a','#ee7058','#ffab7b','#ffe5ad'],
    ['#36524b','#378272','#62af97','#96d8b3','#d4ead0'],
    ['#9b5d38','#cc863f','#efa84e','#ffd576','#ffedac'],
    ['#673b59','#95506c','#c16b86','#ed9da2','#ffcbbe']
  ];
  const rand=(a,b)=>a+Math.random()*(b-a);
  function tone(a,b,length,type,volume,delay=0){
    if(!audio||muted)return;
    const start=audio.currentTime+delay, osc=audio.createOscillator(), gain=audio.createGain();
    osc.type=type; osc.frequency.setValueAtTime(a,start); osc.frequency.exponentialRampToValueAtTime(b,start+length);
    gain.gain.setValueAtTime(.0001,start); gain.gain.exponentialRampToValueAtTime(volume,start+.006);
    gain.gain.exponentialRampToValueAtTime(.0001,start+length);
    osc.connect(gain).connect(audio.destination);osc.start(start);osc.stop(start+length+.02);
  }
  function unlock(){
    try {if(!audio)audio=new (window.AudioContext||window.webkitAudioContext)();
      if(audio.state==='suspended')audio.resume().catch(()=>{});}catch{}
  }
  function balloon(x,y,c,s=1){
    return {x,y,base:x,c,s,phase:rand(0,6.28),speed:rand(6,9),r:9*s};
  }
  function seed(){
    balloons=[[218,137,0,.92],[306,87,2,1],[385,176,1,1.08],[468,119,3,.96],[555,66,0,.85]].map(v=>balloon(...v));
  }
  function hud(){
    el('score').textContent=String(score).padStart(4,'0');el('escaped').textContent=escaped;el('remaining').textContent=popped;
    const secs=Math.max(0,Math.ceil(60-elapsed)); el('clock').textContent=Math.floor(secs/60)+':'+String(secs%60).padStart(2,'0');
    el('power').style.width=Math.round(power*100)+'%';
    el('pause').disabled=!['playing','paused'].includes(state);
    el('pause').dataset.paused=state==='paused';
    el('pause').setAttribute('aria-label',state==='paused'?'Resume':'Pause');
    el('pause').title=state==='paused'?'Resume':'Pause';
  }
  function reset(){
    unlock();elapsed=score=popped=escaped=power=chain=0;lastHit=-10;spawn=1;draw=null; rings=[];arrows=[];particles=[];labels=[];
    seed();state='playing';el('action').textContent='Restart';hud();
    tone(450,620,.13,'sine',.07);tone(700,900,.18,'sine',.05,.08);
  }
  function end(won){
    state=won?'won':'lost';draw=null;power=0;el('action').textContent='Play again';hud();
    [0,1,2].forEach((v)=>{const f=(won?[523,659,784]:[440,370,294])[v];tone(f,f*.99,.24,'triangle',.09,v*.09);});
  }
  function pause(){
    if(state!=='paused'&&state!=='playing')return;
    state=state==='paused'?'playing':'paused';draw=null;power=0;hud();
  }
  el('action').addEventListener('click',reset);el('pause').addEventListener('click',pause);
  el('sound').addEventListener('click',()=>{
    unlock();muted=!muted;el('sound').dataset.muted=muted;el('sound').setAttribute('aria-pressed',String(!muted));el('sound').title=muted?'Enable sound':'Mute sound';
    tone(600,750,.1,'sine',.06);
  });
  document.addEventListener('keydown',e=>{if(e.key.toLowerCase()==='p'||e.key==='Escape')pause();});
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&state==='playing')pause();});
  function point(e){const b=canvas.getBoundingClientRect();return {x:(e.clientX-b.left)*640/b.width,y:(e.clientY-b.top)*300/b.height};}
  function aimAt(p){aim=Math.max(-1.42,Math.min(.63,Math.atan2(p.y-origin.y,Math.max(5,p.x-origin.x))));}
  canvas.style.touchAction='none';
  canvas.addEventListener('pointermove',e=>{
    if(draw&&draw.id!==e.pointerId)return; pointer=point(e);
    if(!draw)aimAt(pointer);
    else draw.pull=Math.min(1,Math.hypot(pointer.x-draw.x,pointer.y-draw.y)/58);
  });
  canvas.addEventListener('pointerdown',e=>{
    if(state!=='playing'||draw||e.button!==0)return;
    unlock();pointer=point(e);aimAt(pointer);canvas.setPointerCapture(e.pointerId);
    draw={...pointer,id:e.pointerId,pull:0,start:time};
    tone(95,182,.27,'triangle',.03);
  });
  canvas.addEventListener('pointerleave',()=>{if(!draw)pointer=null;});
  canvas.addEventListener('pointercancel',()=>{draw=null;power=0;hud();});
  canvas.addEventListener('pointerup',e=>{
    if(!draw||draw.id!==e.pointerId||state!=='playing')return;
    const v=speed();arrows.push({x:origin.x,y:origin.y,vx:Math.cos(aim)*v,vy:Math.sin(aim)*v,trail:[]});
    recoil=1;draw=null;power=0;hud();
    tone(180,53,.15,'triangle',.14);tone(750,210,.075,'sawtooth',.025);
  });
  function speed(){return 260+power*410;}
  function burst(b){
    rings.push({x:b.x,y:b.y,life:.19});
    for(let i=0;i<17;i++){
      const a=rand(0,6.28),v=rand(18,94);
      particles.push({x:b.x,y:b.y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-12,life:rand(.3,.7),color:colors[b.c][i%5],w:i%3+1});
    }
    chain=elapsed-lastHit<2.4?Math.min(4,chain+1):1;lastHit=elapsed;
    const points=100+(chain-1)*25;score+=points;popped++;
    labels.push({x:b.x,y:b.y-8,life:.88,text:'+'+points+(chain>1?'  x'+chain:'')});
    const note=523.25*Math.pow(2,([0,4,7,12][chain-1])/12);
    tone(380,56,.065,'square',.045);tone(note,note*.99,.19,'sine',.12,.025);tone(note*1.5,note*1.5,.23,'sine',.055,.07);
    hud();if(popped===12)end(true);
  }
  function tick(dt){
    elapsed+=dt;spawn-=dt;recoil=Math.max(0,recoil-dt*6);
    if(draw)power=Math.max(draw.pull,Math.min(1,(time-draw.start)/1.15));
    if(spawn<0&&balloons.length<7){spawn=1.9;balloons.push(balloon(rand(170,596),294,Math.floor(rand(0,4)),rand(.88,1.12)));}
    for(const b of balloons){
      b.y-=dt*b.speed;b.x=b.base+Math.sin(time*.85+b.phase)*5;
      if(b.y< -14){escaped++;tone(170,85,.19,'triangle',.08);}
    }
    balloons=balloons.filter(b=>b.y>=-14);if(escaped>=5||elapsed>=60){end(false);return;}
    for(const a of arrows){
      const oldX=a.x,oldY=a.y;a.trail.push([a.x,a.y]);if(a.trail.length>6)a.trail.shift();
      a.x+=a.vx*dt;a.y+=a.vy*dt+42*dt*dt;a.vy+=84*dt;
      const dx=a.x-oldX,dy=a.y-oldY;
      const index=balloons.findIndex(b=>{
        const u=Math.max(0,Math.min(1,((b.x-oldX)*dx+(b.y-oldY)*dy)/(dx*dx+dy*dy||1)));
        return ((oldX+u*dx-b.x)/(b.r+2))**2+((oldY+u*dy-b.y)/(b.r*1.27+2))**2<=1;
      });
      if(index!==-1){a.dead=true;burst(balloons.splice(index,1)[0]);if(state!=='playing')break;}
    }
    arrows=arrows.filter(a=>!a.dead&&a.x<660&&a.y<315);
    hud();
  }
  function paintBalloon(b){
    const c=colors[b.c];ctx.save();ctx.translate(Math.round(b.x),Math.round(b.y));ctx.scale(b.s,b.s);
    const box=(x,y,w,h,color)=>{ctx.fillStyle=color;ctx.fillRect(x,y,w,h);};
    const widths=[4,7,9,10,10,9,8,6,4,2];
    widths.forEach((w,i)=>{const y=Math.round(i*2.4)-12,h=Math.round((i+1)*2.4)-12-y;box(-w,y,w*2,h,c[0]);if(i>0)box(-w+1,y,2*w-2,h,c[1]);if(i>0&&i<8)box(-w+1,y,Math.round(w*1.45),h,c[2]);});
    box(-5,-8,4,2,c[4]);box(-7,-6,3,5,c[3]);box(-5,-7,2,3,c[4]);box(-1,11,2,2,c[0]);box(-2,13,5,2,c[1]);
    for(let i=0;i<19;i++)box(Math.round(Math.sin(i/5+time*2+b.phase)*i/8),15+i,1,1,'#695b56');
    ctx.restore();
  }
  function rect(x,y,w,h,col){ctx.fillStyle=col;ctx.fillRect(Math.round(x),Math.round(y),w,h);}
  function render(dt){
    ctx.save();ctx.imageSmoothingEnabled=false;scenery(ctx,time);
    for(const b of balloons)paintBalloon(b);
    if(draw&&state==='playing'){
      const v=speed();
      for(let i=1;i<=12;i++){
        const t=i*.044;ctx.globalAlpha=1-i*.055;
        rect(origin.x+Math.cos(aim)*v*t,origin.y+Math.sin(aim)*v*t+42*t*t,2,2,'#fff4bd');
      }ctx.globalAlpha=1;
    }
    archer(ctx,time,aim,power,recoil);
    for(const a of arrows){
      ctx.beginPath();for(const [x,y] of a.trail)ctx.lineTo(x,y);ctx.lineTo(a.x,a.y);ctx.strokeStyle='rgba(255,239,194,.45)';ctx.lineWidth=1;ctx.stroke();
      const ang=Math.atan2(a.vy,a.vx);ctx.save();ctx.translate(a.x,a.y);ctx.rotate(ang);
      rect(-18,0,16,1,'#573b35');rect(-18,-1,4,3,'#fbdfa3');rect(-3,-1,4,3,'#465658');ctx.restore();
    }
    for(const ring of rings){ctx.globalAlpha=Math.min(1,ring.life*7);ctx.strokeStyle='#fff1bc';ctx.beginPath();ctx.arc(ring.x,ring.y,10+(.19-ring.life)*82,0,Math.PI*2);ctx.stroke();if(state!=='paused')ring.life-=dt;}rings=rings.filter(r=>r.life>0);ctx.globalAlpha=1;
    for(const p of particles){rect(p.x,p.y,p.w,2,p.color);if(state!=='paused'){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=150*dt;p.life-=dt;}}
    particles=particles.filter(p=>p.life>0);
    ctx.textAlign='center';ctx.font='bold 10px monospace';
    for(const l of labels){ctx.globalAlpha=Math.min(1,l.life*3);ctx.fillStyle='#372c37';ctx.fillText(l.text,l.x+1,l.y+1);ctx.fillStyle='#fff6c9';ctx.fillText(l.text,l.x,l.y);if(state!=='paused'){l.y-=dt*19;l.life-=dt;}}
    labels=labels.filter(l=>l.life>0);ctx.globalAlpha=1;
    if(state==='won'||state==='lost'||state==='paused'){
      ctx.fillStyle='rgba(32,34,43,.50)';ctx.fillRect(0,0,640,300);
      rect(215,109,210,76,'#372e36');rect(217,111,206,72,'#f2d8a8');rect(220,114,200,66,'#344a46');
      ctx.fillStyle='#ffdda1';ctx.font='bold 19px Georgia';ctx.fillText(state==='won'?'Range cleared!':state==='lost'?'Round over':'Paused',320,140);
      ctx.fillStyle='#fff2d7';ctx.font='10px monospace';ctx.fillText(state==='paused'?'Press P to resume':state==='won'?score+' points  /  12 balloons':(escaped>=5?'Five balloons escaped':'Time ran out')+'  /  '+score+' pts',320,160);
    }
    ctx.restore();
  }
  function frame(ms){
    const dt=prev?Math.min(.045,(ms-prev)/1000):0;prev=ms;if(state!=='paused')time+=dt;
    if(state==='playing')tick(dt);
    if(state==='ready')balloons.forEach(b=>{b.x=b.base+Math.sin(time*.65+b.phase)*2;});
    render(dt);requestAnimationFrame(frame);
  }
  seed();hud();requestAnimationFrame(frame);
})();
