const fs = require('node:fs');
const path = require('node:path');
const {spawn} = require('node:child_process');
const {pathToFileURL} = require('node:url');
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
const root = path.resolve(__dirname,'..');
const profile = path.join(__dirname,'qa-profile-'+process.pid);
const browser = spawn('C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', ['--headless=new','--disable-gpu','--disable-extensions','--disable-background-networking','--no-first-run','--no-default-browser-check','--remote-debugging-port=0','--user-data-dir='+profile,'--window-size=1440,960','about:blank'],{stdio:'ignore',windowsHide:true});
let socket, id=0;
const pending = new Map();
const errors=[];
async function connect(url){
 const ws=new WebSocket(url);
 await new Promise((res,rej)=>{ws.onopen=res;ws.onerror=rej});
 ws.onmessage=({data})=>{
  const r=JSON.parse(data);
  if(r.method==='Runtime.exceptionThrown') errors.push(r.params.exceptionDetails.exception?.description || r.params.exceptionDetails.text);
  const item=pending.get(r.id); if(item){ pending.delete(r.id); r.error?item.reject(Error(r.error.message)):item.resolve(r.result) }
 };return ws;
}
function call(method,params={}){
 const i=++id;
 return new Promise((resolve,reject)=>{pending.set(i,{resolve,reject});socket.send(JSON.stringify({id:i,method,params}))});
}
async function evaluate(expression){const {result,exceptionDetails}=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(exceptionDetails)throw Error(exceptionDetails.exception?.description || exceptionDetails.text);return result.value}
async function screenshot(name){
 const r=await call('Page.captureScreenshot',{format:'png'});fs.writeFileSync(path.join(__dirname,name+'.png'),Buffer.from(r.data,'base64'))
}
async function mouse(type,x,y){
 await call('Input.dispatchMouseEvent',{type,x,y,button:type==='mouseMoved'?'none':'left',buttons:type==='mouseReleased'?0:1,clickCount:type==='mouseMoved'?0:1});
}
async function main(){
 const source=path.join(root,'game/index.html');
 if(!fs.existsSync(source)) throw Error('Missing game/index.html');
 let port;
 for(let k=0;k<100 && !port;k++){try{port=fs.readFileSync(path.join(profile,'DevToolsActivePort'),'utf8').split(/\r?\n/)[0]}catch{} if(!port)await delay(80)}
 if(!port)throw Error('No DevTools port');
 const tab=(await(await fetch('http://127.0.0.1:'+port+'/json/list')).json()).find(x=>x.type==='page');
 socket=await connect(tab.webSocketDebuggerUrl);
 await call('Page.enable');await call('Runtime.enable');
 await call('Emulation.setDeviceMetricsOverride',{width:1440,height:960,deviceScaleFactor:1,mobile:false});
 await call('Page.addScriptToEvaluateOnNewDocument',{source:`window.qaTones=0;const oscillator=AudioContext.prototype.createOscillator;AudioContext.prototype.createOscillator=function(...a){window.qaTones++;return oscillator.apply(this,a)};window.qaSpeed=1;let cb=null,prev=0,ts=0;const raf=requestAnimationFrame.bind(window);window.requestAnimationFrame=f=>{cb=f};function loop(ms){const delta=prev?ms-prev:0;prev=ms;for(let n=0;n<window.qaSpeed;n++){ts+=Math.min(delta,40);if(cb){const f=cb;cb=null;f(ts)}}raf(loop)}raf(loop);`});
 await call('Page.navigate',{url:pathToFileURL(source).href});
 for(let k=0;k<100 && !await evaluate('!!document.querySelector("#action")');k++)await delay(100);
 await delay(450);
 await screenshot('opening');
 const box=await evaluate('(()=>{let r=document.querySelector("#field").getBoundingClientRect();return [r.left,r.top,r.width,r.height]})()');
 console.log('Canvas bounds '+box.join(', '));
 const state=()=>evaluate('Object.fromEntries(["score","remaining","escaped","clock","action","pause","power"].map(id=>[id,document.getElementById(id)?.textContent.trim()]))');
 console.log('Opening '+JSON.stringify(await state()));
 const button=await evaluate('(()=>{const r=document.querySelector("#action").getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2]})()');await mouse('mousePressed',...button);await mouse('mouseReleased',...button);
 const [x,y,w,h]=box;
 const pos=(a,b)=>[x+w*a/640,y+h*b/300];
 const drag=async (a,b,back=100)=>{await mouse('mouseMoved',...pos(a,b));await mouse('mousePressed',...pos(a,b));for(let k=1;k<=5;k++){await mouse('mouseMoved',...pos(a-back*k/5,b+(215-b)*back/(a-78)*k/5));await delay(30)}await mouse('mouseReleased',...pos(a-back,b+(215-b)*back/(a-78)));await delay(480)};
 await require('./qa-play.cjs')({evaluate,state,screenshot,drag,delay,call,mouse,pos});
 console.log('Browser exceptions '+JSON.stringify(errors)); if(errors.length)process.exitCode=1;
}
main().catch(e=>{console.error(e.message);process.exitCode=1}).finally(async()=>{
 if(socket?.readyState===1){await Promise.race([call('Browser.close').catch(()=>{}),delay(500)]);socket.close()}
 for(let k=0;k<20 && browser.exitCode===null;k++)await delay(100);
 if(browser.exitCode===null) browser.kill();
 await delay(200);
 const resolved=path.resolve(profile); if(resolved.startsWith(path.resolve(__dirname)+path.sep+'qa-profile-')){try{fs.rmSync(resolved,{recursive:true,force:true,maxRetries:3})}catch{}}
 console.log('Browser closed '+(browser.exitCode!==null || browser.killed));
});



