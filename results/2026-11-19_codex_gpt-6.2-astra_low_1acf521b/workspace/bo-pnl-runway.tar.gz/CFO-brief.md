# H1 2026 investor briefing
## June closed with 9.36 months of cash at the board's burn rate

Net revenue rose 35.8% from January to June. June delivered the highest revenue and gross margin of the half. Every month recorded an EBITDA loss. March and May refunds of R$6,814.15 and R$8,634.37 reduced reported revenue in those months.

### Consolidated operating results in R$

| Month | Net revenue | COGS | Gross profit | GM | Sales & marketing | R&D | G&A | EBITDA |
|:---|---:|---:|---:|---:|---:|---:|---:|---:|
| 2026-01 | 200,510.87 | 60,091.92 | 140,418.95 | 70.03% | 143,475.23 | 163,396.33 | 43,826.35 | -210,278.96 |
| 2026-02 | 216,328.06 | 64,278.71 | 152,049.35 | 70.29% | 138,161.28 | 182,271.02 | 43,917.13 | -212,300.08 |
| 2026-03 | 219,066.17 | 69,096.05 | 149,970.12 | 68.46% | 135,519.34 | 171,742.87 | 47,233.36 | -204,525.45 |
| 2026-04 | 238,163.26 | 70,867.73 | 167,295.53 | 70.24% | 139,688.11 | 179,804.44 | 44,753.63 | -196,950.65 |
| 2026-05 | 243,032.89 | 73,973.13 | 169,059.76 | 69.56% | 138,680.10 | 185,905.30 | 46,420.18 | -201,945.82 |
| 2026-06 | 272,391.57 | 75,162.69 | 197,228.88 | 72.41% | 151,896.54 | 189,990.01 | 48,310.55 | -192,968.22 |
| **H1** | 1,389,492.82 | 413,470.23 | 976,022.59 | 70.24% | 847,420.60 | 1,073,109.97 | 274,461.20 | -1,218,969.18 |

### Liquidity at 30 June

Closing cash of R$1,847,350.40 covers 9.36 months at R$197,288.23 per month. The board defines burn as the average EBITDA loss for April, May and June. The estimate assumes that rate continues with no new financing. Cash fell R$461,837.60 between the May and June closes. The supplied ledger has no cash-flow bridge to explain the difference from June's EBITDA loss.

### Basis of preparation

The close uses posted dates and signed BRL amounts from finance/ledger.csv, classified using finance/chart_of_accounts.csv. Revenue includes subscriptions and onboarding, net of refunds. Gross profit deducts production and support costs. EBITDA then deducts sales and marketing, R&D and G&A. Financial income and expense are excluded. H1 margin uses aggregate gross profit divided by aggregate revenue. Cash comes from finance/cash_balance.txt and the burn convention from finance/README.md. Figures are rounded after aggregation.
