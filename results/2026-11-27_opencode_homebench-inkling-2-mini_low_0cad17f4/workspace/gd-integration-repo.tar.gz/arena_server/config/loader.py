"""Runtime config. Precedence, lowest to highest: DEFAULTS < JSON file < env (docs/CONFIG.md)."""

import json
import os

from arena_server.config.defaults import DEFAULTS


def _coerce(raw, like):
    return type(like)(raw)


def load_config(file_path=None, env=None):
    cfg = dict(DEFAULTS)
    if file_path:
        with open(file_path, encoding="utf-8") as fh:
            for key, value in json.load(fh).items():
                if key in cfg and cfg[key] is not None:
                    cfg[key] = _coerce(value, cfg[key])
                else:
                    cfg[key] = value
    env = os.environ if env is None else env
    for key, default in DEFAULTS.items():
        value = env.get(f"ARENA_{key.upper()}")
        if value is not None:
            cfg[key] = _coerce(value, default)
    return cfg
