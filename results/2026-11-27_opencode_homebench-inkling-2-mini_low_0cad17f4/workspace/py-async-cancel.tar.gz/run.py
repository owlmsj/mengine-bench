import asyncio
import inspect


async def run_tasks(tasks, max_concurrent):
    if max_concurrent < 1:
        raise ValueError("max_concurrent must be >= 1")
    tasks = list(tasks)
    sem = asyncio.Semaphore(max_concurrent)

    async def wrapped(task):
        async with sem:
            job = task()
            if inspect.isawaitable(job):
                await job

    loop = asyncio.get_running_loop()
    pending = []
    try:
        for t in tasks:
            pending.append(loop.create_task(wrapped(t)))
        await asyncio.gather(*pending)
    except asyncio.CancelledError:
        for p in pending:
            p.cancel()
        await asyncio.gather(*pending, return_exceptions=True)
        raise
    except BaseException:
        # let in-flight cleanup run, then propagate
        for p in pending:
            p.cancel()
        await asyncio.gather(*pending, return_exceptions=True)
        raise
