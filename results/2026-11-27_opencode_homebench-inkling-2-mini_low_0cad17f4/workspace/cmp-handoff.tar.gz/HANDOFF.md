HANDOFF: local-9b Q5 @ 128k. Task: measure 131072 ctx. Repo NOT here; record is session/transcript.md.

State:
- Measured once: 37.8 t/s decode, 7881 MiB VRAM (scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024).
- That does NOT count: 7881 MiB is the WDDM ceiling; Shared Usage counter shows 1494 MiB spilled. Re-measure after the fix; confirm no spill.
- Fix applied (step 63): scripts/start_server.ps1:165 (local9 block) + profiles/local/local-9b.json. Earlier number is stale.
- Pending: evals README still cites check_vision.ps1 (deleted); review scratchpad temp-file names (low priority).
- Not delivered; nothing committed/pushed.

Assumptions: the start_server/local-9b recipe is the accepted fix; README + temp names are the only outstanding tasks. Transcript shows only no-op steps (--help, GPU panel, git status, short-prompt repro) - do not redo.

How right: claims copied from transcript notes, none re-verified here; treat 37.8 t/s as unverified until re-measured on the real host.