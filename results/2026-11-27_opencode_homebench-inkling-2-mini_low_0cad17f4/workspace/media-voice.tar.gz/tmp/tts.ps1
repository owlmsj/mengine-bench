Add-Type -AssemblyName System.Speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
$s.SetOutputToWaveFile('./tmp/announce.wav')
$s.Rate = 0
$s.Volume = 100
$s.Speak('Welcome aboard the evening ferry, please keep your bags clear of the doors.')
$s.SetOutputToDefaultAudioDevice()
