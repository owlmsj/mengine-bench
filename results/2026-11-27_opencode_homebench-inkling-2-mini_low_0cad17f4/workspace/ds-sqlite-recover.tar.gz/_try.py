import sqlite3
c = sqlite3.connect('prices.db')
print([r for r in c.execute('SELECT name FROM sqlite_master')])
c.close()
