//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

#[derive(Default)]
struct State {
    players: HashMap<PlayerId, i64>,
    total: i64,
}

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    state: Arc<Mutex<State>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        let mut s = self.state.lock().unwrap();
        let entry = s.players.entry(id).or_insert(0);
        *entry += score;
        s.total += score;
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let mut s = self.state.lock().unwrap();
        *s.players.get_mut(&id).unwrap() += points;
        s.total += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return;
        }
        let mut s = self.state.lock().unwrap();
        *s.players.get_mut(&from).unwrap() -= points;
        *s.players.get_mut(&to).unwrap() += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.state.lock().unwrap().players.get(&id).unwrap()
    }

    pub fn total(&self) -> i64 {
        self.state.lock().unwrap().total
    }
}
