import asyncio
import os
import signal

from run import run_tasks

# 1) concurrency limit + completes all
def test_limit():
    active = 0
    peak = 0
    done = []

    def make_job(i):
        async def job():
            nonlocal active, peak
            active += 1
            peak = max(peak, active)
            try:
                await asyncio.sleep(0.01)
                done.append(i)
            finally:
                active -= 1
        return job()

    async def main():
        await run_tasks((lambda i=i: make_job(i) for i in range(12)), 3)
        return peak, sorted(done)

    peak, done = asyncio.run(main())
    assert peak <= 3, peak
    assert done == list(range(12)), done
    print("limit ok, peak=", peak)

# 2) cleanup on cancellation of the main task
def test_cancel_cleanup():
    cleaned = []

    def make_job(i):
        async def job():
            try:
                await asyncio.sleep(10)
            finally:
                cleaned.append(i)
        return job()

    async def main():
        t = asyncio.create_task(
            run_tasks((lambda i=i: make_job(i) for i in range(5)), 5)
        )
        await asyncio.sleep(0.05)
        t.cancel()
        try:
            await t
        except asyncio.CancelledError:
            pass
        return sorted(cleaned)

    c = asyncio.run(main())
    assert c == list(range(5)), c
    print("cancel cleanup ok", c)

# 3) real SIGINT through asyncio.run -> KeyboardInterrupt + cleanup
def test_sigint():
    cleaned = []

    def make_job(i):
        async def job():
            try:
                await asyncio.sleep(10)
            finally:
                cleaned.append(i)
        return job()

    async def main():
        asyncio.get_running_loop().call_later(
            0.05, os.kill, os.getpid(), signal.SIGINT
        )
        await run_tasks((lambda i=i: make_job(i) for i in range(5)), 5)

    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
    assert sorted(cleaned) == list(range(5)), cleaned
    print("sigint cleanup ok", sorted(cleaned))

test_limit()
test_cancel_cleanup()
test_sigint()
print("ALL OK")
