"""Bounded-concurrency helper for batches of async jobs.

Public API:
    from run import run_tasks
    await run_tasks(tasks, max_concurrent)

`tasks` is an iterable of zero-argument callables; calling one returns an
awaitable job. At most `max_concurrent` jobs are awaited at once and the
function returns only after every job has finished.

Cancellation (including the SIGINT that ``asyncio.run`` turns into cancellation
of the main task) is propagated to the in-flight jobs and awaited before it is
re-raised, so each job's ``finally`` / ``async with`` cleanup gets to run.
"""

from __future__ import annotations

import asyncio
from typing import Awaitable, Callable, Iterable, TypeVar

_T = TypeVar("_T")

_SENTINEL = object()


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[_T]]],
    max_concurrent: int,
) -> None:
    """Run every job produced by `tasks`, at most `max_concurrent` at once.

    Assumptions (the brief leaves these open):
      * `tasks` is a finite iterable, possibly a one-shot generator. It is
        consumed lazily: a factory is called only when a slot is free.
      * `max_concurrent` is a positive int.
      * Job results are ignored. If a job raises, the other jobs are cancelled
        and the failure propagates (as an ExceptionGroup from the TaskGroup).
      * On cancellation the running jobs are cancelled and awaited to
        completion before the cancellation is re-raised, so their cleanup runs.
    """
    if not isinstance(max_concurrent, int) or max_concurrent < 1:
        raise ValueError("max_concurrent must be a positive integer")

    iterator = iter(tasks)

    def next_factory():
        try:
            return next(iterator)
        except StopIteration:
            return _SENTINEL

    async def worker() -> None:
        while True:
            make_job = next_factory()
            if make_job is _SENTINEL:
                return
            await make_job()

    # A fixed pool of workers enforces the limit without creating one task per
    # input item (so it also works for very large or streaming iterables).
    # TaskGroup provides structured cancellation: leaving the block, normally
    # or because the enclosing task is cancelled, cancels the workers and
    # waits for every one of them to finish its cleanup before propagating.
    async with asyncio.TaskGroup() as tg:
        for _ in range(max_concurrent):
            tg.create_task(worker())
