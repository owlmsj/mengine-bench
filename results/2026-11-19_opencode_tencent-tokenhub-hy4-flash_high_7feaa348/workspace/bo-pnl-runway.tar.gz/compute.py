import csv, json
from collections import defaultdict
from decimal import Decimal

BASE = r"<WORKSPACE>\finance"

def parse_br(s):
    s = s.strip()
    neg = s.startswith('-')
    s = s.lstrip('-')
    s = s.replace('.', '').replace(',', '.')
    v = Decimal(s)
    return -v if neg else v

# map account -> pnl_line
coa = {}
with open(BASE + r"\chart_of_accounts.csv", encoding='utf-8-sig') as f:
    for row in csv.DictReader(f, delimiter=';'):
        coa[row['account'].strip()] = row['pnl_line'].strip()

# monthly by pnl_line
monthly = defaultdict(lambda: defaultdict(Decimal))
with open(BASE + r"\ledger.csv", encoding='utf-8-sig') as f:
    for row in csv.DictReader(f, delimiter=';'):
        d, m, y = row['date'].strip().split('/')
        key = f"{y}-{m.zfill(2)}"
        amt = parse_br(row['amount'])
        line = coa[row['account'].strip()]
        monthly[key][line] += amt

months = [f"2026-{m:02d}" for m in range(1,7)]

def q2(x):
    return float(round(x, 2))

result = {
    "revenue": {},
    "gross_margin_pct": {},
    "ebitda": {},
}

print(f"{'month':8} {'revenue':>14} {'cogs':>14} {'grossprofit':>14} {'GM%':>8} {'EBITDA':>14}")
for k in months:
    v = monthly[k]
    rev = v['revenue']
    cogs = v['cogs']            # stored negative
    gp = rev + cogs             # gross profit
    gm = gp / rev * 100 if rev else Decimal(0)
    # EBITDA = all operating lines (exclude financial: interest & investment income)
    ebitda = rev + cogs + v['sales_marketing'] + v['rnd'] + v['ga']
    result['revenue'][k] = q2(rev)
    result['gross_margin_pct'][k] = q2(gm)
    result['ebitda'][k] = q2(ebitda)
    print(f"{k:8} {rev:>14} {cogs:>14} {gp:>14} {gm:>8.2f} {ebitda:>14}")

# Burn: avg monthly negative EBITDA of last 3 closed months (Apr, May, Jun)
last3 = [result['ebitda'][k] for k in months[-3:]]
burn_vals = [-e for e in last3]   # convert negative EBITDA to positive burn
burn = sum(Decimal(str(x)) for x in burn_vals) / Decimal(3)
burn = q2(burn)

latest_cash = Decimal('1847350.40')
runway = q2(latest_cash / Decimal(str(burn)))
result['burn'] = burn
result['runway_months'] = runway

print("\nlast3 EBITDA:", last3)
print("burn:", burn)
print("latest cash:", latest_cash)
print("runway months:", runway)

with open(r"<WORKSPACE>\result.json", 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
print("\nresult.json written")
