"""Runtime config. Precedence, lowest to highest: DEFAULTS < JSON file < env (docs/CONFIG.md)."""

import json
import os

from arena_server.config.defaults import DEFAULTS

ENV_PREFIX = "ARENA_"


def _coerce(raw, like):
    if isinstance(like, bool):
        return str(raw).strip().lower() in {"1", "true", "yes", "on"}
    return type(like)(raw)


def load_config(file_path=None, env=None):
    cfg = dict(DEFAULTS)
    if file_path:
        with open(file_path, encoding="utf-8") as fh:
            cfg.update(json.load(fh))

    env = os.environ if env is None else env
    for key in sorted(set(cfg) | {
        name[len(ENV_PREFIX):].lower() for name in env if name.startswith(ENV_PREFIX)
    }):
        raw = env.get(f"{ENV_PREFIX}{key.upper()}")
        if raw is None:
            continue
        like = cfg.get(key, DEFAULTS.get(key, raw))
        cfg[key] = _coerce(raw, like)
    return cfg
