//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        // Hold each lock across the whole read-modify-write; releasing it
        // between the read and the write lets concurrent awards overwrite
        // each other, which loses points.
        *self.slot(id).lock().unwrap() += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return;
        }
        // Lock both slots in a fixed order (by PlayerId). Locking them in
        // call order deadlocks when two threads transfer in opposite
        // directions, and a self-transfer would lock one mutex twice.
        let a = self.slot(from);
        let b = self.slot(to);
        if from < to {
            let mut fa = a.lock().unwrap();
            let mut tb = b.lock().unwrap();
            *fa -= points;
            *tb += points;
        } else {
            let mut tb = b.lock().unwrap();
            let mut fa = a.lock().unwrap();
            *fa -= points;
            *tb += points;
        }
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}
