import csv, math, collections, json

rows = list(csv.DictReader(open("telemetry/playtest_ab.csv", newline="", encoding="utf-8-sig")))

# Deduplicate on the unique key from the README; keep first (duplicates are byte-identical).
seen = {}
for r in rows:
    seen.setdefault(r["session_id"].strip(), r)
rows = list(seen.values())

groups = collections.defaultdict(lambda: [0, 0])  # variant -> [n, completed]
for r in rows:
    v = r["variant"].strip().lower()
    assert v in ("a", "b"), v
    c = int(r["completed_tutorial"].strip())
    assert c in (0, 1)
    groups[v][0] += 1
    groups[v][1] += c

na, ca = groups["a"]
nb, cb = groups["b"]
pa, pb = ca / na, cb / nb
print("A: n=%d completed=%d rate=%.6f" % (na, ca, pa))
print("B: n=%d completed=%d rate=%.6f" % (nb, cb, pb))
print("difference pb-pa = %.6f" % (pb - pa))

# Pooled two-proportion z-test (standard for A/B significance testing).
p_pool = (ca + cb) / (na + nb)
se = math.sqrt(p_pool * (1 - p_pool) * (1 / na + 1 / nb))
z = (pb - pa) / se
Phi = lambda x: 0.5 * (1 + math.erf(x / math.sqrt(2)))
p_one = 1 - Phi(z)             # H1: pb > pa  ("gain")
p_two = 2 * (1 - Phi(abs(z)))  # H1: pb != pa
print("z=%.6f  one-sided p=%.8f  two-sided p=%.8f" % (z, p_one, p_two))

# Fisher exact test (confirmatory; exact, no normal approximation).
def fisher(n11, n1, n2, k):
    # contingency: row1 = B [k, n1-k], row2 = A [k2, n2-k2], fixed marginals
    N = n1 + n2
    k2 = k - n11 if False else None
def fisher_table(a11, a1n, an1, ann):
    # 2x2 [[a11, a12],[a21,a22]] with margins fixed
    a12 = a1n - a11; a21 = an1 - a11; a22 = an1 and (a1n + a21 and (an1 - a11))
    # compute from margins
    r1, r2 = a1n, ann
    c1, c2 = an1, a11  # placeholder
def logbinom(n, k):
    return math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1)

def fisher_exact(table):
    # table = [[a, b], [c, d]]; returns (two-sided, P(X>=a), P(X<=a)) hypergeometric
    (a, b), (c, d) = table
    r1, r2 = a + b, c + d
    c1, n = a + c, r1 + r2
    lo = max(0, c1 - r2); hi = min(r1, c1)
    denom = logbinom(n, c1)
    probs = {}
    for x in range(lo, hi + 1):
        probs[x] = math.exp(logbinom(r1, x) + logbinom(r2, c1 - x) - denom)
    pobs = probs[a]
    p_ge = sum(p for x, p in probs.items() if p <= pobs + 1e-12)
    p_right = sum(p for x, p in probs.items() if x >= a)
    p_left = sum(p for x, p in probs.items() if x <= a)
    return p_ge, p_right, p_left

t = [[cb, nb - cb], [ca, na - ca]]
f_two, f_right, f_left = fisher_exact(t)
print("Fisher: two-sided p=%.8f  one-sided(B>A) p=%.8f" % (f_two, f_right))

# Sanity: relative lift
print("relative lift = %.4f%%" % (100 * (pb / pa - 1)))

# Also compute naive (no dedupe) to show the trap
naive = collections.defaultdict(lambda: [0, 0])
for r in csv.DictReader(open("telemetry/playtest_ab.csv", newline="", encoding="utf-8-sig")):
    v = r["variant"].strip().lower(); c = int(r["completed_tutorial"])
    naive[v][0] += 1; naive[v][1] += c
print("naive (no dedupe):", dict(naive))
