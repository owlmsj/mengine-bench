import csv, collections

path = "telemetry/playtest_ab.csv"
rows = list(csv.DictReader(open(path, newline="", encoding="utf-8-sig")))
print("total rows", len(rows))
print("columns", list(rows[0].keys()))

raw_variants = collections.Counter(r["variant"] for r in rows)
print("raw variants", dict(raw_variants))
print("raw completed", dict(collections.Counter(r["completed_tutorial"] for r in rows)))

ids = collections.Counter(r["session_id"] for r in rows)
dups = {k: v for k, v in ids.items() if v > 1}
print("unique session_id", len(ids), "duplicated ids", len(dups), "max repeat", max(ids.values()))

# conflicting info across duplicate rows
byid = collections.defaultdict(list)
for r in rows:
    byid[r["session_id"]].append(r)
conflict_v = 0; conflict_c = 0; conflict_p = 0
for k, v in byid.items():
    if len(v) > 1:
        if len({x["variant"].strip().lower() for x in v}) > 1: conflict_v += 1
        if len({x["completed_tutorial"].strip() for x in v}) > 1: conflict_c += 1
        if len({x["player_id"].strip() for x in v}) > 1: conflict_p += 1
print("dup ids with conflicting variant/completed/player:", conflict_v, conflict_c, conflict_p)

# check blank/malformed fields
for col in rows[0].keys():
    blanks = sum(1 for r in rows if not r[col] or not r[col].strip())
    print("blank", col, blanks)

# sample duplicates
print("sample dup groups:")
for k, v in list((k,v) for k,v in byid.items() if len(v) > 1)[:8]:
    print(k, [(x["variant"], x["completed_tutorial"], x["player_id"], x["match_minutes"]) for x in v])
