# Pixel Arena tutorial A/B: ship B

## Decision
Ship **B**. B lifts tutorial completion from 38.0% to 46.7% (+8.67 pp, +22.8% relative) on 900 unique sessions per arm. The gain clears the release rule's 5% significance bar by a wide margin under every reasonable test.

## Assumptions (brief leaves these open)
- `session_id` is the unit of analysis; ETL resends are duplicate rows and are dropped (70 duplicate rows, all byte-identical, no conflicting variant/outcome/player). 1870 rows -> 1800 unique sessions.
- `variant` is normalized with `.strip().lower()` (`A`, ` A`, `a` -> A; `B`, ` B`, `b` -> B), per README.
- `completed_tutorial` is read as 0/1; no blanks or malformed values found.
- Test: pooled two-proportion z-test on completion rates. Headline `p_value` is the **two-sided** p-value, the conservative choice a skeptical lead would demand; the release rule's word "gain" would also justify a one-sided test, which is even more favorable. Fisher's exact test is reported as a distribution-free cross-check.

## Evidence
| Metric | A | B |
|---|---|---|
| Unique sessions | 900 | 900 |
| Completed | 342 | 420 |
| Completion rate | 0.3800 | 0.4667 |

- Absolute lift: +0.0867 (8.67 pp); relative lift: +22.8%.
- Pooled z = 3.721. Two-sided p = 0.000198; one-sided p = 0.000099.
- Fisher exact: two-sided p = 0.000237; one-sided p = 0.000119.
- All p-values << 0.05, so the conclusion is not sensitive to one- vs two-sided or z-test vs exact test.
- Randomization check: exactly 900 sessions per arm after dedupe, consistent with a balanced split.

## Caveats
- This is a single cumulative snapshot of completion only; no segment, novelty-effect, or retention analysis was supplied, so the recommendation is limited to the stated release rule.
- Significance here means statistical, not necessarily practical; the effect size is large enough (8.67 pp) that it is also practically meaningful for a tutorial.
