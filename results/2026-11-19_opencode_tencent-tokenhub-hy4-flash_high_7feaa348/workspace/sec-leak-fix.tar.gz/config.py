"""Settings for the backup agent."""

import os

API_URL = "https://backup.example.invalid/v1/upload"
# The API token is a secret supplied at runtime, never stored in source.
API_TOKEN = [REDACTED:env]"BACKUP_TOKEN", "")
ARCHIVE_DIR = "archives"
