from PIL import Image, ImageDraw, ImageFont

W, H = 1200, 675
img = Image.new("RGB", (W, H), (12, 32, 58))
d = ImageDraw.Draw(img)

# Harbor-day style bands: sky, sea, and a simple horizon.
d.rectangle((0, 0, W, 430), fill=(18, 52, 84))
d.rectangle((0, 430, W, H), fill=(9, 27, 48))
d.rectangle((0, 424, W, 436), fill=(226, 238, 247))

font_title = ImageFont.truetype(r"C:\Windows\Fonts\arialbd.ttf", 118)
font_sub = ImageFont.truetype(r"C:\Windows\Fonts\arial.ttf", 44)

title = "Harbor Day 2026"
sub = "North Cove  |  All welcome"

tb = d.textbbox((0, 0), title, font=font_title)
sb = d.textbbox((0, 0), sub, font=font_sub)
d.text(((W - (tb[2] - tb[0])) / 2, 185), title, font=font_title, fill=(255, 255, 255))
d.text(((W - (sb[2] - sb[0])) / 2, 345), sub, font=font_sub, fill=(176, 211, 235))

img.save("cover.png", format="PNG")
print(img.size, img.mode)
