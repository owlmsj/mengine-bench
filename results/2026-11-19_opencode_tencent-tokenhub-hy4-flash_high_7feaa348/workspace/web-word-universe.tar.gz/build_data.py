import os, re, json, unicodedata, collections
from urllib.parse import unquote

ROOT = os.path.dirname(os.path.abspath(__file__))
SITE = os.path.join(ROOT, 'site')

def norm(s):
    return unicodedata.normalize('NFC', s).strip().lower()

def pretty(s):
    return unicodedata.normalize('NFC', s).strip()

def stem(f):
    return norm(os.path.splitext(unquote(f))[0])

dbg = json.load(open(os.path.join(ROOT, 'parsed_debug.json'), encoding='utf-8'))
L = dbg['links']
valid = set(L)

nodes = {}
for key, v in L.items():
    syn = sorted({t for t, _ in v['sinonimos'] if t in valid})
    ana = sorted({t for t, _ in v['analogas'] if t in valid})
    label = pretty(v['h1'])
    nodes[key] = {
        'id': key,
        'label': label,
        'theme': v['tema'],
        'syn': syn,
        'ana': ana,
        'file': None,
    }

# map each canonical word to its source filename (decoded from percent-encoding)
for f in os.listdir(SITE):
    if f.endswith('.html'):
        s = stem(f)
        if s in nodes and nodes[s]['file'] is None:
            nodes[s]['file'] = unquote(f)

# redirect aliases
aliases = {k: v for k, v in dbg['redirects'].items()}

# words.json: canonical word -> all linked words
words = {k: sorted(set(v['syn']) | set(v['ana'])) for k, v in nodes.items()}

pairs = set()
for k, arr in words.items():
    for t in arr:
        pairs.add(tuple(sorted((k, t))))

deg = collections.Counter()
for a, b in pairs:
    deg[a] += 1
    deg[b] += 1
mx = max(deg.values())
top = sorted([k for k, d in deg.items() if d == mx])

result = {
    'words': len(words),
    'relations': len(pairs),
    'most_connected': top,
    'most_connected_degree': mx,
}

os.makedirs(os.path.join(ROOT, 'universe'), exist_ok=True)
with open(os.path.join(ROOT, 'words.json'), 'w', encoding='utf-8') as fh:
    json.dump(words, fh, ensure_ascii=False, indent=2)
with open(os.path.join(ROOT, 'result.json'), 'w', encoding='utf-8') as fh:
    json.dump(result, fh, ensure_ascii=False, indent=2)

payload = {
    'nodes': [nodes[k] for k in sorted(nodes)],
    'aliases': aliases,
    'stats': result,
}
with open(os.path.join(ROOT, 'graph_payload.json'), 'w', encoding='utf-8') as fh:
    json.dump(payload, fh, ensure_ascii=False, separators=(',', ':'))

print(json.dumps(result, ensure_ascii=False, indent=2))
print('broken:', dbg['broken'])
print('themes:', collections.Counter(n['theme'] for n in nodes.values()))
