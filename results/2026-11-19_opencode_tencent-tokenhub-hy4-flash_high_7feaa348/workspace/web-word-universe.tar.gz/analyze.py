import os, re, json, unicodedata
from urllib.parse import unquote

ROOT = os.path.dirname(os.path.abspath(__file__))
SITE = os.path.join(ROOT, 'site')
files = sorted(os.listdir(SITE))
print('files', len(files))

def norm(s):
    return unicodedata.normalize('NFC', s).strip().lower()

def stem(f):
    return norm(os.path.splitext(unquote(f))[0])

# read all files as utf-8
data = {}
for f in files:
    if not f.endswith('.html'):
        continue
    with open(os.path.join(SITE, f), encoding='utf-8') as fh:
        data[f] = fh.read()

# detect redirects
redirects = {}
for f, txt in data.items():
    m = re.search(r'url=([^\s"\'>]+)', txt)
    if 'http-equiv="refresh"' in txt and m:
        redirects[stem(f)] = stem(unquote(m.group(1)))
        print('REDIRECT', f, '->', unquote(m.group(1)))

# canonical file stem set
stems = set(stem(f) for f in data)
print('stems', len(stems))
canonical = {s for s in stems if s not in redirects}
print('canonical', len(canonical))

def resolve(target):
    t = stem(target)
    seen = set()
    while t in redirects and t not in seen:
        seen.add(t)
        t = redirects[t]
    return t

# special pages to exclude
special = {'index', 'sobre', 'contato'}

links_out = {}
broken = set()
missing_detail = []
for f, txt in data.items():
    s = stem(f)
    if s in redirects or s in special:
        continue
    h1 = re.search(r'<h1>(.*?)</h1>', txt, re.S)
    tema = re.search(r'class="tema">\s*Tema:\s*(.*?)\s*</p>', txt, re.S)
    rels = {'sinonimos': [], 'analogas': []}
    for sec in ('sinonimos', 'analogas'):
        m = re.search(r'<section id="%s".*?>(.*?)</section>' % sec, txt, re.S)
        if m:
            for href, label in re.findall(r'<a href="([^"]+)">(.*?)</a>', m.group(1), re.S):
                target = resolve(unquote(href))
                rels[sec].append((target, re.sub(r'<.*?>', '', label).strip()))
                if target not in canonical:
                    broken.add(target)
    links_out[s] = {'h1': re.sub(r'<.*?>', '', h1.group(1)).strip() if h1 else None,
                    'tema': norm(tema.group(1)) if tema else None,
                    **rels}

print('word pages', len(links_out))
print('broken targets', sorted(broken))
print('missing h1', [s for s, d in links_out.items() if not d['h1']])
print('missing tema', [s for s, d in links_out.items() if not d['tema']])
print('missing sections', [s for s, d in links_out.items() if not d['sinonimos'] or not d['analogas']])

# reciprocal check: how many links go both ways
pairs = set()
for s, d in links_out.items():
    for sec in ('sinonimos', 'analogas'):
        for t, _ in d[sec]:
            if t in links_out:
                pairs.add(tuple(sorted((s, t))))
print('undirected pairs (both directions counted once)', len(pairs))

recip = 0
uni = 0
for s, d in links_out.items():
    for sec in ('sinonimos', 'analogas'):
        for t, _ in d[sec]:
            if t in links_out:
                back = links_out[t]
                if any(x == s for sec2 in ('sinonimos', 'analogas') for x, _ in back[sec2]):
                    recip += 1
                else:
                    uni += 1
print('directed links reciprocal', recip, 'one-way', uni)

# count links by type
nsyn = sum(len(d['sinonimos']) for d in links_out.values())
nana = sum(len(d['analogas']) for d in links_out.values())
print('synonym links', nsyn, 'analog links', nana, 'total', nsyn+nana)

from collections import Counter
c = Counter()
for s, d in links_out.items():
    for t, _ in d['sinonimos'] + d['analogas']:
        c[t] += 1
print('most connected', c.most_common(10))

# check h1 vs stem mismatches
print('h1 vs stem mismatches:', [(s, d['h1']) for s, d in links_out.items() if norm(d['h1']) != s][:30])

with open(os.path.join(ROOT, 'parsed_debug.json'), 'w', encoding='utf-8') as fh:
    json.dump({'links': links_out, 'redirects': redirects, 'broken': sorted(broken)}, fh, ensure_ascii=False, indent=1)
