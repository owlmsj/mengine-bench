import csv, re, json
from collections import defaultdict

base = "./backoffice/"
inv = {}
with open(base + "invoices.csv", newline="", encoding="utf-8-sig") as f:
    for r in csv.DictReader(f):
        inv[r["id"]] = float(r["amount"])

pat = re.compile(r"(?:INV[-\s]?|invoice\s+)0*(\d{4})", re.I)
pays = defaultdict(list)
with open(base + "bank_statement_june.csv", newline="", encoding="utf-8-sig") as f:
    for r in csv.DictReader(f):
        m = pat.search(r["memo"])
        if not m:
            continue
        iid = "INV-" + m.group(1)
        if iid not in inv:
            continue
        pays[iid].append(float(r["amount"]))

unpaid = [i for i in inv if i not in pays]
duplicated = [i for i, v in pays.items() if len(v) > 1]
mismatched = [
    {"id": i, "invoiced": inv[i], "paid": v[0]}
    for i, v in pays.items()
    if len(v) == 1 and abs(v[0] - inv[i]) > 0.005
]

result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
print(json.dumps(result, indent=2))
print("distinct paid:", len(pays), "unpaid count:", len(unpaid))
with open("./result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
