import assert from "node:assert/strict";
import { HookBus } from "../src/bus.ts";
import { registerAuditPlugin } from "../src/plugin.ts";

// ordering + await + emit resolves after all handlers
{
  const bus = new HookBus();
  const seen: string[] = [];
  bus.on("e", async () => { await new Promise(r => setTimeout(r, 15)); seen.push("a"); });
  bus.on("e", () => { seen.push("b"); });
  await bus.emit("e", null);
  assert.deepEqual(seen, ["a", "b"], "sequential order + awaited");
}

// error rejects emit and stops later handlers
{
  const bus = new HookBus();
  const err = new Error("boom");
  let later = false;
  bus.on("e", async () => { await Promise.resolve(); throw err; });
  bus.on("e", () => { later = true; });
  await assert.rejects(() => bus.emit("e", null), (e) => e === err);
  assert.equal(later, false, "later handler skipped on error");
}

// synchronous throw also rejects emit
{
  const bus = new HookBus();
  const err = new Error("sync");
  bus.on("e", () => { throw err; });
  await assert.rejects(() => bus.emit("e", null), (e) => e === err);
}

// unsubscribe during emit affects only the next emit
{
  const bus = new HookBus();
  const seen: string[] = [];
  const off2 = bus.on("e", () => seen.push("second"));
  bus.on("e", () => { off2(); seen.push("first"); });
  await bus.emit("e", null);
  assert.deepEqual(seen, ["second", "first"]);
  seen.length = 0;
  await bus.emit("e", null);
  assert.deepEqual(seen, ["first"]);
}

// one-time notice self-unsubscribes but still completes the current emit
{
  const bus = new HookBus();
  const audit: string[] = [];
  registerAuditPlugin(bus, audit);
  const result = { tool: "read", output: "pw password=hunter2 ok" };
  await bus.emit("tool.after", result);
  assert.equal(result.output, "pw password=[redacted] ok");
  assert.deepEqual(audit, [
    "notice: tool output is audited",
    "read: pw password=[redacted] ok",
  ]);
  audit.length = 0;
  await bus.emit("tool.after", { tool: "write", output: "clean" });
  assert.deepEqual(audit, ["write: clean"], "notice only once");
}

console.log("all contract checks passed");
