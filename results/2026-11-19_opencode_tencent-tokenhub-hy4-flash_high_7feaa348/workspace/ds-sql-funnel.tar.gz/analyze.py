"""Compute the install -> tutorial -> match -> purchase funnel per METRICS.md."""
import json
import sqlite3

STEPS = ('install', 'tutorial_complete', 'first_match', 'purchase')

con = sqlite3.connect('analytics.db')
players = {uid: platform for uid, platform, is_test in con.execute(
    'select user_id, platform, is_test from users where is_test = 0')}
events = {}
for uid, name, ts in con.execute('select user_id, name, ts from events'):
    if uid in players and name in STEPS:
        events.setdefault((uid, name), []).append(ts)

funnel = {}
for platform in sorted(set(players.values())):
    counts = dict.fromkeys(STEPS, 0)
    for uid, plat in players.items():
        if plat != platform:
            continue
        prev_ts = None
        for step in STEPS:
            # First occurrence at or after the previous valid step (inclusive);
            # that occurrence becomes the time for the following step.
            valid = sorted(t for t in events.get((uid, step), ())
                           if prev_ts is None or t >= prev_ts)
            if not valid:
                break
            prev_ts = valid[0]
            counts[step] += 1
    funnel[platform] = counts

biggest = {}
for platform, counts in funnel.items():
    conv = {step: counts[step] / counts[STEPS[i - 1]]
            for i, step in enumerate(STEPS) if i > 0 and counts[STEPS[i - 1]]}
    biggest[platform] = min(conv, key=conv.get)
    print(platform, counts,
          {s: round(v, 4) for s, v in conv.items()},
          'biggest drop:', biggest[platform])

with open('result.json', 'w', encoding='utf-8') as f:
    json.dump({'funnel': funnel, 'biggest_drop': biggest}, f, indent=2)
    f.write('\n')
