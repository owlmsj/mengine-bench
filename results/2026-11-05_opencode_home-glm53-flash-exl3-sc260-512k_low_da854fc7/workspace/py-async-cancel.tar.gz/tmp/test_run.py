import asyncio, signal, sys, time
from run import run_tasks

# 1. Importable as from run import run_tasks, signature ok (no NameError, no run at import).
# 2. Concurrency limit + completion.
async def main():
    log = []
    running = 0
    peak = 0

    def make_job(i, delay=0.05):
        async def job():
            nonlocal running, peak
            running += 1
            peak = max(peak, running)
            try:
                await asyncio.sleep(delay)
                log.append(i)
            finally:
                running -= 1
        return job

    tasks = [make_job(i) for i in range(20)]
    t0 = time.monotonic()
    await run_tasks(tasks, max_concurrent=5)
    dt = time.monotonic() - t0
    assert sorted(log) == list(range(20)), log
    assert peak == 5, peak
    assert 0.15 < dt < 0.6, dt  # 4 waves of 5, not 1 wave (0.05) or serial (1.0)
    print("PASS concurrency/completion: peak=5, all 20 done, dt=%.2f" % dt)

# 3. Ctrl+C / cancellation: remaining jobs cancelled, cleanup runs.
async def main_interrupt():
    ran, cleaned = [], []

    def make_job(i, delay=0.05):
        async def job():
            try:
                await asyncio.sleep(delay)
                ran.append(i)
            finally:
                cleaned.append(i)
        return job

    tasks = [make_job(i, delay=(2.0 if i == 0 else 0.05)) for i in range(5)]
    try:
        await asyncio.wait_for(run_tasks(tasks, max_concurrent=3), timeout=0.15)
        raise AssertionError("should have been cancelled")
    except (asyncio.TimeoutError, asyncio.CancelledError):
        pass
    assert ran == [1, 2, 3, 4], ran            # fast jobs finished; the 2s job was cancelled
    assert sorted(cleaned) == list(range(5)), cleaned  # EVERY job's finally ran
    print("PASS interruption: ran=%s, cleanup ran for %s" % (ran, cleaned))

# 4. Real KeyboardInterrupt at the event loop level (what Ctrl+C does via asyncio.run).
async def main_sigint():
    cleaned = []

    def make_job(i):
        async def job():
            try:
                await asyncio.sleep(5)
            finally:
                cleaned.append(i)
        return job

    tasks = [make_job(i) for i in range(3)]
    if sys.platform == "win32":
        loop = asyncio.get_running_loop()
        def raise_interrupt():
            import _thread
            _thread.interrupt_main()
        loop.call_later(0.05, raise_interrupt)
    else:
        loop = asyncio.get_running_loop()
        loop.call_later(0.05, lambda: signal.raise_signal(signal.SIGINT))
    try:
        await run_tasks(tasks, max_concurrent=3)
        raise AssertionError("should have raised KeyboardInterrupt")
    except KeyboardInterrupt:
        pass
    assert sorted(cleaned) == list(range(3)), cleaned
    print("PASS real SIGINT: cleanup ran for %s" % cleaned)

# 5. Bad max_concurrent rejected; jobs may also return plain Futures/Tasks.
async def main_misc():
    try:
        await run_tasks([], 0)
        raise AssertionError("0 accepted")
    except ValueError as e:
        print("PASS validation:", e)
    res = []
    async def src():
        return 7
    fut = asyncio.ensure_future(src())
    async def wrap_fut():
        return fut
    await run_tasks([wrap_fut], 1)
    assert fut.result() == 7
    print("PASS future-returning task")

asyncio.run(main())
asyncio.run(main_interrupt())
asyncio.run(main_sigint())
asyncio.run(main_misc())
print("ALL TESTS PASSED")