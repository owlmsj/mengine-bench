"""Batch runner helper.

Usage:
    from run import run_tasks
    await run_tasks(tasks, max_concurrent=8)

Each item in ``tasks`` is a zero-argument callable returning an awaitable
(a coroutine, Future or Task). At most ``max_concurrent`` jobs run at once.
run_tasks returns when every job is done.

On Ctrl+C (KeyboardInterrupt, delivered by asyncio.run as a cancellation of
the main task) the remaining jobs are cancelled, and we await them so their
cleanup code (finally blocks, context managers, async with) still runs, then
the interruption propagates.
"""

import asyncio


async def run_tasks(tasks, max_concurrent):
    """Run ``tasks`` with at most ``max_concurrent`` jobs in flight."""
    if not isinstance(max_concurrent, int) or max_concurrent < 1:
        raise ValueError(f"max_concurrent must be a positive int, got {max_concurrent!r}")

    semaphore = asyncio.Semaphore(max_concurrent)

    async def run_one(task):
        async with semaphore:
            return await task()

    jobs = [asyncio.ensure_future(run_one(task)) for task in tasks]
    try:
        await asyncio.gather(*jobs)
    except (asyncio.CancelledError, KeyboardInterrupt):
        # Interrupted: cancel whatever is still running and wait for each job
        # so its cleanup code (finally / async with / context manager exit)
        # executes before we propagate the interruption.
        for job in jobs:
            job.cancel()
        await asyncio.gather(*jobs, return_exceptions=True)
        raise