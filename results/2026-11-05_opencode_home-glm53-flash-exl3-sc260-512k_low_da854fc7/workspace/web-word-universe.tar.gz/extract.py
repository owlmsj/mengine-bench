import os, re, json, urllib.parse, collections

site = 'site'
pages = {}
for f in os.listdir(site):
    if not f.endswith('.html'):
        continue
    html = open(os.path.join(site, f), encoding='utf-8', errors='replace').read()
    m = re.search(r'redirect.*?url=([\w.%-]+)\.html', html)
    if m:
        pages[urllib.parse.unquote(f)[:-5]] = {'redirect': urllib.parse.unquote(m.group(1))}
        continue
    h1 = re.search(r'<h1>(.*?)</h1>', html)
    tema = re.search(r'Tema:\s*(.*?)</p>', html)
    sin = re.findall(r'<section id="sinonimos">.*?</section>', html, re.S)
    ana = re.findall(r'<section id="analogas">.*?</section>', html, re.S)
    def links(block):
        return [(urllib.parse.unquote(u), t) for u, t in re.findall(r'<a href="([\w.%-]+)\.html">(.*?)</a>', block)]
    pages[urllib.parse.unquote(f)[:-5]] = {
        'name': h1.group(1) if h1 else urllib.parse.unquote(f)[:-5],
        'tema': tema.group(1) if tema else None,
        'sinonimos': links(sin[0]) if sin else [],
        'analogas': links(ana[0]) if ana else []}

def resolve(name, depth=0):
    p = pages.get(name)
    if p and 'redirect' in p and depth < 3:
        return resolve(p['redirect'], depth + 1)
    return name

words = {}
for fname, p in pages.items():
    if 'redirect' in p or p['tema'] is None:
        continue  # redirect stubs (saudades/coracoes/paixoes) and non-word pages (Sobre, Contato, index)
    words[p['name']] = {'tema': p['tema'], 'links': {'sinonimo': [], 'analog': []}}
    seen = {'sinonimo': set(), 'analog': set()}
    for rel, sec in (('sinonimo', 'sinonimos'), ('analog', 'analogas')):
        for target, text in p[sec]:
            tc = resolve(target)
            tp = pages.get(tc)
            if not tp or 'redirect' in tp:
                continue  # broken link, e.g. rascunho-3.html
            tname = tp['name']
            if tname == p['name'] or tname in seen[rel]:
                continue
            seen[rel].add(tname)
            words[p['name']]['links'][rel].append(tname)

pairs = set()
deg = {}
for w, d in words.items():
    all_linked = set(d['links']['sinonimo']) | set(d['links']['analog'])
    deg[w] = len(all_linked)
    for t in all_linked:
        pairs.add(tuple(sorted((w, t))))

alltargets = set()
for d in words.values():
    alltargets |= set(d['links']['sinonimo']) | set(d['links']['analog'])
orphans = sorted(set(words) - alltargets)

print('words:', len(words))
print('distinct pairs:', len(pairs))
print('most_connected:', sorted(deg.items(), key=lambda kv: -kv[1])[:10])
print('saudade:', words.get('saudade'))
print('orphan pages:', orphans)

with open('words.json', 'w', encoding='utf-8') as f:
    json.dump(words, f, ensure_ascii=False, indent=1)
top = max(deg.items(), key=lambda kv: kv[1])
with open('result.json', 'w', encoding='utf-8') as f:
    json.dump({'words': len(words), 'relations': len(pairs),
               'most_connected': {'word': top[0], 'degree': top[1]}}, f, ensure_ascii=False, indent=1)