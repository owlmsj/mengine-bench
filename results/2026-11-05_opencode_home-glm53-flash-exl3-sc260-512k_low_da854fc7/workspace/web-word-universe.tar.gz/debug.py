import re
s = '<a href="esperanca.html">Esperanca</a>'
print(re.findall(r'<a href="([\w.%-]+)\.html">(.*?)</a>', s))
print(re.findall(r'<a href="([^"]+)\.html">(.*?)</a>', s))