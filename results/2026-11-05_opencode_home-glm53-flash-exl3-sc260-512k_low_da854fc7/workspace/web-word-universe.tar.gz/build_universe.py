import json, collections

d = json.load(open('words.json', encoding='utf-8'))
rich = json.load(open('rich.json', encoding='utf-8'))  # word -> {tema, sinonimo, analog}
pairs = set()
for w, ls in d.items():
    for t in ls:
        pairs.add(tuple(sorted((w, t))))
top = max((len(v) for v in d.values()))
deg = {w: len(v) for w, v in d.items()}
temas = collections.Counter(rich[w]['tema'] for w in d)
palette = {}
colors = ['#e05780', '#4ea8de', '#ffb703', '#8ac926', '#9d4edd', '#ff8c42', '#38bdbc', '#c9ada7', '#ffd166', '#90be6d', '#f28482', '#577590']
for t, _ in temas.most_common():
    palette[t] = colors[len(palette) % len(colors)]

data = {
    'palette': palette,
    'words': {w: {'tema': rich[w]['tema'], 'sinonimo': rich[w]['links']['sinonimo'], 'analog': rich[w]['links']['analog'], 'grau': deg[w]} for w in d},
}
inline = json.dumps(data, ensure_ascii=False).replace('</', '<\\/')
top_words = sorted(deg.items(), key=lambda kv: -kv[1])[:5]

html = """<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8">
<title>Universo de Palavras | Dicionário Criativo</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,700;1,500&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
:root{--bg:#0b0d14;--ink:#e8e6df;--dim:#7d8698;--line:#232838;--acc:#ffd166}
*{box-sizing:border-box;margin:0}
body{background:var(--bg);color:var(--ink);font-family:'IBM Plex Mono',monospace;overflow:hidden;height:100vh;display:flex;flex-direction:column}
header{display:flex;gap:14px;align-items:center;padding:10px 16px;border-bottom:1px solid var(--line);z-index:5;background:rgba(11,13,20,.85)}
h1{font-family:'Cormorant Garamond',serif;font-weight:700;font-size:20px;letter-spacing:.02em}
h1 em{color:var(--acc)}
#busca{flex:0 1 320px;background:#12151f;border:1px solid var(--line);color:var(--ink);font:inherit;padding:7px 12px;border-radius:6px;outline:none}
#busca:focus{border-color:var(--acc)}
#sugestoes{position:absolute;top:46px;left:230px;max-width:340px;background:#12151f;border:1px solid var(--line);border-radius:6px;list-style:none;z-index:9;display:none}
#sugestoes li{padding:7px 12px;cursor:pointer;border-bottom:1px solid var(--line)}
#sugestoes li:hover,#sugestoes li.at{background:#1c2130}
.stats{margin-left:auto;color:var(--dim);font-size:12px;text-align:right}
canvas{flex:1;display:block;cursor:grab}
#painel{position:absolute;right:14px;top:58px;bottom:14px;width:320px;background:rgba(11,13,20,.94);border:1px solid var(--line);border-radius:10px;padding:18px;overflow:auto;display:none;z-index:6}
#painel h2{font-family:'Cormorant Garamond',serif;font-size:34px;font-weight:700;line-height:1.1}
#painel .tema{color:var(--acc);font-size:12px;text-transform:uppercase;letter-spacing:.12em;margin:6px 0 4px}
#painel .grau{color:var(--dim);font-size:12px;margin-bottom:12px}
#painel h3{font-size:12px;color:var(--dim);text-transform:uppercase;letter-spacing:.1em;margin:14px 0 6px}
#painel ul{list-style:none}
#painel li{margin:4px 0}
#painel a{color:var(--ink);text-decoration:none;border-bottom:1px dotted var(--dim);cursor:pointer}
#painel a:hover{color:var(--acc)}
#fechar{position:absolute;top:8px;right:12px;background:none;border:none;color:var(--dim);font-size:18px;cursor:pointer}
#legenda{position:absolute;left:14px;bottom:12px;font-size:11px;color:var(--dim);max-width:280px;z-index:5}
#legenda span{display:inline-block;margin:2px 8px 2px 0}
#legenda i{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:4px}
#dica{position:absolute;left:14px;top:58px;color:var(--dim);font-size:12px;z-index:5;max-width:260px;line-height:1.5}
@media(max-width:720px){#painel{left:8px;right:8px;width:auto;top:auto;height:55%}}
</style></head><body>
<header>
  <h1><em>Universo</em> de Palavras</h1>
  <input id="busca" type="search" placeholder="buscar uma palavra…" autocomplete="off" aria-label="buscar palavra">
  <ul id="sugestoes"></ul>
  <div class="stats">250 palavras · 757 relações<br>temas: LEITURA-SENTIMENTOS-TEMPO…</div>
</header>
<canvas id="ceu"></canvas>
<div id="dica">Cada ponto é uma palavra. Clique numa palavra (ou busque acima) para ver com quem ela se liga. Compartilhe: ?word=saudade</div>
<div id="legenda"></div>
<aside id="painel"><button id="fechar" aria-label="fechar">×</button><h2 id="pnome"></h2><p class="tema" id="ptema"></p><p class="grau" id="pgrau"></p><div id="prels"></div></aside>
<script type="application/json" id="dados">__DADOS__</script>
<script>
const DADOS=JSON.parse(document.getElementById('dados').textContent);
const WORDS=DADOS.words, PAL=DADOS.palette;
const nomes=Object.keys(WORDS);
const N=nomes.length;
// adjacência simétrica
const viz={}; nomes.forEach(w=>viz[w]=new Set());
for(const w of nomes) for(const t of [...WORDS[w].sinonimo,...WORDS[w].analog]) {viz[w].add(t);viz[t].add(w);}
// layout inicial determinístico: círculo por tema, baralhado por hash
function hash(s){let h=0;for(const c of s)h=(h*31+c.charCodeAt(0))>>>0;return h/4294967296;}
const pos={}; nomes.forEach(w=>{const a=hash(w)*Math.PI*2,r=60+hash(w+w)*Math.min(innerWidth,innerHeight)*0.42;pos[w]=[innerWidth/2+r*Math.cos(a),innerHeight/2+r*Math.sin(a)];});
const cv=document.getElementById('ceu'), ctx=cv.getContext('2d');
let DPR=Math.min(devicePixelRatio||1,2);
function resize(){DPR=Math.min(devicePixelRatio||1,2);cv.width=innerWidth*DPR;cv.height=innerHeight*DPR;}
resize();addEventListener('resize',()=>{resize();});
// física
const vel={}; nomes.forEach(w=>vel[w]=[0,0]);
let foco=null, arrastando=null, ultimoMouse=null;
function passo(){
  const k=260, rep=3400, centro=0.012;
  for(const w of nomes){let fx=0,fy=0;const p=pos[w];
    for(const v of viz[w]){const q=pos[v],dx=q[0]-p[0],dy=q[1]-p[1],d2=dx*dx+dy*dy||1,d=Math.sqrt(d2);
      const f=(d-k)/k*0.9;fx+=dx/d*f;fy+=dy/d*f;}
    // repulsão entre todos (grade aproximada: pares aleatórios por quadro)
    for(let i=0;i<6;i++){const v=nomes[(hash(w+''+i+frame)|0)%N];if(v===w)continue;const q=pos[v];const dx=q[0]-p[0],dy=q[1]-p[1],d2=dx*dx+dy*dy||1;const f=rep/d2;fx-=dx/d*f*0.02;fy-=dy/d*f*0.02;}
    fx+=(innerWidth/2-p[0])*centro;fy+=(innerHeight/2-p[1])*centro;
    vel[w][0]=(vel[w][0]+fx*0.02)*0.86;vel[w][1]=(vel[w][1]+fy*0.02)*0.86;}
  if(!arrastando) for(const w of nomes){if(foco===w)continue;pos[w][0]+=vel[w][0];pos[w][1]+=vel[w][1];}
}
function raio(w){return 3+Math.sqrt(WORDS[w].grau)*1.6;}
function desenha(){
  ctx.setTransform(DPR,0,0,DPR,0,0);ctx.clearRect(0,0,innerWidth,innerHeight);
  // fundo estrelado
  ctx.fillStyle='#0b0d14';ctx.fillRect(0,0,innerWidth,innerHeight);
  const vizFoco=foco?viz[foco]:null;
  // arestas
  const vistas=new Set();
  for(const w of nomes) for(const t of viz[w]){const par=w<t?w+'|'+t:t+'|'+w;if(vistas.has(par))continue;vistas.add(par);
    const a=pos[w],b=pos[t];
    let cor='rgba(125,134,152,',alpha=0.16;
    if(foco){const on=(w===foco||t===foco);alpha=on?0.75:0.05;cor=on?'rgba(255,209,102,':'rgba(125,134,152,';}
    ctx.strokeStyle=cor+alpha+')';ctx.lineWidth=(foco&&(w===foco||t===foco))?1.6:1;
    ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();}
  // nós
  for(const w of nomes){const p=pos[w],r=raio(w),c=PAL[WORDS[w].tema]||'#888';
    let alpha=1;
    if(foco){const on=(w===foco||vizFoco.has(w));alpha=on?1:0.18;}
    ctx.globalAlpha=alpha;
    ctx.fillStyle=c;ctx.beginPath();ctx.arc(p[0],p[1],r,0,7);ctx.fill();
    if(w===foco){ctx.strokeStyle='#fff';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(p[0],p[1],r+4,0,7);ctx.stroke();
      ctx.fillStyle='#fff';ctx.font='500 13px "IBM Plex Mono"';ctx.textAlign='center';ctx.fillText(w,p[0],p[1]-r-8);}
    else if(!foco&&WORDS[w].grau>=9){ctx.globalAlpha=.6;ctx.fillStyle='#e8e6df';ctx.font='11px "IBM Plex Mono"';ctx.textAlign='center';ctx.fillText(w,p[0],p[1]-r-4);}
    ctx.globalAlpha=1;}
}
let frame=0;
function laco(){frame++;passo();desenha();requestAnimationFrame(laco);}
laco();
// interação
cv.addEventListener('mousedown',e=>{ultimoMouse=[e.clientX,e.clientY];const w=perto(e);if(w){foco=w;abrePainel(w);arrastando=w;}})
cv.addEventListener('mousemove',e=>{if(arrastando){pos[arrastando]=[e.clientX,e.clientY];vel[arrastando]=[0,0];}});
addEventListener('mouseup',()=>arrastando=null);
cv.addEventListener('click',e=>{const w=perto(e);if(w){foco=w;abrePainel(w);setURL(w);}else if(!perto(e)){}});
function perto(e){let melhor=null,md=400;for(const w of nomes){const p=pos[w],dx=p[0]-e.clientX,dy=p[1]-e.clientY,d=dx*dx+dy*dy;if(d<md+raio(w)*raio(w)*2&&d<md*(1)||d<(raio(w)+6)**2){if(d<(raio(w)+8)**2&&d<md+ (raio(w)+8)**2){melhor=w;md=d;}}}return melhor;}
// painel
const painel=document.getElementById('painel');
function abrePainel(w){const d=WORDS[w];document.getElementById('pnome').textContent=w;
  document.getElementById('ptema').textContent='Tema: '+d.tema;
  document.getElementById('pgrau').textContent=d.grau+(d.grau===1?' palavra ligada':' palavras ligadas');
  const rotulos={sinonimo:'Sinônimos',analog:'Palavras análogas'};
  let html='';for(const rel of ['sinonimo','analog']){if(!d[rel].length)continue;
    html+='<h3>'+rotulos[rel]+'</h3><ul>'+d[rel].map(t=>'<li><a data-w="'+t+'">'+t+'</a></li>').join('')+'</ul>';}
  document.getElementById('prels').innerHTML=html||'<p class="grau">Sem ligações registadas.</p>';
  painel.style.display='block';}
painel.addEventListener('click',e=>{const w=e.target.getAttribute&&e.target.getAttribute('data-w');if(w){foco=w;abrePainel(w);setURL(w);}if(e.target.id==='fechar'){painel.style.display='none';foco=null;limpaURL();}});
function setURL(w){history.replaceState(null,'','?word='+encodeURIComponent(w));}
function limpaURL(){history.replaceState(null,'','?');}
// busca
const inp=document.getElementById('busca'),sug=document.getElementById('sugestoes');
function filtra(q){q=q.trim().toLowerCase();if(!q)return[];return nomes.filter(w=>w.toLowerCase().startsWith(q)).concat(nomes.filter(w=>!w.toLowerCase().startsWith(q)&&w.toLowerCase().includes(q))).slice(0,8);}
inp.addEventListener('input',()=>{const r=filtra(inp.value);sug.innerHTML=r.map(w=>'<li data-w="'+w+'">'+w+'</li>').join('');sug.style.display=r.length?'block':'none';});
inp.addEventListener('keydown',e=>{if(e.key==='Enter'){const r=filtra(inp.value);if(r.length){escolhe(r[0]);}else{naoEncontrada(inp.value.trim());}}if(e.key==='Escape'){sug.style.display='none';}});
sug.addEventListener('mousedown',e=>{const w=e.target.getAttribute&&e.target.getAttribute('data-w');if(w)escolhe(w);});
function escolhe(w){inp.value='';sug.style.display='none';foco=w;abrePainel(w);setURL(w);}
function naoEncontrada(q){document.getElementById('pnome').textContent='“'+q+'”';
  document.getElementById('ptema').textContent='fora deste universo';
  document.getElementById('pgrau').textContent='Esta palavra não está no dicionário copiado em ./site.';
  document.getElementById('prels').innerHTML='<p class="grau">Tente: '+nomes.slice(0,4).join(', ')+'…</p>';
  painel.style.display='block';foco=null;}
// legenda
document.getElementById('legenda').innerHTML=Object.entries(PAL).map(([t,c])=>'<span><i style="background:'+c+'"></i>'+t+'</span>').join('');
// ?word=
const alvo=new URLSearchParams(location.search).get('word');
if(alvo){const ache=nomes.find(w=>w.toLowerCase()===alvo.toLowerCase());
  if(ache){foco=ache;abrePainel(ache);pos[ache]=[innerWidth/2,innerHeight/2];}
  else naoEncontrada(alvo);}
</script></body></html>"""
html = html.replace('__DADOS__', inline)
html = html.replace('temas: LEITURA-SENTIMENTOS-TEMPO…', 'temas: ' + ', '.join(t for t, _ in temas.most_common())[:80])
import os
os.makedirs('universe', exist_ok=True)
open('universe/index.html', 'w', encoding='utf-8').write(html)
print('written', len(html), 'bytes; top:', top_words, 'temas:', temas.most_common())