# Rubric: did the plan deliver?

Score each plan below from public data. Inflation is the annual IPCA (IBGE), in % for the calendar year.

| plan | next plan |
|---|---|
| Cruzado (1986) | Bresser |
| Bresser (1987) | Verao |
| Verao (1989) | Collor I |
| Collor I (1990) | Collor II |
| Collor II (1991) | Real |
| Real (1994) | none |

For a plan launched in year Y:

- ipca_before = annual IPCA of year Y-1; ipca_after = annual IPCA of year Y+1.
- score_drop = clamp(1 - ipca_after / ipca_before, 0, 1)
- months_lasted = whole calendar months from the plan's launch date to the next plan's launch date
  (Real: no next plan, use 60).
- score_durability = min(months_lasted, 60) / 60
- score = 0.7 * score_drop + 0.3 * score_durability (0 to 1)

The top 3 are the three highest scores, best first.
