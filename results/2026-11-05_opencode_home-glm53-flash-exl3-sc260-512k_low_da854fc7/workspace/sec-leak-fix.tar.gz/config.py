"""Settings for the backup agent."""

import os

API_URL = "https://backup.example.invalid/v1/upload"
# The token never lives in code or logs; it comes from the environment (README.md, Configuration).
API_TOKEN = [REDACTED:env]"BACKUP_TOKEN"]
ARCHIVE_DIR = "archives"