$b = [System.IO.File]::ReadAllBytes('.\prices.db')
$ncells = [BitConverter]::ToUInt16($b, 0)
Write-Host "ncells=$ncells"
# cell pointers: 2 bytes big-endian each, starting at offset 2
$ptrs = @()
for ($i = 0; $i -lt $ncells; $i++) {
  $off = 2 + 2*$i
  $p = ($b[$off] -shl 8) -bor $b[$off+1]
  $ptrs += $p
}
Write-Host ("ptrs: " + ($ptrs -join ','))

function ReadVarInt([byte[]]$b, [int]$pos) {
  $v = 0
  for ($i = 0; $i -lt 9; $i++) {
    $byte = $b[$pos + $i]
    if ($i -eq 8) { $v = ($v -shl 8) -bor $byte; return @($v, $pos + 9) }
    $v = ($v -shl 7) -bor ($byte -band 0x7F)
    if (($byte -band 0x80) -eq 0) { return @($v, $pos + $i + 1) }
  }
  return @($v, $pos + 9)
}

$rows = @()
foreach ($p in $ptrs) {
  $payloadLenRaw = ReadVarInt $b $p
  $payloadLen = $payloadLenRaw[0]
  $rowidRaw = ReadVarInt $b ($p + $payloadLenRaw[1])
  $rowid = $rowidRaw[0]
  $recStart = $rowidRaw[1]
  $hdrLenRaw = ReadVarInt $b $recStart
  $hdrLen = $hdrLenRaw[0]
  $hdrStart = $recStart
  $bodyStart = $recStart + $hdrLen
  # serial types
  $types = @()
  $hp = $hdrStart + 1
  while ($hp -lt $hdrStart + $hdrLen) {
    $tRaw = ReadVarInt $b $hp
    $types += $tRaw[0]
    $hp = $tRaw[1]
  }
  $vals = @()
  $bp = $bodyStart
  foreach ($t in $types) {
    if ($t -eq 0) { $vals += $null }
    elseif ($t -eq 1) { $vals += [int64]($bp -ge 0 ? $b[$bp] : $b[$bp]); $bp += 1 }
    elseif ($t -eq 2) { $v = [BitConverter]::ToInt16($b, $bp); $vals += $v; $bp += 2 }
    elseif ($t -eq 3) { $v = [BitConverter]::ToInt32($b, $bp); $vals += $v; $bp += 3 }
    elseif ($t -eq 4) { $v = [BitConverter]::ToInt64($b, $bp); $vals += $v; $bp += 4 }
    elseif ($t -eq 5) { $v = [BitConverter]::ToInt64($b, $bp); $vals += $v; $bp += 6 }
    elseif ($t -eq 6) { $v = [BitConverter]::ToInt64($b, $bp); $vals += $v; $bp += 8 }
    elseif ($t -eq 7) {
      # IEEE754 big-endian double
      $bb = New-Object byte[] 8
      for ($k = 0; $k -lt 8; $k++) { $bb[7-$k] = $b[$bp+$k] }
      $v = [BitConverter]::ToDouble($bb, 0)
      $vals += $v
      $bp += 8
    }
    elseif ($t -eq 8) { $vals += 0 }
    elseif ($t -eq 9) { $vals += 1 }
    elseif ($t -ge 12 -and $t % 2 -eq 0) {
      $len = ($t - 12) / 2
      $s = [System.Text.Encoding]::UTF8.GetString($b, $bp, $len)
      $vals += $s
      $bp += $len
    }
    elseif ($t -ge 13 -and $t % 2 -eq 1) {
      $len = ($t - 13) / 2
      $vals += ("blob:" + $len)
      $bp += $len
    } else { $vals += ("unk:$t"); }
  }
  $rows += [pscustomobject]@{ rowid=$rowid; payloadLen=$payloadLen; types=($types -join ','); vals=($vals -join '|') }
}
$rows | Format-List