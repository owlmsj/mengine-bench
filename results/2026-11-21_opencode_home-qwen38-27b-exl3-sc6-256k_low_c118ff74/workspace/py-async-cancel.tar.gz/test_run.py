"""Quick checks for run.run_tasks."""
import asyncio
import sys
import time

from run import run_tasks

active = 0
peak = 0


def make_job(delay=0.05):
    async def job():
        global active, peak
        active += 1
        peak = max(peak, active)
        try:
            await asyncio.sleep(delay)
        finally:
            active -= 1
        return "done"
    return job


def test_limit_and_order():
    global active, peak
    active = 0
    peak = 0
    results = asyncio.run(run_tasks([make_job() for _ in range(10)], 3))
    assert results == ["done"] * 10, results
    assert peak <= 3, peak
    print(f"OK limit: peak={peak} results={len(results)}")


def test_order_preserved():
    def mk(i):
        async def job():
            await asyncio.sleep(0.01 * (5 - i))
            return i
        return job
    factories = [mk(i) for i in range(5)]
    results = asyncio.run(run_tasks(factories, 2))
    assert results == [0, 1, 2, 3, 4], results
    print("OK order:", results)


def test_cleanup_on_cancel():
    """Simulate Ctrl+C: cancel the outer task; job cleanup must run."""
    cleaned = []

    async def job():
        try:
            await asyncio.sleep(10)
        finally:
            cleaned.append("cleaned")

    async def main():
        await run_tasks([job], 2)

    async def driver():
        t = asyncio.create_task(main())
        await asyncio.sleep(0.05)
        t.cancel()  # stands in for KeyboardInterrupt / task cancel
        try:
            await t
        except (asyncio.CancelledError, KeyboardInterrupt):
            pass
        return cleaned

    cleaned = asyncio.run(driver())
    assert cleaned == ["cleaned"], cleaned
    print("OK cleanup on cancel:", cleaned)


def test_max_concurrent_validation():
    try:
        asyncio.run(run_tasks([make_job()], 0))
    except ValueError as e:
        print("OK validation:", e)
    else:
        raise AssertionError("expected ValueError")


if __name__ == "__main__":
    test_limit_and_order()
    test_order_preserved()
    test_cleanup_on_cancel()
    test_max_concurrent_validation()
    print("ALL OK")