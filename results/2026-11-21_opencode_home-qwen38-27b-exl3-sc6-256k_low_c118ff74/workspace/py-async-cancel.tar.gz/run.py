"""Concurrency helper for batch scripts.

Provides ``run_tasks(tasks, max_concurrent)``: run zero-argument callables
that each return an awaitable job, with at most ``max_concurrent`` jobs
running at once. Returns when every job is done.

Ctrl+C handling: on KeyboardInterrupt (SIGINT), already-started jobs are
given a chance to run their cleanup code (``finally`` blocks /
``asyncio.CancelledError`` handlers) before the function returns.

Python 3.11+, standard library only.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Iterable
from typing import TypeVar

__all__ = ["run_tasks"]

T = TypeVar("T")


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[T]]],
    max_concurrent: int,
) -> list[T]:
    """Run ``tasks`` with at most ``max_concurrent`` concurrent jobs.

    Each element of ``tasks`` is a zero-argument callable that returns an
    awaitable (e.g. a coroutine function). The callables are invoked lazily
    as slots free up, so at most ``max_concurrent`` jobs run at once.

    Returns a list of the jobs' results, in the order of ``tasks``.

    On Ctrl+C (KeyboardInterrupt) the running jobs are cancelled and awaited
    so their cleanup code (``finally`` blocks, ``async with`` exit, etc.)
    runs before this function re-raises.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent!r}")

    factories = list(tasks)
    semaphore = asyncio.Semaphore(max_concurrent)
    results: list[T | None] = [None] * len(factories)

    async def _run_one(index: int, factory: Callable[[], Awaitable[T]]) -> None:
        async with semaphore:
            results[index] = await factory()

    tasks = [asyncio.create_task(_run_one(i, f)) for i, f in enumerate(factories)]
    try:
        await asyncio.gather(*tasks)
    except (KeyboardInterrupt, asyncio.CancelledError):
        # Cancel every job that has not finished yet, then wait for them so
        # their cleanup code (finally blocks, async-with exit, etc.) runs
        # before we propagate the interrupt.
        for t in tasks:
            if not t.done():
                t.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        raise

    return results  # type: ignore[return-value]