import csv, json, math

path = r"<WORKSPACE>\telemetry\playtest_ab.csv"

# Dedupe by session_id (ETL resends: repeated rows are the same session).
# Keep first occurrence; verify duplicates are consistent.
sessions = {}
dup_inconsistencies = []
rows = 0
with open(path, newline="", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        rows += 1
        sid = r["session_id"].strip()
        variant = r["variant"].strip().lower()
        comp = int(r["completed_tutorial"])
        if sid in sessions:
            if sessions[sid] != (variant, comp):
                dup_inconsistencies.append((sid, sessions[sid], (variant, comp)))
        else:
            sessions[sid] = (variant, comp)

assert rows == 1870, rows
print("rows:", rows, "unique sessions:", len(sessions), "dup inconsistencies:", len(dup_inconsistencies))

a_n = a_c = b_n = b_c = 0
for sid, (v, c) in sessions.items():
    if v == "a":
        a_n += 1; a_c += c
    elif v == "b":
        b_n += 1; b_c += c
    else:
        raise ValueError("bad variant " + v)

p_a = a_c / a_n
p_b = b_c / b_n
print(f"A: {a_c}/{a_n} = {p_a:.6f}")
print(f"B: {b_c}/{b_n} = {p_b:.6f}")
print(f"diff (B-A): {p_b - p_a:.6f}")

# Two-proportion pooled z-test, two-sided, H0: pA = pB.
p_pool = (a_c + b_c) / (a_n + b_n)
se = math.sqrt(p_pool * (1 - p_pool) * (1 / a_n + 1 / b_n))
z = (p_b - p_a) / se
p_value = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))
print(f"pooled p: {p_pool:.6f}  se: {se:.6f}  z: {z:.6f}  p: {p_value:.6g}")
print("significant at 5% (two-sided):", p_value < 0.05)

# Unpooled (Wald) for reference
se_u = math.sqrt(p_a * (1 - p_a) / a_n + p_b * (1 - p_b) / b_n)
z_u = (p_b - p_a) / se_u
p_u = 2 * (1 - 0.5 * (1 + math.erf(abs(z_u) / math.sqrt(2))))
print(f"unpooled z: {z_u:.6f}  p: {p_u:.6g}")

result = {
    "ship_b": bool(p_value < 0.05 and p_b > p_a),
    "sessions_a": a_n,
    "sessions_b": b_n,
    "completion_rate_a": round(p_a, 6),
    "completion_rate_b": round(p_b, 6),
    "p_value": round(p_value, 6),
}
out = r"<WORKSPACE>\result.json"
with open(out, "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))