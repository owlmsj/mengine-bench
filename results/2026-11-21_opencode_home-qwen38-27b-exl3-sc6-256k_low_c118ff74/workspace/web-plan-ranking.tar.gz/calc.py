import json

# Annual IPCA (IBGE), percent, calendar year. Source: Ipeadata (FGV) series 16625, IBGE IPCA.
ipca = {
    1985: 242.23,
    1986: 79.66,
    1987: 363.41,
    1988: 980.21,
    1989: 1972.91,
    1990: 1620.97,
    1991: 472.70,
    1992: 1119.10,
    1993: 2477.15,
    1994: 916.46,
    1995: 22.41,
}

# Plan launch dates (day.month.year) and next-plan launch dates.
# Cruzado 1986-02-01 -> Bresser 1987-02-15
# Bresser 1987-02-15 -> Verao 1989-02-15
# Verao 1989-02-15 -> Collor I 1990-03-15
# Collor I 1990-03-15 -> Collor II 1991-03-15
# Collor II 1991-03-15 -> Real 1994-07-01
# Real 1994-07-01 -> none (use 60 months)
plans = [
    ("Cruzado", 1986, "1986-02-01", "1987-02-15"),
    ("Bresser", 1987, "1987-02-15", "1989-02-15"),
    ("Verao", 1989, "1989-02-15", "1990-03-15"),
    ("Collor I", 1990, "1990-03-15", "1991-03-15"),
    ("Collor II", 1991, "1991-03-15", "1994-07-01"),
    ("Real", 1994, "1994-07-01", None),
]

def months_between(d1, d2):
    y1, m1, _ = map(int, d1.split("-"))
    y2, m2, _ = map(int, d2.split("-"))
    return (y2 - y1) * 12 + (m2 - m1)

SRC = "https://www.ipeadata.gov.br/ExibeSerie.aspx?serid=16625&module=M"
results = []
for name, year, launch, nxt in plans:
    before = ipca[year - 1]
    after = ipca[year + 1]
    drop = max(0.0, min(1.0, 1 - after / before))
    if nxt is None:
        months = 60
    else:
        months = months_between(launch, nxt)
    dur = min(months, 60) / 60
    score = 0.7 * drop + 0.3 * dur
    results.append({
        "plan": name,
        "launch_date": launch,
        "ipca_before": before,
        "ipca_after": after,
        "months_lasted": months,
        "score_drop": round(drop, 4),
        "score_durability": round(dur, 4),
        "score": round(score, 4),
        "sources": [SRC],
    })

results.sort(key=lambda r: r["score"], reverse=True)
top3 = [r["plan"] for r in results[:3]]

print(json.dumps(results, indent=2))
print("TOP3:", top3)