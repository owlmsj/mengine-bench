import csv, json, re

base = r"<WORKSPACE>\backoffice"

invoices = {}
with open(f"{base}/invoices.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = float(row["amount"])

payments = []  # (invoice_id, amount)
with open(f"{base}/bank_statement_june.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        m = re.search(r"(\d{4})", memo)
        if not m:
            continue  # fees, interest, unidentified
        inv_id = "INV-" + m.group(1)
        if inv_id not in invoices:
            continue  # no identifiable invoice
        payments.append((inv_id, float(row["amount"])))

paid = {}
for inv_id, amt in payments:
    paid.setdefault(inv_id, []).append(amt)

unpaid = sorted(i for i in invoices if i not in paid)
duplicated = sorted(i for i, amts in paid.items() if len(amts) > 1)
mismatched = []
for i, amts in sorted(paid.items()):
    if len(amts) == 1 and abs(amts[0] - invoices[i]) > 0.005:
        mismatched.append({"id": i, "invoiced": invoices[i], "paid": amts[0]})

result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))