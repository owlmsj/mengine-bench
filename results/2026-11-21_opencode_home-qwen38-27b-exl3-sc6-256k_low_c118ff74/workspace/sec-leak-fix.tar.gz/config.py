"""Settings for the backup agent."""

import os

API_URL = "https://backup.example.invalid/v1/upload"
# The API token comes from the environment; never hardcode or log it.
API_TOKEN = [REDACTED:env]"BACKUP_TOKEN", "")
ARCHIVE_DIR = "archives"