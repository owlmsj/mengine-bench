# Handoff: local-9b at 128k context

**Done.** local-9b Q5_K_M runs at 128k ctx: decode ~37.8-38.0 t/s, final VRAM 7697 MiB, no spill (median of 3). Root cause: mmproj offload spilled 1494 MiB past the 7881 MiB WDDM ceiling; fixed with `--no-mmproj-offload -ub 512`. Recipe applied in `scripts/start_server.ps1:165` (local9 block) and `profiles/local/local-9b.json`. Q6_K (7.03 GiB) does not fit at 128k - discarded; Q4_K_M (7305 MiB, 40.4 t/s) kept only as fallback.

**Left:**
1. evals README still cites `check_vision.ps1`, which no longer exists - update it.
2. Review names of the scratchpad temp files (noted repeatedly, never done).

**Assumptions:** this workspace holds only the transcript; the referenced scripts/profiles live in the project repo, not here.

**How I know it is right:** numbers above are the transcript's own measurements (steps 10, 42, 45, 63, 76); the fix is recorded as applied (step 63).