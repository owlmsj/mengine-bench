import sqlite3
c = sqlite3.connect(r'<WORKSPACE>\analytics.db')
for r in c.execute("SELECT name, sql FROM sqlite_master WHERE type='table'"):
    print(r[0])
    print(r[1])
    print('---')
for t in [r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")]:
    n = c.execute(f"SELECT COUNT(*) FROM [{t}]").fetchone()[0]
    print(t, n)
    for row in c.execute(f"SELECT * FROM [{t}] LIMIT 5"):
        print(row)
    print('===')