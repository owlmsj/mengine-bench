import sqlite3, json
c = sqlite3.connect(r'<WORKSPACE>\analytics.db')
STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']
users = c.execute("SELECT user_id, platform, is_test FROM users").fetchall()
events = {}
for uid, name, ts in c.execute("SELECT user_id, name, ts FROM events"):
    events.setdefault(uid, []).append((ts, name))
funnel = {}
for uid, plat, is_test in users:
    if is_test:
        continue
    if plat not in funnel:
        funnel[plat] = {s: 0 for s in STEPS}
    evs = events.get(uid, [])
    prev = None  # ts of previous step
    reached = 0
    for i, s in enumerate(STEPS):
        best = None
        for ts, name in evs:
            if name == s and (prev is None or ts >= prev):
                if best is None or ts < best:
                    best = ts
        if best is not None:
            prev = best
            funnel[plat][s] += 1
            reached = i + 1
        else:
            break
# biggest drop: step with lowest conversion (players / previous step players)
out = {'funnel': {}, 'biggest_drop': {}}
for plat, f in sorted(funnel.items()):
    out['funnel'][plat] = f
    conv = {}
    for i, s in enumerate(STEPS):
        if i == 0:
            continue
        prev_n = f[STEPS[i-1]]
        conv[s] = f[s] / prev_n if prev_n else None
    # lowest conversion among steps 2..4
    lowest = min(conv, key=lambda s: (conv[s] is None, conv[s]))
    out['biggest_drop'][plat] = lowest
print(json.dumps(out, indent=2))
with open(r'<WORKSPACE>\result.json', 'w') as fh:
    json.dump(out, fh, indent=2)