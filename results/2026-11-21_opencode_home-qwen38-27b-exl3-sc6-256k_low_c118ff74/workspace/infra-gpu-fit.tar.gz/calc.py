import csv

# Memory requirements (GB = 10^9 bytes)
weights_gb = 70e9 * 1 / 1e9  # 70B params, FP8 = 1 byte/param -> 70 GB
kv_per_token = 327_680  # bytes
ctx = 32_768
seqs = 4
kv_cache_gb = kv_per_token * ctx * seqs / 1e9
overhead_gb = 8.0
total_gb = weights_gb + kv_cache_gb + overhead_gb

print(f"weights_gb={weights_gb}")
print(f"kv_cache_gb={kv_cache_gb}")
print(f"total_gb={total_gb}")

CAP = 4.0
REGIONS = {"us-east", "us-central", "eu-west"}
rows = list(csv.DictReader(open("offers.csv", newline="")))
ok = []
for r in rows:
    if r["in_stock"].strip().lower() != "yes":
        print(f"skip {r['offer_id']}: out of stock")
        continue
    if r["region"].strip() not in REGIONS:
        print(f"skip {r['offer_id']}: region {r['region']}")
        continue
    price = float(r["usd_per_hour"])
    if price > CAP:
        print(f"skip {r['offer_id']}: ${price}/h over cap")
        continue
    vram = int(r["gpu_count"]) * int(r["vram_gb_per_gpu"])
    if vram < total_gb:
        print(f"skip {r['offer_id']}: vram {vram} GB < {total_gb} GB")
        continue
    ok.append((price, r["offer_id"], vram))
    print(f"OK   {r['offer_id']}: vram {vram} GB, ${price}/h")

ok.sort()
best = ok[0]
print(f"\nBEST: {best[1]} at ${best[0]}/h, ${best[0]*730:.2f}/month")
import json
json.dump({
    "weights_gb": weights_gb,
    "kv_cache_gb": kv_cache_gb,
    "total_gb": total_gb,
    "offer_id": best[1],
    "usd_per_hour": best[0],
    "usd_per_month": round(best[0] * 730, 2),
}, open("result.json", "w"), indent=2)
print(open("result.json").read())