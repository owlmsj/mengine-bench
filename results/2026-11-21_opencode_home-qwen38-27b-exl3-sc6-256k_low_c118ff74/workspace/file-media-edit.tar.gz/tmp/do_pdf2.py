from pypdf import PdfReader, PdfWriter
from pypdf.generic import NameObject
import os
WS = r"<WORKSPACE>"
fields = {
    "organizer": "Tidewater Studio",
    "event_date": "2026-12-05",
    "location": "North Cove Lawn",
    "attendees": "40",
}
reader = PdfReader(os.path.join(WS, "permit-form.pdf"))
writer = PdfWriter(clone_from=reader)
# fill and generate appearance streams so values are visible
writer.update_page_form_field_values(writer.pages[0], fields, auto_regenerate=False)
# remove AcroForm so the form is no longer editable; keep annots (with /AP) so values render
if "/AcroForm" in writer._root_object:
    del writer._root_object[NameObject("/AcroForm")]
with open(os.path.join(WS, "out", "permit-filled.pdf"), "wb") as f:
    writer.write(f)
print("saved")
r = PdfReader(os.path.join(WS, "out", "permit-filled.pdf"))
p = r.pages[0]
print("fields:", r.get_fields())
print("acroform:", "/AcroForm" in r.trailer["/Root"])
ann = p.get("/Annots") or []
print("annots:", len(ann))
for a in ann:
    o = a.get_object()
    print(" ", o.get("/T"), "V=", o.get("/V"), "AP=", "/AP" in o)