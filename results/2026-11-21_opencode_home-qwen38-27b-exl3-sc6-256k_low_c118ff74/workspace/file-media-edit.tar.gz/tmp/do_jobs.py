from PIL import Image
from pypdf import PdfReader, PdfWriter
import os

WS = r"<WORKSPACE>"
os.makedirs(os.path.join(WS, "out"), exist_ok=True)

# --- Job 1: feed photo 1080x1350 with magenta balloon fully inside ---
img = Image.open(os.path.join(WS, "launch.jpg"))
W, H = img.size  # 3000x2000
# balloon bbox from detection: (2350,500)-(2750,900), center (2549,700)
bw, bh = 400, 400
cx, cy = 2549, 700
target_ratio = 1080 / 1350  # 0.8
# crop width = 1080/1350 * height; choose crop size so balloon fits with margin
# balloon needs at least bw x bh; add margin
margin = 120
need_w = bw + 2 * margin  # 640
need_h = bh + 2 * margin  # 640
# crop must be 0.8 ratio: w = 0.8*h
# try height = need_h -> width = 0.8*640=512 < need_w, so width-limited
h = need_w / target_ratio  # 800
w = int(h * target_ratio)  # 640
# center on balloon, clamp to image
x0 = int(cx - w / 2)
y0 = int(cy - h / 2)
x0 = max(0, min(x0, W - w))
y0 = max(0, min(y0, H - h))
crop = img.crop((x0, y0, x0 + w, y0 + h))
out = crop.resize((1080, 1350), Image.LANCZOS)
out.save(os.path.join(WS, "out", "feed-photo.jpg"), quality=92)
print("feed-photo saved, crop:", (x0, y0, x0 + w, y0 + h))

# --- Job 2: fill permit form and flatten ---
reader = PdfReader(os.path.join(WS, "permit-form.pdf"))
writer = PdfWriter()
writer.append_pages_from_reader(reader)
# fill fields
fields = {
    "organizer": "Tidewater Studio",
    "event_date": "2026-12-05",
    "location": "North Cove Lawn",
    "attendees": "40",
}
for page in writer.pages:
    if "/Annots" in page:
        for a in page["/Annots"]:
            o = a.get_object()
            name = o.get("/T")
            if name in fields:
                o[writer._add_object if False else "/V"] = fields[name]
                o["/AS"] = None if False else o.get("/AS")
                # set appearance
                from pypdf.generic import NameObject, TextStringObject
                o[NameObject("/V")] = TextStringObject(fields[name])
# flatten: remove form fields after filling
writer.remove_images = False
# pypdf flatten: use clone_from? Actually pypdf has no flatten; use set_need_appearances False and remove annots
# Simplest: after filling, remove the AcroForm and annots to make it non-editable
# We'll write out then strip form
with open(os.path.join(WS, "out", "permit-filled.pdf"), "wb") as f:
    writer.write(f)
print("permit-filled saved (pre-flatten)")

# Flatten: remove AcroForm and field annots
r2 = PdfReader(os.path.join(WS, "out", "permit-filled.pdf"))
w2 = PdfWriter()
w2.append_pages_from_reader(r2)
# remove AcroForm
if "/AcroForm" in w2._root_object:
    del w2._root_object["/AcroForm"]
for page in w2.pages:
    if "/Annots" in page:
        del page["/Annots"]
with open(os.path.join(WS, "out", "permit-filled.pdf"), "wb") as f:
    w2.write(f)
print("permit-filled flattened")