from PIL import Image
import numpy as np

img = Image.open(r"<WORKSPACE>\launch.jpg")
print("size:", img.size, "mode:", img.mode)
a = np.asarray(img.convert("RGB")).astype(int)
r, g, b = a[..., 0], a[..., 1], a[..., 2]
# magenta: high R, low G, high B
mask = (r > 150) & (g < 120) & (b > 150) & ((r - g) > 60) & ((b - g) > 60)
ys, xs = np.where(mask)
print("magenta px:", len(xs))
if len(xs):
    print("bbox:", xs.min(), ys.min(), xs.max(), ys.max())
    print("center:", int(xs.mean()), int(ys.mean()))