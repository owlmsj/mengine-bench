from pypdf import PdfReader
r = PdfReader(r"<WORKSPACE>\permit-form.pdf")
print("pages:", len(r.pages))
for i, p in enumerate(r.pages):
    f = p.get("/Annots")
    if f:
        for a in f:
            o = a.get_object()
            print(i, o.get("/T"), o.get("/FT"), o.get("/V"), o.get("/FT") and o.get("/FT") == "/Btn" and o.get("/V"))
    txt = p.extract_text()
    print("--- page", i, "text ---")
    print(txt)