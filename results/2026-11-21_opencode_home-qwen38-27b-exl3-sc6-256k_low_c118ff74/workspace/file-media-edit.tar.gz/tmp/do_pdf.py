from pypdf import PdfReader, PdfWriter
from pypdf.generic import NameObject, TextStringObject
import os

WS = r"<WORKSPACE>"
fields = {
    "organizer": "Tidewater Studio",
    "event_date": "2026-12-05",
    "location": "North Cove Lawn",
    "attendees": "40",
}

reader = PdfReader(os.path.join(WS, "permit-form.pdf"))
writer = PdfWriter(clone_from=reader)
writer.update_page_form_field_values(writer.pages[0], fields)
# remove AcroForm so fields can't be edited; drop annots (values already drawn? no - need appearance)
# pypdf update_page_form_field_values sets /V but appearance streams may be missing;
# flatten by keeping annots with /AP? Safer: keep AcroForm but the brief says flattened so answers can't be edited.
# Remove AcroForm and annots only if appearances exist; they don't, so instead keep annots but remove AcroForm
# -> viewers show /V text? Not without AP.
# Best: use pypdf's flatten? Not available. Use update_page_form_field_values(auto_regenerate=False)
# then remove AcroForm but keep annots with generated AP.
writer2 = PdfWriter(clone_from=reader)
writer2.update_page_form_field_values(writer2.pages[0], fields, auto_regenerate=False)
# auto_regenerate=False means it will generate appearance streams
if "/AcroForm" in writer2._root_object:
    del writer2._root_object[NameObject("/AcroForm")]
for page in writer2.pages:
    if "/Annots" in page:
        del page[NameObject("/Annots")]
with open(os.path.join(WS, "out", "permit-filled.pdf"), "wb") as f:
    writer2.write(f)
print("saved")
# verify
r = PdfReader(os.path.join(WS, "out", "permit-filled.pdf"))
print("text:", r.pages[0].extract_text())
print("acroform:", "/AcroForm" in r.trailer["/Root"])