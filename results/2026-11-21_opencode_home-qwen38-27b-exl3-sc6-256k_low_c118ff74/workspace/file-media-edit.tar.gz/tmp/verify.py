from PIL import Image
from pypdf import PdfReader
import os
WS = r"<WORKSPACE>"
img = Image.open(os.path.join(WS, "out", "feed-photo.jpg"))
print("feed-photo size:", img.size, img.format)
# check balloon still magenta in output
import numpy as np
a = np.asarray(img.convert("RGB")).astype(int)
r,g,b = a[...,0],a[...,1],a[...,2]
mask = (r>150)&(g<120)&(b>150)&((r-g)>60)&((b-g)>60)
ys,xs = np.where(mask)
print("magenta px in output:", len(xs))
if len(xs): print("bbox:", xs.min(),ys.min(),xs.max(),ys.max())

r = PdfReader(os.path.join(WS, "out", "permit-filled.pdf"))
p = r.pages[0]
print("annot count:", len(p.get("/Annots") or []))
# check for appearance streams / text in content
import zlib
content = p.get_contents()
if content:
    data = content.get_data().decode("latin-1")
    for kw in ["Tidewater","2026-12-05","North Cove","40"]:
        print(kw, "in content:", kw in data)
print("fields left:", r.get_fields())