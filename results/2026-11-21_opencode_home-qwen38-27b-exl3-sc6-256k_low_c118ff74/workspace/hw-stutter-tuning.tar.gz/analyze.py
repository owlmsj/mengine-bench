import csv, statistics, json

# presentmon
rows = []
with open('capture/presentmon.csv') as f:
    for r in csv.DictReader(f):
        rows.append(r)

msb = [float(r['MsBetweenPresents']) for r in rows]
n = len(rows)
total_s = n / 60.0  # 1 minute capture
avg_fps = n / 60.0
msb_sorted = sorted(msb)
p99 = msb_sorted[int(0.99 * (n - 1))]
low1 = 1000.0 / p99

print(f"frames={n} avg_fps={avg_fps:.2f} p99_ms={p99:.3f} low1pct={low1:.2f}")

# big hitches: frame times > 3x median
med = statistics.median(msb)
hitches = [(i, t) for i, t in enumerate(msb) if t > 3 * med]
print(f"median_ms={med:.2f} hitches(>3x med)={len(hitches)}")
for i, t in hitches:
    ts = float(rows[i]['TimeInSeconds'])
    print(f"  frame {i} t={ts:.3f}s msb={t:.2f}")

# sensor log
sens = []
with open('capture/sensors.csv') as f:
    for r in csv.DictReader(f):
        sens.append(r)
print("sensors rows:", len(sens))

# find seconds where gpu went to L1
l1 = [int(r['time_s']) for r in sens if r['gpu_pcie_link_state'] == 'L1']
print("L1 seconds:", l1)

# dpc latency spikes
dpc = [(int(r['time_s']), int(r['dpc_latency_us'])) for r in sens if int(r['dpc_latency_us']) > 200]
print("dpc>200us:", dpc)

# cpu clock drops
clk = [(int(r['time_s']), int(r['cpu_clock_mhz'])) for r in sens if int(r['cpu_clock_mhz']) < 4500]
print("cpu<4500mhz:", clk)

# disk activity
disk = [(int(r['time_s']), int(r['disk_active_pct'])) for r in sens if int(r['disk_active_pct']) > 20]
print("disk>20%:", disk)

# top cpu process changes
procs = [(int(r['time_s']), r['top_cpu_process']) for r in sens if r['top_cpu_process'] != 'Arena.exe']
print("top proc != Arena:", procs)

# gpu clock
gclk = [(int(r['time_s']), int(r['gpu_clock_mhz'])) for r in sens if int(r['gpu_clock_mhz']) < 2500]
print("gpu<2500mhz:", gclk)

# correlation: hitch seconds vs L1 seconds
hitch_secs = sorted(set(int(float(rows[i]['TimeInSeconds'])) for i, t in hitches))
print("hitch seconds:", hitch_secs)
print("L1 secs:", sorted(l1))