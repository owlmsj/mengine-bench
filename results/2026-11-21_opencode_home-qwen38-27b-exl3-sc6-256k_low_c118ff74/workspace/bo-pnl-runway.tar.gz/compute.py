import csv, json
from collections import defaultdict

def parse_amt(s):
    # -56.661,03 -> -56661.03 ; 9.312,12 -> 9312.12
    s = s.strip()
    neg = s.startswith('-')
    s = s.lstrip('-').replace('.', '').replace(',', '.')
    v = float(s)
    return -v if neg else v

pnl = {}
with open('finance/chart_of_accounts.csv', encoding='utf-8') as f:
    r = csv.reader(f, delimiter=';')
    next(r)
    for row in r:
        pnl[row[0]] = row[2]

months = ['2026-01','2026-02','2026-03','2026-04','2026-05','2026-06']
agg = {m: defaultdict(float) for m in months}
with open('finance/ledger.csv', encoding='utf-8') as f:
    r = csv.reader(f, delimiter=';')
    next(r)
    for row in r:
        d, acc, desc, amt = row
        day, mon, yr = d.split('/')
        m = f"{yr}-{mon}"
        assert m in agg, m
        agg[m][pnl[acc]] += parse_amt(amt)

out = {'revenue': {}, 'gross_margin_pct': {}, 'ebitda': {}}
for m in months:
    a = agg[m]
    rev = a['revenue']
    cogs = -a['cogs']
    gp = rev - cogs
    ebitda = rev + a['cogs'] + a['sales_marketing'] + a['rnd'] + a['ga']  # financial excluded
    out['revenue'][m] = round(rev, 2)
    out['gross_margin_pct'][m] = round(gp / rev * 100, 2)
    out['ebitda'][m] = round(ebitda, 2)

# burn: average monthly negative EBITDA of last three closed months (Apr, May, Jun)
last3 = [out['ebitda'][m] for m in ['2026-04','2026-05','2026-06']]
burn = -sum(last3) / 3
cash = 1847350.40
out['burn'] = round(burn, 2)
out['runway_months'] = round(cash / burn, 2)

with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(out, f, indent=2, ensure_ascii=False)
print(json.dumps(out, indent=2))