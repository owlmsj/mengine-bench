//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        // Hold the slot lock across the read-modify-write so concurrent
        // awards cannot overwrite each other's updates.
        let mut score = slot.lock().unwrap();
        *score += points;
        // The total is locked while the slot lock is held; no other
        // operation holds the total lock while taking a slot lock, so the
        // lock order (slot, then total) cannot cycle.
        let mut total = self.total.lock().unwrap();
        *total += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        if from == to {
            return;
        }
        let from_slot = self.slot(from);
        let to_slot = self.slot(to);
        // Lock the two slots in a fixed order (by player id) so that
        // concurrent transfers in opposite directions cannot deadlock.
        let (first, second) = if from < to {
            (&from_slot, &to_slot)
        } else {
            (&to_slot, &from_slot)
        };
        let mut first = first.lock().unwrap();
        let mut second = second.lock().unwrap();
        if from < to {
            *first -= points;
            *second += points;
        } else {
            *first += points;
            *second -= points;
        }
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}
