import csv, json
from decimal import Decimal, ROUND_HALF_UP

def money(s):
    s = s.strip()
    neg = s.startswith('-')
    s = s.lstrip('-').replace('.', '').replace(',', '.')
    d = Decimal(s)
    return -d if neg else d

pnl = {}
with open('finance/chart_of_accounts.csv', newline='') as f:
    for row in csv.DictReader(f, delimiter=';'):
        pnl[row['account']] = row['pnl_line']

months = ['2026-01','2026-02','2026-03','2026-04','2026-05','2026-06']
EXPENSES = {'cogs','sales_marketing','rnd','ga'}
cats = {m: {c: Decimal('0') for c in ['revenue','cogs','sales_marketing','rnd','ga','financial']} for m in months}

n = 0
with open('finance/ledger.csv', newline='') as f:
    for row in csv.DictReader(f, delimiter=';'):
        day, mon, year = row['date'].split('/')
        m = f'{year}-{mon}'
        c = pnl[row['account']]
        amt = money(row['amount'])
        cats[m][c] += abs(amt) if c in EXPENSES else amt
        n += 1
print(f"rows processed: {n}")

def q2(x):
    return float(x.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP))

def gross(m):
    return (cats[m]['revenue'] - cats[m]['cogs']) / cats[m]['revenue'] * 100

def ebitda(m):
    return (cats[m]['revenue'] - cats[m]['cogs'] - cats[m]['sales_marketing']
            - cats[m]['rnd'] - cats[m]['ga'])

out = {
    "revenue": {},
    "gross_margin_pct": {},
    "ebitda": {},
}
for m in months:
    out["revenue"][m] = q2(cats[m]['revenue'])
    out["gross_margin_pct"][m] = q2(gross(m))
    out["ebitda"][m] = q2(ebitda(m))

last3 = ['2026-04','2026-05','2026-06']
avg = sum(ebitda(m) for m in last3) / 3
burn = -avg  # positive magnitude
cash = Decimal('1847350.40')
runway = cash / burn

out["burn"] = q2(burn)
out["runway_months"] = q2(runway)

with open('result.json', 'w') as f:
    json.dump(out, f, indent=2)

print(json.dumps(out, indent=2))
print(f"\nexact burn={burn}  exact runway={runway}")
print("last3 ebitda:", {m: str(ebitda(m)) for m in last3})
