# H1 2026 Close — CFO Brief
Prepared for the investor meeting. All figures in R$, from the consolidated ledger
(`finance/ledger.csv`) mapped to the chart of accounts (`finance/chart_of_accounts.csv`).

## Headline
- **H1 revenue: R$ 1,389,492.82** — up **35.9%** month-over-month from Jan (R$ 200,510.87) to Jun (R$ 272,391.57).
- **Gross margin: steady at ~70%** (H1 average 70.17%).
- **EBITDA: negative every month**, H1 total **R$ -1,218,969.18**.
- **Burn: R$ 197,288.23 / month** (board definition: average of the last three closed months' EBITDA).
- **Runway: ~9.4 months** from the 30/06/2026 closing balance of R$ 1,847,350.40.

## Monthly P&L (H1 2026)

| Month | Revenue | Gross margin | EBITDA |
|-------|---------:|-------------:|-------:|
| 2026-01 | 200,510.87 | 70.03% | -210,278.96 |
| 2026-02 | 216,328.06 | 70.29% | -212,300.08 |
| 2026-03 | 219,066.17 | 68.46% | -204,525.45 |
| 2026-04 | 238,163.26 | 70.24% | -196,950.65 |
| 2026-05 | 243,032.89 | 69.56% | -201,945.82 |
| 2026-06 | 272,391.57 | 72.41% | -192,968.22 |

## Burn & runway
- Last three closed months (Apr–Jun) EBITDA: -196,950.65 / -201,945.82 / -192,968.22.
- Burn = average = **R$ 197,288.23 / month**.
- Latest closing cash (30/06/2026) = R$ 1,847,350.40.
- Runway = 1,847,350.40 / 197,288.23 = **9.36 months** (~mid-Q2 2027 if burn holds).

## Assumptions
- **EBITDA excludes the non-operating "financial" line** (investment income + interest/IOF tax), per the standard EBITDA definition (before interest and taxes). Including it would give burn R$ 190,820.54 and runway 9.68 months.
- **Burn is reported as a positive magnitude**; runway = latest closing cash / burn.
- "Last three closed months" = Apr, May, Jun 2026 (H1 fully closed).
- Monetary values rounded to 2 dp; gross margin and runway to 2 dp.

## Key message to investors
Revenue is growing and gross margin is healthy (~70%), but the business is still cash-negative at ~R$ 200k/month. At current burn, cash runs out in roughly **9 months** — the near-term ask is to either grow the top line faster, cut burn, or raise capital before Q3 2026.
