import csv
from collections import defaultdict

p_variants = defaultdict(set)   # player_id -> set of variants
p_sessions = defaultdict(set)   # player_id -> set of session_ids
with open("telemetry/playtest_ab.csv", newline="", encoding="utf-8") as f:
    r = csv.DictReader(f)
    for row in r:
        p = row["player_id"].strip()
        v = row["variant"].strip().lower()
        s = row["session_id"].strip()
        p_variants[p].add(v)
        p_sessions[p].add(s)

total_players = len(p_variants)
players_in_both = sum(1 for p, vs in p_variants.items() if len(vs) > 1)
players_multi_session = sum(1 for p, ss in p_sessions.items() if len(ss) > 1)
print("total distinct players:", total_players)
print("players appearing in >1 variant:", players_in_both)
print("players with >1 session:", players_multi_session)

# how many sessions per player (on deduped set)
sess_per_player = [len(ss) for ss in p_sessions.values()]
print("max sessions per player:", max(sess_per_player))
print("players with 2 sessions:", sum(1 for x in sess_per_player if x == 2))
