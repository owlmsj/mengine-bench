import csv, json, math
from collections import defaultdict

PATH = "telemetry/playtest_ab.csv"

def norm_variant(v):
    return v.strip().lower()

# --- Load and dedupe by session_id (unique key per README) ---
seen = {}          # session_id -> (variant, completed)
conflicts = []     # session_ids whose repeated rows disagree
order = []
with open(PATH, newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for row in reader:
        sid = row["session_id"].strip()
        variant = norm_variant(row["variant"])
        try:
            completed = int(row["completed_tutorial"].strip())
        except ValueError:
            continue
        if sid not in seen:
            seen[sid] = (variant, completed)
            order.append(sid)
        else:
            prev = seen[sid]
            if prev != (variant, completed):
                conflicts.append((sid, prev, (variant, completed)))

# --- Aggregate per variant ---
n = defaultdict(int)
comp = defaultdict(int)
for sid in order:
    variant, completed = seen[sid]
    n[variant] += 1
    comp[variant] += completed

variants = sorted(n.keys())
print("variants:", variants)
print("total unique sessions:", len(order))
print("conflicting duplicate rows:", len(conflicts))
for c in conflicts[:20]:
    print("  conflict:", c)

for v in variants:
    print(f"variant {v}: n={n[v]} completed={comp[v]} rate={comp[v]/n[v]:.6f}")

a, b = "a", "b"
na, nb = n[a], n[b]
ca, cb = comp[a], comp[b]
pa, pb = ca/na, cb/nb

# --- Two-proportion z-test (pooled) ---
p_pool = (ca + cb) / (na + nb)
se = math.sqrt(p_pool * (1 - p_pool) * (1/na + 1/nb))
z = (pb - pa) / se

def norm_cdf(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))

p_two = 2 * (1 - norm_cdf(z))          # two-sided
p_one = 1 - norm_cdf(z)                # one-sided, H1: p_b > p_a

print(f"\nna={na} ca={ca} pa={pa:.6f}")
print(f"nb={nb} cb={cb} pb={pb:.6f}")
print(f"diff={pb-pa:.6f} se={se:.6f} z={z:.6f}")
print(f"p_two={p_two:.6f} p_one={p_one:.6f}")

# --- Fisher exact (manual, for cross-check) ---
# 2x2 table: [[ca, na-ca],[cb, nb-cb]]
def logfact(k):
    return math.lgamma(k + 1)

def fisher_one_sided(table):
    # table = [[a11,a10],[a01,a00]] ; p for B>=observed given margins (one-sided, B higher)
    a11, a10 = table[0]
    a01, a00 = table[1]
    r1 = a11 + a10
    r0 = a01 + a00
    c1 = a11 + a01
    c0 = a10 + a00
    total = r1 + r0
    p = 0.0
    # k = number of successes in row1 (B), range from max(0, r1-c0) to min(r1, c1)
    k_min = max(0, r1 - c0)
    k_max = min(r1, c1)
    for k in range(k_min, k_max + 1):
        # P(k) = C(r1,k)*C(r0, c1-k) / C(total, c1)
        p += math.exp(logfact(r1) - logfact(k) - logfact(r1 - k)
                      + logfact(r0) - logfact(c1 - k) - logfact(r0 - (c1 - k))
                      - (logfact(total) - logfact(c1) - logfact(total - c1)))
    # one-sided: P(k >= observed k) where observed k = a11 (B completions)
    k_obs = a11
    p_one_fisher = 0.0
    for k in range(k_obs, k_max + 1):
        p_one_fisher += math.exp(logfact(r1) - logfact(k) - logfact(r1 - k)
                                 + logfact(r0) - logfact(c1 - k) - logfact(r0 - (c1 - k))
                                 - (logfact(total) - logfact(c1) - logfact(total - c1)))
    return p_one_fisher

table = [[cb, nb - cb], [ca, na - ca]]
p_fisher_one = fisher_one_sided(table)
print(f"p_fisher_one={p_fisher_one:.6f}")

# --- Decision ---
# Release rule: B ships only if its gain over A is significant at 5% level.
# The directional rule maps to a one-sided test (H1: p_b > p_a); the
# two-sided test is the more conservative/standard choice. Both agree here.
sig_one = p_one < 0.05
sig_two = p_two < 0.05
ship_b = sig_two and (pb > pa)   # conservative gate: significant even two-sided

print(f"\nsig_one={sig_one} sig_two={sig_two} ship_b={ship_b}")
print(f"p_two (exact) = {p_two!r}")
print(f"p_one (exact) = {p_one!r}")

result = {
    "ship_b": ship_b,
    "sessions_a": na,
    "sessions_b": nb,
    "completion_rate_a": pa,
    "completion_rate_b": pb,
    "p_value": p_two,
}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
    f.write("\n")
print("wrote result.json")
print(json.dumps(result, indent=2))
