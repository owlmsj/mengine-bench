import csv
from collections import defaultdict

raw_variants = set()
rows = []
with open("telemetry/playtest_ab.csv", newline="", encoding="utf-8") as f:
    r = csv.DictReader(f)
    for row in r:
        raw_variants.add(row["variant"])
        rows.append((row["session_id"].strip(), row["variant"].strip().lower(), int(row["completed_tutorial"].strip())))
print("raw rows:", len(rows))
print("raw variant forms (with repr):", [repr(v) for v in sorted(raw_variants)])

sids = set(s for s, _, _ in rows)
print("distinct session ids:", len(sids))
cnt = defaultdict(int)
for s, _, _ in rows:
    cnt[s] += 1
dups = {s: c for s, c in cnt.items() if c > 1}
print("session ids appearing >1:", len(dups))

seen = {}
bad = 0
for s, v, c in rows:
    if s in seen and seen[s] != (v, c):
        bad += 1
    seen[s] = (v, c)
print("inconsistent dup rows:", bad)

n = defaultdict(int)
comp = defaultdict(int)
for s, (v, c) in seen.items():
    n[v] += 1
    comp[v] += c
for v in sorted(n):
    print(f"variant {v}: n={n[v]} completed={comp[v]} rate={comp[v]/n[v]:.6f}")
