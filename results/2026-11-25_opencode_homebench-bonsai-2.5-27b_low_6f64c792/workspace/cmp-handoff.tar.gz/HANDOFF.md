# HANDOFF — local-9b Q5 @ 128k

User: "The local model needs 128k. Measure local-9b Q5 at that context."

## Findings (session/transcript.md)
- Baseline (measure_decode.ps1, Ctx 131072, 1024 predict): 37.8 t/s, 7881 MiB.
- 7881 MiB = WDDM ceiling; 1494 MiB spilled — that number does not count.
- Fix: --no-mmproj-offload + -ub 512 → spill gone; 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k — discarded. Q4_K_M: 7305 MiB, 40.4 t/s (fallback).
- Recipe applied: scripts/start_server.ps1:165 (local9 block) + profiles/local/local-9b.json.

## What's left
1. Update the evals README: it still cites check_vision.ps1 (gone).
2. Review the scratchpad temp file names (noted for later).

## Assumptions
- Workspace only contains session/transcript.md; referenced repo files are not here, so the applied edits could not be verified. "Q5" = Q5_K_M.

## How I know
I read session/transcript.md in full (225 lines); these are the only measured values in it; the pending items are its two "Noted for later"/"Pending" lines. No repo files to cross-check.
