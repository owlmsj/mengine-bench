const d = JSON.parse(require('fs').readFileSync('tmp/parsed.json', 'utf8'));
const g = d.graph;
const inDeg = {};
for (const [a, bs] of Object.entries(g)) for (const b of bs) inDeg[b] = (inDeg[b] || 0) + 1;
// undirected distinct degree
const deg = {};
for (const w of Object.keys(g)) {
  const set = new Set(g[w]);
  for (const [b, list] of Object.entries(g)) if (list.includes(w)) set.add(b);
  deg[w] = set.size;
}
const rows = Object.entries(deg).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
console.log('top 15 by undirected degree:');
for (const [w, x] of rows.slice(0, 15)) console.log(`  ${w}: ${x} (out ${g[w].length}, in ${inDeg[w] || 0})`);
// multiplicity total
const tot = {};
for (const [a, bs] of Object.entries(g)) tot[a] = (tot[a] || 0) + bs.length;
for (const [a, bs] of Object.entries(g)) for (const b of bs) tot[b] = (tot[b] || 0) + 1;
console.log('\ntop 10 by total multiplicity (in+out):');
const tr = Object.entries(tot).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
for (const [w, x] of tr.slice(0, 10)) console.log(`  ${w}: ${x}`);
