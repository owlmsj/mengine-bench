const d = JSON.parse(require('fs').readFileSync('tmp/parsed.json', 'utf8'));
const words = Object.keys(d.graph);
// check for html entities or weird chars in words
const weird = words.filter(w => /&|<|>|"/.test(w));
console.log('weird chars:', JSON.stringify(weird));
// longest words
const longest = [...words].sort((a, b) => b.length - a.length).slice(0, 8);
console.log('longest:', JSON.stringify(longest));
// theme coverage
const themes = new Set(Object.values(d.themes));
console.log('themes:', JSON.stringify([...themes].sort()));
// every word has a theme?
const noTheme = words.filter(w => !d.themes[w]);
console.log('no theme:', JSON.stringify(noTheme));
// verify: every linked word is itself a word (no dangling)
let dangling = 0;
for (const [a, bs] of Object.entries(d.graph)) for (const b of bs) if (!d.graph[b]) dangling++;
console.log('dangling links:', dangling);
// check accent variants in filenames vs h1 (sanity)
const fs = require('fs');
const files = fs.readdirSync('site').filter(f => f.endsWith('.html'));
console.log('files:', files.length);
