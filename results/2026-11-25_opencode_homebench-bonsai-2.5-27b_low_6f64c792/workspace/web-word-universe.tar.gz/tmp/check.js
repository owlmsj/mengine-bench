const d = JSON.parse(require('fs').readFileSync('tmp/parsed.json', 'utf8'));
const g = d.graph;
console.log('palavra:', JSON.stringify(g.palavra));
console.log('tempo:', JSON.stringify(g.tempo));
const fs = require('fs');
const files = fs.readdirSync('site').filter(f => f.endsWith('.html'));
let selfRaw = 0, dupRaw = 0, totalRaw = 0;
for (const f of files) {
  const html = fs.readFileSync('site/' + f, 'utf8');
  if (!html.includes('class="tema"')) continue;
  const links = [...html.matchAll(/<section id="(sinonimos|analogas)">([\s\S]*?)<\/section>/g)]
    .flatMap(m => [...m[2].matchAll(/<a href="([^"]*)">/g)].map(x => x[1]));
  totalRaw += links.length;
  if (links.length !== new Set(links).size) dupRaw++;
  if (links.some(h => h === f)) selfRaw++;
}
console.log('raw links total:', totalRaw, '| pages with intra-page dups:', dupRaw, '| pages with self-link:', selfRaw);
let directed = 0;
for (const bs of Object.values(g)) directed += bs.length;
console.log('directed links (resolvable):', directed);
// magoa check
console.log('magoa.html exists:', fs.existsSync('site/magoa.html'));
