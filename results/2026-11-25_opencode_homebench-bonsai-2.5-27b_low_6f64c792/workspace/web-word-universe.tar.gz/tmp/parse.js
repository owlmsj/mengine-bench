// Parse the saved Dicionário Criativo site into a word graph.
import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';

const site = join(process.cwd(), 'site');
const files = readdirSync(site);

const pages = {}; // filename (no .html) -> {word, theme, sinonimos, analogas, raw}
const redirects = {}; // filename -> target filename
const meta = [];

function extractH1(html) {
  const m = html.match(/<h1>([^<]*)<\/h1>/);
  return m ? m[1].trim() : null;
}
function extractTheme(html) {
  const m = html.match(/<p class="tema">Tema:\s*(.*?)<\/p>/);
  return m ? m[1].trim() : null;
}
function sectionLinks(html, id) {
  const m = html.match(new RegExp(`<section id="${id}">([\\s\\S]*?)</section>`));
  if (!m) return [];
  const links = [...m[1].matchAll(/<a href="([^"]*)"[^>]*>[^<]*<\/a>/g)];
  return links.map(l => l[1]);
}
function redirectTarget(html) {
  const m = html.match(/<meta http-equiv="refresh" content="0;\s*url=([^"]+)"/);
  return m ? m[1].replace(/\.html$/, '') : null;
}

for (const f of files) {
  if (!f.endsWith('.html')) continue;
  const name = f.slice(0, -5);
  const html = readFileSync(join(site, f), 'utf-8');
  const word = extractH1(html);
  const theme = extractTheme(html);
  const target = redirectTarget(html);
  if (target) {
    redirects[name] = target;
    continue;
  }
  if (word && theme) {
    pages[name] = {
      word,
      theme,
      sinonimos: sectionLinks(html, 'sinonimos'),
      analogas: sectionLinks(html, 'analogas'),
    };
  } else {
    meta.push(name);
    console.log('UNCLASSIFIED:', name);
  }
}

// Resolve a link target to a canonical word.
function resolve(target) {
  if (!target) return null;
  let t = decodeURIComponent(target).replace(/\.html$/, '').trim();
  if (redirects[t]) t = redirects[t];
  if (pages[t]) return pages[t].word;
  return null;
}

const graph = {}; // word -> Set<word>
const broken = []; // (from, target)
for (const [name, p] of Object.entries(pages)) {
  const links = [...p.sinonimos, ...p.analogas];
  for (const href of links) {
    const w = resolve(href);
    if (!w) {
      broken.push({ from: p.word, href });
      continue;
    }
    if (!graph[p.word]) graph[p.word] = new Set();
    graph[p.word].add(w);
  }
}

// Drop self-links.
for (const w of Object.keys(graph)) graph[w].delete(w);

// Canonical: every word page is a node, even with zero links.
for (const p of Object.values(pages)) graph[p.word] = graph[p.word] ?? new Set();

// Distinct unordered pairs.
const pairs = new Set();
for (const [a, bs] of Object.entries(graph)) {
  for (const b of bs) pairs.add(a < b ? `${a}\u0000${b}` : `${b}\u0000${a}`);
}

// Degrees (undirected, distinct neighbors).
const degree = {};
for (const w of Object.keys(graph)) degree[w] = graph[w].size;
let most = null, mostDeg = -1;
for (const w of Object.keys(degree)) {
  if (degree[w] > mostDeg) { mostDeg = degree[w]; most = w; }
}

const out = {
  words: Object.keys(pages).length,
  wordPages: Object.keys(pages).length,
  redirects, meta,
  graph: Object.fromEntries(Object.entries(graph).map(([k, v]) => [k, [...v].sort()])),
  pairs: pairs.size,
  most_connected: most,
  most_degree: mostDeg,
  broken,
  themes: Object.fromEntries(Object.entries(pages).map(([_, p]) => [p.word, p.theme])),
  // per-edge relation types for the view: word -> target -> type
  edgeTypes: {},
};
for (const p of Object.values(pages)) {
  for (const href of p.sinonimos) {
    const w = resolve(href);
    if (w) out.edgeTypes[p.word] = out.edgeTypes[p.word] || {};
    if (w) out.edgeTypes[p.word][w] = 'sinonimo';
  }
  for (const href of p.analogas) {
    const w = resolve(href);
    if (w) out.edgeTypes[p.word] = out.edgeTypes[p.word] || {};
    if (w) out.edgeTypes[p.word][w] = 'analogica';
  }
}

import { writeFileSync } from 'node:fs';
writeFileSync(join(process.cwd(), 'tmp', 'parsed.json'), JSON.stringify(out, null, 2));
console.log('words:', out.words);
console.log('pairs:', out.pairs);
console.log('most_connected:', out.most_connected, 'degree', out.most_degree);
console.log('meta:', meta.join(', '));
console.log('redirects:', JSON.stringify(redirects));
console.log('broken:', JSON.stringify(broken));
// top 10 by degree
const top = Object.entries(degree).sort((a, b) => b[1] - a[1]).slice(0, 10);
console.log('top10:', JSON.stringify(top));
// how many words have 0 links
const zero = Object.entries(degree).filter(([, d]) => d === 0).map(([w]) => w);
console.log('zero-degree:', zero.length, zero.join(', '));
