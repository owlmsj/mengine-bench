import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const d = JSON.parse(readFileSync(join(process.cwd(), 'tmp', 'parsed.json'), 'utf8'));
const data = {
  words: d.graph,
  themes: d.themes,
  edgeTypes: d.edgeTypes,
};
const dataJson = JSON.stringify(data);

const templatePath = join(process.cwd(), 'tmp', 'index.template.html');
const htmlPath = join(process.cwd(), 'universe', 'index.html');
let html = readFileSync(templatePath, 'utf8');
if (!html.includes('__DATA__')) {
  console.error('placeholder not found in template');
  process.exit(1);
}
html = html.replace('__DATA__', dataJson);
writeFileSync(htmlPath, html);
console.log('injected', dataJson.length, 'bytes of data');
console.log('total html size:', html.length);
