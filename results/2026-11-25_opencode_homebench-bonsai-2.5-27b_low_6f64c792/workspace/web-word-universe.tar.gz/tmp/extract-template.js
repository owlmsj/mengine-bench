import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

// Extract template: replace the DATA line with the placeholder.
const htmlPath = join(process.cwd(), 'universe', 'index.html');
let html = readFileSync(htmlPath, 'utf8');
const lines = html.split('\n');
for (let i = 0; i < lines.length; i++) {
  if (lines[i].startsWith('const DATA = ')) {
    lines[i] = 'const DATA = __DATA__;';
    break;
  }
}
const template = lines.join('\n');
writeFileSync(join(process.cwd(), 'tmp', 'index.template.html'), template);
console.log('template written, has placeholder:', template.includes('__DATA__'));
