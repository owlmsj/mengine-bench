const fs = require('fs');
const files = fs.readdirSync('site').filter(f => f.endsWith('.html'));
const h1 = {};
const redir = {};
for (const f of files) {
  const h = fs.readFileSync('site/' + f, 'utf8');
  const m = h.match(/<h1>([^<]*)<\/h1>/);
  if (m) h1[f.slice(0, -5)] = m[1].trim();
  const r = h.match(/<meta http-equiv="refresh" content="0;\s*url=([^"]+)"/);
  if (r) redir[f.slice(0, -5)] = r[1].replace(/\.html$/, '');
}
const resolve = h => {
  if (!h) return null;
  let t = decodeURIComponent(h).replace(/\.html$/, '').trim();
  if (redir[t]) t = redir[t];
  return h1[t] || null;
};
const pairs = new Set();
let directed = 0;
for (const f of files) {
  const h = fs.readFileSync('site/' + f, 'utf8');
  if (!h.includes('class="tema"')) continue;
  const w = h1[f.slice(0, -5)];
  const links = [...h.matchAll(/<section id="(sinonimos|analogas)">([\s\S]*?)<\/section>/g)]
    .flatMap(m => [...m[2].matchAll(/<a href="([^"]*)">/g)].map(x => x[1]));
  for (const href of links) {
    const t = resolve(href);
    if (!t) continue;
    directed++;
    if (w === t) continue;
    pairs.add(w < t ? w + '|' + t : t + '|' + w);
  }
}
console.log('independent unordered pairs:', pairs.size);
console.log('independent directed links:', directed);
