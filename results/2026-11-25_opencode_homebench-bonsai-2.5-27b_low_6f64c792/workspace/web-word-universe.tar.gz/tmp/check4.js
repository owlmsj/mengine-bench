const fs = require('fs');
const files = fs.readdirSync('site').filter(f => f.endsWith('.html'));
// map filename -> h1 word
const h1 = {};
for (const f of files) {
  const html = fs.readFileSync('site/' + f, 'utf8');
  const m = html.match(/<h1>([^<]*)<\/h1>/);
  if (m) h1[f.slice(0, -5)] = m[1].trim();
}
const redirects = {};
for (const f of files) {
  const html = fs.readFileSync('site/' + f, 'utf8');
  const m = html.match(/<meta http-equiv="refresh" content="0;\s*url=([^"]+)"/);
  if (m) redirects[f.slice(0, -5)] = m[1].replace(/\.html$/, '');
}
function resolve(h) {
  if (!h) return null;
  let t = decodeURIComponent(h).replace(/\.html$/, '').trim();
  if (redirects[t]) t = redirects[t];
  return h1[t] || null;
}
const raw = {};
for (const f of files) {
  const html = fs.readFileSync('site/' + f, 'utf8');
  if (!html.includes('class="tema"')) continue;
  const links = [...html.matchAll(/<section id="(sinonimos|analogas)">([\s\S]*?)<\/section>/g)]
    .flatMap(m => [...m[2].matchAll(/<a href="([^"]*)">/g)].map(x => x[1]));
  const w = h1[f.slice(0, -5)];
  raw[w] = (raw[w] || 0) + links.length;
}
const r = Object.entries(raw).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
console.log('top 8 raw out-degree (no dedupe):');
for (const [w, x] of r.slice(0, 8)) console.log(`  ${w}: ${x}`);
