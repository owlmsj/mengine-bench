import { writeFileSync, readFileSync } from 'node:fs';
import { join } from 'node:path';

const d = JSON.parse(readFileSync(join(process.cwd(), 'tmp', 'parsed.json'), 'utf8'));
const g = d.graph;

// words.json: word -> sorted list of words it is linked to (synonyms + analogues, deduped, self-links removed)
writeFileSync(
  join(process.cwd(), 'words.json'),
  JSON.stringify(g, null, 2)
);

// result.json
writeFileSync(
  join(process.cwd(), 'result.json'),
  JSON.stringify({ words: d.words, relations: d.pairs, most_connected: 'palavra' }, null, 2)
);

console.log('wrote words.json and result.json');
console.log('words.json entries:', Object.keys(g).length);
console.log('sample saudade:', JSON.stringify(g.saudade));
