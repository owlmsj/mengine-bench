"""Helper for running a batch of async tasks with a concurrency cap.

Provides :func:`run_tasks`, which runs a list of zero-argument callables
(each returning an awaitable job) with at most ``max_concurrent`` jobs in
flight at once. It returns once every job has finished, and it makes sure
that a Ctrl+C (or an external cancellation) still lets each job's cleanup
code (``finally`` blocks) run before the exception is re-raised.

Standard library only; requires Python 3.11+.
"""

import asyncio


async def run_tasks(tasks, max_concurrent):
    """Run ``tasks`` with at most ``max_concurrent`` jobs in flight.

    Each element of ``tasks`` is a zero-argument callable that returns an
    awaitable job. Jobs are started as needed so that no more than
    ``max_concurrent`` are running at the same time.

    Returns a list of the jobs' results, in the same order as ``tasks``.

    If the run is interrupted (Ctrl+C, or the enclosing task being
    cancelled), the in-flight and not-yet-started jobs are cancelled and
    awaited so that their cleanup code runs, and the exception is then
    re-raised.
    """
    semaphore = asyncio.Semaphore(max_concurrent)

    async def run(task):
        async with semaphore:
            return await task()

    jobs = [asyncio.create_task(run(task)) for task in tasks]
    try:
        return await asyncio.gather(*jobs)
    except (KeyboardInterrupt, asyncio.CancelledError):
        # A Ctrl+C (or cancellation) arrived. Cancel every job that has not
        # finished yet so its cleanup (finally) code gets a chance to run,
        # then wait for them to finish before re-raising.
        for job in jobs:
            if not job.done():
                job.cancel()
        await asyncio.gather(*jobs, return_exceptions=True)
        raise
