"""Tests for run.py: normal path, concurrency cap, and cancellation cleanup."""
import asyncio
import os
import signal
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from run import run_tasks  # noqa: E402


def make_job(i, sleep=10.0):
    async def job():
        try:
            await asyncio.sleep(sleep)
        finally:
            print(f"job{i} cleanup", flush=True)
            await asyncio.sleep(0.05)  # cleanup itself does an await
        return i
    return job


async def test_normal():
    async def job(i):
        await asyncio.sleep(0.01)
        return i * 10

    tasks = [lambda: job(i) for i in range(5)]
    result = await run_tasks(tasks, max_concurrent=2)
    assert result == [0, 10, 20, 30, 40], result
    print("test_normal OK", result, flush=True)


async def test_concurrency_cap():
    running = 0
    max_running = 0

    async def job(i):
        nonlocal running, max_running
        running += 1
        max_running = max(max_running, running)
        await asyncio.sleep(0.05)
        running -= 1
        return i

    tasks = [lambda: job(i) for i in range(10)]
    result = await run_tasks(tasks, max_concurrent=3)
    assert max_running <= 3, max_running
    assert result == list(range(10)), result
    print("test_concurrency_cap OK max_running =", max_running, flush=True)


async def test_cancelled_error_path():
    """Simulate asyncio.run cancelling the main task (what Ctrl+C triggers)."""
    async def main():
        tasks = [make_job(i) for i in range(5)]
        result = await run_tasks(tasks, max_concurrent=2)
        print("RESULT", result, flush=True)

    main_task = asyncio.create_task(main())
    await asyncio.sleep(0.5)
    main_task.cancel()
    try:
        await main_task
        print("ERROR: main task did not cancel", flush=True)
    except asyncio.CancelledError:
        print("test_cancelled_error_path OK (main cancelled, see cleanups above)", flush=True)


def test_sigint_path():
    """Real Ctrl+C: send SIGINT to ourselves while the run is in flight."""
    async def main():
        tasks = [make_job(i) for i in range(5)]
        result = await run_tasks(tasks, max_concurrent=2)
        print("RESULT", result, flush=True)

    def send_sigint():
        time.sleep(0.5)
        os.kill(os.getpid(), signal.SIGINT)

    t = threading.Thread(target=send_sigint, daemon=True)
    t.start()
    try:
        asyncio.run(main())
        print("ERROR: did not get KeyboardInterrupt", flush=True)
    except KeyboardInterrupt:
        print("test_sigint_path OK (got KeyboardInterrupt, see cleanups above)", flush=True)


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "all"
    if which in ("normal", "all"):
        asyncio.run(test_normal())
    if which in ("cap", "all"):
        asyncio.run(test_concurrency_cap())
    if which in ("cancel", "all"):
        asyncio.run(test_cancelled_error_path())
    if which in ("sigint", "all"):
        test_sigint_path()
    print("ALL DONE", flush=True)
