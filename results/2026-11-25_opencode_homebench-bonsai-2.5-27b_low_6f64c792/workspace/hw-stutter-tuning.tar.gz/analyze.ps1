$rows = Import-Csv 'capture/presentmon.csv'
$mbp = $rows | ForEach-Object { [double]$_.'MsBetweenPresents' }
$mean = ($mbp | Measure-Object -Average).Average
$avg_fps = 1000/$mean

$sorted = $mbp | Sort-Object
$n = $sorted.Count
$idx = 0.99 * ($n - 1)
$f = [math]::Floor($idx)
$c = [math]::Ceiling($idx)
if ($f -eq $c) { $p99 = $sorted[$f] } else { $p99 = $sorted[$f] * ($c - $idx) + $sorted[$c] * ($idx - $f) }
$low1 = 1000/$p99

Write-Host ("frames={0} last_t={1} mean_ms={2:0.5} avg_fps={3:0.4} p99_ms={4:0.4} low1_fps={5:0.4}" -f $n, $rows[-1].TimeInSeconds, $mean, $avg_fps, $p99, $low1)

# nearest-rank p99 for comparison
$rank = [math]::Ceiling(0.99 * $n)
$p99_nr = $sorted[$rank - 1]
Write-Host ("nearest_rank p99_ms={0:0.4} low1_fps={1:0.4}" -f $p99_nr, (1000/$p99_nr))

# hitch detection: ms > 1.5x mean
$thr = 1.5 * $mean
$hits = @()
for ($i = 0; $i -lt $rows.Count; $i++) {
  if ($mbp[$i] -gt $thr) { $hits += [pscustomobject]@{ t = [double]$rows[$i].TimeInSeconds } }
}
# cluster hits into bursts (gap > 0.2s = new burst)
$bursts = @()
$cur = $null
foreach ($h in $hits) {
  if ($null -eq $cur) { $cur = [pscustomobject]@{ start = $h.t; end = $h.t; count = 1 } }
  elseif ($h.t - $cur.end -lt 0.2) { $cur.end = $h.t; $cur.count++ }
  else { $bursts += $cur; $cur = [pscustomobject]@{ start = $h.t; end = $h.t; count = 1 } }
}
if ($cur) { $bursts += $cur }
Write-Host "bursts (start, end, frames):"
foreach ($b in $bursts) { Write-Host ("{0:0.000} - {1:0.000} ({2} frames)" -f $b.start, $b.end, $b.count) }
