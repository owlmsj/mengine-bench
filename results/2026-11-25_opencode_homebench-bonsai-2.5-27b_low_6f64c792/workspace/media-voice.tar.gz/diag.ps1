Add-Type -AssemblyName System.Speech
$asm = [System.Reflection.Assembly]::LoadWithPartialName("System.Speech")
Write-Host "Assembly: $($asm.FullName)"
Write-Host "Location: $($asm.Location)"
Write-Host "Version: $($asm.Version)"
Write-Host "--- Types containing 'OutputFormat' ---"
$asm.GetTypes() | Where-Object { $_.Name -like "*OutputFormat*" } | ForEach-Object { Write-Host $_.FullName }
Write-Host "--- Types containing 'Synthesizer' ---"
$asm.GetTypes() | Where-Object { $_.Name -like "*Synthesizer*" } | ForEach-Object { Write-Host $_.FullName }
Write-Host "--- All top-level type names (first 40) ---"
$asm.GetTypes() | ForEach-Object { $_.Name } | Select-Object -First 40
