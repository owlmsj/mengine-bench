foreach ($c in 'python','python3','dotnet','espeak','espeak-ng','powershell.exe','ffmpeg','sox','nls') {
    $p = Get-Command $c -ErrorAction SilentlyContinue
    if ($p) { Write-Host "$c : $($p.Source)" } else { Write-Host "$c : MISSING" }
}
