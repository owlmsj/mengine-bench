Add-Type -AssemblyName System.Speech
$ts = [System.Speech.Synthesis.SpeechSynthesizer]
Write-Host "=== Properties ==="
$ts.GetProperties() | ForEach-Object { Write-Host $_.Name }
Write-Host "=== Methods ==="
$ts.GetMethods() | Where-Object { $_.DeclaringType -eq $ts } | ForEach-Object { Write-Host $_.ToString() }
