Add-Type -AssemblyName System.Speech
$ts = New-Object System.Speech.Synthesis.SpeechSynthesizer
Write-Host "=== Installed voices ==="
foreach ($v in $ts.GetInstalledVoices()) {
    Write-Host "$($v.Name) | $($v.Language) | Gender=$($v.Gender)"
}
Write-Host "=== Default voice ==="
Write-Host "$($ts.Voice.Name) | $($ts.Voice.Language)"

$ts.SetOutputToWaveFile("announcement.wav")
$ts.Rate = 0
$ts.Speak("Welcome aboard the evening ferry, please keep your bags clear of the doors.")
$ts.Dispose()
Write-Host "=== Generated. File size: ==="
if (Test-Path "announcement.wav") { Write-Host "$(Get-Item announcement.wav).Length bytes" } else { Write-Host "NOT FOUND" }
