import json, datetime

# IPCA annual % (Ipeadata/IBGE)
ipca = {1985:242.23, 1986:79.66, 1987:363.41, 1988:980.21, 1989:1972.91,
        1990:1620.97, 1991:472.70, 1992:1119.10, 1993:2477.15, 1994:916.46, 1995:22.41}

plans = [
    ("Cruzado",  "1986-02-28", "Bresser"),
    ("Bresser",  "1987-06-12", "Verao"),
    ("Verao",    "1989-01-15", "Collor I"),
    ("Collor I", "1990-03-16", "Collor II"),
    ("Collor II","1991-01-31", "Real"),
    ("Real",     "1994-07-01", None),
]
launch = {name: datetime.date.fromisoformat(d) for name, d, _ in plans}

def months_between(a, b):
    return (b.year - a.year) * 12 + (b.month - a.month)

out = []
for name, d, nxt in plans:
    y = int(d[:4])
    before = ipca[y-1]; after = ipca[y+1]
    drop = max(0.0, min(1.0, 1 - after/before))
    if nxt is None:
        ml = 60
    else:
        ml = months_between(launch[name], launch[nxt])
    dur = min(ml, 60)/60
    score = 0.7*drop + 0.3*dur
    out.append(dict(plan=name, launch_date=d, ipca_before=before, ipca_after=after,
                    months_lasted=ml, score=round(score,4),
                    score_drop=round(drop,4), score_durability=round(dur,4)))

ranked = sorted(out, key=lambda r: -r["score"])
top3 = [r["plan"] for r in ranked[:3]]
print(json.dumps(out, indent=1))
print("TOP3:", top3)