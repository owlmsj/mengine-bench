import re, pathlib

IP = r'(?<![\dA-Za-z])(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])(?:\.(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3}(?![\dA-Za-z])'
DATE = r'(?<![\dA-Za-z-])(?:(?:19|20)\d{2}-(?:0[1-9]|1[0-2])-(?:0[1-9]|1\d|2[0-8]|29|30|31))(?![\dA-Za-z-])'

# Line must NOT contain an IP anywhere; then capture the LAST date on the line.
# ^ anchors line start; (?!.*IP) asserts no IP later in the line; .* greedy finds last date.
pat = r'^(?!.*' + IP + r').*' + DATE

patc = re.compile(pat, re.MULTILINE)

log = pathlib.Path("server.log").read_text()
print("sample log findall:", patc.findall(log))

cases = [
    ("2026-04-02 INFO 10.12.0.7 for build 2026-04-01", ["2026-04-01"]),
    ("2026-04-02 cache warm, next sweep 2026-04-03", []),
    ("WARN peer 192.168.40.3 slow, retry 2026-04-02 to 2026-04-05", ["2026-04-05"]),
    ("job 7781-20-4410 queued", []),
    ("upstream 172.20.1.14 refused", []),
    ("bad ip 256.1.1.1 date 2026-01-01", []),
    ("bad ip 010.1.1.1 date 2026-01-01", []),
    ("good ip 0.0.0.0 date 2026-01-01", ["2026-01-01"]),
    ("good ip 255.255.255.255 date 2026-12-31", ["2026-12-31"]),
    ("ip 1.2.3.4 date 2026-02-29", ["2026-02-29"]),
    ("ip 1.2.3.4 date 2026-02-30", []),
    ("ip 1.2.3.4 date 2026-13-01", []),
    ("ip 1.2.3.4 date 2026-00-10", []),
    ("ip 1.2.3.4 date 2026-04-31", []),
    ("ip 1.2.3.4 date 2026-01-32", []),
    ("ip 1.2.3.4 date 2026-01-00", []),
    ("x2026-01-01 ip 1.2.3.4", []),
    ("ip 1.2.3.4 x2026-01-01", []),
    ("ip 1.2.3.4 2026-01-01x", []),
    ("ip 1.2.3.4 2026-01-011", []),
    ("ip 1.2.3.4 2026-01-01-2", []),
    ("ip 1.2.3.4 2026-01-01", ["2026-01-01"]),
    # 1.2.3.4.5: 1.2.3.4 followed by '.' is allowed (only letter/digit disqualify) -> has IP
    ("ip 1.2.3.4.5 date 2026-01-01", ["2026-01-01"]),
    # 1.2.3.45 is itself a valid IP (45 in 0-255) -> has IP
    ("ip 1.2.3.45 date 2026-01-01", ["2026-01-01"]),
    ("ip 1.2.3.4 date 92026-01-01", []),
    ("ip 1.2.3.4 date 2026-01-01 and 2026-02-01", ["2026-02-01"]),
    ("2026-01-01 ip 1.2.3.4", ["2026-01-01"]),
    ("ip 1.2.3.4 2026-01-01 2026-01-02", ["2026-01-02"]),
]
ok = True
for line, exp in cases:
    got = patc.findall(line)
    if got != exp:
        ok = False
        print("FAIL:", repr(line), "expected", exp, "got", got)
print("ALL OK" if ok else "FAILURES")