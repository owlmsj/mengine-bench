import re

# Test 1: simple date with boundaries
p1 = re.compile(r'(?<![\dA-Za-z-])((?:19|20)\d{2})-(0[1-9]|1[0-2])-(?:(?:0[1-9]|1\d|2[0-8])|(?:29|30|31))(?![\dA-Za-z-])', re.MULTILINE)
print("p1:", p1.findall("ip 1.2.3.4 2026-01-01"))

# Test 2: with negative lookahead at start
p2 = re.compile(r'(?! (?<![\dA-Za-z])(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])(?:\.(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])){3}(?![\dA-Za-z]).*) ^.*?(?<![\dA-Za-z-])((?:19|20)\d{2})-(0[1-9]|1[0-2])-(?:(?:0[1-9]|1\d|2[0-8])|(?:29|30|31))(?![\dA-Za-z-])', re.VERBOSE | re.MULTILINE)
print("p2:", p2.findall("ip 1.2.3.4 2026-01-01"))
print("p2 noip:", p2.findall("no ip 2026-01-01"))