"""Batch task runner: run zero-arg callables that return awaitables,
bounded by max_concurrent, with graceful Ctrl+C (KeyboardInterrupt)
handling so in-flight jobs finish their cleanup code."""

import asyncio


async def run_tasks(tasks, max_concurrent):
    """Run each task (a zero-arg callable returning an awaitable) with at
    most max_concurrent jobs in flight. Returns when every job is done.

    On Ctrl+C (KeyboardInterrupt) the runner stops starting new jobs and
    waits for in-flight jobs to finish, so their cleanup code runs.
    """
    sem = asyncio.Semaphore(max_concurrent)
    tasks = list(tasks)

    async def run_one(task):
        async with sem:
            await task()

    jobs = [asyncio.ensure_future(run_one(t)) for t in tasks]
    try:
        await asyncio.gather(*jobs)
    except (KeyboardInterrupt, asyncio.CancelledError):
        # Ctrl+C: stop starting new jobs, let in-flight jobs finish so
        # their cleanup code runs.
        for j in jobs:
            if not j.done():
                j.cancel()
        # Wait for the in-flight jobs to finish (their finally/cleanup
        # blocks run during cancellation).
        await asyncio.gather(*jobs, return_exceptions=True)
        raise