# Handoff: local-9b at 128k

## Done (measured)
- Baseline `scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`: 37.8 t/s, VRAM 7881 MiB = WDDM ceiling; Shared Usage showed 1494 MiB spilled to system RAM. That spill is the bug.
- Fix: `--no-mmproj-offload` + `-ub 512` removes the spill: 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k; discarded. Q4_K_M fits (7305 MiB, 40.4 t/s), fallback only.
- Applied in `scripts/start_server.ps1:165` (local9 block) and `profiles/local/local-9b.json`.

## Left
1. Review scratchpad temp file names (noted, never done).
2. Evals README still cites `check_vision.ps1` (file gone).

## Assumptions
- Applied recipe is final. "Short prompt" repro attempts were dead ends — ignore.

## What I found, how I know
The transcript records the measurements as executed commands with concrete numbers and names the exact files edited (steps 10, 15, 42, 45, 63). The two open items are the only pending statements. No other work in flight.