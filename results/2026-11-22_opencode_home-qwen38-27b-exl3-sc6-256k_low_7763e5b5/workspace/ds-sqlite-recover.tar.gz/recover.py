import struct, json

data = open('prices.db', 'rb').read()
n = len(data)

# Leaf page header at offset 4044: d0 0a 04 00 27 07 66 69 72 73 74 ...
# d0 = leaf table b-tree, 0a = 10 cells, cell content starts at 0x0400 (1024), frag=0
leaf = 4044
ptype = data[leaf]
ncell = struct.unpack('>H', data[leaf+1:leaf+3])[0]
cellstart = struct.unpack('>H', data[leaf+3:leaf+5])[0]
frag = struct.unpack('>H', data[leaf+5:leaf+7])[0]
print(f'ptype={ptype:#x} ncell={ncell} cellstart={cellstart} frag={frag}')

# Cell pointer array: 10 x 2 bytes at leaf+8 .. leaf+28
cellptrs = []
for i in range(ncell):
    off = leaf + 8 + i*2
    if off + 2 <= n:
        cellptrs.append(struct.unpack('>H', data[off:off+2])[0])
    else:
        break
print('cellptrs:', cellptrs)

def varint(buf, i):
    v = 0
    for j in range(9):
        if i + j >= len(buf):
            return v, i + j
        x = buf[i+j]
        if j == 8:
            v = (v << 8) | x
            return v, i + 9
        v = (v << 7) | (x & 0x7f)
        if not (x & 0x80):
            return v, i + j + 1
    return v, i + 9

rows = []
for cp in cellptrs:
    p = cp
    if p >= n:
        print(f'cell at {cp} out of bounds')
        continue
    plen, p2 = varint(data, p)
    rowid, p3 = varint(data, p2)
    rhdr, p4 = varint(data, p3)
    serials = []
    q = p4
    end_hdr = p3 + rhdr
    while q < end_hdr:
        st, q = varint(data, q)
        serials.append(st)
    vals = []
    for st in serials:
        if st == 0:
            vals.append(None)
        elif 1 <= st <= 6:
            ln = {1:1,2:2,3:4,4:8,5:6,6:8}[st]
            fmt = {1:'b',2:'h',3:'i',4:'q',5:'q',6:'q'}[st]
            vals.append(struct.unpack('>'+fmt, data[q:q+ln])[0] if q+ln<=n else None)
            q += ln
        elif st == 7:
            vals.append(struct.unpack('>d', data[q:q+8])[0] if q+8<=n else None)
            q += 8
        elif st >= 13 and st % 2 == 1:
            ln = (st-13)//2
            vals.append(data[q:q+ln].decode('utf-8','replace') if q+ln<=n else data[q:n].decode('utf-8','replace'))
            q += ln
        elif st >= 12:
            ln = (st-12)//2
            vals.append(data[q:q+ln] if q+ln<=n else data[q:n])
            q += ln
    rows.append((rowid, vals))
    print(f'rowid={rowid} vals={vals}')

result = []
for rowid, vals in rows:
    item = next((v for v in vals if isinstance(v, str)), None)
    price = next((v for v in vals if isinstance(v, (int, float)) and not isinstance(v, bool)), None)
    if item is not None and price is not None:
        result.append({"item": item, "price": price})

print(json.dumps(result, indent=2))
with open('recovered.json', 'w') as f:
    json.dump(result, f, indent=2)
print('wrote', len(result), 'rows')