from PIL import Image, ImageDraw, ImageFont

img = Image.new("RGB", (1200, 675), (30, 90, 160))
d = ImageDraw.Draw(img)
try:
    f = ImageFont.truetype("arial.ttf", 80)
except Exception:
    f = ImageFont.load_default()
d.text((600, 337), "Harbor Day 2026", font=f, fill="white", anchor="mm")
img.save(r"<WORKSPACE>\cover.png")
print("ok")