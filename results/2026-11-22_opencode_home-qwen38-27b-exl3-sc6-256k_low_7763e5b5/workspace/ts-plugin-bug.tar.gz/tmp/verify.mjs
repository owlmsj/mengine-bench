import { HookBus } from "../src/bus.ts";
import { registerAuditPlugin } from "../src/plugin.ts";
import assert from "node:assert/strict";

// 1. Sequential order: async handlers must finish before the next starts.
{
  const bus = new HookBus();
  const log = [];
  bus.on("e", async () => { await new Promise(r => setTimeout(r, 20)); log.push("A"); });
  bus.on("e", async () => { log.push("B"); });
  bus.on("e", async () => { await new Promise(r => setTimeout(r, 5)); log.push("C"); });
  await bus.emit("e", null);
  assert.deepEqual(log, ["A", "B", "C"]);
}

// 2. emit resolves only after every handler finished.
{
  const bus = new HookBus();
  let done = false;
  bus.on("e", async () => { await new Promise(r => setTimeout(r, 30)); done = true; });
  await bus.emit("e", null);
  assert.equal(done, true);
}

// 3. A rejecting handler rejects emit with the same error; later handlers do not run.
{
  const bus = new HookBus();
  const log = [];
  bus.on("e", () => { log.push("A"); });
  bus.on("e", () => { throw new Error("boom"); });
  bus.on("e", () => { log.push("C"); });
  await assert.rejects(bus.emit("e", null), (err) => err.message === "boom");
  assert.deepEqual(log, ["A"]);
}
{
  const bus = new HookBus();
  const log = [];
  bus.on("e", async () => { await Promise.reject(new Error("async-boom")); });
  bus.on("e", () => { log.push("C"); });
  await assert.rejects(bus.emit("e", null), (err) => err.message === "async-boom");
  assert.deepEqual(log, []);
}

// 4. Unsubscribe during an emit does not stop the others in that emit; counts from the next.
{
  const bus = new HookBus();
  const log = [];
  const off = bus.on("e", () => { log.push("A"); off(); });
  bus.on("e", () => { log.push("B"); });
  await bus.emit("e", null);
  assert.deepEqual(log, ["A", "B"]);
  log.length = 0;
  await bus.emit("e", null);
  assert.deepEqual(log, ["B"]);
}

// 5. Plugin: notice first, redacted output, audit log last; notice only once.
{
  const bus = new HookBus();
  const audit = [];
  registerAuditPlugin(bus, audit);
  const result = { tool: "shell", output: "password=secret123 done" };
  await bus.emit("tool.after", result);
  assert.deepEqual(audit, ["notice: tool output is audited", "shell: password=[redacted] done"]);
  assert.equal(result.output, "password=[redacted] done");
  await bus.emit("tool.after", { tool: "read", output: "password=x" });
  assert.deepEqual(audit, ["notice: tool output is audited", "shell: password=[redacted] done", "read: password=[redacted]"]);
}

console.log("all contract checks passed");