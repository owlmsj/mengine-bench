import csv, json

GB = 1e9
weights_gb = 70e9 / GB  # 70B params, 8-bit = 1 byte each
kv_per_token = 327_680
kv_gb = 4 * 32_768 * kv_per_token / GB
overhead_gb = 8.0
total_gb = weights_gb + kv_gb + overhead_gb

print(f"weights_gb={weights_gb} kv_cache_gb={kv_gb} total_gb={total_gb}")

rows = list(csv.DictReader(open("offers.csv")))
cands = []
for r in rows:
    if r["in_stock"] != "yes":
        print(f"skip {r['offer_id']}: out of stock")
        continue
    if r["region"] not in ("us-east", "us-central", "eu-west"):
        print(f"skip {r['offer_id']}: region {r['region']}")
        continue
    price = float(r["usd_per_hour"])
    if price > 4.0:
        print(f"skip {r['offer_id']}: ${price}/h over cap")
        continue
    usable = int(r["gpu_count"]) * float(r["vram_gb_per_gpu"])
    if usable < total_gb:
        print(f"skip {r['offer_id']}: {usable} GB < {total_gb} GB")
        continue
    cands.append((price, r["offer_id"], usable))

cands.sort()
print("candidates:", cands)
best_price, best_id, best_usable = cands[0]
result = {
    "weights_gb": weights_gb,
    "kv_cache_gb": kv_gb,
    "total_gb": total_gb,
    "offer_id": best_id,
    "usd_per_hour": best_price,
    "usd_per_month": round(best_price * 730, 2),
}
json.dump(result, open("result.json", "w"), indent=2)
print(json.dumps(result, indent=2))