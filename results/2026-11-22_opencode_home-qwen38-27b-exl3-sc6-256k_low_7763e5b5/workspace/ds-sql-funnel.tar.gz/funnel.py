import sqlite3, json

db = r'<WORKSPACE>\analytics.db'
c = sqlite3.connect(db)
c.row_factory = sqlite3.Row

STEPS = ["install", "tutorial_complete", "first_match", "purchase"]

# valid users: not test, known platform
users = {}
for r in c.execute("select user_id, platform, is_test from users"):
    if not r["is_test"]:
        users[r["user_id"]] = r["platform"]

# first occurrence of each event per user (min ts)
first = {}
for r in c.execute("select user_id, name, min(ts) as ts from events where name in ('install','tutorial_complete','first_match','purchase') group by user_id, name"):
    first.setdefault(r["user_id"], {})[r["name"]] = r["ts"]

funnel = {}  # platform -> {step: count}
for uid, plat in users.items():
    ev = first.get(uid, {})
    prev_ts = None
    reached = {}
    for s in STEPS:
        ts = ev.get(s)
        if ts is None:
            break
        if prev_ts is not None and ts < prev_ts:
            # step before previous step: not valid
            break
        reached[s] = True
        prev_ts = ts
    for s in STEPS:
        funnel.setdefault(plat, {x: 0 for x in STEPS})
        if reached.get(s):
            funnel[plat][s] += 1

# biggest drop per platform: step with lowest conversion vs previous step
biggest = {}
for plat, f in funnel.items():
    convs = []
    prev = None
    for s in STEPS:
        if prev is not None and f[prev] > 0:
            convs.append((s, f[s] / f[prev]))
        prev = s
    if convs:
        s, v = min(convs, key=lambda x: x[1])
        biggest[plat] = s

result = {
    "funnel": {p: funnel[p] for p in sorted(funnel)},
    "biggest_drop": {p: biggest[p] for p in sorted(biggest)},
}
with open(r'<WORKSPACE>\result.json', 'w', encoding='utf-8') as fh:
    json.dump(result, fh, indent=2, ensure_ascii=False)
print(json.dumps(result, indent=2))