import sqlite3

db = r'<WORKSPACE>\analytics.db'
c = sqlite3.connect(db)
c.row_factory = sqlite3.Row

# events from users not in users table (unknown players)
unknown = c.execute("""
select count(*) from events e
where not exists (select 1 from users u where u.user_id = e.user_id)
""").fetchone()[0]
print("events from unknown players:", unknown)

# test users with events
test_ev = c.execute("""
select count(*) from events e join users u on u.user_id=e.user_id where u.is_test=1
""").fetchone()[0]
print("events from test users:", test_ev)

# users with no install event at all
no_install = c.execute("""
select count(*) from users u
where u.is_test=0 and not exists (select 1 from events e where e.user_id=u.user_id and e.name='install')
""").fetchone()[0]
print("non-test users without install:", no_install)

# check ordering violations: a later step occurring before an earlier step for same user
viol = c.execute("""
select e2.user_id, e1.name as earlier, min(e1.ts) as earlier_ts, e2.name as later, min(e2.ts) as later_ts
from events e1 join events e2 on e1.user_id=e2.user_id
where e1.name='install' and e2.name in ('tutorial_complete','first_match','purchase')
  and e2.ts < e1.ts
group by e2.user_id, e2.name
limit 10
""").fetchall()
print("ordering violations (later step before install):", len(viol))
for v in viol:
    print(dict(v))

# distinct platforms
print("platforms:", [r[0] for r in c.execute("select distinct platform from users")])
# event names present
print("event names:", [r[0] for r in c.execute("select distinct name from events")])