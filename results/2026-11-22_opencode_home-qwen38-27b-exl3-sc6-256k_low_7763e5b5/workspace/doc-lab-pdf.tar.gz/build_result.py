import json

# First report (Alfa, 10/02/2026) - units of reference
# marker: (date, value, unit, ref_min, ref_max)
first = {
    "glicose em jejum": ("2026-02-10", 92, "mg/dL", 70, 99),
    "colesterol ldl": ("2026-02-10", 118, "mg/dL", None, 130),  # desirable < 130
    "creatinina": ("2026-02-10", 0.95, "mg/dL", 0.70, 1.30),
    "hemoglobina glicada (hba1c)": ("2026-02-10", 5.4, "%", 4.0, 5.6),
}

# Second report (Beta, 18/08/2026) - convert to first report's units
# glicose: mmol/L -> mg/dL  (x 18.015588)
# colesterol ldl: mmol/L -> mg/dL (x 38.6695)
# creatinina: umol/L -> mg/dL (x 0.011299)
# hba1c: mmol/mol -> %  (IFCC: % = (mmol/mol + 2.3593) / 10.929)
second_raw = {
    "glicose em jejum": 6.1,
    "colesterol ldl": 3.70,
    "creatinina": 76,
    "hemoglobina glicada (hba1c)": 37,
}

def to_first_unit(marker, v):
    if marker == "glicose em jejum":
        return round(v * 18.015588, 1)
    if marker == "colesterol ldl":
        return round(v * 38.6695, 1)
    if marker == "creatinina":
        return round(v * 0.011299, 2)
    if marker == "hemoglobina glicada (hba1c)":
        return round((v + 2.3593) / 10.929, 1)

history = {}
worse = []
for marker, (date1, val1, unit, rmin, rmax) in first.items():
    val2 = to_first_unit(marker, second_raw[marker])
    history[marker] = {"2026-02-10": val1, "2026-08-18": val2}
    # worse = got worse AND now outside first report's reference range
    outside = (rmin is not None and val2 < rmin) or (rmax is not None and val2 > rmax)
    got_worse = val2 > val1
    if got_worse and outside:
        worse.append(marker)

result = {"history": history, "worse": worse}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
print(json.dumps(result, indent=2, ensure_ascii=False))