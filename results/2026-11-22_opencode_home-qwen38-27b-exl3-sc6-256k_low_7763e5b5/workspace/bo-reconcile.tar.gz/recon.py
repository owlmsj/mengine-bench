import csv, re, json
from collections import defaultdict

base = r"<WORKSPACE>"

inv = {}
with open(base + r"\backoffice\invoices.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        inv[row["id"]] = float(row["amount"])

payments = defaultdict(list)  # invoice id -> list of (date, amount)
skipped = []
with open(base + r"\backoffice\bank_statement_june.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        m = re.search(r"(?:INV[-\s]?|invoice\s+|inv)(\d{4})", memo, re.I)
        if not m:
            skipped.append((row["date"], memo, row["amount"]))
            continue
        iid = "INV-" + m.group(1)
        if iid not in inv:
            skipped.append((row["date"], memo, row["amount"]))
            continue
        payments[iid].append((row["date"], float(row["amount"])))

unpaid, duplicated, mismatched = [], [], []
for iid in sorted(inv):
    pays = payments.get(iid, [])
    if not pays:
        unpaid.append(iid)
    elif len(pays) > 1:
        duplicated.append(iid)
    else:
        amt = pays[0][1]
        if abs(amt - inv[iid]) > 0.005:
            mismatched.append({"id": iid, "invoiced": inv[iid], "paid": amt})

print("skipped:", skipped)
print("unpaid:", unpaid)
print("duplicated:", duplicated)
print("mismatched:", mismatched)

result = {
    "unpaid": unpaid,
    "duplicated": duplicated,
    "mismatched": [
        {"id": m["id"], "invoiced": m["invoiced"], "paid": m["paid"]} for m in mismatched
    ],
}
with open(base + r"\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
print("wrote result.json")