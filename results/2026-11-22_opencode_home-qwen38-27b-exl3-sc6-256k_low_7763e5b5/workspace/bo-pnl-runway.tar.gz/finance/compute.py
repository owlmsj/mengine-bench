import csv, json, collections

coa = {}
with open('finance/chart_of_accounts.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        coa[row['account']] = row['pnl_line']

months = ['2026-01','2026-02','2026-03','2026-04','2026-05','2026-06']
agg = {m: collections.defaultdict(float) for m in months}

with open('finance/ledger.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f, delimiter=';'):
        d = row['date']
        day, m, y = d.split('/')
        month = f"{y}-{m}"
        amt = float(row['amount'].replace('.', '').replace(',', '.'))
        line = coa[row['account']]
        agg[month][line] += amt

out = {}
for m in months:
    rev = agg[m]['revenue']
    cogs = agg[m]['cogs']
    gp = rev + cogs  # cogs negative
    gm = gp / rev * 100 if rev else 0
    ebitda = sum(v for k, v in agg[m].items())  # all lines incl financial
    out[m] = {'revenue': round(rev,2), 'gross_margin_pct': round(gm,2), 'ebitda': round(ebitda,2)}

eb = [out[m]['ebitda'] for m in months]
burn = round(-sum(eb[-3:]) / 3, 2)  # avg monthly negative EBITDA of last 3 closed months
cash = 1847350.40
runway = round(cash / burn, 2)

result = {
    'revenue': {m: out[m]['revenue'] for m in months},
    'gross_margin_pct': {m: out[m]['gross_margin_pct'] for m in months},
    'ebitda': {m: out[m]['ebitda'] for m in months},
    'burn': burn,
    'runway_months': runway,
}
with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
print(json.dumps(result, indent=2))