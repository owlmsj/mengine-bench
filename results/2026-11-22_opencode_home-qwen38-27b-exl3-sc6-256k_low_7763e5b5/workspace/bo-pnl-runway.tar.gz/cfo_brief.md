# H1 2026 close — CFO briefing

Source: finance/ledger.csv (86 entries, dd/mm/yyyy), finance/chart_of_accounts.csv,
finance/cash_balance.txt, finance/README.md (board's burn/runway rule).

## Monthly P&L (R$)

| Month  | Revenue   | Gross margin | EBITDA     |
|--------|-----------|--------------|------------|
| 2026-01 | 200,510.87 | 70.03%      | -203,812.19 |
| 2026-02 | 216,328.06 | 70.29%      | -205,001.69 |
| 2026-03 | 219,066.17 | 68.46%      | -198,078.94 |
| 2026-04 | 238,163.26 | 70.24%      | -189,670.28 |
| 2026-05 | 243,032.89 | 69.56%      | -195,444.78 |
| 2026-06 | 272,391.57 | 72.41%      | -187,346.57 |

- Revenue grew every month: +36% from Jan (200.5k) to Jun (272.4k).
- Gross margin steady around 68–72%.
- EBITDA negative all six months but improving: loss narrowed from -203.8k (Jan)
  to -187.3k (Jun).

## Burn and runway (board's rule, finance/README.md)

- Burn = average monthly negative EBITDA of the last three closed months
  (Apr, May, Jun): (189,670.28 + 195,444.78 + 187,346.57) / 3 = 190,820.54 R$/month.
- Latest closing cash balance (30/06/2026): 1,847,350.40 R$.
- Runway = 1,847,350.40 / 190,820.54 = 9.68 months.

## Assumptions

1. EBITDA here = total P&L per month: revenue + cogs + sales_marketing + rnd + ga +
   financial (investment income and interest/IOF included). No D&A or non-EBITDA
   items exist in the chart of accounts, so total P&L equals EBITDA.
2. Refunds and cancellations (3.1.09) net against revenue, per the COA pnl_line.
3. "Last three closed months" = April, May, June 2026 (all closed per the
   30/06/2026 balance).
4. Cash = consolidated balance on 30/06/2026 from cash_balance.txt.