import csv, json, math
from collections import Counter

path = r"<WORKSPACE>\telemetry\playtest_ab.csv"

rows = []
with open(path, newline="", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        rows.append(r)

total_rows = len(rows)

# Normalize variant: strip whitespace, lowercase
def norm_variant(v):
    return v.strip().lower()

# Dedupe by session_id (keep first occurrence)
seen = {}
dup_count = 0
for r in rows:
    sid = r["session_id"].strip()
    if sid in seen:
        dup_count += 1
        # verify consistency
        prev = seen[sid]
        if prev["completed"] != int(r["completed_tutorial"]):
            print(f"CONFLICT: {sid} completed differs")
        if norm_variant(prev["variant"]) != norm_variant(r["variant"]):
            print(f"CONFLICT: {sid} variant differs: {prev['variant']!r} vs {r['variant']!r}")
    else:
        seen[sid] = {
            "variant": norm_variant(r["variant"]),
            "completed": int(r["completed_tutorial"]),
        }

sessions = list(seen.values())
n_sessions = len(sessions)

# Count variants
variant_counts = Counter(s["variant"] for s in sessions)
print(f"Total rows: {total_rows}")
print(f"Unique sessions: {n_sessions}")
print(f"Duplicate rows removed: {dup_count}")
print(f"Variant counts (normalized): {dict(variant_counts)}")

# Check for unexpected variant values
unexpected = [v for v in variant_counts if v not in ("a", "b")]
if unexpected:
    print(f"WARNING: unexpected variant values: {unexpected}")

a = [s for s in sessions if s["variant"] == "a"]
b = [s for s in sessions if s["variant"] == "b"]

n_a, n_b = len(a), len(b)
c_a = sum(s["completed"] for s in a)
c_b = sum(s["completed"] for s in b)
p_a = c_a / n_a
p_b = c_b / n_b

print(f"\nA: n={n_a}, completed={c_a}, rate={p_a:.6f}")
print(f"B: n={n_b}, completed={c_b}, rate={p_b:.6f}")

# Two-proportion z-test (two-sided, alpha=0.05)
p_pool = (c_a + c_b) / (n_a + n_b)
se = math.sqrt(p_pool * (1 - p_pool) * (1/n_a + 1/n_b))
z = (p_b - p_a) / se
# two-sided p-value
p_value = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))

print(f"\nPooled p: {p_pool:.6f}")
print(f"SE: {se:.6f}")
print(f"z: {z:.6f}")
print(f"p-value (two-sided): {p_value:.6f}")

significant = p_value < 0.05
b_wins = p_b > p_a
ship_b = significant and b_wins

print(f"\nB > A: {b_wins}")
print(f"Significant at 5%: {significant}")
print(f"Ship B: {ship_b}")

result = {
    "ship_b": ship_b,
    "sessions_a": n_a,
    "sessions_b": n_b,
    "completion_rate_a": round(p_a, 6),
    "completion_rate_b": round(p_b, 6),
    "p_value": round(p_value, 6),
}

out = r"<WORKSPACE>\result.json"
with open(out, "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(f"\nWrote {out}")
print(json.dumps(result, indent=2))