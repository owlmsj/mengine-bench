import csv, re, json
from collections import defaultdict

# Load invoices
invoices = {}
with open('backoffice/invoices.csv', newline='', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        invoices[row['id']] = float(row['amount'])

# Load bank statement, extract invoice id from memo
payments = defaultdict(list)  # invoice_id -> [amounts]
skipped = []
with open('backoffice/bank_statement_june.csv', newline='', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        memo = row['memo']
        amt = float(row['amount'])
        # find invoice id in memo: INV-1007, inv1007, invoice 1023
        m = re.search(r'(?:INV[-\s]?|invoice\s+)(\d{4})', memo, re.IGNORECASE)
        if m:
            inv_id = 'INV-' + m.group(1)
            payments[inv_id].append(amt)
        else:
            skipped.append((row['date'], memo, amt))

print("Skipped (no identifiable invoice):")
for s in skipped:
    print("  ", s)

# Classify
unpaid = []
duplicated = []
mismatched = []

for inv_id, amount in sorted(invoices.items()):
    pays = payments.get(inv_id, [])
    if len(pays) == 0:
        unpaid.append(inv_id)
    elif len(pays) > 1:
        duplicated.append(inv_id)
    else:
        if abs(pays[0] - amount) > 0.005:
            mismatched.append({"id": inv_id, "invoiced": amount, "paid": pays[0]})

# Also check for payments referencing invoice ids not in invoices
known = set(invoices.keys())
for inv_id in payments:
    if inv_id not in known:
        print("Payment references unknown invoice:", inv_id, payments[inv_id])

result = {
    "unpaid": unpaid,
    "duplicated": duplicated,
    "mismatched": mismatched,
}
with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2, ensure_ascii=False)

print("\n=== RESULT ===")
print(json.dumps(result, indent=2, ensure_ascii=False))