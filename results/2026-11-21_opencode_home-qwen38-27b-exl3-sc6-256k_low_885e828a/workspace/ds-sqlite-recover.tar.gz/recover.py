import json, struct

data = open('prices.db','rb').read()
assert len(data) == 4096

def varint(buf, i):
    result = 0
    for n in range(9):
        b = buf[i+n]
        if n == 8:
            result = (result << 8) | b
            return result, i+9
        result = (result << 7) | (b & 0x7F)
        if not (b & 0x80):
            return result, i+n+1
    return result, i+9

def read_value(buf, body, s):
    if s == 0:
        return None, body
    if s == 1:
        return struct.unpack('>b', buf[body:body+1])[0], body+1
    if s in (2,3,4,6,8):
        n = {2:2,3:3,4:4,6:6,8:8}[s]
        return int.from_bytes(buf[body:body+n],'big',signed=True), body+n
    if s == 5:
        return int.from_bytes(buf[body:body+6],'big',signed=True), body+6
    if s == 7:
        return struct.unpack('>d', buf[body:body+8])[0], body+8
    if s == 8:
        return 0, body
    if s == 9:
        return 1, body
    if s >= 12 and s % 2 == 0:
        n = (s-12)//2
        return buf[body:body+n].decode('utf-8','replace'), body+n
    if s >= 13 and s % 2 == 1:
        n = (s-13)//2
        return buf[body:body+n], body+n
    return None, body

# Cell pointer array at offsets 12..34 (12 pointers). Validate each:
# a valid pointer points into the cell content region (>= 0x0C, < 4096),
# and the payload there must be parseable.
ptrs = [struct.unpack('>H', data[12+2*k:14+2*k])[0] for k in range(12)]
print('pointers:', [hex(p) for p in ptrs])

rows = []
for off in ptrs:
    if off < 0x0C or off >= 4096:
        continue
    payload_len, i = varint(data, off)
    if payload_len <= 0 or payload_len > 4096:
        continue
    rowid, i = varint(data, i)
    hdr_start = i
    hdr_len, i = varint(data, i)
    if hdr_len <= 0 or hdr_start + hdr_len > 4096:
        continue
    hdr_end = hdr_start + hdr_len
    serials = []
    j = i
    ok = True
    while j < hdr_end:
        s, j = varint(data, j)
        serials.append(s)
    body = hdr_end
    values = []
    for s in serials:
        v, body = read_value(data, body, s)
        values.append(v)
    if body > 4096:
        continue
    # Layout: (NULL, item TEXT, price NUM); rowid is the table rowid
    if len(values) == 3 and isinstance(values[1], str) and isinstance(values[2], (int, float)) and not isinstance(values[2], bool):
        rows.append({'item': values[1], 'price': values[2]})
        print(f'rowid={rowid} item={values[1]!r} price={values[2]!r}')
    else:
        print(f'rowid={rowid} SKIP values={values!r}')

with open('recovered.json','w',encoding='utf-8') as f:
    json.dump(rows, f, ensure_ascii=False, indent=2)
print('wrote', len(rows), 'rows')