import asyncio
from run import run_tasks


async def test_bound_and_done():
    peak = 0
    cur = 0
    lock = asyncio.Lock()

    def task():
        async def job():
            nonlocal peak, cur
            async with lock:
                cur += 1
                peak = max(peak, cur)
            try:
                await asyncio.sleep(0.05)
            finally:
                async with lock:
                    cur -= 1
        return job()

    await run_tasks([task] * 10, 3)
    assert peak <= 3, f"peak {peak} exceeded max_concurrent=3"
    assert peak == 3, f"expected bound to be tight, peak {peak}"


async def test_cleanup_on_cancel():
    cleaned = []

    def task():
        async def job():
            try:
                await asyncio.sleep(10)
            finally:
                cleaned.append(1)
        return job()

    async def cancel_soon():
        await asyncio.sleep(0.1)
        for t in asyncio.all_tasks():
            if t is not asyncio.current_task():
                t.cancel()

    c = asyncio.create_task(cancel_soon())
    try:
        await run_tasks([task] * 3, 2)
    except asyncio.CancelledError:
        pass
    await c
    # With max_concurrent=2, at most 2 jobs are in flight when the cancel
    # lands; those must run their finally blocks. The 3rd never started.
    assert len(cleaned) == 2, f"cleanup ran {len(cleaned)} times, want 2"


async def test_propagates_exception():
    def ok():
        async def job():
            await asyncio.sleep(0.01)
        return job()

    def boom():
        async def job():
            raise ValueError("boom")
        return job()

    try:
        await run_tasks([ok, boom, ok], 2)
        assert False, "expected ValueError"
    except ValueError as e:
        assert str(e) == "boom"


async def main():
    await test_bound_and_done()
    await test_cleanup_on_cancel()
    await test_propagates_exception()
    print("all tests passed")


asyncio.run(main())