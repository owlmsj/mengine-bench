"""Batch task runner: run zero-arg callables that return awaitables,
with a bound on how many jobs run at once.

Ctrl+C (SIGINT) cancels the in-flight jobs; their cleanup code (finally
blocks / try-finally / async with) still runs before run_tasks returns.
"""

from __future__ import annotations

import asyncio


async def run_tasks(tasks, max_concurrent):
    """Run all tasks concurrently, at most max_concurrent at a time.

    tasks: iterable of zero-argument callables; each call returns an
           awaitable job (coroutine, Task, Future, ...).
    max_concurrent: positive int bound on simultaneously running jobs.

    Returns None once every job has finished. If a job raises, the
    exception propagates after the other jobs have been given a chance
    to finish (gather's default behaviour).
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent!r}")

    sem = asyncio.Semaphore(max_concurrent)

    async def _run(task):
        async with sem:
            return await task()

    await asyncio.gather(*(_run(t) for t in tasks))