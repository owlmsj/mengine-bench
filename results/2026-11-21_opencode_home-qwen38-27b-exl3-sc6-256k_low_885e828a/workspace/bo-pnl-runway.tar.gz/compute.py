import csv, json
from collections import defaultdict

def num(s):
    s = s.strip().replace(' ', '')
    neg = s.startswith('-')
    if neg: s = s[1:]
    s = s.replace('.', '').replace(',', '.')
    return -float(s) if neg else float(s)

coa = {}
with open('finance/chart_of_accounts.csv', encoding='utf-8') as f:
    r = csv.reader(f, delimiter=';')
    next(r)
    for row in r:
        coa[row[0].strip()] = row[2].strip()

months = ['2026-01','2026-02','2026-03','2026-04','2026-05','2026-06']
agg = {m: defaultdict(float) for m in months}
with open('finance/ledger.csv', encoding='utf-8') as f:
    r = csv.reader(f, delimiter=';')
    next(r)
    n = 0
    for row in r:
        d, acct, desc, amt = [c.strip() for c in row]
        dd, mm, yy = d.split('/')
        m = f"{yy}-{mm}"
        assert m in agg, m
        agg[m][coa[acct]] += num(amt)
        n += 1
print("entries:", n)

res = {}
for m in months:
    rev = agg[m]['revenue']
    cogs = agg[m]['cogs']
    gm = (rev + cogs) / rev * 100  # cogs stored negative
    ebitda = sum(agg[m][k] for k in ('revenue','cogs','sales_marketing','rnd','ga'))
    fin = agg[m]['financial']
    res[m] = dict(revenue=round(rev,2), gross_margin_pct=round(gm,2),
                  ebitda=round(ebitda,2), financial=round(fin,2),
                  net=round(ebitda+fin,2))
    print(m, res[m])

# burn: avg of negative EBITDA over last 3 closed months (Apr,May,Jun)
last3 = [res[m]['ebitda'] for m in months[3:]]
neg = [e for e in last3 if e < 0]
burn = -sum(neg)/len(neg)
cash = 1847350.40  # 30/06/2026 consolidated balance
runway = cash / burn
print("last3 ebitda:", last3)
print("burn:", round(burn,2), "runway:", round(runway,2))

out = {
  "revenue": {m: res[m]['revenue'] for m in months},
  "gross_margin_pct": {m: res[m]['gross_margin_pct'] for m in months},
  "ebitda": {m: res[m]['ebitda'] for m in months},
  "burn": round(burn,2),
  "runway_months": round(runway,2),
}
with open('result.json','w',encoding='utf-8') as f:
    json.dump(out, f, indent=2, ensure_ascii=False)
print(json.dumps(out, indent=2))