# H1 2026 close — CFO brief (prepared 2026-11-21)

## Headline
- Revenue grew every month: R$ 200.5k (Jan) → R$ 272.4k (Jun), +35.8% over the half.
- Gross margin steady at 68–72%; June best at 72.4%.
- EBITDA loss narrowed every month except May: −R$ 212.3k (Feb) → −R$ 193.0k (Jun).
- Cash at 30/06/2026: R$ 1,847,350.40. Board burn (avg negative EBITDA, Apr–Jun): R$ 197,288.23/mo.
- **Runway: 9.36 months at current burn (~mid-Mar 2027).**

## Monthly PnL (R$, from ledger.csv via chart_of_accounts.csv)
| Month | Revenue | COGS | Gross margin % | S&M | R&D | G&A | Financial | EBITDA | Net |
|---|---|---|---|---|---|---|---|---|---|
| 2026-01 | 200,510.87 | −60,153.09 | 70.03 | −143,475.23 | −173,396.37 | −43,826.35 | +6,466.77 | −210,278.96 | −203,812.19 |
| 2026-02 | 216,328.06 | −64,278.71 | 70.29 | −138,161.28 | −176,270.99 | −44,497.13 | +7,298.39 | −212,300.08 | −205,001.69 |
| 2026-03 | 219,066.17 | −69,026.07 | 68.46 | −135,519.34 | −171,742.87 | −47,233.36 | +6,446.51 | −204,525.45 | −198,078.94 |
| 2026-04 | 238,163.26 | −70,997.73 | 70.24 | −139,688.11 | −179,874.72 | −44,753.63 | +7,280.37 | −196,950.65 | −189,670.28 |
| 2026-05 | 243,032.89 | −73,971.59 | 69.56 | −138,680.10 | −190,595.88 | −46,420.18 | +6,501.04 | −201,945.82 | −195,444.78 |
| 2026-06 | 272,391.57 | −74,950.69 | 72.41 | −151,896.54 | −189,489.92 | −48,310.55 | +5,621.65 | −192,968.22 | −187,346.57 |

## Burn and runway (board definition, per README.md)
- Burn = average of the negative EBITDA of the last three closed months (Apr, May, Jun):
  (196,950.65 + 201,945.82 + 192,968.22) / 3 = **R$ 197,288.23/mo**
- Runway = latest closing cash (30/06/2026, R$ 1,847,350.40) ÷ burn = **9.36 months**
- Cash fell R$ 461,837.60 in June (2.31M → 1.85M); EBITDA loss of ~R$ 193k plus working capital/timing.

## Assumptions
1. EBITDA = revenue + COGS + S&M + R&D + G&A (no D&A in the ledger); financial income/expense (6.1.xx) excluded from EBITDA, shown separately.
2. Refunds (3.1.09, negative) net against revenue per the chart of accounts.
3. "Last three closed months" = Apr–Jun 2026 (the half just closed); all three EBITDA values are negative, so the average uses all three.
4. Cash balance taken from cash_balance.txt (consolidated, 30/06/2026).
5. Amounts in BRL; ledger dates dd/mm/yyyy.

## Method / verification
- 86 ledger entries parsed (semicolon CSV, pt-BR number format: dot thousands, comma decimal).
- Totals recomputed independently in PowerShell; match the Python figures exactly.
- Key figures recorded in result.json (revenue, gross_margin_pct, ebitda per month; burn; runway_months).