import csv, json, math, sys

path = r"<WORKSPACE>\telemetry\playtest_ab.csv"

sessions = {}
dupes = 0
bad_variant = 0
bad_completed = 0
with open(path, newline="", encoding="utf-8-sig") as f:
    r = csv.DictReader(f)
    for row in r:
        sid = row["session_id"].strip()
        v = row["variant"].strip().lower()
        c = row["completed_tutorial"].strip()
        if v not in ("a", "b"):
            bad_variant += 1
            continue
        if c not in ("0", "1"):
            bad_completed += 1
            continue
        if sid in sessions:
            dupes += 1
            # verify resend consistency
            prev = sessions[sid]
            if (prev[0], prev[1]) != (v, int(c)):
                print(f"INCONSISTENT DUPE {sid}: {prev} vs {(v,int(c))}", file=sys.stderr)
            continue
        sessions[sid] = (v, int(c))

a_n = a_c = b_n = b_c = 0
for v, c in sessions.values():
    if v == "a":
        a_n += 1
        a_c += c
    else:
        b_n += 1
        b_c += c

pa = a_c / a_n
pb = b_c / b_n
p = (a_c + b_c) / (a_n + b_n)
se = math.sqrt(p * (1 - p) * (1 / a_n + 1 / b_n))
z = (pb - pa) / se
# two-sided p-value
p_value = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))

out = {
    "ship_b": bool(pb > pa and p_value < 0.05),
    "sessions_a": a_n,
    "sessions_b": b_n,
    "completion_rate_a": round(pa, 6),
    "completion_rate_b": round(pb, 6),
    "p_value": round(p_value, 6),
}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2)

print(f"rows deduped: {len(sessions)} unique sessions, {dupes} duplicate rows dropped")
print(f"bad_variant={bad_variant} bad_completed={bad_completed}")
print(f"A: {a_c}/{a_n} = {pa:.4f}")
print(f"B: {b_c}/{b_n} = {pb:.4f}")
print(f"z={z:.4f} p={p_value:.6f}")
print(json.dumps(out, indent=2))