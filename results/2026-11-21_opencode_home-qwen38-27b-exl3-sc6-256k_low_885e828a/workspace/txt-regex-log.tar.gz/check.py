import re, calendar

# ---- build the regex (will be saved to regex.txt) ----
# IPv4: dotted decimal, each part 0-255, no leading zeros
OCT = r"(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])"
IP = OCT + r"(?:\." + OCT + r"){3}"
# Date: YYYY-MM-DD, real calendar dates, Feb up to 29 every year
Y = r"(?:\d{3}[2468]|\d{3}[02468][048]|\d{3}[13579][26]|\d{3}[013579][013579]|1900|2100|2200|2300|2400|2500|2600|2700|2800|2900|3000|3100|3200|3300|3400|3500|3600|3700|3800|3900|4000)"
# simpler: year = \d{4} then validate day via alternatives
LEAP = r"(?:\d{3}[2468]|\d{3}[02468][048]|\d{3}[13579][26]|(?:19|21|22|23|24|25|26|27|28|29|30|31|32|33|34|35|36|37|38|39|40)00)"
NONLEAP = r"(?:\d{4}(?!%s)|%s)" % (LEAP, "")  # placeholder
# month/day
M = r"(?:0[1-9]|1[0-2])"
D_LEAP = r"(?:0[1-9]|[12][0-9]|30)"
D_NONLEAP = r"(?:0[1-9]|[12][0-9]|30)"
# Feb: 01-28 always, 29 only leap years
# Build date pattern with leap-year awareness
DATE = (
    r"(?<!\d)(?<![\w-])"
    r"(?:"
    # non-leap year: Feb up to 28
    r"(?:\d{4})(?:(?<!\d)0[13578]|(?<!\d)1[02])-(?:0[1-9]|[12][0-9]|30)"
    r"|(?:\d{4})(?<!\d)04-(?:0[1-9]|[12][0-9])"
    r"|(?:\d{4})(?<!\d)06-(?:0[1-9]|[12][0-9]|30)"
    r"|(?:\d{4})(?<!\d)09-(?:0[1-9]|[12][0-9]|30)"
    r"|(?:\d{4})(?<!\d)11-(?:0[1-9]|[12][0-9]|30)"
    r"|(?:\d{4})(?<!\d)02-(?:0[1-9]|1[0-9]|2[0-8])"
    # leap year: Feb up to 29
    r"|(?:\d{3}[2468]|\d{3}[02468][048]|\d{3}[13579][26]|(?:19|21|22|23|24|25|26|27|28|29|30|31|32|33|34|35|36|37|38|39|40)00)(?<!\d)02-(?:0[1-9]|1[0-9]|29)"
    r")"
    r"(?!\d)(?![\w-])"
)
# This is getting complex. Let me use a cleaner approach.

# Cleaner: year with leap check inline
# Leap year: divisible by 4, not by 100, or by 400
# \d{4} = abcd; leap if (cd % 4 == 0 and cd % 100 != 0) or (abcd % 400 == 0)
# cd % 4 == 0: last two digits divisible by 4
# cd % 100 != 0: last two digits not 00
# abcd % 400 == 0: last three digits 000 and first digit even, or last four digits in {0400, 0800, ...}
# Actually abcd % 400 == 0 iff abcd is in {0400, 0800, 1200, ..., 9600} for 4-digit years
# i.e. abcd = k*400, k=1..24

LEAP_Y = (
    r"(?:"
    r"\d{3}[2468]"          # xxx2,xxx4,xxx6,xxx8 -> last digit even, but need last two digits %4==0
    r"|\d{3}[02468][048]"   # last two digits: 00,04,08,20,24,28,40,44,48,60,64,68,80,84,88
    r"|\d{3}[13579][26]"    # last two digits: 12,16,32,36,52,56,72,76,92,96
    r"|(?:19|21|22|23|24|25|26|27|28|29|30|31|32|33|34|35|36|37|38|39|40)00"  # k*400
    r")"
)
# Wait, \d{3}[2468] matches years ending in 2,4,6,8 but that's not right for %4.
# Last two digits % 4 == 0:
# 00,04,08,12,16,20,24,28,32,36,40,44,48,52,56,60,64,68,72,76,80,84,88,92,96
# That's: [02468][048] covers 00,04,08,20,24,28,40,44,48,60,64,68,80,84,88
# [13579][26] covers 12,16,32,36,52,56,72,76,92,96
# Together: all 25 values. Good.
# But we also need NOT divisible by 100 (i.e. last two digits != 00) OR divisible by 400.
# So leap = (last two % 4 == 0 AND last two != 00) OR (year % 400 == 0)
# year % 400 == 0: last three digits 000 and first digit in {0,4,8} for 4-digit, or more precisely
# 0400, 0800, 1200, 1600, 2000, 2400, 2800, 3200, 3600, 4000, 4400, 4800, 5200, 5600, 6000, 6400, 6800, 7200, 7600, 8000, 8400, 8800, 9200, 9600
# i.e. first digit in {0,4,8} and last three 000, OR first digit in {1,2,3,5,6,7,9} and last three 200? No.
# k*400 for k=1..24: 0400,0800,1200,1600,2000,2400,2800,3200,3600,4000,4400,4800,5200,5600,6000,6400,6800,7200,7600,8000,8400,8800,9200,9600
# Pattern: (?:04|08|12|16|20|24|28|32|36|40|44|48|52|56|60|64|68|72|76|80|84|88|92|96)00

DIV400 = r"(?:04|08|12|16|20|24|28|32|36|40|44|48|52|56|60|64|68|72|76|80|84|88|92|96)00"
# Leap year (4-digit):
LEAP_Y = (
    r"(?:"
    r"(?:\d{2}(?:[02468][048]|[13579][26]))(?!00)"  # last two %4==0 and not 00
    r"|"
    + DIV400 +
    r")"
)
# Hmm, \d{2}[02468][048] is 4 digits: first two arbitrary, last two in the set. That's correct for "last two digits %4==0".
# But we need the whole 4-digit year. Let me restructure.

# Year = 4 digits: d1 d2 d3 d4
# Leap if (d3d4 % 4 == 0 and d3d4 != 00) or (year % 400 == 0)
# d3d4 % 4 == 0 and != 00: d3d4 in {04,08,12,16,20,24,28,32,36,40,44,48,52,56,60,64,68,72,76,80,84,88,92,96}
# year % 400 == 0: year in {0400,0800,...,9600}

LEAP_Y = (
    r"(?:"
    r"\d{2}(?:04|08|12|16|20|24|28|32|36|40|44|48|52|56|60|64|68|72|76|80|84|88|92|96)"  # last two %4==0, not 00
    r"|"
    + DIV400 +  # year % 400 == 0
    r")"
)
NONLEAP_Y = r"(?!\d{2}(?:04|08|12|16|20|24|28|32|36|40|44|48|52|56|60|64|68|72|76|80|84|88|92|96))(?!" + DIV400 + r")\d{4}"

# Date pattern
# For non-leap years: months 1,3,5,7,8,10,12 -> 31 days; 4,6,9,11 -> 30 days; 2 -> 28 days
# For leap years: same but Feb -> 29 days
DATE = (
    r"(?<!\d)(?<![\w-])"
    r"(?:"
    # non-leap year
    r"(?:"
    r"(?:" + NONLEAP_Y + r")(?:-(?:0[13578]|1[02])-(?:0[1-9]|[12][0-9]|30)"
    r"|(?:-(?:0[469]|11)-(?:0[1-9]|[12][0-9]|30))"
    r"|(?:-02-(?:0[1-9]|1[0-9]|2[0-8])))"
    r"|"
    # leap year
    r"(?:" + LEAP_Y + r")(?:-(?:0[13578]|1[02])-(?:0[1-9]|[12][0-9]|30)"
    r"|(?:-(?:0[469]|11)-(?:0[1-9]|[12][0-9]|30))"
    r"|-02-(?:0[1-9]|1[0-9]|29))"
    r")"
    r"(?!\d)(?![\w-])"
)

IP = OCT + r"(?:\." + OCT + r"){3}"

# Full regex: match a line that contains an IP, capture the last date on that line
# Strategy: use a lookahead to assert IP presence, then match up to last date
# re.findall returns group(1) if there's one group
PATTERN = (
    r"^(?=.*" + IP + r".*$)"  # line contains an IP
    r"(?:.*" + DATE + r")*"   # consume everything up to and including the last date
    r"(" + DATE + r")"        # capture the last date
)
# Wait, this is greedy: (?:.*DATE)* will consume all dates, then the final (DATE) needs to match after.
# Actually (?:.*DATE)* is greedy and will consume as many DATEs as possible, then the final (DATE) tries to match
# at the position after the last consumed DATE. But there's no more DATE after that, so it backtracks.
# The last iteration of (?:.*DATE)* consumes up to the last DATE, then (DATE) tries to match at the end.
# But .* is greedy too. Let me think again.
#
# Actually the issue: (?:.*DATE)* - each iteration matches .* then DATE. The .* is greedy so it'll try to
# consume as much as possible. The * is greedy so it'll try to repeat as many times as possible.
# The last repetition: .* consumes everything remaining, then DATE must match. If the line ends with a date,
# .* consumes up to just before the date, DATE matches the last date. Then (DATE) tries to match after that - fails.
# Backtrack: the * gives back one iteration. Now .* in the last iteration consumes less...
# This is getting complicated. Let me use a different approach.
#
# Better: use a lookahead to find the last date position, or use a simpler pattern.
#
# Alternative: match the whole line, use a lookahead to assert IP, and capture the last date
# by matching everything up to the last date.
#
# Simplest correct approach:
# ^(?=.*IP)(?:.*?)(DATE)(?!.*DATE)
# where (?!.*DATE) asserts no more dates after this one.
# But (?:.*?) is lazy, so it'll try to match the FIRST date, then (?!.*DATE) checks if there's another date after.
# If yes, backtrack and try the next date. Eventually it finds the last date.
# This works!

PATTERN = (
    r"^(?=.*" + IP + r".*)"   # line contains an IP (lookahead)
    r".*?"                    # lazy match up to a date
    r"(" + DATE + r")"        # capture a date
    r"(?!.*" + DATE + r")"    # assert no more dates after
)

# Test
with open(r"<WORKSPACE>\server.log") as f:
    log_text = f.read()

results = re.findall(PATTERN, log_text, re.MULTILINE)
print("Results:", results)

# Independent check: parse each line, check for IP, find last valid date
def has_ip(line):
    # find all potential IPs with word boundaries
    for m in re.finditer(r"(?<![\d.])(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})(?![\d.])", line):
        parts = m.group(1).split(".")
        if all(0 <= int(p) <= 255 for p in parts):
            # check no leading zeros
            if all(p == "0" or not p.startswith("0") for p in parts):
                return True
    return False

def find_last_date(line):
    dates = []
    for m in re.finditer(r"(?<!\d)(\d{4}-\d{2}-\d{2})(?!\d)", line):
        s = m.group(1)
        y, mo, d = int(s[:4]), int(s[5:7]), int(s[8:10])
        if 1 <= mo <= 12:
            max_d = [31, 29 if (y%4==0 and (y%100!=0 or y%400==0)) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][mo-1]
            if 1 <= d <= max_d:
                dates.append(s)
    return dates[-1] if dates else None

expected = []
for line in log_text.splitlines():
    if has_ip(line):
        d = find_last_date(line)
        if d:
            expected.append(d)

print("Expected:", expected)
print("Match:", results == expected)

# Save the pattern
with open(r"<WORKSPACE>\regex.txt", "w") as f:
    f.write(PATTERN)
print("Pattern saved.")
print("Pattern length:", len(PATTERN))