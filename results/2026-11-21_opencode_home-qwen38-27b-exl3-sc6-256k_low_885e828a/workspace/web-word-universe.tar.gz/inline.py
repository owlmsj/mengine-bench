import json, re

with open("words.json", encoding="utf-8") as f:
    data = json.load(f)
js = json.dumps(data, ensure_ascii=False, separators=(",", ":"))

with open("universe/index.html", encoding="utf-8") as f:
    html = f.read()

# Replace the existing inlined WORDS literal (single line: const WORDS = {...};)
new_line = "const WORDS = " + js + ";"
html = re.sub(r"const WORDS = \{.*?\};", new_line, html, count=1, flags=re.S)

with open("universe/index.html", "w", encoding="utf-8") as f:
    f.write(html)
print("inlined", len(data), "words; html size", len(html))