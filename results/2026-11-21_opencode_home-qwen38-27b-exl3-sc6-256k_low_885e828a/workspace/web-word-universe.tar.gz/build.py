import os, re, json, html
from collections import Counter

site = os.path.join(os.path.dirname(__file__), "site")
pages = [f for f in os.listdir(site) if f.endswith(".html")]
word_files = [f for f in pages if f != "index.html"]

def clean(s):
    return re.sub(r"\s+", " ", html.unescape(s)).strip()

# Pass 1: display title (H1) per file
titles = {}
for f in word_files:
    with open(os.path.join(site, f), encoding="utf-8") as fh:
        text = fh.read()
    h1 = re.search(r"<h1>(.*?)</h1>", text, re.S)
    titles[f] = clean(h1.group(1)) if h1 else f

# Pass 2: build graph keyed by display title
graph = {}
for f in word_files:
    with open(os.path.join(site, f), encoding="utf-8") as fh:
        text = fh.read()
    main = re.search(r"<main>(.*?)</main>", text, re.S)
    main_html = main.group(1) if main else text
    links = re.findall(r'<a href="([^"]+\.html)">([^<]*)</a>', main_html)
    linked = set()
    for href, label in links:
        if href == f:
            continue
        stem = href.rsplit("/", 1)[-1].rsplit(".", 1)[0]
        target = titles.get(stem, clean(label))
        if target != titles[f]:
            linked.add(target)
    graph[titles[f]] = linked

# words.json keyed by display title
words_json = {w: sorted(l) for w, l in graph.items()}

# distinct pairs (canonical: casefold + strip accents)
def norm(s):
    import unicodedata
    s = s.casefold()
    s = "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")
    return s
pairs = set()
for w, linked in graph.items():
    nw = norm(w)
    for l in linked:
        nl = norm(l)
        if nw == nl:
            continue
        pairs.add(tuple(sorted((nw, nl))))

deg = Counter({w: len(l) for w, l in graph.items()})
top = deg.most_common(3)

result = {
    "words": len(graph),
    "relations": len(pairs),
    "most_connected": [{"word": w, "degree": d} for w, d in top],
}

out = os.path.dirname(__file__)
with open(os.path.join(out, "words.json"), "w", encoding="utf-8") as fh:
    json.dump(words_json, fh, ensure_ascii=False, indent=2)
with open(os.path.join(out, "result.json"), "w", encoding="utf-8") as fh:
    json.dump(result, fh, ensure_ascii=False, indent=2)

print("words:", len(graph))
print("relations:", len(pairs))
print("most_connected:", top)
print("keys sample:", list(words_json)[:8])
print("saudade:", words_json.get("saudade"))
print("pais keys:", [k for k in words_json if norm(k) in ("pais","país")])