import json
from datetime import date

# Annual IPCA (IBGE), % per calendar year, from public sources (see dossier)
ipca = {
    1985: 242.25, 1986: 79.66, 1987: 363.41, 1988: 980.22, 1989: 1972.91,
    1990: 1620.97, 1991: 472.69, 1992: 1119.09, 1993: 2477.15, 1994: 916.43,
    1995: 22.41, 1996: 9.56,
}

# plan -> (launch date, next plan launch date or None)
plans = [
    ("Cruzado",   date(1986, 2, 28),  date(1987, 6, 12)),
    ("Bresser",   date(1987, 6, 12),  date(1989, 1, 15)),
    ("Verao",     date(1989, 1, 15),  date(1990, 3, 15)),
    ("Collor I",  date(1990, 3, 15),  date(1991, 1, 31)),
    ("Collor II", date(1991, 1, 31),  date(1994, 7, 1)),
    ("Real",      date(1994, 7, 1),   None),
]

def whole_months(a, b):
    return (b.year - a.year) * 12 + (b.month - a.month) - (1 if b.day < a.day else 0)

out = []
for name, launch, nxt in plans:
    y = launch.year
    before = ipca[y - 1]
    after = ipca[y + 1]
    drop = max(0.0, min(1.0, 1 - after / before))
    if nxt is None:
        months = 60
    else:
        months = whole_months(launch, nxt)
    dur = min(months, 60) / 60
    score = 0.7 * drop + 0.3 * dur
    out.append({
        "plan": name,
        "launch_date": launch.isoformat(),
        "ipca_before": before,
        "ipca_after": after,
        "months_lasted": months,
        "score": round(score, 4),
        "_drop": round(drop, 4),
        "_dur": round(dur, 4),
    })

out.sort(key=lambda r: r["score"], reverse=True)
for r in out:
    print(f"{r['plan']:10} before={r['ipca_before']:8.2f} after={r['ipca_after']:8.2f} "
          f"months={r['months_lasted']:3} drop={r['_drop']:.4f} dur={r['_dur']:.4f} score={r['score']:.4f}")
print("TOP3:", [r["plan"] for r in out[:3]])