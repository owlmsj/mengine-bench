import sqlite3
DB = r'<WORKSPACE>\analytics.db'
c = sqlite3.connect(DB)
# raw distinct valid users with an install event per platform
print("distinct valid users w/ install per platform:", list(c.execute(
    "SELECT u.platform, COUNT(DISTINCT u.user_id) FROM events e JOIN users u ON u.user_id=e.user_id "
    "WHERE u.is_test=0 AND e.name='install' GROUP BY u.platform")))
# users per platform (valid)
print("valid users per platform:", list(c.execute(
    "SELECT platform, COUNT(*) FROM users WHERE is_test=0 GROUP BY platform")))
# install events per user - any user with multiple install events?
print("users with >1 install event:", c.execute(
    "SELECT COUNT(*) FROM (SELECT user_id FROM events WHERE name='install' GROUP BY user_id HAVING COUNT(*)>1)").fetchone()[0])