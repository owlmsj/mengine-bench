import sqlite3
c = sqlite3.connect(r'<WORKSPACE>\analytics.db')
for name, sql in c.execute("SELECT name, sql FROM sqlite_master WHERE type='table'"):
    print("==", name)
    print(sql)
    print()
for name, in c.execute("SELECT name FROM sqlite_master WHERE type='table'"):
    print("== sample", name)
    for row in c.execute(f"SELECT * FROM {name} LIMIT 5"):
        print(row)
    print("count:", c.execute(f"SELECT COUNT(*) FROM {name}").fetchone()[0])