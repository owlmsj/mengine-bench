import sqlite3, json
DB = r'<WORKSPACE>\analytics.db'
STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']
c = sqlite3.connect(DB)

# valid players: known (in users), non-test
users = {uid: (plat, test) for uid, plat, test in c.execute("SELECT user_id, platform, is_test FROM users")}

# first occurrence per (user, step), only events from valid players
first = {}
for uid, name, ts in c.execute("SELECT user_id, name, ts FROM events"):
    if uid not in users or users[uid][1]:
        continue
    if name not in STEPS:
        continue
    key = (uid, name)
    if key not in first or ts < first[key]:
        first[key] = ts

funnel = {}
for plat in sorted({p for p, t in users.values() if not t}):
    counts = {}
    prev = None
    for step in STEPS:
        n = 0
        for uid, (plat2, test) in users.items():
            if test or plat2 != plat:
                continue
            ts = first.get((uid, step))
            if ts is None:
                continue
            if prev is not None:
                p = first.get((uid, prev))
                if p is None or ts < p:
                    continue
            n += 1
        counts[step] = n
        prev = step
    funnel[plat] = counts

# biggest drop: step with lowest conversion (players over previous step)
biggest = {}
for plat, counts in funnel.items():
    best_step, best_conv = None, None
    for i, step in enumerate(STEPS):
        if i == 0:
            continue
        prev_step = STEPS[i-1]
        pc = counts[prev_step]
        conv = (counts[step] / pc) if pc else 0.0
        if best_conv is None or conv < best_conv:
            best_conv, best_step = conv, step
    biggest[plat] = best_step

out = {"funnel": funnel, "biggest_drop": biggest}
with open(r'<WORKSPACE>\result.json', 'w') as f:
    json.dump(out, f, indent=2)
print(json.dumps(out, indent=2))
# sanity: totals
print("total valid players:", sum(1 for p, t in users.values() if not t))
print("install total:", sum(v['install'] for v in funnel.values()))
print("purchase total:", sum(v['purchase'] for v in funnel.values()))