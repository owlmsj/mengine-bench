import json
d = json.load(open(r'<WORKSPACE>\result.json'))
for plat, f in d['funnel'].items():
    print(plat)
    prev = None
    for s in ['install','tutorial_complete','first_match','purchase']:
        if prev is None:
            print(f"  {s}: {f[s]}")
        else:
            print(f"  {s}: {f[s]} ({f[s]/prev:.3f})")
        prev = f[s]
    print("  biggest_drop:", d['biggest_drop'][plat])