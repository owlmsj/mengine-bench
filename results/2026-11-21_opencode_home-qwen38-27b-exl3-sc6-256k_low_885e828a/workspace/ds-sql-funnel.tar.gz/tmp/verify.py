import sqlite3
DB = r'<WORKSPACE>\analytics.db'
c = sqlite3.connect(DB)
print("event names:", list(c.execute("SELECT DISTINCT name FROM events")))
print("platforms:", list(c.execute("SELECT DISTINCT platform FROM users")))
print("test users:", c.execute("SELECT COUNT(*) FROM users WHERE is_test=1").fetchone()[0])
print("events from unknown players:", c.execute(
    "SELECT COUNT(*) FROM events e WHERE NOT EXISTS (SELECT 1 FROM users u WHERE u.user_id=e.user_id)").fetchone()[0])
print("events from test players:", c.execute(
    "SELECT COUNT(*) FROM events e JOIN users u ON u.user_id=e.user_id WHERE u.is_test=1").fetchone()[0])
print("install events per platform (valid):", list(c.execute(
    "SELECT u.platform, COUNT(*) FROM events e JOIN users u ON u.user_id=e.user_id "
    "WHERE u.is_test=0 AND e.name='install' GROUP BY u.platform")))
print("duplicate event rows:", c.execute(
    "SELECT COUNT(*) FROM (SELECT user_id,name,ts FROM events GROUP BY user_id,name,ts HAVING COUNT(*)>1)").fetchone()[0])