# HANDOFF — local-9b @ 128k

**Done (measured):** baseline `measure_decode.ps1 -Ctx 131072 -NPredict 1024`: 37.8 t/s, VRAM 7881 MiB = WDDM ceiling, 1494 MiB spilled to system RAM (Shared Usage counter). Fix `--no-mmproj-offload` + `-ub 512`: spill gone, 7697 MiB, 38.0 t/s (median of 3). Q6_K (7.03 GiB) doesn't fit at 128k, discarded; Q4_K_M (7305 MiB, 40.4 t/s) kept as fallback only. Recipe applied in `scripts/start_server.ps1:165` (local9 block) and `profiles/local/local-9b.json`.

**Open:**
1. Review scratchpad temp-file names (noted for later, never done).
2. Evals README still cites `check_vision.ps1` (file no longer exists) — update it.

**Assumptions:** repo (scripts/, profiles/, evals README) is not in this folder — it's in the project repo. Numbers are from that session; re-run `measure_decode.ps1` on another machine before trusting them.

**Why it's right:** spill fix is a measured A/B (7881+1494 MiB spill → 7697 MiB, none); 38.0 t/s is median of 3.