import csv

# Model memory (GB = 10^9 bytes)
weights_gb = 70e9 / 1e9  # 70 GB (FP8, 1 byte/param)
kv_per_token = 327_680
ctx = 32_768
seqs = 4
kv_cache_gb = kv_per_token * ctx * seqs / 1e9
overhead_gb = 8.0
total_gb = weights_gb + kv_cache_gb + overhead_gb
print(f"weights_gb={weights_gb}, kv_cache_gb={kv_cache_gb}, total_gb={total_gb}")

allowed_regions = {"us-east", "us-central", "eu-west"}
hourly_cap = 4.0

rows = list(csv.DictReader(open(r"<WORKSPACE>\offers.csv")))
best = None
for r in rows:
    ok = True
    reasons = []
    if r["in_stock"].strip().lower() != "yes":
        ok = False; reasons.append("out of stock")
    if r["region"] not in allowed_regions:
        ok = False; reasons.append("region not allowed")
    price = float(r["usd_per_hour"])
    if price > hourly_cap:
        ok = False; reasons.append("over hourly cap")
    usable = int(r["gpu_count"]) * float(r["vram_gb_per_gpu"])
    if usable < total_gb:
        ok = False; reasons.append(f"usable {usable} GB < {total_gb} GB")
    status = "OK" if ok else "NO (" + ", ".join(reasons) + ")"
    print(f"{r['offer_id']}: {r['gpu']} x{r['gpu_count']} {r['region']} ${price}/h usable={usable}GB -> {status}")
    if ok and (best is None or price < best["usd_per_hour"]):
        best = {"offer_id": r["offer_id"], "usd_per_hour": price}

print("best:", best)
if best:
    best["usd_per_month"] = best["usd_per_hour"] * 730
    print("monthly:", best["usd_per_month"])