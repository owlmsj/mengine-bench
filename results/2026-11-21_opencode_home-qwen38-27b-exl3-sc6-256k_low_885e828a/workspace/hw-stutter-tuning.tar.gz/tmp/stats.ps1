$path = '<WORKSPACE>\capture\presentmon.csv'
$lines = Get-Content $path
$mbp = [double[]]@()
$mbd = [double[]]@()
foreach ($l in $lines[1..($lines.Count-1)]) {
  if (-not $l.Trim()) { continue }
  $c = $l.Split(',')
  $mbp += [double]$c[8]
  $mbd += [double]$c[9]
}
$n = $mbp.Count
$mean = ($mbp | Measure-Object -Average).Average
$avgFps = 1000.0 / $mean
function Pct([double[]]$a, [double]$p) {
  $s = $a | Sort-Object
  $idx = [Math]::Ceiling($p/100.0 * $s.Count) - 1
  if ($idx -lt 0) { $idx = 0 }
  return $s[$idx]
}
$p99 = Pct $mbp 99
$low1 = 1000.0 / $p99
$p99d = Pct $mbd 99
Write-Host "frames=$n mean_ms=$mean avg_fps=$avgFps p99_ms=$p99 low1pct_fps=$low1 p99_display_ms=$p99d"
# hitch rows: frame time > 3x median
$med = Pct $mbp 50
$big = 0
for ($i = 1; $i -lt $n; $i++) {
  if ($mbp[$i] -gt 3*$med) {
    $big++
    if ($big -le 15) { Write-Host ("row {0}: time_s={1} mbp={2} mbd={3}" -f ($i+1), $lines[$i].Split(',')[7], $mbp[$i], $mbd[$i]) }
  }
}
Write-Host "big_frames(>3x median)=$big median_ms=$med"