$pm = '<WORKSPACE>\capture\presentmon.csv'
$sn = '<WORKSPACE>\capture\sensors.csv'
$lines = Get-Content $pm
$rows = @()
for ($i = 1; $i -lt $lines.Count; $i++) {
  if (-not $lines[$i].Trim()) { continue }
  $c = $lines[$i].Split(',')
  $rows += ,@([double]$c[7], [double]$c[8])
}
# hitch clusters: contiguous runs of mbp > 15ms
$clusters = @()
$start = -1
for ($i = 0; $i -lt $rows.Count; $i++) {
  if ($rows[$i][1] -gt 15.0) {
    if ($start -lt 0) { $start = $i }
  } else {
    if ($start -ge 0) { $clusters += ,@($rows[$start][0], $rows[$i-1][0]); $start = -1 }
  }
}
if ($start -ge 0) { $clusters += ,@($rows[$start][0], $rows[$rows.Count-1][0]) }
Write-Host "hitch clusters (t_start..t_end):"
foreach ($cl in $clusters) { Write-Host ("  {0:0.000} .. {1:0.000}" -f $cl[0], $cl[1]) }
# sensor L1 and defender rows
$sens = Get-Content $sn
Write-Host "sensor L1 / defender rows:"
foreach ($l in $sens[1..($sens.Count-1)]) {
  if (-not $l.Trim()) { continue }
  $c = $l.Split(',')
  if ($c[4] -eq 'L1' -or $c[8] -ne 'Arena.exe') { Write-Host ("  t={0} link={1} top={2} dpc={3} disk={4}" -f $c[0], $c[4], $c[8], $c[6], $c[7]) }
}
# correlation: for each cluster, which sensor second(s) does it fall in
Write-Host "cluster -> sensor seconds:"
foreach ($cl in $clusters) {
  $a = [int][Math]::Floor($cl[0]); $b = [int][Math]::Ceil($cl[1])
  $hits = @()
  foreach ($l in $sens[1..($sens.Count-1)]) {
    if (-not $l.Trim()) { continue }
    $c = $l.Split(',')
    $t = [int]$c[0]
    if ($t -ge $a -and $t -le $b) { $hits += ("t{0}:{1}/{2}" -f $t, $c[4], $c[8]) }
  }
  Write-Host ("  {0:0.000}..{1:0.000} -> {2}" -f $cl[0], $cl[1], ($hits -join ' '))
}