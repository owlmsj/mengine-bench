import csv, json
from collections import defaultdict

months = ["2026-01","2026-02","2026-03","2026-04","2026-05","2026-06"]
pnl = {}
with open("finance/chart_of_accounts.csv", encoding="utf-8") as f:
    r = csv.reader(f, delimiter=";")
    next(r)
    for row in r:
        pnl[row[0]] = row[2]

agg = {m: defaultdict(float) for m in months}
with open("finance/ledger.csv", encoding="utf-8") as f:
    r = csv.reader(f, delimiter=";")
    next(r)
    for date, acct, desc, amt in r:
        d, m, y = date.split("/")
        key = f"{y}-{m}"
        val = float(amt.replace(".", "").replace(",", "."))
        agg[key][pnl[acct]] += val

out = {"revenue": {}, "gross_margin_pct": {}, "ebitda": {}}
ebitda_by_month = {}
for m in months:
    rev = agg[m]["revenue"]
    cogs = -agg[m]["cogs"]
    gross = rev - cogs
    gm = gross / rev * 100 if rev else 0.0
    ebitda = rev - cogs + agg[m]["sales_marketing"] + agg[m]["rnd"] + agg[m]["ga"]
    out["revenue"][m] = round(rev, 2)
    out["gross_margin_pct"][m] = round(gm, 2)
    out["ebitda"][m] = round(ebitda, 2)
    ebitda_by_month[m] = ebitda

# burn: avg monthly negative EBITDA of last 3 closed months (Apr, May, Jun)
last3 = [ebitda_by_month[m] for m in ["2026-04","2026-05","2026-06"]]
burn = -sum(last3) / 3
cash = 1847350.40
runway = cash / burn
out["burn"] = round(burn, 2)
out["runway_months"] = round(runway, 2)
print(json.dumps(out, indent=1))
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2)