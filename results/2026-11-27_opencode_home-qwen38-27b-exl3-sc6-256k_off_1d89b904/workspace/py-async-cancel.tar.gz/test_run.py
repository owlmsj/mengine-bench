import asyncio
import sys
from run import run_tasks

async def test_normal():
    max_seen = [0]
    cur = [0]
    lock = asyncio.Lock()

    async def job(i):
        async with lock:
            cur[0] += 1
            max_seen[0] = max(max_seen[0], cur[0])
        await asyncio.sleep(0.05)
        async with lock:
            cur[0] -= 1
        return i * 10

    results = await run_tasks([lambda i=i: job(i) for i in range(10)], 3)
    assert sorted(results) == list(range(0, 100, 10)), results
    assert max_seen[0] == 3, max_seen
    print("normal OK, max concurrent seen:", max_seen[0])

async def test_ctrl_c():
    cleaned = []

    def make(i):
        async def job():
            try:
                await asyncio.sleep(30)
            finally:
                cleaned.append(i)
        return job

    # Inject a real KeyboardInterrupt into the loop while run_tasks is running
    async def main():
        t = asyncio.ensure_future(run_tasks([make(i) for i in range(4)], 2))
        await asyncio.sleep(0.1)
        loop = asyncio.get_running_loop()
        loop.call_soon(KeyboardInterrupt)
        try:
            await t
            print("ERROR: KI not raised")
            sys.exit(1)
        except KeyboardInterrupt:
            pass

    await main()
    assert sorted(cleaned) == [0, 1, 2, 3], cleaned
    print("ctrl+c OK, cleaned:", cleaned)

asyncio.run(test_normal())
asyncio.run(test_ctrl_c())
print("ALL OK")