"""Concurrent task runner with graceful Ctrl+C handling."""
import asyncio


async def run_tasks(tasks, max_concurrent):
    """Run zero-arg callables (each returning an awaitable) with bounded concurrency.

    Each task is a zero-argument callable returning an awaitable job. At most
    max_concurrent jobs run at once; the rest wait for a free slot. Returns
    when every job is done.

    Ctrl+C behavior: the first KeyboardInterrupt cancels every running job and
    awaits their cleanup (finally blocks, async with __aexit__, ...) before
    run_tasks re-raises the KeyboardInterrupt. A second Ctrl+C during cleanup
    propagates immediately.
    """
    if max_concurrent < 1:
        raise ValueError("max_concurrent must be >= 1")

    sem = asyncio.Semaphore(max_concurrent)
    pending = set()

    async def wrap(task):
        async with sem:
            return await task()

    for t in tasks:
        pending.add(asyncio.ensure_future(wrap(t)))

    try:
        results = await asyncio.gather(*pending)
    except (KeyboardInterrupt, asyncio.CancelledError) as exc:
        # Cancel every job that is still running or waiting for a slot, then
        # await them so their cleanup code runs to completion.
        for p in pending:
            p.cancel()
        await asyncio.gather(*pending, return_exceptions=True)
        raise exc
    return results