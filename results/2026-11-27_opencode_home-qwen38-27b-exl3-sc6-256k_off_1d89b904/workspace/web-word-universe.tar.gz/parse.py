import os, re, json, unicodedata
from urllib.parse import unquote

site = os.path.join(os.path.dirname(__file__), "site")

def canon(w):
    w = w.strip().lower()
    w = re.sub(r"[^a-z0-9]", "", unicodedata.normalize("NFKD", w))
    return w

# map filename (decoded) -> canonical word, from each page's <h1>
pages = {}
for fn in os.listdir(site):
    if not fn.endswith(".html"):
        continue
    html = open(os.path.join(site, fn), encoding="utf-8").read()
    m = re.search(r"<h1>(.*?)</h1>", html, re.S)
    if not m:
        continue
    word = m.group(1).strip()
    c = canon(word)
    if c:
        pages[unquote(fn)] = c

words = {}  # canonical -> {"display": str, "links": set, "theme": str|None}
for fn, c in pages.items():
    html = open(os.path.join(site, fn), encoding="utf-8").read()
    m = re.search(r"<h1>(.*?)</h1>", html, re.S)
    theme_m = re.search(r'class="tema">Tema:\s*(.*?)</p>', html, re.S)
    entry = words.setdefault(c, {"display": m.group(1).strip(), "links": set(), "theme": theme_m.group(1).strip() if theme_m else None})
    for sec in re.finditer(r'<section id="(sinonimos|analogas)">.*?</section>', html, re.S):
        for a in re.finditer(r'<a href="([^"]+)">([^<]+)</a>', sec.group(0)):
            href = unquote(a.group(1))
            if href in ("index.html", "sobre.html", "contato.html"):
                continue
            tc = pages.get(href)
            if tc:
                entry["links"].add(tc)

# merge plural stubs into singulars (saudades->saudade, coracoes->coracao, paixoes->paixao)
for plural, singular in (("saudades", "saudade"), ("coracoes", "coracao"), ("paixoes", "paixao")):
    if plural in words and singular in words:
        words[singular]["links"] |= words[plural]["links"]
        del words[plural]

out = {c: sorted(e["links"]) for c, e in words.items()}
pairs = set()
for c, links in out.items():
    for l in links:
        pairs.add(tuple(sorted((c, l))))
deg = {c: len(l) for c, l in out.items()}
best = max(deg.values())
most = sorted([c for c, d in deg.items() if d == best])[0]
result = {"words": len(out), "relations": len(pairs), "most_connected": {"word": most, "count": best}}

base = os.path.dirname(__file__)
json.dump(out, open(os.path.join(base, "words.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
json.dump(result, open(os.path.join(base, "result.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
meta = {c: {"display": e["display"], "theme": e["theme"]} for c, e in words.items()}
json.dump(meta, open(os.path.join(base, "meta.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)

print(json.dumps(result, ensure_ascii=False))
print("top:", sorted(deg.items(), key=lambda kv: (-kv[1], kv[0]))[:8])
dangling = sorted({l for links in out.values() for l in links if l not in out})
print("dangling:", dangling)