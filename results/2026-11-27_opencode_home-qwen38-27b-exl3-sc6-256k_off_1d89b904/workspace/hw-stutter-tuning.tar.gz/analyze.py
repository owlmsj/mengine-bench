import csv, statistics, json

# --- presentmon ---
rows = []
with open('capture/presentmon.csv') as f:
    for r in csv.DictReader(f):
        rows.append((float(r['TimeInSeconds']), float(r['MsBetweenPresents'])))

ft = [t for _, t in rows]
n = len(ft)
avg_fps = 1000.0 / (sum(ft) / n)
# p99 frame time (owner's definition: 1000 / p99 of MsBetweenPresents)
srt = sorted(ft)
# linear interpolation percentile (numpy default)
def pct(v, p):
    k = (len(v) - 1) * p / 100.0
    f = int(k); c = min(f + 1, len(v) - 1)
    return v[f] + (v[c] - v[f]) * (k - f)
p99 = pct(srt, 99)
low1 = 1000.0 / p99
print(f"frames={n} avg_fps={avg_fps:.2f} p99_ms={p99:.3f} low1={low1:.2f}")

# --- sensors ---
sens = []
with open('capture/sensors.csv') as f:
    for r in csv.DictReader(f):
        sens.append(r)
print("sensor rows:", len(sens))

# frames per second bucket
buckets = {}
for t, ms in rows:
    b = int(t)
    buckets.setdefault(b, []).append(ms)

# L1 seconds
l1 = [int(r['time_s']) for r in sens if r['gpu_pcie_link_state'] == 'L1']
print("L1 seconds:", l1)

# dpc > 100us
dpc_hi = [(int(r['time_s']), int(r['dpc_latency_us'])) for r in sens if int(r['dpc_latency_us']) > 100]
print("dpc>100us:", dpc_hi)

# per-second: mean ft, max ft, count, sensor state
print("sec | frames | mean_ms | max_ms | L1 | dpc_us | disk% | top_cpu")
for b in sorted(buckets):
    ms = buckets[b]
    s = sens[b] if b < len(sens) else None
    if s:
        print(f"{b:3d} | {len(ms):6d} | {sum(ms)/len(ms):8.2f} | {max(ms):7.2f} | {s['gpu_pcie_link_state']} | {s['dpc_latency_us']:>6} | {s['disk_active_pct']:>4} | {s['top_cpu_process']}")

# worst frames
worst = sorted(rows, key=lambda x: -x[1])[:15]
print("\nworst frames (t, ms):")
for t, ms in worst:
    print(f"  t={t:.3f} ms={ms:.2f}")