import json

# Alfa (first report, 10/02/2026) - units: mg/dL, mg/dL, mg/dL, %
alfa = {
    "GLICOSE EM JEJUM": 92,
    "COLESTEROL LDL": 118,
    "CREATININA": 0.95,
    "HEMOGLOBINA GLICADA (HbA1c)": 5.4,
}
# Alfa reference ranges
ref = {
    "GLICOSE EM JEJUM": (70, 99),
    "COLESTEROL LDL": (None, 130),   # "inferior a 130"
    "CREATININA": (0.70, 1.30),
    "HEMOGLOBINA GLICADA (HbA1c)": (4.0, 5.6),
}

# Beta (18/08/2026) converted to Alfa units
# glucose: 6.1 mmol/L * 18.01559 = mg/dL
# LDL: 3.70 mmol/L * 38.67 = mg/dL
# creatinine: 76 umol/L / 88.42 = mg/dL
# HbA1c: 37 mmol/mol -> % via IFCC: % = (mmol/mol + 23.5) / 1.0929
glu = 6.1 * 18.01559
ldl = 3.70 * 38.67
cre = 76 / 88.42
hba1c = (37 + 23.5) / 10.929

beta = {
    "GLICOSE EM JEJUM": round(glu, 1),
    "COLESTEROL LDL": round(ldl, 1),
    "CREATININA": round(cre, 2),
    "HEMOGLOBINA GLICADA (HbA1c)": round(hba1c, 2),
}

history = {}
for m in alfa:
    history[m] = {"2026-02-10": alfa[m], "2026-08-18": beta[m]}

worse = []
for m in alfa:
    lo, hi = ref[m]
    v = beta[m]
    outside = (lo is not None and v < lo) or (hi is not None and v > hi)
    if outside:
        worse.append(m)

result = {"history": history, "worse": worse}
with open("result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
print(json.dumps(result, ensure_ascii=False, indent=2))