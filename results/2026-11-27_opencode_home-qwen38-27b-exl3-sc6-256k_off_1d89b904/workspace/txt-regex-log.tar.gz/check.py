import re

pat = open("regex.txt", encoding="utf-8").read().strip()
log = open("server.log", encoding="utf-8").read()
print("sample:", re.findall(pat, log, re.MULTILINE))

cases = [
    # (line, expected)
    ("2026-04-02 07:15:09 INFO  gateway accepted 10.12.0.7 for build 2026-04-01", ["2026-04-01"]),
    ("2026-04-02 07:15:11 INFO  cache warm, 412 keys, next sweep 2026-04-03", []),
    ("2026-04-02 07:16:40 WARN  peer 192.168.40.3 slow, retry window 2026-04-02 to 2026-04-05", ["2026-04-05"]),
    ("2026-04-02 07:18:02 INFO  job 7781-20-4410 queued by scheduler", []),
    ("2026-04-02 07:19:30 ERROR upstream 172.20.1.14 refused handshake", []),
    # address edge cases
    ("bad ip 256.1.1.1 date 2026-01-01", []),
    ("bad ip 1.2.3.04 date 2026-01-01", []),
    ("bad ip 01.2.3.4 date 2026-01-01", []),
    ("ok ip 255.255.255.255 date 2026-01-01", ["2026-01-01"]),
    ("ok ip 0.0.0.0 date 2026-01-01", ["2026-01-01"]),
    ("glued 91.2.3.4 date 2026-01-01", []),
    ("glued 1.2.3.456 date 2026-01-01", []),
    ("dotted 1.2.3.4.5 date 2026-01-01", []),
    ("dash 1.2.3.4-x date 2026-01-01", []),
    ("dot 1.2.3.4. date 2026-01-01", []),
    # date edge cases
    ("ip 10.0.0.1 feb 2026-02-29", ["2026-02-29"]),
    ("ip 10.0.0.1 feb 2025-02-29", ["2025-02-29"]),
    ("ip 10.0.0.1 feb 2026-02-30", []),
    ("ip 10.0.0.1 apr 2026-04-31", []),
    ("ip 10.0.0.1 jun 2026-06-31", []),
    ("ip 10.0.0.1 dec 2026-12-31", ["2026-12-31"]),
    ("ip 10.0.0.1 glued x2026-01-01", []),
    ("ip 10.0.0.1 glued 2026-01-01x", []),
    ("ip 10.0.0.1 glued 2026-01-01-5", []),
    ("ip 10.0.0.1 two 2026-01-01 2026-01-02", ["2026-01-02"]),
    ("no ip 2026-01-01 2026-01-02", []),
    ("ip 10.0.0.1 only date 2026-01-01", ["2026-01-01"]),
]
bad = 0
for line, exp in cases:
    got = re.findall(pat, line, re.MULTILINE)
    if got != exp:
        bad += 1
        print("FAIL", repr(line), "got", got, "want", exp)
print("all pass" if bad == 0 else f"{bad} failures")