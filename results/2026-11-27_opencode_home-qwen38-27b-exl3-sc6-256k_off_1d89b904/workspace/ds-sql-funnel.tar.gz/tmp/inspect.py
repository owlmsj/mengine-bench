import sqlite3
c = sqlite3.connect('analytics.db')
for r in c.execute("SELECT name, sql FROM sqlite_master WHERE type='table'"):
    print(r[0])
    print(r[1])
    print('---')
    n = c.execute(f"SELECT COUNT(*) FROM {r[0]}").fetchone()[0]
    print('rows:', n)
    for row in c.execute(f"SELECT * FROM {r[0]} LIMIT 5"):
        print(row)
    print()