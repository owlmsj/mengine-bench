import sqlite3, json
c = sqlite3.connect('analytics.db')
STEPS = ['install', 'tutorial_complete', 'first_match', 'purchase']
users = {uid: (plat, test) for uid, plat, test in c.execute("SELECT user_id, platform, is_test FROM users")}
# first valid occurrence per user per step
first = {}
for uid, name, ts in c.execute("SELECT user_id, name, ts FROM events"):
    if name not in STEPS:
        continue
    key = (uid, name)
    if key not in first or ts < first[key]:
        first[key] = ts
# per platform funnel: step counts only at or after previous step
funnel = {}
for plat in sorted({p for p, _ in users.values()}):
    counts = {}
    for i, step in enumerate(STEPS):
        n = 0
        for uid, (p, test) in users.items():
            if p != plat or test:
                continue
            t = first.get((uid, step))
            if t is None:
                continue
            ok = True
            for prev in STEPS[:i]:
                tp = first.get((uid, prev))
                if tp is None or t < tp:
                    ok = False
                    break
            if ok:
                n += 1
        counts[step] = n
    funnel[plat] = counts
# biggest drop: step with lowest conversion (players over previous step's players)
result = {'funnel': funnel, 'biggest_drop': {}}
for plat, counts in funnel.items():
    worst, worst_conv = None, None
    for i in range(1, len(STEPS)):
        prev, cur = STEPS[i-1], STEPS[i]
        conv = counts[cur] / counts[prev] if counts[prev] else 0.0
        if worst_conv is None or conv < worst_conv:
            worst, worst_conv = cur, conv
    result['biggest_drop'][plat] = worst
print(json.dumps(result, indent=2))
with open('result.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, indent=2)