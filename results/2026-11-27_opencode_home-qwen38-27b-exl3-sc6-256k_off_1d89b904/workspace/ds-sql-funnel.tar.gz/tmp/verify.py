import sqlite3
c = sqlite3.connect('analytics.db')
# independent check: for each platform, count users with first valid occurrence of each step
# using window functions, no python loop
q = """
WITH f AS (
  SELECT e.user_id, e.name, MIN(e.ts) ts
  FROM events e JOIN users u ON u.user_id=e.user_id
  WHERE u.is_test=0 AND e.name IN ('install','tutorial_complete','first_match','purchase')
  GROUP BY e.user_id, e.name
)
SELECT u.platform,
  SUM(CASE WHEN f.name='install' THEN 1 ELSE 0 END),
  SUM(CASE WHEN f.name='tutorial_complete' AND
      (SELECT MIN(ts) FROM f f2 WHERE f2.user_id=f.user_id AND f2.name='install') <= f.ts THEN 1 ELSE 0 END),
  SUM(CASE WHEN f.name='first_match' AND
      (SELECT MIN(ts) FROM f f2 WHERE f2.user_id=f.user_id AND f2.name='tutorial_complete') <= f.ts THEN 1 ELSE 0 END),
  SUM(CASE WHEN f.name='purchase' AND
      (SELECT MIN(ts) FROM f f2 WHERE f2.user_id=f.user_id AND f2.name='first_match') <= f.ts THEN 1 ELSE 0 END)
FROM f JOIN users u ON u.user_id=f.user_id
GROUP BY u.platform
"""
# note: the above per-step condition only checks immediate previous step's first ts;
# full rule needs all previous steps. Do full check in python instead.
first = {}
for uid, name, ts in c.execute("SELECT user_id, name, ts FROM events"):
    k=(uid,name)
    if k not in first or ts<first[k]: first[k]=ts
users = {uid:(plat,test) for uid,plat,test in c.execute("SELECT user_id,platform,is_test FROM users")}
STEPS=['install','tutorial_complete','first_match','purchase']
from collections import defaultdict
out=defaultdict(lambda: defaultdict(int))
for uid,(plat,test) in users.items():
    if test: continue
    for i,s in enumerate(STEPS):
        t=first.get((uid,s))
        if t is None: continue
        ok=True
        for prev in STEPS[:i]:
            tp=first.get((uid,prev))
            if tp is None or t<tp:
                ok=False; break
        if ok: out[plat][s]+=1
for plat in sorted(out):
    print(plat, dict(out[plat]))