import csv, json, math

rows = {}
with open("telemetry/playtest_ab.csv", newline="", encoding="utf-8") as f:
    for r in csv.DictReader(f):
        sid = r["session_id"].strip()
        variant = r["variant"].strip().lower()
        comp = int(r["completed_tutorial"])
        rows[sid] = (variant, comp)  # dedupe: last row wins (same session)

a = [c for v, c in rows.values() if v == "a"]
b = [c for v, c in rows.values() if v == "b"]
na, nb = len(a), len(b)
ca, cb = sum(a), sum(b)
pa, pb = ca / na, cb / nb
p = (ca + cb) / (na + nb)
se = math.sqrt(p * (1 - p) * (1 / na + 1 / nb))
z = (pb - pa) / se
# two-sided p-value via normal CDF
p_value = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))

print(f"sessions_a={na} sessions_b={nb}")
print(f"completed_a={ca} completed_b={cb}")
print(f"rate_a={pa:.6f} rate_b={pb:.6f}")
print(f"z={z:.4f} p_value={p_value:.6g}")
print(f"significant_at_5%={p_value < 0.05}")

with open("result.json", "w", encoding="utf-8") as f:
    json.dump({
        "ship_b": bool(p_value < 0.05 and pb > pa),
        "sessions_a": na,
        "sessions_b": nb,
        "completion_rate_a": round(pa, 6),
        "completion_rate_b": round(pb, 6),
        "p_value": round(p_value, 6),
    }, f, indent=2)
print("wrote result.json")