import json

# Annual IPCA % (IBGE), calendar year
ipca = {
    1985: 242.23,
    1986: 79.66,
    1987: 363.41,
    1988: 980.21,
    1989: 1972.91,
    1990: 1620.97,
    1991: 472.70,
    1992: 1119.10,
    1993: 2477.15,
    1994: 916.46,
    1995: 22.41,
}

# plan: (launch_date, next_launch_date or None)
plans = [
    ("Cruzado", "1986-02-15", "1987-02-15"),
    ("Bresser", "1987-02-15", "1989-03-15"),
    ("Verao", "1989-03-15", "1990-03-15"),
    ("Collor I", "1990-03-15", "1991-03-15"),
    ("Collor II", "1991-03-15", "1994-02-01"),
    ("Real", "1994-07-01", None),
]

def months_between(d1, d2):
    y1, m1, _ = map(int, d1.split("-"))
    y2, m2, _ = map(int, d2.split("-"))
    return (y2 - y1) * 12 + (m2 - m1)

results = []
for name, launch, nxt in plans:
    y = int(launch[:4])
    before = ipca[y - 1]
    after = ipca[y + 1]
    drop = max(0.0, min(1.0, 1 - after / before))
    if nxt is None:
        m = 60
    else:
        m = months_between(launch, nxt)
    dur = min(m, 60) / 60
    score = 0.7 * drop + 0.3 * dur
    results.append({
        "plan": name,
        "launch_date": launch,
        "ipca_before": before,
        "ipca_after": after,
        "months_lasted": m,
        "score": round(score, 4),
    })

results.sort(key=lambda r: r["score"], reverse=True)
print(json.dumps(results, indent=2))
print("TOP3:", [r["plan"] for r in results[:3]])