# HANDOFF — local-9b @ 128k

Goal: measure local-9b Q5 at 128k context.

Done (measured):
- Baseline `measure_decode.ps1 -Ctx 131072 -NPredict 1024`: 37.8 t/s, VRAM 7881 MiB. 7881 is the WDDM ceiling; 1494 MiB spilled, so that VRAM number does not count.
- Fix `--no-mmproj-offload -ub 512`: spill gone → 7697 MiB, 38.0 t/s (median of 3).
- Q6_K (7.03 GiB) does not fit at 128k — discarded. Q4_K_M fits (7305 MiB, 40.4 t/s) — fallback only.
- Recipe applied: scripts/start_server.ps1:165 (local9 block), profiles/local/local-9b.json.

Left:
1. Evals README still cites check_vision.ps1, which no longer exists — update it.
2. Review the scratchpad temp-file names.

Assumptions: local-9b = local9 block; Q5 kept; 38.0 t/s / 7697 MiB final.

Found: 128k measurement complete, spill fixed; open items are the README reference and temp-file names. I know it is right because the transcript records the measured runs (37.8→38.0 t/s, spill gone) and the recipe applied at the two cited paths.