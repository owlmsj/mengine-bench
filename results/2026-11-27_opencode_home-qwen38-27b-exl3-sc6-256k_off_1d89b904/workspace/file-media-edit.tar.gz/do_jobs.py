import os
from PIL import Image
import pypdf

os.makedirs('out', exist_ok=True)

# --- Job 1: feed photo 1080x1350, magenta balloon fully inside ---
im = Image.open('launch.jpg').convert('RGB')
W, H = im.size  # 3000x2000
# balloon bbox from scan (with margin)
bx0, by0, bx1, by1 = 2352, 500, 2748, 900
# target aspect 1080:1350 = 4:5
tw, th = 1080, 1350
ar = tw / th  # 0.8
# choose crop window in source that contains balloon and has aspect ar
# balloon center
cx, cy = (bx0 + bx1) / 2, (by0 + by1) / 2
# crop width in source: choose so balloon fits with margin; use balloon span * factor
bw = bx1 - bx0  # 396
bh = by1 - by0  # 400
# crop must be at least balloon size; pick crop w = max(bw, bh/ar) * 1.6 margin
cw = max(bw, bh / ar) * 1.7
ch = cw * ar
# center on balloon but clamp to image
x0 = int(cx - cw / 2)
y0 = int(cy - ch / 2)
x0 = max(0, min(x0, W - int(cw)))
y0 = max(0, min(y0, H - int(ch)))
x1 = x0 + int(cw)
y1 = y0 + int(ch)
print('crop', x0, y0, x1, y1)
crop = im.crop((x0, y0, x1, y1)).resize((tw, th), Image.LANCZOS)
crop.save('out/feed-photo.jpg', quality=92)
print('saved feed-photo.jpg', crop.size)

# --- Job 2: fill permit form and flatten ---
reader = pypdf.PdfReader('permit-form.pdf')
writer = pypdf.PdfWriter()
writer.append(reader)
data = {
    'organizer': 'Tidewater Studio',
    'event_date': 'Saturday 5 December 2026',
    'location': 'North Cove Lawn',
    'attendees': 'about 40',
}
writer.update_page_form_field_values(writer.pages[0], data, auto_regenerate=False)
# flatten: set ReadOnly flag on all fields so answers can no longer be edited
for page in writer.pages:
    for annot in page.get('/Annots', []):
        o = annot.get_object()
        if o.get('/Subtype') == '/Widget':
            ff = o.get('/Ff', 0)
            o[pypdf.generic.NameObject('/Ff')] = pypdf.generic.NumberObject(int(ff) | 1)  # ReadOnly bit = 1
with open('out/permit-filled.pdf', 'wb') as f:
    writer.write(f)
print('saved permit-filled.pdf')