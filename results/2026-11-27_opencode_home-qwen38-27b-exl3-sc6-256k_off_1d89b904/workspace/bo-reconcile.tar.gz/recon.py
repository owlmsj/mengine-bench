import csv, re, json
from collections import defaultdict

base = r"<WORKSPACE>\backoffice"

invoices = {}
with open(f"{base}/invoices.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        invoices[row["id"]] = float(row["amount"])

payments = defaultdict(list)  # invoice id -> [amounts]
ignored = []
with open(f"{base}/bank_statement_june.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        memo = row["memo"]
        m = re.search(r"(?:inv|invoice)\s*-?#?(\d{4})", memo, re.I)
        if not m:
            ignored.append(memo)
            continue
        inv = "INV-" + m.group(1)
        if inv not in invoices:
            ignored.append(memo)
            continue
        payments[inv].append(float(row["amount"]))

unpaid, duplicated, mismatched = [], [], []
for inv in sorted(invoices):
    pays = payments.get(inv, [])
    if not pays:
        unpaid.append(inv)
    elif len(pays) > 1:
        duplicated.append(inv)
    elif abs(pays[0] - invoices[inv]) > 0.005:
        mismatched.append({"id": inv, "invoiced": invoices[inv], "paid": pays[0]})

result = {"unpaid": unpaid, "duplicated": duplicated, "mismatched": mismatched}
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(result, f, indent=2, ensure_ascii=False)
print(json.dumps(result, indent=2, ensure_ascii=False))
print("ignored:", ignored)
print("paid invoices:", len(payments), "of", len(invoices))