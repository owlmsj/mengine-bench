"""Loot drops for the dungeon crawler."""

RARE_CHANCE = 0.05
PITY_LIMIT = 10


class LootTable:
    """Decides what one defeated monster drops."""

    def __init__(self, event_multiplier: float = 1.0) -> None:
        self.event_multiplier = event_multiplier
        self.misses = 0

    def drop(self, roll: float) -> str:
        """Return "rare" or "common" for a roll in [0, 1).

        A roll below the rare chance drops a rare.
        Pity timer: after PITY_LIMIT common drops in a row, the next drop is rare whatever the roll.
        Any rare drop, however it came, resets the count of commons in a row to zero.
        During an event the rare chance is RARE_CHANCE times event_multiplier, capped at 1.
        A rare that only the event made possible is a rare like any other.
        """
        chance = min(1.0, RARE_CHANCE * self.event_multiplier)
        if self.misses >= PITY_LIMIT or roll < chance:
            self.misses = 0
            return "rare"
        self.misses += 1
        return "common"