import json, datetime
from datetime import date
IPCA = {1985:242.23,1986:79.66,1987:363.41,1988:980.21,1989:1972.91,1990:1620.97,
        1991:472.70,1992:1119.10,1993:2477.15,1994:916.46,1995:22.41}
def whole_months(a,b):
    m=(b.year-a.year)*12+(b.month-a.month)
    try: anniv=a.replace(year=a.year+m//12, month=((a.month-1+m)%12)+1)
    except ValueError:  # day 31 -> clamp to month end
        y=a.year+(a.month-1+m)//12; mo=(a.month-1+m)%12+1
        import calendar; anniv=date(y,mo,calendar.monthrange(y,mo)[1])
    if anniv>b: m-=1
    return m
PLANS=[("Cruzado",date(1986,2,28),date(1987,6,12)),("Bresser",date(1987,6,12),date(1989,1,15)),
("Verao",date(1989,1,15),date(1990,3,16)),("Collor I",date(1990,3,16),date(1991,1,31)),
("Collor II",date(1991,1,31),date(1994,2,27)),("Real",date(1994,2,27),None)]
SIDRA="https://apisidra.ibge.gov.br/values/t/1737/n1/all/v/69/p/198512,198612,198712,198812,198912,199012,199112,199212,199312,199412,199512"
SRC={"Cruzado":"http://www.planalto.gov.br/ccivil_03/decreto-lei/1980-1988/del2283.htm",
"Bresser":"http://www.planalto.gov.br/ccivil_03/decreto-lei/1980-1988/del2335.htm",
"Verao":"http://www.planalto.gov.br/ccivil_03/mpv/1988-1989/032.htm",
"Collor I":"http://www.planalto.gov.br/ccivil_03/mpv/1990-1995/168.htm",
"Collor II":"http://www.planalto.gov.br/ccivil_03/mpv/1990-1995/294.htm",
"Real":"http://www.planalto.gov.br/ccivil_03/mpv/1990-1995/434.htm"}
out=[]
for name,launch,nxt in PLANS:
    y=launch.year; before=IPCA[y-1]; after=IPCA[y+1]
    drop=max(0.0,min(1.0,1-after/before))
    months=60 if nxt is None else whole_months(launch,nxt)
    dur=min(months,60)/60
    score=0.7*drop+0.3*dur
    out.append(dict(plan=name,launch_date=launch.isoformat(),ipca_before=before,ipca_after=after,
        months_lasted=months,score=round(score,4),
        sources=[SRC[name],SIDRA,"https://sidra.ibge.gov.br/tabela/1737"]))
    print(f"{name:9s} {launch} before={before:8.2f} after={after:8.2f} drop={drop:.4f} months={months:2d} dur={dur:.4f} score={score:.4f}")
out_sorted=sorted(out,key=lambda r:-r["score"])
json.dump({"plans":out,"top3":[r["plan"] for r in out_sorted[:3]]},open("result.json","w"),indent=2)
print("top3:",[r["plan"] for r in out_sorted])
