"""Proves run_tasks: concurrency cap, ordering, failure policy, Ctrl+C cleanup."""

import asyncio
import time

from run import run_tasks


async def test_cap_and_order() -> None:
    live = peak = 0
    done: list[int] = []

    def make(i: int):
        async def job():
            nonlocal live, peak
            live += 1
            peak = max(peak, live)
            await asyncio.sleep(0.05 - 0.004 * i)
            live -= 1
            done.append(i)
            return i * 10

        return job

    t0 = time.perf_counter()
    results = await run_tasks([make(i) for i in range(10)], max_concurrent=3)
    dt = time.perf_counter() - t0
    assert results == [i * 10 for i in range(10)], results
    assert peak == 3, peak
    assert done == sorted(done) or len(done) == 10
    assert 0.10 < dt < 0.35, dt  # ~4 waves of 3, not 10 serial, not all-at-once
    assert await run_tasks([], max_concurrent=3) == []
    print("test_cap_and_order ok", peak, round(dt, 3))


async def test_cleanup_on_cancel() -> None:
    started = cleaned = 0

    def make(i: int):
        async def job():
            nonlocal started, cleaned
            started += 1
            try:
                await asyncio.sleep(10)
            finally:
                await asyncio.sleep(0.05)  # async cleanup must still run
                cleaned += 1

        return job

    runner = asyncio.create_task(run_tasks([make(i) for i in range(6)], max_concurrent=3))
    await asyncio.sleep(0.1)
    runner.cancel()  # what asyncio.run does on Ctrl+C
    try:
        await runner
        raise AssertionError("expected CancelledError")
    except asyncio.CancelledError:
        pass
    assert started == 3, started  # only admitted jobs ever began, so only they clean up
    assert cleaned == 3, cleaned
    print("test_cleanup_on_cancel ok", started, cleaned)


async def test_keyboard_interrupt_runs_cleanup() -> None:
    cleaned = 0

    async def job():
        nonlocal cleaned
        try:
            await asyncio.sleep(10)
        finally:
            await asyncio.sleep(0.02)
            cleaned += 1

    def make():
        return job

    runner = asyncio.create_task(run_tasks([make() for _ in range(2)], max_concurrent=2))
    await asyncio.sleep(0.05)
    runner.cancel(msg="KeyboardInterrupt")
    await asyncio.gather(runner, return_exceptions=True)
    assert cleaned == 2, cleaned
    print("test_keyboard_interrupt_runs_cleanup ok", cleaned)


async def test_failures() -> None:
    def make(i: int):
        async def job():
            await asyncio.sleep(0.01 * i)
            if i % 2:
                raise ValueError(i)
            return i

        return job

    try:
        await run_tasks([make(i) for i in range(4)], max_concurrent=2)
        raise AssertionError("expected failure")
    except BaseExceptionGroup as group:
        assert sorted(e.args[0] for e in group.exceptions) == [1, 3], group

    def bad():
        async def job():
            raise RuntimeError("solo")

        return job

    try:
        await run_tasks([bad()], max_concurrent=1)
        raise AssertionError("expected RuntimeError")
    except RuntimeError as exc:
        assert str(exc) == "solo"

    try:
        await run_tasks([bad()], max_concurrent=0)
        raise AssertionError("expected ValueError")
    except ValueError as exc:
        assert "max_concurrent" in str(exc), exc
    print("test_failures ok")


async def main() -> None:
    await test_cap_and_order()
    await test_cleanup_on_cancel()
    await test_keyboard_interrupt_runs_cleanup()
    await test_failures()
    print("ALL OK")


asyncio.run(main())