# Real SIGINT (Ctrl+C path): KeyboardInterrupt escapes run_until_complete,
# asyncio.run cancels the main task, run_tasks must still run job cleanup.
import asyncio, os, signal, threading, time
from run import run_tasks

cleaned = []

def make(i):
    async def job():
        try:
            await asyncio.sleep(30)
        finally:
            await asyncio.sleep(0.1)   # async cleanup (flush, close, commit)
            cleaned.append(i)
            print(f"cleanup {i}", flush=True)
    return job

def poke():
    time.sleep(0.3)
    os.kill(os.getpid(), signal.SIGINT)  # same signal a Ctrl+C delivers

threading.Thread(target=poke, daemon=True).start()
try:
    asyncio.run(run_tasks([make(i) for i in range(4)], max_concurrent=2))
except KeyboardInterrupt:
    print("KeyboardInterrupt escaped asyncio.run")
print("cleaned:", cleaned)
