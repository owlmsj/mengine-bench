"""Bounded-concurrency batch runner for zero-argument async job factories.

Used by batch scripts as::

    from run import run_tasks

    results = await run_tasks([make_job(a) for a in items], max_concurrent=8)
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Iterable
from typing import Any, TypeVar

T = TypeVar("T")

Job = Callable[[], Awaitable[T]]


async def run_tasks(tasks: Iterable[Job[Any]], max_concurrent: int) -> list[Any]:
    """Run every job with at most ``max_concurrent`` jobs in flight.

    ``tasks`` is an iterable of zero-argument callables; each call returns an
    awaitable. Returns a list of job results in input order once every job has
    finished.

    Failure policy (brief is silent, this is the chosen contract):
      * A job raising does not stop the other jobs; all jobs are awaited, then
        the first failure is re-raised, or a BaseExceptionGroup if several jobs
        failed (each with ``__context__`` chaining to the others is not done,
        the group carries them all).
      * Cancellation (Ctrl+C -> KeyboardInterrupt, or the surrounding task
        being cancelled) cancels every job and *awaits* them, so each job's
        ``finally`` block / ``async with`` cleanup runs to completion, before
        the CancelledError is re-raised. A second Ctrl+C can abandon that
        cleanup wait; that is unavoidable without blocking the loop.
    """
    if max_concurrent < 1:
        raise ValueError(f"max_concurrent must be >= 1, got {max_concurrent!r}")

    semaphore = asyncio.Semaphore(max_concurrent)
    jobs = [asyncio.ensure_future(_bounded(job, semaphore)) for job in tasks]
    if not jobs:
        return []

    try:
        outcomes = await asyncio.gather(*jobs, return_exceptions=True)
    except (KeyboardInterrupt, asyncio.CancelledError):
        for job in jobs:
            job.cancel()
        # Jobs are already cancelled; this await only lets their cleanup
        # (finally blocks, async context managers) finish. return_exceptions
        # keeps one cleanup error from hiding the cancellation.
        await asyncio.gather(*jobs, return_exceptions=True)
        raise

    failures = [r for r in outcomes if isinstance(r, BaseException)]
    if len(failures) == 1:
        raise failures[0]
    if failures:
        raise BaseExceptionGroup("run_tasks: jobs failed", failures)
    return list(outcomes)


async def _bounded(job: Job[Any], semaphore: asyncio.Semaphore) -> Any:
    """Call ``job()`` only while a slot is free, then await the awaitable."""
    async with semaphore:
        return await job()