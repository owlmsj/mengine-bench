"""Runtime config. Precedence, lowest to highest: DEFAULTS < JSON file < env (docs/CONFIG.md)."""

import json
import os

from arena_server.config.defaults import DEFAULTS


def _coerce(raw, like):
    """Cast an env string to the type of the default it overrides."""
    if isinstance(like, bool):
        if isinstance(raw, bool):
            return raw
        if str(raw).strip().lower() in {"1", "true", "yes", "on"}:
            return True
        if str(raw).strip().lower() in {"0", "false", "no", "off"}:
            return False
        raise ValueError(f"expected a boolean for ARENA env override, got {raw!r}")
    if isinstance(like, int) and not isinstance(like, bool):
        return int(str(raw).strip())
    try:
        return type(like)(str(raw).strip()) if isinstance(raw, str) else type(like)(raw)
    except (TypeError, ValueError) as exc:
        raise ValueError(
            f"expected a value coercible to {type(like).__name__}, got {raw!r}"
        ) from exc


def load_config(file_path=None, env=None):
    cfg = dict(DEFAULTS)
    env = os.environ if env is None else env
    if file_path:
        with open(file_path, encoding="utf-8") as fh:
            cfg.update(json.load(fh))
    # Env last: live-ops must win over the deployed JSON file (docs/CONFIG.md).
    for key, default in DEFAULTS.items():
        value = env.get(f"ARENA_{key.upper()}")
        if value is not None:
            cfg[key] = _coerce(value, default)
    return cfg