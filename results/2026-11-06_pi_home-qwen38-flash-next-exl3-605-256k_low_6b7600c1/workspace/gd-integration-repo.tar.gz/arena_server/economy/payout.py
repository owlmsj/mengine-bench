"""Match payout. Rules live in docs/ECONOMY.md."""

from decimal import ROUND_HALF_UP, Decimal

_TEN = Decimal(10)


def _dec(value):
    """Exact Decimal from any numeric config value, without binary float noise."""
    return Decimal(str(value))


def match_payout(won, kills, cfg):
    base = _dec(cfg["win_base"] if won else cfg["loss_base"])
    raw = (base + _dec(kills) * _dec(cfg["kill_bonus"])) * _dec(cfg["event_multiplier"])
    return int((raw / _TEN).quantize(Decimal(1), rounding=ROUND_HALF_UP) * _TEN)