import json
import tempfile
import unittest
from decimal import Decimal
from pathlib import Path

from arena_server.config.loader import load_config
from arena_server.economy.payout import match_payout
from arena_server.models.profile import Profile
from arena_server.persistence.codec import decode, encode


class ConfigPrecedence(unittest.TestCase):
    def test_env_beats_file_beats_defaults(self):
        with tempfile.TemporaryDirectory() as tmp:
            cfg_file = Path(tmp) / "live.json"
            cfg_file.write_text(json.dumps({"kill_bonus": 50, "event_multiplier": 1.25}))
            cfg = load_config(cfg_file, env={"ARENA_KILL_BONUS": "75"})
            self.assertEqual(cfg["kill_bonus"], 75)
            self.assertEqual(cfg["event_multiplier"], 1.25)
            self.assertEqual(cfg["win_base"], 900)

    def test_env_coerces_to_default_type(self):
        cfg = load_config(env={"ARENA_EVENT_MULTIPLIER": "2.5", "ARENA_WIN_BASE": "1000"})
        self.assertEqual(cfg["event_multiplier"], 2.5)
        self.assertEqual(cfg["win_base"], 1000)


class Rounding(unittest.TestCase):
    def test_rounds_to_nearest_ten_halves_up(self):
        cfg = {"win_base": 900, "loss_base": 600, "kill_bonus": 50, "event_multiplier": 1.5}
        self.assertEqual(match_payout(True, 5, cfg), 1730)   # 1150 * 1.5 = 1725 -> up
        self.assertEqual(match_payout(False, 5, cfg), 1280)  # 850 * 1.5 = 1275 -> up
        cfg["event_multiplier"] = 1.238
        self.assertEqual(match_payout(True, 5, cfg), 1420)   # 1423.7 -> down

    def test_half_up_survives_float_noise(self):
        # 650 * 0.7 == 454.99999999999994 in binary floats; the rule is 455 -> 460.
        cfg = {"win_base": 600, "loss_base": 600, "kill_bonus": 50, "event_multiplier": 0.7}
        self.assertEqual(match_payout(False, 1, cfg), 460)

    def test_returns_int(self):
        cfg = {"win_base": 900, "loss_base": 600, "kill_bonus": 75, "event_multiplier": 1.25}
        payout = match_payout(True, 5, cfg)  # (900 + 375) * 1.25 = 1593.75 -> 1590
        self.assertIsInstance(payout, int)
        self.assertEqual(payout, 1590)
        self.assertNotIsInstance(payout, Decimal)

    def test_doc_examples(self):
        cfg = {"win_base": 900, "loss_base": 600, "kill_bonus": 105, "event_multiplier": 1.0}
        self.assertEqual(match_payout(True, 5, cfg), 1430)  # 1425 -> 1430 (docs/ECONOMY.md)
        cfg["kill_bonus"] = 137
        self.assertEqual(match_payout(True, 5, cfg), 1590)  # 1585 -> 1590 (docs/ECONOMY.md)


class ProfilePersistence(unittest.TestCase):
    def test_credits_round_trip(self):
        blob = encode(Profile("p1", level=12, credits=1690, cosmetics=["neoplastic_skin"]))
        self.assertEqual(decode(blob).credits, 1690)

    def test_all_fields_round_trip(self):
        profile = Profile("p1", level=12, credits=1690, cosmetics=["a", "b"])
        back = decode(encode(profile))
        self.assertEqual(back, profile)


if __name__ == "__main__":
    unittest.main()