import sqlite3, json
from collections import defaultdict

STEPS = ["install", "tutorial_complete", "first_match", "purchase"]
con = sqlite3.connect("analytics.db")

users = {u: p for u, p in con.execute(
    "select user_id, platform from users where is_test = 0")}

ev = defaultdict(lambda: defaultdict(list))  # user -> step -> [ts]
for u, n, ts in con.execute("select user_id, name, ts from events"):
    if u in users and n in STEPS:          # drop unknown players + non-funnel names
        ev[u][n].append(ts)

funnel = {p: dict.fromkeys(STEPS, 0) for p in set(users.values())}
for u, plat in users.items():
    prev, reached = None, []
    for step in STEPS:
        cands = sorted(t for t in ev[u].get(step, []) if prev is None or t >= prev)
        if not cands:
            break
        prev = cands[0]                    # first valid occurrence
        reached.append(step)
    for step in reached:
        funnel[plat][step] += 1

result = {"funnel": funnel, "biggest_drop": {}}
for plat, f in funnel.items():
    worst, worst_conv = None, None
    for a, b in zip(STEPS, STEPS[1:]):
        conv = f[b] / f[a] if f[a] else float("nan")
        if worst_conv is None or conv < worst_conv:
            worst, worst_conv = b, conv
    result["biggest_drop"][plat] = worst
    print(plat, f, {f"{a}->{b}": round(f[b]/f[a], 4) if f[a] else None
                    for a, b in zip(STEPS, STEPS[1:])})

json.dump(result, open("result.json", "w"), indent=2)
print(json.dumps(result))
