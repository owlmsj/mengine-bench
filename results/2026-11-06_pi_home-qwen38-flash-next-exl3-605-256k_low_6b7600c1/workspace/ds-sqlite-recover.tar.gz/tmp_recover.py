import json, struct

d = open('prices.db','rb').read()
print('file size', len(d))
ptype = d[0]
cell_count = struct.unpack('>H', d[3:5])[0]
content_start = struct.unpack('>H', d[5:7])[0]
frag = d[7]
ptrs = [struct.unpack('>H', d[8+2*i:10+2*i])[0] for i in range(cell_count)]
print('page type', hex(ptype), 'cells', cell_count, 'content_start', content_start, 'frag', frag)
print('ptrs', ptrs)

def varint(b, i):
    v = 0
    for k in range(9):
        c = b[i+k]
        if k == 8: v = (v<<8)|c; return v, i+9
        v = (v<<7)|(c&0x7f)
        if not c & 0x80: return v, i+1+k
    raise ValueError

def serial_len(t):
    if t == 0: return 0
    if t <= 4: return t-1 if t else 0
    if t == 5: return 6
    if t == 6: return 8
    if t == 7: return 8
    if t in (8,9): return 0
    if t >= 12 and t % 2 == 0: return (t-12)//2
    return (t-13)//2

rows = []
for p in ptrs:
    try:
        plen, i = varint(d, p)
        rowid, i = varint(d, i)
        hdr_start = i
        hlen, i = varint(d, i)
        types = []
        while i < hdr_start + hlen:
            t, i = varint(d, i)
            types.append(t)
        body = hdr_start + hlen
        vals = []
        ok = True
        for t in types:
            n = serial_len(t)
            if body + n > len(d):
                ok = False
                break
            raw = d[body:body+n]
            if t == 0: v = None
            elif t == 8: v = 0
            elif t == 9: v = 1
            elif t in (1,2,3,4,5,6): v = int.from_bytes(raw,'big',signed=True)
            elif t == 7: v = struct.unpack('>d', raw)[0]
            elif t >= 13 and t % 2 == 1: v = raw.decode('utf-8')
            else: v = raw
            vals.append(v)
            body += n
        print(f'ptr={p} rowid={rowid} plen={plen} types={types} vals={vals} complete={ok and body==hdr_start+hlen+plen}')
        if ok: rows.append((rowid, vals))
    except Exception as e:
        print('ptr', p, 'FAILED', e)

rows.sort()
out = []
for rowid, vals in rows:
    item = next((v for v in vals if isinstance(v, str)), None)
    price = next((v for v in vals if isinstance(v, (int, float))), None)
    if item is None or price is None: continue
    out.append({'item': item, 'price': price})
json.dump(out, open('recovered.json','w'), indent=2, ensure_ascii=False)
print(json.dumps(out, ensure_ascii=False))
