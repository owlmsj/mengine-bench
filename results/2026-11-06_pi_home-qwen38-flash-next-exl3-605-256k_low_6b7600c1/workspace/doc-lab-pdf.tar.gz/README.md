# Lab history merge (exams/laudo_alfa.pdf + exams/resultado_beta.pdf)

## Order / units
First report = earliest collection = Laboratorio Alfa, coleta 10/02/2026.
Second = Beta Diagnosticos, coleta 18/08/2026. All values in result.json are in
Alfa's units: glucose mg/dL, LDL mg/dL, creatinine mg/dL, HbA1c %.

## Conversions applied to Beta (standard clinical factors)
| Marker | Beta (as printed) | Factor | Converted |
|---|---|---|---|
| Glicose em jejum | 6.1 mmol/L | x18.0182 | 109.9 mg/dL |
| Colesterol LDL | 3.70 mmol/L | x38.67 | 143.1 mg/dL |
| Creatinina | 76 umol/L | /88.42 | 0.86 mg/dL |
| Hemoglobina glicada | 37 mmol/mol (IFCC) | NGSP = 0.09148*IFCC + 2.152 | 5.54 % |

Conversion cross-check: converting Beta's own reference ranges with the same
factors reproduces Alfa's ranges, which validates both the factors and the
marker matching:
- glucose 3.9-5.5 mmol/L -> 70.3-99.1 vs Alfa 70-99 mg/dL
- creatinine 62-115 umol/L -> 0.70-1.30 vs Alfa 0.70-1.30 mg/dL
- HbA1c 20-38 mmol/mol -> 3.98-5.63 vs Alfa 4.0-5.6 %
- LDL <3.4 mmol/L -> <131.5 vs Alfa "<130 mg/dL"

## Trend vs Alfa reference range
| Marker | 2026-02-10 | 2026-08-18 | Alfa range | Direction | Outside range now |
|---|---|---|---|---|---|
| Glicose em jejum | 92 | 109.9 | 70-99 | up = worse | yes (high) |
| Colesterol LDL | 118 | 143.1 | <130 desirable | up = worse | yes (high) |
| Creatinina | 0.95 | 0.86 | 0.70-1.30 | down = better | no |
| Hemoglobina glicada | 5.4 | 5.54 | 4.0-5.6 | up = worse | no (still in range) |

`worse` = got worse AND now outside Alfa's reference range => glucose, LDL.
HbA1c drifted up (5.4 -> 5.54) but stays inside 4.0-5.6, so it is excluded.

## Assumptions
- "First report" = earlier collection date, not file order.
- Same patient identity assumed (name/patient id match: "Teste Sintetico 0042").
- Marker names normalised to Alfa's wording and capitalisation.
- "Worse" = clinically deteriorating direction (higher for glucose/LDL/HbA1c,
  lower or higher for creatinine only if outside range), judged against Alfa's
  reference range as the brief requires.
- Beta HbA1c is IFCC mmol/mol (stated "HPLC (IFCC)"), converted with the
  master NGSP equation; rounded to 2 decimals, others to 1-2 significant decimals.
- Dates are ISO YYYY-MM-DD from the collection date (not Beta's emission date).