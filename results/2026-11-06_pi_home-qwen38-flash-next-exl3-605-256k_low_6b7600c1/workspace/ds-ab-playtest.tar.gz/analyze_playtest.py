"""Pixel Arena tutorial A/B: clean the arena-panel export and test the release rule.

Release rule (telemetry/README.md): ship a variant only if its completion gain is
significant at the 5% level. Export quirks handled here: ETL resends rows (dedupe on
session_id), `variant` may be lowercase or space-padded.
"""
import csv, math, random, statistics, collections, json

SRC = "telemetry/playtest_ab.csv"
OUT = "result.json"
SEED = 7


def load_sessions(path=SRC):
    """session_id-keyed sessions, variant normalised; exact duplicate rows collapsed."""
    sessions, dup_rows, raw_rows, conflicts = {}, 0, 0, 0
    for r in csv.DictReader(open(path, newline="", encoding="utf-8-sig")):
        raw_rows += 1
        sid = r["session_id"].strip()
        rec = {
            "variant": r["variant"].strip().lower(),
            "player": r["player_id"].strip(),
            "done": int(r["completed_tutorial"]),
        }
        if sid in sessions:
            dup_rows += 1
            if sessions[sid] != rec:
                conflicts += 1
                print(f"WARN session {sid} resent with conflicting fields: {sessions[sid]} vs {rec}")
            continue
        sessions[sid] = rec
    return sessions, dup_rows, raw_rows, conflicts


def two_proportion_test(ka, na, kb, nb):
    pooled = (ka + kb) / (na + nb)
    z = (kb / nb - ka / na) / math.sqrt(pooled * (1 - pooled) * (1 / na + 1 / nb))
    return z, math.erfc(abs(z) / math.sqrt(2))


def fisher_exact(ka, na, kb, nb):
    """Two-sided Fisher exact by direct hypergeometric summation."""
    k_total, n_total = ka + kb, na + nb
    pmf = lambda x: math.comb(na, x) * math.comb(nb, k_total - x) / math.comb(n_total, k_total)
    p_obs = pmf(ka)
    return sum(pmf(x) for x in range(max(0, k_total - nb), min(na, k_total) + 1) if pmf(x) <= p_obs * (1 + 1e-9))


def wilson(k, n, z=1.96):
    p, d = k / n, 1 + z * z / n
    c, h = (p + z * z / (2 * n)) / d, z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return round(c - h, 4), round(c + h, 4)


def player_bootstrap(sessions, draws=20000, seed=SEED):
    """Resample PLAYERS, not sessions: 366/763 players appear in both arms, so sessions
    are clustered and the naive interval is optimistic."""
    by_player = collections.defaultdict(list)
    for s in sessions.values():
        by_player[s["player"]].append(s)
    players = list(by_player)
    rng = random.Random(seed)
    diffs = []
    for _ in range(draws):
        sample = [by_player[rng.choice(players)] for _ in players]
        a = [s for g in sample for s in g if s["variant"] == "a"]
        b = [s for g in sample for s in g if s["variant"] == "b"]
        diffs.append(sum(s["done"] for s in b) / len(b) - sum(s["done"] for s in a) / len(a))
    diffs.sort()
    p_two = 2 * min(sum(1 for x in diffs if x <= 0), sum(1 for x in diffs if x >= 0)) / len(diffs)
    return round(diffs[int(0.025 * len(diffs))], 4), round(diffs[int(0.975 * len(diffs))], 4), round(min(p_two, 1.0), 4)


def within_player_test(sessions):
    """Paired check on players who saw both arms: removes any player-composition confound."""
    by_player = collections.defaultdict(list)
    for s in sessions.values():
        by_player[s["player"]].append(s)
    diffs = []
    for group in by_player.values():
        a = [s["done"] for s in group if s["variant"] == "a"]
        b = [s["done"] for s in group if s["variant"] == "b"]
        if a and b:
            diffs.append(sum(b) / len(b) - sum(a) / len(a))
    m = statistics.mean(diffs)
    se = statistics.stdev(diffs) / math.sqrt(len(diffs))
    t = m / se
    return len(diffs), round(m, 4), round(t, 3), round(math.erfc(abs(t) / math.sqrt(2)), 5)


def _groups_by_player(sessions):
    by_player = collections.defaultdict(list)
    for s in sessions.values():
        by_player[s["player"]].append(s)
    return by_player


def main():
    sessions, dup_rows, raw_rows, conflicts = load_sessions()
    a = [s for s in sessions.values() if s["variant"] == "a"]
    b = [s for s in sessions.values() if s["variant"] == "b"]
    ka, na, kb, nb = sum(s["done"] for s in a), len(a), sum(s["done"] for s in b), len(b)
    ra, rb = ka / na, kb / nb
    z, p_naive = two_proportion_test(ka, na, kb, nb)
    p_fisher = fisher_exact(ka, na, kb, nb)
    ci_lo, ci_hi, p_cluster = player_bootstrap(sessions)
    n_paired, paired_mean, paired_t, p_paired = within_player_test(sessions)
    result = {
        "ship_b": p_cluster < 0.05,
        "sessions_a": na,
        "sessions_b": nb,
        "completion_rate_a": round(ra, 4),
        "completion_rate_b": round(rb, 4),
        "p_value": p_cluster,
        "decision_rule": "ship B only if player-clustered two-sided p < 0.05 (telemetry/README.md release rule)",
        "effect": {
            "uplift_pp": round(100 * (rb - ra), 2),
            "uplift_ci95_pp": [round(100 * ci_lo, 2), round(100 * ci_hi, 2)],
            "completion_ci95_a": wilson(ka, na),
            "completion_ci95_b": wilson(kb, nb),
        },
        "tests": {
            "player_cluster_bootstrap": {"p_value": p_cluster, "ci95_diff": [ci_lo, ci_hi], "draws": 20000, "unit": "player"},
            "two_proportion_z": {"z": round(z, 3), "p_value": round(p_naive, 5), "unit": "session"},
            "fisher_exact": {"p_value": round(p_fisher, 5), "unit": "session"},
            "within_player_paired": {"n_players": n_paired, "mean_diff": paired_mean, "t": paired_t, "p_value": p_paired},
        },
        "data_quality": {
            "raw_rows": raw_rows,
            "duplicate_resend_rows_dropped": dup_rows,
            "unique_sessions": len(sessions),
            "unique_players": len({s["player"] for s in sessions.values()}),
            "players_in_both_arms": sum(
                1 for g in _groups_by_player(sessions).values() if len({s["variant"] for s in g}) > 1
            ),
            "variant_labels_normalised": ["' A'/'a' -> 'a'", "' B'/'b' -> 'b'"],
            "conflicting_resends": conflicts,
            "assignment_balance": {"a": na, "b": nb},
        },
        "assumptions": [
            "session_id is the unit of analysis; repeated rows are ETL resends of the same session and are collapsed (all 70 were byte-identical).",
            "variant is compared after strip+lowercase; no other values exist.",
            "completed_tutorial is the ship metric named by the release rule; match_minutes is reported context only.",
            "p_value reported is the conservative player-clustered bootstrap, because 366 of 763 players appear in both arms; the session-level tests are shown for cross-check.",
        ],
    }
    json.dump(result, open(OUT, "w"), indent=2)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()