from PIL import Image, ImageDraw, ImageFont
W,H=1200,675
img=Image.new("RGB",(W,H))
px=img.load()
top=(16,42,74); bot=(232,120,68)
for y in range(H):
    t=y/(H-1)
    r=int(top[0]+(bot[0]-top[0])*t**1.6); g=int(top[1]+(bot[1]-top[1])*t**1.6); b=int(top[2]+(bot[2]-top[2])*t**1.6)
    for x in range(W): px[x,y]=(r,g,b)
d=ImageDraw.Draw(img,"RGBA")
# sun
d.ellipse([860,120,1030,290], fill=(255,214,140,255))
# water band
d.rectangle([0,470,W,H], fill=(12,32,58,255))
for i in range(28):
    y=480+i*7
    w=200+((i*97)%500)
    x=(i*173)%900
    d.rectangle([x,y,x+w,y+2], fill=(255,190,120,70))
# distant hills
d.polygon([(0,470),(220,380),(430,470)], fill=(24,52,78,255))
d.polygon([(300,470),(560,350),(820,470)], fill=(18,42,66,255))
# lighthouse
d.polygon([(150,470),(186,470),(178,300),(158,300)], fill=(245,245,240,255))
for i in range(3):
    y=320+i*50
    d.rectangle([152,y,184,y+16], fill=(196,60,52,255))
d.rectangle([154,278,182,300], fill=(60,66,72,255))
d.polygon([(150,278),(186,278),(168,258)], fill=(196,60,52,255))
# sailboat
d.polygon([(640,500),(760,500),(735,540),(665,540)], fill=(20,26,34,255))
d.polygon([(700,500),(700,395),(745,500)], fill=(250,250,248,255))
# title plate for legibility
d.rounded_rectangle([90,120,1110,330], radius=26, fill=(8,22,40,215))
def font(sz, bold=True):
    for p in ([r"C:\Windows\Fonts\arialbd.ttf"] if bold else [])+[r"C:\Windows\Fonts\arial.ttf", r"C:\Windows\Fonts\segoeuib.ttf"]:
        try: return ImageFont.truetype(p, sz)
        except OSError: pass
    return ImageFont.load_default()
f=font(112); s=font(34, bold=False)
tb=d.textbbox((0,0),"Harbor Day 2026",font=f)
tw,tb_h=tb[2]-tb[0],tb[3]-tb[1]
d.text((600-tw/2-tb[0], 225-tb_h/2-tb[1]),"Harbor Day 2026",font=f,fill=(255,255,255,255))
sub="Harbour front \u2022 Sat 15 Aug 2026 \u2022 Bluehaze CC"
sb=d.textbbox((0,0),sub,font=s)
d.text((600-(sb[2]-sb[0])/2-sb[0], 352),sub,font=s,fill=(235,242,250,255))
img.save("cover.png")
print(img.size, img.mode)
