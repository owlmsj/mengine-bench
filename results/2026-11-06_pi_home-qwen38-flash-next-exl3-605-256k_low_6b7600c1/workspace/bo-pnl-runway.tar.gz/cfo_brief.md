# CFO brief - H1 2026 close (board meeting)

Currency: BRL (R$). Source: `finance/ledger.csv` (86 postings, 2026-01..2026-06),
mapped by `finance/chart_of_accounts.csv`; cash from `finance/cash_balance.txt`;
burn/runway rule from `finance/README.md` (board's note).

## Headline

| Metric | Value |
|---|---|
| H1 revenue (net of refunds) | R$ 1,389,492.82 |
| H1 EBITDA | R$ -1,218,969.18 |
| June gross margin | 72.4% (H1 range 68.5% - 72.4%) |
| Burn (board rule: avg monthly negative EBITDA, Apr-Jun) | R$ 197,288.23 / month |
| Closing cash 30/06/2026 | R$ 1,847,350.40 |
| **Runway** | **9.36 months -> cash out ~early April 2027** |

## Monthly P&L (accrual, from ledger)

| Month | Revenue | COGS | Gross profit | GM% | S&M | R&D | G&A | EBITDA |
|---|---|---|---|---|---|---|---|---|
| 2026-01 | 200,510.87 | -60,091.92 | 140,418.95 | 70.03% | -143,475.23 | -163,396.33 | -43,826.35 | -210,278.96 |
| 2026-02 | 216,328.06 | -64,278.71 | 152,049.35 | 70.29% | -138,161.28 | -182,271.02 | -43,917.13 | -212,300.08 |
| 2026-03 | 219,066.17 | -69,096.05 | 149,970.12 | 68.46% | -135,519.34 | -171,742.87 | -47,233.36 | -204,525.45 |
| 2026-04 | 238,163.26 | -70,867.73 | 167,295.53 | 70.24% | -139,688.11 | -179,804.44 | -44,753.63 | -196,950.65 |
| 2026-05 | 243,032.89 | -73,973.13 | 169,059.76 | 69.56% | -138,680.10 | -185,905.30 | -46,420.18 | -201,945.82 |
| 2026-06 | 272,391.57 | -75,162.69 | 197,228.88 | 72.41% | -151,896.54 | -189,990.01 | -48,310.55 | -192,968.22 |

Financial results (account 6.x: investment income, interest/IOF) are excluded from
EBITDA by definition; they add R$ 6.5k-7.0k per month and are shown in
`pnl_2026_h1.csv` as the `net` line.

## How each month went

- **Jan** R$200.5k revenue, EBITDA -R$210.3k. Baseline; opex (R$350.7k) is 1.75x revenue.
- **Feb** Best GM of Q1 so far (70.3%) but highest EBITDA loss of H1 (-R$212.3k) as R&D jumped +R$18.9k.
- **Mar** Weakest month: GM fell to 68.5% (cloud + support up, refunds R$6.8k customer Kestrel) and revenue growth stalled at +1.3%.
- **Apr** Turnaround starts: revenue +8.7%, GM back to 70.2%, EBITDA loss narrows to -R$197.0k (best of H1).
- **May** Revenue +2.0%, GM 69.6%, second Kestrel refund (R$8.6k); loss widens slightly to -R$201.9k on R&D.
- **Jun** Strongest month of H1: revenue R$272.4k (+12.1% MoM), GM 72.4% (H1 high), smallest loss -R$193.0k.

Trend: revenue +35.8% Jan->Jun (6.3%/month), gross margin +2.4 pts, EBITDA loss
-8.2% since Jan. Loss is flat while revenue grows because opex is sticky:
Jun opex R$390.2k vs Jan R$350.7k (+11.3%) against +35.8% revenue.

## Burn and runway

- Board rule: burn = average monthly negative EBITDA of last three closed months
  (Apr, May, Jun) = (196,950.65 + 201,945.82 + 192,968.22) / 3 = **R$ 197,288.23**.
- Runway = latest closing cash / burn = 1,847,350.40 / 197,288.23 = **9.36 months**
  (cash out around the first week of April 2027).
- All six months have negative EBITDA, so no zero/positive month distorts the average.

## Caveats to raise before investors do

1. **Cash burn is running hotter than EBITDA burn.** Bank balance fell
   R$461,837.60 from 31/05 to 30/06, ~2.4x June EBITDA loss (-R$192,968.22).
   At that cash rate runway is ~4.0 months, not 9.4. The ledger has no capex,
   tax, payroll-tax or working-capital lines, so the gap is unexplained by these
   books. Recommend reconciling the June bank movement before the meeting; the
   9.36 month figure is only as safe as that reconciliation.
2. **Only two cash balances are provided** (31/05, 30/06); no opening cash, so
   H1 cash burn cannot be verified from the ledger.
3. **Refund concentration**: account 3.1.09 has two refunds, both "customer
   Kestrel" (Mar R$6,814.15, May R$8,634.37 = R$15,448.52, 1.1% of H1 revenue).
   Churn on one account is already visible in the numbers.
4. **June is the best month and the last data point.** One month is not a trend;
   the flat EBITDA line is the honest story.

## Assumptions made (brief left these open)

- Dates parsed as DD/MM/YYYY (Brazilian format, R$ amounts with comma decimals).
- Revenue is **net** of refunds: 3.1.09 is mapped to `revenue` in the chart of accounts.
- Gross margin = (revenue + COGS) / revenue, using only accounts 4.1.01/4.1.02 as COGS.
- EBITDA = revenue + COGS + S&M + R&D + G&A; account 6.x (financial) excluded.
  No D&A or interest lines exist in the ledger, so EBITDA ~= operating result.
- "Last three closed months" = Apr/May/Jun 2026, since a 30/06 cash balance exists.
- Amounts taken at face value; ledger has no duplicate postings (checked on
  date+account+description+amount) and every month carries 14-15 entries.

Files: `result.json` (key figures), `pnl_2026_h1.csv` (full monthly P&L incl. financial line).