//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// One lock guards every score and the total, so a multi-player operation such
/// as [`Board::transfer`] can never hold two locks at once (deadlock) nor
/// release the lock mid-operation (lost updates under concurrent awards).
#[derive(Default)]
struct Scores {
    players: HashMap<PlayerId, i64>,
    total: i64,
}

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    scores: Arc<Mutex<Scores>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        let mut scores = self.scores.lock().unwrap();
        scores.total += score;
        scores.players.insert(id, score);
    }

    fn score_locked(scores: &Scores, id: PlayerId) -> i64 {
        *scores.players.get(&id).unwrap_or_else(|| {
            panic!("unknown player {id}: expected a PlayerId passed to Board::join")
        })
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let mut scores = self.scores.lock().unwrap();
        let score = Self::score_locked(&scores, id);
        scores.players.insert(id, score + points);
        scores.total += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let mut scores = self.scores.lock().unwrap();
        if from == to {
            return;
        }
        let from_score = Self::score_locked(&scores, from);
        let to_score = Self::score_locked(&scores, to);
        scores.players.insert(from, from_score - points);
        scores.players.insert(to, to_score + points);
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        let scores = self.scores.lock().unwrap();
        Self::score_locked(&scores, id)
    }

    pub fn total(&self) -> i64 {
        self.scores.lock().unwrap().total
    }
}