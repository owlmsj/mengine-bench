use arena_scores::Board;
use std::sync::Arc;
use std::thread;

#[test]
fn concurrent_awards_lose_nothing() {
    let board = Board::new();
    board.join(1, 0);
    let threads: Vec<_> = (0..8)
        .map(|_| {
            let board = board.clone();
            thread::spawn(move || {
                for _ in 0..20_000 {
                    board.award(1, 1);
                }
            })
        })
        .collect();
    for t in threads {
        t.join().unwrap();
    }
    assert_eq!((board.score(1), board.total()), (160_000, 160_000));
}

#[test]
fn self_transfer_does_not_hang() {
    let board = Board::new();
    board.join(7, 5);
    let handle = {
        let board = board.clone();
        thread::spawn(move || board.transfer(7, 7, 3))
    };
    handle.join().unwrap();
    assert_eq!((board.score(7), board.total()), (5, 5));
}

#[test]
fn concurrent_transfers_conserve_the_total() {
    let board = Arc::new(Board::new());
    for id in 0..4 {
        board.join(id, 1_000_000);
    }
    let threads: Vec<_> = (0..8)
        .map(|_| {
            let board = board.clone();
            thread::spawn(move || {
                for i in 0..20_000 {
                    board.transfer(i % 4, (i + 1) % 4, 3);
                    board.award(i % 4, 1);
                }
            })
        })
        .collect();
    for t in threads {
        t.join().unwrap();
    }
    let sum: i64 = (0..4).map(|id| board.score(id)).sum();
    assert_eq!(sum, 4_000_000 + 8 * 20_000);
    assert_eq!(board.total(), sum);
}
