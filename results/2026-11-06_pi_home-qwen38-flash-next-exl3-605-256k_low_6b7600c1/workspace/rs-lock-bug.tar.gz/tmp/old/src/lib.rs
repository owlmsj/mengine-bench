use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self { Self::default() }
    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }
    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        let score = *slot.lock().unwrap();
        *slot.lock().unwrap() = score + points;
        let total = *self.total.lock().unwrap();
        *self.total.lock().unwrap() = total + points;
    }
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let from_slot = self.slot(from);
        let to_slot = self.slot(to);
        let mut from_score = from_slot.lock().unwrap();
        let mut to_score = to_slot.lock().unwrap();
        *from_score -= points;
        *to_score += points;
    }
    pub fn score(&self, id: PlayerId) -> i64 { *self.slot(id).lock().unwrap() }
    pub fn total(&self) -> i64 { *self.total.lock().unwrap() }
}
