
const DATA = {"adj":{"acento":["sílaba","pergunta","fala","sotaque","prazer"],"advogado":["professor","juiz","cachoeira","hora","coração","eternidade","fala","palavra"],"afeto":["amor","carinho","angústia","voz"],"aflição":["angústia","ansiedade","felicidade","escultura","pavor","água"],"aldeia":["vila","bairro","capital","trabalho"],"alegria":["surpresa","felicidade","ternura","queijo"],"alfaiate":["sapateiro","padeiro","boca","emprego","profissão","susto","açougueiro"],"alma":["pé","corpo","amor","dente","gíria","pátria"],"almoço":["refeição","jantar","carne","patrão","pimenta","frase"],"amanhã":["hoje","eternidade","hora","perna","porta"],"amor":["paixão","afeto","susto","tristeza","alma","árvore"],"angústia":["dor","aflição","compaixão","riacho","medo","afeto"],"ano":["século","mês","crepúsculo","música"],"ansiedade":["aflição","medo","rua","paixão","manteiga"],"apelido":["nome","letra","idioma","acento","irmã"],"areia":["praia","natureza","montanha","ofício","rima"],"arroz":["trigo","feijão","chá","madrugada"],"arte":["fotografia","música","samba","cachoeira","romance"],"ator":["cena","poesia","canção","primo"],"aurora":["madrugada","crepúsculo","prazer","instante","professor"],"avenida":["rua","praça","casa","feijão","quarto"],"avó":["avô","neto","mãe","idioma","genro"],"avô":["irmã","avó","pais","coração","semana"],"açougueiro":["padeiro","pescador","tarde","alfaiate","boca"],"açúcar":["manteiga","mel","pimenta","unha","tempo"],"bairro":["aldeia","rua","igreja","porta","refeição"],"boca":["olho","língua","rosto","ombro","alfaiate","açougueiro","livro"],"braço":["ombro","mão","surpresa","língua","janela"],"cabeça":["corpo","rosto","mão","enfermeira"],"cachoeira":["riacho","lago","pétala","semente","advogado","linguagem"],"café":["pimenta","chá","momento","água","trabalho"],"campo":["jardim","prado","selva","onda","ponte","milho"],"canção":["música","melodia","tela","pai","cena","ator","idioma"],"capital":["cidade","vila","estação","riacho","aldeia","voz","tempo"],"carinho":["afeto","ternura","melancolia","compaixão","saudade","esperança"],"carne":["mandioca","peixe","filho","arroz","nação","ovo","salário"],"carpinteiro":["pedreiro","ferreiro","trabalho","patrão","vila"],"casa":["escola","lar","avenida","igreja","poesia"],"cena":["teatro","ator","melodia","canção","ponte","livro"],"chá":["café","vinho","peixe","queijo","dente"],"cidade":["estado","capital","prima","estação","jardim"],"cinema":["escultura","fotografia","tela","pergunta"],"comida":["água","refeição","peito","farinha","história"],"compaixão":["ternura","esperança","angústia","carinho","contentamento","sílaba","ovo"],"contentamento":["felicidade","prazer","pais"],"conto":["romance","livro","folha","lar","verso","herança","palavra"],"conversa":["fala","silêncio","grito","felicidade"],"coração":["peito","pulmão","avô","rosto","advogado","joelho","jantar"],"corpo":["alma","cabeça","peixe","pescoço"],"cozinha":["quarto","janela","pai","fígado","capital","voz"],"crepúsculo":["aurora","ontem","cunhado","segundo","ano","época","gíria","hoje"],"cunhado":["sobrinho","sogra","pais","crepúsculo"],"dança":["tambor","teatro","piano","rima","voz","desenho"],"dedo":["mão","unha","pé","sapateiro"],"dente":["língua","pescoço","pulmão","hoje"],"desenho":["tela","escultura","noite","dança","prima"],"dia":["semana","manhã","tarde","casa","letra"],"dicionário":["significado","sinônimo","voz","arte"],"dor":["mágoa","angústia","saudade","almoço"],"emprego":["profissão","salário","esperança","eternidade","mercado","alfaiate","jantar"],"enfermeira":["médico","professor","época","açougueiro","violão"],"engenheiro":["marinheiro","trabalho","irmão","juiz","lavrador","ternura"],"era":["época","século","mês","teatro","palavra"],"escola":["igreja","casa","esquina","esperança"],"escultura":["desenho","cinema","jardim","olho","violão","sobrinho"],"espanto":["susto","surpresa","esperança","país"],"esperança":["compaixão","saudade","nostalgia","espanto","carinho","emprego","escola"],"esquina":["praça","ponte","cozinha","pescador","escola"],"estado":["pátria","cidade","mão","praça","médico","poesia"],"estação":["porto","mercado","tia","cidade","capital","susto"],"estômago":["pulmão","fígado","língua","irmão"],"eternidade":["amanhã","passado","instante","madrugada","emprego","peixe","advogado"],"fala":["voz","conversa","acento","advogado"],"família":["herança","parentesco","nora","susto"],"farinha":["pão","trigo","vinho","pescador"],"feijão":["arroz","milho","avenida","mandioca","vinho","palavra"],"felicidade":["alegria","contentamento","aflição","compaixão","trigo","conversa"],"ferreiro":["carpinteiro","sapateiro","segundo","pastor","onda"],"filha":["filho","irmão","parentesco","tia","manteiga","primo","nora"],"filho":["pai","filha","genro","carne"],"flor":["folha","pétala","mar","samba","semente"],"floresta":["natureza","mata","mar","medo","tempo"],"folha":["raiz","flor","tio","semente","conto","silêncio"],"fotografia":["cinema","arte","soldado","rima","teatro","refeição"],"frase":["linguagem","sentido","tristeza","letra","almoço","gíria","sussurro"],"fruto":["semente","jardim","natureza","piano"],"futuro":["passado","tempo","minuto","século","fígado"],"fígado":["estômago","pele","futuro","alma","cozinha"],"genro":["sogra","nora","madrinha","avó"],"grito":["silêncio","sussurro","conversa","sobrinho","pergunta"],"gíria":["sinônimo","sotaque","crepúsculo","alma","frase","idioma"],"herança":["madrinha","família","tio","neta","sinônimo","pimenta","marinheiro","conto"],"história":["resposta","memória","comida","apelido","surpresa","tempo"],"hoje":["ontem","amanhã","crepúsculo","tristeza","dente"],"hora":["tempo","minuto","época","advogado"],"idioma":["palavra","linguagem","madrinha","apelido","canção","gíria"],"igreja":["mercado","escola","bairro","operário"],"instante":["segundo","momento","eternidade","almoço","aurora"],"irmã":["irmão","avô","tia","pintura","sal","apelido"],"irmão":["filha","irmã","pais","tia","engenheiro","ponte"],"janela":["cozinha","porta","braço","igreja","nação","profissão"],"jantar":["almoço","pão","mel","coração","emprego"],"jardim":["fruto","campo","pétala","escultura","montanha","praia"],"joelho":["perna","pé","coração","pedreiro","tambor"],"juiz":["advogado","soldado","porto","patrão","engenheiro","mão"],"lago":["cachoeira","mar","natureza","acento"],"lar":["casa","quarto","rua","ponte","praça","conto"],"lavrador":["pescador","pastor","padeiro","ofício","selva","engenheiro"],"leite":["queijo","manteiga","pele","pão","mandioca","época"],"letra":["apelido","sílaba","significado","dia"],"linguagem":["idioma","frase","riacho","grito","cachoeira"],"livro":["conto","pintura","cena","boca"],"língua":["boca","dente","osso","tarde"],"madrinha":["padrinho","herança","genro","neta","idioma"],"madrugada":["noite","aurora","manhã","nome","eternidade","passado","vila","arroz","médico"],"mandioca":["milho","carne","feijão","pimenta","árvore","leite","sentido"],"manhã":["dia","tarde","ano","profissão"],"manteiga":["leite","açúcar","milho","queijo","almoço","ansiedade"],"mar":["lago","onda","flor","vale","medo"],"marinheiro":["soldado","engenheiro","pedreiro","médico","advogado","herança"],"mata":["floresta","selva","fruto","mercado","árvore"],"medo":["ansiedade","pavor","angústia","ternura"],"mel":["açúcar","sal","jantar","pimenta","melancolia"],"melancolia":["nostalgia","tristeza","carinho","médico","mágoa"],"melodia":["canção","ritmo","piano","cena","verso"],"memória":["história","palavra","sílaba","alma"],"mercado":["estação","igreja","mata","porta","emprego"],"milho":["feijão","mandioca","refeição","trigo","manteiga","campo","tela"],"minuto":["hora","segundo","futuro","tambor","noite"],"momento":["instante","época","noite","café"],"montanha":["prado","serra","jardim","lavrador","areia"],"mágoa":["tristeza","dor","melancolia","nostalgia"],"mãe":["pais","pai","neto","cena","avó"],"mão":["braço","dedo","pele","estado"],"médico":["pastor","enfermeira","estado","marinheiro","madrugada"],"mês":["ano","semana","era","momento","ferreiro","sinônimo"],"música":["arte","canção","ano","verso","nora","samba","pintura"],"natureza":["areia","floresta","raiz","romance"],"nação":["país","pátria","rua","instante","vila"],"neta":["neto","tio","pais","arroz","madrinha","quarto"],"neto":["avó","neta","mãe","filho","romance","sílaba"],"noite":["tarde","madrugada","momento","minuto","desenho"],"nome":["sussurro","apelido","madrugada","voz","ritmo"],"nora":["genro","padrinho","família","filha","peixe","patrão","música"],"nostalgia":["saudade","melancolia","esperança","sílaba","mágoa"],"ofício":["trabalho","profissão","areia","padeiro","livro","lavrador"],"olho":["rosto","boca","pulmão","escultura"],"ombro":["pescoço","braço","boca","água"],"onda":["mar","praia","campo","riacho","prado","ferreiro","tempo"],"ontem":["crepúsculo","hoje","pavor"],"operário":["patrão","pedreiro","passado","profissão","lavrador","igreja","soldado"],"osso":["pele","sangue","língua","pescoço","farinha"],"ovo":["peixe","queijo","carne","compaixão","palavra"],"padeiro":["alfaiate","açougueiro","ofício","lavrador","capital"],"padrinho":["nora","madrinha","tio","sotaque"],"pai":["mãe","filho","avó","cozinha","canção"],"pais":["parentesco","mãe","contentamento","irmão","pavor","neta","tia"],"paixão":["prazer","amor","ansiedade","conto","unha"],"palavra":["memória","idioma","mágoa","professor","cabeça","tia","patrão","dedo","era","advogado","conto","ovo","alma","montanha","pintura","feijão"],"parentesco":["família","pais","filha","médico"],"passado":["eternidade","futuro","madrugada","operário"],"pastor":["lavrador","médico","ferreiro","profissão","mel"],"patrão":["salário","operário","almoço","juiz","nora","carpinteiro","palavra"],"pavor":["medo","susto","melancolia","aflição","pais","ontem","ritmo"],"país":["porta","nação","espanto","cidade","violão"],"pedreiro":["operário","carpinteiro","joelho","marinheiro","osso"],"peito":["unha","coração","pulmão","comida"],"peixe":["carne","ovo","nora","chá","eternidade"],"pele":["fígado","osso","mão","pulmão","leite"],"pergunta":["acento","resposta","grito","olho"],"perna":["sangue","joelho","amanhã"],"pescador":["açougueiro","lavrador","pedreiro","amanhã","verso"],"pescoço":["dente","ombro","corpo","avô","sangue"],"piano":["violão","tambor","sobrinho","fruto","melodia","dança","prado"],"pimenta":["sal","café","mandioca","açúcar","mel","almoço","herança"],"pintura":["livro","tela","irmã","música","janela","palavra"],"poesia":["ator","verso","casa","violão","estado"],"ponte":["esquina","porto","campo","vale","lar","irmão"],"porta":["janela","país","bairro","amanhã"],"porto":["ponte","estação","pátria","vila","juiz"],"prado":["campo","montanha","carinho","onda","piano"],"praia":["onda","areia","rio","jardim","pescador"],"prazer":["contentamento","paixão","ternura","aurora","acento"],"praça":["avenida","esquina","ternura","pátria","vale","lar"],"prima":["primo","sobrinho","herança","cidade"],"primo":["tia","prima","filha","professor","sobrinho","ator"],"professor":["enfermeira","advogado","primo","salário","sapateiro","água","palavra"],"profissão":["ofício","emprego","serra","operário","janela","alfaiate"],"pulmão":["coração","estômago","olho","unha","peito","pescoço","avô","pele"],"pátria":["nação","estado","porto","alma","praça","tempo"],"pão":["jantar","farinha","leite","verso"],"pé":["joelho","alma","rosto","tela"],"pétala":["flor","semente","susto","cachoeira","mar"],"quarto":["lar","cozinha","avenida","neta"],"queijo":["ovo","leite","alegria","manteiga","poesia","chá"],"raiz":["árvore","folha","natureza","serra","vale"],"refeição":["comida","almoço","milho","bairro","água","fotografia"],"resposta":["pergunta","história","letra","semana"],"riacho":["rio","cachoeira","angústia","onda","linguagem","capital"],"rima":["verso","romance","violão","fotografia","areia","significado"],"rio":["vale","riacho","praia","pedreiro"],"ritmo":["melodia","samba","teatro","pavor","nome"],"romance":["rima","conto","natureza","teatro","arte","sotaque"],"rosto":["cabeça","olho","boca","nora","pé"],"rua":["bairro","avenida","nação","lar","alfaiate"],"sal":["mel","pimenta","irmã"],"salário":["emprego","patrão","professor","carne"],"samba":["ritmo","violão","flor","arte","romance","música"],"sangue":["osso","perna","pescoço","sentido"],"sapateiro":["ferreiro","alfaiate","dedo","professor"],"saudade":["esperança","nostalgia","ansiedade","dor","carinho"],"segundo":["minuto","instante","crepúsculo","ferreiro"],"selva":["mata","árvore","campo","igreja"],"semana":["mês","dia","futuro","avô"],"semente":["pétala","fruto","folha","flor","mercado","cachoeira"],"sentido":["frase","significado","sangue","trabalho","história","mandioca"],"serra":["montanha","vale","árvore","profissão"],"significado":["sentido","dicionário","rima","letra"],"silêncio":["conversa","grito","sussurro","folha"],"sinônimo":["dicionário","gíria","herança","sílaba","mês"],"sobrinho":["prima","cunhado","primo","piano","sotaque","grito"],"sogra":["cunhado","genro","tia","dente","tempo"],"soldado":["juiz","marinheiro","operário","fotografia"],"sotaque":["gíria","voz","vinho","sobrinho","acento"],"surpresa":["espanto","alegria","braço","história"],"sussurro":["grito","nome","silêncio","frase","folha"],"susto":["pavor","espanto","amor","pétala","estação","alfaiate","tempo"],"século":["era","ano","minuto"],"sílaba":["letra","acento","nostalgia","compaixão","frase","neto","memória"],"tambor":["piano","dança","minuto","verso","joelho"],"tarde":["manhã","noite","dia","açougueiro","língua"],"teatro":["dança","cena","era","ritmo","romance","pai","fotografia","tempo"],"tela":["pintura","desenho","pé","cinema","milho"],"tempo":["futuro","hora","rua","açúcar","tio","história","pátria","susto","idioma","capital","onda","teatro","floresta","pescador","prado","sogra"],"ternura":["carinho","compaixão","alegria","medo","praça","engenheiro"],"tia":["tio","primo","filha","irmão","pais","estação","sogra"],"tio":["neta","tia","herança","folha","tempo"],"trabalho":["engenheiro","ofício","aldeia","carpinteiro","sentido"],"trigo":["farinha","arroz","milho","unha"],"tristeza":["melancolia","mágoa","amor","frase","hoje"],"unha":["dedo","peito","pulmão","paixão","trigo","açúcar"],"vale":["serra","rio","raiz","mar","ponte"],"verso":["poesia","rima","pão","tambor","melodia","pescador"],"vila":["capital","aldeia","nação","madrugada","porto","carpinteiro"],"vinho":["chá","água","farinha","feijão","sotaque"],"violão":["samba","piano","país","enfermeira","rima","praça","poesia","escultura"],"voz":["sotaque","fala","afeto","cozinha","nome","capital"],"água":["vinho","comida","ombro","café","refeição","aflição","professor"],"árvore":["selva","raiz","mata","amor","serra","mandioca"],"época":["momento","era","enfermeira","leite"]},"themes":{"acento":"linguagem","advogado":"ofícios","afeto":"sentimentos","aflição":"sentimentos","aldeia":"lugares","alegria":"sentimentos","alfaiate":"ofícios","alma":"corpo","almoço":"comida","amanhã":"tempo","amor":"sentimentos","angústia":"sentimentos","ano":"tempo","ansiedade":"sentimentos","apelido":"linguagem","areia":"natureza","arroz":"comida","arte":"artes","ator":"artes","aurora":"tempo","avenida":"lugares","avó":"família","avô":"família","açougueiro":"ofícios","açúcar":"comida","bairro":"lugares","boca":"corpo","braço":"corpo","cabeça":"corpo","cachoeira":"natureza","café":"comida","campo":"natureza","canção":"artes","capital":"lugares","carinho":"sentimentos","carne":"comida","carpinteiro":"ofícios","casa":"lugares","cena":"artes","chá":"comida","cidade":"lugares","cinema":"artes","comida":"comida","compaixão":"sentimentos","contentamento":"sentimentos","conto":"artes","conversa":"linguagem","coração":"corpo","corpo":"corpo","cozinha":"lugares","crepúsculo":"tempo","cunhado":"família","dança":"artes","dedo":"corpo","dente":"corpo","desenho":"artes","dia":"tempo","dicionário":"linguagem","dor":"sentimentos","emprego":"ofícios","enfermeira":"ofícios","engenheiro":"ofícios","era":"tempo","escola":"lugares","escultura":"artes","espanto":"sentimentos","esperança":"sentimentos","esquina":"lugares","estado":"lugares","estação":"lugares","estômago":"corpo","eternidade":"tempo","fala":"linguagem","família":"família","farinha":"comida","feijão":"comida","felicidade":"sentimentos","ferreiro":"ofícios","filha":"família","filho":"família","flor":"natureza","floresta":"natureza","folha":"natureza","fotografia":"artes","frase":"linguagem","fruto":"natureza","futuro":"tempo","fígado":"corpo","genro":"família","grito":"linguagem","gíria":"linguagem","herança":"família","história":"linguagem","hoje":"tempo","hora":"tempo","idioma":"linguagem","igreja":"lugares","instante":"tempo","irmã":"família","irmão":"família","janela":"lugares","jantar":"comida","jardim":"natureza","joelho":"corpo","juiz":"ofícios","lago":"natureza","lar":"lugares","lavrador":"ofícios","leite":"comida","letra":"linguagem","linguagem":"linguagem","livro":"artes","língua":"corpo","madrinha":"família","madrugada":"tempo","mandioca":"comida","manhã":"tempo","manteiga":"comida","mar":"natureza","marinheiro":"ofícios","mata":"natureza","medo":"sentimentos","mel":"comida","melancolia":"sentimentos","melodia":"artes","memória":"linguagem","mercado":"lugares","milho":"comida","minuto":"tempo","momento":"tempo","montanha":"natureza","mágoa":"sentimentos","mãe":"família","mão":"corpo","médico":"ofícios","mês":"tempo","música":"artes","natureza":"natureza","nação":"lugares","neta":"família","neto":"família","noite":"tempo","nome":"linguagem","nora":"família","nostalgia":"sentimentos","ofício":"ofícios","olho":"corpo","ombro":"corpo","onda":"natureza","ontem":"tempo","operário":"ofícios","osso":"corpo","ovo":"comida","padeiro":"ofícios","padrinho":"família","pai":"família","pais":"família","paixão":"sentimentos","palavra":"linguagem","parentesco":"família","passado":"tempo","pastor":"ofícios","patrão":"ofícios","pavor":"sentimentos","país":"lugares","pedreiro":"ofícios","peito":"corpo","peixe":"comida","pele":"corpo","pergunta":"linguagem","perna":"corpo","pescador":"ofícios","pescoço":"corpo","piano":"artes","pimenta":"comida","pintura":"artes","poesia":"artes","ponte":"lugares","porta":"lugares","porto":"lugares","prado":"natureza","praia":"natureza","prazer":"sentimentos","praça":"lugares","prima":"família","primo":"família","professor":"ofícios","profissão":"ofícios","pulmão":"corpo","pátria":"lugares","pão":"comida","pé":"corpo","pétala":"natureza","quarto":"lugares","queijo":"comida","raiz":"natureza","refeição":"comida","resposta":"linguagem","riacho":"natureza","rima":"artes","rio":"natureza","ritmo":"artes","romance":"artes","rosto":"corpo","rua":"lugares","sal":"comida","salário":"ofícios","samba":"artes","sangue":"corpo","sapateiro":"ofícios","saudade":"sentimentos","segundo":"tempo","selva":"natureza","semana":"tempo","semente":"natureza","sentido":"linguagem","serra":"natureza","significado":"linguagem","silêncio":"linguagem","sinônimo":"linguagem","sobrinho":"família","sogra":"família","soldado":"ofícios","sotaque":"linguagem","surpresa":"sentimentos","sussurro":"linguagem","susto":"sentimentos","século":"tempo","sílaba":"linguagem","tambor":"artes","tarde":"tempo","teatro":"artes","tela":"artes","tempo":"tempo","ternura":"sentimentos","tia":"família","tio":"família","trabalho":"ofícios","trigo":"comida","tristeza":"sentimentos","unha":"corpo","vale":"natureza","verso":"artes","vila":"lugares","vinho":"comida","violão":"artes","voz":"linguagem","água":"comida","árvore":"natureza","época":"tempo"},"themeColors":{"sentimentos":"#f26d78","família":"#f2b880","comida":"#e8d16b","tempo":"#9ad86b","natureza":"#5fd6a8","lugares":"#57c7e8","corpo":"#7f9cf5","ofícios":"#c58cf0","artes":"#f58ad0","linguagem":"#f2c14e"},"themeCounts":{"linguagem":25,"ofícios":25,"comida":25,"sentimentos":25,"lugares":25,"corpo":25,"tempo":25,"natureza":25,"artes":25,"família":25},"accent":"#f2c14e","mostConnected":"palavra","mostConnectedDegree":16};

/* ---------- graph model (undirected view of the site's directed links) ---------- */
const norm = s => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"");
const words = Object.keys(DATA.adj).sort();
const idx = new Map(words.map((w,i)=>[w,i]));
const N = words.length;
const out = words.map(w => DATA.adj[w]);
const nbr = words.map(()=>new Set());
const edges = [];
const seen = new Set();
for (const [a,ls] of Object.entries(DATA.adj)) for (const b of ls) {
  const i = idx.get(a), j = idx.get(b);
  const k = i<j ? i+"-"+j : j+"-"+i;
  if (!seen.has(k)) { seen.add(k); edges.push([i,j]); nbr[i].add(j); nbr[j].add(i); }
}
const OUT = out.map(ls => ls.map(w=>idx.get(w)));
const IN  = words.map((w,i)=>{ const s=[]; for (const [a,ls] of Object.entries(DATA.adj)) if (ls.includes(w)) s.push(idx.get(a)); return s; });
const deg = nbr.map(s=>s.size);
const maxDeg = Math.max(...deg);
const themes = DATA.themes;
const themeList = Object.keys(DATA.themeColors);
const color = words.map(w => DATA.themeColors[themes[w]] || "#999");

/* ---------- 3D force layout (own simulation, so rendering can fall back) ---------- */
const anchor = themeList.map((t,k)=>{                       // one hub per theme, fibonacci sphere
  const y = 1 - (k+0.5)/themeList.length*2, r = Math.sqrt(Math.max(0,1-y*y)), a = k*2.399963;
  return [Math.cos(a)*r*430, y*430, Math.sin(a)*r*430];
});
const P = new Float64Array(N*3), V = new Float64Array(N*3);
{ let s = 7; const rnd=()=>((s=(s*1103515245+12345)&0x7fffffff)/0x7fffffff*2-1);
  for (let i=0;i<N;i++){ const a = anchor[themeList.indexOf(themes[words[i]])]||[0,0,0];
    P[i*3]=a[0]+rnd()*90; P[i*3+1]=a[1]+rnd()*90; P[i*3+2]=a[2]+rnd()*90; } }
function relax(iters){
  for (let it=0; it<iters; it++){
    for (let i=0;i<N;i++){                                  // repulsion
      for (let j=i+1;j<N;j++){
        let dx=P[i*3]-P[j*3], dy=P[i*3+1]-P[j*3+1], dz=P[i*3+2]-P[j*3+2];
        let d2=dx*dx+dy*dy+dz*dz+40; const f=4200/d2, d=Math.sqrt(d2);
        dx/=d; dy/=d; dz/=d;
        V[i*3]+=dx*f; V[i*3+1]+=dy*f; V[i*3+2]+=dz*f;
        V[j*3]-=dx*f; V[j*3+1]-=dy*f; V[j*3+2]-=dz*f;
      }
    }
    for (const [i,j] of edges){                              // springs
      let dx=P[j*3]-P[i*3], dy=P[j*3+1]-P[i*3+1], dz=P[j*3+2]-P[i*3+2];
      const d=Math.sqrt(dx*dx+dy*dy+dz*dz)+.01, f=(d-72)/d*0.055;
      dx*=f; dy*=f; dz*=f;
      V[i*3]+=dx; V[i*3+1]+=dy; V[i*3+2]+=dz;
      V[j*3]-=dx; V[j*3+1]-=dy; V[j*3+2]-=dz;
    }
    for (let i=0;i<N;i++){                                   // theme anchor + origin
      const a = anchor[themeList.indexOf(themes[words[i]])]||[0,0,0];
      for (let k=0;k<3;k++) V[i*3+k]+=((a[k]-P[i*3+k])*0.008) + (-P[i*3+k]*0.0012);
    }
    const damp = 0.86 - it*0.001;
    for (let i=0;i<N*3;i++){ V[i]*=damp; P[i]+=Math.max(-6,Math.min(6,V[i])); }
  }
}
relax(420);
let cx=0,cy=0,cz=0; for (let i=0;i<N;i++){cx+=P[i*3];cy+=P[i*3+1];cz+=P[i*3+2];}
cx/=N; cy/=N; cz/=N; for (let i=0;i<N;i++){P[i*3]-=cx;P[i*3+1]-=cy;P[i*3+2]-=cz;}

/* ---------- camera + interaction ---------- */
let rotX = -0.22, rotY = 0.6, tRotX = null, tRotY = null, zoom = 1.45, autoSpin = true, spin = 0.001;
let W = innerWidth, H = innerHeight;
const canvas = document.getElementById("c2d");
const ctx = canvas.getContext("2d");
const labels = document.getElementById("labels");
let THREE = null;
try { THREE = await import("https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js"); }
catch (e) { console.warn("three.js indisponível, usando canvas 2D", e); }

const proj = new Float32Array(N*3);
function project(){
  const cxr=Math.cos(rotX), sxr=Math.sin(rotX), cyr=Math.cos(rotY), syr=Math.sin(rotY);
  const f = 900*zoom, cz = 1000;
  for (let i=0;i<N;i++){
    let x=P[i*3], y=P[i*3+1], z=P[i*3+2];
    let x1=x*cyr - z*syr, z1=x*syr + z*cyr;
    let y1=y*cxr - z1*sxr, z2=y*sxr + z1*cxr;
    const s = f/(cz+z2);
    proj[i*3]=W/2 + x1*s; proj[i*3+1]=H/2 + y1*s; proj[i*3+2]=z2;
  }
}

/* ---------- three.js renderer (primary) ---------- */
let gl = null;
function initGL(){
  const renderer = new THREE.WebGLRenderer({antialias:true, alpha:true});
  renderer.setPixelRatio(Math.min(devicePixelRatio,2));
  renderer.setSize(W,H);
  Object.assign(renderer.domElement.style,{position:"fixed",inset:"0",zIndex:"0"});
  document.body.appendChild(renderer.domElement);
  canvas.style.display="none";
  const scene = new THREE.Scene();
  const cam = new THREE.PerspectiveCamera(50, W/H, 1, 8000); cam.position.z = 1000;
  cam.zoom = 1.45; cam.updateProjectionMatrix();
  const pos = new Float32Array(N*3), col = new Float32Array(N*3), size = new Float32Array(N);
  const c = new THREE.Color();
  const geo = new THREE.BufferGeometry();
  for (let i=0;i<N;i++){ c.set(color[i]); col[i*3]=c.r; col[i*3+1]=c.g; col[i*3+2]=c.b;
    size[i] = 4 + deg[i]/maxDeg*16; }
  const sprite = (()=>{ const s=64, cv=document.createElement("canvas"); cv.width=cv.height=s;
      const g=cv.getContext("2d"), r=g.createRadialGradient(s/2,s/2,0,s/2,s/2,s/2);
      r.addColorStop(0,"rgba(255,255,255,1)"); r.addColorStop(.45,"rgba(255,255,255,.85)");
      r.addColorStop(1,"rgba(255,255,255,0)"); g.fillStyle=r; g.fillRect(0,0,s,s);
      return new THREE.CanvasTexture(cv); })();
  geo.setAttribute("position", new THREE.BufferAttribute(pos,3));
  geo.setAttribute("color", new THREE.BufferAttribute(col,3));
  const pts = new THREE.Points(geo, new THREE.PointsMaterial({
    map:sprite, vertexColors:true, size:11, sizeAttenuation:true,
    transparent:true, depthWrite:false, blending:THREE.AdditiveBlending }));
  const HL = 64, hpos = new Float32Array(HL*3), hcol = new Float32Array(HL*3);
  const hgeo = new THREE.BufferGeometry();
  hgeo.setAttribute("position", new THREE.BufferAttribute(hpos,3));
  hgeo.setAttribute("color", new THREE.BufferAttribute(hcol,3));
  const hpts = new THREE.Points(hgeo, new THREE.PointsMaterial({
    map:sprite, vertexColors:true, size:26, sizeAttenuation:true,
    transparent:true, depthWrite:false, blending:THREE.AdditiveBlending }));
  scene.add(hpts);
  const epos = new Float32Array(edges.length*6), ecol = new Float32Array(edges.length*6);
  const egeo = new THREE.BufferGeometry();
  egeo.setAttribute("position", new THREE.BufferAttribute(epos,3));
  egeo.setAttribute("color", new THREE.BufferAttribute(ecol,3));
  const lines = new THREE.LineSegments(egeo, new THREE.LineBasicMaterial({
    vertexColors:true, transparent:true, opacity:.55, blending:THREE.AdditiveBlending }));
  scene.add(lines); scene.add(pts);
  gl = { renderer, scene, cam, geo, pts, hgeo, hpos, hcol, HL, epos, ecol, egeo, pos, col, size, c };
}
if (THREE) { try { initGL(); } catch(e){ console.warn("WebGL falhou", e); gl=null; canvas.style.display="block"; } }

/* ---------- state ---------- */
let sel = -1, hov = -1;
const off = new Set();
function visible(i){ return !off.has(themes[words[i]]); }
function focusSet(i){ const s = new Set([i]); if (i>=0) for (const j of nbr[i]) s.add(j); return s; }

/* ---------- draw ---------- */
const labelPool = [];
function draw(){
  project();
  const focus = focusSet(hov>=0 ? hov : sel);
  const hasFocus = (hov>=0 || sel>=0);
  if (gl){
    const {renderer,scene,cam,geo,pos,epos,ecol,egeo,hgeo,hpos,hcol,HL,c} = gl;
    for (let i=0;i<N;i++){ pos[i*3]=P[i*3]; pos[i*3+1]=P[i*3+1]; pos[i*3+2]=P[i*3+2];
      const on = visible(i), hot = focus.has(i);
      c.set(color[i]);
      const k = !on ? 0.05 : (hasFocus ? (hot?1.6:0.28) : (0.75 + deg[i]/maxDeg*0.6));
      col3(c,k);
      geo.attributes.color.array[i*3]=c.r; geo.attributes.color.array[i*3+1]=c.g; geo.attributes.color.array[i*3+2]=c.b;
    }
    geo.attributes.position.needsUpdate = geo.attributes.color.needsUpdate = true;
    geo.setDrawRange(0,N);
    let h = 0;
    for (const i of focus){ if (h>=HL || !visible(i)) continue;
      hpos[h*3]=P[i*3]; hpos[h*3+1]=P[i*3+1]; hpos[h*3+2]=P[i*3+2];
      c.set(i===sel||i===hov ? DATA.accent : color[i]); col3(c,1.3);
      hcol[h*3]=c.r; hcol[h*3+1]=c.g; hcol[h*3+2]=c.b; h++; }
    hgeo.setDrawRange(0,h);
    hgeo.attributes.position.needsUpdate = hgeo.attributes.color.needsUpdate = true;
    let e = 0;
    for (const [i,j] of edges){
      const on = visible(i) && visible(j);
      const hot = hasFocus && (i===(hov>=0?hov:sel) || j===(hov>=0?hov:sel));
      const v = !on ? 0 : (hot ? 1.0 : (hasFocus ? 0.04 : 0.2));
      epos[e*6]=P[i*3];epos[e*6+1]=P[i*3+1];epos[e*6+2]=P[i*3+2];
      epos[e*6+3]=P[j*3];epos[e*6+4]=P[j*3+1];epos[e*6+5]=P[j*3+2];
      c.set(hot?DATA.accent:color[i]); col3(c,v);
      ecol[e*6]=c.r;ecol[e*6+1]=c.g;ecol[e*6+2]=c.b;
      c.set(hot?DATA.accent:color[j]); col3(c,v);
      ecol[e*6+3]=c.r;ecol[e*6+4]=c.g;ecol[e*6+5]=c.b;
      e++;
    }
    egeo.attributes.position.needsUpdate = egeo.attributes.color.needsUpdate = true;
    renderer.render(scene,cam);
  } else {
    ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);
    ctx.clearRect(0,0,W,H); ctx.lineWidth = 1;
    const t = hov>=0?hov:sel;
    for (const [i,j] of edges){
      if (!visible(i)||!visible(j)) continue;
      const hot = hasFocus && (i===t||j===t);
      ctx.globalAlpha = hot?0.9:(hasFocus?0.05:0.22);
      ctx.strokeStyle = hot?DATA.accent:"#7d86a8";
      ctx.beginPath(); ctx.moveTo(proj[i*3],proj[i*3+1]); ctx.lineTo(proj[j*3],proj[j*3+1]); ctx.stroke();
    }
    for (let i=0;i<N;i++){
      if (!visible(i)) continue;
      const hot = focus.has(i);
      const r = (2.2 + deg[i]/maxDeg*7) * (hot?1.7:1) * (1 + (400-proj[i*3+2])/2600);
      ctx.globalAlpha = hasFocus ? (hot?1:0.22) : 0.92;
      ctx.fillStyle = color[i];
      ctx.beginPath(); ctx.arc(proj[i*3],proj[i*3+1],Math.max(1,r),0,6.284); ctx.fill();
    }
    ctx.globalAlpha = 1;
  }
  drawLabels(focus, hasFocus);
}
function col3(c,k){ c.r=Math.min(1,c.r*k); c.g=Math.min(1,c.g*k); c.b=Math.min(1,c.b*k); }
function drawLabels(focus, hasFocus){
  const show = [];
  if (hasFocus) for (const i of focus) show.push(i);
  else { const top = words.map((w,i)=>i).sort((a,b)=>deg[b]-deg[a]);
         for (const i of top) if (visible(i) && show.length<26) show.push(i); }
  if (hov>=0 && !show.includes(hov)) show.push(hov);
  while (labelPool.length < show.length){ const d=document.createElement("div");
    d.className="lbl"; labels.appendChild(d); labelPool.push(d); }
  labelPool.forEach((d,k)=>{
    if (k>=show.length){ d.style.display="none"; return; }
    const i = show[k];
    d.style.display="block";
    d.textContent = words[i];
    d.style.left = Math.max(70, Math.min(W-70, proj[i*3]))+"px";
    d.style.top = Math.max(28, Math.min(H-20, proj[i*3+1] - (10+deg[i]/maxDeg*16))) + "px";
    d.style.fontSize = (12 + deg[i]/maxDeg*15).toFixed(1)+"px";
    d.style.zIndex = 1000 - Math.round(proj[i*3+2]);
    d.className = "lbl" + (i===sel?" sel":"") + (focus.has(i)&&hasFocus?" nb":"") +
                  (hasFocus && !focus.has(i) ? " faded":"");
  });
}
function tick(){
  if (tRotX !== null){
    let dy = tRotY - rotY; while (dy > Math.PI) dy -= 2*Math.PI; while (dy < -Math.PI) dy += 2*Math.PI;
    rotY += dy*0.12; rotX += (tRotX - rotX)*0.12;
    if (Math.abs(dy) < 0.004 && Math.abs(tRotX - rotX) < 0.004){ rotY = tRotY; rotX = tRotX; tRotX = tRotY = null; }
  } else if (autoSpin && !dragging) rotY += spin;
  draw();
  requestAnimationFrame(tick);
}
/* aim the camera at a node so a shared ?word= always lands in view */
function frame(i){
  const x = P[i*3], y = P[i*3+1], z = P[i*3+2];
  const ry = Math.atan2(x, z), z1 = x*Math.sin(ry) + z*Math.cos(ry);
  tRotY = ry; tRotX = Math.max(-1.45, Math.min(1.45, Math.atan2(y, z1)));
}

/* ---------- picking, drag, zoom ---------- */
let dragging=false, moved=0, px=0, py=0;
function pick(mx,my){
  let best=-1, bd=26*26;
  for (let i=0;i<N;i++){ if(!visible(i)) continue;
    const dx=proj[i*3]-mx, dy=proj[i*3+1]-my, d=dx*dx+dy*dy;
    if (d<bd){ bd=d; best=i; } }
  return best;
}
addEventListener("pointerdown", e=>{ if (e.target!==document.body && e.target.tagName!=="CANVAS") return;
  dragging=true; moved=0; px=e.clientX; py=e.clientY; tRotX=tRotY=null; });
addEventListener("pointermove", e=>{
  if (dragging){ const dx=e.clientX-px, dy=e.clientY-py; moved+=Math.abs(dx)+Math.abs(dy);
    rotY += dx*0.006; rotX += dy*0.006; rotX = Math.max(-1.5,Math.min(1.5,rotX));
    px=e.clientX; py=e.clientY; }
  else hov = pick(e.clientX,e.clientY);
});
addEventListener("pointerup", e=>{
  if (dragging && moved<5){ const i = pick(e.clientX,e.clientY); if (i>=0) select(i); else select(-1); }
  dragging=false;
});
addEventListener("wheel", e=>{ zoom = Math.max(.35, Math.min(4, zoom*(e.deltaY<0?1.1:0.9))); }, {passive:true});
addEventListener("keydown", e=>{ if (e.key==="Escape") select(-1); });
addEventListener("resize", ()=>{ W=innerWidth; H=innerHeight;
  canvas.width=W*devicePixelRatio; canvas.height=H*devicePixelRatio;
  if (gl){ gl.renderer.setSize(W,H); gl.cam.aspect=W/H; gl.cam.updateProjectionMatrix(); } });

/* ---------- selection, card, url ---------- */
function esc(s){ return s.replace(/[&<>]/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;"}[c])); }
function select(i, push=true){
  sel = i;
  if (i>=0) frame(i);
  const card = document.getElementById("card");
  if (i<0){ card.style.display="none"; }
  else {
    const w = words[i];
    const o = OUT[i].filter(j=>j>=0), n = IN[i].filter(j=>j>=0);
    const chip = (j,cls) => `<span class="chip ${cls}" data-i="${j}" title="${OUT[i].includes(j)?"ligação recíproca":"só neste sentido"}">${esc(words[j])}${OUT[i].includes(j)?"":" <small>↦</small>"}</span>`;
    card.style.display="block";
    card.innerHTML =
      `<h2>${esc(w)}</h2>
       <div class="tema"><span class="dot" style="background:${color[i]}"></span>${esc(themes[w]||"—")} · ${deg[i]} ${deg[i]===1?"ligação":"ligações"}</div>
       <h3>Remete a (${o.length})</h3><div class="chips">${o.map(j=>chip(j,"out")).join("")||"<i>nada declarado</i>"}</div>
       <h3>Citada por (${n.length})</h3><div class="chips">${n.map(j=>chip(j,"in")).join("")||"<i>nada declarado</i>"}</div>`;
    card.querySelectorAll(".chip").forEach(c=>c.onclick=()=>select(+c.dataset.i));
  }
  if (push){
    const url = new URL(location.href);
    if (i<0) url.searchParams.delete("word"); else url.searchParams.set("word", words[i]);
    try { history.replaceState(null,"",url); } catch(e){}
  }
}

/* ---------- search ---------- */
const q = document.getElementById("q"), sug = document.getElementById("sug");
const nwords = words.map(norm);
let hits = [], cur = 0;
function find(word){ const k = norm(word); let i = nwords.indexOf(k);
  if (i<0) i = nwords.findIndex(w=>w.startsWith(k));
  if (i<0) i = nwords.findIndex(w=>w.includes(k));
  return i; }
function update(){
  const k = norm(q.value.trim());
  hits = !k ? [] : words.map((w,i)=>[w.startsWith(k)?0:nwords[i].startsWith(k)?1:nwords[i].includes(k)?2:9,i])
    .filter(x=>x[0]<9).sort((a,b)=>a[0]-b[0]||deg[b[1]]-deg[a[1]]).slice(0,8).map(x=>x[1]);
  cur = 0;
  sug.style.display = hits.length ? "block" : "none";
  sug.innerHTML = hits.map((i,k)=>`<div data-i="${i}" class="${k===cur?"on":""}">
    <span>${esc(words[i])}</span><i>${deg[i]} · ${esc(themes[words[i]])}</i></div>`).join("");
  sug.querySelectorAll("div").forEach(d=>d.onclick=()=>{ select(+d.dataset.i); q.value=""; sug.style.display="none"; });
}
q.addEventListener("input", update);
q.addEventListener("keydown", e=>{
  if (e.key==="ArrowDown"||e.key==="ArrowUp"){ e.preventDefault();
    cur = (cur + (e.key==="ArrowDown"?1:-1) + hits.length) % (hits.length||1); update(); }
  else if (e.key==="Enter"){ const i = hits.length ? hits[cur] : find(q.value.trim());
    if (i>=0){ select(i); q.value=""; sug.style.display="none"; q.blur(); } }
  else if (e.key==="Escape"){ sug.style.display="none"; q.value=""; hits=[]; }
});
q.addEventListener("blur", ()=>setTimeout(()=>sug.style.display="none",120));

/* ---------- legend ---------- */
const legend = document.getElementById("themes");
legend.innerHTML = themeList.map(t=>
  `<label data-t="${esc(t)}"><span class="sw" style="background:${DATA.themeColors[t]}"></span>${esc(t)} · ${DATA.themeCounts[t]}</label>`).join("");
legend.querySelectorAll("label").forEach(l=>l.onclick=()=>{
  const t=l.dataset.t;
  if (off.has(t)) off.delete(t); else off.add(t);
  l.classList.toggle("off", off.has(t));
});

/* ---------- stats + boot ---------- */
document.getElementById("stats").innerHTML =
  `<b>${N}</b> palavras · <b>${edges.length}</b> relações<br>mais ligada: <b>${esc(DATA.mostConnected)}</b> (${DATA.mostConnectedDegree})`;
document.getElementById("stats").insertAdjacentHTML("beforeend",
  `<div id="hint">arraste para girar · roda para aproximar · clique numa palavra<br>↦ = ligação só neste sentido</div>`);
canvas.width = W*devicePixelRatio; canvas.height = H*devicePixelRatio;
const want = new URLSearchParams(location.search).get("word") || location.hash.replace(/^#/,"");
if (want){ const i = find(decodeURIComponent(want)); if (i>=0) select(i,false); }
tick();
