import os, re, json, unicodedata
from urllib.parse import unquote
from collections import OrderedDict

SITE = "site"
files = [f for f in os.listdir(SITE) if f.lower().endswith(".html")]
by_lower = {f.lower(): f for f in files}

def read(f):
    return open(os.path.join(SITE, f), encoding="utf-8").read()

# --- pass 1: classify pages, find redirects
redirect = {}   # lower filename -> target lower filename
wordpage = {}   # lower filename -> (file, word, tema)
for f in files:
    html = read(f)
    m = re.search(r'<meta http-equiv="refresh" content="0; url=([^"]+)"', html)
    if m:
        redirect[f.lower()] = unquote(m.group(1)).lower()
        continue
    h1 = re.search(r"<main><h1>(.*?)</h1>", html)
    if not h1:
        continue
    tema = re.search(r'<p class="tema">Tema: (.*?)</p>', html)
    if not tema:            # index / sobre / contato are navigation pages, not words
        continue
    wordpage[f.lower()] = (f, h1.group(1).strip(), tema.group(1).strip())

def resolve(href):
    """href -> canonical word or None"""
    href = href.split("#")[0]
    if not href.lower().endswith(".html"):
        return None
    key = unquote(href).lower()
    seen = set()
    while key in redirect and key not in seen:
        seen.add(key)
        key = redirect[key]
    if key not in wordpage:
        return None
    return wordpage[key][1]

words = OrderedDict()
meta = {}
dangling = []
for key in sorted(wordpage):
    f, word, tema = wordpage[key]
    html = read(f)
    main = re.search(r"<main>(.*?)</main>", html, re.S).group(1)
    links, kinds = [], {}
    for sec in re.finditer(r'<section id="(sinonimos|analogas)"><h2>.*?</h2><ul>(.*?)</ul></section>', main, re.S):
        kind, body = sec.group(1), sec.group(2)
        for href, text in re.findall(r'<a href="([^"]+)">(.*?)</a>', body):
            target = resolve(href)
            if target is None:
                dangling.append((word, href))
                continue
            if target == word:
                continue
            if target not in kinds:
                links.append(target)
            kinds[target] = kinds.get(target, kind) if target not in kinds else kinds[target]
    words[word] = links
    meta[word] = {"tema": tema, "kind": kinds}

# undirected distinct pairs
pairs = set()
for w, ls in words.items():
    for l in ls:
        pairs.add(tuple(sorted((w, l))))

deg = {w: len(set(words[w])) for w in words}
# every word that appears as a target must itself be a page (guaranteed by resolve)
out = {w: words[w] for w in words}
json.dump(out, open("words.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1, sort_keys=True)

top = sorted(deg.items(), key=lambda kv: (-kv[1], kv[0]))
themes = {}
for w in words:
    t = meta[w]["tema"] or "?"
    themes[t] = themes.get(t, 0) + 1

undeg = {w: set() for w in words}
for a, b in pairs:
    undeg[a].add(b); undeg[b].add(a)
utop = sorted(((w, len(s)) for w, s in undeg.items()), key=lambda kv: (-kv[1], kv[0]))
result = {
    "words": len(words),
    "relations": len(pairs),
    "most_connected": utop[0][0],
    "most_connected_degree": utop[0][1],
    "top_connected": [{"word": w, "degree": d} for w, d in utop[:10]],
    "themes": themes,
    "notes": {
        "source": "site/*.html",
        "word_pages": len(words),
        "directed_links": sum(len(v) for v in words.values()),
        "asymmetric_pairs": sum(1 for a, b in pairs if b not in words[a]),
        "dangling_links_excluded": sorted({h for _, h in dangling}),
        "redirects_resolved": sorted(redirect.items()),
        "degree_metric": "distinct neighbours over undirected distinct pairs",
    },
}
json.dump(result, open("result.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("words", len(words), "pairs", len(pairs))
print("utop", utop[:12])
print("themes", sorted(themes.items(), key=lambda kv: -kv[1]))
print("dangling", dangling)
print("zero-degree", [w for w in words if deg[w] == 0])
print("asymmetry", sum(1 for a, b in pairs if b not in words[a]))
json.dump({"meta": meta, "deg": deg, "themes": themes, "pairs": sorted(pairs)}, open("tmp/graph.json", "w", encoding="utf-8"), ensure_ascii=False)