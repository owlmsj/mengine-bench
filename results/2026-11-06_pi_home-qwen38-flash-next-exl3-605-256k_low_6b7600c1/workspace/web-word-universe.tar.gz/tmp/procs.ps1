Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" |
  Where-Object { $_.CommandLine -like '*headless*' } |
  ForEach-Object { "{0} {1}" -f $_.ProcessId, $_.CreationDate }
