import json
adj = json.load(open("words.json", encoding="utf-8"))
res = json.load(open("result.json", encoding="utf-8"))
themes = {w: None for w in adj}
# theme per word comes from the parsed graph sidecar
g = json.load(open("tmp/graph.json", encoding="utf-8"))
themes = {w: (g["meta"][w]["tema"] if w in g["meta"] else None) for w in adj}
COLORS = {
    "sentimentos": "#f26d78", "família": "#f2b880", "comida": "#e8d16b",
    "tempo": "#9ad86b", "natureza": "#5fd6a8", "lugares": "#57c7e8",
    "corpo": "#7f9cf5", "ofícios": "#c58cf0", "artes": "#f58ad0",
    "linguagem": "#f2c14e",
}
data = {
    "adj": adj,
    "themes": themes,
    "themeColors": COLORS,
    "themeCounts": res["themes"],
    "accent": "#f2c14e",
    "mostConnected": res["most_connected"],
    "mostConnectedDegree": res["most_connected_degree"],
}
tpl = open("tmp/template.html", encoding="utf-8").read()
assert "__DATA__" in tpl
open("universe/index.html", "w", encoding="utf-8").write(
    tpl.replace("__DATA__", json.dumps(data, ensure_ascii=False, separators=(",", ":"))))
print("bytes", len(open("universe/index.html", encoding="utf-8").read()))
print("themes missing", [w for w, t in themes.items() if not t])