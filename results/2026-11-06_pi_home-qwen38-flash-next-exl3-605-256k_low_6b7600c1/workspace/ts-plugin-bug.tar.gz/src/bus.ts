/**
 * Hook bus for harness plugins (OpenCode-style hooks). The README states the contract:
 * handlers run one after another in subscription order, emit resolves after all of them,
 * a handler error rejects emit, and unsubscribing during an emit does not stop the others.
 */

export type Handler<T> = (payload: T) => void | Promise<void>;

/**
 * One subscription, wrapped so that the same function subscribed twice yields two
 * distinct identities and each unsubscribe removes exactly its own subscription.
 */
type Subscription = { handler: Handler<unknown> };

export class HookBus {
  private handlers: Map<string, Subscription[]> = new Map();

  /** Subscribes a handler to an event; returns the function that unsubscribes it. */
  on<T>(event: string, handler: Handler<T>): () => void {
    const subscription: Subscription = { handler: handler as Handler<unknown> };
    const list = this.handlers.get(event) ?? [];
    list.push(subscription);
    this.handlers.set(event, list);
    return () => {
      const index = (this.handlers.get(event) ?? []).indexOf(subscription);
      if (index >= 0) {
        this.handlers.get(event)!.splice(index, 1);
      }
    };
  }

  /** Runs the handlers of an event with the payload, sequentially in subscription order. */
  async emit<T>(event: string, payload: T): Promise<void> {
    // Snapshot the subscriptions: changes made during this emit count from the next one (README).
    const subscriptions = [...(this.handlers.get(event) ?? [])];
    for (const subscription of subscriptions) {
      // Await each handler before starting the next; a throw or rejection propagates out of
      // emit unchanged and skips the remaining handlers.
      await subscription.handler(payload);
    }
  }

  /** How many handlers an event has. */
  count(event: string): number {
    return (this.handlers.get(event) ?? []).length;
  }
}