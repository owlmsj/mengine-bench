import { HookBus } from "./old_bus.ts";
const bus = new HookBus();
const seen: string[] = [];
bus.on("e", async () => { await new Promise((r) => setTimeout(r, 20)); seen.push("a"); });
bus.on("e", () => { seen.push("b"); });
await bus.emit("e", 1);
console.log("order after await:", JSON.stringify(seen), "(expected [a,b])");
let caught = "none";
const b2 = new HookBus();
b2.on("e", async () => { throw new Error("boom"); });
try { await b2.emit("e", 1); } catch (err) { caught = (err as Error).message; }
console.log("emit rejected with:", caught, "(expected boom)");
