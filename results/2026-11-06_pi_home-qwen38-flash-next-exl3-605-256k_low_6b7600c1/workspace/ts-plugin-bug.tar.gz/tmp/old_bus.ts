export type Handler<T> = (payload: T) => void | Promise<void>;
export class HookBus {
  private handlers: Map<string, Handler<unknown>[]> = new Map();
  on<T>(event: string, handler: Handler<T>): () => void {
    const list = this.handlers.get(event) ?? [];
    list.push(handler as Handler<unknown>);
    this.handlers.set(event, list);
    return () => { const i = list.indexOf(handler as Handler<unknown>); if (i >= 0) list.splice(i, 1); };
  }
  async emit<T>(event: string, payload: T): Promise<void> {
    const list = this.handlers.get(event) ?? [];
    list.forEach(async (handler) => { await handler(payload); });
  }
  count(event: string): number { return (this.handlers.get(event) ?? []).length; }
}
