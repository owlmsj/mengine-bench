import assert from "node:assert/strict";
import { HookBus } from "../src/bus.ts";
import { registerAuditPlugin } from "../src/plugin.ts";

const t = async (name: string, fn: () => Promise<void>) => {
  await fn();
  console.log(`ok - ${name}`);
};

await t("sequential order, slow handler first", async () => {
  const bus = new HookBus();
  const seen: string[] = [];
  bus.on("e", async () => {
    await new Promise((r) => setTimeout(r, 20));
    seen.push("a");
  });
  bus.on("e", () => { seen.push("b"); });
  bus.on("e", async () => { await Promise.resolve(); seen.push("c"); });
  await bus.emit("e", 1);
  assert.deepEqual(seen, ["a", "b", "c"]);
});

await t("emit resolves only after async handlers finish", async () => {
  const bus = new HookBus();
  let done = false;
  bus.on("e", async () => { await new Promise((r) => setTimeout(r, 15)); done = true; });
  await bus.emit("e", 1);
  assert.equal(done, true);
});

await t("sync throw rejects emit with same error and skips rest", async () => {
  const bus = new HookBus();
  const boom = new Error("boom");
  const seen: string[] = [];
  bus.on("e", () => { seen.push("a"); });
  bus.on("e", () => { throw boom; });
  bus.on("e", () => { seen.push("never"); });
  await assert.rejects(bus.emit("e", 1), (err) => err === boom);
  assert.deepEqual(seen, ["a"]);
});

await t("rejection rejects emit with same error and skips rest", async () => {
  const bus = new HookBus();
  const boom = new Error("nope");
  const seen: string[] = [];
  bus.on("e", async () => { seen.push("a"); throw boom; });
  bus.on("e", () => { seen.push("never"); });
  await assert.rejects(bus.emit("e", 1), (err) => err === boom);
  assert.deepEqual(seen, ["a"]);
});

await t("self-unsubscribe during emit does not stop the others", async () => {
  const bus = new HookBus();
  const seen: string[] = [];
  const off = bus.on("e", () => { off(); seen.push("a"); });
  bus.on("e", () => { seen.push("b"); });
  await bus.emit("e", 1);
  assert.deepEqual(seen, ["a", "b"]);
  assert.equal(bus.count("e"), 1);
  await bus.emit("e", 1);
  assert.deepEqual(seen, ["a", "b", "b"]);
});

await t("unsubscribing another handler during emit does not stop the snapshot", async () => {
  const bus = new HookBus();
  const seen: string[] = [];
  const offC = bus.on("e", () => { seen.push("c"); });
  bus.on("e", () => { offC(); seen.push("b"); });
  await bus.emit("e", 1);
  assert.deepEqual(seen, ["c", "b"]);
});

await t("handler subscribed during emit runs from the next emit", async () => {
  const bus = new HookBus();
  const seen: string[] = [];
  bus.on("e", () => { bus.on("e", () => { seen.push("late"); }); seen.push("first"); });
  await bus.emit("e", 1);
  assert.deepEqual(seen, ["first"]);
  await bus.emit("e", 1);
  assert.deepEqual(seen, ["first", "first", "late"]);
});

await t("same function twice unsubscribes independently", async () => {
  const bus = new HookBus();
  let calls = 0;
  const h = () => { calls++; };
  const off1 = bus.on("e", h);
  bus.on("e", h);
  off1();
  assert.equal(bus.count("e"), 1);
  await bus.emit("e", 1);
  assert.equal(calls, 1);
});

await t("unknown event emits cleanly", async () => {
  const bus = new HookBus();
  await bus.emit("missing", 1);
  assert.equal(bus.count("missing"), 0);
});

await t("audit plugin: notice, redaction, then log", async () => {
  const bus = new HookBus();
  const audit: string[] = [];
  registerAuditPlugin(bus, audit);
  await bus.emit("tool.after", { tool: "read", output: "secret password=hunter2 end" });
  assert.deepEqual(audit, [
    "notice: tool output is audited",
    "read: secret password=[redacted] end",
  ]);
  assert.equal(bus.count("tool.after"), 2);
  await bus.emit("tool.after", { tool: "write", output: "clean" });
  assert.deepEqual(audit[2], "write: clean");
});

console.log("all checks passed");