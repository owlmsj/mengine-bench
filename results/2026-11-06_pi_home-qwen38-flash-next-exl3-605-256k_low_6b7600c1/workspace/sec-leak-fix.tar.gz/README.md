# backup-agent

Backs up a folder of the office file server: the intranet web form posts the folder path, the agent packs it into
a `.tar.gz` under `archives/` and uploads it to the backup API.

- `handle_form(form)` is the web form handler; `form["folder"]` is the folder path exactly as the user typed it.
- `archive_folder(folder, out_dir)` packs the folder and returns the archive path.
- `send_archive(path, url, token)` is the HTTP client that uploads one archive; keep its signature.
- `upload(path)` sends an archive with the API settings.

## Configuration

From now on the API token comes from the environment variable `BACKUP_TOKEN`; it is no longer part of the code.
Run the tests with `python -m unittest`.

```bash
export BACKUP_TOKEN='<paste the secret into the environment, never into a file>'
python -m unittest
```

If `BACKUP_TOKEN` is missing, `config.api_token()` fails with an error naming the variable. The token is
never logged: `upload()` logs only the archive path.
