"""Backup agent: packs a folder chosen in the intranet web form and uploads it to the backup API."""

from __future__ import annotations

import logging
import tarfile
import urllib.request
from pathlib import Path

import config

log = logging.getLogger("backup_agent")


def archive_folder(folder: str, out_dir: str = config.ARCHIVE_DIR) -> Path:
    """Packs `folder` into `out_dir/<folder name>.tar.gz` and returns the archive path.

    Packed with the `tarfile` module instead of the `tar` command: `folder` is
    typed into the web form, so it must never be handed to a shell.
    """
    source = Path(folder)
    if not source.is_dir():
        raise NotADirectoryError(f"expected a folder that exists, received: {folder!r}")
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    target = out / (source.name + ".tar.gz")
    with tarfile.open(target, "w:gz") as packed:
        packed.add(source, arcname=source.name)
    return target


def send_archive(path: Path, url: str, token: str) -> int:
    """Uploads one archive to the backup API and returns the HTTP status."""
    request = urllib.request.Request(url, data=path.read_bytes(), method="POST",
                                     headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.status


def upload(path: Path) -> int:
    """Uploads `path` with the API settings; the token comes from the environment."""
    log.info("uploading %s", path)
    return send_archive(path, config.API_URL, config.api_token())


def handle_form(form: dict[str, str]) -> int:
    """Web form handler: backs up the folder the user typed."""
    archive = archive_folder(form["folder"])
    log.info("archived %s", archive)
    return upload(archive)
