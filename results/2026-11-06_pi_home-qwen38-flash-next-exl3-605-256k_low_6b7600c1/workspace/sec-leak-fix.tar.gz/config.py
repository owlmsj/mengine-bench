"""Settings for the backup agent."""

from __future__ import annotations

import os

API_URL = "https://backup.example.invalid/v1/upload"
ARCHIVE_DIR = "archives"

#: Name of the environment variable that holds the API token. The token itself is
#: never stored here, so nothing secret ships with the source or lands in a log.
API_TOKEN_ENV = "BACKUP_TOKEN"


def api_token(env: dict[str, str] | None = None) -> str:
    """Returns the backup API token, read from the environment on every call."""
    value = (os.environ if env is None else env).get(API_TOKEN_ENV, "").strip()
    if not value:
        raise RuntimeError(
            f"{API_TOKEN_ENV} is not set: expected the backup API token in that "
            "environment variable (it is no longer stored in the code)"
        )
    return value