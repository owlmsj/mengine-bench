"""Security guards for the open-source release: no secret in code or logs, no shell."""

from __future__ import annotations

import os
import unittest
from pathlib import Path
from unittest import mock

import backup_agent
import config

ROOT = Path(__file__).resolve().parents[1]
SOURCES = ["backup_agent.py", "config.py", "README.md"]
SECRET_PREFIX = "bk_" + "live_"  # built at runtime so no secret-shaped literal ships


class TokenStaysOutOfCode(unittest.TestCase):
    def test_no_token_literal_in_the_shipped_sources(self):
        for name in SOURCES:
            self.assertNotIn(SECRET_PREFIX, (ROOT / name).read_text(encoding="utf-8"), name)

    def test_config_no_longer_exposes_a_token_constant(self):
        self.assertFalse(hasattr(config, "API_TOKEN"))

    def test_token_is_read_from_the_environment_on_every_call(self):
        with mock.patch.dict(os.environ, {config.API_TOKEN_ENV: "env-only-token"}):
            self.assertEqual(config.api_token(), "env-only-token")

    def test_missing_token_raises_and_names_the_variable(self):
        with mock.patch.dict(os.environ, {}, clear=True):
            with self.assertRaises(RuntimeError) as caught:
                config.api_token()
        self.assertIn("BACKUP_TOKEN", str(caught.exception))


class TokenStaysOutOfLogs(unittest.TestCase):
    def test_upload_logs_the_archive_but_never_the_token(self):
        Path("a.tar.gz").write_bytes(b"x")
        with mock.patch.dict(os.environ, {config.API_TOKEN_ENV: "env-only-token"}), \
                mock.patch.object(backup_agent, "send_archive", return_value=200):
            with self.assertLogs("backup_agent", "INFO") as logged:
                self.assertEqual(backup_agent.upload(Path("a.tar.gz")), 200)
        self.assertNotIn("env-only-token", "\n".join(logged.output))


class FormDataIsNeverACommand(unittest.TestCase):
    def test_shell_metacharacters_in_the_folder_are_not_executed(self):
        hostile = 'docs; touch pwned$(id)`id`&&touch pwned2'
        with self.assertRaises(NotADirectoryError):
            backup_agent.handle_form({"folder": hostile})
        self.assertFalse(Path("pwned").exists())
        self.assertFalse(Path("pwned2").exists())


if __name__ == "__main__":
    unittest.main()