# HANDOFF

Task: measure local-9b Q5 at 128k ctx (llama.cpp).

Accepted result: 38.0 t/s decode, 7697 MiB VRAM, no spill, needs
`--no-mmproj-offload` + `-ub 512`. Median of 3 via
`pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`.

Rejected: first run 37.8 t/s / 7881 MiB sat on the WDDM ceiling with 1494 MiB
in Shared Usage (sysmem spill): invalid.
Q6_K (7.03 GiB) does not fit 128k, dropped. Q4_K_M fits: 7305 MiB / 40.4 t/s,
kept as fallback only.

Applied to: scripts/start_server.ps1:165 (local9 block), profiles/local/local-9b.json.

Open:
1. No post-apply verification: recipe was written but never re-measured through
   start_server.ps1. Do this first.
2. evals README still cites check_vision.ps1, a deleted file.
3. Scratchpad temp-file names flagged repeatedly, never reviewed.
4. Nothing committed; diffs so far were formatting-only.

Assumption: repo not in this workspace (only AGENTS.md + session/transcript.md);
paths/numbers quoted from transcript, unverified here.