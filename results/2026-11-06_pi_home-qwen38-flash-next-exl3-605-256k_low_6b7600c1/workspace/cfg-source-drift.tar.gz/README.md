# Harness model configs

The model settings that OpenCode, Codex and Claude Code read on the workstation.

- `models.json`: the models we serve and their limits.
- `gen.py`: writes `out/` from `models.json` (`python gen.py`).
- `out/`: generated; the install step copies these files into each harness.

Never hand-edit `out/`: a hand-edit fixes one harness and leaves the other two
behind (that is how fast-coder ended up 262144 in OpenCode and 131072 in Codex
and Claude Code). Change `models.json`, run `python gen.py`, then
`python gen.py --check` (exits non-zero if `out/` is stale or hand-edited).
