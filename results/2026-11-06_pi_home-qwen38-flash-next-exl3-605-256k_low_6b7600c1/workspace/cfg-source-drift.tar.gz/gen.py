"""Writes the harness configs in out/ from models.json. Python stdlib only.

out/ is generated: never hand-edit it, edit models.json and re-run. `--check`
fails on drift (stale or hand-edited out/) so the three harnesses cannot
silently disagree again.
"""

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def opencode(models):
    entries = {
        model["name"]: {
            "name": model["name"],
            "limit": {"context": model["context_window"], "output": model["max_output"]},
            "tool_call": model["tool_calling"],
        }
        for model in models
    }
    config = {"provider": {"workstation": {"npm": "@ai-sdk/openai-compatible", "models": entries}}}
    return json.dumps(config, indent=2) + "\n"


def codex(models):
    lines = []
    for model in models:
        lines += [
            f'[models."{model["name"]}"]',
            f'context_window = {model["context_window"]}',
            f'max_output_tokens = {model["max_output"]}',
            f'tool_calling = {"true" if model["tool_calling"] else "false"}',
            "",
        ]
    return "\n".join(lines)


def claude(models):
    entries = [
        {
            "id": model["name"],
            "contextWindow": model["context_window"],
            "maxOutputTokens": model["max_output"],
            "supportsTools": model["tool_calling"],
        }
        for model in models
    ]
    return json.dumps({"models": entries}, indent=2) + "\n"


RENDERS = (("opencode.json", opencode), ("codex.toml", codex), ("claude.json", claude))


def main():
    check = "--check" in sys.argv[1:]
    models = json.loads((ROOT / "models.json").read_text(encoding="utf-8"))["models"]
    out = ROOT / "out"
    out.mkdir(exist_ok=True)
    drifted = []
    for name, render in RENDERS:
        expected = render(models)
        path = out / name
        if check:
            current = path.read_text(encoding="utf-8") if path.exists() else None
            if current != expected:
                drifted.append(name)
                print(f"stale: out/{name} != models.json")
            else:
                print(f"ok: out/{name}")
            continue
        path.write_text(expected, encoding="utf-8", newline="\n")
        print(f"wrote out/{name}")
    if drifted:
        raise SystemExit(f"out/ is out of sync with models.json: {', '.join(drifted)}")


if __name__ == "__main__":
    main()
