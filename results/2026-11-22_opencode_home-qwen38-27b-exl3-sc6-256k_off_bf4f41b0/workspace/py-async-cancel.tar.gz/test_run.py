"""Verification for run.run_tasks."""
import asyncio
import run


def test_concurrency_limit():
    async def main():
        in_flight = 0
        peak = 0

        def make_job(i):
            async def job():
                nonlocal in_flight, peak
                in_flight += 1
                peak = max(peak, in_flight)
                await asyncio.sleep(0.05)
                in_flight -= 1
            return job

        await run.run_tasks([make_job(i) for i in range(10)], 3)
        assert peak <= 3, f"peak {peak}"
        assert in_flight == 0

    asyncio.run(main())


def test_all_done():
    results = []

    async def main():
        def make(i):
            async def job():
                results.append(i)
            return job

        await run.run_tasks([make(i) for i in range(5)], 2)
        assert sorted(results) == [0, 1, 2, 3, 4]

    asyncio.run(main())


def test_lazy_call():
    called = []

    def make(i):
        called.append(i)

        async def job():
            pass

        return lambda: job()

    async def main():
        await run.run_tasks([make(i) for i in range(4)], 1)

    asyncio.run(main())
    assert called == [0, 1, 2, 3]


def test_cancel_runs_cleanup():
    cleaned = []

    async def main():
        async def job():
            try:
                await asyncio.sleep(10)
            finally:
                cleaned.append("done")

        tasks = [job for _ in range(4)]

        async def cancel_later():
            await asyncio.sleep(0.1)
            outer.cancel()

        outer = asyncio.ensure_future(run.run_tasks(tasks, 2))
        asyncio.get_running_loop().call_later(0.1, lambda: outer.cancel())
        try:
            await outer
        except asyncio.CancelledError:
            pass
        assert len(cleaned) == 2, f"cleaned {cleaned}"  # 2 in flight at cancel

    asyncio.run(main())


def test_cancel_all_cleaned_before_return():
    """Even if the outer cancel lands mid-cleanup, all in-flight jobs finish finally."""
    cleaned = []

    async def main():
        async def job():
            try:
                await asyncio.sleep(10)
            finally:
                await asyncio.sleep(0.05)
                cleaned.append(1)

        outer = asyncio.ensure_future(run.run_tasks([job for _ in range(3)], 3))
        await asyncio.sleep(0.02)
        outer.cancel()
        try:
            await outer
        except asyncio.CancelledError:
            pass
        # gather inside run_tasks should have awaited the finalizes
        assert len(cleaned) == 3, f"cleaned {len(cleaned)}"

    asyncio.run(main())


if __name__ == "__main__":
    test_concurrency_limit()
    test_all_done()
    test_lazy_call()
    test_cancel_runs_cleanup()
    test_cancel_all_cleaned_before_return()
    print("ALL PASS")
