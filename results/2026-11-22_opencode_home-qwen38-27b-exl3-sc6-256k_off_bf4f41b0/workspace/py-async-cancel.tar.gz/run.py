"""Concurrent task runner: async def run_tasks(tasks, max_concurrent)."""

import asyncio


async def run_tasks(tasks, max_concurrent):
    """Run zero-arg callables returning awaitable jobs, at most max_concurrent at once.

    Each task callable is invoked only when a semaphore slot is free, so
    at most max_concurrent jobs run at once. Returns when every job has
    finished; the first job exception is re-raised.

    Ctrl+C: the event loop cancels this task, and asyncio.gather then awaits
    cancellation of every in-flight child, so each running job's finally
    blocks (cleanup code) execute before cancellation propagates back.
    """
    semaphore = asyncio.Semaphore(max_concurrent)

    async def guarded(task):
        async with semaphore:
            await task()

    await asyncio.gather(*(guarded(t) for t in tasks))
