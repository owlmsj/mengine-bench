from PIL import Image, ImageDraw, ImageFont

img = Image.new("RGB", (1200, 675), "#12365c")
d = ImageDraw.Draw(img)
d.rectangle([0, 0, 1200, 675], fill="#12365c")
d.rectangle([40, 40, 1160, 635], outline="#e8f0ff", width=6)

font = ImageFont.load_default(size=110)
d.text((600, 337), "Harbor Day 2026", font=font, fill="#ffffff", anchor="mm")

img.save("cover.png")
print("saved", img.size)
