use arena_scores::Board;
use std::thread;

fn main() {
    // Isolate: 2 threads, only award + score checks, no transfer/join races.
    let board = Board::new();
    board.join(1, 0);
    board.join(2, 0);
    let mut handles = vec![];
    for _ in 0..8 {
        let b = board.clone();
        handles.push(thread::spawn(move || {
            for _ in 0..100_000 {
                b.award(1, 1);
            }
        }));
    }
    for h in handles { h.join().unwrap(); }
    // 8 threads x 100k awards of 1 => score(1) = 800_000, total = 800_000
    println!("award-only: score(1)={} total={} (expect both 800000)", board.score(1), board.total());
    assert_eq!(board.score(1), 800_000);
    assert_eq!(board.total(), 800_000);
    println!("OK award-only");

    // Isolate: 2 threads, only transfer 1<->2, no award. Total should stay 0.
    let b2 = Board::new();
    b2.join(1, 0);
    b2.join(2, 0);
    let mut hs = vec![];
    for _ in 0..8 {
        let b = b2.clone();
        hs.push(thread::spawn(move || {
            for _ in 0..100_000 {
                b.transfer(1, 2, 1);
            }
        }));
    }
    for h in hs { h.join().unwrap(); }
    // transfer is net-zero on total => total stays 0; score(1)+score(2) stays 0.
    println!("transfer-only: score(1)={} score(2)={} total={} (expect total 0)", b2.score(1), b2.score(2), b2.total());
    assert_eq!(b2.total(), 0);
    assert_eq!(b2.score(1) + b2.score(2), 0);
    println!("OK transfer-only");
}
