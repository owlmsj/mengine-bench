// Temporary stress check: hammer the board with cross transfers, join/award races.
use arena_scores::Board;
use std::thread;
use std::time::Duration;

fn main() {
    let board = Board::new();
    for id in 0..64u32 {
        board.join(id, 0);
    }
    let mut handles = vec![];
    for t in 0..16 {
        let b = board.clone();
        handles.push(thread::spawn(move || {
            for _ in 0..50_000 {
                let from = rand_i() % 64;
                let to = rand_i() % 64;
                b.transfer(from, to, 1);
                b.award(from, 1);
                b.join(to, 7); // re-join same id: total must adjust by delta
            }
        }));
    }
    for h in handles {
        h.join().unwrap();
    }
    // Invariants: every score >= 0, total == sum of scores.
    let mut sum = 0i64;
    for id in 0..64u32 {
        let s = board.score(id);
        assert!(s >= 0, "negative score for {id}: {s}");
        sum += s;
    }
    assert_eq!(board.total(), sum, "total diverged from sum of scores");
    println!("ok: total={} sum={} (no deadlock, total consistent)", board.total(), sum);
    let _ = Duration::from_secs(1);
}

fn rand_i() -> u32 {
    // xorshift-ish; no deps.
    static mut S: u64 = 0x2545F4914F6CDD1D;
    unsafe {
        S ^= S << 13;
        S ^= S >> 7;
        S ^= S << 17;
        S as u32
    }
}
