#!/usr/bin/env python3
"""Decode a SQLite table-leaf B-tree page (single 4096-byte page) from prices.db."""
import json, os, struct

base = os.path.dirname(os.path.abspath(__file__))
data = open(os.path.join(base, "prices.db"), "rb").read()

# Verify page header
p_type = data[0]
freeblock = struct.unpack(">H", data[1:3])[0]
cell_count = struct.unpack(">H", data[3:5])[0]
content_start = struct.unpack(">H", data[5:7])[0]
frag = data[7]
print(f"type={p_type:#04x} freeblock={freeblock} cells={cell_count} content_start={content_start} frag={frag}")

pointers = [struct.unpack(">H", data[8 + 2*i:10 + 2*i])[0] for i in range(cell_count)]
print("pointers:", [hex(p) for p in pointers])

def varint(buf, off):
    """SQLite big-endian varint, 9 bytes max."""
    result = 0
    for i in range(9):
        b = buf[off + i]
        if i == 8:
            result = (result << 8) | b
            return result, off + 9
        result = (result << 7) | (b & 0x7F)
        if not (b & 0x80):
            return result, off + i + 1
    return result, off + 9

def decode_value(buf, off, serial):
    if serial == 0:
        return None, off
    if serial == 1:
        return struct.unpack(">b", buf[off:off+1])[0], off+1
    if serial == 2:
        return struct.unpack(">h", buf[off:off+2])[0], off+2
    if serial == 3:
        return struct.unpack(">i", b"\x00" + buf[off:off+3])[0], off+3
    if serial == 4:
        return struct.unpack(">i", buf[off:off+4])[0], off+4
    if serial == 5:
        return struct.unpack(">q", b"\x00"*4 + buf[off:off+6])[0], off+6
    if serial == 6:
        return struct.unpack(">q", buf[off:off+8])[0], off+8
    if serial == 7:
        return struct.unpack(">d", buf[off:off+8])[0], off+8
    if serial == 8:
        return 0, off
    if serial == 9:
        return 1, off
    if serial >= 12 and serial % 2 == 0:  # TEXT, serial = 2*len+12 -> actually (n+13)/2
        n = (serial - 12) // 2
        return buf[off:off+n].decode("utf-8", "replace"), off+n
    if serial >= 13 and serial % 2 == 1:  # BLOB, serial = (n+12)/2 -> n = (serial-13)*2+1... spec: for 13: N=(K-13)*2+1? no:
        # spec: if serial >= 12, N = (serial - 12)/2; if serial odd -> BLOB, if even -> TEXT
        n = (serial - 12) // 2
        return ("BLOB:" + buf[off:off+n].hex()), off+n
    raise ValueError(f"bad serial {serial}")

rows = []
for ptr in sorted(pointers):
    off = ptr
    payload_len, off = varint(data, off)
    overflow, off = varint(data, off)
    assert overflow == 0, f"overflow page {overflow} at {ptr}"
    rowid, off = varint(data, off)
    hdr_size, off2 = varint(data, off)
    hdr_end = off + hdr_size
    serials = []
    while off2 < hdr_end:
        s, off2 = varint(data, off2)
        serials.append(s)
    val_off = off + hdr_size
    vals = []
    for s in serials:
        v, val_off = decode_value(data, val_off, s)
        vals.append(v)
    rows.append({"rowid": rowid, "serials": serials, "values": vals})
    print(f"ptr={ptr:#05x} rowid={rowid} serials={serials} values={vals}")

with open(os.path.join(base, "decoded_cells.json"), "w") as f:
    json.dump(rows, f, indent=2)
print("wrote decoded_cells.json")
