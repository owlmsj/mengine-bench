#!/usr/bin/env python3
"""Recover rows from a truncated SQLite database (./prices.db).

Approach:
- Read raw file bytes.
- The first page (page 1, 4096 bytes) contains the SQLite header + sqlite_master.
- Since the DB is truncated to 4096 bytes, only page 1 exists.
- Try to open with sqlite3 in readonly mode; if it fails, parse manually.
- Extract table schema from sqlite_master (page 1, offset 100+).
- Try to read rows from any table defined in sqlite_master.
- If the table data is on a later page (which doesn't exist due to truncation),
  we can only recover what's in page 1.
- Fallback: scan the raw bytes for recognizable row patterns.
"""

import json
import os
import struct
import sys

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "prices.db")
OUT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "recovered.json")

with open(DB_PATH, "rb") as f:
    data = f.read()

print(f"File size: {len(data)} bytes")

# Check if it's a valid SQLite header
if len(data) >= 16 and data[:16] == b"SQLite format 3\x00":
    print("Valid SQLite header detected.")
else:
    print("WARNING: Not a standard SQLite header!")

if len(data) < 4096:
    print("File is less than one full page; may be severely truncated.")
    sys.exit(1)

# Page size from header
page_size = struct.unpack(">H", data[16:18])[0]
print(f"Page size: {page_size}")

# Try opening with sqlite3
import sqlite3

rows = []
try:
    con = sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True)
    cur = con.cursor()
    # Get all tables
    tables = cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchall()
    print(f"Tables found: {[t[0] for t in tables]}")
    for (tname,) in tables:
        try:
            cols = cur.execute(f"PRAGMA table_info({tname})").fetchall()
            col_names = [c[1] for c in cols]
            print(f"  {tname} columns: {col_names}")
            # Try to read rows
            try:
                table_rows = cur.execute(f"SELECT * FROM {tname}").fetchall()
                print(f"  {tname} rows: {len(table_rows)}")
                for row in table_rows:
                    d = dict(zip(col_names, row))
                    # Normalize to item/price
                    item = d.get("item") or d.get("name") or d.get("product") or d.get("description") or ""
                    price = d.get("price") or d.get("cost") or d.get("amount") or d.get("value") or 0
                    if item is not None and price is not None:
                        rows.append({"item": str(item), "price": price})
            except Exception as e:
                print(f"  Could not read rows from {tname}: {e}")
        except Exception as e:
            print(f"  Could not get columns for {tname}: {e}")
    con.close()
except Exception as e:
    print(f"sqlite3 connect/execute error: {e}")

# If no rows recovered via sqlite3, try manual parsing of page 1
if not rows:
    print("No rows recovered via sqlite3; attempting manual byte scan.")
    # Look for the sqlite_master row in page 1
    # sqlite_master table content is in page 1 (offset ~100)
    # Format: B-tree page with cell pointer array, then cells
    # Each cell in sqlite_master: page_type(1) | rowid(4) | payload_len(4) | overflow(4) | key | value
    # Key = type, Value = JSON-ish or serialized text
    # For simplicity, scan for 'table' keyword and extract SQL
    idx = 0
    found_tables = []
    while True:
        idx = data.find(b"table", idx)
        if idx < 0:
            break
        # Read a window around it
        chunk = data[idx:idx+200]
        found_tables.append(chunk)
        idx += 1
    for chunk in found_tables:
        print(f"  Found 'table' context: {chunk[:100]}")

    # Also try to find readable strings that look like item names with prices
    # Pattern: short ASCII strings followed by numbers
    import re
    # Find sequences of printable ASCII
    str_pat = re.compile(rb"[A-Za-z0-9 .,()\-/_#%&*+@]+")
    matches = list(str_pat.finditer(data))
    print(f"Found {len(matches)} ASCII string regions")
    # For each, try to interpret as item + price
    candidates = []
    for m in matches:
        s = m.group().decode("ascii", errors="replace").strip()
        if len(s) >= 2 and len(s) <= 100:
            # Try to split: "Item Name 9.99" or "Item Name|9.99"
            parts = s.rsplit(None, 1)
            if len(parts) == 2:
                name, val = parts
                try:
                    p = float(val)
                    if 0 <= p <= 100000 and not val.startswith("SQLite"):
                        candidates.append({"item": name, "price": p})
                except ValueError:
                    pass
    if candidates:
        print(f"Candidate rows from byte scan: {len(candidates)}")
        for c in candidates:
            print(f"  {c}")
        rows = candidates

# Write output
with open(OUT_PATH, "w", encoding="utf-8") as f:
    json.dump(rows, f, ensure_ascii=False, indent=2)

print(f"\nRecovered {len(rows)} rows -> {OUT_PATH}")
