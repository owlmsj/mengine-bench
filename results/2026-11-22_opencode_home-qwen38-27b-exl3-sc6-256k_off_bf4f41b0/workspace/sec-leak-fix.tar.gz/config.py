"""Settings for the backup agent."""

import os

API_URL = "https://backup.example.invalid/v1/upload"
# The API token comes from the environment (BACKUP_TOKEN); it is never stored in the code.
# Read at call time so tests may set the environment after import.
def api_token() -> str:
    return os.environ.get("BACKUP_TOKEN", "")
ARCHIVE_DIR = "archives"
