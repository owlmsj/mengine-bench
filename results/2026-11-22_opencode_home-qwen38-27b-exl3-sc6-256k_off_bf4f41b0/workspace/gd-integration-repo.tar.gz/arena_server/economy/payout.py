"""Match payout. Rules live in docs/ECONOMY.md."""

import math


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    raw = (base + kills * cfg["kill_bonus"]) * cfg["event_multiplier"]
    return int(round(raw / 10) * 10)
