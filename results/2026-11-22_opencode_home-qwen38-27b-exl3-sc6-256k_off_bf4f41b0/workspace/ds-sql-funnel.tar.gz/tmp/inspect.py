import sqlite3
con = sqlite3.connect('analytics.db')
cur = con.cursor()
for t in ('users', 'events'):
    print(t, cur.execute(f'PRAGMA table_info({t})').fetchall())
    for r in cur.execute(f'SELECT * FROM {t} LIMIT 8'):
        print(r)
    print(t, 'count', cur.execute(f'SELECT COUNT(*) FROM {t}').fetchone())
print('platforms', cur.execute('SELECT platform, COUNT(*) FROM users GROUP BY platform').fetchall())
print('event_types', cur.execute('SELECT DISTINCT event_type FROM events').fetchall())
print('users null platform sample', cur.execute("SELECT * FROM users WHERE platform IS NULL LIMIT 5").fetchall())
