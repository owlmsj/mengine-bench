import sqlite3
con = sqlite3.connect('analytics.db')
cur = con.cursor()
print('install by platform (non-test):', cur.execute(
    "SELECT u.platform, COUNT(DISTINCT e.user_id) FROM events e JOIN users u ON u.user_id=e.user_id WHERE u.is_test=0 AND e.name='install' GROUP BY u.platform").fetchall())
print('purchase by platform (non-test):', cur.execute(
    "SELECT u.platform, COUNT(DISTINCT e.user_id) FROM events e JOIN users u ON u.user_id=e.user_id WHERE u.is_test=0 AND e.name='purchase' GROUP BY u.platform").fetchall())
print('users with install event:', cur.execute(
    "SELECT u.platform, COUNT(*) FROM users u JOIN events e ON e.user_id=u.user_id WHERE u.is_test=0 AND e.name='install' GROUP BY u.platform").fetchall())
# duplicate events for same user same name
print('dup name+user rows:', cur.execute(
    "SELECT user_id, name, COUNT(*) FROM events GROUP BY user_id, name HAVING COUNT(*)>1").fetchall()[:10])
