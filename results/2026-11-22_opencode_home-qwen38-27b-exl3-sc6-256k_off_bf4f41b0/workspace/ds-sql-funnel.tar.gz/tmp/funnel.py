import sqlite3, json
con = sqlite3.connect('analytics.db')
cur = con.cursor()
print('event names:', cur.execute('SELECT DISTINCT name FROM events').fetchall())
print('test users:', cur.execute('SELECT is_test, COUNT(*) FROM users GROUP BY is_test').fetchall())
# events for users not in users table
print('orphan event users:', cur.execute("SELECT COUNT(DISTINCT user_id) FROM events WHERE user_id NOT IN (SELECT user_id FROM users)").fetchone())

steps = ['install', 'tutorial_complete', 'first_match', 'purchase']
# first occurrence per user per event (non-test users only; events join users)
rows = cur.execute("""
SELECT u.platform, u.user_id, e.name, MIN(e.ts)
FROM users u JOIN events e ON e.user_id = u.user_id
WHERE u.is_test = 0
GROUP BY u.platform, u.user_id, e.name
""").fetchall()

by_user = {}
for plat, uid, name, ts in rows:
    by_user.setdefault(uid, {'platform': plat, 'd': {}})['d'][name] = ts

funnel = {}
for plat in sorted({v['platform'] for v in by_user.values()}):
    reached_counts = {i: 0 for i in range(len(steps) + 1)}
    for v in by_user.values():
        if v['platform'] != plat:
            continue
        d = v['d']
        last_ts = None
        reached = 0
        for i, s in enumerate(steps):
            if s not in d:
                break
            if last_ts is not None and d[s] < last_ts:
                break  # step before previous step: invalid, stop
            last_ts = d[s]
            reached = i + 1
        reached_counts[reached] += 1
    fun = {s: 0 for s in steps}
    for reached, n in reached_counts.items():
        for i in range(reached):
            fun[steps[i]] += n
    funnel[plat] = fun

print(json.dumps(funnel, indent=2))

result = {
    'funnel': funnel,
    'biggest_drop': {},
}
for plat, fun in funnel.items():
    best = None  # (conv, step)
    for i, s in enumerate(steps):
        if i == 0:
            continue
        prev = fun[steps[i-1]]
        conv = (fun[s] / prev) if prev else 0.0
        if best is None or conv < best[0]:
            best = (conv, s)
    result['biggest_drop'][plat] = best[1]
print(json.dumps(result, indent=2))
with open('result.json', 'w') as f:
    json.dump(result, f, indent=2)
print('written result.json')
con.close()
