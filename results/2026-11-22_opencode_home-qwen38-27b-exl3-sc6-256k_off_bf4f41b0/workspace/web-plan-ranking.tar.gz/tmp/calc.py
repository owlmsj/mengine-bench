from datetime import date

# Annual IPCA (IBGE), % - standard published values 1984-1995
ipca = {
    1984: 174.05,
    1985: 264.65,
    1986: 236.01,
    1987: 453.65,
    1988: 764.50,
    1989: 1974.17,
    1990: 5789.54,
    1991: 2555.70,
    1992: 1114.28,
    1993: 2477.81,
    1994: 948.62,
    1995: 22.41,
}

plans = [
    # name, launch date, year Y, next plan launch date
    ("Cruzado",  date(1986, 2, 28), 1986, date(1987, 6, 12)),
    ("Bresser",  date(1987, 6, 12), 1987, date(1989, 1, 15)),
    ("Verão",    date(1989, 1, 15), 1989, date(1990, 3, 15)),
    ("Collor I", date(1990, 3, 15), 1990, date(1991, 1, 31)),
    ("Collor II", date(1991, 1, 31), 1991, date(1994, 7, 1)),
    ("Real",     date(1994, 7, 1),  1994, None),
]

def months_lasted(d1, d2):
    # whole calendar months from d1 to d2
    m = (d2.year - d1.year) * 12 + (d2.month - d1.month)
    if d2.day < d1.day:
        m -= 1
    return m

rows = []
for name, launch, y, nxt in plans:
    before = ipca[y-1]
    after = ipca[y+1]
    if nxt is None:
        months = 60
    else:
        months = months_lasted(launch, nxt)
    score_drop = min(max(1 - after/before, 0), 1)
    score_dur = min(months, 60)/60
    score = 0.7*score_drop + 0.3*score_dur
    rows.append((name, launch.isoformat(), before, after, months, round(score_drop,4), round(score_dur,4), round(score,4)))

for r in rows:
    print(r)

ranked = sorted(rows, key=lambda r: -r[7])
print("\nTop 3:", [r[0] for r in ranked[:3]])
