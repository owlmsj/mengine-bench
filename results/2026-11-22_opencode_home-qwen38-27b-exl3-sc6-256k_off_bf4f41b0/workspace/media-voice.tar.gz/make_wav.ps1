Add-Type -AssemblyName System.Speech
$s = New-Object System.Speech.Synthesis.SpeechSynthesizer
$w = New-Object System.IO.MemoryStream
$s.SetOutputToWaveStream($w)
$s.Speak('Welcome aboard the evening ferry, please keep your bags clear of the doors.')
$s.Dispose()
$w.Position = 0
$bytes = $w.ToArray()
$out = Join-Path (Get-Location) 'announcement.wav'
[System.IO.File]::WriteAllBytes($out, $bytes)
$fs = [System.IO.File]::OpenRead($out)
$hdr = New-Object byte[] 44
$null = $fs.Read($hdr, 0, 44)
$rate = [BitConverter]::ToInt32($hdr, 24)
$bps = [BitConverter]::ToInt16($hdr, 22)
$ch = [BitConverter]::ToInt16($hdr, 2)
$fs.Close()
$len = $bytes.Length
$dur = [math]::Round(($len - 44) / ($rate * $ch * ($bps / 8)), 2)
Write-Output "bytes=$len rate=$rate bits=$bps channels=$ch duration_sec=$dur"
