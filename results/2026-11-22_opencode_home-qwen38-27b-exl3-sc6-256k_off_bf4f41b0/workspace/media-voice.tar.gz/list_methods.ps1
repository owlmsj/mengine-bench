Add-Type -AssemblyName System.Speech
$t = [System.Speech.Synthesis.SpeechSynthesizer]
$names = $t.GetMethods() | ForEach-Object { $_.Name }
$names | Where-Object { $_ -match 'Output|Speak|Wav' } | Sort-Object -Unique
