# HANDOFF — local-9b Q5 @128k

Goal: local-9b (Q5) at 128k context, GPU-only, no VRAM spill. Done.

Working recipe: `--no-mmproj-offload -ub 512` — decode 38.0 t/s (median of 3), VRAM 7697 MiB (WDDM ceiling 7881; the 1494 MiB Shared-Usage spill counter is noise). Baseline: 37.8 t/s, 7881 MiB with spill. Applied in `scripts/start_server.ps1:165` (local9 block) and `profiles/local/local-9b.json`. Q6_K (7.03 GiB) does not fit, discarded; Q4_K_M (7305 MiB, 40.4 t/s) fallback only. Measure: `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`; short prompts are irrelevant (prefill) — full 128k only.

Pending: (1) evals README still cites `check_vision.ps1`, which no longer exists — update it. (2) Review scratchpad temp-file names.

Assumption: this workspace holds only the transcript; the real repo is where it ran. Verify the applied files match the recipe before re-measuring.

Found: all numbers quoted verbatim from session/transcript.md (lines 30, 44, 124, 132, 185, 222).
