import csv, json, math

path = r"<WORKSPACE>\telemetry\playtest_ab.csv"

# Dedupe by session_id (ETL resends sessions). Keep first occurrence per session.
sessions = {}
bad = 0
with open(path, newline="", encoding="utf-8") as f:
    for row in csv.DictReader(f):
        sid = row["session_id"].strip()
        variant = row["variant"].strip().lower()
        comp = int(row["completed_tutorial"])
        if variant not in ("a", "b"):
            bad += 1
            continue
        if sid in sessions:
            # verify consistency of the resend
            assert sessions[sid] == (variant, comp), f"inconsistent resend {sid}"
            continue
        sessions[sid] = (variant, comp)

assert bad == 0, f"unexpected variant values: {bad}"

n = { "a": [0, 0], "b": [0, 0] }  # [completed, total]
for sid, (v, c) in sessions.items():
    n[v][1] += 1
    n[v][0] += c

p_a = n["a"][0] / n["a"][1]
p_b = n["b"][0] / n["b"][1]

# Two-proportion pooled z-test, two-sided
p_pool = (n["a"][0] + n["b"][0]) / (n["a"][1] + n["b"][1])
se = math.sqrt(p_pool * (1 - p_pool) * (1 / n["a"][1] + 1 / n["b"][1]))
z = (p_b - p_a) / se
p_value = 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))

out = {
    "ship_b": bool(p_b > p_a and p_value < 0.05),
    "sessions_a": n["a"][1],
    "sessions_b": n["b"][1],
    "completion_rate_a": round(p_a, 6),
    "completion_rate_b": round(p_b, 6),
    "p_value": round(p_value, 6),
}
print(json.dumps(out))
print("completed a:", n["a"][0], "completed b:", n["b"][0])
print("z =", z)
with open(r"<WORKSPACE>\result.json", "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2)
print("unique sessions:", len(sessions))
