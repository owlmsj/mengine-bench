import csv, json
from collections import defaultdict

months = ["2026-01","2026-02","2026-03","2026-04","2026-05","2026-06"]
# pnl lines per account
lines = {
 "3.1.01":"revenue","3.1.02":"revenue","3.1.09":"revenue",
 "4.1.01":"cogs","4.1.02":"cogs",
 "5.1.01":"opex","5.1.02":"opex","5.2.01":"opex","5.2.02":"opex",
 "5.3.01":"opex","5.3.02":"opex",
 "6.1.01":"financial","6.1.02":"financial",
}
acc = defaultdict(lambda: defaultdict(float))
with open("finance/ledger.csv", encoding="utf-8") as f:
    for row in csv.DictReader(f, delimiter=";"):
        d = row["date"]  # dd/mm/yyyy
        ym = f"{row['date'].split('/')[2]}-{row['date'].split('/')[1]}"
        amt = float(row["amount"].replace(".","").replace(",","."))
        acc[ym][lines[row["account"]]] += amt

out = {}
rev = {}; cogs = {}; opex = {}; ebitda = {}; gm = {}
for m in months:
    r = acc[m]["revenue"]; c = -acc[m]["cogs"]; o = -acc[m]["opex"]
    e = r - c - o
    rev[m] = round(r,2); cogs[m] = round(c,2); opex[m] = round(o,2)
    ebitda[m] = round(e,2); gm[m] = round((r-c)/r*100, 2) if r else None
    print(m, "rev", rev[m], "cogs", cogs[m], "opex", opex[m], "ebitda", ebitda[m], "gm%", gm[m])

# burn: average of negative EBITDA of last three closed months (Apr, May, Jun)
last3 = [months[i] for i in (3,4,5)]
burn = round(-sum(ebitda[m] for m in last3)/3, 2)
cash_jun = 1847350.40
runway = round(cash_jun / burn, 2)
print("burn", burn, "cash 30/06", cash_jun, "runway", runway)

result = {
  "revenue": rev,
  "gross_margin_pct": gm,
  "ebitda": ebitda,
  "burn": burn,
  "runway_months": runway,
}
with open("result.json","w",encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
print("written result.json")
