import { HookBus } from "../src/bus.ts";
import { registerAuditPlugin } from "../src/plugin.ts";

// 1. Sequential order + emit resolves after all handlers (plugin scenario)
{
  const bus = new HookBus();
  const audit: string[] = [];
  registerAuditPlugin(bus, audit);
  const result = { tool: "bash", output: "login password=secret123 done" };
  await bus.emit("tool.after", result);
  console.log("audit:", JSON.stringify(audit));
  console.log("redacted:", result.output);
  if (JSON.stringify(audit) !== JSON.stringify(["notice: tool output is audited", "bash: login password=[redacted] done"])) throw new Error("order wrong");
  if (result.output !== "login password=[redacted] done") throw new Error("redaction wrong");
}

// 2. Failing hook: emit rejects with the same error, later handlers do not run
{
  const bus = new HookBus();
  const ran: string[] = [];
  bus.on("tool.after", async () => { ran.push("a"); });
  bus.on("tool.after", async () => { ran.push("boom"); throw new Error("hook failed"); });
  bus.on("tool.after", () => { ran.push("c"); });
  let caught = null;
  try { await bus.emit("tool.after", null); } catch (e) { caught = e; }
  if (caught === null || !(caught instanceof Error)) throw new Error("expected rejection");
  if (caught.message !== "hook failed") throw new Error("wrong error: " + caught.message);
  if (JSON.stringify(ran) !== JSON.stringify(["a", "boom"])) throw new Error("later handler ran: " + ran);
}

// 3. Self-unsubscribe during an emit: others still run in that emit, gone next emit
{
  const bus = new HookBus();
  const ran: string[] = [];
  const off = bus.on("tool.after", () => { ran.push("1"); off(); });
  bus.on("tool.after", () => { ran.push("2"); });
  bus.on("tool.after", () => { ran.push("3"); });
  await bus.emit("tool.after", null);
  if (JSON.stringify(ran) !== JSON.stringify(["1", "2", "3"])) throw new Error("self-unsub broke emit: " + ran);
  ran.length = 0;
  await bus.emit("tool.after", null);
  if (JSON.stringify(ran) !== JSON.stringify(["2", "3"])) throw new Error("unsub not applied next emit: " + ran);
}

// 4. Subscription order with async handlers of differing durations
{
  const bus = new HookBus();
  const order: string[] = [];
  bus.on("e", async () => { await new Promise(r => setTimeout(r, 30)); order.push("slow-first"); });
  bus.on("e", async () => { await new Promise(r => setTimeout(r, 5)); order.push("fast-second"); });
  await bus.emit("e", null);
  if (JSON.stringify(order) !== JSON.stringify(["slow-first", "fast-second"])) throw new Error("out of order: " + order);
}

console.log("all contract checks passed");
