$ErrorActionPreference = 'Stop'
$base = '<WORKSPACE>\backoffice'

$invoices = @{}
foreach ($line in (Get-Content "$base\invoices.csv" | Select-Object -Skip 1)) {
    $p = $line -split ','
    $id = $p[0].Trim()
    $amt = [decimal]$p[2]
    $invoices[$id] = $amt
}

# parse invoice refs from memos: formats: inv1007, INV-1015, invoice 1023, INV-1015 etc.
$payments = @{}   # id => list of amounts
$ignored = @()
foreach ($line in (Get-Content "$base\bank_statement_june.csv" | Select-Object -Skip 1)) {
    $p = $line -split ','
    $memo = $p[1].Trim()
    $amt  = [decimal]$p[2]
    # skip interest/fees
    if ($memo -match 'INTEREST|FEE|SERVICE') { $ignored += "fee/interest: $memo"; continue }
    # extract invoice number: INV-?1234 or invoice 1234
    if (-not ($memo -match '(?i)(?:INV-?|invoice\s+)(\d{4})')) {
        # PIX without identifiable invoice
        $ignored += "unidentified: $memo ($amt)"; continue
    }
    $num = $Matches[1]
    $id = "INV-$num"
    if (-not $invoices.ContainsKey($id)) { $ignored += "unknown invoice: $memo ($id)"; continue }
    if (-not $payments.ContainsKey($id)) { $payments[$id] = @() }
    $payments[$id] += , $amt
}

$unpaid = @()
$duplicated = @()
$mismatched = @()

foreach ($id in ($invoices.Keys | Sort-Object)) {
    if (-not $payments.ContainsKey($id) -or $payments[$id].Count -eq 0) {
        $unpaid += $id
        continue
    }
    $expected = $invoices[$id]
    if ($payments[$id].Count -gt 1) {
        $duplicated += $id
        continue  # per README: duplicated never also mismatched
    }
    $paid = $payments[$id][0]
    if ($paid -ne $expected) {
        $mismatched += [pscustomobject]@{ id = $id; invoiced = $expected; paid = $paid }
    }
}

Write-Output "IGNORED:"
$ignored | ForEach-Object { Write-Output "  $_" }
Write-Output "PAID IDS: $($payments.Keys -join ', ')"
Write-Output "UNPAID: $($unpaid -join ', ')"
Write-Output "DUPLICATED: $($duplicated -join ', ')"
Write-Output "MISMATCHED:"
$mismatched | ForEach-Object { Write-Output ("  {0}: invoiced={1} paid={2}" -f $_.id, $_.invoiced, $_.paid) }
