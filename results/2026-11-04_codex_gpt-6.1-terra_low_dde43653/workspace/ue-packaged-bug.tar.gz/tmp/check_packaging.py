from pathlib import Path
h = Path('Source/PixelArena/ArenaGameMode.h').read_text()
c = Path('Config/DefaultGame.ini').read_text()
assert 'UPROPERTY()\n\tTObjectPtr<UArenaScoreTracker> ScoreTracker' in h, 'ScoreTracker must be GC-tracked'
assert '+DirectoriesToAlwaysCook=(Path="/Game/Data/Palettes")' in c, 'Palette directory must be cooked'
print('Packaged-build source checks passed')
