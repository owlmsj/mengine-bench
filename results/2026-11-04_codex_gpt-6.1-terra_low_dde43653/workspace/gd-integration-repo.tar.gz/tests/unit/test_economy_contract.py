import json
import tempfile
import unittest
from pathlib import Path

from arena_server.config.loader import load_config
from arena_server.economy.payout import match_payout
from arena_server.models.profile import Profile
from arena_server.persistence.codec import decode, encode


class EconomyContract(unittest.TestCase):
    def test_environment_overrides_file_and_defaults(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as tmp:
            path = Path(tmp) / 'config.json'
            path.write_text(json.dumps({'kill_bonus': 50, 'event_multiplier': 1.25}), encoding='utf-8')
            cfg = load_config(path, env={'ARENA_KILL_BONUS': '75'})
        self.assertEqual(cfg['kill_bonus'], 75)
        self.assertEqual(cfg['event_multiplier'], 1.25)
        self.assertEqual(cfg['win_base'], 900)

    def test_credits_survive_codec_round_trip_and_old_profiles(self):
        profile = Profile('player', level=12, credits=1690, cosmetics=['skin'])
        self.assertEqual(decode(encode(profile)), profile)
        self.assertEqual(decode('{"name":"old"}').credits, 0)

    def test_decimal_half_rounds_up(self):
        cfg = load_config(env={'ARENA_EVENT_MULTIPLIER': '2.05'})
        self.assertEqual(match_payout(True, 0, cfg), 1850)

