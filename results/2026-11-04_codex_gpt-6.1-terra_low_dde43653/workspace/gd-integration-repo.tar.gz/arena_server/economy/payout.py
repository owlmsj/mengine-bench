"""Match payout. Rules live in docs/ECONOMY.md."""

from decimal import Decimal, ROUND_HALF_UP


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    raw = (Decimal(str(base)) + kills * Decimal(str(cfg["kill_bonus"]))) * Decimal(str(cfg["event_multiplier"]))
    return int((raw / 10).quantize(Decimal("1"), rounding=ROUND_HALF_UP) * 10)
