# Fact sheet: Composition with Red, Blue and Yellow

Source: https://en.wikipedia.org/wiki/Composition_with_Red,_Blue_and_Yellow

- Title: Composition with Red, Blue and Yellow (also listed as Composition II in Red, Blue, and Yellow)
- Painter: Piet Mondrian (1872-1944), Dutch painter
- Year: 1930
- Medium: oil on canvas
- Collection: Kunsthaus Zurich
- Movement: De Stijl, founded in the Netherlands in 1917 by Theo van Doesburg and Piet Mondrian
- Principles (Neoplasticism): only horizontal and vertical lines, the three primary colours red, blue and
  yellow, and the non-colours white, grey and black
- The picture: a large red square at the top right, a small blue square at the bottom left and a small yellow
  rectangle at the bottom right, divided by thick black lines on a white ground
- Why it matters: its asymmetric balance of a few primary-colour blocks became a reference for modern graphic
  design and architecture
