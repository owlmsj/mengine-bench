import json
import unittest
from pathlib import Path

import gen


class ModelConfigTest(unittest.TestCase):
    def test_configs_match_source_and_fast_coder_limit(self):
        root = Path(__file__).resolve().parent
        models = json.loads((root / "models.json").read_text(encoding="utf-8"))["models"]
        fast_coder = next(model for model in models if model["name"] == "fast-coder")
        self.assertEqual(fast_coder["context_window"], 262144)
        for filename, render in (("opencode.json", gen.opencode), ("codex.toml", gen.codex), ("claude.json", gen.claude)):
            with self.subTest(filename=filename):
                self.assertEqual((root / "out" / filename).read_text(encoding="utf-8"), render(models))


if __name__ == "__main__":
    unittest.main()
