Goal: Measure local-9b Q5 at 128k context. Assume the reported measurements and changes are accurate; project files and logs are unavailable here.

Current state: `pwsh -File scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024` initially gave 37.8 t/s and 7881 MiB, but WDDM Shared Usage showed 1494 MiB spilled, so that result does not count. With `--no-mmproj-offload` and `-ub 512`, the reported spill disappeared: 7697 MiB and 38.0 t/s median of 3. Recipe applied to `scripts/start_server.ps1:165` (local9 block) and `profiles/local/local-9b.json`. Q6_K did not fit; Q4_K_M is a fallback at 7305 MiB and 40.4 t/s.

Next: update the evals README: it still cites `check_vision.ps1`, which no longer exists. Verify the replacement and the applied recipe before closing.

Found: Q5 has a reported spill-free 128k result, with README cleanup pending. Basis: explicit measurement, configuration and pending-work entries in the transcript; independent verification is unavailable here.
