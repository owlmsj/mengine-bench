import asyncio
import unittest

from run import run_tasks


class RunTasksTests(unittest.IsolatedAsyncioTestCase):
    async def test_limit_and_completion(self):
        active = 0
        peak = 0
        done = []

        async def job(index):
            nonlocal active, peak
            active += 1
            peak = max(peak, active)
            await asyncio.sleep(0.01)
            done.append(index)
            active -= 1

        await run_tasks([lambda i=i: job(i) for i in range(8)], 2)
        self.assertEqual(peak, 2)
        self.assertCountEqual(done, range(8))

    async def test_cancellation_waits_for_cleanup(self):
        started = asyncio.Event()
        cleaned = []

        async def job():
            started.set()
            try:
                await asyncio.Event().wait()
            finally:
                await asyncio.sleep(0.01)
                cleaned.append(True)

        runner = asyncio.create_task(run_tasks([job], 1))
        await started.wait()
        runner.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await runner
        self.assertEqual(cleaned, [True])

    async def test_failure_cancels_other_jobs(self):
        started = asyncio.Event()
        cleaned = []

        async def waiting():
            started.set()
            try:
                await asyncio.Event().wait()
            finally:
                cleaned.append(True)

        async def failing():
            await started.wait()
            raise ValueError('failure')

        with self.assertRaises(ExceptionGroup) as caught:
            await run_tasks([waiting, failing], 2)
        self.assertIsInstance(caught.exception.exceptions[0], ValueError)
        self.assertEqual(cleaned, [True])

    async def test_invalid_limit(self):
        with self.assertRaises(ValueError):
            await run_tasks([], 0)
