import asyncio
from collections.abc import Awaitable, Callable, Iterable


async def run_tasks(
    tasks: Iterable[Callable[[], Awaitable[object]]], max_concurrent: int
) -> None:
    """Run jobs with a bounded worker pool, waiting for cancellation cleanup.

    A job failure cancels the other jobs and is raised in an ExceptionGroup.
    Cancelling this coroutine cancels active jobs and waits for their cleanup.
    """
    if isinstance(max_concurrent, bool) or not isinstance(max_concurrent, int) or max_concurrent < 1:
        raise ValueError(f"max_concurrent must be a positive integer, got {max_concurrent!r}")

    pending = iter(tasks)

    async def worker() -> None:
        for make_job in pending:
            await make_job()

    async with asyncio.TaskGroup() as group:
        for _ in range(max_concurrent):
            group.create_task(worker())
