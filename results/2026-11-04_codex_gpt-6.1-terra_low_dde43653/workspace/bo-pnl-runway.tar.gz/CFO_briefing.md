# First half 2026: CFO briefing

All amounts in Brazilian reais (R$). Revenue is net of refunds. Parentheses indicate losses.

| Month | Revenue | Gross margin | EBITDA |
|---|---:|---:|---:|
| January | 200,510.87 | 70.03% | (210,278.96) |
| February | 216,328.06 | 70.29% | (212,300.08) |
| March | 219,066.17 | 68.46% | (204,525.45) |
| April | 238,163.26 | 70.24% | (196,950.65) |
| May | 243,032.89 | 69.56% | (201,945.82) |
| June | 272,391.57 | 72.41% | (192,968.22) |

Revenue rose 35.85% from January to June. February's EBITDA loss widened despite revenue growth; March's margin fell to 68.46%, including a R$ 6,814.15 refund. April improved on both margin and EBITDA; May's loss widened again and includes a R$ 8,634.37 refund. June delivered the highest revenue and margin and the smallest EBITDA loss of the half. Half-year revenue was R$ 1,389,492.82 and EBITDA was a loss of R$ 1,218,969.18.

## Cash and runway

- Closing cash at 30 June: R$ 1,847,350.40.
- Board-defined burn: average monthly EBITDA loss for April to June = (196,950.65 + 201,945.82 + 192,968.22) / 3 = R$ 197,288.23 per month.
- Runway: 1,847,350.40 / 197,288.23 = 9.36 months from 30 June, assuming that burn and cash remain representative and no financing or other cash movements occur.
- Cash fell R$ 461,837.60 from 31 May to 30 June, R$ 268,869.38 more than June's EBITDA loss. EBITDA is not cash flow; the supplied records do not explain this difference. Investigate working capital, capital spending, financing and other cash movements before relying on runway as a cash forecast.

## Basis and checks

The ledger is grouped by transaction month and account using the supplied chart of accounts. Gross profit equals net revenue plus signed COGS; gross margin is gross profit divided by net revenue. EBITDA equals gross profit plus signed sales and marketing, R&D and G&A expenses. Financial income and interest are excluded. No depreciation or amortization accounts are identified in the supplied chart; the operating result is treated as EBITDA on that basis. The board's definition and the latest cash balance come from finance/README.md and finance/cash_balance.txt. This is a calculation from the supplied ledger, not evidence that accruals, completeness or the cash bridge have been independently verified.
