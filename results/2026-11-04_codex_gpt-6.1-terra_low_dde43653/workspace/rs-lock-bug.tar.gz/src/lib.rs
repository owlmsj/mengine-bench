//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

#[derive(Default)]
struct Scores {
    players: HashMap<PlayerId, i64>,
    total: i64,
}

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    scores: Arc<Mutex<Scores>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        let mut scores = self.scores.lock().unwrap();
        let old_score = scores.players.insert(id, score).unwrap_or(0);
        scores.total += score - old_score;
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let mut scores = self.scores.lock().unwrap();
        *scores.players.get_mut(&id).expect("player must exist") += points;
        scores.total += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        let mut scores = self.scores.lock().unwrap();
        let from_score = scores.players[&from];
        let to_score = scores.players[&to];
        if from == to {
            return;
        }
        scores.players.insert(from, from_score - points);
        scores.players.insert(to, to_score + points);
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        self.scores.lock().unwrap().players[&id]
    }

    pub fn total(&self) -> i64 {
        self.scores.lock().unwrap().total
    }
}

#[cfg(test)]
mod regression_tests {
    use super::Board;
    use std::sync::mpsc;
    use std::thread;
    use std::time::Duration;

    #[test]
    fn replacing_player_updates_total() {
        let board = Board::new();
        board.join(1, 10);
        board.join(1, 4);
        assert_eq!(board.total(), 4);
    }

    #[test]
    fn concurrent_awards_are_not_lost() {
        let board = Board::new();
        board.join(1, 0);
        let threads: Vec<_> = (0..8)
            .map(|_| {
                let board = board.clone();
                thread::spawn(move || {
                    for _ in 0..10000 {
                        board.award(1, 1);
                    }
                })
            })
            .collect();
        for thread in threads {
            thread.join().unwrap();
        }
        assert_eq!((board.score(1), board.total()), (80000, 80000));
    }

    #[test]
    fn transfers_complete_in_both_directions_and_to_self() {
        let board = Board::new();
        board.join(1, 100);
        board.join(2, 100);
        let (send, receive) = mpsc::channel();
        for (from, to) in [(1, 2), (2, 1), (1, 1)] {
            let board = board.clone();
            let send = send.clone();
            thread::spawn(move || {
                for _ in 0..1000 {
                    board.transfer(from, to, 1);
                }
                send.send(()).unwrap();
            });
        }
        for _ in 0..3 {
            receive.recv_timeout(Duration::from_secs(5)).unwrap();
        }
        assert_eq!(
            (board.score(1), board.score(2), board.total()),
            (100, 100, 200)
        );
    }
}
