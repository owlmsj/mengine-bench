
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js';
const scene=new THREE.Scene(); scene.background=new THREE.Color('#e9dfc4');
const camera=new THREE.OrthographicCamera(-8,8,5,-5,.1,100); camera.position.set(0,0,30); camera.lookAt(0,0,0);
const renderer=new THREE.WebGLRenderer({antialias:true}); renderer.setPixelRatio(Math.min(devicePixelRatio,2)); renderer.setSize(innerWidth,innerHeight); renderer.outputColorSpace=THREE.SRGBColorSpace; document.body.appendChild(renderer.domElement);
scene.add(new THREE.AmbientLight(0xffffff,2)); const light=new THREE.DirectionalLight(0xfff3d9,2); light.position.set(-4,8,15);scene.add(light);
const palette={ink:0x123d59,deep:0x124865,blue:0x206c8d,mid:0x4c91a0,foam:0xecebd9,white:0xf6f1dd,sand:0xd7ad80,wood:0xc78e68};
function shape(points,color,z,depth=.08){const s=new THREE.Shape();s.moveTo(...points[0]);for(const p of points.slice(1))s.lineTo(...p);s.closePath();const g=new THREE.ExtrudeGeometry(s,{depth,bevelEnabled:true,bevelThickness:.025,bevelSize:.025,bevelSegments:1});const m=new THREE.Mesh(g,new THREE.MeshStandardMaterial({color,roughness:1,flatShading:true}));m.position.z=z;scene.add(m);return m}
function line(points,color,z,width=.025){const curve=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(p[0],p[1],z)));const mesh=new THREE.Mesh(new THREE.TubeGeometry(curve,Math.max(8,points.length*4),width,4,false),new THREE.MeshStandardMaterial({color,roughness:1,flatShading:true}));scene.add(mesh);return mesh}
// Distant horizon and the unmistakable snow-capped cone.
shape([[-8,-1.4],[-5,-1.55],[-2,-1.5],[1,-1.7],[4,-1.4],[8,-1.25],[8,-5],[-8,-5]],0x9a9a89,-6);
shape([[.7,-2.65],[2.15,-.95],[3.65,-2.65]],palette.ink,-4);
shape([[1.44,-1.78],[2.15,-.95],[2.93,-1.87],[2.57,-1.7],[2.43,-1.83],[2.27,-1.62],[2.1,-1.77],[1.94,-1.59],[1.75,-1.83]],palette.white,-3.8);
// The wave's arched body curls over the open sky.
shape([[-8,-5],[-8,-1.35],[-7,-1.15],[-6.3,-.55],[-5.7,.35],[-5,1.2],[-4.2,2],[-3.35,2.75],[-2.5,3.15],[-1.65,3.12],[-.9,2.82],[-.35,2.35],[.15,2.1],[.42,1.55],[.15,1.75],[-.25,1.65],[-.55,1.2],[-.9,.55],[-1.02,-.2],[-.78,-.85],[-.15,-1.7],[.8,-2.45],[2,-3.1],[3,-5]],palette.foam,-1);
shape([[-8,-4.7],[-8,-2.1],[-7.3,-2.25],[-6.8,-1.7],[-6.1,-1.35],[-5.5,-.9],[-4.9,-.35],[-4.45,.25],[-4.1,.85],[-3.9,1.6],[-3.45,2.15],[-2.95,2.38],[-2.45,2.3],[-2.05,1.98],[-1.55,2.03],[-1.1,1.8],[-1.0,1.3],[-1.4,.72],[-1.65,.1],[-1.58,-.7],[-1.14,-1.45],[-.35,-2.25],[.7,-2.9],[2.5,-5]],palette.ink,-.6);
// Long facets follow the wave's curve.
for(let i=0;i<5;i++){let x=-4.25+i*.52;shape([[x-1.5,-2.8],[x-1,-1.6],[x-.55,-.7],[x-.35,.25],[x-.15,1.1],[x+.15,1.72],[x+.47,1.93],[x+.25,1.3],[x+.13,.4],[x+.04,-.55],[x+.35,-1.4],[x+1.5,-2.8]],i%2?palette.blue:palette.deep,-.3+i*.015)}
// Foam fingers, modeled as angular white tapered arms.
function finger(x,y,scale,rot){const p=[[0,0],[.12,.27],[.22,.48],[.42,.62],[.58,.56],[.65,.39],[.55,.33],[.48,.45],[.35,.43],[.27,.25],[.2,0]];const c=Math.cos(rot),s=Math.sin(rot);shape(p.map(([a,b])=>[x+scale*(a*c-b*s),y+scale*(a*s+b*c)]),palette.white,.2)}
for(let i=0;i<18;i++){let t=i/17;let x=-4.3+4.4*t;let y=1.5+1.05*Math.sin(t*Math.PI)-.25*t;finger(x,y,.65+(.22*Math.sin(i*2)), -.9+1.1*t)}
for(let i=0;i<18;i++){let x=-7.5+(i%9)*.45,y=-1.45+Math.floor(i/9)*.38+.16*Math.sin(i*2);finger(x,y,.48,-.3)}
// Layered swells create depth and carry the three boats.
shape([[-8,-3.7],[-6.6,-3.45],[-5.5,-3.7],[-4.6,-3.5],[-3.7,-2.85],[-2.75,-1.95],[-2.3,-1.7],[-1.85,-1.9],[-1.2,-2.55],[-.2,-3.05],[1,-3.5],[2.4,-3.65],[4.1,-3.55],[5.5,-3.1],[6.8,-2.25],[8,-1.15],[8,-5],[-8,-5]],palette.white,1);
shape([[-8,-4.35],[-6.5,-4.05],[-5,-4.2],[-3.7,-3.9],[-2.8,-3.25],[-2.2,-2.52],[-1.7,-2.6],[-1.05,-3.25],[0,-3.72],[1.5,-4],[3,-4.06],[4.8,-3.8],[6.3,-3.1],[8,-2.25],[8,-5],[-8,-5]],palette.mid,1.2);
shape([[-8,-4.7],[-6.5,-4.45],[-5,-4.6],[-3.6,-4.3],[-2.4,-3.5],[-1.9,-3.05],[-1.2,-3.55],[.1,-4.1],[1.7,-4.35],[3.4,-4.4],[5,-4.06],[6.7,-3.35],[8,-2.85],[8,-5],[-8,-5]],palette.deep,1.4);
for(let i=0;i<5;i++){let y=-4.75+i*.26;line([[-.5,y],[1.5,y-.15],[3.4,y-.12],[5.4,y+.18],[7.8,y+1.1]],i%2?palette.mid:palette.foam,1.7,.035)}
function boat(x,y,scale,angle){const group=new THREE.Group();scene.add(group);group.position.set(x,y,2.3);group.rotation.z=angle;group.scale.setScalar(scale);function part(points,col,z){const s=new THREE.Shape();s.moveTo(...points[0]);points.slice(1).forEach(p=>s.lineTo(...p));s.closePath();const mesh=new THREE.Mesh(new THREE.ExtrudeGeometry(s,{depth:.12,bevelEnabled:false}),new THREE.MeshStandardMaterial({color:col,flatShading:true,roughness:1}));mesh.position.z=z;group.add(mesh)}part([[-2,.18],[-1.35,-.27],[.95,-.28],[1.65,-.1],[2,.28],[1.38,.08],[-1.35,.05]],palette.wood,0);part([[-1.45,.08],[1.45,.09],[1.15,-.04],[-1.1,-.05]],palette.sand,.14);for(let i=0;i<7;i++){let xx=-.65+i*.28;const head=new THREE.Mesh(new THREE.IcosahedronGeometry(.09,0),new THREE.MeshStandardMaterial({color:palette.sand,flatShading:true}));head.position.set(xx,.16,.25);group.add(head);part([[xx-.1,.06],[xx-.05,.18],[xx+.06,.18],[xx+.13,.04]],palette.ink,.16)}return group}
const boats=[boat(-5.9,-2.5,.74,-.35),boat(3.9,-2.55,.83,.31),boat(1.15,-4.05,1.1,-.12)];
// Floating foam chips and short broken ink marks.
for(let i=0;i<55;i++){let x=-6.7+(i*1.618%6.5),y=-3.9+(i*2.113%3.8);const chip=new THREE.Mesh(new THREE.IcosahedronGeometry(.025+(i%3)*.014,0),new THREE.MeshStandardMaterial({color:i%4?palette.white:palette.mid,flatShading:true}));chip.position.set(x,y,2);scene.add(chip)}
function resize(){const aspect=innerWidth/innerHeight;const view=10;camera.left=-view*aspect/2;camera.right=view*aspect/2;camera.top=view/2;camera.bottom=-view/2;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)}addEventListener('resize',resize);resize();
const clock=new THREE.Clock();function animate(){const t=clock.getElapsedTime();boats.forEach((b,i)=>{b.position.y=[-2.5,-2.55,-4.05][i]+Math.sin(t*.7+i)*.035;b.rotation.z=[-.35,.31,-.12][i]+Math.sin(t*.6+i)*.012});renderer.render(scene,camera);requestAnimationFrame(animate)}animate();

