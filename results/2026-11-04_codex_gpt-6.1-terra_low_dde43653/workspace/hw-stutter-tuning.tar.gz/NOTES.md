# Owner notes - rig "arena-01"

The game hitches every few seconds even though the average frame rate looks fine.
Capture: PresentMon on Arena.exe for one minute in the same replay, plus a 1 s sensor log
taken at the same time (same clock: second 0 of both files is the same instant).
settings.json is a dump of the rig's current settings.

How we measure:
- Average FPS = frames presented divided by the capture's seconds (1000 / mean MsBetweenPresents).
- 1% low = the FPS at the 99th percentile frame time (1000 / p99 of MsBetweenPresents).

Fixed constraints:
- The GPU stays at its current PCIe link speed (Gen5 x4): the slot is shared with the
  AI workload and that link speed is validated for it.
- No BIOS overclock changes (XMP, PBO, core ratio stay as they are).
