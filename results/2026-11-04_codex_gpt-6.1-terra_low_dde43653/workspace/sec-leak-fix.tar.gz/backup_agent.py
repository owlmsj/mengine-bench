"""Backup agent: packs a folder chosen in the intranet web form and uploads it to the backup API."""

from __future__ import annotations

import os
import tarfile
import urllib.request
from pathlib import Path

import config


def archive_folder(folder: str, out_dir: str = config.ARCHIVE_DIR) -> Path:
    """Packs `folder` into `out_dir/<folder name>.tar.gz` and returns the archive path."""
    source = Path(folder)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    target = out / (source.name + ".tar.gz")
    with tarfile.open(target, "w:gz") as archive:
        archive.add(source, arcname=source.name)
    return target


def send_archive(path: Path, url: str, token: str) -> int:
    """Uploads one archive to the backup API and returns the HTTP status."""
    request = urllib.request.Request(url, data=path.read_bytes(), method="POST",
                                     headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.status


def upload(path: Path) -> int:
    return send_archive(path, config.API_URL, os.environ["BACKUP_TOKEN"])


def handle_form(form: dict[str, str]) -> int:
    """Web form handler: backs up the folder the user typed."""
    return upload(archive_folder(form["folder"]))
