import logging
import os
import tarfile
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import backup_agent


class SecurityRegressionTest(unittest.TestCase):
    def test_form_metacharacters_are_only_a_folder_name(self):
        with tempfile.TemporaryDirectory(dir=".") as work:
            folder = Path(work) / "docs;echo INJECTED"
            folder.mkdir()
            (folder / "report.txt").write_text("backup", encoding="utf-8")
            with mock.patch.object(backup_agent, "send_archive", return_value=200), \
                 mock.patch.dict(os.environ, {"BACKUP_TOKEN": "[REDACTED:env]"}), \
                 mock.patch("subprocess.run", side_effect=AssertionError("command executed")):
                self.assertEqual(backup_agent.handle_form({"folder": str(folder)}), 200)
            archive = Path("archives") / (folder.name + ".tar.gz")
            try:
                with tarfile.open(archive) as packed:
                    self.assertIn(folder.name + "/report.txt", packed.getnames())
            finally:
                archive.unlink()
                archive.parent.rmdir()

    def test_upload_reads_environment_without_logging_token(self):
        with mock.patch.dict(os.environ, {"BACKUP_TOKEN": "[REDACTED:env]"}), \
             mock.patch.object(backup_agent, "send_archive", return_value=201) as send, \
             mock.patch.object(logging.Logger, "_log") as logged:
            self.assertEqual(backup_agent.upload(Path("archive.tar.gz")), 201)
        self.assertEqual(send.call_args.args[2], "test-secret")
        logged.assert_not_called()
