import { test } from "node:test";
import assert from "node:assert/strict";
import { HookBus } from "./src/bus.ts";
import { registerAuditPlugin } from "./src/plugin.ts";

test("audit hooks run in order despite self-unsubscription", async () => {
  const bus = new HookBus();
  const audit: string[] = [];
  registerAuditPlugin(bus, audit);
  await bus.emit("tool.after", { tool: "read", output: "password=secret" });
  await bus.emit("tool.after", { tool: "read", output: "password=again" });
  assert.deepEqual(audit, ["notice: tool output is audited", "read: password=[redacted]", "read: password=[redacted]"]);
});

test("emit snapshots subscriptions and propagates the first error", async () => {
  const bus = new HookBus();
  const seen: string[] = [];
  const failure = new Error("hook failed");
  let off = () => {};
  bus.on("event", () => { seen.push("first"); off(); bus.on("event", () => { seen.push("late"); }); });
  off = bus.on("event", async () => { await Promise.resolve(); seen.push("second"); throw failure; });
  bus.on("event", () => { seen.push("third"); });
  await assert.rejects(bus.emit("event", null), (error: unknown) => error === failure);
  assert.deepEqual(seen, ["first", "second"]);
  seen.length = 0;
  await bus.emit("event", null);
  assert.deepEqual(seen, ["first", "third", "late"]);
});
