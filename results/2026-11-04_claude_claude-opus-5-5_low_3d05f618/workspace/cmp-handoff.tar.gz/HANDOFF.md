# HANDOFF: local-9b Q5 at 128k context

Goal: run local-9b Q5 at ctx 131072 without VRAM spill.

Done (per transcript):
- First run (`scripts/measure_decode.ps1 -Ctx 131072 -NPredict 1024`): 37.8 t/s, 7881 MiB. INVALID: that is the WDDM ceiling, 1494 MiB spilled to Shared.
- Fix: `--no-mmproj-offload` + `-ub 512`. VRAM 7697 MiB, no spill, decode 38.0 t/s (median of 3). This is the valid number.
- Q6_K (7.03 GiB) does not fit at 128k. Q4_K_M fits: 7305 MiB, 40.4 t/s (fallback only).
- Recipe applied: scripts/start_server.ps1:165 (local9 block) and profiles/local/local-9b.json.

Left:
1. Update evals README: it still cites check_vision.ps1, which no longer exists.
2. Not verified by me: that the edits are on disk, and that Shared Usage stays ~0 on a re-measure. Re-run the command above with the new flags and check that counter.

Source: the transcript only. I had no repo access, so nothing was re-measured.
