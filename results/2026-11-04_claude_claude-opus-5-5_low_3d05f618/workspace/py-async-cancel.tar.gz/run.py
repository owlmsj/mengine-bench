"""Bounded-concurrency async job runner (stdlib only, Python 3.11+)."""
import asyncio
from collections.abc import Awaitable, Callable, Iterable
from typing import Any


async def run_tasks(tasks: Iterable[Callable[[], Awaitable[Any]]], max_concurrent: int) -> list[Any]:
    """Run each zero-arg callable's awaitable, at most max_concurrent at once.

    Returns results in input order. A job is only created (callable invoked)
    when a slot is free. On the first failure, or on cancellation (Ctrl+C under
    asyncio.run cancels the main task), all running jobs are cancelled and
    awaited, so their finally/cleanup code runs; the error then propagates
    (failures as ExceptionGroup via TaskGroup).
    """
    if not isinstance(max_concurrent, int) or max_concurrent < 1:
        raise ValueError(f"max_concurrent must be an int >= 1, got {max_concurrent!r}")
    pending = list(enumerate(tasks))
    results: list[Any] = [None] * len(pending)
    feed = iter(pending)

    async def worker() -> None:
        for index, make_job in feed:
            results[index] = await make_job()

    async with asyncio.TaskGroup() as group:
        for _ in range(min(max_concurrent, len(pending))):
            group.create_task(worker())
    return results
