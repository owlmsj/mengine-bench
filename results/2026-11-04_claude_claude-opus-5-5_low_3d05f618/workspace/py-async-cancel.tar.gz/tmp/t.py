import asyncio, sys, signal, os, threading
sys.path.insert(0, '.')
from run import run_tasks
cur = peak = 0; cleaned = 0
def mk(i, d):
    async def job():
        global cur, peak, cleaned
        cur += 1; peak = max(peak, cur)
        try: await asyncio.sleep(d); return i
        finally: cur -= 1; cleaned += 1
    return job
print(asyncio.run(run_tasks([mk(i, .01) for i in range(10)], 3)), "peak", peak)
cleaned = 0
threading.Timer(0.2, lambda: signal.raise_signal(signal.SIGINT)).start()
try: asyncio.run(run_tasks([mk(i, 5) for i in range(10)], 4))
except KeyboardInterrupt: print("KeyboardInterrupt, cleaned", cleaned)
