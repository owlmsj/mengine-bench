//! Player scores shared between the match threads of the Pixel Arena server.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

pub type PlayerId = u32;

/// Clones share the same scores, so each match thread keeps its own handle.
#[derive(Clone, Default)]
pub struct Board {
    players: Arc<Mutex<HashMap<PlayerId, Arc<Mutex<i64>>>>>,
    total: Arc<Mutex<i64>>,
}

impl Board {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn join(&self, id: PlayerId, score: i64) {
        self.players.lock().unwrap().insert(id, Arc::new(Mutex::new(score)));
        *self.total.lock().unwrap() += score;
    }

    fn slot(&self, id: PlayerId) -> Arc<Mutex<i64>> {
        self.players.lock().unwrap()[&id].clone()
    }

    /// Adds points to a player and to the board total.
    pub fn award(&self, id: PlayerId, points: i64) {
        let slot = self.slot(id);
        // One guard per read-modify-write; separate lock/unlock lost updates.
        *slot.lock().unwrap() += points;
        *self.total.lock().unwrap() += points;
    }

    /// Moves points between two players. The board total does not change.
    /// Moving points from a player to the same player changes nothing.
    pub fn transfer(&self, from: PlayerId, to: PlayerId, points: i64) {
        // Same id would lock one mutex twice (self-deadlock).
        if from == to {
            return;
        }
        let from_slot = self.slot(from);
        let to_slot = self.slot(to);
        // Lock in id order so opposite transfers cannot deadlock (AB/BA).
        let (mut from_score, mut to_score) = if from < to {
            let f = from_slot.lock().unwrap();
            (f, to_slot.lock().unwrap())
        } else {
            let t = to_slot.lock().unwrap();
            (from_slot.lock().unwrap(), t)
        };
        *from_score -= points;
        *to_score += points;
    }

    pub fn score(&self, id: PlayerId) -> i64 {
        *self.slot(id).lock().unwrap()
    }

    pub fn total(&self) -> i64 {
        *self.total.lock().unwrap()
    }
}

#[cfg(test)]
mod concurrency_tests {
    use super::*;
    use std::thread;

    #[test]
    fn concurrent_awards_and_crossed_transfers_finish_and_add_up() {
        let board = Board::new();
        board.join(1, 0);
        board.join(2, 0);
        let handles: Vec<_> = (0..8)
            .map(|i| {
                let b = board.clone();
                thread::spawn(move || {
                    for _ in 0..10_000 {
                        b.award(1, 1);
                        if i % 2 == 0 { b.transfer(1, 2, 1) } else { b.transfer(2, 1, 1) }
                        b.transfer(1, 1, 5);
                    }
                })
            })
            .collect();
        for h in handles {
            h.join().unwrap();
        }
        assert_eq!(board.total(), 80_000);
        assert_eq!(board.score(1) + board.score(2), 80_000);
    }
}
