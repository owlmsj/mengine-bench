
const W={
 "acento": [
  "apelido",
  "fala",
  "lago",
  "pergunta",
  "prazer",
  "sotaque",
  "sílaba"
 ],
 "advogado": [
  "cachoeira",
  "coração",
  "eternidade",
  "fala",
  "hora",
  "juiz",
  "marinheiro",
  "palavra",
  "professor"
 ],
 "afeto": [
  "amor",
  "angústia",
  "carinho",
  "voz"
 ],
 "aflição": [
  "angústia",
  "ansiedade",
  "escultura",
  "felicidade",
  "pavor",
  "água"
 ],
 "aldeia": [
  "bairro",
  "capital",
  "trabalho",
  "vila"
 ],
 "alegria": [
  "felicidade",
  "queijo",
  "surpresa",
  "ternura"
 ],
 "alfaiate": [
  "açougueiro",
  "boca",
  "emprego",
  "padeiro",
  "profissão",
  "rua",
  "sapateiro",
  "susto"
 ],
 "alma": [
  "amor",
  "corpo",
  "dente",
  "fígado",
  "gíria",
  "memória",
  "palavra",
  "pátria",
  "pé"
 ],
 "almoço": [
  "carne",
  "dor",
  "frase",
  "instante",
  "jantar",
  "manteiga",
  "patrão",
  "pimenta",
  "refeição"
 ],
 "amanhã": [
  "eternidade",
  "hoje",
  "hora",
  "perna",
  "pescador",
  "porta"
 ],
 "amor": [
  "afeto",
  "alma",
  "paixão",
  "susto",
  "tristeza",
  "árvore"
 ],
 "angústia": [
  "afeto",
  "aflição",
  "compaixão",
  "dor",
  "medo",
  "riacho"
 ],
 "ano": [
  "crepúsculo",
  "manhã",
  "mês",
  "música",
  "século"
 ],
 "ansiedade": [
  "aflição",
  "manteiga",
  "medo",
  "paixão",
  "rua",
  "saudade"
 ],
 "apelido": [
  "acento",
  "história",
  "idioma",
  "irmã",
  "letra",
  "nome"
 ],
 "areia": [
  "montanha",
  "natureza",
  "ofício",
  "praia",
  "rima"
 ],
 "arroz": [
  "carne",
  "chá",
  "feijão",
  "madrugada",
  "neta",
  "trigo"
 ],
 "arte": [
  "cachoeira",
  "dicionário",
  "fotografia",
  "música",
  "romance",
  "samba"
 ],
 "ator": [
  "canção",
  "cena",
  "poesia",
  "primo"
 ],
 "aurora": [
  "crepúsculo",
  "instante",
  "madrugada",
  "prazer",
  "professor"
 ],
 "avenida": [
  "casa",
  "feijão",
  "praça",
  "quarto",
  "rua"
 ],
 "avó": [
  "avô",
  "genro",
  "idioma",
  "mãe",
  "neto",
  "pai"
 ],
 "avô": [
  "avó",
  "coração",
  "irmã",
  "pais",
  "pescoço",
  "pulmão",
  "semana"
 ],
 "açougueiro": [
  "alfaiate",
  "boca",
  "enfermeira",
  "padeiro",
  "pescador",
  "tarde"
 ],
 "açúcar": [
  "manteiga",
  "mel",
  "pimenta",
  "tempo",
  "unha"
 ],
 "bairro": [
  "aldeia",
  "igreja",
  "porta",
  "refeição",
  "rua"
 ],
 "boca": [
  "alfaiate",
  "açougueiro",
  "livro",
  "língua",
  "olho",
  "ombro",
  "rosto"
 ],
 "braço": [
  "janela",
  "língua",
  "mão",
  "ombro",
  "surpresa"
 ],
 "cabeça": [
  "corpo",
  "enfermeira",
  "mão",
  "palavra",
  "rosto"
 ],
 "cachoeira": [
  "advogado",
  "arte",
  "lago",
  "linguagem",
  "pétala",
  "riacho",
  "semente"
 ],
 "café": [
  "chá",
  "momento",
  "pimenta",
  "trabalho",
  "água"
 ],
 "campo": [
  "jardim",
  "milho",
  "onda",
  "ponte",
  "prado",
  "selva"
 ],
 "canção": [
  "ator",
  "cena",
  "idioma",
  "melodia",
  "música",
  "pai",
  "tela"
 ],
 "capital": [
  "aldeia",
  "cidade",
  "cozinha",
  "estação",
  "padeiro",
  "riacho",
  "tempo",
  "vila",
  "voz"
 ],
 "carinho": [
  "afeto",
  "compaixão",
  "esperança",
  "melancolia",
  "prado",
  "saudade",
  "ternura"
 ],
 "carne": [
  "almoço",
  "arroz",
  "filho",
  "mandioca",
  "nação",
  "ovo",
  "peixe",
  "salário"
 ],
 "carpinteiro": [
  "ferreiro",
  "patrão",
  "pedreiro",
  "trabalho",
  "vila"
 ],
 "casa": [
  "avenida",
  "dia",
  "escola",
  "igreja",
  "lar",
  "poesia"
 ],
 "cena": [
  "ator",
  "canção",
  "livro",
  "melodia",
  "mãe",
  "ponte",
  "teatro"
 ],
 "chá": [
  "arroz",
  "café",
  "dente",
  "peixe",
  "queijo",
  "vinho"
 ],
 "cidade": [
  "capital",
  "estado",
  "estação",
  "jardim",
  "país",
  "prima"
 ],
 "cinema": [
  "escultura",
  "fotografia",
  "pergunta",
  "tela"
 ],
 "comida": [
  "farinha",
  "história",
  "peito",
  "refeição",
  "água"
 ],
 "compaixão": [
  "angústia",
  "carinho",
  "contentamento",
  "esperança",
  "felicidade",
  "ovo",
  "sílaba",
  "ternura"
 ],
 "contato": [],
 "contentamento": [
  "compaixão",
  "felicidade",
  "pais",
  "prazer"
 ],
 "conto": [
  "folha",
  "herança",
  "lar",
  "livro",
  "paixão",
  "palavra",
  "romance",
  "verso"
 ],
 "conversa": [
  "fala",
  "felicidade",
  "grito",
  "silêncio"
 ],
 "coração": [
  "advogado",
  "avô",
  "jantar",
  "joelho",
  "peito",
  "pulmão",
  "rosto"
 ],
 "corpo": [
  "alma",
  "cabeça",
  "peixe",
  "pescoço"
 ],
 "cozinha": [
  "capital",
  "esquina",
  "fígado",
  "janela",
  "pai",
  "quarto",
  "voz"
 ],
 "crepúsculo": [
  "ano",
  "aurora",
  "cunhado",
  "gíria",
  "hoje",
  "ontem",
  "segundo",
  "época"
 ],
 "cunhado": [
  "crepúsculo",
  "pais",
  "sobrinho",
  "sogra"
 ],
 "dança": [
  "desenho",
  "piano",
  "rima",
  "tambor",
  "teatro",
  "voz"
 ],
 "dedo": [
  "mão",
  "palavra",
  "pé",
  "sapateiro",
  "unha"
 ],
 "dente": [
  "alma",
  "chá",
  "hoje",
  "língua",
  "pescoço",
  "pulmão",
  "sogra"
 ],
 "desenho": [
  "dança",
  "escultura",
  "noite",
  "prima",
  "tela"
 ],
 "dia": [
  "casa",
  "letra",
  "manhã",
  "semana",
  "tarde"
 ],
 "dicionário": [
  "arte",
  "significado",
  "sinônimo",
  "voz"
 ],
 "dicionário criativo": [],
 "dor": [
  "almoço",
  "angústia",
  "mágoa",
  "saudade"
 ],
 "emprego": [
  "alfaiate",
  "esperança",
  "eternidade",
  "jantar",
  "mercado",
  "profissão",
  "salário"
 ],
 "enfermeira": [
  "açougueiro",
  "cabeça",
  "médico",
  "professor",
  "violão",
  "época"
 ],
 "engenheiro": [
  "irmão",
  "juiz",
  "lavrador",
  "marinheiro",
  "ternura",
  "trabalho"
 ],
 "era": [
  "mês",
  "palavra",
  "século",
  "teatro",
  "época"
 ],
 "escola": [
  "casa",
  "esperança",
  "esquina",
  "igreja"
 ],
 "escultura": [
  "aflição",
  "cinema",
  "desenho",
  "jardim",
  "olho",
  "sobrinho",
  "violão"
 ],
 "espanto": [
  "esperança",
  "país",
  "surpresa",
  "susto"
 ],
 "esperança": [
  "carinho",
  "compaixão",
  "emprego",
  "escola",
  "espanto",
  "nostalgia",
  "saudade"
 ],
 "esquina": [
  "cozinha",
  "escola",
  "pescador",
  "ponte",
  "praça"
 ],
 "estado": [
  "cidade",
  "mão",
  "médico",
  "poesia",
  "praça",
  "pátria"
 ],
 "estação": [
  "capital",
  "cidade",
  "mercado",
  "porto",
  "susto",
  "tia"
 ],
 "estômago": [
  "fígado",
  "irmão",
  "língua",
  "pulmão"
 ],
 "eternidade": [
  "advogado",
  "amanhã",
  "emprego",
  "instante",
  "madrugada",
  "passado",
  "peixe"
 ],
 "fala": [
  "acento",
  "advogado",
  "conversa",
  "voz"
 ],
 "família": [
  "herança",
  "nora",
  "parentesco",
  "susto"
 ],
 "farinha": [
  "comida",
  "osso",
  "pescador",
  "pão",
  "trigo",
  "vinho"
 ],
 "feijão": [
  "arroz",
  "avenida",
  "mandioca",
  "milho",
  "palavra",
  "vinho"
 ],
 "felicidade": [
  "aflição",
  "alegria",
  "compaixão",
  "contentamento",
  "conversa",
  "trigo"
 ],
 "ferreiro": [
  "carpinteiro",
  "mês",
  "onda",
  "pastor",
  "sapateiro",
  "segundo"
 ],
 "filha": [
  "filho",
  "irmão",
  "manteiga",
  "nora",
  "parentesco",
  "primo",
  "tia"
 ],
 "filho": [
  "carne",
  "filha",
  "genro",
  "neto",
  "pai"
 ],
 "flor": [
  "folha",
  "mar",
  "pétala",
  "samba",
  "semente"
 ],
 "floresta": [
  "mar",
  "mata",
  "medo",
  "natureza",
  "tempo"
 ],
 "folha": [
  "conto",
  "flor",
  "raiz",
  "semente",
  "silêncio",
  "sussurro",
  "tio"
 ],
 "fotografia": [
  "arte",
  "cinema",
  "refeição",
  "rima",
  "soldado",
  "teatro"
 ],
 "frase": [
  "almoço",
  "gíria",
  "letra",
  "linguagem",
  "sentido",
  "sussurro",
  "sílaba",
  "tristeza"
 ],
 "fruto": [
  "jardim",
  "mata",
  "natureza",
  "piano",
  "semente"
 ],
 "futuro": [
  "fígado",
  "minuto",
  "passado",
  "semana",
  "século",
  "tempo"
 ],
 "fígado": [
  "alma",
  "cozinha",
  "estômago",
  "futuro",
  "pele"
 ],
 "genro": [
  "avó",
  "filho",
  "madrinha",
  "nora",
  "sogra"
 ],
 "grito": [
  "conversa",
  "linguagem",
  "pergunta",
  "silêncio",
  "sobrinho",
  "sussurro"
 ],
 "gíria": [
  "alma",
  "crepúsculo",
  "frase",
  "idioma",
  "sinônimo",
  "sotaque"
 ],
 "herança": [
  "conto",
  "família",
  "madrinha",
  "marinheiro",
  "neta",
  "pimenta",
  "prima",
  "sinônimo",
  "tio"
 ],
 "história": [
  "apelido",
  "comida",
  "memória",
  "resposta",
  "sentido",
  "surpresa",
  "tempo"
 ],
 "hoje": [
  "amanhã",
  "crepúsculo",
  "dente",
  "ontem",
  "tristeza"
 ],
 "hora": [
  "advogado",
  "amanhã",
  "minuto",
  "tempo",
  "época"
 ],
 "idioma": [
  "apelido",
  "avó",
  "canção",
  "gíria",
  "linguagem",
  "madrinha",
  "palavra",
  "tempo"
 ],
 "igreja": [
  "bairro",
  "casa",
  "escola",
  "janela",
  "mercado",
  "operário",
  "selva"
 ],
 "instante": [
  "almoço",
  "aurora",
  "eternidade",
  "momento",
  "nação",
  "segundo"
 ],
 "irmã": [
  "apelido",
  "avô",
  "irmão",
  "pintura",
  "sal",
  "tia"
 ],
 "irmão": [
  "engenheiro",
  "estômago",
  "filha",
  "irmã",
  "pais",
  "ponte",
  "tia"
 ],
 "janela": [
  "braço",
  "cozinha",
  "igreja",
  "nação",
  "pintura",
  "porta",
  "profissão"
 ],
 "jantar": [
  "almoço",
  "coração",
  "emprego",
  "mel",
  "pão"
 ],
 "jardim": [
  "campo",
  "cidade",
  "escultura",
  "fruto",
  "montanha",
  "praia",
  "pétala"
 ],
 "joelho": [
  "coração",
  "pedreiro",
  "perna",
  "pé",
  "tambor"
 ],
 "juiz": [
  "advogado",
  "engenheiro",
  "mão",
  "patrão",
  "porto",
  "soldado"
 ],
 "lago": [
  "acento",
  "cachoeira",
  "mar",
  "natureza"
 ],
 "lar": [
  "casa",
  "conto",
  "ponte",
  "praça",
  "quarto",
  "rua"
 ],
 "lavrador": [
  "engenheiro",
  "montanha",
  "ofício",
  "operário",
  "padeiro",
  "pastor",
  "pescador",
  "selva"
 ],
 "leite": [
  "mandioca",
  "manteiga",
  "pele",
  "pão",
  "queijo",
  "época"
 ],
 "letra": [
  "apelido",
  "dia",
  "frase",
  "resposta",
  "significado",
  "sílaba"
 ],
 "linguagem": [
  "cachoeira",
  "frase",
  "grito",
  "idioma",
  "riacho"
 ],
 "livro": [
  "boca",
  "cena",
  "conto",
  "ofício",
  "pintura"
 ],
 "língua": [
  "boca",
  "braço",
  "dente",
  "estômago",
  "osso",
  "tarde"
 ],
 "madrinha": [
  "genro",
  "herança",
  "idioma",
  "neta",
  "padrinho"
 ],
 "madrugada": [
  "arroz",
  "aurora",
  "eternidade",
  "manhã",
  "médico",
  "noite",
  "nome",
  "passado",
  "vila"
 ],
 "mandioca": [
  "carne",
  "feijão",
  "leite",
  "milho",
  "pimenta",
  "sentido",
  "árvore"
 ],
 "manhã": [
  "ano",
  "dia",
  "madrugada",
  "profissão",
  "tarde"
 ],
 "manteiga": [
  "almoço",
  "ansiedade",
  "açúcar",
  "filha",
  "leite",
  "milho",
  "queijo"
 ],
 "mar": [
  "flor",
  "floresta",
  "lago",
  "medo",
  "onda",
  "pétala",
  "vale"
 ],
 "marinheiro": [
  "advogado",
  "engenheiro",
  "herança",
  "médico",
  "pedreiro",
  "soldado"
 ],
 "mata": [
  "floresta",
  "fruto",
  "mercado",
  "selva",
  "árvore"
 ],
 "medo": [
  "angústia",
  "ansiedade",
  "floresta",
  "mar",
  "pavor",
  "ternura"
 ],
 "mel": [
  "açúcar",
  "jantar",
  "melancolia",
  "pastor",
  "pimenta",
  "sal"
 ],
 "melancolia": [
  "carinho",
  "mel",
  "mágoa",
  "médico",
  "nostalgia",
  "pavor",
  "tristeza"
 ],
 "melodia": [
  "canção",
  "cena",
  "piano",
  "ritmo",
  "verso"
 ],
 "memória": [
  "alma",
  "história",
  "palavra",
  "sílaba"
 ],
 "mercado": [
  "emprego",
  "estação",
  "igreja",
  "mata",
  "porta",
  "semente"
 ],
 "milho": [
  "campo",
  "feijão",
  "mandioca",
  "manteiga",
  "refeição",
  "tela",
  "trigo"
 ],
 "minuto": [
  "futuro",
  "hora",
  "noite",
  "segundo",
  "século",
  "tambor"
 ],
 "momento": [
  "café",
  "instante",
  "mês",
  "noite",
  "época"
 ],
 "montanha": [
  "areia",
  "jardim",
  "lavrador",
  "palavra",
  "prado",
  "serra"
 ],
 "mágoa": [
  "dor",
  "melancolia",
  "nostalgia",
  "palavra",
  "tristeza"
 ],
 "mãe": [
  "avó",
  "cena",
  "neto",
  "pai",
  "pais"
 ],
 "mão": [
  "braço",
  "cabeça",
  "dedo",
  "estado",
  "juiz",
  "pele"
 ],
 "médico": [
  "enfermeira",
  "estado",
  "madrugada",
  "marinheiro",
  "melancolia",
  "parentesco",
  "pastor"
 ],
 "mês": [
  "ano",
  "era",
  "ferreiro",
  "momento",
  "semana",
  "sinônimo"
 ],
 "música": [
  "ano",
  "arte",
  "canção",
  "nora",
  "pintura",
  "samba",
  "verso"
 ],
 "natureza": [
  "areia",
  "floresta",
  "fruto",
  "lago",
  "raiz",
  "romance"
 ],
 "nação": [
  "carne",
  "instante",
  "janela",
  "país",
  "pátria",
  "rua",
  "vila"
 ],
 "neta": [
  "arroz",
  "herança",
  "madrinha",
  "neto",
  "pais",
  "quarto",
  "tio"
 ],
 "neto": [
  "avó",
  "filho",
  "mãe",
  "neta",
  "romance",
  "sílaba"
 ],
 "noite": [
  "desenho",
  "madrugada",
  "minuto",
  "momento",
  "tarde"
 ],
 "nome": [
  "apelido",
  "madrugada",
  "ritmo",
  "sussurro",
  "voz"
 ],
 "nora": [
  "família",
  "filha",
  "genro",
  "música",
  "padrinho",
  "patrão",
  "peixe",
  "rosto"
 ],
 "nostalgia": [
  "esperança",
  "melancolia",
  "mágoa",
  "saudade",
  "sílaba"
 ],
 "ofício": [
  "areia",
  "lavrador",
  "livro",
  "padeiro",
  "profissão",
  "trabalho"
 ],
 "olho": [
  "boca",
  "escultura",
  "pergunta",
  "pulmão",
  "rosto"
 ],
 "ombro": [
  "boca",
  "braço",
  "pescoço",
  "água"
 ],
 "onda": [
  "campo",
  "ferreiro",
  "mar",
  "prado",
  "praia",
  "riacho",
  "tempo"
 ],
 "ontem": [
  "crepúsculo",
  "hoje",
  "pavor"
 ],
 "operário": [
  "igreja",
  "lavrador",
  "passado",
  "patrão",
  "pedreiro",
  "profissão",
  "soldado"
 ],
 "osso": [
  "farinha",
  "língua",
  "pedreiro",
  "pele",
  "pescoço",
  "sangue"
 ],
 "ovo": [
  "carne",
  "compaixão",
  "palavra",
  "peixe",
  "queijo"
 ],
 "padeiro": [
  "alfaiate",
  "açougueiro",
  "capital",
  "lavrador",
  "ofício"
 ],
 "padrinho": [
  "madrinha",
  "nora",
  "sotaque",
  "tio"
 ],
 "pai": [
  "avó",
  "canção",
  "cozinha",
  "filho",
  "mãe",
  "teatro"
 ],
 "pais": [
  "avô",
  "contentamento",
  "cunhado",
  "irmão",
  "mãe",
  "neta",
  "parentesco",
  "pavor",
  "tia"
 ],
 "paixão": [
  "amor",
  "ansiedade",
  "conto",
  "prazer",
  "unha"
 ],
 "palavra": [
  "advogado",
  "alma",
  "cabeça",
  "conto",
  "dedo",
  "era",
  "feijão",
  "idioma",
  "memória",
  "montanha",
  "mágoa",
  "ovo",
  "patrão",
  "pintura",
  "professor",
  "tia"
 ],
 "parentesco": [
  "família",
  "filha",
  "médico",
  "pais"
 ],
 "passado": [
  "eternidade",
  "futuro",
  "madrugada",
  "operário"
 ],
 "pastor": [
  "ferreiro",
  "lavrador",
  "mel",
  "médico",
  "profissão"
 ],
 "patrão": [
  "almoço",
  "carpinteiro",
  "juiz",
  "nora",
  "operário",
  "palavra",
  "salário"
 ],
 "pavor": [
  "aflição",
  "medo",
  "melancolia",
  "ontem",
  "pais",
  "ritmo",
  "susto"
 ],
 "país": [
  "cidade",
  "espanto",
  "nação",
  "porta",
  "violão"
 ],
 "pedreiro": [
  "carpinteiro",
  "joelho",
  "marinheiro",
  "operário",
  "osso",
  "pescador",
  "rio"
 ],
 "peito": [
  "comida",
  "coração",
  "pulmão",
  "unha"
 ],
 "peixe": [
  "carne",
  "chá",
  "corpo",
  "eternidade",
  "nora",
  "ovo"
 ],
 "pele": [
  "fígado",
  "leite",
  "mão",
  "osso",
  "pulmão"
 ],
 "pergunta": [
  "acento",
  "cinema",
  "grito",
  "olho",
  "resposta"
 ],
 "perna": [
  "amanhã",
  "joelho",
  "sangue"
 ],
 "pescador": [
  "amanhã",
  "açougueiro",
  "esquina",
  "farinha",
  "lavrador",
  "pedreiro",
  "praia",
  "tempo",
  "verso"
 ],
 "pescoço": [
  "avô",
  "corpo",
  "dente",
  "ombro",
  "osso",
  "pulmão",
  "sangue"
 ],
 "piano": [
  "dança",
  "fruto",
  "melodia",
  "prado",
  "sobrinho",
  "tambor",
  "violão"
 ],
 "pimenta": [
  "almoço",
  "açúcar",
  "café",
  "herança",
  "mandioca",
  "mel",
  "sal"
 ],
 "pintura": [
  "irmã",
  "janela",
  "livro",
  "música",
  "palavra",
  "tela"
 ],
 "poesia": [
  "ator",
  "casa",
  "estado",
  "queijo",
  "verso",
  "violão"
 ],
 "ponte": [
  "campo",
  "cena",
  "esquina",
  "irmão",
  "lar",
  "porto",
  "vale"
 ],
 "porta": [
  "amanhã",
  "bairro",
  "janela",
  "mercado",
  "país"
 ],
 "porto": [
  "estação",
  "juiz",
  "ponte",
  "pátria",
  "vila"
 ],
 "prado": [
  "campo",
  "carinho",
  "montanha",
  "onda",
  "piano",
  "tempo"
 ],
 "praia": [
  "areia",
  "jardim",
  "onda",
  "pescador",
  "rio"
 ],
 "prazer": [
  "acento",
  "aurora",
  "contentamento",
  "paixão",
  "ternura"
 ],
 "praça": [
  "avenida",
  "esquina",
  "estado",
  "lar",
  "pátria",
  "ternura",
  "vale",
  "violão"
 ],
 "prima": [
  "cidade",
  "desenho",
  "herança",
  "primo",
  "sobrinho"
 ],
 "primo": [
  "ator",
  "filha",
  "prima",
  "professor",
  "sobrinho",
  "tia"
 ],
 "professor": [
  "advogado",
  "aurora",
  "enfermeira",
  "palavra",
  "primo",
  "salário",
  "sapateiro",
  "água"
 ],
 "profissão": [
  "alfaiate",
  "emprego",
  "janela",
  "manhã",
  "ofício",
  "operário",
  "pastor",
  "serra"
 ],
 "pulmão": [
  "avô",
  "coração",
  "dente",
  "estômago",
  "olho",
  "peito",
  "pele",
  "pescoço",
  "unha"
 ],
 "pátria": [
  "alma",
  "estado",
  "nação",
  "porto",
  "praça",
  "tempo"
 ],
 "pão": [
  "farinha",
  "jantar",
  "leite",
  "verso"
 ],
 "pé": [
  "alma",
  "dedo",
  "joelho",
  "rosto",
  "tela"
 ],
 "pétala": [
  "cachoeira",
  "flor",
  "jardim",
  "mar",
  "semente",
  "susto"
 ],
 "quarto": [
  "avenida",
  "cozinha",
  "lar",
  "neta"
 ],
 "queijo": [
  "alegria",
  "chá",
  "leite",
  "manteiga",
  "ovo",
  "poesia"
 ],
 "raiz": [
  "folha",
  "natureza",
  "serra",
  "vale",
  "árvore"
 ],
 "refeição": [
  "almoço",
  "bairro",
  "comida",
  "fotografia",
  "milho",
  "água"
 ],
 "resposta": [
  "história",
  "letra",
  "pergunta",
  "semana"
 ],
 "riacho": [
  "angústia",
  "cachoeira",
  "capital",
  "linguagem",
  "onda",
  "rio"
 ],
 "rima": [
  "areia",
  "dança",
  "fotografia",
  "romance",
  "significado",
  "verso",
  "violão"
 ],
 "rio": [
  "pedreiro",
  "praia",
  "riacho",
  "vale"
 ],
 "ritmo": [
  "melodia",
  "nome",
  "pavor",
  "samba",
  "teatro"
 ],
 "romance": [
  "arte",
  "conto",
  "natureza",
  "neto",
  "rima",
  "samba",
  "sotaque",
  "teatro"
 ],
 "rosto": [
  "boca",
  "cabeça",
  "coração",
  "nora",
  "olho",
  "pé"
 ],
 "rua": [
  "alfaiate",
  "ansiedade",
  "avenida",
  "bairro",
  "lar",
  "nação",
  "tempo"
 ],
 "sal": [
  "irmã",
  "mel",
  "pimenta"
 ],
 "salário": [
  "carne",
  "emprego",
  "patrão",
  "professor"
 ],
 "samba": [
  "arte",
  "flor",
  "música",
  "ritmo",
  "romance",
  "violão"
 ],
 "sangue": [
  "osso",
  "perna",
  "pescoço",
  "sentido"
 ],
 "sapateiro": [
  "alfaiate",
  "dedo",
  "ferreiro",
  "professor"
 ],
 "saudade": [
  "ansiedade",
  "carinho",
  "dor",
  "esperança",
  "nostalgia"
 ],
 "segundo": [
  "crepúsculo",
  "ferreiro",
  "instante",
  "minuto"
 ],
 "selva": [
  "campo",
  "igreja",
  "lavrador",
  "mata",
  "árvore"
 ],
 "semana": [
  "avô",
  "dia",
  "futuro",
  "mês",
  "resposta"
 ],
 "semente": [
  "cachoeira",
  "flor",
  "folha",
  "fruto",
  "mercado",
  "pétala"
 ],
 "sentido": [
  "frase",
  "história",
  "mandioca",
  "sangue",
  "significado",
  "trabalho"
 ],
 "serra": [
  "montanha",
  "profissão",
  "raiz",
  "vale",
  "árvore"
 ],
 "significado": [
  "dicionário",
  "letra",
  "rima",
  "sentido"
 ],
 "silêncio": [
  "conversa",
  "folha",
  "grito",
  "sussurro"
 ],
 "sinônimo": [
  "dicionário",
  "gíria",
  "herança",
  "mês",
  "sílaba"
 ],
 "sobre": [],
 "sobrinho": [
  "cunhado",
  "escultura",
  "grito",
  "piano",
  "prima",
  "primo",
  "sotaque"
 ],
 "sogra": [
  "cunhado",
  "dente",
  "genro",
  "tempo",
  "tia"
 ],
 "soldado": [
  "fotografia",
  "juiz",
  "marinheiro",
  "operário"
 ],
 "sotaque": [
  "acento",
  "gíria",
  "padrinho",
  "romance",
  "sobrinho",
  "vinho",
  "voz"
 ],
 "surpresa": [
  "alegria",
  "braço",
  "espanto",
  "história"
 ],
 "sussurro": [
  "folha",
  "frase",
  "grito",
  "nome",
  "silêncio"
 ],
 "susto": [
  "alfaiate",
  "amor",
  "espanto",
  "estação",
  "família",
  "pavor",
  "pétala",
  "tempo"
 ],
 "século": [
  "ano",
  "era",
  "futuro",
  "minuto"
 ],
 "sílaba": [
  "acento",
  "compaixão",
  "frase",
  "letra",
  "memória",
  "neto",
  "nostalgia",
  "sinônimo"
 ],
 "tambor": [
  "dança",
  "joelho",
  "minuto",
  "piano",
  "verso"
 ],
 "tarde": [
  "açougueiro",
  "dia",
  "língua",
  "manhã",
  "noite"
 ],
 "teatro": [
  "cena",
  "dança",
  "era",
  "fotografia",
  "pai",
  "ritmo",
  "romance",
  "tempo"
 ],
 "tela": [
  "canção",
  "cinema",
  "desenho",
  "milho",
  "pintura",
  "pé"
 ],
 "tempo": [
  "açúcar",
  "capital",
  "floresta",
  "futuro",
  "história",
  "hora",
  "idioma",
  "onda",
  "pescador",
  "prado",
  "pátria",
  "rua",
  "sogra",
  "susto",
  "teatro",
  "tio"
 ],
 "ternura": [
  "alegria",
  "carinho",
  "compaixão",
  "engenheiro",
  "medo",
  "prazer",
  "praça"
 ],
 "tia": [
  "estação",
  "filha",
  "irmã",
  "irmão",
  "pais",
  "palavra",
  "primo",
  "sogra",
  "tio"
 ],
 "tio": [
  "folha",
  "herança",
  "neta",
  "padrinho",
  "tempo",
  "tia"
 ],
 "trabalho": [
  "aldeia",
  "café",
  "carpinteiro",
  "engenheiro",
  "ofício",
  "sentido"
 ],
 "trigo": [
  "arroz",
  "farinha",
  "felicidade",
  "milho",
  "unha"
 ],
 "tristeza": [
  "amor",
  "frase",
  "hoje",
  "melancolia",
  "mágoa"
 ],
 "unha": [
  "açúcar",
  "dedo",
  "paixão",
  "peito",
  "pulmão",
  "trigo"
 ],
 "vale": [
  "mar",
  "ponte",
  "praça",
  "raiz",
  "rio",
  "serra"
 ],
 "verso": [
  "conto",
  "melodia",
  "música",
  "pescador",
  "poesia",
  "pão",
  "rima",
  "tambor"
 ],
 "vila": [
  "aldeia",
  "capital",
  "carpinteiro",
  "madrugada",
  "nação",
  "porto"
 ],
 "vinho": [
  "chá",
  "farinha",
  "feijão",
  "sotaque",
  "água"
 ],
 "violão": [
  "enfermeira",
  "escultura",
  "país",
  "piano",
  "poesia",
  "praça",
  "rima",
  "samba"
 ],
 "voz": [
  "afeto",
  "capital",
  "cozinha",
  "dança",
  "dicionário",
  "fala",
  "nome",
  "sotaque"
 ],
 "água": [
  "aflição",
  "café",
  "comida",
  "ombro",
  "professor",
  "refeição",
  "vinho"
 ],
 "árvore": [
  "amor",
  "mandioca",
  "mata",
  "raiz",
  "selva",
  "serra"
 ],
 "época": [
  "crepúsculo",
  "enfermeira",
  "era",
  "hora",
  "leite",
  "momento"
 ]
};const names=Object.keys(W);const idx={};names.forEach((n,i)=>idx[n]=i);
const N=names.map((n,i)=>({n,x:Math.cos(i)*300*Math.random(),y:Math.sin(i)*300*Math.random(),vx:0,vy:0,d:W[n].length}));
const E=[];names.forEach(a=>W[a].forEach(b=>{if(a<b)E.push([idx[a],idx[b]])}));
stats.textContent=`${names.length} palavras · ${E.length} ligações · tamanho = nº de ligações`;
dl.innerHTML=names.map(n=>`<option value="${n}">`).join('');
const c=document.getElementById('c'),g=c.getContext('2d');let sel=-1,cam={x:0,y:0,s:1};
function rs(){c.width=innerWidth;c.height=innerHeight}rs();onresize=rs;
for(let k=0;k<400;k++)step(1-k/400);
function step(t){for(const a of N){for(const b of N){if(a===b)continue;let dx=a.x-b.x,dy=a.y-b.y,d=dx*dx+dy*dy+1;let f=900/d;a.vx+=dx*f*.05;a.vy+=dy*f*.05}a.vx-=a.x*.002;a.vy-=a.y*.002}
for(const[i,j]of E){let a=N[i],b=N[j],dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1,f=(d-40)*.02;a.vx+=dx/d*f;a.vy+=dy/d*f;b.vx-=dx/d*f;b.vy-=dy/d*f}
for(const a of N){a.x+=a.vx*t;a.y+=a.vy*t;a.vx*=.5;a.vy*=.5}}
const P=(a)=>[(a.x-cam.x)*cam.s+c.width/2,(a.y-cam.y)*cam.s+c.height/2];
function draw(){g.clearRect(0,0,c.width,c.height);const nb=sel<0?null:new Set(W[names[sel]].map(n=>idx[n]));
for(const[i,j]of E){const on=nb&&(i==sel||j==sel);g.strokeStyle=on?'#ffd27a':nb?'#ffffff0d':'#8890c033';g.lineWidth=on?2:1;const[a,b]=P(N[i]),[x,y]=P(N[j]);g.beginPath();g.moveTo(a,b);g.lineTo(x,y);g.stroke()}
N.forEach((a,i)=>{const[x,y]=P(a),r=2+Math.sqrt(a.d)*1.6,hot=i==sel||(nb&&nb.has(i));g.fillStyle=i==sel?'#ffd27a':hot?'#ff9f7a':nb?'#555a7a':`hsl(${220+a.d*8},70%,${55+a.d*2}%)`;g.beginPath();g.arc(x,y,r*(i==sel?1.8:1),0,7);g.fill();
if(hot||a.d>=10||cam.s>2){g.fillStyle=hot?'#fff':'#c8cbe8aa';g.font=(i==sel?'bold 18px ':'12px ')+'Fraunces';g.fillText(a.n,x+r+3,y+4)}});requestAnimationFrame(draw)}draw();
function show(w){w=(w||'').trim().toLowerCase();if(!(w in idx)){info.innerHTML=w?`<p>“${w}” não está no universo.</p>`:'';sel=-1;return}
sel=idx[w];cam.x=N[sel].x;cam.y=N[sel].y;cam.s=Math.max(cam.s,1.6);q.value=w;history.replaceState(0,'','?word='+encodeURIComponent(w));
info.innerHTML=`<h2>${w}</h2><small>${W[w].length} ligações</small><p>${W[w].map(n=>`<a data-w="${n}">${n}</a>`).join('')}</p>`}
info.onclick=e=>{if(e.target.dataset.w)show(e.target.dataset.w)};q.onchange=()=>show(q.value);
c.onclick=e=>{let best=-1,bd=200;N.forEach((a,i)=>{const[x,y]=P(a),d=(x-e.clientX)**2+(y-e.clientY)**2;if(d<bd){bd=d;best=i}});if(best>=0)show(names[best])};
c.onwheel=e=>{cam.s*=e.deltaY<0?1.15:.87};let dr=null;c.onmousedown=e=>dr=[e.clientX,e.clientY];onmouseup=()=>dr=null;
c.onmousemove=e=>{if(!dr)return;cam.x-=(e.clientX-dr[0])/cam.s;cam.y-=(e.clientY-dr[1])/cam.s;dr=[e.clientX,e.clientY]};
const fit=Math.max(...N.map(a=>Math.max(Math.abs(a.x),Math.abs(a.y))));cam.s=Math.min(c.width,c.height)/2/fit;
show(new URLSearchParams(location.search).get('word')||'');
