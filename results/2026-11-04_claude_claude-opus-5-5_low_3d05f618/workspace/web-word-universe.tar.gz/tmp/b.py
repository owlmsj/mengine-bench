import unicodedata,urllib.parse,re,os,json,sys,html
d=sys.argv[1];files={f.lower():f for f in os.listdir(d)}
def h1(f):
  t=open(os.path.join(d,f),encoding='utf-8').read();m=re.search(r'<h1>(.*?)</h1>',t);return t,(html.unescape(m.group(1)).strip().lower() if m else None)
name={};pages={}
for k,f in files.items():
  t,w=h1(f)
  if w: name[k]=w;pages[w]=t
for k,f in files.items():
  r=re.search(r'url=([^"]+)"',open(os.path.join(d,f),encoding='utf-8').read())
  if k not in name and r and r.group(1).lower() in name: name[k]=name[r.group(1).lower()]
def res(h0):
  h=h0
  h=urllib.parse.unquote(h0).lower();h=''.join(c for c in unicodedata.normalize('NFD',h) if not unicodedata.combining(c))
  return name.get(urllib.parse.unquote(h0).lower()) or name.get(h)
adj={w:set() for w in pages};miss=set();secs={}
for w,t in pages.items():
  m=re.search(r'<main>(.*?)</main>',t,re.S)
  for sid,body in re.findall(r'<section id="(\w+)">(.*?)</section>',m.group(1),re.S):
    for href,txt in re.findall(r'href="([^"]+)">(.*?)</a>',body):
      o=res(href)
      if not o: miss.add(href);continue
      if o==w: continue
      adj.setdefault(o,set());adj[w].add(o);adj[o].add(w);secs[tuple(sorted((w,o)))]=sid
  tm=re.search(r'Tema: (.*?)<',t)
W={w:sorted(v) for w,v in sorted(adj.items())}
json.dump(W,open('words.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
pairs=len(secs);mc=max(W,key=lambda w:len(W[w]))
json.dump({"words":len(W),"relations":pairs,"most_connected":mc},open('result.json','w',encoding='utf-8'),ensure_ascii=False)
print(len(W),pairs,mc,len(W[mc]),'missing',len(miss),sorted(miss)[:10],[k for k in files if k not in name][:10])
