"""Settings for the backup agent."""

API_URL = "https://backup.example.invalid/v1/upload"
# The API token is read from the BACKUP_TOKEN environment variable (see README).
ARCHIVE_DIR = "archives"
