import csv,json,collections,sys
coa={r['account']:r['pnl_line'] for r in csv.DictReader(open('finance/chart_of_accounts.csv',encoding='utf-8'),delimiter=';')}
rows=list(csv.DictReader(open('finance/ledger.csv',encoding='utf-8'),delimiter=';'))
seen=collections.Counter(tuple(r.values()) for r in rows)
print('rows',len(rows),'dups',[k for k,v in seen.items() if v>1])
agg=collections.defaultdict(float);odd=[]
for k in seen:
  d,a,desc,amt=k
  dd,mm,yy=d.split('/');m=f"{yy}-{mm}"
  if a not in coa or not m.startswith('2026-0') or int(mm)>6: odd.append(k);continue
  agg[(m,coa[a])]+=float(amt.replace('.','').replace(',','.'))
print('odd',odd)
R={};G={};E={}
for i in range(1,7):
  m=f"2026-0{i}";g=lambda l:agg[(m,l)]
  rev=g('revenue');gp=rev+g('cogs');e=gp+g('sales_marketing')+g('rnd')+g('ga')
  R[m]=round(rev,2);G[m]=round(gp/rev*100,2);E[m]=round(e,2)
  print(m,R[m],G[m],E[m],round(g('financial'),2))
burn=round(-sum(E[f"2026-0{i}"] for i in (4,5,6))/3,2)
run=round(1847350.40/burn,2)
json.dump(dict(revenue=R,gross_margin_pct=G,ebitda=E,burn=burn,runway_months=run),open('result.json','w'),indent=2)
print(burn,run)
