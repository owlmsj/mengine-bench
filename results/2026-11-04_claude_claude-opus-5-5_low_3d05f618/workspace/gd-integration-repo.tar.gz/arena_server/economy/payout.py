"""Match payout. Rules live in docs/ECONOMY.md."""

from decimal import ROUND_HALF_UP, Decimal


def match_payout(won, kills, cfg):
    base = cfg["win_base"] if won else cfg["loss_base"]
    # Decimal from str avoids binary float error (e.g. 1.15) breaking half-up at x5.
    raw = (Decimal(base) + kills * Decimal(str(cfg["kill_bonus"]))) * Decimal(str(cfg["event_multiplier"]))
    return int((raw / 10).quantize(Decimal("1"), rounding=ROUND_HALF_UP) * 10)
