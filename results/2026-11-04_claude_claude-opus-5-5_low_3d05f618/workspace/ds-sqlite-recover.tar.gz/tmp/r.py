import sys,json,struct
d=open(sys.argv[1],'rb').read()
def varint(b,i):
    v=0
    for k in range(9):
        c=b[i+k]
        if k==8: return (v<<8)|c,i+9
        v=(v<<7)|(c&0x7f)
        if c<0x80: return v,i+k+1
    return v,i+9
ps=4096
out=[]
for p in range(0,len(d),ps):
    off=0
    pg=d[p:p+ps]
    if len(pg)<off+8 or pg[off]!=13: continue
    n=struct.unpack('>H',pg[off+3:off+5])[0]
    for c in range(n):
        try:
            cp=struct.unpack('>H',pg[off+8+2*c:off+10+2*c])[0]
            if cp==0 or cp>=len(pg): continue
            ln,i=varint(pg,cp); rid,i=varint(pg,i)
            h,j=varint(pg,i); he=i+h; ts=[]
            while j<he: t,j=varint(pg,j); ts.append(t)
            vals=[];k=he
            for t in ts:
                if t==0: vals.append(None)
                elif t<=6:
                    sz=[0,1,2,3,4,6,8][t]; vals.append(int.from_bytes(pg[k:k+sz],'big',signed=True)); k+=sz
                elif t==7: vals.append(struct.unpack('>d',pg[k:k+8])[0]); k+=8
                elif t in(8,9): vals.append(t-8)
                elif t>=13 and t%2: sz=(t-13)//2; s=pg[k:k+sz]; k+=sz; assert len(s)==sz; vals.append(s.decode())
                elif t>=12: sz=(t-12)//2; vals.append(pg[k:k+sz]); k+=sz
            if k>len(pg): continue
            print(p//ps+1,rid,vals,file=sys.stderr)
            strs=[v for v in vals if isinstance(v,str)]; nums=[v for v in vals if isinstance(v,(int,float)) and not isinstance(v,bool)]
            if strs and nums and not strs[0].startswith('CREATE'): out.append({"item":strs[0],"price":nums[-1]})
        except Exception as e: pass
json.dump(out,open(sys.argv[2],'w'),indent=1,ensure_ascii=False); print(len(d),ps,len(out))
