import sqlite3,json
c=sqlite3.connect('analytics.db')
print(c.execute("select platform,is_test,count(*) from users group by 1,2").fetchall())
print(c.execute("select name,count(*) from events group by 1").fetchall())
print(c.execute("select min(ts),max(ts),min(length(ts)),max(length(ts)) from events").fetchall())
S=['install','tutorial_complete','first_match','purchase']
u={r[0]:r[1].strip().lower() for r in c.execute("select user_id,platform from users where is_test=0")}
ev={}
for uid,n,ts in c.execute("select user_id,trim(lower(name)),ts from events order by ts"):
  if uid in u: ev.setdefault(uid,[]).append((ts,n))
F={}
for uid,p in u.items():
  F.setdefault(p,[0]*4); t=None; k=0
  for ts,n in ev.get(uid,[]):
    if k<4 and n==S[k] and (t is None or ts>=t): t=ts; F[p][k]+=1; k+=1
res={"funnel":{p:dict(zip(S,v)) for p,v in sorted(F.items())},"biggest_drop":{p:S[1+min(range(3),key=lambda i:v[i+1]/v[i] if v[i] else 9)] for p,v in sorted(F.items())}}
json.dump(res,open('result.json','w'),indent=1);print(res)
